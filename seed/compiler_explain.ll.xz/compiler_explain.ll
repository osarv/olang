; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/explain:Code" = type { { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Attr" = type { %"compiler/source:Span", ptr, i32 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
@G_2ecompiler_2fexplain_2eLongValue = constant <{ [8 x i8] }> <{ [8 x i8] c"\90\01\00\00\00\00\00\00" }>, align 8
define dso_local i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i32
  %l24 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerOf(ptr %v0, ptr %t4, i64 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb5
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l15
  br label %bb4
bb4:
  %t26 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t28 = trunc i64 18 to i32
  %t29 = icmp eq i32 %t26, %t28
  %t31 = xor i1 %t29, true
  store i1 %t31, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l10, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  store i32 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l24
  br label %bb9
bb9:
  %t45 = load i32, ptr %l24, !tbaa !23
  store i32 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l45 = alloca ptr
  %l47 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i32
  %l61 = alloca { i64, ptr }
  %l65 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t8)
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l17
  br label %bb3
bb3:
  %t16 = load i64, ptr %l17, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb6:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l24, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l24, !tbaa !24
  store i64 %t43, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb12:
  br label %bb13
bb13:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l9, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l45
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l45, !tbaa !29
  store ptr %t71, ptr %l10, !tbaa !29
  %t72 = load ptr, ptr %l10, !tbaa !29
  %t74 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t72)
  store i1 %t74, ptr %l47
  br label %bb15
bb15:
  %t75 = load i1, ptr %l47, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb19
bb17:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l9, !tbaa !24
  %t82 = call i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %t78, i64 %t79)
  store i32 %t82, ptr %l52
  br label %bb18
bb18:
  %t84 = load i32, ptr %l52, !tbaa !23
  %t86 = icmp ne i32 %t84, %a1
  store i1 %t86, ptr %l49, !tbaa !21
  br label %bb19
bb19:
  %t88 = load i1, ptr %l49, !tbaa !21
  br i1 %t88, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb21:
  br label %bb22
bb22:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/load:Loader", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load ptr, ptr %l10, !tbaa !29
  %t101 = getelementptr %"compiler/ast:Func", ptr %t99, i32 0, i32 10
  %t102 = load i32, ptr %t101, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t98, i32 %t102)
  store { i64, ptr } %t105, ptr %l61
  br label %bb23
bb23:
  %t106 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t107, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l11, !tbaa !27
  %t115 = xor i1 %a2, true
  br i1 %t115, label %bb24, label %bb25
bb24:
  %t117 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = icmp sgt i64 %t119, 0
  br i1 %t121, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb30
bb26:
  %t123 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr i8, ptr %t124, i64 0
  %t126 = load i8, ptr %t125, !tbaa !32
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t126)
  store i1 %t128, ptr %l71
  br label %bb28
bb27:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb29
bb28:
  %t129 = load i1, ptr %l71, !tbaa !21
  store i1 %t129, ptr %l69, !tbaa !21
  br label %bb29
bb29:
  %t130 = load i1, ptr %l69, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l65, !tbaa !21
  br label %bb30
bb30:
  %t133 = load i1, ptr %l65, !tbaa !21
  br i1 %t133, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t134 = load ptr, ptr %lp3
  %t135 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t134, i64 %t135)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb35:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l8, !tbaa !24
  br label %bb10
bb36:
  %t142 = load ptr, ptr %lp3
  %t143 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t142
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eCaps(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca %"compiler/effects:Facts"
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca %"compiler/effects:Facts"
  %l54 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l81 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca %"compiler/effects:Facts"
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l100 = alloca { i64, ptr }
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l121 = alloca i64
  %l124 = alloca i64
  %l148 = alloca i1
  %l149 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l157 = alloca i1
  %l163 = alloca i64
  %l165 = alloca i64
  %l170 = alloca i64
  %l173 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l183 = alloca %"std/prelude/text:StringBuilder"
  %l185 = alloca i64
  %l187 = alloca i64
  %l192 = alloca i64
  %l199 = alloca i64
  %l202 = alloca i64
  %l227 = alloca ptr
  %l229 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l231 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l237 = alloca i64
  %l238 = alloca { i64, ptr }
  %l240 = alloca i1
  %l242 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t31 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l40
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l40, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 10
  %t15 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H6c17f05b74a2ea6689cdfc72c602a991(ptr %v0, ptr %v0, ptr %t13)
  store { i64, ptr } %t15, ptr %l45
  br label %bb2
bb2:
  %t16 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l47, !tbaa !24
  %t20 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t20, ptr %l48
  br label %bb3
bb3:
  %t21 = load i64, ptr %l47, !tbaa !24
  %t22 = icmp sge i64 %t21, 0
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load i64, ptr %l47, !tbaa !24
  %t25 = icmp sle i64 %t24, 115292150460684697
  br i1 %t25, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_91de52063b71ca44_3ab230bc0b47a90)
  unreachable
bb6:
  %t27 = load i64, ptr %l47, !tbaa !24
  %t28 = mul i64 %t27, 80
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  %t30 = load %"compiler/effects:Facts", ptr %l48
  store i64 0, ptr %t31
  br label %fill.32
fill.32:
  %t35 = load i64, ptr %t31
  %t36 = icmp slt i64 %t35, %t27
  br i1 %t36, label %fillb.33, label %filld.34
fillb.33:
  %t37 = getelementptr %"compiler/effects:Facts", ptr %t29, i64 %t35
  store %"compiler/effects:Facts" %t30, ptr %t37
  %t38 = add i64 %t35, 1
  store i64 %t38, ptr %t31
  br label %fill.32
filld.34:
  %t39 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t29, 1
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 14
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l54
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_91de52063b71ca44_3ab230bc0b47a90)
  unreachable
bb8:
  %t47 = load i64, ptr %l54, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = icmp sgt i64 %t48, %t49
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb14
bb11:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = sub i64 %t58, %t59
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = sub i64 %t66, 1
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = sdiv i64 %t68, %t69
  store i64 %t72, ptr %l61, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb13
bb13:
  %t74 = load i64, ptr %l61, !tbaa !24
  store i64 %t74, ptr %l58, !tbaa !24
  br label %bb14
bb14:
  %t75 = load i64, ptr %l58, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb16, label %bb17
bb16:
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t84 = load i64, ptr %l4, !tbaa !24
  %t85 = load i64, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = mul i64 %t85, %t86
  %t92 = add i64 %t84, %t89
  store i64 %t92, ptr %l9, !tbaa !24
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t95 = load i64, ptr %l9, !tbaa !24
  %t98 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eModuleOf(ptr %v0, ptr %t94, i64 %t95)
  store i64 %t98, ptr %l81
  br label %bb19
bb19:
  %t99 = load i64, ptr %l81, !tbaa !24
  store i64 %t99, ptr %l10, !tbaa !24
  %t100 = load i64, ptr %l10, !tbaa !24
  %t102 = icmp sge i64 %t100, 0
  br i1 %t102, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr %"compiler/effects:Facts", ptr %t107, i64 %t104
  store ptr %t108, ptr %l85, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t110 = load i64, ptr %l9, !tbaa !24
  %t113 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t109, i64 %t110)
  store %"compiler/effects:Facts" %t113, ptr %l88
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t114 = load ptr, ptr %l85, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s3, ptr %t114, ptr %l88)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l8, !tbaa !24
  br label %bb15
bb26:
  %t120 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l92
  br label %bb27
bb27:
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l11
  %t122 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t122, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  store i64 %t126, ptr %l14, !tbaa !24
  br label %bb28
bb28:
  %t128 = load i64, ptr %l13, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb29, label %bb30
bb29:
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t136 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t136, ptr %l100, !tbaa !27
  %t137 = load i64, ptr %l13, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr ptr, ptr %t140, i64 %t137
  %t142 = load ptr, ptr %t141, !tbaa !39
  %t146 = getelementptr %"compiler/load:Module", ptr %t142, i32 0, i32 2
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = extractvalue { i64, ptr } %t147, 0
  %t151 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t149, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l11, { i64, ptr } %t160)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t163 = load i64, ptr %l13, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l13, !tbaa !24
  br label %bb28
bb34:
  %t167 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167, ptr %l110
  br label %bb35
bb35:
  %t168 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %l16
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/generic:Program", ptr %t172, i32 0, i32 0
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/load:Loader", ptr %t175, i32 0, i32 12
  %t178 = load i64, ptr %t177, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l16, i64 %t178)
  br label %bb36
bb36:
  store i64 0, ptr %l17, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  store i64 %t183, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l18, !tbaa !24
  %t186 = load i64, ptr %l17, !tbaa !24
  %t189 = icmp sgt i64 %t185, %t186
  br i1 %t189, label %bb37, label %bb38
bb37:
  %t191 = load i64, ptr %l19, !tbaa !24
  %t193 = icmp sgt i64 %t191, 0
  br i1 %t193, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb42
bb39:
  %t195 = load i64, ptr %l18, !tbaa !24
  %t196 = load i64, ptr %l17, !tbaa !24
  %t199 = sub i64 %t195, %t196
  %t200 = load i64, ptr %l19, !tbaa !24
  %t203 = add i64 %t199, %t200
  %t205 = sub i64 %t203, 1
  %t206 = load i64, ptr %l19, !tbaa !24
  %t209 = sdiv i64 %t205, %t206
  store i64 %t209, ptr %l124, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb41
bb41:
  %t211 = load i64, ptr %l124, !tbaa !24
  store i64 %t211, ptr %l121, !tbaa !24
  br label %bb42
bb42:
  %t212 = load i64, ptr %l121, !tbaa !24
  store i64 %t212, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb43
bb43:
  %t213 = load i64, ptr %l21, !tbaa !24
  %t214 = load i64, ptr %l20, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb44, label %bb45
bb44:
  br label %bb56
bb45:
  br label %bb46
bb46:
  %t221 = load i64, ptr %l17, !tbaa !24
  %t222 = load i64, ptr %l21, !tbaa !24
  %t223 = load i64, ptr %l19, !tbaa !24
  %t226 = mul i64 %t222, %t223
  %t229 = add i64 %t221, %t226
  store i64 %t229, ptr %l22, !tbaa !24
  %t231 = load i64, ptr %l22, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 0
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/load:Loader", ptr %t238, i32 0, i32 12
  %t241 = load i64, ptr %t240, !tbaa !24
  %t244 = icmp ne i64 %t231, %t241
  br i1 %t244, label %bb47, label %bb48
bb47:
  %t246 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t246, ptr %l149, !tbaa !27
  %t247 = load i64, ptr %l22, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr ptr, ptr %t250, i64 %t247
  %t252 = load ptr, ptr %t251, !tbaa !39
  %t254 = getelementptr %"compiler/load:Module", ptr %t252, i32 0, i32 2
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t256, ptr %l153, !tbaa !27
  %t257 = load i64, ptr %l22, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr ptr, ptr %t260, i64 %t257
  %t262 = load ptr, ptr %t261, !tbaa !39
  %t264 = getelementptr %"compiler/load:Module", ptr %t262, i32 0, i32 3
  %t265 = load i1, ptr %t264, !tbaa !21
  %t268 = call i1 @compiler_2fexplain_2ecapsShown(ptr %v0, { i64, ptr } %t255, i1 %t265)
  store i1 %t268, ptr %l157
  br label %bb49
bb48:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb50
bb49:
  %t269 = load i1, ptr %l157, !tbaa !21
  store i1 %t269, ptr %l148, !tbaa !21
  br label %bb50
bb50:
  %t270 = load i1, ptr %l148, !tbaa !21
  br i1 %t270, label %bb51, label %bb52
bb51:
  %t271 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l16, i64 %t271)
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t274 = load i64, ptr %l21, !tbaa !24
  %t276 = add i64 %t274, 1
  store i64 %t276, ptr %l21, !tbaa !24
  br label %bb43
bb56:
  store i64 0, ptr %l23, !tbaa !24
  store ptr %l16, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s14
  %t279 = load i64, ptr %l25, !tbaa !24
  store i64 %t279, ptr %l163, !tbaa !24
  %t280 = load ptr, ptr %l24, !tbaa !29
  %t282 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t280)
  store i64 %t282, ptr %l165
  br label %bb58
bb58:
  %t283 = load i64, ptr %l163, !tbaa !24
  %t284 = load i64, ptr %l165, !tbaa !24
  %t285 = icmp slt i64 %t283, %t284
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s14)
  br label %bb69
bb60:
  br label %bb61
bb61:
  %t289 = load ptr, ptr %l24, !tbaa !29
  %t290 = load i64, ptr %l25, !tbaa !24
  %t293 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t289, i64 %t290)
  store i64 %t293, ptr %l170
  br label %bb62
bb62:
  %t294 = load i64, ptr %l170, !tbaa !24
  store i64 %t294, ptr %l26, !tbaa !24
  %t295 = load i64, ptr %l26, !tbaa !24
  %t298 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s14, ptr %l11, i64 %t295)
  store { i64, ptr } %t298, ptr %l173
  br label %bb63
bb63:
  %t299 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 0
  %t301 = load i64, ptr %l23, !tbaa !24
  %t304 = icmp sgt i64 %t300, %t301
  br i1 %t304, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s15
  %t306 = load i64, ptr %l26, !tbaa !24
  %t309 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s15, ptr %l11, i64 %t306)
  store { i64, ptr } %t309, ptr %l179
  br label %bb66
bb65:
  br label %bb67
bb66:
  %t310 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 0
  store i64 %t311, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s14)
  br label %bb68
bb68:
  %t313 = load i64, ptr %l25, !tbaa !24
  %t315 = add i64 %t313, 1
  store i64 %t315, ptr %l25, !tbaa !24
  br label %bb57
bb69:
  %t317 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t317, ptr %l183
  br label %bb70
bb70:
  %t318 = load %"std/prelude/text:StringBuilder", ptr %l183
  store %"std/prelude/text:StringBuilder" %t318, ptr %l27
  store ptr %l16, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s18
  %t320 = load i64, ptr %l29, !tbaa !24
  store i64 %t320, ptr %l185, !tbaa !24
  %t321 = load ptr, ptr %l28, !tbaa !29
  %t323 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t321)
  store i64 %t323, ptr %l187
  br label %bb72
bb72:
  %t324 = load i64, ptr %l185, !tbaa !24
  %t325 = load i64, ptr %l187, !tbaa !24
  %t326 = icmp slt i64 %t324, %t325
  %t328 = xor i1 %t326, true
  br i1 %t328, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s18)
  br label %bb102
bb74:
  br label %bb75
bb75:
  %t330 = load ptr, ptr %l28, !tbaa !29
  %t331 = load i64, ptr %l29, !tbaa !24
  %t334 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t330, i64 %t331)
  store i64 %t334, ptr %l192
  br label %bb76
bb76:
  %t335 = load i64, ptr %l192, !tbaa !24
  store i64 %t335, ptr %l30, !tbaa !24
  %t336 = load i64, ptr %l30, !tbaa !24
  %t338 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr %"compiler/effects:Facts", ptr %t339, i64 %t336
  %t341 = load %"compiler/effects:Facts", ptr %t340
  store %"compiler/effects:Facts" %t341, ptr %l31
  store i64 0, ptr %l32, !tbaa !24
  %t343 = load i64, ptr @G_2ecompiler_2feffects_2eCapCount, !tbaa !24
  store i64 %t343, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t345 = load i64, ptr %l33, !tbaa !24
  %t346 = load i64, ptr %l32, !tbaa !24
  %t349 = icmp sgt i64 %t345, %t346
  br i1 %t349, label %bb77, label %bb78
bb77:
  %t351 = load i64, ptr %l34, !tbaa !24
  %t353 = icmp sgt i64 %t351, 0
  br i1 %t353, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb82
bb79:
  %t355 = load i64, ptr %l33, !tbaa !24
  %t356 = load i64, ptr %l32, !tbaa !24
  %t359 = sub i64 %t355, %t356
  %t360 = load i64, ptr %l34, !tbaa !24
  %t363 = add i64 %t359, %t360
  %t365 = sub i64 %t363, 1
  %t366 = load i64, ptr %l34, !tbaa !24
  %t369 = sdiv i64 %t365, %t366
  store i64 %t369, ptr %l202, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb81
bb81:
  %t371 = load i64, ptr %l202, !tbaa !24
  store i64 %t371, ptr %l199, !tbaa !24
  br label %bb82
bb82:
  %t372 = load i64, ptr %l199, !tbaa !24
  store i64 %t372, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb83
bb83:
  %t373 = load i64, ptr %l36, !tbaa !24
  %t374 = load i64, ptr %l35, !tbaa !24
  %t377 = icmp slt i64 %t373, %t374
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb84, label %bb85
bb84:
  br label %bb91
bb85:
  br label %bb86
bb86:
  %t381 = load i64, ptr %l32, !tbaa !24
  %t382 = load i64, ptr %l36, !tbaa !24
  %t383 = load i64, ptr %l34, !tbaa !24
  %t386 = mul i64 %t382, %t383
  %t389 = add i64 %t381, %t386
  store i64 %t389, ptr %l37, !tbaa !24
  %t391 = load i64, ptr %l37, !tbaa !24
  %t392 = getelementptr %"compiler/effects:Facts", ptr %l31, i32 0, i32 15
  %t394 = getelementptr [6 x i64], ptr %t392, i64 0, i64 %t391
  %t395 = load i64, ptr %t394, !tbaa !34
  %t396 = load i64, ptr %l30, !tbaa !24
  %t399 = icmp eq i64 %t395, %t396
  br i1 %t399, label %bb87, label %bb88
bb87:
  %t401 = load i64, ptr %l37, !tbaa !24
  %t402 = getelementptr %"compiler/effects:Facts", ptr %l31, i32 0, i32 15
  %t404 = getelementptr [6 x i64], ptr %t402, i64 0, i64 %t401
  store i64 -1, ptr %t404, !tbaa !34
  br label %bb89
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t405 = load i64, ptr %l36, !tbaa !24
  %t407 = add i64 %t405, 1
  store i64 %t407, ptr %l36, !tbaa !24
  br label %bb83
bb91:
  store ptr %l31, ptr %l227, !tbaa !29
  %t410 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l11)
  store { i64, ptr } %t410, ptr %l229
  br label %bb92
bb92:
  %t411 = load ptr, ptr %l227, !tbaa !29
  %t412 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t413 = call { i64, ptr } @compiler_2feffects_2eCapText(ptr %s18, ptr %s0, ptr %s18, ptr %t411, { i64, ptr } %t412)
  store { i64, ptr } %t413, ptr %l230
  br label %bb93
bb93:
  %t414 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t414, ptr %l38, !tbaa !27
  store ptr %l27, ptr %l231, !tbaa !29
  %t415 = load i64, ptr %l30, !tbaa !24
  %t418 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l11, i64 %t415)
  store { i64, ptr } %t418, ptr %l234
  br label %bb94
bb94:
  %t419 = load i64, ptr %l23, !tbaa !24
  %t420 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t422 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s0, ptr %s18, { i64, ptr } %t420, i64 %t419, i8 32)
  store { i64, ptr } %t422, ptr %l236
  br label %bb95
bb95:
  %t423 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t423, 0
  store i64 %t424, ptr %l237, !tbaa !24
  %t425 = load i64, ptr %l237, !tbaa !24
  %t426 = mul i64 %t425, 1
  %t427 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t426)
  %t428 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t429 = insertvalue { i64, ptr } %t428, ptr %t427, 1
  store { i64, ptr } %t429, ptr %l238, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = load i64, ptr %l237, !tbaa !24
  %t435 = mul i64 %t434, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t431, ptr %t433, i64 %t435, i1 false)
  %t436 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t438 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s18, ptr %s18, { i64, ptr } %t436, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t438, ptr %l240
  br label %bb96
bb96:
  %t439 = load i1, ptr %l240, !tbaa !21
  %t440 = xor i1 %t439, true
  br i1 %t440, label %bb97, label %bb98
bb97:
  %t442 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t442, ptr %l242, !tbaa !27
  br label %bb99
bb98:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l242, !tbaa !27
  br label %bb99
bb99:
  %t444 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 1
  %t446 = extractvalue { i64, ptr } %t444, 0
  %t447 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t448 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t449 = add i64 %t446, %t448
  %t450 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t450, 1
  %t452 = extractvalue { i64, ptr } %t450, 0
  %t453 = add i64 %t449, %t452
  %t454 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t455 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t456 = add i64 %t453, %t455
  %t457 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t456)
  call void @olang_textcopy(ptr %t457, ptr %t445, i64 %t446)
  %t458 = getelementptr i8, ptr %t457, i64 %t446
  call void @olang_textcopy(ptr %t458, ptr %t447, i64 %t448)
  %t459 = getelementptr i8, ptr %t458, i64 %t448
  call void @olang_textcopy(ptr %t459, ptr %t451, i64 %t452)
  %t460 = getelementptr i8, ptr %t459, i64 %t452
  call void @olang_textcopy(ptr %t460, ptr %t454, i64 %t455)
  %t461 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t462 = insertvalue { i64, ptr } %t461, ptr %t457, 1
  %t464 = extractvalue { i64, ptr } %t462, 0
  %t465 = extractvalue { i64, ptr } %t462, 1
  %t466 = mul i64 %t464, 1
  %t467 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t466)
  call void @llvm.memcpy.p0.p0.i64(ptr %t467, ptr %t465, i64 %t466, i1 false)
  %t468 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t469 = insertvalue { i64, ptr } %t468, ptr %t467, 1
  %t470 = load ptr, ptr %l231, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %t470, { i64, ptr } %t469)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s18)
  br label %bb101
bb101:
  %t472 = load i64, ptr %l29, !tbaa !24
  %t474 = add i64 %t472, 1
  store i64 %t474, ptr %l29, !tbaa !24
  br label %bb71
bb102:
  %t477 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l27)
  store { i64, ptr } %t477, ptr %l249
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s0)
  %t478 = load { i64, ptr }, ptr %l249, !tbaa !27
  store { i64, ptr } %t478, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fexplain_2eCodes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca i64
  %lp9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %lp19 = alloca ptr
  %l25 = alloca i64
  %l32 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l67 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i64
  %l74 = alloca i32
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca %"compiler/explain:Code"
  %l90 = alloca i64
  %l94 = alloca i64
  %l97 = alloca i64
  %l118 = alloca i64
  %l123 = alloca i64
  %l126 = alloca ptr
  %l130 = alloca i32
  %l136 = alloca i32
  %l143 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l158 = alloca i64
  %l162 = alloca { i64, ptr }
  %l163 = alloca %"compiler/explain:Code"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t11 = call i64 @compiler_2fexplain_2efnNamed(ptr %v0, ptr %v1, ptr %t5, i64 %t6, { i64, ptr } %a2)
  store i64 %t11, ptr %l25
  br label %bb2
bb2:
  %t12 = load i64, ptr %l25, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t18 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t18, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t22, i64 %t23)
  store ptr %t26, ptr %l32
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l32, !tbaa !29
  store ptr %t27, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/load:Loader", ptr %t34, i32 0, i32 4
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/load:Loader", ptr %t45, i32 0, i32 10
  store ptr %t47, ptr %l40, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t51, i64 %t52)
  store i64 %t55, ptr %l44
  br label %bb7
bb7:
  %t56 = load ptr, ptr %l40, !tbaa !29
  %t57 = load i64, ptr %l44, !tbaa !24
  %t58 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store ptr %t58, ptr %l45
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l45, !tbaa !29
  %t61 = getelementptr %"compiler/load:Module", ptr %t59, i32 0, i32 4
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l6, !tbaa !24
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v2, ptr %t64, i64 %t65)
  store { i64, ptr } %t68, ptr %l50
  br label %bb9
bb9:
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t69, ptr %lp7
  %t70 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t71 = load ptr, ptr %lp7
  store { i64, ptr } %t70, ptr %t71, !tbaa !27
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Func", ptr %t74, i32 0, i32 0
  %t77 = getelementptr %"compiler/source:Span", ptr %t76, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t84 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t72, i64 %t73, i64 %t80)
  store i64 %t84, ptr %l56
  br label %bb10
bb10:
  %t85 = load i64, ptr %l56, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l57
  br label %bb11
bb11:
  %t87 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t87, ptr %lp9
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  %t89 = load ptr, ptr %lp9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %t89
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  store ptr %t93, ptr %l59, !tbaa !29
  %t94 = load i64, ptr %l3, !tbaa !24
  %t96 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t94)
  store i64 %t96, ptr %l61
  br label %bb12
bb12:
  %t97 = load ptr, ptr %l59, !tbaa !29
  %t98 = load i64, ptr %l61, !tbaa !24
  %t99 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t97, i64 %t98)
  store i64 %t99, ptr %l62
  br label %bb13
bb13:
  %t100 = load i64, ptr %l62, !tbaa !24
  %t101 = icmp eq i64 %t100, 0
  br i1 %t101, label %bb14, label %bb15
bb14:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t107 = load i64, ptr %l3, !tbaa !24
  %t110 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t106, i64 %t107, i32 0)
  store i64 %t110, ptr %l67
  br label %bb16
bb15:
  br label %bb23
bb16:
  %t111 = load i64, ptr %l67, !tbaa !24
  store i64 %t111, ptr %l10, !tbaa !24
  %t112 = load ptr, ptr %lp9
  store ptr %t112, ptr %l68, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l69, !tbaa !29
  %t114 = load i64, ptr %l3, !tbaa !24
  store i64 %t114, ptr %l70, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t118, i64 %t119)
  store i32 %t122, ptr %l74
  br label %bb17
bb17:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i64, ptr %l10, !tbaa !24
  %t127 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t123, i64 %t124)
  store i64 %t127, ptr %l77
  br label %bb18
bb18:
  %t128 = load ptr, ptr %l69, !tbaa !29
  %t129 = load i64, ptr %l70, !tbaa !24
  %t130 = load i32, ptr %l74, !tbaa !23
  %t131 = load i64, ptr %l77, !tbaa !24
  %t132 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v2, ptr %t128, i64 %t129, i32 %t130, i64 %t131)
  store { i64, ptr } %t132, ptr %l78
  br label %bb19
bb19:
  %t133 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  store { i64, ptr } %t139, ptr %l79, !tbaa !27
  %t140 = load ptr, ptr %lp7
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l80, !tbaa !27
  %t142 = load i64, ptr %l8, !tbaa !24
  store i64 %t142, ptr %l81, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = load i64, ptr %l10, !tbaa !24
  %t150 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %v0, ptr %t146, i64 %t147)
  store { i64, ptr } %t150, ptr %l85
  br label %bb20
bb20:
  %t151 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t153 = load i64, ptr %l81, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t155 = call %"compiler/explain:Code" @compiler_2fexplain_3aCode_2ector(ptr %v2, ptr %v2, ptr %v0, ptr %v2, { i64, ptr } %t151, { i64, ptr } %t152, i64 %t153, { i64, ptr } %t154)
  store %"compiler/explain:Code" %t155, ptr %l86
  br label %bb21
bb21:
  %t156 = load ptr, ptr %l68, !tbaa !29
  %t157 = load %"compiler/explain:Code", ptr %l86
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2ePush_3ccompiler_2fexplain_3aCode_3e(ptr %v2, ptr %v2, ptr %t156, %"compiler/explain:Code" %t157)
  br label %bb22
bb22:
  %t158 = load ptr, ptr %lp9
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158
  %t161 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t161, ptr %rv
  br label %ret
bb23:
  store i64 0, ptr %l11, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %t165)
  store i64 %t167, ptr %l90
  br label %bb24
bb24:
  %t168 = load i64, ptr %l90, !tbaa !24
  store i64 %t168, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t169 = load i64, ptr %l12, !tbaa !24
  %t170 = load i64, ptr %l11, !tbaa !24
  %t173 = icmp sgt i64 %t169, %t170
  br i1 %t173, label %bb25, label %bb26
bb25:
  %t175 = load i64, ptr %l13, !tbaa !24
  %t177 = icmp sgt i64 %t175, 0
  br i1 %t177, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb30
bb27:
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = load i64, ptr %l11, !tbaa !24
  %t183 = sub i64 %t179, %t180
  %t184 = load i64, ptr %l13, !tbaa !24
  %t187 = add i64 %t183, %t184
  %t189 = sub i64 %t187, 1
  %t190 = load i64, ptr %l13, !tbaa !24
  %t193 = sdiv i64 %t189, %t190
  store i64 %t193, ptr %l97, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb29
bb29:
  %t195 = load i64, ptr %l97, !tbaa !24
  store i64 %t195, ptr %l94, !tbaa !24
  br label %bb30
bb30:
  %t196 = load i64, ptr %l94, !tbaa !24
  store i64 %t196, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t197 = load i64, ptr %l15, !tbaa !24
  %t198 = load i64, ptr %l14, !tbaa !24
  %t201 = icmp slt i64 %t197, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb53
bb33:
  br label %bb34
bb34:
  %t205 = load i64, ptr %l11, !tbaa !24
  %t206 = load i64, ptr %l15, !tbaa !24
  %t207 = load i64, ptr %l13, !tbaa !24
  %t210 = mul i64 %t206, %t207
  %t213 = add i64 %t205, %t210
  store i64 %t213, ptr %l16, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/check:Checker", ptr %t215, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t219 = load i64, ptr %l16, !tbaa !24
  %t222 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t218, i64 %t219)
  store i64 %t222, ptr %l118
  br label %bb35
bb35:
  %t223 = load i64, ptr %l3, !tbaa !24
  %t224 = load i64, ptr %l118, !tbaa !24
  %t226 = icmp ne i64 %t224, %t223
  br i1 %t226, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb37:
  br label %bb38
bb38:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i64, ptr %l16, !tbaa !24
  %t232 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t228, i64 %t229)
  store i64 %t232, ptr %l123
  br label %bb39
bb39:
  %t233 = load i64, ptr %l123, !tbaa !24
  store i64 %t233, ptr %l17, !tbaa !24
  %t234 = load i64, ptr %l17, !tbaa !24
  %t236 = icmp slt i64 %t234, 0
  br i1 %t236, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb41:
  br label %bb42
bb42:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l126, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t243 = load i64, ptr %l16, !tbaa !24
  %t246 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t242, i64 %t243)
  store i32 %t246, ptr %l130
  br label %bb43
bb43:
  %t247 = load ptr, ptr %l4, !tbaa !29
  %t249 = getelementptr %"compiler/ast:Func", ptr %t247, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t251 = load ptr, ptr %l4, !tbaa !29
  %t253 = getelementptr %"compiler/ast:Func", ptr %t251, i32 0, i32 3
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = getelementptr %"compiler/ast:Sig", ptr %t254, i32 0, i32 0
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  %t258 = load ptr, ptr %l126, !tbaa !29
  %t259 = load i32, ptr %l130, !tbaa !23
  %t262 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t258, i32 %t259, ptr %t250, { i64, ptr } %t257)
  store i32 %t262, ptr %l136
  br label %bb44
bb44:
  %t263 = load i32, ptr %l136, !tbaa !23
  store i32 %t263, ptr %l18, !tbaa !23
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 0
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/load:Loader", ptr %t270, i32 0, i32 3
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = load ptr, ptr %l4, !tbaa !29
  %t276 = getelementptr %"compiler/ast:Func", ptr %t274, i32 0, i32 2
  %t277 = load i32, ptr %t276, !tbaa !23
  %t280 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s4, ptr %t273, i32 %t277)
  store { i64, ptr } %t280, ptr %l143
  br label %bb45
bb45:
  %t281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t281, ptr %l144, !tbaa !29
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/check:Checker", ptr %t282, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t286 = load i64, ptr %l16, !tbaa !24
  %t289 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t285, i64 %t286)
  store i32 %t289, ptr %l148
  br label %bb46
bb46:
  %t290 = load ptr, ptr %l144, !tbaa !29
  %t291 = load i32, ptr %l148, !tbaa !23
  %t292 = call { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %s4, ptr %t290, i32 %t291)
  store { i64, ptr } %t292, ptr %l149
  br label %bb47
bb47:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i32, ptr %l18, !tbaa !23
  %t295 = load i64, ptr %l17, !tbaa !24
  %t299 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s4, ptr %t293, i32 %t294, i64 %t295)
  store { i64, ptr } %t299, ptr %l153
  br label %bb48
bb48:
  %t300 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t302 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t302, 1
  %t304 = extractvalue { i64, ptr } %t302, 0
  %t305 = add i64 %t301, %t304
  %t306 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 1
  %t308 = extractvalue { i64, ptr } %t306, 0
  %t309 = add i64 %t305, %t308
  %t310 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t312 = add i64 %t309, %t311
  %t313 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t316 = add i64 %t312, %t315
  %t317 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t316)
  call void @olang_textcopy(ptr %t317, ptr %t300, i64 %t301)
  %t318 = getelementptr i8, ptr %t317, i64 %t301
  call void @olang_textcopy(ptr %t318, ptr %t303, i64 %t304)
  %t319 = getelementptr i8, ptr %t318, i64 %t304
  call void @olang_textcopy(ptr %t319, ptr %t307, i64 %t308)
  %t320 = getelementptr i8, ptr %t319, i64 %t308
  call void @olang_textcopy(ptr %t320, ptr %t310, i64 %t311)
  %t321 = getelementptr i8, ptr %t320, i64 %t311
  call void @olang_textcopy(ptr %t321, ptr %t314, i64 %t315)
  %t322 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t317, 1
  %t324 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t324, ptr %lp19
  %t326 = load ptr, ptr %lp19
  store { i64, ptr } %t323, ptr %t326, !tbaa !27
  %t327 = load ptr, ptr %lp9
  store ptr %t327, ptr %l155, !tbaa !29
  %t328 = load ptr, ptr %lp19
  %t329 = load { i64, ptr }, ptr %t328, !tbaa !27
  store { i64, ptr } %t329, ptr %l156, !tbaa !27
  %t330 = load ptr, ptr %lp7
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  store { i64, ptr } %t331, ptr %l157, !tbaa !27
  %t332 = load i64, ptr %l8, !tbaa !24
  store i64 %t332, ptr %l158, !tbaa !24
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = getelementptr %"compiler/check:Checker", ptr %t333, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !29
  %t337 = load i64, ptr %l16, !tbaa !24
  %t340 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %v0, ptr %t336, i64 %t337)
  store { i64, ptr } %t340, ptr %l162
  br label %bb49
bb49:
  %t341 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t342 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t343 = load i64, ptr %l158, !tbaa !24
  %t344 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t345 = call %"compiler/explain:Code" @compiler_2fexplain_3aCode_2ector(ptr %v2, ptr %v2, ptr %v0, ptr %v2, { i64, ptr } %t341, { i64, ptr } %t342, i64 %t343, { i64, ptr } %t344)
  store %"compiler/explain:Code" %t345, ptr %l163
  br label %bb50
bb50:
  %t346 = load ptr, ptr %l155, !tbaa !29
  %t347 = load %"compiler/explain:Code", ptr %l163
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2ePush_3ccompiler_2fexplain_3aCode_3e(ptr %v2, ptr %v2, ptr %t346, %"compiler/explain:Code" %t347)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb52:
  %t348 = load i64, ptr %l15, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l15, !tbaa !24
  br label %bb31
bb53:
  %t352 = load ptr, ptr %lp9
  %t353 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t352
  %t355 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t353, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t355, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eFnLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l18 = alloca i32
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i64
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t5)
  store i64 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t8, i64 %t9)
  store i64 %t10, ptr %l7
  br label %bb2
bb2:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t17, i64 %t18, i32 0)
  store i64 %t21, ptr %l12
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i64, ptr %l12, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l14, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t33, i64 %t34)
  store i64 %t37, ptr %l21
  br label %bb7
bb7:
  %t38 = load ptr, ptr %l13, !tbaa !29
  %t39 = load i64, ptr %l14, !tbaa !24
  %t40 = load i32, ptr %l18, !tbaa !23
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %t38, i64 %t39, i32 %t40, i64 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l23, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  store i64 %t45, ptr %l24, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t49, i64 %t50)
  store i32 %t53, ptr %l28
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l23, !tbaa !29
  %t55 = load i64, ptr %l24, !tbaa !24
  %t56 = load i32, ptr %l28, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %t54, i64 %t55, i32 %t56, i64 -1)
  store { i64, ptr } %t57, ptr %l29
  br label %bb11
bb11:
  %t58 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/names:Entry"
  %l12 = alloca i64
  %l13 = alloca i32
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l29 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca %"compiler/names:Entry"
  %l65 = alloca i64
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l84 = alloca i32
  %l89 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 3
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v3, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) })
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l23
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb3, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l22
  br label %bb2
bb2:
  %t23 = load i64, ptr %l22, !tbaa !24
  store i64 %t23, ptr %l20, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb5
bb5:
  %t24 = load i64, ptr %l20, !tbaa !24
  %t27 = icmp sgt i64 %t24, 0
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t35 = call i64 @compiler_2fexplain_2efnNamed(ptr %v0, ptr %v3, ptr %t29, i64 %t30, { i64, ptr } %t31)
  store i64 %t35, ptr %l29
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t36 = load i64, ptr %l29, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t37, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load i64, ptr %l7, !tbaa !24
  %t49 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t43, ptr %t44, i64 %t45)
  store { i64, ptr } %t49, ptr %l36
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t51 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t50, 1
  store { i32, { i64, ptr } } %t51, ptr %rv
  br label %ret
bb13:
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t56 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v3, ptr %t52, { i64, ptr } %t53)
  store i32 %t56, ptr %l39
  br label %bb14
bb14:
  %t57 = load i32, ptr %l39, !tbaa !23
  store i32 %t57, ptr %l8, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/names:Resolver", ptr %t64, i32 0, i32 1
  %t67 = load i64, ptr %l3, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l45
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l45, !tbaa !29
  %t73 = getelementptr %"compiler/names:Table", ptr %t71, i32 0, i32 0
  store ptr %t73, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t75 = load i64, ptr %l10, !tbaa !24
  store i64 %t75, ptr %l48, !tbaa !24
  %t76 = load ptr, ptr %l9, !tbaa !29
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t76)
  store i64 %t78, ptr %l50
  br label %bb17
bb17:
  %t79 = load i64, ptr %l48, !tbaa !24
  %t80 = load i64, ptr %l50, !tbaa !24
  %t81 = icmp slt i64 %t79, %t80
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb18, label %bb19
bb18:
  br label %bb38
bb19:
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l9, !tbaa !29
  %t86 = load i64, ptr %l10, !tbaa !24
  %t89 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t85, i64 %t86)
  store %"compiler/names:Entry" %t89, ptr %l55
  br label %bb21
bb21:
  %t90 = load %"compiler/names:Entry", ptr %l55
  store %"compiler/names:Entry" %t90, ptr %l11
  %t91 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = load i32, ptr %l8, !tbaa !23
  %t96 = icmp ne i32 %t92, %t93
  br i1 %t96, label %bb22, label %bb23
bb22:
  br label %bb37
bb23:
  br label %bb24
bb24:
  %t98 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 2
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 9}
  %t101 = trunc i64 3 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb25, label %bb26
bb25:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = load i64, ptr %l3, !tbaa !24
  %t109 = load i32, ptr %l8, !tbaa !23
  %t113 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t107, i64 %t108, i32 %t109)
  store i64 %t113, ptr %l65
  br label %bb27
bb26:
  br label %bb32
bb27:
  %t114 = load i64, ptr %l65, !tbaa !24
  store i64 %t114, ptr %l12, !tbaa !24
  %t115 = load i64, ptr %l12, !tbaa !24
  %t117 = icmp sge i64 %t115, 0
  br i1 %t117, label %bb28, label %bb29
bb28:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t121 = load i64, ptr %l12, !tbaa !24
  %t125 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t119, ptr %t120, i64 %t121)
  store { i64, ptr } %t125, ptr %l71
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t126 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t127 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t126, 1
  store { i32, { i64, ptr } } %t127, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t128 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 2
  %t129 = load i32, ptr %t128, !range !{i32 0, i32 9}
  %t131 = trunc i64 2 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb33, label %bb34
bb33:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i64, ptr %l3, !tbaa !24
  %t137 = load %"compiler/names:Entry", ptr %l11
  %t142 = call { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v2, ptr %v0, ptr %v4, ptr %t134, ptr %a2, i64 %t136, %"compiler/names:Entry" %t137)
  store { i64, ptr } %t142, ptr %l78
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t143 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t144 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t143, 1
  store { i32, { i64, ptr } } %t144, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t145 = load i64, ptr %l10, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l10, !tbaa !24
  br label %bb16
bb38:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i64, ptr %l3, !tbaa !24
  %t151 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t155 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t149, i64 %t150, { i64, ptr } %t151)
  store i32 %t155, ptr %l84
  br label %bb39
bb39:
  %t156 = load i32, ptr %l84, !tbaa !23
  store i32 %t156, ptr %l13, !tbaa !23
  %t157 = load i32, ptr %l13, !tbaa !23
  %t159 = icmp sge i32 %t157, 0
  br i1 %t159, label %bb40, label %bb41
bb40:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l13, !tbaa !23
  %t165 = call { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v4, ptr %t161, i32 %t162)
  store { i64, ptr } %t165, ptr %l89
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t166 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t167 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t166, 1
  store { i32, { i64, ptr } } %t167, ptr %rv
  br label %ret
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t169 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t169, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eNoValueWhy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i64
  %l46 = alloca i64
  %l51 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l61 = alloca i64
  %l63 = alloca i1
  %l65 = alloca i1
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l83 = alloca i64
  %l89 = alloca i1
  %l96 = alloca { i64, ptr }
  %l99 = alloca i1
  %l102 = alloca i1
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t19, i32 %t23)
  store { i64, ptr } %t26, ptr %l18
  br label %bb2
bb2:
  %t27 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Func", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l25, !tbaa !24
  %t40 = load i64, ptr %l25, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l26, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l25, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t51, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t56, i64 %t57)
  store i1 %t60, ptr %l30
  br label %bb6
bb6:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t62, ptr %l32, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l33, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l34, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l33, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t76, ptr %l32, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t77 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t80 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t78)
  store i64 %t80, ptr %l36
  br label %bb10
bb10:
  %t81 = load i64, ptr %l36, !tbaa !24
  store i64 %t81, ptr %l6, !tbaa !24
  %t82 = load ptr, ptr %l4, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Func", ptr %t82, i32 0, i32 5
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l39, !tbaa !24
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t90 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t88)
  store i1 %t90, ptr %l41
  br label %bb11
bb11:
  %t91 = load i1, ptr %l41, !tbaa !21
  br i1 %t91, label %bb12, label %bb13
bb12:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load i64, ptr %l2, !tbaa !24
  %t99 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerVarCount(ptr %v0, ptr %t95, i64 %t96)
  store i64 %t99, ptr %l46
  br label %bb14
bb13:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb15
bb14:
  %t100 = load i64, ptr %l46, !tbaa !24
  store i64 %t100, ptr %l42, !tbaa !24
  br label %bb15
bb15:
  %t101 = load i64, ptr %l39, !tbaa !24
  %t102 = load i64, ptr %l42, !tbaa !24
  %t103 = add i64 %t101, %t102
  store i64 %t103, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t109 = load i64, ptr %l6, !tbaa !24
  %t112 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t108, i64 %t109)
  store i64 %t112, ptr %l51
  br label %bb16
bb16:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l51, !tbaa !24
  %t116 = icmp sgt i64 %t114, %t113
  br i1 %t116, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t118, ptr %l55, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l56, !tbaa !24
  %t121 = load i64, ptr %l56, !tbaa !24
  %t122 = mul i64 %t121, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l57, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l56, !tbaa !24
  %t131 = mul i64 %t130, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t127, ptr %t129, i64 %t131, i1 false)
  %t132 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t132, ptr %l55, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t133 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t133, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = load i64, ptr %l6, !tbaa !24
  %t141 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t137, i64 %t138)
  store i64 %t141, ptr %l61
  br label %bb20
bb20:
  %t142 = load i64, ptr %l61, !tbaa !24
  %t143 = icmp sgt i64 %t142, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t147 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t145)
  store i1 %t147, ptr %l65
  br label %bb23
bb22:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb24
bb23:
  %t148 = load i1, ptr %l65, !tbaa !21
  store i1 %t148, ptr %l63, !tbaa !21
  br label %bb24
bb24:
  %t149 = load i1, ptr %l63, !tbaa !21
  br i1 %t149, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t150 = load ptr, ptr %l4, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 0
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/load:Loader", ptr %t157, i32 0, i32 3
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v0, ptr %s4, ptr %t150, ptr %t160)
  store { i64, ptr } %t163, ptr %l71
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 0
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/load:Loader", ptr %t170, i32 0, i32 3
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t174 = load ptr, ptr %l4, !tbaa !29
  %t176 = getelementptr %"compiler/ast:Func", ptr %t174, i32 0, i32 10
  %t177 = load i32, ptr %t176, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s4, ptr %t173, i32 %t177)
  store { i64, ptr } %t180, ptr %l78
  br label %bb28
bb28:
  %t181 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t183 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = add i64 %t182, %t185
  %t187 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t190 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 1
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t193 = add i64 %t189, %t192
  %t194 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t181, i64 %t182)
  %t198 = getelementptr i8, ptr %t197, i64 %t182
  call void @olang_textcopy(ptr %t198, ptr %t184, i64 %t185)
  %t199 = getelementptr i8, ptr %t198, i64 %t185
  call void @olang_textcopy(ptr %t199, ptr %t187, i64 %t188)
  %t200 = getelementptr i8, ptr %t199, i64 %t188
  call void @olang_textcopy(ptr %t200, ptr %t191, i64 %t192)
  %t201 = getelementptr i8, ptr %t200, i64 %t192
  call void @olang_textcopy(ptr %t201, ptr %t194, i64 %t195)
  %t202 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t197, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t203, ptr %rv
  br label %ret
bb29:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t209 = load i64, ptr %l6, !tbaa !24
  %t212 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t208, i64 %t209)
  store i64 %t212, ptr %l83
  br label %bb30
bb30:
  %t213 = load i64, ptr %l83, !tbaa !24
  %t214 = icmp sgt i64 %t213, 0
  br i1 %t214, label %bb31, label %bb32
bb31:
  %t216 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t217 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t220 = extractvalue { i64, ptr } %t216, 1
  %t221 = extractvalue { i64, ptr } %t216, 0
  %t222 = add i64 %t218, %t221
  %t223 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t217, i64 %t218)
  %t227 = getelementptr i8, ptr %t226, i64 %t218
  call void @olang_textcopy(ptr %t227, ptr %t220, i64 %t221)
  %t228 = getelementptr i8, ptr %t227, i64 %t221
  call void @olang_textcopy(ptr %t228, ptr %t223, i64 %t224)
  %t229 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t226, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t230, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t232 = load i64, ptr %l3, !tbaa !24
  %t234 = icmp sge i64 %t232, 0
  br i1 %t234, label %bb34, label %bb35
bb34:
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t237 = load i64, ptr %l3, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/load:Loader", ptr %t244, i32 0, i32 3
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t251 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v1, ptr %v0, ptr %s0, ptr %t236, i64 %t237, ptr %t247)
  store { i64, ptr } %t251, ptr %l96
  br label %bb36
bb35:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb37
bb36:
  %t252 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 0
  %t255 = icmp sgt i64 %t253, 0
  store i1 %t255, ptr %l89, !tbaa !21
  br label %bb37
bb37:
  %t257 = load i1, ptr %l89, !tbaa !21
  br i1 %t257, label %bb38, label %bb39
bb38:
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t259 = load i64, ptr %l3, !tbaa !24
  %t262 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eValueCovered(ptr %v1, ptr %t258, i64 %t259)
  store i1 %t262, ptr %l102
  br label %bb40
bb39:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb41
bb40:
  %t263 = load i1, ptr %l102, !tbaa !21
  %t264 = xor i1 %t263, true
  store i1 %t264, ptr %l99, !tbaa !21
  br label %bb41
bb41:
  %t266 = load i1, ptr %l99, !tbaa !21
  br i1 %t266, label %bb42, label %bb43
bb42:
  store { i64, ptr } { i64 181, ptr getelementptr inbounds (<{ i64, [181 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l104, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t267, ptr %l105, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 0
  store i64 %t269, ptr %l106, !tbaa !24
  %t270 = load i64, ptr %l106, !tbaa !24
  %t271 = mul i64 %t270, 1
  %t272 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t271)
  %t273 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  store { i64, ptr } %t274, ptr %l107, !tbaa !27
  %t275 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = load i64, ptr %l106, !tbaa !24
  %t280 = mul i64 %t279, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t276, ptr %t278, i64 %t280, i1 false)
  %t281 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t281, ptr %l105, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t282 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t282, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l108, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t283, ptr %l109, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  store i64 %t285, ptr %l110, !tbaa !24
  %t286 = load i64, ptr %l110, !tbaa !24
  %t287 = mul i64 %t286, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t287)
  %t289 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  store { i64, ptr } %t290, ptr %l111, !tbaa !27
  %t291 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = load i64, ptr %l110, !tbaa !24
  %t296 = mul i64 %t295, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t292, ptr %t294, i64 %t296, i1 false)
  %t297 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t297, ptr %l109, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t298 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t298, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2eattrLines(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l19 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %s3 = alloca %olang.scope
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 10
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t15, i64 %a2)
  store ptr %t19, ptr %l19
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l19, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l5, !tbaa !29
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_e4b17f5ad4d0393_dacada4c9c892187)
  unreachable
bb6:
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l6, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t49 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t49, ptr %l34, !tbaa !27
  %t50 = load i64, ptr %l8, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr ptr, ptr %t53, i64 %t50
  %t55 = load ptr, ptr %t54, !tbaa !39
  store ptr %t55, ptr %l10, !tbaa !29
  store ptr %a0, ptr %l37, !tbaa !29
  store { i64, ptr } %a4, ptr %l38, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t59, ptr %l39, !tbaa !27
  %t60 = load ptr, ptr %l10, !tbaa !29
  %t62 = getelementptr %"compiler/ast:Attr", ptr %t60, i32 0, i32 0
  %t63 = getelementptr %"compiler/source:Span", ptr %t62, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l42, !tbaa !24
  %t67 = load ptr, ptr %l10, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Attr", ptr %t67, i32 0, i32 0
  %t70 = getelementptr %"compiler/source:Span", ptr %t69, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = sext i32 %t71 to i64
  store i64 %t73, ptr %l45, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l46, !tbaa !24
  %t76 = load i64, ptr %l42, !tbaa !24
  %t77 = icmp sge i64 %t76, 0
  br i1 %t77, label %bb12, label %bb13
bb12:
  %t79 = load i64, ptr %l42, !tbaa !24
  %t80 = load i64, ptr %l45, !tbaa !24
  %t81 = icmp sle i64 %t79, %t80
  br i1 %t81, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_31b785093080fa1c_de0f6dc4f3b337d0)
  unreachable
bb14:
  %t83 = load i64, ptr %l45, !tbaa !24
  %t84 = load i64, ptr %l46, !tbaa !24
  %t85 = icmp sle i64 %t83, %t84
  br i1 %t85, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_31b785093080fa1c_de0f6dc4f3b337d0)
  unreachable
bb16:
  %t87 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l42, !tbaa !24
  %t90 = load i64, ptr %l45, !tbaa !24
  %t91 = getelementptr i8, ptr %t88, i64 %t89
  %t92 = sub i64 %t90, %t89
  %t93 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t91, 1
  %t95 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = extractvalue { i64, ptr } %t94, 1
  %t100 = extractvalue { i64, ptr } %t94, 0
  %t101 = add i64 %t97, %t100
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t96, i64 %t97)
  %t106 = getelementptr i8, ptr %t105, i64 %t97
  call void @olang_textcopy(ptr %t106, ptr %t99, i64 %t100)
  %t107 = getelementptr i8, ptr %t106, i64 %t100
  call void @olang_textcopy(ptr %t107, ptr %t102, i64 %t103)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t105, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = extractvalue { i64, ptr } %t109, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t117 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t117, { i64, ptr } %t116)
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_31b785093080fa1c_de0f6dc4f3b337d0)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l8, !tbaa !24
  br label %bb8
bb20:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2eattrsBefore(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, { i64, ptr } }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca { i64, { i64, ptr } }
  %l20 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l41 = alloca %"std/prelude/text:StringBuilder"
  %l49 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l70 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAttrsOf(ptr %v0, ptr %s0, ptr %t4, i32 %a1)
  store { i64, { i64, ptr } } %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load { i64, { i64, ptr } }, ptr %l15
  store { i64, { i64, ptr } } %t9, ptr %l2
  %t10 = getelementptr { i64, { i64, ptr } }, ptr %l2, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, { i64, ptr } }, ptr %l2, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t16, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb4
bb3:
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp eq i64 %t22, 0
  store i1 %t24, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t27, ptr %l25, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l26, !tbaa !24
  %t30 = load i64, ptr %l26, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l27, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l26, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t42 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t42, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/load:Loader", ptr %t49, i32 0, i32 10
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l33
  br label %bb8
bb8:
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t58 = getelementptr %"compiler/load:Module", ptr %t56, i32 0, i32 6
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l5, !tbaa !29
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  br i1 %t63, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_654ac6e7d4d962a_57fceb1b72d2ae56)
  unreachable
bb10:
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/source:Source", ptr %t65, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l6, !tbaa !27
  %t71 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t71, ptr %l41
  br label %bb12
bb12:
  %t72 = load %"std/prelude/text:StringBuilder", ptr %l41
  store %"std/prelude/text:StringBuilder" %t72, ptr %l7
  %t73 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t73, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t87 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t87, ptr %l49, !tbaa !27
  %t88 = load i64, ptr %l9, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr ptr, ptr %t91, i64 %t88
  %t93 = load ptr, ptr %t92, !tbaa !39
  store ptr %t93, ptr %l11, !tbaa !29
  store ptr %l7, ptr %l52, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t95, ptr %l53, !tbaa !27
  %t96 = load ptr, ptr %l11, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Attr", ptr %t96, i32 0, i32 0
  %t99 = getelementptr %"compiler/source:Span", ptr %t98, i32 0, i32 0
  %t100 = load i32, ptr %t99, !tbaa !23
  %t102 = sext i32 %t100 to i64
  store i64 %t102, ptr %l56, !tbaa !24
  %t103 = load ptr, ptr %l11, !tbaa !29
  %t105 = getelementptr %"compiler/ast:Attr", ptr %t103, i32 0, i32 0
  %t106 = getelementptr %"compiler/source:Span", ptr %t105, i32 0, i32 1
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = sext i32 %t107 to i64
  store i64 %t109, ptr %l59, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %l60, !tbaa !24
  %t112 = load i64, ptr %l56, !tbaa !24
  %t113 = icmp sge i64 %t112, 0
  br i1 %t113, label %bb17, label %bb18
bb17:
  %t115 = load i64, ptr %l56, !tbaa !24
  %t116 = load i64, ptr %l59, !tbaa !24
  %t117 = icmp sle i64 %t115, %t116
  br i1 %t117, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d0280248a738559f_8af1b7358df9134b)
  unreachable
bb19:
  %t119 = load i64, ptr %l59, !tbaa !24
  %t120 = load i64, ptr %l60, !tbaa !24
  %t121 = icmp sle i64 %t119, %t120
  br i1 %t121, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d0280248a738559f_8af1b7358df9134b)
  unreachable
bb21:
  %t123 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = load i64, ptr %l59, !tbaa !24
  %t127 = getelementptr i8, ptr %t124, i64 %t125
  %t128 = sub i64 %t126, %t125
  %t129 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t127, 1
  %t132 = extractvalue { i64, ptr } %t130, 1
  %t133 = extractvalue { i64, ptr } %t130, 0
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t132, i64 %t133)
  %t138 = getelementptr i8, ptr %t137, i64 %t133
  call void @olang_textcopy(ptr %t138, ptr %t134, i64 %t135)
  %t139 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = extractvalue { i64, ptr } %t140, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t148 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t148, { i64, ptr } %t147)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d0280248a738559f_8af1b7358df9134b)
  unreachable
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t150 = load i64, ptr %l9, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l9, !tbaa !24
  br label %bb13
bb25:
  %t155 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l7)
  store { i64, ptr } %t155, ptr %l70
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t156 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t156, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2ebuilders(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fexplain_2eBuilders(ptr %v1, ptr %s1, ptr %t1, i32 %a2, i1 false)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t7 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  store ptr %t7, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l10, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t10)
  store i64 %t12, ptr %l12
  br label %bb3
bb3:
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l17
  br label %bb7
bb7:
  %t24 = load i64, ptr %l17, !tbaa !24
  store ptr %a0, ptr %l18, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2fexplain_2eFnLine(ptr %v1, ptr %s2, ptr %t26, i64 %t24)
  store { i64, ptr } %t30, ptr %l21
  br label %bb8
bb8:
  %t31 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t33 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t34, i64 %t35)
  %t42 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t40, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t52 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t52, { i64, ptr } %t51)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l4, !tbaa !24
  br label %bb2
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fexplain_2ecapsShown(ptr %v0, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = xor i1 %a1, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t7, ptr %l6
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t8 = load i1, ptr %l6, !tbaa !21
  %t9 = xor i1 %t8, true
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t14, ptr %l10
  br label %bb7
bb6:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb8
bb7:
  %t15 = load i1, ptr %l10, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t21, ptr %l14
  br label %bb11
bb10:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t22 = load i1, ptr %l14, !tbaa !21
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i1, ptr %l12, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = icmp sle i64 0, 1152921504606846975
  br i1 %t34, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb12:
  %t36 = mul i64 0, 8
  %t37 = insertvalue { i64, ptr } undef, i64 0, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fexplain_2ecaseWhole(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 3
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5177bd7d484351dd_5d0dbb04dc509331)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fexplain_2econtract(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l25 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca i64
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca i64
  %l60 = alloca i64
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = getelementptr i8, ptr %t14, i64 %t10
  call void @olang_textcopy(ptr %t15, ptr %t11, i64 %t12)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t14, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t6, { i64, ptr } %t24)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Sig", ptr %t27, i32 0, i32 5
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t36 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/load:Loader", ptr %t40, i32 0, i32 10
  %t46 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t42, i64 %a3)
  store ptr %t46, ptr %l25
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t49 = getelementptr %"compiler/load:Module", ptr %t47, i32 0, i32 6
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  br i1 %t54, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e7ca39a48e286d3f_b849249cb4ab4933)
  unreachable
bb10:
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/source:Source", ptr %t56, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l6, !tbaa !27
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Sig", ptr %t62, i32 0, i32 5
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_ec0929e0cef23b20_10aa079683981964)
  unreachable
bb13:
  br label %bb14
bb14:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Sig", ptr %t69, i32 0, i32 5
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t75 = getelementptr %"compiler/ast:ContractBlock", ptr %t72, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb17:
  br label %bb18
bb18:
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l46, !tbaa !27
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr ptr, ptr %t94, i64 %t91
  %t96 = load ptr, ptr %t95, !tbaa !39
  store ptr %t96, ptr %l10, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l49, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t99, ptr %l50, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t100, ptr %l51, !tbaa !27
  %t101 = load ptr, ptr %l10, !tbaa !29
  %t103 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v2, ptr %t101)
  store %"compiler/source:Span" %t103, ptr %l53
  br label %bb19
bb19:
  %t104 = getelementptr %"compiler/source:Span", ptr %l53, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = sext i32 %t105 to i64
  store i64 %t107, ptr %l55, !tbaa !24
  %t108 = load ptr, ptr %l10, !tbaa !29
  %t110 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v2, ptr %t108)
  store %"compiler/source:Span" %t110, ptr %l57
  br label %bb20
bb20:
  %t111 = getelementptr %"compiler/source:Span", ptr %l57, i32 0, i32 1
  %t112 = load i32, ptr %t111, !tbaa !23
  %t114 = sext i32 %t112 to i64
  store i64 %t114, ptr %l59, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l60, !tbaa !24
  %t117 = load i64, ptr %l55, !tbaa !24
  %t118 = icmp sge i64 %t117, 0
  br i1 %t118, label %bb21, label %bb22
bb21:
  %t120 = load i64, ptr %l55, !tbaa !24
  %t121 = load i64, ptr %l59, !tbaa !24
  %t122 = icmp sle i64 %t120, %t121
  br i1 %t122, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb23:
  %t124 = load i64, ptr %l59, !tbaa !24
  %t125 = load i64, ptr %l60, !tbaa !24
  %t126 = icmp sle i64 %t124, %t125
  br i1 %t126, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb25:
  %t128 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l55, !tbaa !24
  %t131 = load i64, ptr %l59, !tbaa !24
  %t132 = getelementptr i8, ptr %t129, i64 %t130
  %t133 = sub i64 %t131, %t130
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  %t136 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t143 = extractvalue { i64, ptr } %t135, 1
  %t144 = extractvalue { i64, ptr } %t135, 0
  %t145 = add i64 %t141, %t144
  %t146 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t137, i64 %t138)
  %t150 = getelementptr i8, ptr %t149, i64 %t138
  call void @olang_textcopy(ptr %t150, ptr %t139, i64 %t140)
  %t151 = getelementptr i8, ptr %t150, i64 %t140
  call void @olang_textcopy(ptr %t151, ptr %t143, i64 %t144)
  %t152 = getelementptr i8, ptr %t151, i64 %t144
  call void @olang_textcopy(ptr %t152, ptr %t146, i64 %t147)
  %t153 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t149, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = extractvalue { i64, ptr } %t154, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  %t162 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t162, { i64, ptr } %t161)
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t164 = load i64, ptr %l8, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l8, !tbaa !24
  br label %bb15
bb29:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:StructBody", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = icmp sle i64 0, 1152921504606846975
  br i1 %t28, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb12:
  %t30 = mul i64 0, 8
  %t31 = insertvalue { i64, ptr } undef, i64 0, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t32, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_979fe2e14fb6de05_5947910940c194f1)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l11, !tbaa !24
  %t16 = icmp sge i64 3, 0
  br i1 %t16, label %bb5, label %bb6
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 1
  %t21 = extractvalue { i64, ptr } %t18, 0
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t20, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l8, !tbaa !27
  br label %bb11
bb5:
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 3, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_559eb4fe50ed7f04_5fd8618740f13e0)
  unreachable
bb7:
  %t29 = load i64, ptr %l10, !tbaa !24
  %t30 = load i64, ptr %l11, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_559eb4fe50ed7f04_5fd8618740f13e0)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l10, !tbaa !24
  %t36 = getelementptr i8, ptr %t34, i64 3
  %t37 = sub i64 %t35, 3
  %t38 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  %t40 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t43 = extractvalue { i64, ptr } %t39, 1
  %t44 = extractvalue { i64, ptr } %t39, 0
  %t45 = add i64 %t41, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t40, i64 %t41)
  %t47 = getelementptr i8, ptr %t46, i64 %t41
  call void @olang_textcopy(ptr %t47, ptr %t43, i64 %t44)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t46, 1
  store { i64, ptr } %t49, ptr %l8, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_559eb4fe50ed7f04_5fd8618740f13e0)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2edeclWord(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %l7, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l9, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t24, ptr %l7, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaredUnique(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l14
  br label %bb5
bb5:
  %t36 = load i1, ptr %l14, !tbaa !21
  br i1 %t36, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t37, ptr %l16, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l17, !tbaa !24
  %t40 = load i64, ptr %l17, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l18, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l17, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t51, ptr %l16, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t53, ptr %l20, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l21, !tbaa !24
  %t56 = load i64, ptr %l21, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l22, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l21, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t67, ptr %l20, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2eeffectLine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i1
  %l18 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca ptr
  %l32 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l73 = alloca %"compiler/effects:Facts"
  %l74 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v1, ptr %t8, i64 %t9)
  store i1 %t12, ptr %l18
  br label %bb3
bb3:
  %t13 = load i1, ptr %l18, !tbaa !21
  store i1 %t13, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v1, ptr %v1, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l22
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l22, !tbaa !29
  store ptr %t23, ptr %l5, !tbaa !29
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l23
  br label %bb9
bb9:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l6
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  store ptr %l6, ptr %l28, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/load:Loader", ptr %t41, i32 0, i32 3
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l32, !tbaa !29
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  br i1 %t50, label %bb12, label %bb13
bb11:
  br label %bb17
bb12:
  call void @__olang_check_failed(ptr @olang_loc_98928cfde749f632_385db913ea7e7976)
  unreachable
bb13:
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t54 = getelementptr %"compiler/ast:Func", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Param", ptr %t55, i32 0, i32 1
  %t59 = load i32, ptr %t58, !tbaa !23
  %t60 = load ptr, ptr %l32, !tbaa !29
  %t62 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s2, ptr %t60, i32 %t59)
  store { i64, ptr } %t62, ptr %l40
  br label %bb15
bb15:
  %t63 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t64, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load ptr, ptr %l28, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t76, { i64, ptr } %t75)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t80 = getelementptr %"compiler/ast:Func", ptr %t78, i32 0, i32 3
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Sig", ptr %t81, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l9, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb20:
  br label %bb21
bb21:
  %t98 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t98, ptr %l52, !tbaa !27
  %t99 = load i64, ptr %l8, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr ptr, ptr %t102, i64 %t99
  %t104 = load ptr, ptr %t103, !tbaa !39
  store ptr %l6, ptr %l55, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/load:Loader", ptr %t112, i32 0, i32 3
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t118 = getelementptr %"compiler/ast:Param", ptr %t104, i32 0, i32 1
  %t119 = load i32, ptr %t118, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s5, ptr %t115, i32 %t119)
  store { i64, ptr } %t122, ptr %l62
  br label %bb22
bb22:
  %t123 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t124, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t136 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t136, { i64, ptr } %t135)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l8, !tbaa !24
  br label %bb18
bb25:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v1, ptr %v1, ptr %t142)
  store ptr %t144, ptr %l68
  br label %bb26
bb26:
  %t145 = load ptr, ptr %l68, !tbaa !29
  store ptr %a0, ptr %l69, !tbaa !29
  store { i64, ptr } %a4, ptr %l70, !tbaa !27
  %t149 = load i64, ptr %l3, !tbaa !24
  %t152 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v1, ptr %t145, i64 %t149)
  store %"compiler/effects:Facts" %t152, ptr %l73
  br label %bb27
bb27:
  store ptr %l73, ptr %l74, !tbaa !29
  %t154 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t154, ptr %l76
  br label %bb28
bb28:
  %t155 = load ptr, ptr %l74, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t157 = call { i64, ptr } @compiler_2feffects_2eDescribe(ptr %s0, ptr %s0, ptr %s0, ptr %t155, { i64, ptr } %t156)
  store { i64, ptr } %t157, ptr %l77
  br label %bb29
bb29:
  %t158 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t164 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = add i64 %t163, %t166
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t159, i64 %t160)
  %t172 = getelementptr i8, ptr %t171, i64 %t160
  call void @olang_textcopy(ptr %t172, ptr %t161, i64 %t162)
  %t173 = getelementptr i8, ptr %t172, i64 %t162
  call void @olang_textcopy(ptr %t173, ptr %t165, i64 %t166)
  %t174 = getelementptr i8, ptr %t173, i64 %t166
  call void @olang_textcopy(ptr %t174, ptr %t168, i64 %t169)
  %t175 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t171, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } %t176, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t184 = load ptr, ptr %l69, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t184, { i64, ptr } %t183)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb51
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l56, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = sub i64 %t96, 1
  store i64 %t98, ptr %l1, !tbaa !24
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = icmp eq i8 %t104, 63
  store i1 %t106, ptr %l63, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb34
bb34:
  %t108 = load i1, ptr %l63, !tbaa !21
  br i1 %t108, label %bb35, label %bb36
bb35:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t111 = icmp sgt i64 %t109, 0
  store i1 %t111, ptr %l66, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb37
bb37:
  %t113 = load i1, ptr %l66, !tbaa !21
  br i1 %t113, label %bb38, label %bb39
bb38:
  %t114 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t114, ptr %l70, !tbaa !27
  %t115 = load i64, ptr %l7, !tbaa !24
  %t117 = sub i64 %t115, 1
  %t119 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i8, ptr %t120, i64 %t117
  %t122 = load i8, ptr %t121, !tbaa !32
  %t124 = icmp eq i8 %t122, 32
  store i1 %t124, ptr %l69, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb40
bb40:
  %t126 = load i1, ptr %l69, !tbaa !21
  br i1 %t126, label %bb41, label %bb42
bb41:
  %t127 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t127, ptr %l75, !tbaa !27
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = sub i64 %t128, 1
  store i64 %t130, ptr %l77, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t131, 0
  store i64 %t134, ptr %l80, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l81, !tbaa !24
  %t137 = load i64, ptr %l77, !tbaa !24
  %t138 = icmp sge i64 %t137, 0
  br i1 %t138, label %bb43, label %bb44
bb42:
  br label %bb49
bb43:
  %t140 = load i64, ptr %l77, !tbaa !24
  %t141 = load i64, ptr %l80, !tbaa !24
  %t142 = icmp sle i64 %t140, %t141
  br i1 %t142, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb45:
  %t144 = load i64, ptr %l80, !tbaa !24
  %t145 = load i64, ptr %l81, !tbaa !24
  %t146 = icmp sle i64 %t144, %t145
  br i1 %t146, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb47:
  %t148 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = load i64, ptr %l77, !tbaa !24
  %t151 = load i64, ptr %l80, !tbaa !24
  %t152 = getelementptr i8, ptr %t149, i64 %t150
  %t153 = sub i64 %t151, %t150
  %t154 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t152, 1
  store { i64, ptr } %t155, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb49:
  br label %bb50
bb50:
  %t158 = load i64, ptr %l6, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l6, !tbaa !24
  br label %bb7
bb51:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l89, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t162, ptr %l90, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l91, !tbaa !24
  %t165 = load i64, ptr %l91, !tbaa !24
  %t166 = mul i64 %t165, 1
  %t167 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t166)
  %t168 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l92, !tbaa !27
  %t170 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = load i64, ptr %l91, !tbaa !24
  %t175 = mul i64 %t174, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t171, ptr %t173, i64 %t175, i1 false)
  %t176 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t176, ptr %l90, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t177, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2efields(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/typed:Local"
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l23 = alloca i64
  %l25 = alloca i64
  %l30 = alloca ptr
  %l41 = alloca i32
  %l45 = alloca i1
  %l50 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i1
  %l62 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l74 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca i64
  %l81 = alloca ptr
  %l91 = alloca i64
  %l95 = alloca i64
  %l98 = alloca i64
  %l117 = alloca ptr
  %l121 = alloca i32
  %l123 = alloca %"compiler/typed:Local"
  %l128 = alloca i32
  %l129 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l138 = alloca i64
  %l140 = alloca i64
  %l141 = alloca i64
  %l151 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l153 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l23, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l25
  br label %bb2
bb2:
  %t9 = load i64, ptr %l23, !tbaa !24
  %t10 = load i64, ptr %l25, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb69
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l30
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l30, !tbaa !29
  store ptr %t20, ptr %l5, !tbaa !29
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 1
  %t24 = load { i64, [2 x i64] }, ptr %t23
  store { i64, [2 x i64] } %t24, ptr %l6
  %t26 = load { i64, [2 x i64] }, ptr %l6
  %t28 = extractvalue { i64, [2 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 1
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t32 = getelementptr { i32, i32 }, ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l7, !tbaa !23
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t36 = getelementptr { i32, i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l8, !tbaa !23
  br label %bb9
bb8:
  br label %bb62
bb9:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l7, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l41
  br label %bb10
bb10:
  %t49 = load i32, ptr %l41, !range !{i32 0, i32 33}
  %t51 = trunc i64 18 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb15
bb12:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l7, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l50
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l2, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l55
  br label %bb14
bb14:
  %t76 = load i32, ptr %l50, !tbaa !23
  %t77 = load i32, ptr %l55, !tbaa !23
  %t78 = icmp ne i32 %t76, %t77
  store i1 %t78, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t80 = load i1, ptr %l45, !tbaa !21
  br i1 %t80, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb18
bb17:
  %t81 = load i32, ptr %l8, !tbaa !23
  %t83 = icmp ne i32 %t81, 0
  store i1 %t83, ptr %l57, !tbaa !21
  br label %bb18
bb18:
  %t85 = load i1, ptr %l57, !tbaa !21
  br i1 %t85, label %bb19, label %bb20
bb19:
  br label %bb68
bb20:
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  store ptr %t91, ptr %l62, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l2, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v1, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l67
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l62, !tbaa !29
  %t103 = load i32, ptr %l67, !tbaa !23
  %t104 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %v1, ptr %t102, i32 %t103)
  store { i64, ptr } %t104, ptr %l68
  br label %bb23
bb23:
  %t105 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t105, ptr %l9, !tbaa !27
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/load:Loader", ptr %t112, i32 0, i32 10
  store ptr %t114, ptr %l72, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  store ptr %t118, ptr %l74, !tbaa !29
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l2, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l79
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l74, !tbaa !29
  %t130 = load i32, ptr %l79, !tbaa !23
  %t131 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v1, ptr %t129, i32 %t130)
  store i64 %t131, ptr %l80
  br label %bb25
bb25:
  %t132 = load ptr, ptr %l72, !tbaa !29
  %t133 = load i64, ptr %l80, !tbaa !24
  %t134 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t132, i64 %t133)
  store ptr %t134, ptr %l81
  br label %bb26
bb26:
  %t135 = load ptr, ptr %l81, !tbaa !29
  %t137 = getelementptr %"compiler/load:Module", ptr %t135, i32 0, i32 6
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %l10, !tbaa !29
  %t140 = load ptr, ptr %l10, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_1ab09a44950d5518_36fac77ffd6769bc)
  unreachable
bb28:
  br label %bb29
bb29:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t147 = getelementptr %"compiler/source:Source", ptr %t144, i32 0, i32 1
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t150 = load ptr, ptr %l5, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Body", ptr %t150, i32 0, i32 10
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t152)
  store i64 %t154, ptr %l91
  br label %bb30
bb30:
  %t155 = load i64, ptr %l91, !tbaa !24
  store i64 %t155, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l12, !tbaa !24
  %t160 = icmp sgt i64 %t156, %t157
  br i1 %t160, label %bb31, label %bb32
bb31:
  %t162 = load i64, ptr %l14, !tbaa !24
  %t164 = icmp sgt i64 %t162, 0
  br i1 %t164, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb36
bb33:
  %t166 = load i64, ptr %l13, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = sub i64 %t166, %t167
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = add i64 %t170, %t171
  %t176 = sub i64 %t174, 1
  %t177 = load i64, ptr %l14, !tbaa !24
  %t180 = sdiv i64 %t176, %t177
  store i64 %t180, ptr %l98, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb35
bb35:
  %t182 = load i64, ptr %l98, !tbaa !24
  store i64 %t182, ptr %l95, !tbaa !24
  br label %bb36
bb36:
  %t183 = load i64, ptr %l95, !tbaa !24
  store i64 %t183, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb61
bb39:
  br label %bb40
bb40:
  %t192 = load i64, ptr %l12, !tbaa !24
  %t193 = load i64, ptr %l16, !tbaa !24
  %t194 = load i64, ptr %l14, !tbaa !24
  %t197 = mul i64 %t193, %t194
  %t200 = add i64 %t192, %t197
  store i64 %t200, ptr %l17, !tbaa !24
  %t202 = load ptr, ptr %l5, !tbaa !29
  %t204 = getelementptr %"compiler/typed:Body", ptr %t202, i32 0, i32 7
  store ptr %t204, ptr %l117, !tbaa !29
  %t205 = load ptr, ptr %l5, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Body", ptr %t205, i32 0, i32 10
  %t208 = load i64, ptr %l17, !tbaa !24
  %t211 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t207, i64 %t208)
  store i32 %t211, ptr %l121
  br label %bb41
bb41:
  %t212 = load i32, ptr %l121, !tbaa !23
  %t213 = sext i32 %t212 to i64
  %t214 = load ptr, ptr %l117, !tbaa !29
  %t216 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t214, i64 %t213)
  store %"compiler/typed:Local" %t216, ptr %l123
  br label %bb42
bb42:
  %t217 = load %"compiler/typed:Local", ptr %l123
  store %"compiler/typed:Local" %t217, ptr %l18
  %t218 = load i64, ptr %l17, !tbaa !24
  %t219 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t224 = icmp slt i64 %t218, %t221
  br i1 %t224, label %bb43, label %bb44
bb43:
  %t226 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t226, ptr %l129, !tbaa !27
  %t227 = load i64, ptr %l17, !tbaa !24
  %t229 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr i32, ptr %t230, i64 %t227
  %t232 = load i32, ptr %t231, !tbaa !33
  store i32 %t232, ptr %l128, !tbaa !23
  br label %bb45
bb44:
  %t234 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 2
  %t235 = load i32, ptr %t234, !tbaa !23
  store i32 %t235, ptr %l128, !tbaa !23
  br label %bb45
bb45:
  %t237 = load i32, ptr %l128, !tbaa !23
  store i32 %t237, ptr %l19, !tbaa !23
  %t238 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 0
  %t239 = load i32, ptr %t238, !tbaa !23
  %t241 = icmp eq i32 %t239, 0
  br i1 %t241, label %bb46, label %bb47
bb46:
  %t243 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t243, ptr %l136, !tbaa !27
  %t244 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t245 = getelementptr %"compiler/source:Span", ptr %t244, i32 0, i32 0
  %t246 = load i32, ptr %t245, !tbaa !23
  %t248 = sext i32 %t246 to i64
  store i64 %t248, ptr %l138, !tbaa !24
  %t249 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t250 = getelementptr %"compiler/source:Span", ptr %t249, i32 0, i32 1
  %t251 = load i32, ptr %t250, !tbaa !23
  %t253 = sext i32 %t251 to i64
  store i64 %t253, ptr %l140, !tbaa !24
  %t254 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  store i64 %t255, ptr %l141, !tbaa !24
  %t256 = load i64, ptr %l138, !tbaa !24
  %t257 = icmp sge i64 %t256, 0
  br i1 %t257, label %bb48, label %bb49
bb47:
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t259, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !29
  %t264 = getelementptr %"compiler/generic:Program", ptr %t262, i32 0, i32 0
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = getelementptr %"compiler/load:Loader", ptr %t265, i32 0, i32 3
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 0
  %t270 = load i32, ptr %t269, !tbaa !23
  %t273 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s6, ptr %t268, i32 %t270)
  store { i64, ptr } %t273, ptr %l151
  br label %bb54
bb48:
  %t274 = load i64, ptr %l138, !tbaa !24
  %t275 = load i64, ptr %l140, !tbaa !24
  %t276 = icmp sle i64 %t274, %t275
  br i1 %t276, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021)
  unreachable
bb50:
  %t278 = load i64, ptr %l140, !tbaa !24
  %t279 = load i64, ptr %l141, !tbaa !24
  %t280 = icmp sle i64 %t278, %t279
  br i1 %t280, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021)
  unreachable
bb52:
  %t282 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = load i64, ptr %l138, !tbaa !24
  %t285 = load i64, ptr %l140, !tbaa !24
  %t286 = getelementptr i8, ptr %t283, i64 %t284
  %t287 = sub i64 %t285, %t284
  %t288 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t286, 1
  store { i64, ptr } %t289, ptr %l135, !tbaa !27
  br label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021)
  unreachable
bb54:
  %t291 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t291, ptr %l135, !tbaa !27
  br label %bb55
bb55:
  %t292 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t292, ptr %l20, !tbaa !27
  store ptr %a0, ptr %l152, !tbaa !29
  %t294 = load ptr, ptr %l1, !tbaa !29
  store ptr %t294, ptr %l153, !tbaa !29
  %t295 = load ptr, ptr %l1, !tbaa !29
  %t297 = getelementptr %"compiler/check:Checker", ptr %t295, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t299 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t300 = load i32, ptr %l2, !tbaa !23
  %t301 = load i64, ptr %l17, !tbaa !24
  %t306 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v1, ptr %t298, i64 %t299, i32 %t300, i64 0, i64 %t301)
  store i32 %t306, ptr %l159
  br label %bb56
bb56:
  %t307 = load ptr, ptr %l153, !tbaa !29
  %t308 = load i32, ptr %l159, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2fexplain_2eattrsBefore(ptr %v1, ptr %s6, ptr %t307, i32 %t308)
  store { i64, ptr } %t309, ptr %l160
  br label %bb57
bb57:
  %t310 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t310, ptr %l161, !tbaa !27
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t312 = load i32, ptr %l19, !tbaa !23
  %t315 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s6, ptr %t311, i32 %t312)
  store { i64, ptr } %t315, ptr %l164
  br label %bb58
bb58:
  %t316 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t318 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 1
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t321 = add i64 %t317, %t320
  %t322 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 1
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t325 = add i64 %t321, %t324
  %t326 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t327 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t328 = add i64 %t325, %t327
  %t329 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = add i64 %t328, %t331
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t334 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t335 = add i64 %t332, %t334
  %t336 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t335)
  call void @olang_textcopy(ptr %t336, ptr %t316, i64 %t317)
  %t337 = getelementptr i8, ptr %t336, i64 %t317
  call void @olang_textcopy(ptr %t337, ptr %t319, i64 %t320)
  %t338 = getelementptr i8, ptr %t337, i64 %t320
  call void @olang_textcopy(ptr %t338, ptr %t323, i64 %t324)
  %t339 = getelementptr i8, ptr %t338, i64 %t324
  call void @olang_textcopy(ptr %t339, ptr %t326, i64 %t327)
  %t340 = getelementptr i8, ptr %t339, i64 %t327
  call void @olang_textcopy(ptr %t340, ptr %t330, i64 %t331)
  %t341 = getelementptr i8, ptr %t340, i64 %t331
  call void @olang_textcopy(ptr %t341, ptr %t333, i64 %t334)
  %t342 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t336, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = extractvalue { i64, ptr } %t343, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  %t351 = load ptr, ptr %l152, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t351, { i64, ptr } %t350)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb60:
  %t353 = load i64, ptr %l16, !tbaa !24
  %t355 = add i64 %t353, 1
  store i64 %t355, ptr %l16, !tbaa !24
  br label %bb37
bb61:
  br label %ret
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_b65b7d917c440185_24d12a03c9296209)
  unreachable
bb67:
  br label %bb68
bb68:
  %t357 = load i64, ptr %l4, !tbaa !24
  %t359 = add i64 %t357, 1
  store i64 %t359, ptr %l4, !tbaa !24
  br label %bb1
bb69:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fexplain_2efirstClose(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t2, 0
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = icmp sge i64 3, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sle i64 3, %t10
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sle i64 %t13, %t14
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb5:
  %t17 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr i8, ptr %t18, i64 3
  %t21 = sub i64 %t19, 3
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = call i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %t23)
  store i64 %t25, ptr %l10
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb7:
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = add i64 3, %t26
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEnd(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb42
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l56, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = sub i64 %t96, 1
  store i64 %t98, ptr %l1, !tbaa !24
  br label %bb41
bb30:
  br label %bb31
bb31:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = icmp eq i8 %t104, 44
  br i1 %t106, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb37
bb34:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb36
bb35:
  %t108 = load i8, ptr %l8, !tbaa !22
  %t110 = icmp eq i8 %t108, 41
  store i1 %t110, ptr %l66, !tbaa !21
  br label %bb36
bb36:
  %t112 = load i1, ptr %l66, !tbaa !21
  store i1 %t112, ptr %l63, !tbaa !21
  br label %bb37
bb37:
  %t113 = load i1, ptr %l63, !tbaa !21
  br i1 %t113, label %bb38, label %bb39
bb38:
  %t114 = load i64, ptr %l7, !tbaa !24
  store i64 %t114, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l6, !tbaa !24
  br label %bb7
bb42:
  %t120 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  store i64 %t122, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb28, label %bb29
bb27:
  br label %bb31
bb28:
  %t95 = load i64, ptr %l7, !tbaa !24
  store i64 %t95, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t97 = load i64, ptr %l1, !tbaa !24
  %t99 = sub i64 %t97, 1
  store i64 %t99, ptr %l1, !tbaa !24
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l6, !tbaa !24
  br label %bb7
bb33:
  %t105 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i64
  %l30 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i64
  %l53 = alloca i32
  %l55 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca i64
  %l91 = alloca i32
  %l92 = alloca { i64, ptr }
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca ptr
  %l106 = alloca i64
  %l109 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l136 = alloca i64
  %l140 = alloca i64
  %l143 = alloca i64
  %l164 = alloca i64
  %l169 = alloca i64
  %l172 = alloca ptr
  %l176 = alloca i32
  %l182 = alloca i32
  %l183 = alloca ptr
  %l190 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l195 = alloca i32
  %l196 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l20
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  store ptr %l3, ptr %l21, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l22, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t7, i64 %t8)
  store i64 %t11, ptr %l26
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l30
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l30, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 8
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t24 = load ptr, ptr %l21, !tbaa !29
  %t25 = load ptr, ptr %l22, !tbaa !29
  %t26 = load i64, ptr %l26, !tbaa !24
  call void @compiler_2fexplain_2eattrLines(ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t24, ptr %t25, i64 %t26, { i64, ptr } %t23, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb4
bb4:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t28)
  store i64 %t30, ptr %l34
  br label %bb5
bb5:
  %t31 = load i64, ptr %l34, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t35, i64 %t31)
  store i64 %t39, ptr %l38
  br label %bb6
bb6:
  %t40 = load i64, ptr %l38, !tbaa !24
  %t41 = icmp eq i64 %t40, 0
  br i1 %t41, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i64, ptr %l2, !tbaa !24
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t46, i64 %t47, i32 0)
  store i64 %t50, ptr %l43
  br label %bb9
bb8:
  br label %bb21
bb9:
  %t51 = load i64, ptr %l43, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l46
  br label %bb10
bb10:
  %t57 = load i64, ptr %l46, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  store ptr %l3, ptr %l47, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l48, !tbaa !29
  %t59 = load i64, ptr %l2, !tbaa !24
  store i64 %t59, ptr %l49, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t63, i64 %t64)
  store i32 %t67, ptr %l53
  br label %bb11
bb11:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t69 = load ptr, ptr %l48, !tbaa !29
  %t70 = load i64, ptr %l49, !tbaa !24
  %t71 = load i32, ptr %l53, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s1, ptr %t69, i64 %t70, i32 %t71, i64 %t68)
  store { i64, ptr } %t73, ptr %l55
  br label %bb12
bb12:
  %t74 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t75, i64 %t76)
  %t81 = getelementptr i8, ptr %t80, i64 %t76
  call void @olang_textcopy(ptr %t81, ptr %t77, i64 %t78)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t91, { i64, ptr } %t90)
  br label %bb13
bb13:
  store ptr %l3, ptr %l58, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l59, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t98 = load i64, ptr %l2, !tbaa !24
  %t101 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t97, i64 %t98)
  store ptr %t101, ptr %l63
  br label %bb14
bb14:
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Func", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  store ptr %t105, ptr %l65, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l2, !tbaa !24
  %t113 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t109, i64 %t110)
  store i64 %t113, ptr %l69
  br label %bb15
bb15:
  %t114 = load ptr, ptr %l58, !tbaa !29
  %t115 = load ptr, ptr %l59, !tbaa !29
  %t116 = load ptr, ptr %l65, !tbaa !29
  %t117 = load i64, ptr %l69, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s1, ptr %t114, ptr %t115, ptr %t116, i64 %t117, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb16
bb16:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t120 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s1, ptr %l3, ptr %t118, ptr %t119, i64 %t120, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb17
bb17:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t127 = load i64, ptr %l2, !tbaa !24
  %t128 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2enoValue(ptr %s0, ptr %v0, ptr %v1, ptr %s1, ptr %l3, ptr %t125, ptr %t126, i64 %t127, i64 %t128, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb18
bb18:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l2, !tbaa !24
  %t136 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2eeffectLine(ptr %s0, ptr %v0, ptr %s1, ptr %l3, ptr %t134, i64 %t135, i64 %t136, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb19
bb19:
  %t142 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t142, ptr %l84
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t143 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t143, ptr %rv
  br label %ret
bb21:
  store ptr %l3, ptr %l85, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l86, !tbaa !29
  %t145 = load i64, ptr %l2, !tbaa !24
  store i64 %t145, ptr %l87, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load i64, ptr %l2, !tbaa !24
  %t153 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t149, i64 %t150)
  store i32 %t153, ptr %l91
  br label %bb22
bb22:
  %t154 = load ptr, ptr %l86, !tbaa !29
  %t155 = load i64, ptr %l87, !tbaa !24
  %t156 = load i32, ptr %l91, !tbaa !23
  %t157 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s0, ptr %t154, i64 %t155, i32 %t156, i64 -1)
  store { i64, ptr } %t157, ptr %l92
  br label %bb23
bb23:
  %t158 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t164 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t163)
  call void @olang_textcopy(ptr %t164, ptr %t159, i64 %t160)
  %t165 = getelementptr i8, ptr %t164, i64 %t160
  call void @olang_textcopy(ptr %t165, ptr %t161, i64 %t162)
  %t166 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t164, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = extractvalue { i64, ptr } %t167, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t175 = load ptr, ptr %l85, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t175, { i64, ptr } %t174)
  br label %bb24
bb24:
  store ptr %l3, ptr %l95, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l96, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t182 = load i64, ptr %l2, !tbaa !24
  %t185 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t181, i64 %t182)
  store ptr %t185, ptr %l100
  br label %bb25
bb25:
  %t186 = load ptr, ptr %l100, !tbaa !29
  %t188 = getelementptr %"compiler/ast:Func", ptr %t186, i32 0, i32 3
  %t189 = load ptr, ptr %t188, !tbaa !29
  store ptr %t189, ptr %l102, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/check:Checker", ptr %t190, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t194 = load i64, ptr %l2, !tbaa !24
  %t197 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t193, i64 %t194)
  store i64 %t197, ptr %l106
  br label %bb26
bb26:
  %t198 = load ptr, ptr %l95, !tbaa !29
  %t199 = load ptr, ptr %l96, !tbaa !29
  %t200 = load ptr, ptr %l102, !tbaa !29
  %t201 = load i64, ptr %l106, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t198, ptr %t199, ptr %t200, i64 %t201, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l2, !tbaa !24
  %t206 = call { i64, ptr } @compiler_2fneeds_2eLines(ptr %v0, ptr %s4, ptr %t202, i64 %t203)
  store { i64, ptr } %t206, ptr %l109
  br label %bb28
bb28:
  %t207 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = extractvalue { i64, ptr } %t207, 1
  %t210 = mul i64 %t208, 16
  %t211 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  store { i64, ptr } %t213, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t215 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t215, 0
  store i64 %t217, ptr %l9, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t219 = load i64, ptr %l8, !tbaa !24
  %t220 = load i64, ptr %l9, !tbaa !24
  %t223 = icmp slt i64 %t219, %t220
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t227 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t227, ptr %l117, !tbaa !27
  %t228 = load i64, ptr %l8, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %t231, i64 %t228
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !37
  %t236 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t239 = extractvalue { i64, ptr } %t233, 1
  %t240 = extractvalue { i64, ptr } %t233, 0
  %t241 = add i64 %t237, %t240
  %t242 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t244 = add i64 %t241, %t243
  %t245 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t244)
  call void @olang_textcopy(ptr %t245, ptr %t236, i64 %t237)
  %t246 = getelementptr i8, ptr %t245, i64 %t237
  call void @olang_textcopy(ptr %t246, ptr %t239, i64 %t240)
  %t247 = getelementptr i8, ptr %t246, i64 %t240
  call void @olang_textcopy(ptr %t247, ptr %t242, i64 %t243)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t245, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = extractvalue { i64, ptr } %t249, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l3, { i64, ptr } %t256)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  %t259 = load i64, ptr %l8, !tbaa !24
  %t261 = add i64 %t259, 1
  store i64 %t261, ptr %l8, !tbaa !24
  br label %bb29
bb35:
  call void @__olang_scope_close(ptr %s4)
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t265 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fexplain_2enoValue(ptr %s0, ptr %v0, ptr %v1, ptr %s0, ptr %l3, ptr %t263, ptr %t264, i64 %t265, i64 -1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb36
bb36:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = load i64, ptr %l2, !tbaa !24
  %t277 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t273, i64 %t274)
  store ptr %t277, ptr %l133
  br label %bb37
bb37:
  %t278 = load ptr, ptr %l133, !tbaa !29
  store ptr %t278, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %t282)
  store i64 %t284, ptr %l136
  br label %bb38
bb38:
  %t285 = load i64, ptr %l136, !tbaa !24
  store i64 %t285, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t286 = load i64, ptr %l13, !tbaa !24
  %t287 = load i64, ptr %l12, !tbaa !24
  %t290 = icmp sgt i64 %t286, %t287
  br i1 %t290, label %bb39, label %bb40
bb39:
  %t292 = load i64, ptr %l14, !tbaa !24
  %t294 = icmp sgt i64 %t292, 0
  br i1 %t294, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb44
bb41:
  %t296 = load i64, ptr %l13, !tbaa !24
  %t297 = load i64, ptr %l12, !tbaa !24
  %t300 = sub i64 %t296, %t297
  %t301 = load i64, ptr %l14, !tbaa !24
  %t304 = add i64 %t300, %t301
  %t306 = sub i64 %t304, 1
  %t307 = load i64, ptr %l14, !tbaa !24
  %t310 = sdiv i64 %t306, %t307
  store i64 %t310, ptr %l143, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb43
bb43:
  %t312 = load i64, ptr %l143, !tbaa !24
  store i64 %t312, ptr %l140, !tbaa !24
  br label %bb44
bb44:
  %t313 = load i64, ptr %l140, !tbaa !24
  store i64 %t313, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t314 = load i64, ptr %l16, !tbaa !24
  %t315 = load i64, ptr %l15, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb67
bb47:
  br label %bb48
bb48:
  %t322 = load i64, ptr %l12, !tbaa !24
  %t323 = load i64, ptr %l16, !tbaa !24
  %t324 = load i64, ptr %l14, !tbaa !24
  %t327 = mul i64 %t323, %t324
  %t330 = add i64 %t322, %t327
  store i64 %t330, ptr %l17, !tbaa !24
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t332, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !29
  %t336 = load i64, ptr %l17, !tbaa !24
  %t339 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t335, i64 %t336)
  store i64 %t339, ptr %l164
  br label %bb49
bb49:
  %t340 = load i64, ptr %l2, !tbaa !24
  %t341 = load i64, ptr %l164, !tbaa !24
  %t343 = icmp ne i64 %t341, %t340
  br i1 %t343, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb51:
  br label %bb52
bb52:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i64, ptr %l17, !tbaa !24
  %t349 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t345, i64 %t346)
  store i64 %t349, ptr %l169
  br label %bb53
bb53:
  %t350 = load i64, ptr %l169, !tbaa !24
  store i64 %t350, ptr %l18, !tbaa !24
  %t351 = load i64, ptr %l18, !tbaa !24
  %t353 = icmp slt i64 %t351, 0
  br i1 %t353, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb55:
  br label %bb56
bb56:
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l172, !tbaa !29
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/check:Checker", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t360 = load i64, ptr %l17, !tbaa !24
  %t363 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t359, i64 %t360)
  store i32 %t363, ptr %l176
  br label %bb57
bb57:
  %t364 = load ptr, ptr %l11, !tbaa !29
  %t366 = getelementptr %"compiler/ast:Func", ptr %t364, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !29
  %t368 = load ptr, ptr %l11, !tbaa !29
  %t370 = getelementptr %"compiler/ast:Func", ptr %t368, i32 0, i32 3
  %t371 = load ptr, ptr %t370, !tbaa !29
  %t373 = getelementptr %"compiler/ast:Sig", ptr %t371, i32 0, i32 0
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  %t375 = load ptr, ptr %l172, !tbaa !29
  %t376 = load i32, ptr %l176, !tbaa !23
  %t379 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t375, i32 %t376, ptr %t367, { i64, ptr } %t374)
  store i32 %t379, ptr %l182
  br label %bb58
bb58:
  %t380 = load i32, ptr %l182, !tbaa !23
  store i32 %t380, ptr %l19, !tbaa !23
  store ptr %l3, ptr %l183, !tbaa !29
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/check:Checker", ptr %t381, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t386 = getelementptr %"compiler/generic:Program", ptr %t384, i32 0, i32 0
  %t387 = load ptr, ptr %t386, !tbaa !29
  %t389 = getelementptr %"compiler/load:Loader", ptr %t387, i32 0, i32 3
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t391 = load ptr, ptr %l11, !tbaa !29
  %t393 = getelementptr %"compiler/ast:Func", ptr %t391, i32 0, i32 2
  %t394 = load i32, ptr %t393, !tbaa !23
  %t397 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s9, ptr %t390, i32 %t394)
  store { i64, ptr } %t397, ptr %l190
  br label %bb59
bb59:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l191, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/check:Checker", ptr %t399, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !29
  %t403 = load i64, ptr %l17, !tbaa !24
  %t406 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t402, i64 %t403)
  store i32 %t406, ptr %l195
  br label %bb60
bb60:
  %t407 = load ptr, ptr %l191, !tbaa !29
  %t408 = load i32, ptr %l195, !tbaa !23
  %t409 = call { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %s9, ptr %t407, i32 %t408)
  store { i64, ptr } %t409, ptr %l196
  br label %bb61
bb61:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load i32, ptr %l19, !tbaa !23
  %t412 = load i64, ptr %l18, !tbaa !24
  %t416 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s9, ptr %t410, i32 %t411, i64 %t412)
  store { i64, ptr } %t416, ptr %l200
  br label %bb62
bb62:
  %t417 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t419 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t419, 1
  %t421 = extractvalue { i64, ptr } %t419, 0
  %t422 = add i64 %t418, %t421
  %t423 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t423, 1
  %t425 = extractvalue { i64, ptr } %t423, 0
  %t426 = add i64 %t422, %t425
  %t427 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t428 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t429 = add i64 %t426, %t428
  %t430 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t430, 1
  %t432 = extractvalue { i64, ptr } %t430, 0
  %t433 = add i64 %t429, %t432
  %t434 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t435 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t436 = add i64 %t433, %t435
  %t437 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t436)
  call void @olang_textcopy(ptr %t437, ptr %t417, i64 %t418)
  %t438 = getelementptr i8, ptr %t437, i64 %t418
  call void @olang_textcopy(ptr %t438, ptr %t420, i64 %t421)
  %t439 = getelementptr i8, ptr %t438, i64 %t421
  call void @olang_textcopy(ptr %t439, ptr %t424, i64 %t425)
  %t440 = getelementptr i8, ptr %t439, i64 %t425
  call void @olang_textcopy(ptr %t440, ptr %t427, i64 %t428)
  %t441 = getelementptr i8, ptr %t440, i64 %t428
  call void @olang_textcopy(ptr %t441, ptr %t431, i64 %t432)
  %t442 = getelementptr i8, ptr %t441, i64 %t432
  call void @olang_textcopy(ptr %t442, ptr %t434, i64 %t435)
  %t443 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t437, 1
  %t446 = extractvalue { i64, ptr } %t444, 0
  %t447 = extractvalue { i64, ptr } %t444, 1
  %t448 = mul i64 %t446, 1
  %t449 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t448)
  call void @llvm.memcpy.p0.p0.i64(ptr %t449, ptr %t447, i64 %t448, i1 false)
  %t450 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t449, 1
  %t452 = load ptr, ptr %l183, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t452, { i64, ptr } %t451)
  br label %bb63
bb63:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load ptr, ptr %l1, !tbaa !29
  %t456 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s9, ptr %l3, ptr %t454, ptr %t455, i64 %t456, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d53, i32 0, i32 1) })
  br label %bb64
bb64:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load i64, ptr %l2, !tbaa !24
  %t463 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fexplain_2eeffectLine(ptr %s0, ptr %v0, ptr %s9, ptr %l3, ptr %t461, i64 %t462, i64 %t463, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) })
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb66:
  %t468 = load i64, ptr %l16, !tbaa !24
  %t470 = add i64 %t468, 1
  store i64 %t470, ptr %l16, !tbaa !24
  br label %bb45
bb67:
  %t473 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t473, ptr %l214
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t474 = load { i64, ptr }, ptr %l214, !tbaa !27
  store { i64, ptr } %t474, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i8
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l40 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l47 = alloca i1
  %l51 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca { i64, ptr }
  %l72 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l79 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l89 = alloca i64
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l97 = alloca i64
  %l99 = alloca ptr
  %l107 = alloca i32
  %l109 = alloca { i64, ptr }
  %l113 = alloca i1
  %l114 = alloca ptr
  %l119 = alloca i32
  %l120 = alloca { i64, ptr }
  %l123 = alloca i1
  %l124 = alloca i1
  %l126 = alloca i1
  %l131 = alloca i64
  %l132 = alloca i64
  %l136 = alloca { i64, ptr }
  %l138 = alloca i64
  %l139 = alloca i64
  %l145 = alloca { i64, ptr }
  %l147 = alloca i64
  %l151 = alloca i1
  %l152 = alloca i1
  %l154 = alloca i1
  %l156 = alloca i64
  %l157 = alloca i64
  %l170 = alloca i64
  %l173 = alloca i64
  %l191 = alloca { i64, ptr }
  %l196 = alloca i1
  %l203 = alloca i1
  %l206 = alloca i1
  %l213 = alloca i1
  %l216 = alloca i1
  %l219 = alloca i1
  %l222 = alloca i1
  %l228 = alloca i1
  %l229 = alloca { i64, ptr }
  %l241 = alloca i64
  %l242 = alloca i64
  %l246 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l248 = alloca i64
  %l249 = alloca i64
  %l253 = alloca { i64, ptr }
  %l254 = alloca { i64, ptr }
  %l255 = alloca i64
  %l258 = alloca i64
  %l259 = alloca i64
  %l265 = alloca { i64, ptr }
  %l267 = alloca i64
  %l272 = alloca i1
  %l273 = alloca { i64, ptr }
  %l275 = alloca i64
  %l276 = alloca ptr
  %l277 = alloca i64
  %l278 = alloca i64
  %l282 = alloca { i64, ptr }
  %l285 = alloca { i64, ptr }
  %l289 = alloca i64
  %l294 = alloca i64
  %l295 = alloca { i64, ptr }
  %l296 = alloca i64
  %l298 = alloca i64
  %l299 = alloca i64
  %l313 = alloca i64
  %l314 = alloca i64
  %l315 = alloca i64
  %l323 = alloca { i64, ptr }
  %l325 = alloca i64
  %l327 = alloca i64
  %l328 = alloca i64
  %l333 = alloca i64
  %l335 = alloca i64
  %l336 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l30
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l30, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t19, i32 %t23)
  store { i64, ptr } %t26, ptr %l37
  br label %bb2
bb2:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l38, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t28)
  store i64 %t30, ptr %l40
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l43
  br label %bb4
bb4:
  %t36 = load ptr, ptr %l38, !tbaa !29
  %t37 = load i64, ptr %l40, !tbaa !24
  %t38 = load i64, ptr %l43, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t36, i64 %t37, i64 %t38)
  store { i64, ptr } %t39, ptr %l44
  br label %bb5
bb5:
  %t40 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = add i64 %t42, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t41, i64 %t42)
  %t48 = getelementptr i8, ptr %t47, i64 %t42
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t52)
  store i1 %t54, ptr %l47
  br label %bb6
bb6:
  %t55 = load i1, ptr %l47, !tbaa !21
  br i1 %t55, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 10
  store ptr %t64, ptr %l51, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  %t72 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l55
  br label %bb9
bb8:
  br label %bb31
bb9:
  %t73 = load ptr, ptr %l51, !tbaa !29
  %t74 = load i64, ptr %l55, !tbaa !24
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  store ptr %t75, ptr %l56
  br label %bb10
bb10:
  %t76 = load ptr, ptr %l56, !tbaa !29
  %t78 = getelementptr %"compiler/load:Module", ptr %t76, i32 0, i32 6
  %t79 = load ptr, ptr %t78, !tbaa !29
  store ptr %t79, ptr %l6, !tbaa !29
  %t81 = load ptr, ptr %l6, !tbaa !29
  %t83 = icmp eq ptr %t81, null
  br i1 %t83, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_fc7f64fd7b454af3_cf2a3e2278d9fc1f)
  unreachable
bb12:
  br label %bb13
bb13:
  %t85 = load ptr, ptr %l6, !tbaa !29
  %t88 = getelementptr %"compiler/source:Source", ptr %t85, i32 0, i32 1
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l7, !tbaa !27
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Func", ptr %t91, i32 0, i32 9
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_499d9639469ba124_2d1e6838c6dcdf80)
  unreachable
bb15:
  br label %bb16
bb16:
  %t98 = load ptr, ptr %l4, !tbaa !29
  %t100 = getelementptr %"compiler/ast:Func", ptr %t98, i32 0, i32 9
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t101)
  store %"compiler/source:Span" %t103, ptr %l69
  br label %bb17
bb17:
  %t104 = load %"compiler/source:Span", ptr %l69
  store %"compiler/source:Span" %t104, ptr %l8
  %t105 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t105, ptr %l70, !tbaa !27
  %t106 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = sext i32 %t107 to i64
  store i64 %t109, ptr %l72, !tbaa !24
  %t110 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t111 = load i32, ptr %t110, !tbaa !23
  %t113 = sext i32 %t111 to i64
  store i64 %t113, ptr %l74, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l75, !tbaa !24
  %t116 = load i64, ptr %l72, !tbaa !24
  %t117 = icmp sge i64 %t116, 0
  br i1 %t117, label %bb18, label %bb19
bb18:
  %t119 = load i64, ptr %l72, !tbaa !24
  %t120 = load i64, ptr %l74, !tbaa !24
  %t121 = icmp sle i64 %t119, %t120
  br i1 %t121, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb20:
  %t123 = load i64, ptr %l74, !tbaa !24
  %t124 = load i64, ptr %l75, !tbaa !24
  %t125 = icmp sle i64 %t123, %t124
  br i1 %t125, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb22:
  %t127 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l72, !tbaa !24
  %t130 = load i64, ptr %l74, !tbaa !24
  %t131 = getelementptr i8, ptr %t128, i64 %t129
  %t132 = sub i64 %t130, %t129
  %t133 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t131, 1
  store { i64, ptr } %t134, ptr %l79, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/load:Loader", ptr %t141, i32 0, i32 3
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t147 = getelementptr %"compiler/ast:Func", ptr %t145, i32 0, i32 10
  %t148 = load i32, ptr %t147, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t144, i32 %t148)
  store { i64, ptr } %t151, ptr %l86
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb24:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l87, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  %t155 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t153)
  store i64 %t155, ptr %l89
  br label %bb25
bb25:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i64, ptr %l1, !tbaa !24
  %t163 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerVarCount(ptr %v0, ptr %t159, i64 %t160)
  store i64 %t163, ptr %l93
  br label %bb26
bb26:
  %t164 = load ptr, ptr %l87, !tbaa !29
  %t165 = load i64, ptr %l89, !tbaa !24
  %t166 = load i64, ptr %l93, !tbaa !24
  %t167 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s2, ptr %t164, i64 %t165, i64 %t166)
  store { i64, ptr } %t167, ptr %l94
  br label %bb27
bb27:
  %t168 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t174 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = add i64 %t173, %t176
  %t178 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = add i64 %t177, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t169, i64 %t170)
  %t183 = getelementptr i8, ptr %t182, i64 %t170
  call void @olang_textcopy(ptr %t183, ptr %t171, i64 %t172)
  %t184 = getelementptr i8, ptr %t183, i64 %t172
  call void @olang_textcopy(ptr %t184, ptr %t175, i64 %t176)
  %t185 = getelementptr i8, ptr %t184, i64 %t176
  call void @olang_textcopy(ptr %t185, ptr %t179, i64 %t180)
  %t186 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t182, 1
  store { i64, ptr } %t187, ptr %l95, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  store i64 %t191, ptr %l97, !tbaa !24
  %t193 = load i64, ptr %l97, !tbaa !24
  %t194 = icmp eq i64 %t189, %t193
  br i1 %t194, label %bb28, label %bb29
bb28:
  %t196 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = load i64, ptr %l97, !tbaa !24
  %t201 = mul i64 %t200, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %t199, i64 %t201, i1 false)
  br label %bb30
bb29:
  %t202 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t202, ptr %l5, !tbaa !27
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l99, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i32, ptr %l2, !tbaa !23
  %t206 = load ptr, ptr %l4, !tbaa !29
  %t208 = getelementptr %"compiler/ast:Func", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t210 = load ptr, ptr %l4, !tbaa !29
  %t212 = getelementptr %"compiler/ast:Func", ptr %t210, i32 0, i32 3
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = getelementptr %"compiler/ast:Sig", ptr %t213, i32 0, i32 0
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  %t221 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t204, i32 %t205, ptr %t209, { i64, ptr } %t216)
  store i32 %t221, ptr %l107
  br label %bb32
bb32:
  %t223 = load ptr, ptr %l99, !tbaa !29
  %t224 = load i32, ptr %l107, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s0, ptr %t223, i32 %t224, i64 %a3)
  store { i64, ptr } %t226, ptr %l109
  br label %bb33
bb33:
  %t227 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t227, ptr %l9, !tbaa !27
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t232 = load i64, ptr %l1, !tbaa !24
  %t235 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t231, i64 %t232)
  store i1 %t235, ptr %l113
  br label %bb34
bb34:
  %t236 = load i1, ptr %l113, !tbaa !21
  br i1 %t236, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s4
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l114, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 2
  %t244 = load i32, ptr %l2, !tbaa !23
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t243, i32 %t244)
  store i32 %t247, ptr %l119
  br label %bb37
bb36:
  br label %bb142
bb37:
  %t248 = load ptr, ptr %l114, !tbaa !29
  %t249 = load i32, ptr %l119, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s4, ptr %t248, i32 %t249)
  store { i64, ptr } %t250, ptr %l120
  br label %bb38
bb38:
  %t251 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t251, ptr %l10, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t256 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s4, { i64, ptr } %t252, { i64, ptr } %t253)
  store i1 %t256, ptr %l123
  br label %bb39
bb39:
  %t257 = load i1, ptr %l123, !tbaa !21
  br i1 %t257, label %bb40, label %bb41
bb40:
  %t258 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t260 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s4, ptr %s4, { i64, ptr } %t258, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t260, ptr %l126
  br label %bb42
bb41:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb43
bb42:
  %t261 = load i1, ptr %l126, !tbaa !21
  store i1 %t261, ptr %l124, !tbaa !21
  br label %bb43
bb43:
  %t262 = load i1, ptr %l124, !tbaa !21
  br i1 %t262, label %bb44, label %bb45
bb44:
  %t263 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t271 = sub i64 %t265, %t268
  store i64 %t271, ptr %l131, !tbaa !24
  %t272 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  store i64 %t273, ptr %l132, !tbaa !24
  %t274 = icmp sge i64 0, 0
  br i1 %t274, label %bb46, label %bb47
bb45:
  store %olang.scope zeroinitializer, ptr %s7
  %t276 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t277 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t280 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s4, { i64, ptr } %t276, { i64, ptr } %t277)
  store i1 %t280, ptr %l151
  br label %bb61
bb46:
  %t281 = load i64, ptr %l131, !tbaa !24
  %t282 = icmp sle i64 0, %t281
  br i1 %t282, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb48:
  %t284 = load i64, ptr %l131, !tbaa !24
  %t285 = load i64, ptr %l132, !tbaa !24
  %t286 = icmp sle i64 %t284, %t285
  br i1 %t286, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb50:
  %t288 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = load i64, ptr %l131, !tbaa !24
  %t291 = getelementptr i8, ptr %t289, i64 0
  %t292 = sub i64 %t290, 0
  %t293 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t291, 1
  store { i64, ptr } %t294, ptr %l136, !tbaa !27
  %t295 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t295, 0
  store i64 %t297, ptr %l138, !tbaa !24
  %t298 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t298, 0
  store i64 %t299, ptr %l139, !tbaa !24
  %t300 = icmp sge i64 9, 0
  br i1 %t300, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb52:
  %t302 = load i64, ptr %l138, !tbaa !24
  %t303 = icmp sle i64 9, %t302
  br i1 %t303, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb54:
  %t305 = load i64, ptr %l138, !tbaa !24
  %t306 = load i64, ptr %l139, !tbaa !24
  %t307 = icmp sle i64 %t305, %t306
  br i1 %t307, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb56:
  %t309 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = load i64, ptr %l138, !tbaa !24
  %t312 = getelementptr i8, ptr %t310, i64 9
  %t313 = sub i64 %t311, 9
  %t314 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t312, 1
  %t316 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t321 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t322 = add i64 %t319, %t321
  %t324 = extractvalue { i64, ptr } %t315, 1
  %t325 = extractvalue { i64, ptr } %t315, 0
  %t326 = add i64 %t322, %t325
  %t327 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t328 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t329 = add i64 %t326, %t328
  %t331 = extractvalue { i64, ptr } %t316, 1
  %t332 = extractvalue { i64, ptr } %t316, 0
  %t333 = add i64 %t329, %t332
  %t334 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t333)
  call void @olang_textcopy(ptr %t334, ptr %t318, i64 %t319)
  %t335 = getelementptr i8, ptr %t334, i64 %t319
  call void @olang_textcopy(ptr %t335, ptr %t320, i64 %t321)
  %t336 = getelementptr i8, ptr %t335, i64 %t321
  call void @olang_textcopy(ptr %t336, ptr %t324, i64 %t325)
  %t337 = getelementptr i8, ptr %t336, i64 %t325
  call void @olang_textcopy(ptr %t337, ptr %t327, i64 %t328)
  %t338 = getelementptr i8, ptr %t337, i64 %t328
  call void @olang_textcopy(ptr %t338, ptr %t331, i64 %t332)
  %t339 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t334, 1
  store { i64, ptr } %t340, ptr %l145, !tbaa !27
  %t341 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 0
  %t343 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  store i64 %t344, ptr %l147, !tbaa !24
  %t346 = load i64, ptr %l147, !tbaa !24
  %t347 = icmp eq i64 %t342, %t346
  br i1 %t347, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb58:
  %t349 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = load i64, ptr %l147, !tbaa !24
  %t354 = mul i64 %t353, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t350, ptr %t352, i64 %t354, i1 false)
  br label %bb60
bb59:
  %t355 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t355, ptr %l9, !tbaa !27
  br label %bb60
bb60:
  br label %bb141
bb61:
  %t356 = load i1, ptr %l151, !tbaa !21
  br i1 %t356, label %bb62, label %bb63
bb62:
  %t357 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t359 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s4, ptr %s7, { i64, ptr } %t357, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t359, ptr %l154
  br label %bb64
bb63:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb65
bb64:
  %t360 = load i1, ptr %l154, !tbaa !21
  store i1 %t360, ptr %l152, !tbaa !21
  br label %bb65
bb65:
  %t361 = load i1, ptr %l152, !tbaa !21
  br i1 %t361, label %bb66, label %bb67
bb66:
  %t362 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  store i64 %t364, ptr %l156, !tbaa !24
  %t365 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 0
  store i64 %t366, ptr %l157, !tbaa !24
  %t367 = icmp sge i64 13, 0
  br i1 %t367, label %bb68, label %bb69
bb67:
  br label %bb140
bb68:
  %t369 = load i64, ptr %l156, !tbaa !24
  %t370 = icmp sle i64 13, %t369
  br i1 %t370, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb70:
  %t372 = load i64, ptr %l156, !tbaa !24
  %t373 = load i64, ptr %l157, !tbaa !24
  %t374 = icmp sle i64 %t372, %t373
  br i1 %t374, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb72:
  %t376 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = load i64, ptr %l156, !tbaa !24
  %t379 = getelementptr i8, ptr %t377, i64 13
  %t380 = sub i64 %t378, 13
  %t381 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t379, 1
  store { i64, ptr } %t382, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t384 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t384, 0
  %t388 = sub i64 %t386, 1
  store i64 %t388, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t390 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t390, 0
  store i64 %t392, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t394 = load i64, ptr %l15, !tbaa !24
  %t395 = load i64, ptr %l14, !tbaa !24
  %t398 = icmp sgt i64 %t394, %t395
  br i1 %t398, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb74:
  %t400 = load i64, ptr %l16, !tbaa !24
  %t402 = icmp sgt i64 %t400, 0
  br i1 %t402, label %bb76, label %bb77
bb75:
  store i64 0, ptr %l170, !tbaa !24
  br label %bb79
bb76:
  %t404 = load i64, ptr %l15, !tbaa !24
  %t405 = load i64, ptr %l14, !tbaa !24
  %t408 = sub i64 %t404, %t405
  %t409 = load i64, ptr %l16, !tbaa !24
  %t412 = add i64 %t408, %t409
  %t414 = sub i64 %t412, 1
  %t415 = load i64, ptr %l16, !tbaa !24
  %t418 = sdiv i64 %t414, %t415
  store i64 %t418, ptr %l173, !tbaa !24
  br label %bb78
bb77:
  store i64 0, ptr %l173, !tbaa !24
  br label %bb78
bb78:
  %t420 = load i64, ptr %l173, !tbaa !24
  store i64 %t420, ptr %l170, !tbaa !24
  br label %bb79
bb79:
  %t421 = load i64, ptr %l170, !tbaa !24
  store i64 %t421, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb80
bb80:
  %t422 = load i64, ptr %l18, !tbaa !24
  %t423 = load i64, ptr %l17, !tbaa !24
  %t426 = icmp slt i64 %t422, %t423
  %t428 = xor i1 %t426, true
  br i1 %t428, label %bb81, label %bb82
bb81:
  br label %bb118
bb82:
  br label %bb83
bb83:
  %t430 = load i64, ptr %l14, !tbaa !24
  %t431 = load i64, ptr %l18, !tbaa !24
  %t432 = load i64, ptr %l16, !tbaa !24
  %t435 = mul i64 %t431, %t432
  %t438 = add i64 %t430, %t435
  store i64 %t438, ptr %l19, !tbaa !24
  %t440 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t440, ptr %l191, !tbaa !27
  %t441 = load i64, ptr %l19, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr i8, ptr %t444, i64 %t441
  %t446 = load i8, ptr %t445, !tbaa !32
  store i8 %t446, ptr %l20, !tbaa !22
  %t448 = load i8, ptr %l20, !tbaa !22
  %t450 = icmp eq i8 %t448, 60
  br i1 %t450, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l196, !tbaa !21
  br label %bb86
bb85:
  %t452 = load i8, ptr %l20, !tbaa !22
  %t454 = icmp eq i8 %t452, 40
  store i1 %t454, ptr %l196, !tbaa !21
  br label %bb86
bb86:
  %t456 = load i1, ptr %l196, !tbaa !21
  br i1 %t456, label %bb87, label %bb88
bb87:
  %t457 = load i64, ptr %l12, !tbaa !24
  %t459 = add i64 %t457, 1
  store i64 %t459, ptr %l12, !tbaa !24
  br label %bb89
bb88:
  br label %bb89
bb89:
  %t461 = load i8, ptr %l20, !tbaa !22
  %t463 = icmp eq i8 %t461, 62
  br i1 %t463, label %bb90, label %bb91
bb90:
  store i1 true, ptr %l203, !tbaa !21
  br label %bb92
bb91:
  %t465 = load i8, ptr %l20, !tbaa !22
  %t467 = icmp eq i8 %t465, 41
  store i1 %t467, ptr %l203, !tbaa !21
  br label %bb92
bb92:
  %t469 = load i1, ptr %l203, !tbaa !21
  br i1 %t469, label %bb93, label %bb94
bb93:
  %t470 = load i64, ptr %l12, !tbaa !24
  %t472 = icmp sgt i64 %t470, 0
  store i1 %t472, ptr %l206, !tbaa !21
  br label %bb95
bb94:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb95
bb95:
  %t474 = load i1, ptr %l206, !tbaa !21
  br i1 %t474, label %bb96, label %bb97
bb96:
  %t475 = load i64, ptr %l12, !tbaa !24
  %t477 = sub i64 %t475, 1
  store i64 %t477, ptr %l12, !tbaa !24
  br label %bb117
bb97:
  br label %bb98
bb98:
  %t479 = load i64, ptr %l12, !tbaa !24
  %t481 = icmp eq i64 %t479, 0
  br i1 %t481, label %bb99, label %bb100
bb99:
  %t483 = load i8, ptr %l20, !tbaa !22
  %t485 = icmp eq i8 %t483, 62
  br i1 %t485, label %bb101, label %bb102
bb100:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb113
bb101:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb103
bb102:
  %t487 = load i8, ptr %l20, !tbaa !22
  %t489 = icmp eq i8 %t487, 44
  store i1 %t489, ptr %l216, !tbaa !21
  br label %bb103
bb103:
  %t491 = load i1, ptr %l216, !tbaa !21
  br i1 %t491, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l219, !tbaa !21
  br label %bb112
bb105:
  %t492 = load i8, ptr %l20, !tbaa !22
  %t494 = icmp eq i8 %t492, 32
  br i1 %t494, label %bb106, label %bb107
bb106:
  %t496 = load i64, ptr %l19, !tbaa !24
  %t498 = add i64 %t496, 1
  %t499 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t501 = extractvalue { i64, ptr } %t499, 0
  %t504 = icmp slt i64 %t498, %t501
  store i1 %t504, ptr %l222, !tbaa !21
  br label %bb108
bb107:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb108
bb108:
  %t506 = load i1, ptr %l222, !tbaa !21
  br i1 %t506, label %bb109, label %bb110
bb109:
  %t507 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t507, ptr %l229, !tbaa !27
  %t508 = load i64, ptr %l19, !tbaa !24
  %t510 = add i64 %t508, 1
  %t512 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t513 = load ptr, ptr %t512, !tbaa !27
  %t514 = getelementptr i8, ptr %t513, i64 %t510
  %t515 = load i8, ptr %t514, !tbaa !32
  %t517 = icmp eq i8 %t515, 63
  store i1 %t517, ptr %l228, !tbaa !21
  br label %bb111
bb110:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb111
bb111:
  %t519 = load i1, ptr %l228, !tbaa !21
  store i1 %t519, ptr %l219, !tbaa !21
  br label %bb112
bb112:
  %t520 = load i1, ptr %l219, !tbaa !21
  store i1 %t520, ptr %l213, !tbaa !21
  br label %bb113
bb113:
  %t521 = load i1, ptr %l213, !tbaa !21
  br i1 %t521, label %bb114, label %bb115
bb114:
  %t522 = load i64, ptr %l19, !tbaa !24
  store i64 %t522, ptr %l13, !tbaa !24
  br label %bb118
bb115:
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t524 = load i64, ptr %l18, !tbaa !24
  %t526 = add i64 %t524, 1
  store i64 %t526, ptr %l18, !tbaa !24
  br label %bb80
bb118:
  %t528 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t530 = extractvalue { i64, ptr } %t528, 0
  %t531 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t531, 0
  %t536 = sub i64 %t530, %t533
  store i64 %t536, ptr %l241, !tbaa !24
  %t537 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t538 = extractvalue { i64, ptr } %t537, 0
  store i64 %t538, ptr %l242, !tbaa !24
  %t539 = icmp sge i64 0, 0
  br i1 %t539, label %bb119, label %bb120
bb119:
  %t541 = load i64, ptr %l241, !tbaa !24
  %t542 = icmp sle i64 0, %t541
  br i1 %t542, label %bb121, label %bb122
bb120:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb121:
  %t544 = load i64, ptr %l241, !tbaa !24
  %t545 = load i64, ptr %l242, !tbaa !24
  %t546 = icmp sle i64 %t544, %t545
  br i1 %t546, label %bb123, label %bb124
bb122:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb123:
  %t548 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = load i64, ptr %l241, !tbaa !24
  %t551 = getelementptr i8, ptr %t549, i64 0
  %t552 = sub i64 %t550, 0
  %t553 = insertvalue { i64, ptr } undef, i64 %t552, 0
  %t554 = insertvalue { i64, ptr } %t553, ptr %t551, 1
  store { i64, ptr } %t554, ptr %l246, !tbaa !27
  %t555 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t555, ptr %l247, !tbaa !27
  %t556 = load i64, ptr %l13, !tbaa !24
  store i64 %t556, ptr %l248, !tbaa !24
  %t557 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t558 = extractvalue { i64, ptr } %t557, 0
  store i64 %t558, ptr %l249, !tbaa !24
  %t559 = icmp sge i64 0, 0
  br i1 %t559, label %bb125, label %bb126
bb124:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb125:
  %t561 = load i64, ptr %l248, !tbaa !24
  %t562 = icmp sle i64 0, %t561
  br i1 %t562, label %bb127, label %bb128
bb126:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb127:
  %t564 = load i64, ptr %l248, !tbaa !24
  %t565 = load i64, ptr %l249, !tbaa !24
  %t566 = icmp sle i64 %t564, %t565
  br i1 %t566, label %bb129, label %bb130
bb128:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb129:
  %t568 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t569 = load ptr, ptr %t568, !tbaa !27
  %t570 = load i64, ptr %l248, !tbaa !24
  %t571 = getelementptr i8, ptr %t569, i64 0
  %t572 = sub i64 %t570, 0
  %t573 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t571, 1
  store { i64, ptr } %t574, ptr %l253, !tbaa !27
  %t575 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t575, ptr %l254, !tbaa !27
  %t576 = load i64, ptr %l13, !tbaa !24
  store i64 %t576, ptr %l255, !tbaa !24
  %t577 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t577, 0
  store i64 %t580, ptr %l258, !tbaa !24
  %t581 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t582 = extractvalue { i64, ptr } %t581, 0
  store i64 %t582, ptr %l259, !tbaa !24
  %t583 = load i64, ptr %l255, !tbaa !24
  %t584 = icmp sge i64 %t583, 0
  br i1 %t584, label %bb131, label %bb132
bb130:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb131:
  %t586 = load i64, ptr %l255, !tbaa !24
  %t587 = load i64, ptr %l258, !tbaa !24
  %t588 = icmp sle i64 %t586, %t587
  br i1 %t588, label %bb133, label %bb134
bb132:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb133:
  %t590 = load i64, ptr %l258, !tbaa !24
  %t591 = load i64, ptr %l259, !tbaa !24
  %t592 = icmp sle i64 %t590, %t591
  br i1 %t592, label %bb135, label %bb136
bb134:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb135:
  %t594 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t595 = load ptr, ptr %t594, !tbaa !27
  %t596 = load i64, ptr %l255, !tbaa !24
  %t597 = load i64, ptr %l258, !tbaa !24
  %t598 = getelementptr i8, ptr %t595, i64 %t596
  %t599 = sub i64 %t597, %t596
  %t600 = insertvalue { i64, ptr } undef, i64 %t599, 0
  %t601 = insertvalue { i64, ptr } %t600, ptr %t598, 1
  %t602 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t603 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t604 = extractvalue { i64, ptr } %t603, 1
  %t605 = extractvalue { i64, ptr } %t603, 0
  %t606 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t607 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t608 = add i64 %t605, %t607
  %t609 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t610 = extractvalue { i64, ptr } %t609, 1
  %t611 = extractvalue { i64, ptr } %t609, 0
  %t612 = add i64 %t608, %t611
  %t613 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t614 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t615 = add i64 %t612, %t614
  %t617 = extractvalue { i64, ptr } %t601, 1
  %t618 = extractvalue { i64, ptr } %t601, 0
  %t619 = add i64 %t615, %t618
  %t620 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t621 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t622 = add i64 %t619, %t621
  %t624 = extractvalue { i64, ptr } %t602, 1
  %t625 = extractvalue { i64, ptr } %t602, 0
  %t626 = add i64 %t622, %t625
  %t627 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t626)
  call void @olang_textcopy(ptr %t627, ptr %t604, i64 %t605)
  %t628 = getelementptr i8, ptr %t627, i64 %t605
  call void @olang_textcopy(ptr %t628, ptr %t606, i64 %t607)
  %t629 = getelementptr i8, ptr %t628, i64 %t607
  call void @olang_textcopy(ptr %t629, ptr %t610, i64 %t611)
  %t630 = getelementptr i8, ptr %t629, i64 %t611
  call void @olang_textcopy(ptr %t630, ptr %t613, i64 %t614)
  %t631 = getelementptr i8, ptr %t630, i64 %t614
  call void @olang_textcopy(ptr %t631, ptr %t617, i64 %t618)
  %t632 = getelementptr i8, ptr %t631, i64 %t618
  call void @olang_textcopy(ptr %t632, ptr %t620, i64 %t621)
  %t633 = getelementptr i8, ptr %t632, i64 %t621
  call void @olang_textcopy(ptr %t633, ptr %t624, i64 %t625)
  %t634 = insertvalue { i64, ptr } undef, i64 %t626, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t627, 1
  store { i64, ptr } %t635, ptr %l265, !tbaa !27
  %t636 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t637 = extractvalue { i64, ptr } %t636, 0
  %t638 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t639 = extractvalue { i64, ptr } %t638, 0
  store i64 %t639, ptr %l267, !tbaa !24
  %t641 = load i64, ptr %l267, !tbaa !24
  %t642 = icmp eq i64 %t637, %t641
  br i1 %t642, label %bb137, label %bb138
bb136:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb137:
  %t644 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t645 = load ptr, ptr %t644, !tbaa !27
  %t646 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t647 = load ptr, ptr %t646, !tbaa !27
  %t648 = load i64, ptr %l267, !tbaa !24
  %t649 = mul i64 %t648, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t645, ptr %t647, i64 %t649, i1 false)
  br label %bb139
bb138:
  %t650 = load { i64, ptr }, ptr %l265, !tbaa !27
  store { i64, ptr } %t650, ptr %l9, !tbaa !27
  br label %bb139
bb139:
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s7)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s4)
  br label %bb142
bb142:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/check:Checker", ptr %t651, i32 0, i32 1
  %t654 = load ptr, ptr %t653, !tbaa !29
  %t655 = load i64, ptr %l1, !tbaa !24
  %t658 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t654, i64 %t655)
  store i1 %t658, ptr %l272
  br label %bb143
bb143:
  %t659 = load i1, ptr %l272, !tbaa !21
  br i1 %t659, label %bb144, label %bb145
bb144:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l273, !tbaa !27
  br label %bb146
bb145:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l273, !tbaa !27
  br label %bb146
bb146:
  %t660 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t660, ptr %l21, !tbaa !27
  %t661 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t663 = call i64 @compiler_2fexplain_2efirstClose(ptr %s0, { i64, ptr } %t661)
  store i64 %t663, ptr %l275
  br label %bb147
bb147:
  %t664 = load i64, ptr %l275, !tbaa !24
  store i64 %t664, ptr %l22, !tbaa !24
  %t665 = load ptr, ptr %l0, !tbaa !29
  store ptr %t665, ptr %l276, !tbaa !29
  %t666 = load i64, ptr %l22, !tbaa !24
  store i64 %t666, ptr %l277, !tbaa !24
  %t667 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t668 = extractvalue { i64, ptr } %t667, 0
  store i64 %t668, ptr %l278, !tbaa !24
  %t669 = icmp sge i64 3, 0
  br i1 %t669, label %bb148, label %bb149
bb148:
  %t671 = load i64, ptr %l277, !tbaa !24
  %t672 = icmp sle i64 3, %t671
  br i1 %t672, label %bb150, label %bb151
bb149:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb150:
  %t674 = load i64, ptr %l277, !tbaa !24
  %t675 = load i64, ptr %l278, !tbaa !24
  %t676 = icmp sle i64 %t674, %t675
  br i1 %t676, label %bb152, label %bb153
bb151:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb152:
  %t678 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t679 = load ptr, ptr %t678, !tbaa !27
  %t680 = load i64, ptr %l277, !tbaa !24
  %t681 = getelementptr i8, ptr %t679, i64 3
  %t682 = sub i64 %t680, 3
  %t683 = insertvalue { i64, ptr } undef, i64 %t682, 0
  %t684 = insertvalue { i64, ptr } %t683, ptr %t681, 1
  store { i64, ptr } %t684, ptr %l282, !tbaa !27
  %t685 = load ptr, ptr %l4, !tbaa !29
  %t687 = getelementptr %"compiler/ast:Func", ptr %t685, i32 0, i32 3
  %t688 = load ptr, ptr %t687, !tbaa !29
  %t690 = getelementptr %"compiler/ast:Sig", ptr %t688, i32 0, i32 0
  %t691 = load { i64, ptr }, ptr %t690, !tbaa !27
  store { i64, ptr } %t691, ptr %l285, !tbaa !27
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t694 = getelementptr %"compiler/check:Checker", ptr %t692, i32 0, i32 1
  %t695 = load ptr, ptr %t694, !tbaa !29
  %t696 = load i64, ptr %l1, !tbaa !24
  %t699 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t695, i64 %t696)
  store i64 %t699, ptr %l289
  br label %bb154
bb153:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb154:
  %t700 = load ptr, ptr %l4, !tbaa !29
  %t702 = getelementptr %"compiler/ast:Func", ptr %t700, i32 0, i32 1
  %t703 = load ptr, ptr %t702, !tbaa !29
  %t705 = icmp eq ptr %t703, null
  %t707 = xor i1 %t705, true
  br i1 %t707, label %bb155, label %bb156
bb155:
  store i64 1, ptr %l294, !tbaa !24
  br label %bb157
bb156:
  store i64 0, ptr %l294, !tbaa !24
  br label %bb157
bb157:
  %t709 = load ptr, ptr %l276, !tbaa !29
  %t710 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t711 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t712 = load i64, ptr %l289, !tbaa !24
  %t713 = load i64, ptr %l294, !tbaa !24
  %t714 = call { i64, ptr } @compiler_2fexplain_2ewithDefaults(ptr %v0, ptr %s0, ptr %v0, ptr %s0, ptr %t709, { i64, ptr } %t710, { i64, ptr } %t711, i64 %t712, i64 %t713)
  store { i64, ptr } %t714, ptr %l295
  br label %bb158
bb158:
  %t715 = load i64, ptr %l22, !tbaa !24
  store i64 %t715, ptr %l296, !tbaa !24
  %t716 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t718 = extractvalue { i64, ptr } %t716, 0
  store i64 %t718, ptr %l298, !tbaa !24
  %t719 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t720 = extractvalue { i64, ptr } %t719, 0
  store i64 %t720, ptr %l299, !tbaa !24
  %t721 = load i64, ptr %l296, !tbaa !24
  %t722 = icmp sge i64 %t721, 0
  br i1 %t722, label %bb159, label %bb160
bb159:
  %t724 = load i64, ptr %l296, !tbaa !24
  %t725 = load i64, ptr %l298, !tbaa !24
  %t726 = icmp sle i64 %t724, %t725
  br i1 %t726, label %bb161, label %bb162
bb160:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb161:
  %t728 = load i64, ptr %l298, !tbaa !24
  %t729 = load i64, ptr %l299, !tbaa !24
  %t730 = icmp sle i64 %t728, %t729
  br i1 %t730, label %bb163, label %bb164
bb162:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb163:
  %t732 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t733 = load ptr, ptr %t732, !tbaa !27
  %t734 = load i64, ptr %l296, !tbaa !24
  %t735 = load i64, ptr %l298, !tbaa !24
  %t736 = getelementptr i8, ptr %t733, i64 %t734
  %t737 = sub i64 %t735, %t734
  %t738 = insertvalue { i64, ptr } undef, i64 %t737, 0
  %t739 = insertvalue { i64, ptr } %t738, ptr %t736, 1
  %t740 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t741 = extractvalue { i64, ptr } %t740, 1
  %t742 = extractvalue { i64, ptr } %t740, 0
  %t744 = extractvalue { i64, ptr } %t739, 1
  %t745 = extractvalue { i64, ptr } %t739, 0
  %t746 = add i64 %t742, %t745
  %t747 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t746)
  call void @olang_textcopy(ptr %t747, ptr %t741, i64 %t742)
  %t748 = getelementptr i8, ptr %t747, i64 %t742
  call void @olang_textcopy(ptr %t748, ptr %t744, i64 %t745)
  %t749 = insertvalue { i64, ptr } undef, i64 %t746, 0
  %t750 = insertvalue { i64, ptr } %t749, ptr %t747, 1
  store { i64, ptr } %t750, ptr %l23, !tbaa !27
  %t752 = load ptr, ptr %l4, !tbaa !29
  %t754 = getelementptr %"compiler/ast:Func", ptr %t752, i32 0, i32 1
  %t755 = load ptr, ptr %t754, !tbaa !29
  %t757 = icmp eq ptr %t755, null
  br i1 %t757, label %bb165, label %bb166
bb164:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb165:
  %t759 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t760 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t761 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t763 = extractvalue { i64, ptr } %t759, 1
  %t764 = extractvalue { i64, ptr } %t759, 0
  %t766 = extractvalue { i64, ptr } %t760, 1
  %t767 = extractvalue { i64, ptr } %t760, 0
  %t768 = add i64 %t764, %t767
  %t769 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t770 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t771 = add i64 %t768, %t770
  %t773 = extractvalue { i64, ptr } %t761, 1
  %t774 = extractvalue { i64, ptr } %t761, 0
  %t775 = add i64 %t771, %t774
  %t776 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t775)
  call void @olang_textcopy(ptr %t776, ptr %t763, i64 %t764)
  %t777 = getelementptr i8, ptr %t776, i64 %t764
  call void @olang_textcopy(ptr %t777, ptr %t766, i64 %t767)
  %t778 = getelementptr i8, ptr %t777, i64 %t767
  call void @olang_textcopy(ptr %t778, ptr %t769, i64 %t770)
  %t779 = getelementptr i8, ptr %t778, i64 %t770
  call void @olang_textcopy(ptr %t779, ptr %t773, i64 %t774)
  %t780 = insertvalue { i64, ptr } undef, i64 %t775, 0
  %t781 = insertvalue { i64, ptr } %t780, ptr %t776, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t781, ptr %rv
  br label %ret
bb166:
  br label %bb167
bb167:
  %t783 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t785 = call i64 @compiler_2fexplain_2efirstItemEnd(ptr %s0, { i64, ptr } %t783)
  store i64 %t785, ptr %l313
  br label %bb168
bb168:
  %t786 = load i64, ptr %l313, !tbaa !24
  store i64 %t786, ptr %l24, !tbaa !24
  %t787 = load i64, ptr %l24, !tbaa !24
  store i64 %t787, ptr %l314, !tbaa !24
  %t788 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t789 = extractvalue { i64, ptr } %t788, 0
  store i64 %t789, ptr %l315, !tbaa !24
  %t790 = icmp sge i64 0, 0
  br i1 %t790, label %bb169, label %bb170
bb169:
  %t792 = load i64, ptr %l314, !tbaa !24
  %t793 = icmp sle i64 0, %t792
  br i1 %t793, label %bb171, label %bb172
bb170:
  call void @__olang_check_failed(ptr @olang_loc_87334f8237d1e26_d87acd2b8515436a)
  unreachable
bb171:
  %t795 = load i64, ptr %l314, !tbaa !24
  %t796 = load i64, ptr %l315, !tbaa !24
  %t797 = icmp sle i64 %t795, %t796
  br i1 %t797, label %bb173, label %bb174
bb172:
  call void @__olang_check_failed(ptr @olang_loc_87334f8237d1e26_d87acd2b8515436a)
  unreachable
bb173:
  %t799 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t800 = load ptr, ptr %t799, !tbaa !27
  %t801 = load i64, ptr %l314, !tbaa !24
  %t802 = getelementptr i8, ptr %t800, i64 0
  %t803 = sub i64 %t801, 0
  %t804 = insertvalue { i64, ptr } undef, i64 %t803, 0
  %t805 = insertvalue { i64, ptr } %t804, ptr %t802, 1
  store { i64, ptr } %t805, ptr %l25, !tbaa !27
  %t807 = load i64, ptr %l24, !tbaa !24
  %t809 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t810 = load ptr, ptr %t809, !tbaa !27
  %t811 = getelementptr i8, ptr %t810, i64 %t807
  %t812 = load i8, ptr %t811, !tbaa !32
  %t814 = icmp eq i8 %t812, 44
  br i1 %t814, label %bb175, label %bb176
bb174:
  call void @__olang_check_failed(ptr @olang_loc_87334f8237d1e26_d87acd2b8515436a)
  unreachable
bb175:
  %t816 = load i64, ptr %l24, !tbaa !24
  %t818 = add i64 %t816, 2
  store i64 %t818, ptr %l325, !tbaa !24
  %t819 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t821 = extractvalue { i64, ptr } %t819, 0
  store i64 %t821, ptr %l327, !tbaa !24
  %t822 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t823 = extractvalue { i64, ptr } %t822, 0
  store i64 %t823, ptr %l328, !tbaa !24
  %t824 = load i64, ptr %l325, !tbaa !24
  %t825 = icmp sge i64 %t824, 0
  br i1 %t825, label %bb177, label %bb178
bb176:
  %t827 = load i64, ptr %l24, !tbaa !24
  store i64 %t827, ptr %l333, !tbaa !24
  %t828 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t830 = extractvalue { i64, ptr } %t828, 0
  store i64 %t830, ptr %l335, !tbaa !24
  %t831 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t832 = extractvalue { i64, ptr } %t831, 0
  store i64 %t832, ptr %l336, !tbaa !24
  %t833 = load i64, ptr %l333, !tbaa !24
  %t834 = icmp sge i64 %t833, 0
  br i1 %t834, label %bb183, label %bb184
bb177:
  %t836 = load i64, ptr %l325, !tbaa !24
  %t837 = load i64, ptr %l327, !tbaa !24
  %t838 = icmp sle i64 %t836, %t837
  br i1 %t838, label %bb179, label %bb180
bb178:
  call void @__olang_check_failed(ptr @olang_loc_96b8876366bd9a81_fe1335b03e31611d)
  unreachable
bb179:
  %t840 = load i64, ptr %l327, !tbaa !24
  %t841 = load i64, ptr %l328, !tbaa !24
  %t842 = icmp sle i64 %t840, %t841
  br i1 %t842, label %bb181, label %bb182
bb180:
  call void @__olang_check_failed(ptr @olang_loc_96b8876366bd9a81_fe1335b03e31611d)
  unreachable
bb181:
  %t844 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t845 = load ptr, ptr %t844, !tbaa !27
  %t846 = load i64, ptr %l325, !tbaa !24
  %t847 = load i64, ptr %l327, !tbaa !24
  %t848 = getelementptr i8, ptr %t845, i64 %t846
  %t849 = sub i64 %t847, %t846
  %t850 = insertvalue { i64, ptr } undef, i64 %t849, 0
  %t851 = insertvalue { i64, ptr } %t850, ptr %t848, 1
  store { i64, ptr } %t851, ptr %l323, !tbaa !27
  br label %bb189
bb182:
  call void @__olang_check_failed(ptr @olang_loc_96b8876366bd9a81_fe1335b03e31611d)
  unreachable
bb183:
  %t853 = load i64, ptr %l333, !tbaa !24
  %t854 = load i64, ptr %l335, !tbaa !24
  %t855 = icmp sle i64 %t853, %t854
  br i1 %t855, label %bb185, label %bb186
bb184:
  call void @__olang_check_failed(ptr @olang_loc_96b8876366bd9a81_fe1335b03e31611d)
  unreachable
bb185:
  %t857 = load i64, ptr %l335, !tbaa !24
  %t858 = load i64, ptr %l336, !tbaa !24
  %t859 = icmp sle i64 %t857, %t858
  br i1 %t859, label %bb187, label %bb188
bb186:
  call void @__olang_check_failed(ptr @olang_loc_96b8876366bd9a81_fe1335b03e31611d)
  unreachable
bb187:
  %t861 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t862 = load ptr, ptr %t861, !tbaa !27
  %t863 = load i64, ptr %l333, !tbaa !24
  %t864 = load i64, ptr %l335, !tbaa !24
  %t865 = getelementptr i8, ptr %t862, i64 %t863
  %t866 = sub i64 %t864, %t863
  %t867 = insertvalue { i64, ptr } undef, i64 %t866, 0
  %t868 = insertvalue { i64, ptr } %t867, ptr %t865, 1
  store { i64, ptr } %t868, ptr %l323, !tbaa !27
  br label %bb189
bb188:
  call void @__olang_check_failed(ptr @olang_loc_96b8876366bd9a81_fe1335b03e31611d)
  unreachable
bb189:
  %t870 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t871 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t872 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t873 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t876 = extractvalue { i64, ptr } %t871, 1
  %t877 = extractvalue { i64, ptr } %t871, 0
  %t878 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t879 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t880 = add i64 %t877, %t879
  %t882 = extractvalue { i64, ptr } %t872, 1
  %t883 = extractvalue { i64, ptr } %t872, 0
  %t884 = add i64 %t880, %t883
  %t885 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t886 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t887 = add i64 %t884, %t886
  %t889 = extractvalue { i64, ptr } %t873, 1
  %t890 = extractvalue { i64, ptr } %t873, 0
  %t891 = add i64 %t887, %t890
  %t892 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t893 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t894 = add i64 %t891, %t893
  %t896 = extractvalue { i64, ptr } %t870, 1
  %t897 = extractvalue { i64, ptr } %t870, 0
  %t898 = add i64 %t894, %t897
  %t899 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t898)
  call void @olang_textcopy(ptr %t899, ptr %t876, i64 %t877)
  %t900 = getelementptr i8, ptr %t899, i64 %t877
  call void @olang_textcopy(ptr %t900, ptr %t878, i64 %t879)
  %t901 = getelementptr i8, ptr %t900, i64 %t879
  call void @olang_textcopy(ptr %t901, ptr %t882, i64 %t883)
  %t902 = getelementptr i8, ptr %t901, i64 %t883
  call void @olang_textcopy(ptr %t902, ptr %t885, i64 %t886)
  %t903 = getelementptr i8, ptr %t902, i64 %t886
  call void @olang_textcopy(ptr %t903, ptr %t889, i64 %t890)
  %t904 = getelementptr i8, ptr %t903, i64 %t890
  call void @olang_textcopy(ptr %t904, ptr %t892, i64 %t893)
  %t905 = getelementptr i8, ptr %t904, i64 %t893
  call void @olang_textcopy(ptr %t905, ptr %t896, i64 %t897)
  %t906 = insertvalue { i64, ptr } undef, i64 %t898, 0
  %t907 = insertvalue { i64, ptr } %t906, ptr %t899, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t907, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fexplain_2efnNamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/names:Entry"
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l44 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca i64
  %l69 = alloca ptr
  %l73 = alloca i32
  %l75 = alloca i64
  %l78 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l84 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i32
  %l99 = alloca ptr
  %l102 = alloca i64
  %l104 = alloca i64
  %l109 = alloca %"compiler/names:Entry"
  %l113 = alloca i1
  %l120 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l3, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) })
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l19
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb2, label %ok.18, !prof !99
ok.18:
  store i64 %t15, ptr %l18
  br label %bb1
bb1:
  %t19 = load i64, ptr %l18, !tbaa !24
  store i64 %t19, ptr %l16, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l16, !tbaa !24
  br label %bb4
bb4:
  %t20 = load i64, ptr %l16, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l22, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l23, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l24, !tbaa !27
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l25, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l26, !tbaa !24
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb7, label %bb8
bb6:
  br label %bb48
bb7:
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = icmp sle i64 0, %t33
  br i1 %t34, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_83191eb44b7384_f52b74cb91a30b30)
  unreachable
bb9:
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_83191eb44b7384_f52b74cb91a30b30)
  unreachable
bb11:
  %t40 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = getelementptr i8, ptr %t41, i64 0
  %t44 = sub i64 %t42, 0
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = load i64, ptr %l23, !tbaa !24
  %t50 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v1, ptr %t47, i64 %t48, { i64, ptr } %t46)
  store i32 %t50, ptr %l31
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_83191eb44b7384_f52b74cb91a30b30)
  unreachable
bb13:
  %t51 = load i32, ptr %l31, !tbaa !23
  store i32 %t51, ptr %l5, !tbaa !23
  %t52 = load ptr, ptr %l3, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t53, ptr %l33, !tbaa !27
  %t54 = load i64, ptr %l4, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l35, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t57, 0
  store i64 %t60, ptr %l38, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l39, !tbaa !24
  %t63 = load i64, ptr %l35, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t66 = load i64, ptr %l35, !tbaa !24
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = icmp sle i64 %t66, %t67
  br i1 %t68, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_b6495ab5ccd815f1_8b49adc496fcf80d)
  unreachable
bb16:
  %t70 = load i64, ptr %l38, !tbaa !24
  %t71 = load i64, ptr %l39, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b6495ab5ccd815f1_8b49adc496fcf80d)
  unreachable
bb18:
  %t74 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l35, !tbaa !24
  %t77 = load i64, ptr %l38, !tbaa !24
  %t78 = getelementptr i8, ptr %t75, i64 %t76
  %t79 = sub i64 %t77, %t76
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  %t82 = load ptr, ptr %l32, !tbaa !29
  %t84 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t82, { i64, ptr } %t81)
  store i32 %t84, ptr %l44
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_b6495ab5ccd815f1_8b49adc496fcf80d)
  unreachable
bb20:
  %t85 = load i32, ptr %l44, !tbaa !23
  store i32 %t85, ptr %l6, !tbaa !23
  %t86 = load i32, ptr %l5, !tbaa !23
  %t88 = icmp slt i32 %t86, 0
  br i1 %t88, label %bb21, label %bb22
bb21:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l47, !tbaa !29
  %t91 = load i64, ptr %l1, !tbaa !24
  store i64 %t91, ptr %l48, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l49, !tbaa !27
  %t93 = load i64, ptr %l4, !tbaa !24
  store i64 %t93, ptr %l50, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l51, !tbaa !24
  %t96 = icmp sge i64 0, 0
  br i1 %t96, label %bb23, label %bb24
bb22:
  br label %bb30
bb23:
  %t98 = load i64, ptr %l50, !tbaa !24
  %t99 = icmp sle i64 0, %t98
  br i1 %t99, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f77a02592a0a9372_4ac4ccf0828b43ae)
  unreachable
bb25:
  %t101 = load i64, ptr %l50, !tbaa !24
  %t102 = load i64, ptr %l51, !tbaa !24
  %t103 = icmp sle i64 %t101, %t102
  br i1 %t103, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f77a02592a0a9372_4ac4ccf0828b43ae)
  unreachable
bb27:
  %t105 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l50, !tbaa !24
  %t108 = getelementptr i8, ptr %t106, i64 0
  %t109 = sub i64 %t107, 0
  %t110 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  %t112 = load i32, ptr %l6, !tbaa !23
  %t113 = load ptr, ptr %l47, !tbaa !29
  %t114 = load i64, ptr %l48, !tbaa !24
  %t117 = call i64 @compiler_2fexplain_2ewrittenMethod(ptr %v0, ptr %v1, ptr %t113, i64 %t114, { i64, ptr } %t111, i32 %t112)
  store i64 %t117, ptr %l57
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f77a02592a0a9372_4ac4ccf0828b43ae)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t118 = load i64, ptr %l57, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
bb30:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  store ptr %t122, ptr %l59, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t127 = load i32, ptr %l5, !tbaa !23
  %t130 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t126, i32 %t127)
  store i32 %t130, ptr %l63
  br label %bb31
bb31:
  %t131 = load i32, ptr %l6, !tbaa !23
  %t132 = load ptr, ptr %l59, !tbaa !29
  %t133 = load i32, ptr %l63, !tbaa !23
  %t135 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t132, i32 %t133, i32 %t131)
  store i64 %t135, ptr %l65
  br label %bb32
bb32:
  %t136 = load i64, ptr %l65, !tbaa !24
  store i64 %t136, ptr %l7, !tbaa !24
  %t137 = load i64, ptr %l7, !tbaa !24
  %t139 = icmp slt i64 %t137, 0
  br i1 %t139, label %bb33, label %bb34
bb33:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  store ptr %t144, ptr %l69, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t149 = load i32, ptr %l5, !tbaa !23
  %t152 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l73
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t153 = load i32, ptr %l6, !tbaa !23
  %t154 = load ptr, ptr %l69, !tbaa !29
  %t155 = load i32, ptr %l73, !tbaa !23
  %t157 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t154, i32 %t155, i32 %t153, i1 true)
  store i64 %t157, ptr %l75
  br label %bb36
bb36:
  %t158 = load i64, ptr %l75, !tbaa !24
  store i64 %t158, ptr %l7, !tbaa !24
  br label %bb37
bb37:
  %t159 = load i64, ptr %l7, !tbaa !24
  %t161 = icmp sge i64 %t159, 0
  br i1 %t161, label %bb38, label %bb39
bb38:
  %t163 = load i64, ptr %l7, !tbaa !24
  store i64 %t163, ptr %l78, !tbaa !24
  br label %bb47
bb39:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l80, !tbaa !29
  %t166 = load i64, ptr %l1, !tbaa !24
  store i64 %t166, ptr %l81, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t167, ptr %l82, !tbaa !27
  %t168 = load i64, ptr %l4, !tbaa !24
  store i64 %t168, ptr %l83, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 0
  store i64 %t170, ptr %l84, !tbaa !24
  %t171 = icmp sge i64 0, 0
  br i1 %t171, label %bb40, label %bb41
bb40:
  %t173 = load i64, ptr %l83, !tbaa !24
  %t174 = icmp sle i64 0, %t173
  br i1 %t174, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_85b05f6e7a1e78ef_648f77bc98c82cab)
  unreachable
bb42:
  %t176 = load i64, ptr %l83, !tbaa !24
  %t177 = load i64, ptr %l84, !tbaa !24
  %t178 = icmp sle i64 %t176, %t177
  br i1 %t178, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_85b05f6e7a1e78ef_648f77bc98c82cab)
  unreachable
bb44:
  %t180 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = load i64, ptr %l83, !tbaa !24
  %t183 = getelementptr i8, ptr %t181, i64 0
  %t184 = sub i64 %t182, 0
  %t185 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t183, 1
  %t187 = load i32, ptr %l6, !tbaa !23
  %t188 = load ptr, ptr %l80, !tbaa !29
  %t189 = load i64, ptr %l81, !tbaa !24
  %t192 = call i64 @compiler_2fexplain_2ewrittenMethod(ptr %v0, ptr %v1, ptr %t188, i64 %t189, { i64, ptr } %t186, i32 %t187)
  store i64 %t192, ptr %l90
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_85b05f6e7a1e78ef_648f77bc98c82cab)
  unreachable
bb46:
  %t193 = load i64, ptr %l90, !tbaa !24
  store i64 %t193, ptr %l78, !tbaa !24
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  %t194 = load i64, ptr %l78, !tbaa !24
  store i64 %t194, ptr %rv
  br label %ret
bb48:
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t196 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t199 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t195, { i64, ptr } %t196)
  store i32 %t199, ptr %l93
  br label %bb49
bb49:
  %t200 = load i32, ptr %l93, !tbaa !23
  store i32 %t200, ptr %l8, !tbaa !23
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/check:Checker", ptr %t201, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = getelementptr %"compiler/names:Resolver", ptr %t207, i32 0, i32 1
  %t210 = load i64, ptr %l1, !tbaa !24
  %t213 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t209, i64 %t210)
  store ptr %t213, ptr %l99
  br label %bb50
bb50:
  %t214 = load ptr, ptr %l99, !tbaa !29
  %t216 = getelementptr %"compiler/names:Table", ptr %t214, i32 0, i32 0
  store ptr %t216, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb51
bb51:
  %t218 = load i64, ptr %l10, !tbaa !24
  store i64 %t218, ptr %l102, !tbaa !24
  %t219 = load ptr, ptr %l9, !tbaa !29
  %t221 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t219)
  store i64 %t221, ptr %l104
  br label %bb52
bb52:
  %t222 = load i64, ptr %l102, !tbaa !24
  %t223 = load i64, ptr %l104, !tbaa !24
  %t224 = icmp slt i64 %t222, %t223
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb53, label %bb54
bb53:
  br label %bb65
bb54:
  br label %bb55
bb55:
  %t228 = load ptr, ptr %l9, !tbaa !29
  %t229 = load i64, ptr %l10, !tbaa !24
  %t232 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t228, i64 %t229)
  store %"compiler/names:Entry" %t232, ptr %l109
  br label %bb56
bb56:
  %t233 = load %"compiler/names:Entry", ptr %l109
  store %"compiler/names:Entry" %t233, ptr %l11
  %t234 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 0
  %t235 = load i32, ptr %t234, !tbaa !23
  %t236 = load i32, ptr %l8, !tbaa !23
  %t239 = icmp eq i32 %t235, %t236
  br i1 %t239, label %bb57, label %bb58
bb57:
  %t241 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 2
  %t242 = load i32, ptr %t241, !range !{i32 0, i32 9}
  %t244 = trunc i64 3 to i32
  %t245 = icmp eq i32 %t242, %t244
  store i1 %t245, ptr %l113, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb59
bb59:
  %t247 = load i1, ptr %l113, !tbaa !21
  br i1 %t247, label %bb60, label %bb61
bb60:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/check:Checker", ptr %t248, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t252 = load i64, ptr %l1, !tbaa !24
  %t253 = load i32, ptr %l8, !tbaa !23
  %t257 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t251, i64 %t252, i32 %t253)
  store i64 %t257, ptr %l120
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_scope_close(ptr %s0)
  %t258 = load i64, ptr %l120, !tbaa !24
  store i64 %t258, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  %t259 = load i64, ptr %l10, !tbaa !24
  %t261 = add i64 %t259, 1
  store i64 %t261, ptr %l10, !tbaa !24
  br label %bb51
bb65:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, %"compiler/names:Entry" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/names:Entry"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l18 = alloca i32
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l47 = alloca i32
  %l50 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i32
  %l59 = alloca i32
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/names:Entry" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %t12, i64 %t13, i32 %t15)
  store i32 %t19, ptr %l18
  br label %bb1
bb1:
  %t20 = load i32, ptr %l18, !tbaa !23
  store i32 %t20, ptr %l5, !tbaa !23
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t21, i32 %t23)
  store { i64, ptr } %t26, ptr %l21
  br label %bb2
bb2:
  %t27 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l5, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t30, i32 %t31)
  store { i64, ptr } %t34, ptr %l26
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t36, i64 %t37)
  %t47 = getelementptr i8, ptr %t46, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = getelementptr i8, ptr %t47, i64 %t40
  call void @olang_textcopy(ptr %t48, ptr %t43, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  %t52 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = getelementptr i8, ptr %t62, i64 %t58
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 1
  %t72 = load %"compiler/source:Span", ptr %t71
  %t77 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %t67, i64 %t68, i32 %t70, %"compiler/source:Span" %t72)
  store i64 %t77, ptr %l35
  br label %bb10
bb10:
  %t78 = load i64, ptr %l35, !tbaa !24
  %t83 = call { i32, { i64, ptr } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v1, ptr %s0, ptr %a1, i64 %t78)
  %t84 = extractvalue { i32, { i64, ptr } } %t83, 1
  %t85 = extractvalue { i32, { i64, ptr } } %t83, 0
  store i32 %t85, ptr %l40
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb12, label %ok.87, !prof !99
ok.87:
  store { i64, ptr } %t84, ptr %l39
  br label %bb11
bb11:
  %t88 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t88, ptr %l36, !tbaa !27
  br label %bb14
bb12:
  br label %bb13
bb13:
  %t89 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t91, i64 %t92)
  %t97 = getelementptr i8, ptr %t96, i64 %t92
  call void @olang_textcopy(ptr %t97, ptr %t93, i64 %t94)
  %t98 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t99, ptr %rv
  br label %ret
bb14:
  %t101 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t101, ptr %l8, !tbaa !27
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l5, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l47
  br label %bb15
bb15:
  %t112 = load i32, ptr %l47, !range !{i32 0, i32 33}
  %t114 = trunc i64 20 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb16, label %bb17
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l5, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l55
  br label %bb18
bb17:
  %t127 = load i32, ptr %l5, !tbaa !23
  store i32 %t127, ptr %l50, !tbaa !23
  br label %bb19
bb18:
  %t129 = load i32, ptr %l55, !tbaa !23
  store i32 %t129, ptr %l50, !tbaa !23
  br label %bb19
bb19:
  %t130 = load i32, ptr %l50, !tbaa !23
  store i32 %t130, ptr %l57, !tbaa !23
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %t132)
  store i32 %t134, ptr %l59
  br label %bb20
bb20:
  %t135 = load i32, ptr %l57, !tbaa !23
  %t136 = load i32, ptr %l59, !tbaa !23
  %t137 = icmp eq i32 %t135, %t136
  br i1 %t137, label %bb21, label %bb22
bb21:
  %t139 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t141 = call { i64, ptr } @compiler_2fexplain_2equoted(ptr %s0, ptr %s0, { i64, ptr } %t139)
  store { i64, ptr } %t141, ptr %l63
  br label %bb23
bb22:
  %t142 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = extractvalue { i64, ptr } %t142, 0
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t144, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l61, !tbaa !27
  br label %bb24
bb23:
  %t150 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t151, i64 %t152)
  %t154 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l61, !tbaa !27
  br label %bb24
bb24:
  %t157 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t157, ptr %l10, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = load i64, ptr @G_2ecompiler_2fexplain_2eLongValue, !tbaa !24
  %t164 = icmp sgt i64 %t160, %t161
  br i1 %t164, label %bb25, label %bb26
bb25:
  %t166 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t166, ptr %l71, !tbaa !27
  %t167 = load i64, ptr @G_2ecompiler_2fexplain_2eLongValue, !tbaa !24
  store i64 %t167, ptr %l72, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  store i64 %t169, ptr %l73, !tbaa !24
  %t170 = icmp sge i64 0, 0
  br i1 %t170, label %bb27, label %bb28
bb26:
  br label %bb33
bb27:
  %t172 = load i64, ptr %l72, !tbaa !24
  %t173 = icmp sle i64 0, %t172
  br i1 %t173, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb29:
  %t175 = load i64, ptr %l72, !tbaa !24
  %t176 = load i64, ptr %l73, !tbaa !24
  %t177 = icmp sle i64 %t175, %t176
  br i1 %t177, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb31:
  %t179 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l72, !tbaa !24
  %t182 = getelementptr i8, ptr %t180, i64 0
  %t183 = sub i64 %t181, 0
  %t184 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t182, 1
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t194 = add i64 %t191, %t193
  %t196 = extractvalue { i64, ptr } %t185, 1
  %t197 = extractvalue { i64, ptr } %t185, 0
  %t198 = add i64 %t194, %t197
  %t199 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t203 = call i64 @__olang_fmt_i64(ptr null, i64 %t188)
  %t204 = add i64 %t201, %t203
  %t205 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t207 = add i64 %t204, %t206
  %t208 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t190, i64 %t191)
  %t209 = getelementptr i8, ptr %t208, i64 %t191
  call void @olang_textcopy(ptr %t209, ptr %t192, i64 %t193)
  %t210 = getelementptr i8, ptr %t209, i64 %t193
  call void @olang_textcopy(ptr %t210, ptr %t196, i64 %t197)
  %t211 = getelementptr i8, ptr %t210, i64 %t197
  call void @olang_textcopy(ptr %t211, ptr %t199, i64 %t200)
  %t212 = getelementptr i8, ptr %t211, i64 %t200
  %t213 = call i64 @__olang_fmt_i64(ptr %t212, i64 %t188)
  %t214 = getelementptr i8, ptr %t212, i64 %t203
  call void @olang_textcopy(ptr %t214, ptr %t205, i64 %t206)
  %t215 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t208, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t216, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb33:
  %t218 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t218, 1
  %t222 = extractvalue { i64, ptr } %t218, 0
  %t223 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t227 = extractvalue { i64, ptr } %t219, 1
  %t228 = extractvalue { i64, ptr } %t219, 0
  %t229 = add i64 %t225, %t228
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t221, i64 %t222)
  %t234 = getelementptr i8, ptr %t233, i64 %t222
  call void @olang_textcopy(ptr %t234, ptr %t223, i64 %t224)
  %t235 = getelementptr i8, ptr %t234, i64 %t224
  call void @olang_textcopy(ptr %t235, ptr %t227, i64 %t228)
  %t236 = getelementptr i8, ptr %t235, i64 %t228
  call void @olang_textcopy(ptr %t236, ptr %t230, i64 %t231)
  %t237 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t233, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t238, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l27 = alloca i64
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca i64
  %l32 = alloca i64
  %l40 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t26 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load i64, ptr %l19, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d78, i32 0, i32 1) })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  store ptr %l2, ptr %l22, !tbaa !29
  store { i64, ptr } %a0, ptr %l23, !tbaa !27
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l25
  br label %bb11
bb11:
  %t35 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l27, !tbaa !24
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t41 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t39)
  store %"compiler/source:Span" %t41, ptr %l29
  br label %bb12
bb12:
  %t42 = getelementptr %"compiler/source:Span", ptr %l29, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = sext i32 %t43 to i64
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l32, !tbaa !24
  %t48 = load i64, ptr %l27, !tbaa !24
  %t49 = icmp sge i64 %t48, 0
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb15:
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb17:
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l27, !tbaa !24
  %t62 = load i64, ptr %l31, !tbaa !24
  %t63 = getelementptr i8, ptr %t60, i64 %t61
  %t64 = sub i64 %t62, %t61
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t67 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t67, { i64, ptr } %t66)
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb19:
  br label %bb20
bb20:
  %t69 = load i64, ptr %l4, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l4, !tbaa !24
  br label %bb2
bb21:
  %t74 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t74, ptr %l40
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2emethods(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca i1
  %l54 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l75 = alloca i32
  %l82 = alloca i32
  %l87 = alloca i32
  %l91 = alloca i1
  %l96 = alloca i32
  %l101 = alloca i32
  %l104 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i64
  %l119 = alloca i32
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i64
  %l131 = alloca i64
  %l132 = alloca ptr
  %l133 = alloca ptr
  %l134 = alloca i64
  %l138 = alloca i32
  %l139 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v1, ptr %t4)
  br label %bb1
bb1:
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb2
bb2:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v1, ptr %v1, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l44
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l44, !tbaa !29
  store ptr %t67, ptr %l9, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v1, ptr %t78, i32 %t79, i32 %t83)
  store i64 %t87, ptr %l54
  br label %bb16
bb16:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l54, !tbaa !24
  %t91 = icmp ne i64 %t89, %t88
  store i1 %t91, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t93 = load i1, ptr %l48, !tbaa !21
  br i1 %t93, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb19:
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l59, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t105, ptr %l62, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t109, i64 %t110)
  store i32 %t113, ptr %l66
  br label %bb21
bb21:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load i32, ptr %l66, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t114, i32 %t115)
  store i32 %t116, ptr %l67
  br label %bb22
bb22:
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load i32, ptr %l67, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %s2, ptr %t117, i32 %t118)
  store { i64, ptr } %t119, ptr %l68
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t120, ptr %l69, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i32, ptr %t122, i64 0
  %t124 = load i32, ptr %t123, !tbaa !33
  store i32 %t124, ptr %l10, !tbaa !23
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l10, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l75
  br label %bb24
bb24:
  %t136 = load i32, ptr %l75, !range !{i32 0, i32 33}
  %t138 = trunc i64 20 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb25, label %bb26
bb25:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l10, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v1, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l82
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t151 = load i32, ptr %l82, !tbaa !23
  store i32 %t151, ptr %l10, !tbaa !23
  br label %bb28
bb28:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  %t158 = load i32, ptr %l10, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t157, i32 %t158)
  store i32 %t161, ptr %l87
  br label %bb29
bb29:
  %t162 = load i32, ptr %l87, !range !{i32 0, i32 33}
  %t164 = trunc i64 18 to i32
  %t165 = icmp eq i32 %t162, %t164
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb34
bb31:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/generic:Program", ptr %t172, i32 0, i32 2
  %t175 = load i32, ptr %l10, !tbaa !23
  %t178 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t174, i32 %t175)
  store i32 %t178, ptr %l96
  br label %bb32
bb32:
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l2, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l101
  br label %bb33
bb33:
  %t189 = load i32, ptr %l96, !tbaa !23
  %t190 = load i32, ptr %l101, !tbaa !23
  %t191 = icmp ne i32 %t189, %t190
  store i1 %t191, ptr %l91, !tbaa !21
  br label %bb34
bb34:
  %t193 = load i1, ptr %l91, !tbaa !21
  br i1 %t193, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb36:
  br label %bb37
bb37:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  store ptr %t197, ptr %l104, !tbaa !29
  %t198 = load i64, ptr %l8, !tbaa !24
  %t200 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t198)
  store i64 %t200, ptr %l106
  br label %bb38
bb38:
  %t201 = load ptr, ptr %l104, !tbaa !29
  %t202 = load i64, ptr %l106, !tbaa !24
  %t203 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t201, i64 %t202)
  store i64 %t203, ptr %l107
  br label %bb39
bb39:
  %t204 = load i64, ptr %l107, !tbaa !24
  %t205 = icmp eq i64 %t204, 0
  br i1 %t205, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v1, ptr %t210, i64 %t211, i32 0)
  store i64 %t214, ptr %l112
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l132, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  store ptr %t216, ptr %l133, !tbaa !29
  %t217 = load i64, ptr %l8, !tbaa !24
  store i64 %t217, ptr %l134, !tbaa !24
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t222 = load i64, ptr %l8, !tbaa !24
  %t225 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t221, i64 %t222)
  store i32 %t225, ptr %l138
  br label %bb49
bb42:
  %t226 = load i64, ptr %l112, !tbaa !24
  store i64 %t226, ptr %l11, !tbaa !24
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l113, !tbaa !29
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l114, !tbaa !29
  %t229 = load i64, ptr %l8, !tbaa !24
  store i64 %t229, ptr %l115, !tbaa !24
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v1, ptr %t233, i64 %t234)
  store i32 %t237, ptr %l119
  br label %bb43
bb43:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t239 = load i64, ptr %l11, !tbaa !24
  %t242 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v1, ptr %t238, i64 %t239)
  store i64 %t242, ptr %l122
  br label %bb44
bb44:
  %t243 = load ptr, ptr %l114, !tbaa !29
  %t244 = load i64, ptr %l115, !tbaa !24
  %t245 = load i32, ptr %l119, !tbaa !23
  %t246 = load i64, ptr %l122, !tbaa !24
  %t247 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s6, ptr %t243, i64 %t244, i32 %t245, i64 %t246)
  store { i64, ptr } %t247, ptr %l123
  br label %bb45
bb45:
  %t248 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t250 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t269 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t269, { i64, ptr } %t268)
  br label %bb46
bb46:
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l126, !tbaa !29
  %t272 = load ptr, ptr %l1, !tbaa !29
  store ptr %t272, ptr %l127, !tbaa !29
  %t273 = load i64, ptr %l8, !tbaa !24
  store i64 %t273, ptr %l128, !tbaa !24
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t275 = load i64, ptr %l11, !tbaa !24
  %t278 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v1, ptr %t274, i64 %t275)
  store i64 %t278, ptr %l131
  br label %bb47
bb47:
  %t279 = load ptr, ptr %l126, !tbaa !29
  %t280 = load ptr, ptr %l127, !tbaa !29
  %t281 = load i64, ptr %l128, !tbaa !24
  %t282 = load i64, ptr %l131, !tbaa !24
  call void @compiler_2fexplain_2eeffectLine(ptr %v0, ptr %v1, ptr %s6, ptr %t279, ptr %t280, i64 %t281, i64 %t282, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d81, i32 0, i32 1) })
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb52
bb49:
  %t283 = load ptr, ptr %l133, !tbaa !29
  %t284 = load i64, ptr %l134, !tbaa !24
  %t285 = load i32, ptr %l138, !tbaa !23
  %t286 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s8, ptr %t283, i64 %t284, i32 %t285, i64 -1)
  store { i64, ptr } %t286, ptr %l139
  br label %bb50
bb50:
  %t287 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t289 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t292 = add i64 %t288, %t291
  %t293 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t295 = add i64 %t292, %t294
  %t296 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t295)
  call void @olang_textcopy(ptr %t296, ptr %t287, i64 %t288)
  %t297 = getelementptr i8, ptr %t296, i64 %t288
  call void @olang_textcopy(ptr %t297, ptr %t290, i64 %t291)
  %t298 = getelementptr i8, ptr %t297, i64 %t291
  call void @olang_textcopy(ptr %t298, ptr %t293, i64 %t294)
  %t299 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t296, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = extractvalue { i64, ptr } %t300, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  %t308 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t308, { i64, ptr } %t307)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb53:
  %t310 = load i64, ptr %l7, !tbaa !24
  %t312 = add i64 %t310, 1
  store i64 %t312, ptr %l7, !tbaa !24
  br label %bb9
bb54:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca { i64, ptr }
  %l37 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = icmp eq ptr %t3, null
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = sext i32 %t12 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t14)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l7, !tbaa !24
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  %t47 = getelementptr %"compiler/ast:Param", ptr %t43, i32 0, i32 1
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = sext i32 %t48 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t50)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t53 = load i64, ptr %l6, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  br label %bb15
bb15:
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t58, ptr %l37
  br label %bb16
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  store ptr %t64, ptr %l40, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l1, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l45
  br label %bb17
bb17:
  %t75 = load ptr, ptr %l40, !tbaa !29
  %t76 = load i32, ptr %l45, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t75, i32 %t76)
  store { i64, ptr } %t77, ptr %l46
  br label %bb18
bb18:
  %t78 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = load i64, ptr %l37, !tbaa !24
  %t82 = icmp ne i64 %t80, %t79
  br i1 %t82, label %bb19, label %bb20
bb19:
  %t84 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t84, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  store ptr %t91, ptr %l52, !tbaa !29
  %t92 = load i32, ptr %l1, !tbaa !23
  store i32 %t92, ptr %l53, !tbaa !23
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l56, !tbaa !29
  %t100 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t100, ptr %l58
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l56, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t103 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %s0, ptr %t101, { i64, ptr } %t102)
  store i64 %t103, ptr %l59
  br label %bb23
bb23:
  %t104 = load ptr, ptr %l52, !tbaa !29
  %t105 = load i32, ptr %l53, !tbaa !23
  %t106 = load i64, ptr %l59, !tbaa !24
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t104, i32 %t105, i64 %t106)
  store i32 %t107, ptr %l60
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i32, ptr %l60, !tbaa !23
  store i32 %t108, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fexplain_2enoValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t9 = call { i64, ptr } @compiler_2fexplain_2eNoValueWhy(ptr %v1, ptr %v2, ptr %s0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
  store { i64, ptr } %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t10, ptr %l6, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load i1, ptr %l13, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t21 = extractvalue { i64, ptr } %a5, 1
  %t22 = extractvalue { i64, ptr } %a5, 0
  %t23 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %t19, 1
  %t28 = extractvalue { i64, ptr } %t19, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t21, i64 %t22)
  %t34 = getelementptr i8, ptr %t33, i64 %t22
  call void @olang_textcopy(ptr %t34, ptr %t23, i64 %t24)
  %t35 = getelementptr i8, ptr %t34, i64 %t24
  call void @olang_textcopy(ptr %t35, ptr %t27, i64 %t28)
  %t36 = getelementptr i8, ptr %t35, i64 %t28
  call void @olang_textcopy(ptr %t36, ptr %t30, i64 %t31)
  %t37 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t33, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %a0, { i64, ptr } %t45)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fexplain_2eobligations(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v2, ptr %v1, ptr %s2, ptr %a2, i64 %t6, ptr %t16)
  store { i64, ptr } %t20, ptr %l17
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 16
  %t25 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  %t53 = extractvalue { i64, ptr } %a4, 1
  %t54 = extractvalue { i64, ptr } %a4, 0
  %t55 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t59 = extractvalue { i64, ptr } %t47, 1
  %t60 = extractvalue { i64, ptr } %t47, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = getelementptr i8, ptr %t65, i64 %t54
  call void @olang_textcopy(ptr %t66, ptr %t55, i64 %t56)
  %t67 = getelementptr i8, ptr %t66, i64 %t56
  call void @olang_textcopy(ptr %t67, ptr %t59, i64 %t60)
  %t68 = getelementptr i8, ptr %t67, i64 %t60
  call void @olang_textcopy(ptr %t68, ptr %t62, i64 %t63)
  %t69 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t65, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %a0, { i64, ptr } %t77)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb5
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fexplain_2epushPayload(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l24 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l43 = alloca i32
  %l47 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v1, ptr %v1, ptr %t4, i32 %t5)
  store ptr %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_267284e461664677_b2c2386ba62ab5d3)
  unreachable
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = call i1 @compiler_2fexplain_2ecaseWhole(ptr %v1, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l16
  br label %bb5
bb5:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l18, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  store ptr %t27, ptr %l21, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  store ptr %t33, ptr %l24, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t39 = load i64, ptr %l4, !tbaa !24
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v1, ptr %t37, i32 %t38, i64 %t39)
  store i32 %t43, ptr %l29
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = load i32, ptr %l29, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t44, i32 %t45)
  store i32 %t46, ptr %l30
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = load i32, ptr %l30, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %s1, ptr %t47, i32 %t48)
  store { i64, ptr } %t49, ptr %l31
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i32, ptr %t52, i64 0
  %t54 = load i32, ptr %t53, !tbaa !33
  %t55 = load ptr, ptr %l18, !tbaa !29
  %t57 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s1, ptr %t55, i32 %t54)
  store { i64, ptr } %t57, ptr %l34
  br label %bb11
bb11:
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t60 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = add i64 %t59, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t58, i64 %t59)
  %t65 = getelementptr i8, ptr %t64, i64 %t59
  call void @olang_textcopy(ptr %t65, ptr %t61, i64 %t62)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t64, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t75, { i64, ptr } %t74)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l37, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i32, ptr %l3, !tbaa !23
  %t84 = load i64, ptr %l4, !tbaa !24
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v1, ptr %t82, i32 %t83, i64 %t84)
  store i32 %t88, ptr %l43
  br label %bb14
bb14:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  %t96 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v1, ptr %v1, ptr %t92, i32 %t93)
  store ptr %t96, ptr %l47
  br label %bb15
bb15:
  %t97 = load ptr, ptr %l47, !tbaa !29
  store ptr %t97, ptr %l6, !tbaa !29
  %t98 = load ptr, ptr %l6, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_66f7703ccaf4f658_ca46a1b97aa24804)
  unreachable
bb17:
  br label %bb18
bb18:
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t103 = load i64, ptr %l4, !tbaa !24
  %t106 = call { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v1, ptr %s0, ptr %t102, i64 %t103)
  store { i64, ptr } %t106, ptr %l52
  br label %bb19
bb19:
  %t107 = load ptr, ptr %l38, !tbaa !29
  %t108 = load i32, ptr %l43, !tbaa !23
  %t109 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t110 = call i32 @compiler_2fexplain_2enamed(ptr %v1, ptr %s0, ptr %s0, ptr %t107, i32 %t108, ptr null, { i64, ptr } %t109)
  store i32 %t110, ptr %l53
  br label %bb20
bb20:
  %t111 = load ptr, ptr %l37, !tbaa !29
  %t112 = load i32, ptr %l53, !tbaa !23
  %t113 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v1, ptr %s0, ptr %t111, i32 %t112)
  store { i64, ptr } %t113, ptr %l54
  br label %bb21
bb21:
  %t114 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t114, ptr %l7, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l55, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = call i64 @compiler_2fexplain_2efirstClose(ptr %s0, { i64, ptr } %t116)
  store i64 %t118, ptr %l57
  br label %bb22
bb22:
  %t119 = load i64, ptr %l57, !tbaa !24
  %t120 = add i64 %t119, 1
  store i64 %t120, ptr %l58, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l59, !tbaa !24
  %t123 = icmp sge i64 2, 0
  br i1 %t123, label %bb23, label %bb24
bb23:
  %t125 = load i64, ptr %l58, !tbaa !24
  %t126 = icmp sle i64 2, %t125
  br i1 %t126, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887)
  unreachable
bb25:
  %t128 = load i64, ptr %l58, !tbaa !24
  %t129 = load i64, ptr %l59, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887)
  unreachable
bb27:
  %t132 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l58, !tbaa !24
  %t135 = getelementptr i8, ptr %t133, i64 2
  %t136 = sub i64 %t134, 2
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  %t139 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t139, { i64, ptr } %t138)
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2equoted(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb2
bb2:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb25
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t19
  %t24 = load i8, ptr %t23, !tbaa !32
  store i8 %t24, ptr %l5, !tbaa !22
  %t26 = load i8, ptr %l5, !tbaa !22
  %t28 = icmp eq i8 %t26, 34
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 92
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb12
bb11:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 10
  br i1 %t38, label %bb14, label %bb15
bb12:
  %t40 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t40)
  br label %bb13
bb13:
  br label %bb23
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb16
bb15:
  %t44 = load i8, ptr %l5, !tbaa !22
  %t46 = icmp eq i8 %t44, 9
  br i1 %t46, label %bb17, label %bb18
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb19
bb18:
  %t49 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t49)
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s7)
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb3
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb26
bb26:
  %t58 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t58, ptr %l38
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l6 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l29 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Func", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l20
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load i32, ptr %l20, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l13, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 0
  %t47 = load i32, ptr %t46, !tbaa !33
  store i32 %t47, ptr %l2, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l29
  br label %bb8
bb8:
  %t59 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t61 = trunc i64 20 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l36
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t74 = load i32, ptr %l36, !tbaa !23
  store i32 %t74, ptr %l2, !tbaa !23
  br label %bb12
bb12:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l41
  br label %bb13
bb13:
  %t85 = load i32, ptr %l41, !range !{i32 0, i32 33}
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l48, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l2, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l53
  br label %bb17
bb17:
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t110 = load i32, ptr %l53, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l54
  br label %bb18
bb18:
  %t112 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  call void @__olang_scope_close(ptr %s0)
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i64
  %l42 = alloca i32
  %l45 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l10
  br label %bb3
bb3:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %v1, ptr %t14, i32 %t15)
  store { i64, ptr } %t18, ptr %l14
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t24, ptr %l17
  br label %bb9
bb9:
  %t25 = load i32, ptr %l17, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l25
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb11
bb11:
  %t52 = load i32, ptr %l3, !tbaa !23
  store i32 %t52, ptr %l31, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l36
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t72, ptr %l41
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l20, !tbaa !29
  %t74 = load i32, ptr %l25, !tbaa !23
  %t75 = load i32, ptr %l30, !tbaa !23
  %t76 = load i32, ptr %l31, !tbaa !23
  %t77 = load i32, ptr %l36, !tbaa !23
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 %t74, i32 %t75, i32 %t76, i32 %t77, i64 %t78, i1 false, i32 0)
  store i32 %t79, ptr %l42
  br label %bb14
bb14:
  %t80 = load i32, ptr %l42, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t85 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %s0, ptr %t81, i32 %t80)
  store { i64, ptr } %t85, ptr %l45
  br label %bb15
bb15:
  %t86 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = getelementptr i8, ptr %t92, i64 %t88
  call void @olang_textcopy(ptr %t93, ptr %t89, i64 %t90)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2etraitsMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca %"compiler/names:Entry"
  %l89 = alloca i1
  %l93 = alloca %"compiler/names:Entry"
  %l100 = alloca i32
  %l105 = alloca i32
  %l109 = alloca i1
  %l111 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i32
  %l124 = alloca i1
  %l125 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca ptr
  %l139 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 1
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H1e7e683fc0332c06b6c705cd46691777(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l24, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb5:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l31, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  br label %bb53
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l9, !tbaa !24
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/names:Resolver", ptr %t67, i32 0, i32 1
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v1, ptr %v1, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l54
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l54, !tbaa !29
  store ptr %t74, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  %t75 = load ptr, ptr %l10, !tbaa !29
  %t77 = getelementptr %"compiler/names:Table", ptr %t75, i32 0, i32 0
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %t77)
  store i64 %t79, ptr %l57
  br label %bb14
bb14:
  %t80 = load i64, ptr %l57, !tbaa !24
  store i64 %t80, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t81 = load i64, ptr %l12, !tbaa !24
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb15, label %bb16
bb15:
  %t87 = load i64, ptr %l13, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb20
bb17:
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load i64, ptr %l11, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l13, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l13, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l64, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb19
bb19:
  %t107 = load i64, ptr %l64, !tbaa !24
  store i64 %t107, ptr %l61, !tbaa !24
  br label %bb20
bb20:
  %t108 = load i64, ptr %l61, !tbaa !24
  store i64 %t108, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t109 = load i64, ptr %l15, !tbaa !24
  %t110 = load i64, ptr %l14, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb23:
  br label %bb24
bb24:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l15, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t125 = add i64 %t117, %t122
  store i64 %t125, ptr %l16, !tbaa !24
  %t127 = load ptr, ptr %l10, !tbaa !29
  %t129 = getelementptr %"compiler/names:Table", ptr %t127, i32 0, i32 0
  %t130 = load i64, ptr %l16, !tbaa !24
  %t133 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %s4, ptr %t129, i64 %t130)
  store %"compiler/names:Entry" %t133, ptr %l85
  br label %bb25
bb25:
  %t134 = getelementptr %"compiler/names:Entry", ptr %l85, i32 0, i32 2
  %t135 = load i32, ptr %t134, !range !{i32 0, i32 9}
  %t137 = trunc i64 4 to i32
  %t138 = icmp eq i32 %t135, %t137
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb29
bb27:
  %t142 = load ptr, ptr %l10, !tbaa !29
  %t144 = getelementptr %"compiler/names:Table", ptr %t142, i32 0, i32 0
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %v1, ptr %t144, i64 %t145)
  store %"compiler/names:Entry" %t148, ptr %l93
  br label %bb28
bb28:
  %t149 = getelementptr %"compiler/names:Entry", ptr %l93, i32 0, i32 4
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  store i1 %t152, ptr %l89, !tbaa !21
  br label %bb29
bb29:
  %t154 = load i1, ptr %l89, !tbaa !21
  br i1 %t154, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb31:
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i64, ptr %l9, !tbaa !24
  %t160 = load i64, ptr %l16, !tbaa !24
  %t164 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v1, ptr %t158, i64 %t159, i64 %t160)
  store i32 %t164, ptr %l100
  br label %bb33
bb33:
  %t165 = load i32, ptr %l100, !tbaa !23
  store i32 %t165, ptr %l17, !tbaa !23
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  %t172 = load i32, ptr %l17, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v1, ptr %t171, i32 %t172)
  store i32 %t175, ptr %l105
  br label %bb34
bb34:
  %t176 = load i32, ptr %l105, !range !{i32 0, i32 6}
  %t178 = trunc i64 3 to i32
  %t179 = icmp eq i32 %t176, %t178
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb39
bb36:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l111, !tbaa !29
  %t187 = load i32, ptr %l17, !tbaa !23
  %t189 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t187)
  store i64 %t189, ptr %l113
  br label %bb37
bb37:
  %t190 = load ptr, ptr %l111, !tbaa !29
  %t191 = load i64, ptr %l113, !tbaa !24
  %t192 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t190, i64 %t191)
  store i64 %t192, ptr %l114
  br label %bb38
bb38:
  %t193 = load i64, ptr %l114, !tbaa !24
  %t194 = icmp sgt i64 %t193, 0
  store i1 %t194, ptr %l109, !tbaa !21
  br label %bb39
bb39:
  %t196 = load i1, ptr %l109, !tbaa !21
  br i1 %t196, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb41:
  br label %bb42
bb42:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t201 = load i32, ptr %l17, !tbaa !23
  %t204 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v1, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l119
  br label %bb43
bb43:
  %t205 = load i32, ptr %l119, !tbaa !23
  store i32 %t205, ptr %l18, !tbaa !23
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = load i32, ptr %l18, !tbaa !23
  %t215 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v1, ptr %t209, i32 %a2, i32 %t211)
  store i1 %t215, ptr %l124
  br label %bb44
bb44:
  %t216 = load i1, ptr %l124, !tbaa !21
  br i1 %t216, label %bb45, label %bb46
bb45:
  store ptr %l3, ptr %l125, !tbaa !29
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t218 = load i32, ptr %l18, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s0, ptr %t217, i32 %t218)
  store { i64, ptr } %t221, ptr %l128
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t222 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t229 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t229, { i64, ptr } %t228)
  br label %bb48
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb50:
  %t231 = load i64, ptr %l15, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l15, !tbaa !24
  br label %bb21
bb51:
  br label %bb52
bb52:
  %t235 = load i64, ptr %l8, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l8, !tbaa !24
  br label %bb9
bb53:
  %t240 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t240, ptr %l135
  br label %bb54
bb54:
  %t241 = load i64, ptr %l135, !tbaa !24
  %t242 = icmp sgt i64 %t241, 0
  br i1 %t242, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %a0, ptr %l137, !tbaa !29
  %t246 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s10, ptr %s10, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store { i64, ptr } %t246, ptr %l139
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t247 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t249 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = add i64 %t248, %t251
  %t253 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t247, i64 %t248)
  %t257 = getelementptr i8, ptr %t256, i64 %t248
  call void @olang_textcopy(ptr %t257, ptr %t250, i64 %t251)
  %t258 = getelementptr i8, ptr %t257, i64 %t251
  call void @olang_textcopy(ptr %t258, ptr %t253, i64 %t254)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t256, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } %t260, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t268 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s10, ptr %t268, { i64, ptr } %t267)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l28 = alloca i32
  %l35 = alloca i32
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 60)
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t9, i32 %a1)
  store { i64, ptr } %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb6:
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  store i32 %t33, ptr %l7, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l7, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l28
  br label %bb8
bb8:
  %t45 = load i32, ptr %l28, !range !{i32 0, i32 33}
  %t47 = trunc i64 30 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l7, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb11
bb10:
  br label %bb20
bb11:
  %t60 = load i32, ptr %l35, !tbaa !23
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l37, !tbaa !29
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb14, label %bb15
bb13:
  br label %bb19
bb14:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l7, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s4, ptr %t67, i32 %t68)
  store { i64, ptr } %t71, ptr %l43
  br label %bb17
bb17:
  %t72 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t73, i64 %t74)
  %t80 = getelementptr i8, ptr %t79, i64 %t74
  call void @olang_textcopy(ptr %t80, ptr %t76, i64 %t77)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } %t82, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  %t90 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t90, { i64, ptr } %t89)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb20:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d98, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb24:
  store ptr %l2, ptr %l49, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l7, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s2, ptr %t97, i32 %t98)
  store { i64, ptr } %t101, ptr %l52
  br label %bb25
bb25:
  %t102 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t109, { i64, ptr } %t108)
  br label %bb26
bb26:
  %t111 = load i64, ptr %l3, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t115 = load i64, ptr %l5, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l5, !tbaa !24
  br label %bb4
bb28:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 62)
  br label %bb29
bb29:
  %t121 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t121, ptr %l60
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t122 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t122, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca %"std/prelude/text:StringBuilder"
  %l63 = alloca i32
  %l67 = alloca i1
  %l71 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l80 = alloca i64
  %l87 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l103 = alloca i32
  %l113 = alloca i1
  %l123 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l131 = alloca i64
  %l132 = alloca ptr
  %l147 = alloca { i64, ptr }
  %l153 = alloca i64
  %l156 = alloca i64
  %l174 = alloca ptr
  %l177 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l183 = alloca i64
  %l184 = alloca { i64, ptr }
  %l188 = alloca i64
  %l189 = alloca i64
  %l202 = alloca { i64, ptr }
  %l208 = alloca i64
  %l211 = alloca i64
  %l229 = alloca ptr
  %l231 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l251 = alloca ptr
  %l255 = alloca i64
  %l261 = alloca ptr
  %l278 = alloca ptr
  %l279 = alloca i1
  %l289 = alloca ptr
  %l292 = alloca { i64, ptr }
  %l298 = alloca ptr
  %l301 = alloca { i64, ptr }
  %l310 = alloca ptr
  %l311 = alloca i1
  %l323 = alloca { i64, ptr }
  %l326 = alloca ptr
  %l327 = alloca { i64, ptr }
  %l330 = alloca i64
  %l333 = alloca i64
  %l334 = alloca i64
  %l339 = alloca { i64, ptr }
  %l345 = alloca { i64, ptr }
  %l348 = alloca ptr
  %l349 = alloca { i64, ptr }
  %l352 = alloca { i64, ptr }
  %l357 = alloca ptr
  %l362 = alloca i32
  %l363 = alloca { i64, ptr }
  %l368 = alloca { i64, ptr }
  %l374 = alloca i64
  %l377 = alloca i64
  %l396 = alloca ptr
  %l397 = alloca ptr
  %l403 = alloca i32
  %l404 = alloca { i64, ptr }
  %l406 = alloca ptr
  %l408 = alloca { i64, ptr }
  %l411 = alloca { i64, ptr }
  %l416 = alloca i1
  %l417 = alloca { i64, ptr }
  %l435 = alloca i32
  %l436 = alloca ptr
  %l437 = alloca { i64, ptr }
  %l440 = alloca { i64, ptr }
  %l444 = alloca i1
  %l445 = alloca { i64, ptr }
  %l450 = alloca i32
  %l453 = alloca { i64, ptr }
  %l456 = alloca { i64, ptr }
  %l459 = alloca { i64, ptr }
  %l465 = alloca ptr
  %l471 = alloca ptr
  %l472 = alloca i1
  %l480 = alloca ptr
  %l481 = alloca ptr
  %l485 = alloca i32
  %l489 = alloca i32
  %l490 = alloca { i64, ptr }
  %l492 = alloca i64
  %l493 = alloca ptr
  %l495 = alloca i64
  %l496 = alloca i64
  %l500 = alloca { i64, ptr }
  %l502 = alloca i64
  %l504 = alloca i64
  %l505 = alloca i64
  %l510 = alloca { i64, ptr }
  %l511 = alloca i64
  %l512 = alloca { i64, ptr }
  %l518 = alloca ptr
  %l519 = alloca ptr
  %l523 = alloca i32
  %l527 = alloca ptr
  %l531 = alloca { i64, ptr }
  %l532 = alloca i32
  %l533 = alloca { i64, ptr }
  %l535 = alloca i64
  %l536 = alloca ptr
  %l537 = alloca i64
  %l538 = alloca i64
  %l542 = alloca { i64, ptr }
  %l546 = alloca ptr
  %l550 = alloca { i64, ptr }
  %l554 = alloca i64
  %l555 = alloca { i64, ptr }
  %l556 = alloca ptr
  %l557 = alloca { i64, ptr }
  %l560 = alloca { i64, ptr }
  %l565 = alloca i1
  %l566 = alloca { i64, ptr }
  %l567 = alloca { i64, ptr }
  %l569 = alloca i64
  %l571 = alloca i64
  %l572 = alloca i64
  %l577 = alloca { i64, ptr }
  %l578 = alloca i64
  %l579 = alloca { i64, ptr }
  %l585 = alloca ptr
  %l591 = alloca ptr
  %l592 = alloca i1
  %l601 = alloca ptr
  %l602 = alloca ptr
  %l607 = alloca ptr
  %l611 = alloca i64
  %l625 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l59
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l59
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l63
  br label %bb2
bb2:
  %t11 = load i32, ptr %l63, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l67
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t23, i32 %t24)
  store ptr %t27, ptr %l71
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l71, !tbaa !29
  store ptr %t28, ptr %l4, !tbaa !29
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l2, ptr %l75, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l76, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l80
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TypeDecl", ptr %t44, i32 0, i32 4
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = load ptr, ptr %l75, !tbaa !29
  %t49 = load ptr, ptr %l76, !tbaa !29
  %t50 = load i64, ptr %l80, !tbaa !24
  call void @compiler_2fexplain_2eattrLines(ptr %s0, ptr %v0, ptr %v0, ptr %s1, ptr %t48, ptr %t49, i64 %t50, { i64, ptr } %t47, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/load:Loader", ptr %t58, i32 0, i32 3
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l5, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  store ptr %t63, ptr %l87, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l92
  br label %bb10
bb10:
  %t74 = load ptr, ptr %l87, !tbaa !29
  %t75 = load i32, ptr %l92, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t74, i32 %t75)
  store { i64, ptr } %t76, ptr %l93
  br label %bb11
bb11:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l94, !tbaa !29
  %t78 = load i32, ptr %l1, !tbaa !23
  %t80 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t78)
  store i64 %t80, ptr %l96
  br label %bb12
bb12:
  %t81 = load ptr, ptr %l94, !tbaa !29
  %t82 = load i64, ptr %l96, !tbaa !24
  %t83 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t81, i64 %t82, i64 0)
  store { i64, ptr } %t83, ptr %l97
  br label %bb13
bb13:
  %t84 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = add i64 %t86, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t85, i64 %t86)
  %t92 = getelementptr i8, ptr %t91, i64 %t86
  call void @olang_textcopy(ptr %t92, ptr %t88, i64 %t89)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t91, 1
  store { i64, ptr } %t94, ptr %l6, !tbaa !27
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l1, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l103
  br label %bb14
bb14:
  %t106 = load i32, ptr %l103, !range !{i32 0, i32 6}
  store i32 %t106, ptr %l7
  %t107 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t109 = trunc i64 5 to i32
  %t110 = icmp eq i32 %t107, %t109
  br i1 %t110, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t113 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t116 = extractvalue { i64, ptr } %t112, 1
  %t117 = extractvalue { i64, ptr } %t112, 0
  %t118 = add i64 %t114, %t117
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t121 = add i64 %t118, %t120
  %t122 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t113, i64 %t114)
  %t123 = getelementptr i8, ptr %t122, i64 %t114
  call void @olang_textcopy(ptr %t123, ptr %t116, i64 %t117)
  %t124 = getelementptr i8, ptr %t123, i64 %t117
  call void @olang_textcopy(ptr %t124, ptr %t119, i64 %t120)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t122, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t126, ptr %rv
  br label %ret
bb18:
  %t128 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t130 = trunc i64 2 to i32
  %t131 = icmp eq i32 %t128, %t130
  br i1 %t131, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb78
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load i32, ptr %l1, !tbaa !23
  %t140 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t140, ptr %l113
  br label %bb22
bb22:
  %t141 = load i1, ptr %l113, !tbaa !21
  br i1 %t141, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t142 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t143 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t146 = extractvalue { i64, ptr } %t142, 1
  %t147 = extractvalue { i64, ptr } %t142, 0
  %t148 = add i64 %t144, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t143, i64 %t144)
  %t150 = getelementptr i8, ptr %t149, i64 %t144
  call void @olang_textcopy(ptr %t150, ptr %t146, i64 %t147)
  %t151 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t149, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l2, { i64, ptr } %t159)
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2ewordPayload(ptr %s0, ptr %v0, ptr %l2, ptr %t162, i32 %t163, i64 0)
  br label %bb26
bb26:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l2, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb27
bb27:
  %t169 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t169, ptr %l123
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t170 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t170, ptr %rv
  br label %ret
bb29:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 0
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/load:Loader", ptr %t177, i32 0, i32 10
  store ptr %t179, ptr %l127, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t184 = load i32, ptr %l1, !tbaa !23
  %t187 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t183, i32 %t184)
  store i64 %t187, ptr %l131
  br label %bb30
bb30:
  %t188 = load ptr, ptr %l127, !tbaa !29
  %t189 = load i64, ptr %l131, !tbaa !24
  %t190 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t188, i64 %t189)
  store ptr %t190, ptr %l132
  br label %bb31
bb31:
  %t191 = load ptr, ptr %l132, !tbaa !29
  %t193 = getelementptr %"compiler/load:Module", ptr %t191, i32 0, i32 6
  %t194 = load ptr, ptr %t193, !tbaa !29
  store ptr %t194, ptr %l8, !tbaa !29
  %t196 = load ptr, ptr %l8, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  br i1 %t198, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a)
  unreachable
bb33:
  br label %bb34
bb34:
  %t200 = load ptr, ptr %l8, !tbaa !29
  %t203 = getelementptr %"compiler/source:Source", ptr %t200, i32 0, i32 1
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l9, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t207 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t210 = extractvalue { i64, ptr } %t206, 1
  %t211 = extractvalue { i64, ptr } %t206, 0
  %t212 = add i64 %t208, %t211
  %t213 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t216 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t215)
  call void @olang_textcopy(ptr %t216, ptr %t207, i64 %t208)
  %t217 = getelementptr i8, ptr %t216, i64 %t208
  call void @olang_textcopy(ptr %t217, ptr %t210, i64 %t211)
  %t218 = getelementptr i8, ptr %t217, i64 %t211
  call void @olang_textcopy(ptr %t218, ptr %t213, i64 %t214)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t216, 1
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t223 = extractvalue { i64, ptr } %t220, 1
  %t224 = mul i64 %t222, 1
  %t225 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t224)
  call void @llvm.memcpy.p0.p0.i64(ptr %t225, ptr %t223, i64 %t224, i1 false)
  %t226 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l2, { i64, ptr } %t227)
  br label %bb35
bb35:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load i32, ptr %l1, !tbaa !23
  %t237 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %s5, ptr %t233, i32 %t234)
  store { i64, ptr } %t237, ptr %l147
  br label %bb36
bb36:
  %t238 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t238, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  store i64 %t241, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t243 = load i64, ptr %l12, !tbaa !24
  %t244 = load i64, ptr %l11, !tbaa !24
  %t247 = icmp sgt i64 %t243, %t244
  br i1 %t247, label %bb37, label %bb38
bb37:
  %t249 = load i64, ptr %l13, !tbaa !24
  %t251 = icmp sgt i64 %t249, 0
  br i1 %t251, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l153, !tbaa !24
  br label %bb42
bb39:
  %t253 = load i64, ptr %l12, !tbaa !24
  %t254 = load i64, ptr %l11, !tbaa !24
  %t257 = sub i64 %t253, %t254
  %t258 = load i64, ptr %l13, !tbaa !24
  %t261 = add i64 %t257, %t258
  %t263 = sub i64 %t261, 1
  %t264 = load i64, ptr %l13, !tbaa !24
  %t267 = sdiv i64 %t263, %t264
  store i64 %t267, ptr %l156, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l156, !tbaa !24
  br label %bb41
bb41:
  %t269 = load i64, ptr %l156, !tbaa !24
  store i64 %t269, ptr %l153, !tbaa !24
  br label %bb42
bb42:
  %t270 = load i64, ptr %l153, !tbaa !24
  store i64 %t270, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t271 = load i64, ptr %l15, !tbaa !24
  %t272 = load i64, ptr %l14, !tbaa !24
  %t275 = icmp slt i64 %t271, %t272
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb45:
  br label %bb46
bb46:
  %t279 = load i64, ptr %l11, !tbaa !24
  %t280 = load i64, ptr %l15, !tbaa !24
  %t281 = load i64, ptr %l13, !tbaa !24
  %t284 = mul i64 %t280, %t281
  %t287 = add i64 %t279, %t284
  store i64 %t287, ptr %l16, !tbaa !24
  store ptr %l2, ptr %l174, !tbaa !29
  %t289 = load i64, ptr %l16, !tbaa !24
  %t291 = icmp sgt i64 %t289, 0
  br i1 %t291, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d106, i32 0, i32 1) }, ptr %l177, !tbaa !27
  br label %bb49
bb48:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, ptr %l177, !tbaa !27
  br label %bb49
bb49:
  %t293 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t293, ptr %l178, !tbaa !27
  %t294 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t294, ptr %l179, !tbaa !27
  %t295 = load i64, ptr %l16, !tbaa !24
  %t297 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = getelementptr ptr, ptr %t298, i64 %t295
  %t300 = load ptr, ptr %t299, !tbaa !39
  %t302 = getelementptr %"compiler/ast:Path", ptr %t300, i32 0, i32 0
  %t303 = getelementptr %"compiler/source:Span", ptr %t302, i32 0, i32 0
  %t304 = load i32, ptr %t303, !tbaa !23
  %t306 = sext i32 %t304 to i64
  store i64 %t306, ptr %l183, !tbaa !24
  %t307 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t307, ptr %l184, !tbaa !27
  %t308 = load i64, ptr %l16, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr ptr, ptr %t311, i64 %t308
  %t313 = load ptr, ptr %t312, !tbaa !39
  %t315 = getelementptr %"compiler/ast:Path", ptr %t313, i32 0, i32 0
  %t316 = getelementptr %"compiler/source:Span", ptr %t315, i32 0, i32 1
  %t317 = load i32, ptr %t316, !tbaa !23
  %t319 = sext i32 %t317 to i64
  store i64 %t319, ptr %l188, !tbaa !24
  %t320 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 0
  store i64 %t321, ptr %l189, !tbaa !24
  %t322 = load i64, ptr %l183, !tbaa !24
  %t323 = icmp sge i64 %t322, 0
  br i1 %t323, label %bb50, label %bb51
bb50:
  %t325 = load i64, ptr %l183, !tbaa !24
  %t326 = load i64, ptr %l188, !tbaa !24
  %t327 = icmp sle i64 %t325, %t326
  br i1 %t327, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb52:
  %t329 = load i64, ptr %l188, !tbaa !24
  %t330 = load i64, ptr %l189, !tbaa !24
  %t331 = icmp sle i64 %t329, %t330
  br i1 %t331, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb54:
  %t333 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = load i64, ptr %l183, !tbaa !24
  %t336 = load i64, ptr %l188, !tbaa !24
  %t337 = getelementptr i8, ptr %t334, i64 %t335
  %t338 = sub i64 %t336, %t335
  %t339 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t337, 1
  %t341 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 1
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t345 = extractvalue { i64, ptr } %t340, 1
  %t346 = extractvalue { i64, ptr } %t340, 0
  %t347 = add i64 %t343, %t346
  %t348 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t347)
  call void @olang_textcopy(ptr %t348, ptr %t342, i64 %t343)
  %t349 = getelementptr i8, ptr %t348, i64 %t343
  call void @olang_textcopy(ptr %t349, ptr %t345, i64 %t346)
  %t350 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t348, 1
  %t353 = extractvalue { i64, ptr } %t351, 0
  %t354 = extractvalue { i64, ptr } %t351, 1
  %t355 = mul i64 %t353, 1
  %t356 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t355)
  call void @llvm.memcpy.p0.p0.i64(ptr %t356, ptr %t354, i64 %t355, i1 false)
  %t357 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t356, 1
  %t359 = load ptr, ptr %l174, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t359, { i64, ptr } %t358)
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  %t361 = load i64, ptr %l15, !tbaa !24
  %t363 = add i64 %t361, 1
  store i64 %t363, ptr %l15, !tbaa !24
  br label %bb43
bb58:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb59
bb59:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr %"compiler/check:Checker", ptr %t366, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !29
  %t370 = load i32, ptr %l1, !tbaa !23
  %t373 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s5, ptr %t369, i32 %t370)
  store { i64, ptr } %t373, ptr %l202
  br label %bb60
bb60:
  %t374 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t374, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t375 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t375, 0
  store i64 %t377, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t379 = load i64, ptr %l19, !tbaa !24
  %t380 = load i64, ptr %l18, !tbaa !24
  %t383 = icmp sgt i64 %t379, %t380
  br i1 %t383, label %bb61, label %bb62
bb61:
  %t385 = load i64, ptr %l20, !tbaa !24
  %t387 = icmp sgt i64 %t385, 0
  br i1 %t387, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l208, !tbaa !24
  br label %bb66
bb63:
  %t389 = load i64, ptr %l19, !tbaa !24
  %t390 = load i64, ptr %l18, !tbaa !24
  %t393 = sub i64 %t389, %t390
  %t394 = load i64, ptr %l20, !tbaa !24
  %t397 = add i64 %t393, %t394
  %t399 = sub i64 %t397, 1
  %t400 = load i64, ptr %l20, !tbaa !24
  %t403 = sdiv i64 %t399, %t400
  store i64 %t403, ptr %l211, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l211, !tbaa !24
  br label %bb65
bb65:
  %t405 = load i64, ptr %l211, !tbaa !24
  store i64 %t405, ptr %l208, !tbaa !24
  br label %bb66
bb66:
  %t406 = load i64, ptr %l208, !tbaa !24
  store i64 %t406, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s14
  %t407 = load i64, ptr %l22, !tbaa !24
  %t408 = load i64, ptr %l21, !tbaa !24
  %t411 = icmp slt i64 %t407, %t408
  %t413 = xor i1 %t411, true
  br i1 %t413, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s14)
  br label %bb76
bb69:
  br label %bb70
bb70:
  %t415 = load i64, ptr %l18, !tbaa !24
  %t416 = load i64, ptr %l22, !tbaa !24
  %t417 = load i64, ptr %l20, !tbaa !24
  %t420 = mul i64 %t416, %t417
  %t423 = add i64 %t415, %t420
  store i64 %t423, ptr %l23, !tbaa !24
  store ptr %l2, ptr %l229, !tbaa !29
  %t425 = load ptr, ptr %l5, !tbaa !29
  %t426 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t426, ptr %l231, !tbaa !27
  %t427 = load i64, ptr %l23, !tbaa !24
  %t429 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = getelementptr i32, ptr %t430, i64 %t427
  %t432 = load i32, ptr %t431, !tbaa !33
  %t435 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s14, ptr %t425, i32 %t432)
  store { i64, ptr } %t435, ptr %l234
  br label %bb71
bb71:
  %t436 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t437 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t438 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t439 = extractvalue { i64, ptr } %t438, 1
  %t440 = extractvalue { i64, ptr } %t438, 0
  %t441 = add i64 %t437, %t440
  %t442 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t441)
  call void @olang_textcopy(ptr %t442, ptr %t436, i64 %t437)
  %t443 = getelementptr i8, ptr %t442, i64 %t437
  call void @olang_textcopy(ptr %t443, ptr %t439, i64 %t440)
  %t444 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr %t442, 1
  %t447 = extractvalue { i64, ptr } %t445, 0
  %t448 = extractvalue { i64, ptr } %t445, 1
  %t449 = mul i64 %t447, 1
  %t450 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t449)
  call void @llvm.memcpy.p0.p0.i64(ptr %t450, ptr %t448, i64 %t449, i1 false)
  %t451 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t450, 1
  %t453 = load ptr, ptr %l229, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %t453, { i64, ptr } %t452)
  br label %bb72
bb72:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load i32, ptr %l3, !tbaa !23
  %t457 = load i64, ptr %l23, !tbaa !24
  call void @compiler_2fexplain_2ewordPayload(ptr %s0, ptr %v0, ptr %l2, ptr %t455, i32 %t456, i64 %t457)
  br label %bb73
bb73:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s14)
  br label %bb75
bb75:
  %t463 = load i64, ptr %l22, !tbaa !24
  %t465 = add i64 %t463, 1
  store i64 %t465, ptr %l22, !tbaa !24
  br label %bb67
bb76:
  %t468 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t468, ptr %l245
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t469 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t469, ptr %rv
  br label %ret
bb78:
  %t470 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t472 = trunc i64 3 to i32
  %t473 = icmp eq i32 %t470, %t472
  br i1 %t473, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb143
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/check:Checker", ptr %t475, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !29
  %t479 = load i32, ptr %l1, !tbaa !23
  %t482 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t478, i32 %t479)
  store ptr %t482, ptr %l251
  br label %bb82
bb82:
  %t483 = load ptr, ptr %l251, !tbaa !29
  store ptr %t483, ptr %l24, !tbaa !29
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t486 = getelementptr %"compiler/check:Checker", ptr %t484, i32 0, i32 1
  %t487 = load ptr, ptr %t486, !tbaa !29
  %t488 = load i32, ptr %l1, !tbaa !23
  %t491 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t487, i32 %t488)
  store i64 %t491, ptr %l255
  br label %bb83
bb83:
  %t492 = load i64, ptr %l255, !tbaa !24
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t495 = getelementptr %"compiler/check:Checker", ptr %t493, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !29
  %t498 = getelementptr %"compiler/generic:Program", ptr %t496, i32 0, i32 0
  %t499 = load ptr, ptr %t498, !tbaa !29
  %t501 = getelementptr %"compiler/load:Loader", ptr %t499, i32 0, i32 10
  %t505 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t501, i64 %t492)
  store ptr %t505, ptr %l261
  br label %bb84
bb84:
  %t506 = load ptr, ptr %l261, !tbaa !29
  %t508 = getelementptr %"compiler/load:Module", ptr %t506, i32 0, i32 6
  %t509 = load ptr, ptr %t508, !tbaa !29
  store ptr %t509, ptr %l26, !tbaa !29
  %t511 = load ptr, ptr %l26, !tbaa !29
  %t513 = icmp eq ptr %t511, null
  br i1 %t513, label %bb85, label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_a185ff5f85e75430_c999a61f9f0eedcc)
  unreachable
bb86:
  br label %bb87
bb87:
  %t515 = load ptr, ptr %l26, !tbaa !29
  %t518 = getelementptr %"compiler/source:Source", ptr %t515, i32 0, i32 1
  %t519 = load { i64, ptr }, ptr %t518, !tbaa !27
  store { i64, ptr } %t519, ptr %l27, !tbaa !27
  %t521 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t522 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t523 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t525 = extractvalue { i64, ptr } %t521, 1
  %t526 = extractvalue { i64, ptr } %t521, 0
  %t527 = add i64 %t523, %t526
  %t528 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t529 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t530 = add i64 %t527, %t529
  %t531 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t530)
  call void @olang_textcopy(ptr %t531, ptr %t522, i64 %t523)
  %t532 = getelementptr i8, ptr %t531, i64 %t523
  call void @olang_textcopy(ptr %t532, ptr %t525, i64 %t526)
  %t533 = getelementptr i8, ptr %t532, i64 %t526
  call void @olang_textcopy(ptr %t533, ptr %t528, i64 %t529)
  %t534 = insertvalue { i64, ptr } undef, i64 %t530, 0
  %t535 = insertvalue { i64, ptr } %t534, ptr %t531, 1
  %t537 = extractvalue { i64, ptr } %t535, 0
  %t538 = extractvalue { i64, ptr } %t535, 1
  %t539 = mul i64 %t537, 1
  %t540 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t539)
  call void @llvm.memcpy.p0.p0.i64(ptr %t540, ptr %t538, i64 %t539, i1 false)
  %t541 = insertvalue { i64, ptr } undef, i64 %t537, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t540, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %l2, { i64, ptr } %t542)
  br label %bb88
bb88:
  %t545 = load ptr, ptr %l24, !tbaa !29
  %t547 = icmp eq ptr %t545, null
  br i1 %t547, label %bb89, label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_60d3429e949e0f0f_c9b6e73225d64a3b)
  unreachable
bb90:
  br label %bb91
bb91:
  %t549 = load ptr, ptr %l24, !tbaa !29
  %t552 = getelementptr %"compiler/ast:TypeDecl", ptr %t549, i32 0, i32 3
  %t553 = load ptr, ptr %t552, !tbaa !29
  store ptr %t553, ptr %l28, !tbaa !29
  %t555 = load ptr, ptr %l28, !tbaa !29
  store ptr %t555, ptr %l278, !tbaa !29
  store i1 false, ptr %l279, !tbaa !21
  %t556 = load ptr, ptr %l278, !tbaa !29
  %t557 = icmp ne ptr %t556, null
  br i1 %t557, label %bb92, label %bb93
bb92:
  %t559 = load ptr, ptr %l278, !tbaa !29
  %t560 = load i64, ptr %t559, !range !{i64 0, i64 5}
  %t562 = icmp eq i64 %t560, 2
  store i1 %t562, ptr %l279, !tbaa !21
  br label %bb93
bb93:
  %t563 = load i1, ptr %l279, !tbaa !21
  br i1 %t563, label %bb94, label %bb95
bb94:
  %t564 = load ptr, ptr %l28, !tbaa !29
  %t566 = getelementptr { i64, [6 x i64] }, ptr %t564, i32 0, i32 1
  %t567 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t566, i32 0, i32 1
  %t568 = load { i64, ptr }, ptr %t567
  store { i64, ptr } %t568, ptr %l29, !tbaa !27
  %t570 = load ptr, ptr %l28, !tbaa !29
  %t572 = getelementptr { i64, [6 x i64] }, ptr %t570, i32 0, i32 1
  %t573 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t572, i32 0, i32 2
  %t574 = load { i64, ptr }, ptr %t573
  store { i64, ptr } %t574, ptr %l30, !tbaa !27
  br label %bb96
bb95:
  br label %bb107
bb96:
  %t576 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t578 = extractvalue { i64, ptr } %t576, 0
  %t580 = icmp sgt i64 %t578, 0
  br i1 %t580, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s20
  store ptr %l2, ptr %l289, !tbaa !29
  %t582 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t583 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t586 = call { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v0, ptr %s20, { i64, ptr } %t582, { i64, ptr } %t583)
  store { i64, ptr } %t586, ptr %l292
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t587 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t588 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t589 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t590 = extractvalue { i64, ptr } %t589, 1
  %t591 = extractvalue { i64, ptr } %t589, 0
  %t592 = add i64 %t588, %t591
  %t593 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t592)
  call void @olang_textcopy(ptr %t593, ptr %t587, i64 %t588)
  %t594 = getelementptr i8, ptr %t593, i64 %t588
  call void @olang_textcopy(ptr %t594, ptr %t590, i64 %t591)
  %t595 = insertvalue { i64, ptr } undef, i64 %t592, 0
  %t596 = insertvalue { i64, ptr } %t595, ptr %t593, 1
  %t598 = extractvalue { i64, ptr } %t596, 0
  %t599 = extractvalue { i64, ptr } %t596, 1
  %t600 = mul i64 %t598, 1
  %t601 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t600)
  call void @llvm.memcpy.p0.p0.i64(ptr %t601, ptr %t599, i64 %t600, i1 false)
  %t602 = insertvalue { i64, ptr } undef, i64 %t598, 0
  %t603 = insertvalue { i64, ptr } %t602, ptr %t601, 1
  %t604 = load ptr, ptr %l289, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %t604, { i64, ptr } %t603)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s20)
  br label %bb101
bb101:
  %t606 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t606, 0
  %t610 = icmp sgt i64 %t608, 0
  br i1 %t610, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s22
  store ptr %l2, ptr %l298, !tbaa !29
  %t612 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t613 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t616 = call { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v0, ptr %s22, { i64, ptr } %t612, { i64, ptr } %t613)
  store { i64, ptr } %t616, ptr %l301
  br label %bb104
bb103:
  br label %bb106
bb104:
  %t617 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t618 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t619 = load { i64, ptr }, ptr %l301, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t619, 1
  %t621 = extractvalue { i64, ptr } %t619, 0
  %t622 = add i64 %t618, %t621
  %t623 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t622)
  call void @olang_textcopy(ptr %t623, ptr %t617, i64 %t618)
  %t624 = getelementptr i8, ptr %t623, i64 %t618
  call void @olang_textcopy(ptr %t624, ptr %t620, i64 %t621)
  %t625 = insertvalue { i64, ptr } undef, i64 %t622, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t623, 1
  %t628 = extractvalue { i64, ptr } %t626, 0
  %t629 = extractvalue { i64, ptr } %t626, 1
  %t630 = mul i64 %t628, 1
  %t631 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t630)
  call void @llvm.memcpy.p0.p0.i64(ptr %t631, ptr %t629, i64 %t630, i1 false)
  %t632 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t633 = insertvalue { i64, ptr } %t632, ptr %t631, 1
  %t634 = load ptr, ptr %l298, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %t634, { i64, ptr } %t633)
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s22)
  br label %bb106
bb106:
  br label %bb112
bb107:
  br i1 true, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_9e7f77c067ece8f1_2a0afb54e00d35)
  unreachable
bb112:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) })
  br label %bb113
bb113:
  %t637 = load ptr, ptr %l24, !tbaa !29
  %t639 = icmp eq ptr %t637, null
  br i1 %t639, label %bb114, label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_7b101762ff8ffda9_ced5d247097fb61d)
  unreachable
bb115:
  br label %bb116
bb116:
  %t641 = load ptr, ptr %l24, !tbaa !29
  %t644 = getelementptr %"compiler/ast:TypeDecl", ptr %t641, i32 0, i32 3
  %t645 = load ptr, ptr %t644, !tbaa !29
  store ptr %t645, ptr %l31, !tbaa !29
  %t647 = load ptr, ptr %l31, !tbaa !29
  store ptr %t647, ptr %l310, !tbaa !29
  store i1 false, ptr %l311, !tbaa !21
  %t648 = load ptr, ptr %l310, !tbaa !29
  %t649 = icmp ne ptr %t648, null
  br i1 %t649, label %bb117, label %bb118
bb117:
  %t651 = load ptr, ptr %l310, !tbaa !29
  %t652 = load i64, ptr %t651, !range !{i64 0, i64 5}
  %t654 = icmp eq i64 %t652, 2
  store i1 %t654, ptr %l311, !tbaa !21
  br label %bb118
bb118:
  %t655 = load i1, ptr %l311, !tbaa !21
  br i1 %t655, label %bb119, label %bb120
bb119:
  %t656 = load ptr, ptr %l31, !tbaa !29
  %t658 = getelementptr { i64, [6 x i64] }, ptr %t656, i32 0, i32 1
  %t659 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t658, i32 0, i32 0
  %t660 = load { i64, ptr }, ptr %t659
  store { i64, ptr } %t660, ptr %l32, !tbaa !27
  br label %bb121
bb120:
  br label %bb136
bb121:
  %t662 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t662, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t664 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t664, 0
  store i64 %t666, ptr %l35, !tbaa !24
  br label %bb122
bb122:
  store %olang.scope zeroinitializer, ptr %s27
  %t668 = load i64, ptr %l34, !tbaa !24
  %t669 = load i64, ptr %l35, !tbaa !24
  %t672 = icmp slt i64 %t668, %t669
  %t674 = xor i1 %t672, true
  br i1 %t674, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s27)
  br label %bb135
bb124:
  br label %bb125
bb125:
  %t676 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t676, ptr %l323, !tbaa !27
  %t677 = load i64, ptr %l34, !tbaa !24
  %t679 = getelementptr { i64, ptr }, ptr %l323, i32 0, i32 1
  %t680 = load ptr, ptr %t679, !tbaa !27
  %t681 = getelementptr ptr, ptr %t680, i64 %t677
  %t682 = load ptr, ptr %t681, !tbaa !39
  store ptr %t682, ptr %l36, !tbaa !29
  store ptr %l2, ptr %l326, !tbaa !29
  %t684 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t684, ptr %l327, !tbaa !27
  %t685 = load ptr, ptr %l36, !tbaa !29
  %t687 = getelementptr %"compiler/ast:Func", ptr %t685, i32 0, i32 0
  %t688 = getelementptr %"compiler/source:Span", ptr %t687, i32 0, i32 0
  %t689 = load i32, ptr %t688, !tbaa !23
  %t691 = sext i32 %t689 to i64
  store i64 %t691, ptr %l330, !tbaa !24
  %t692 = load ptr, ptr %l36, !tbaa !29
  %t694 = getelementptr %"compiler/ast:Func", ptr %t692, i32 0, i32 0
  %t695 = getelementptr %"compiler/source:Span", ptr %t694, i32 0, i32 1
  %t696 = load i32, ptr %t695, !tbaa !23
  %t698 = sext i32 %t696 to i64
  store i64 %t698, ptr %l333, !tbaa !24
  %t699 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t700 = extractvalue { i64, ptr } %t699, 0
  store i64 %t700, ptr %l334, !tbaa !24
  %t701 = load i64, ptr %l330, !tbaa !24
  %t702 = icmp sge i64 %t701, 0
  br i1 %t702, label %bb126, label %bb127
bb126:
  %t704 = load i64, ptr %l330, !tbaa !24
  %t705 = load i64, ptr %l333, !tbaa !24
  %t706 = icmp sle i64 %t704, %t705
  br i1 %t706, label %bb128, label %bb129
bb127:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb128:
  %t708 = load i64, ptr %l333, !tbaa !24
  %t709 = load i64, ptr %l334, !tbaa !24
  %t710 = icmp sle i64 %t708, %t709
  br i1 %t710, label %bb130, label %bb131
bb129:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb130:
  %t712 = getelementptr { i64, ptr }, ptr %l327, i32 0, i32 1
  %t713 = load ptr, ptr %t712, !tbaa !27
  %t714 = load i64, ptr %l330, !tbaa !24
  %t715 = load i64, ptr %l333, !tbaa !24
  %t716 = getelementptr i8, ptr %t713, i64 %t714
  %t717 = sub i64 %t715, %t714
  %t718 = insertvalue { i64, ptr } undef, i64 %t717, 0
  %t719 = insertvalue { i64, ptr } %t718, ptr %t716, 1
  %t721 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s27, { i64, ptr } %t719)
  store { i64, ptr } %t721, ptr %l339
  br label %bb132
bb131:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb132:
  %t722 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t723 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t724 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t725 = extractvalue { i64, ptr } %t724, 1
  %t726 = extractvalue { i64, ptr } %t724, 0
  %t727 = add i64 %t723, %t726
  %t728 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t729 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t730 = add i64 %t727, %t729
  %t731 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t730)
  call void @olang_textcopy(ptr %t731, ptr %t722, i64 %t723)
  %t732 = getelementptr i8, ptr %t731, i64 %t723
  call void @olang_textcopy(ptr %t732, ptr %t725, i64 %t726)
  %t733 = getelementptr i8, ptr %t732, i64 %t726
  call void @olang_textcopy(ptr %t733, ptr %t728, i64 %t729)
  %t734 = insertvalue { i64, ptr } undef, i64 %t730, 0
  %t735 = insertvalue { i64, ptr } %t734, ptr %t731, 1
  %t737 = extractvalue { i64, ptr } %t735, 0
  %t738 = extractvalue { i64, ptr } %t735, 1
  %t739 = mul i64 %t737, 1
  %t740 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t739)
  call void @llvm.memcpy.p0.p0.i64(ptr %t740, ptr %t738, i64 %t739, i1 false)
  %t741 = insertvalue { i64, ptr } undef, i64 %t737, 0
  %t742 = insertvalue { i64, ptr } %t741, ptr %t740, 1
  %t743 = load ptr, ptr %l326, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %t743, { i64, ptr } %t742)
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s27)
  br label %bb134
bb134:
  %t745 = load i64, ptr %l34, !tbaa !24
  %t747 = add i64 %t745, 1
  store i64 %t747, ptr %l34, !tbaa !24
  br label %bb122
bb135:
  br label %bb141
bb136:
  br i1 true, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  call void @__olang_check_failed(ptr @olang_loc_4e8cd845c965dada_c1eb458e34ff6f7e)
  unreachable
bb141:
  %t750 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t750, ptr %l345
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t751 = load { i64, ptr }, ptr %l345, !tbaa !27
  store { i64, ptr } %t751, ptr %rv
  br label %ret
bb143:
  %t752 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t754 = trunc i64 1 to i32
  %t755 = icmp eq i32 %t752, %t754
  br i1 %t755, label %bb144, label %bb145
bb144:
  br label %bb146
bb145:
  br label %bb178
bb146:
  store %olang.scope zeroinitializer, ptr %s31
  store ptr %l2, ptr %l348, !tbaa !29
  %t757 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t757, ptr %l349, !tbaa !27
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t759 = load i32, ptr %l3, !tbaa !23
  %t762 = call { i64, ptr } @compiler_2fexplain_2edeclWord(ptr %v0, ptr %s31, ptr %t758, i32 %t759)
  store { i64, ptr } %t762, ptr %l352
  br label %bb147
bb147:
  %t763 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t764 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t765 = load { i64, ptr }, ptr %l349, !tbaa !27
  %t766 = extractvalue { i64, ptr } %t765, 1
  %t767 = extractvalue { i64, ptr } %t765, 0
  %t768 = add i64 %t764, %t767
  %t769 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t769, 1
  %t771 = extractvalue { i64, ptr } %t769, 0
  %t772 = add i64 %t768, %t771
  %t773 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t774 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t775 = add i64 %t772, %t774
  %t776 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t775)
  call void @olang_textcopy(ptr %t776, ptr %t763, i64 %t764)
  %t777 = getelementptr i8, ptr %t776, i64 %t764
  call void @olang_textcopy(ptr %t777, ptr %t766, i64 %t767)
  %t778 = getelementptr i8, ptr %t777, i64 %t767
  call void @olang_textcopy(ptr %t778, ptr %t770, i64 %t771)
  %t779 = getelementptr i8, ptr %t778, i64 %t771
  call void @olang_textcopy(ptr %t779, ptr %t773, i64 %t774)
  %t780 = insertvalue { i64, ptr } undef, i64 %t775, 0
  %t781 = insertvalue { i64, ptr } %t780, ptr %t776, 1
  %t783 = extractvalue { i64, ptr } %t781, 0
  %t784 = extractvalue { i64, ptr } %t781, 1
  %t785 = mul i64 %t783, 1
  %t786 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t785)
  call void @llvm.memcpy.p0.p0.i64(ptr %t786, ptr %t784, i64 %t785, i1 false)
  %t787 = insertvalue { i64, ptr } undef, i64 %t783, 0
  %t788 = insertvalue { i64, ptr } %t787, ptr %t786, 1
  %t789 = load ptr, ptr %l348, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s31, ptr %t789, { i64, ptr } %t788)
  br label %bb148
bb148:
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t793 = getelementptr %"compiler/check:Checker", ptr %t791, i32 0, i32 1
  %t794 = load ptr, ptr %t793, !tbaa !29
  %t796 = getelementptr %"compiler/generic:Program", ptr %t794, i32 0, i32 2
  store ptr %t796, ptr %l357, !tbaa !29
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t799 = getelementptr %"compiler/check:Checker", ptr %t797, i32 0, i32 1
  %t800 = load ptr, ptr %t799, !tbaa !29
  %t802 = getelementptr %"compiler/generic:Program", ptr %t800, i32 0, i32 2
  %t803 = load i32, ptr %l3, !tbaa !23
  %t806 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t802, i32 %t803)
  store i32 %t806, ptr %l362
  br label %bb149
bb149:
  %t807 = load ptr, ptr %l357, !tbaa !29
  %t808 = load i32, ptr %l362, !tbaa !23
  %t809 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t807, i32 %t808)
  store { i64, ptr } %t809, ptr %l363
  br label %bb150
bb150:
  %t810 = load { i64, ptr }, ptr %l363, !tbaa !27
  store { i64, ptr } %t810, ptr %l37, !tbaa !27
  %t811 = load ptr, ptr %l0, !tbaa !29
  %t813 = getelementptr %"compiler/check:Checker", ptr %t811, i32 0, i32 1
  %t814 = load ptr, ptr %t813, !tbaa !29
  %t816 = getelementptr %"compiler/generic:Program", ptr %t814, i32 0, i32 2
  %t817 = load i32, ptr %l3, !tbaa !23
  %t820 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s31, ptr %t816, i32 %t817)
  store { i64, ptr } %t820, ptr %l368
  br label %bb151
bb151:
  %t821 = load { i64, ptr }, ptr %l368, !tbaa !27
  store { i64, ptr } %t821, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t822 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t824 = extractvalue { i64, ptr } %t822, 0
  store i64 %t824, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t826 = load i64, ptr %l40, !tbaa !24
  %t827 = load i64, ptr %l39, !tbaa !24
  %t830 = icmp sgt i64 %t826, %t827
  br i1 %t830, label %bb152, label %bb153
bb152:
  %t832 = load i64, ptr %l41, !tbaa !24
  %t834 = icmp sgt i64 %t832, 0
  br i1 %t834, label %bb154, label %bb155
bb153:
  store i64 0, ptr %l374, !tbaa !24
  br label %bb157
bb154:
  %t836 = load i64, ptr %l40, !tbaa !24
  %t837 = load i64, ptr %l39, !tbaa !24
  %t840 = sub i64 %t836, %t837
  %t841 = load i64, ptr %l41, !tbaa !24
  %t844 = add i64 %t840, %t841
  %t846 = sub i64 %t844, 1
  %t847 = load i64, ptr %l41, !tbaa !24
  %t850 = sdiv i64 %t846, %t847
  store i64 %t850, ptr %l377, !tbaa !24
  br label %bb156
bb155:
  store i64 0, ptr %l377, !tbaa !24
  br label %bb156
bb156:
  %t852 = load i64, ptr %l377, !tbaa !24
  store i64 %t852, ptr %l374, !tbaa !24
  br label %bb157
bb157:
  %t853 = load i64, ptr %l374, !tbaa !24
  store i64 %t853, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb158
bb158:
  store %olang.scope zeroinitializer, ptr %s34
  %t854 = load i64, ptr %l43, !tbaa !24
  %t855 = load i64, ptr %l42, !tbaa !24
  %t858 = icmp slt i64 %t854, %t855
  %t860 = xor i1 %t858, true
  br i1 %t860, label %bb159, label %bb160
bb159:
  call void @__olang_scope_close(ptr %s34)
  br label %bb177
bb160:
  br label %bb161
bb161:
  %t862 = load i64, ptr %l39, !tbaa !24
  %t863 = load i64, ptr %l43, !tbaa !24
  %t864 = load i64, ptr %l41, !tbaa !24
  %t867 = mul i64 %t863, %t864
  %t870 = add i64 %t862, %t867
  store i64 %t870, ptr %l44, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s34, ptr %l2, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d119, i32 0, i32 1) })
  br label %bb162
bb162:
  store ptr %l2, ptr %l396, !tbaa !29
  %t873 = load ptr, ptr %l0, !tbaa !29
  store ptr %t873, ptr %l397, !tbaa !29
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t876 = getelementptr %"compiler/check:Checker", ptr %t874, i32 0, i32 1
  %t877 = load ptr, ptr %t876, !tbaa !29
  %t878 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t879 = load i32, ptr %l3, !tbaa !23
  %t880 = load i64, ptr %l44, !tbaa !24
  %t885 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %t877, i64 %t878, i32 %t879, i64 %t880, i64 0)
  store i32 %t885, ptr %l403
  br label %bb163
bb163:
  %t886 = load ptr, ptr %l397, !tbaa !29
  %t887 = load i32, ptr %l403, !tbaa !23
  %t888 = call { i64, ptr } @compiler_2fexplain_2eattrsBefore(ptr %v0, ptr %s34, ptr %t886, i32 %t887)
  store { i64, ptr } %t888, ptr %l404
  br label %bb164
bb164:
  %t889 = load { i64, ptr }, ptr %l404, !tbaa !27
  %t890 = extractvalue { i64, ptr } %t889, 0
  %t891 = extractvalue { i64, ptr } %t889, 1
  %t892 = mul i64 %t890, 1
  %t893 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t892)
  call void @llvm.memcpy.p0.p0.i64(ptr %t893, ptr %t891, i64 %t892, i1 false)
  %t894 = insertvalue { i64, ptr } undef, i64 %t890, 0
  %t895 = insertvalue { i64, ptr } %t894, ptr %t893, 1
  %t896 = load ptr, ptr %l396, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s34, ptr %t896, { i64, ptr } %t895)
  br label %bb165
bb165:
  store ptr %l2, ptr %l406, !tbaa !29
  %t898 = load ptr, ptr %l5, !tbaa !29
  %t899 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t899, ptr %l408, !tbaa !27
  %t900 = load i64, ptr %l44, !tbaa !24
  %t902 = getelementptr { i64, ptr }, ptr %l408, i32 0, i32 1
  %t903 = load ptr, ptr %t902, !tbaa !27
  %t904 = getelementptr i32, ptr %t903, i64 %t900
  %t905 = load i32, ptr %t904, !tbaa !33
  %t908 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t898, i32 %t905)
  store { i64, ptr } %t908, ptr %l411
  br label %bb166
bb166:
  %t909 = load ptr, ptr %l406, !tbaa !29
  %t910 = load { i64, ptr }, ptr %l411, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t909, { i64, ptr } %t910)
  br label %bb167
bb167:
  %t911 = load i64, ptr %l44, !tbaa !24
  %t912 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t914 = extractvalue { i64, ptr } %t912, 0
  %t917 = icmp slt i64 %t911, %t914
  br i1 %t917, label %bb168, label %bb169
bb168:
  %t919 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t919, ptr %l417, !tbaa !27
  %t920 = load i64, ptr %l44, !tbaa !24
  %t922 = getelementptr { i64, ptr }, ptr %l417, i32 0, i32 1
  %t923 = load ptr, ptr %t922, !tbaa !27
  %t924 = getelementptr i32, ptr %t923, i64 %t920
  %t925 = load i32, ptr %t924, !tbaa !33
  %t927 = icmp ne i32 %t925, 0
  store i1 %t927, ptr %l416, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l416, !tbaa !21
  br label %bb170
bb170:
  %t929 = load i1, ptr %l416, !tbaa !21
  br i1 %t929, label %bb171, label %bb172
bb171:
  %t930 = load ptr, ptr %l0, !tbaa !29
  %t931 = load i32, ptr %l1, !tbaa !23
  %t932 = load i32, ptr %l3, !tbaa !23
  %t933 = load i64, ptr %l44, !tbaa !24
  call void @compiler_2fexplain_2epushPayload(ptr %s0, ptr %v0, ptr %l2, ptr %t930, i32 %t931, i32 %t932, i64 %t933)
  br label %bb173
bb172:
  br label %bb174
bb173:
  br label %bb174
bb174:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s34)
  br label %bb176
bb176:
  %t940 = load i64, ptr %l43, !tbaa !24
  %t942 = add i64 %t940, 1
  store i64 %t942, ptr %l43, !tbaa !24
  br label %bb158
bb177:
  call void @__olang_scope_close(ptr %s31)
  br label %bb295
bb178:
  %t944 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t946 = trunc i64 4 to i32
  %t947 = icmp eq i32 %t944, %t946
  br i1 %t947, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  br label %bb231
bb181:
  store %olang.scope zeroinitializer, ptr %s37
  %t949 = load ptr, ptr %l0, !tbaa !29
  %t951 = getelementptr %"compiler/check:Checker", ptr %t949, i32 0, i32 1
  %t952 = load ptr, ptr %t951, !tbaa !29
  %t954 = getelementptr %"compiler/generic:Program", ptr %t952, i32 0, i32 2
  %t955 = load i32, ptr %l3, !tbaa !23
  %t958 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t954, i32 %t955)
  store i32 %t958, ptr %l435
  br label %bb182
bb182:
  %t959 = load i32, ptr %l435, !tbaa !23
  store i32 %t959, ptr %l45, !tbaa !23
  store ptr %l2, ptr %l436, !tbaa !29
  %t960 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t960, ptr %l437, !tbaa !27
  %t961 = load ptr, ptr %l0, !tbaa !29
  %t962 = load i32, ptr %l3, !tbaa !23
  %t965 = call { i64, ptr } @compiler_2fexplain_2edeclWord(ptr %v0, ptr %s37, ptr %t961, i32 %t962)
  store { i64, ptr } %t965, ptr %l440
  br label %bb183
bb183:
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t968 = getelementptr %"compiler/check:Checker", ptr %t966, i32 0, i32 1
  %t969 = load ptr, ptr %t968, !tbaa !29
  %t970 = load i32, ptr %l3, !tbaa !23
  %t973 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t969, i32 %t970)
  store i1 %t973, ptr %l444
  br label %bb184
bb184:
  %t974 = load i1, ptr %l444, !tbaa !21
  br i1 %t974, label %bb185, label %bb186
bb185:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d120, i32 0, i32 1) }, ptr %l445, !tbaa !27
  br label %bb187
bb186:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) }, ptr %l445, !tbaa !27
  br label %bb187
bb187:
  %t975 = load ptr, ptr %l0, !tbaa !29
  %t977 = getelementptr %"compiler/check:Checker", ptr %t975, i32 0, i32 1
  %t978 = load ptr, ptr %t977, !tbaa !29
  %t980 = getelementptr %"compiler/generic:Program", ptr %t978, i32 0, i32 2
  %t981 = load i32, ptr %l45, !tbaa !23
  %t984 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t980, i32 %t981)
  store i32 %t984, ptr %l450
  br label %bb188
bb188:
  %t985 = load i32, ptr %l450, !range !{i32 0, i32 33}
  %t987 = trunc i64 21 to i32
  %t988 = icmp eq i32 %t985, %t987
  br i1 %t988, label %bb189, label %bb190
bb189:
  %t990 = load ptr, ptr %l0, !tbaa !29
  %t991 = load i32, ptr %l45, !tbaa !23
  %t994 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %s37, ptr %t990, i32 %t991)
  store { i64, ptr } %t994, ptr %l456
  br label %bb191
bb190:
  %t995 = load ptr, ptr %l0, !tbaa !29
  %t996 = load i32, ptr %l45, !tbaa !23
  %t999 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s37, ptr %t995, i32 %t996)
  store { i64, ptr } %t999, ptr %l459
  br label %bb192
bb191:
  %t1000 = load { i64, ptr }, ptr %l456, !tbaa !27
  store { i64, ptr } %t1000, ptr %l453, !tbaa !27
  br label %bb193
bb192:
  %t1001 = load { i64, ptr }, ptr %l459, !tbaa !27
  store { i64, ptr } %t1001, ptr %l453, !tbaa !27
  br label %bb193
bb193:
  %t1002 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t1003 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t1004 = load { i64, ptr }, ptr %l437, !tbaa !27
  %t1005 = extractvalue { i64, ptr } %t1004, 1
  %t1006 = extractvalue { i64, ptr } %t1004, 0
  %t1007 = add i64 %t1003, %t1006
  %t1008 = load { i64, ptr }, ptr %l440, !tbaa !27
  %t1009 = extractvalue { i64, ptr } %t1008, 1
  %t1010 = extractvalue { i64, ptr } %t1008, 0
  %t1011 = add i64 %t1007, %t1010
  %t1012 = load { i64, ptr }, ptr %l445, !tbaa !27
  %t1013 = extractvalue { i64, ptr } %t1012, 1
  %t1014 = extractvalue { i64, ptr } %t1012, 0
  %t1015 = add i64 %t1011, %t1014
  %t1016 = load { i64, ptr }, ptr %l453, !tbaa !27
  %t1017 = extractvalue { i64, ptr } %t1016, 1
  %t1018 = extractvalue { i64, ptr } %t1016, 0
  %t1019 = add i64 %t1015, %t1018
  %t1020 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1019)
  call void @olang_textcopy(ptr %t1020, ptr %t1002, i64 %t1003)
  %t1021 = getelementptr i8, ptr %t1020, i64 %t1003
  call void @olang_textcopy(ptr %t1021, ptr %t1005, i64 %t1006)
  %t1022 = getelementptr i8, ptr %t1021, i64 %t1006
  call void @olang_textcopy(ptr %t1022, ptr %t1009, i64 %t1010)
  %t1023 = getelementptr i8, ptr %t1022, i64 %t1010
  call void @olang_textcopy(ptr %t1023, ptr %t1013, i64 %t1014)
  %t1024 = getelementptr i8, ptr %t1023, i64 %t1014
  call void @olang_textcopy(ptr %t1024, ptr %t1017, i64 %t1018)
  %t1025 = insertvalue { i64, ptr } undef, i64 %t1019, 0
  %t1026 = insertvalue { i64, ptr } %t1025, ptr %t1020, 1
  %t1028 = extractvalue { i64, ptr } %t1026, 0
  %t1029 = extractvalue { i64, ptr } %t1026, 1
  %t1030 = mul i64 %t1028, 1
  %t1031 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1030)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1031, ptr %t1029, i64 %t1030, i1 false)
  %t1032 = insertvalue { i64, ptr } undef, i64 %t1028, 0
  %t1033 = insertvalue { i64, ptr } %t1032, ptr %t1031, 1
  %t1034 = load ptr, ptr %l436, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s37, ptr %t1034, { i64, ptr } %t1033)
  br label %bb194
bb194:
  %t1036 = load ptr, ptr %l0, !tbaa !29
  %t1038 = getelementptr %"compiler/check:Checker", ptr %t1036, i32 0, i32 1
  %t1039 = load ptr, ptr %t1038, !tbaa !29
  %t1040 = load i32, ptr %l1, !tbaa !23
  %t1043 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t1039, i32 %t1040)
  store ptr %t1043, ptr %l465
  br label %bb195
bb195:
  %t1044 = load ptr, ptr %l465, !tbaa !29
  store ptr %t1044, ptr %l46, !tbaa !29
  %t1045 = load ptr, ptr %l46, !tbaa !29
  %t1047 = icmp eq ptr %t1045, null
  br i1 %t1047, label %bb196, label %bb197
bb196:
  call void @__olang_check_failed(ptr @olang_loc_12615553f525a8d6_4928bb51d62e2722)
  unreachable
bb197:
  br label %bb198
bb198:
  %t1049 = load ptr, ptr %l46, !tbaa !29
  %t1052 = getelementptr %"compiler/ast:TypeDecl", ptr %t1049, i32 0, i32 3
  %t1053 = load ptr, ptr %t1052, !tbaa !29
  store ptr %t1053, ptr %l47, !tbaa !29
  %t1055 = load ptr, ptr %l47, !tbaa !29
  store ptr %t1055, ptr %l471, !tbaa !29
  store i1 false, ptr %l472, !tbaa !21
  %t1056 = load ptr, ptr %l471, !tbaa !29
  %t1057 = icmp ne ptr %t1056, null
  br i1 %t1057, label %bb199, label %bb200
bb199:
  %t1059 = load ptr, ptr %l471, !tbaa !29
  %t1060 = load i64, ptr %t1059, !range !{i64 0, i64 5}
  %t1062 = icmp eq i64 %t1060, 3
  store i1 %t1062, ptr %l472, !tbaa !21
  br label %bb200
bb200:
  %t1063 = load i1, ptr %l472, !tbaa !21
  br i1 %t1063, label %bb201, label %bb202
bb201:
  %t1064 = load ptr, ptr %l47, !tbaa !29
  %t1066 = getelementptr { i64, [6 x i64] }, ptr %t1064, i32 0, i32 1
  %t1067 = getelementptr { ptr, ptr }, ptr %t1066, i32 0, i32 1
  %t1068 = load ptr, ptr %t1067
  store ptr %t1068, ptr %l48, !tbaa !29
  br label %bb203
bb202:
  br label %bb224
bb203:
  %t1070 = load ptr, ptr %l48, !tbaa !29
  %t1072 = icmp eq ptr %t1070, null
  %t1074 = xor i1 %t1072, true
  br i1 %t1074, label %bb204, label %bb205
bb204:
  store %olang.scope zeroinitializer, ptr %s39
  %t1076 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1076, ptr %l480, !tbaa !29
  %t1077 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1077, ptr %l481, !tbaa !29
  %t1078 = load ptr, ptr %l0, !tbaa !29
  %t1080 = getelementptr %"compiler/check:Checker", ptr %t1078, i32 0, i32 1
  %t1081 = load ptr, ptr %t1080, !tbaa !29
  %t1082 = load i32, ptr %l3, !tbaa !23
  %t1085 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t1081, i32 %t1082)
  store i32 %t1085, ptr %l485
  br label %bb206
bb205:
  br label %bb224
bb206:
  %t1086 = load ptr, ptr %l48, !tbaa !29
  %t1088 = getelementptr %"compiler/ast:Func", ptr %t1086, i32 0, i32 3
  %t1089 = load ptr, ptr %t1088, !tbaa !29
  %t1091 = getelementptr %"compiler/ast:Sig", ptr %t1089, i32 0, i32 0
  %t1092 = load { i64, ptr }, ptr %t1091, !tbaa !27
  %t1093 = load ptr, ptr %l481, !tbaa !29
  %t1094 = load i32, ptr %l485, !tbaa !23
  %t1096 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s39, ptr %v0, ptr %t1093, i32 %t1094, ptr null, { i64, ptr } %t1092)
  store i32 %t1096, ptr %l489
  br label %bb207
bb207:
  %t1097 = load ptr, ptr %l480, !tbaa !29
  %t1098 = load i32, ptr %l489, !tbaa !23
  %t1099 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %s39, ptr %t1097, i32 %t1098)
  store { i64, ptr } %t1099, ptr %l490
  br label %bb208
bb208:
  %t1100 = load { i64, ptr }, ptr %l490, !tbaa !27
  store { i64, ptr } %t1100, ptr %l49, !tbaa !27
  %t1101 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1103 = call i64 @compiler_2fexplain_2efirstClose(ptr %s39, { i64, ptr } %t1101)
  store i64 %t1103, ptr %l492
  br label %bb209
bb209:
  %t1104 = load i64, ptr %l492, !tbaa !24
  store i64 %t1104, ptr %l50, !tbaa !24
  store ptr %l2, ptr %l493, !tbaa !29
  %t1105 = load i64, ptr %l50, !tbaa !24
  %t1107 = add i64 %t1105, 1
  store i64 %t1107, ptr %l495, !tbaa !24
  %t1108 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1109 = extractvalue { i64, ptr } %t1108, 0
  store i64 %t1109, ptr %l496, !tbaa !24
  %t1110 = icmp sge i64 2, 0
  br i1 %t1110, label %bb210, label %bb211
bb210:
  %t1112 = load i64, ptr %l495, !tbaa !24
  %t1113 = icmp sle i64 2, %t1112
  br i1 %t1113, label %bb212, label %bb213
bb211:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb212:
  %t1115 = load i64, ptr %l495, !tbaa !24
  %t1116 = load i64, ptr %l496, !tbaa !24
  %t1117 = icmp sle i64 %t1115, %t1116
  br i1 %t1117, label %bb214, label %bb215
bb213:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb214:
  %t1119 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t1120 = load ptr, ptr %t1119, !tbaa !27
  %t1121 = load i64, ptr %l495, !tbaa !24
  %t1122 = getelementptr i8, ptr %t1120, i64 2
  %t1123 = sub i64 %t1121, 2
  %t1124 = insertvalue { i64, ptr } undef, i64 %t1123, 0
  %t1125 = insertvalue { i64, ptr } %t1124, ptr %t1122, 1
  store { i64, ptr } %t1125, ptr %l500, !tbaa !27
  %t1126 = load i64, ptr %l50, !tbaa !24
  %t1128 = add i64 %t1126, 1
  store i64 %t1128, ptr %l502, !tbaa !24
  %t1129 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1131 = extractvalue { i64, ptr } %t1129, 0
  store i64 %t1131, ptr %l504, !tbaa !24
  %t1132 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1133 = extractvalue { i64, ptr } %t1132, 0
  store i64 %t1133, ptr %l505, !tbaa !24
  %t1134 = load i64, ptr %l502, !tbaa !24
  %t1135 = icmp sge i64 %t1134, 0
  br i1 %t1135, label %bb216, label %bb217
bb215:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb216:
  %t1137 = load i64, ptr %l502, !tbaa !24
  %t1138 = load i64, ptr %l504, !tbaa !24
  %t1139 = icmp sle i64 %t1137, %t1138
  br i1 %t1139, label %bb218, label %bb219
bb217:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb218:
  %t1141 = load i64, ptr %l504, !tbaa !24
  %t1142 = load i64, ptr %l505, !tbaa !24
  %t1143 = icmp sle i64 %t1141, %t1142
  br i1 %t1143, label %bb220, label %bb221
bb219:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb220:
  %t1145 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t1146 = load ptr, ptr %t1145, !tbaa !27
  %t1147 = load i64, ptr %l502, !tbaa !24
  %t1148 = load i64, ptr %l504, !tbaa !24
  %t1149 = getelementptr i8, ptr %t1146, i64 %t1147
  %t1150 = sub i64 %t1148, %t1147
  %t1151 = insertvalue { i64, ptr } undef, i64 %t1150, 0
  %t1152 = insertvalue { i64, ptr } %t1151, ptr %t1149, 1
  %t1154 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s39, ptr %s39, { i64, ptr } %t1152)
  store { i64, ptr } %t1154, ptr %l510
  br label %bb222
bb221:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb222:
  %t1155 = load { i64, ptr }, ptr %l510, !tbaa !27
  %t1156 = extractvalue { i64, ptr } %t1155, 0
  store i64 %t1156, ptr %l511, !tbaa !24
  %t1157 = load i64, ptr %l511, !tbaa !24
  %t1158 = mul i64 %t1157, 1
  %t1159 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1158)
  %t1160 = insertvalue { i64, ptr } undef, i64 %t1157, 0
  %t1161 = insertvalue { i64, ptr } %t1160, ptr %t1159, 1
  store { i64, ptr } %t1161, ptr %l512, !tbaa !27
  %t1162 = getelementptr { i64, ptr }, ptr %l512, i32 0, i32 1
  %t1163 = load ptr, ptr %t1162, !tbaa !27
  %t1164 = getelementptr { i64, ptr }, ptr %l510, i32 0, i32 1
  %t1165 = load ptr, ptr %t1164, !tbaa !27
  %t1166 = load i64, ptr %l511, !tbaa !24
  %t1167 = mul i64 %t1166, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1163, ptr %t1165, i64 %t1167, i1 false)
  %t1168 = load { i64, ptr }, ptr %l500, !tbaa !27
  %t1169 = extractvalue { i64, ptr } %t1168, 1
  %t1170 = extractvalue { i64, ptr } %t1168, 0
  %t1171 = load { i64, ptr }, ptr %l512, !tbaa !27
  %t1172 = extractvalue { i64, ptr } %t1171, 1
  %t1173 = extractvalue { i64, ptr } %t1171, 0
  %t1174 = add i64 %t1170, %t1173
  %t1175 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1174)
  call void @olang_textcopy(ptr %t1175, ptr %t1169, i64 %t1170)
  %t1176 = getelementptr i8, ptr %t1175, i64 %t1170
  call void @olang_textcopy(ptr %t1176, ptr %t1172, i64 %t1173)
  %t1177 = insertvalue { i64, ptr } undef, i64 %t1174, 0
  %t1178 = insertvalue { i64, ptr } %t1177, ptr %t1175, 1
  %t1180 = extractvalue { i64, ptr } %t1178, 0
  %t1181 = extractvalue { i64, ptr } %t1178, 1
  %t1182 = mul i64 %t1180, 1
  %t1183 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1183, ptr %t1181, i64 %t1182, i1 false)
  %t1184 = insertvalue { i64, ptr } undef, i64 %t1180, 0
  %t1185 = insertvalue { i64, ptr } %t1184, ptr %t1183, 1
  %t1186 = load ptr, ptr %l493, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %t1186, { i64, ptr } %t1185)
  br label %bb223
bb223:
  call void @__olang_scope_close(ptr %s39)
  br label %bb229
bb224:
  br i1 true, label %bb225, label %bb226
bb225:
  br label %bb227
bb226:
  br label %bb228
bb227:
  br label %bb229
bb228:
  call void @__olang_check_failed(ptr @olang_loc_6531017cd55dbf94_87ab3d542028c5d8)
  unreachable
bb229:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb230
bb230:
  call void @__olang_scope_close(ptr %s37)
  br label %bb295
bb231:
  %t1189 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t1191 = trunc i64 0 to i32
  %t1192 = icmp eq i32 %t1189, %t1191
  br i1 %t1192, label %bb232, label %bb233
bb232:
  br label %bb234
bb233:
  br label %bb294
bb234:
  store %olang.scope zeroinitializer, ptr %s42
  %t1194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1194, ptr %l518, !tbaa !29
  %t1195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1195, ptr %l519, !tbaa !29
  %t1196 = load ptr, ptr %l0, !tbaa !29
  %t1198 = getelementptr %"compiler/check:Checker", ptr %t1196, i32 0, i32 1
  %t1199 = load ptr, ptr %t1198, !tbaa !29
  %t1200 = load i32, ptr %l3, !tbaa !23
  %t1203 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t1199, i32 %t1200)
  store i32 %t1203, ptr %l523
  br label %bb235
bb235:
  %t1204 = load ptr, ptr %l0, !tbaa !29
  %t1206 = getelementptr %"compiler/check:Checker", ptr %t1204, i32 0, i32 1
  %t1207 = load ptr, ptr %t1206, !tbaa !29
  %t1208 = load i32, ptr %l1, !tbaa !23
  %t1211 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t1207, i32 %t1208)
  store ptr %t1211, ptr %l527
  br label %bb236
bb236:
  %t1212 = load ptr, ptr %l527, !tbaa !29
  store ptr %t1212, ptr %l51, !tbaa !29
  %t1213 = load ptr, ptr %l51, !tbaa !29
  %t1215 = icmp eq ptr %t1213, null
  br i1 %t1215, label %bb237, label %bb238
bb237:
  call void @__olang_check_failed(ptr @olang_loc_fdc41c6a76f01a06_9680a398378cbf4a)
  unreachable
bb238:
  br label %bb239
bb239:
  %t1217 = load ptr, ptr %l51, !tbaa !29
  %t1219 = call { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %s42, ptr %t1217)
  store { i64, ptr } %t1219, ptr %l531
  br label %bb240
bb240:
  %t1220 = load ptr, ptr %l519, !tbaa !29
  %t1221 = load i32, ptr %l523, !tbaa !23
  %t1222 = load { i64, ptr }, ptr %l531, !tbaa !27
  %t1223 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s42, ptr %s42, ptr %t1220, i32 %t1221, ptr null, { i64, ptr } %t1222)
  store i32 %t1223, ptr %l532
  br label %bb241
bb241:
  %t1224 = load ptr, ptr %l518, !tbaa !29
  %t1225 = load i32, ptr %l532, !tbaa !23
  %t1226 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %s42, ptr %t1224, i32 %t1225)
  store { i64, ptr } %t1226, ptr %l533
  br label %bb242
bb242:
  %t1227 = load { i64, ptr }, ptr %l533, !tbaa !27
  store { i64, ptr } %t1227, ptr %l52, !tbaa !27
  %t1228 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t1230 = call i64 @compiler_2fexplain_2efirstClose(ptr %s42, { i64, ptr } %t1228)
  store i64 %t1230, ptr %l535
  br label %bb243
bb243:
  %t1231 = load i64, ptr %l535, !tbaa !24
  store i64 %t1231, ptr %l53, !tbaa !24
  %t1232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1232, ptr %l536, !tbaa !29
  %t1233 = load i64, ptr %l53, !tbaa !24
  store i64 %t1233, ptr %l537, !tbaa !24
  %t1234 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t1235 = extractvalue { i64, ptr } %t1234, 0
  store i64 %t1235, ptr %l538, !tbaa !24
  %t1236 = icmp sge i64 3, 0
  br i1 %t1236, label %bb244, label %bb245
bb244:
  %t1238 = load i64, ptr %l537, !tbaa !24
  %t1239 = icmp sle i64 3, %t1238
  br i1 %t1239, label %bb246, label %bb247
bb245:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb246:
  %t1241 = load i64, ptr %l537, !tbaa !24
  %t1242 = load i64, ptr %l538, !tbaa !24
  %t1243 = icmp sle i64 %t1241, %t1242
  br i1 %t1243, label %bb248, label %bb249
bb247:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb248:
  %t1245 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t1246 = load ptr, ptr %t1245, !tbaa !27
  %t1247 = load i64, ptr %l537, !tbaa !24
  %t1248 = getelementptr i8, ptr %t1246, i64 3
  %t1249 = sub i64 %t1247, 3
  %t1250 = insertvalue { i64, ptr } undef, i64 %t1249, 0
  %t1251 = insertvalue { i64, ptr } %t1250, ptr %t1248, 1
  store { i64, ptr } %t1251, ptr %l542, !tbaa !27
  %t1252 = load ptr, ptr %l0, !tbaa !29
  %t1254 = getelementptr %"compiler/check:Checker", ptr %t1252, i32 0, i32 1
  %t1255 = load ptr, ptr %t1254, !tbaa !29
  %t1256 = load i32, ptr %l1, !tbaa !23
  %t1259 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t1255, i32 %t1256)
  store ptr %t1259, ptr %l546
  br label %bb250
bb249:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb250:
  %t1260 = load ptr, ptr %l546, !tbaa !29
  store ptr %t1260, ptr %l54, !tbaa !29
  %t1261 = load ptr, ptr %l54, !tbaa !29
  %t1263 = icmp eq ptr %t1261, null
  br i1 %t1263, label %bb251, label %bb252
bb251:
  call void @__olang_check_failed(ptr @olang_loc_5a4859640df0add8_178cc34ee3f1765c)
  unreachable
bb252:
  br label %bb253
bb253:
  %t1265 = load ptr, ptr %l54, !tbaa !29
  %t1267 = call { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %s42, ptr %t1265)
  store { i64, ptr } %t1267, ptr %l550
  br label %bb254
bb254:
  %t1268 = load ptr, ptr %l0, !tbaa !29
  %t1270 = getelementptr %"compiler/check:Checker", ptr %t1268, i32 0, i32 1
  %t1271 = load ptr, ptr %t1270, !tbaa !29
  %t1272 = load i32, ptr %l1, !tbaa !23
  %t1275 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t1271, i32 %t1272)
  store i64 %t1275, ptr %l554
  br label %bb255
bb255:
  %t1276 = load ptr, ptr %l536, !tbaa !29
  %t1277 = load { i64, ptr }, ptr %l542, !tbaa !27
  %t1278 = load { i64, ptr }, ptr %l550, !tbaa !27
  %t1279 = load i64, ptr %l554, !tbaa !24
  %t1280 = call { i64, ptr } @compiler_2fexplain_2ewithDefaults(ptr %v0, ptr %s42, ptr %s42, ptr %s42, ptr %t1276, { i64, ptr } %t1277, { i64, ptr } %t1278, i64 %t1279, i64 0)
  store { i64, ptr } %t1280, ptr %l555
  br label %bb256
bb256:
  %t1281 = load { i64, ptr }, ptr %l555, !tbaa !27
  store { i64, ptr } %t1281, ptr %l55, !tbaa !27
  store ptr %l2, ptr %l556, !tbaa !29
  %t1282 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t1282, ptr %l557, !tbaa !27
  %t1283 = load ptr, ptr %l0, !tbaa !29
  %t1284 = load i32, ptr %l3, !tbaa !23
  %t1287 = call { i64, ptr } @compiler_2fexplain_2edeclWord(ptr %v0, ptr %s42, ptr %t1283, i32 %t1284)
  store { i64, ptr } %t1287, ptr %l560
  br label %bb257
bb257:
  %t1288 = load ptr, ptr %l0, !tbaa !29
  %t1290 = getelementptr %"compiler/check:Checker", ptr %t1288, i32 0, i32 1
  %t1291 = load ptr, ptr %t1290, !tbaa !29
  %t1293 = getelementptr %"compiler/generic:Program", ptr %t1291, i32 0, i32 2
  %t1294 = load i32, ptr %l3, !tbaa !23
  %t1297 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t1293, i32 %t1294)
  store i1 %t1297, ptr %l565
  br label %bb258
bb258:
  %t1298 = load i1, ptr %l565, !tbaa !21
  br i1 %t1298, label %bb259, label %bb260
bb259:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d123, i32 0, i32 1) }, ptr %l566, !tbaa !27
  br label %bb261
bb260:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d124, i32 0, i32 1) }, ptr %l566, !tbaa !27
  br label %bb261
bb261:
  %t1299 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t1299, ptr %l567, !tbaa !27
  %t1300 = load i64, ptr %l53, !tbaa !24
  %t1302 = add i64 %t1300, 1
  store i64 %t1302, ptr %l569, !tbaa !24
  %t1303 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t1305 = extractvalue { i64, ptr } %t1303, 0
  store i64 %t1305, ptr %l571, !tbaa !24
  %t1306 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t1307 = extractvalue { i64, ptr } %t1306, 0
  store i64 %t1307, ptr %l572, !tbaa !24
  %t1308 = load i64, ptr %l569, !tbaa !24
  %t1309 = icmp sge i64 %t1308, 0
  br i1 %t1309, label %bb262, label %bb263
bb262:
  %t1311 = load i64, ptr %l569, !tbaa !24
  %t1312 = load i64, ptr %l571, !tbaa !24
  %t1313 = icmp sle i64 %t1311, %t1312
  br i1 %t1313, label %bb264, label %bb265
bb263:
  call void @__olang_check_failed(ptr @olang_loc_731041b9517c977f_a1670725ff3ccc5b)
  unreachable
bb264:
  %t1315 = load i64, ptr %l571, !tbaa !24
  %t1316 = load i64, ptr %l572, !tbaa !24
  %t1317 = icmp sle i64 %t1315, %t1316
  br i1 %t1317, label %bb266, label %bb267
bb265:
  call void @__olang_check_failed(ptr @olang_loc_731041b9517c977f_a1670725ff3ccc5b)
  unreachable
bb266:
  %t1319 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t1320 = load ptr, ptr %t1319, !tbaa !27
  %t1321 = load i64, ptr %l569, !tbaa !24
  %t1322 = load i64, ptr %l571, !tbaa !24
  %t1323 = getelementptr i8, ptr %t1320, i64 %t1321
  %t1324 = sub i64 %t1322, %t1321
  %t1325 = insertvalue { i64, ptr } undef, i64 %t1324, 0
  %t1326 = insertvalue { i64, ptr } %t1325, ptr %t1323, 1
  %t1328 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s42, ptr %s42, { i64, ptr } %t1326)
  store { i64, ptr } %t1328, ptr %l577
  br label %bb268
bb267:
  call void @__olang_check_failed(ptr @olang_loc_731041b9517c977f_a1670725ff3ccc5b)
  unreachable
bb268:
  %t1329 = load { i64, ptr }, ptr %l577, !tbaa !27
  %t1330 = extractvalue { i64, ptr } %t1329, 0
  store i64 %t1330, ptr %l578, !tbaa !24
  %t1331 = load i64, ptr %l578, !tbaa !24
  %t1332 = mul i64 %t1331, 1
  %t1333 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t1332)
  %t1334 = insertvalue { i64, ptr } undef, i64 %t1331, 0
  %t1335 = insertvalue { i64, ptr } %t1334, ptr %t1333, 1
  store { i64, ptr } %t1335, ptr %l579, !tbaa !27
  %t1336 = getelementptr { i64, ptr }, ptr %l579, i32 0, i32 1
  %t1337 = load ptr, ptr %t1336, !tbaa !27
  %t1338 = getelementptr { i64, ptr }, ptr %l577, i32 0, i32 1
  %t1339 = load ptr, ptr %t1338, !tbaa !27
  %t1340 = load i64, ptr %l578, !tbaa !24
  %t1341 = mul i64 %t1340, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1337, ptr %t1339, i64 %t1341, i1 false)
  %t1342 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t1343 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t1344 = load { i64, ptr }, ptr %l557, !tbaa !27
  %t1345 = extractvalue { i64, ptr } %t1344, 1
  %t1346 = extractvalue { i64, ptr } %t1344, 0
  %t1347 = add i64 %t1343, %t1346
  %t1348 = load { i64, ptr }, ptr %l560, !tbaa !27
  %t1349 = extractvalue { i64, ptr } %t1348, 1
  %t1350 = extractvalue { i64, ptr } %t1348, 0
  %t1351 = add i64 %t1347, %t1350
  %t1352 = load { i64, ptr }, ptr %l566, !tbaa !27
  %t1353 = extractvalue { i64, ptr } %t1352, 1
  %t1354 = extractvalue { i64, ptr } %t1352, 0
  %t1355 = add i64 %t1351, %t1354
  %t1356 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t1357 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t1358 = add i64 %t1355, %t1357
  %t1359 = load { i64, ptr }, ptr %l567, !tbaa !27
  %t1360 = extractvalue { i64, ptr } %t1359, 1
  %t1361 = extractvalue { i64, ptr } %t1359, 0
  %t1362 = add i64 %t1358, %t1361
  %t1363 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t1364 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t1365 = add i64 %t1362, %t1364
  %t1366 = load { i64, ptr }, ptr %l579, !tbaa !27
  %t1367 = extractvalue { i64, ptr } %t1366, 1
  %t1368 = extractvalue { i64, ptr } %t1366, 0
  %t1369 = add i64 %t1365, %t1368
  %t1370 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t1371 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t1372 = add i64 %t1369, %t1371
  %t1373 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t1372)
  call void @olang_textcopy(ptr %t1373, ptr %t1342, i64 %t1343)
  %t1374 = getelementptr i8, ptr %t1373, i64 %t1343
  call void @olang_textcopy(ptr %t1374, ptr %t1345, i64 %t1346)
  %t1375 = getelementptr i8, ptr %t1374, i64 %t1346
  call void @olang_textcopy(ptr %t1375, ptr %t1349, i64 %t1350)
  %t1376 = getelementptr i8, ptr %t1375, i64 %t1350
  call void @olang_textcopy(ptr %t1376, ptr %t1353, i64 %t1354)
  %t1377 = getelementptr i8, ptr %t1376, i64 %t1354
  call void @olang_textcopy(ptr %t1377, ptr %t1356, i64 %t1357)
  %t1378 = getelementptr i8, ptr %t1377, i64 %t1357
  call void @olang_textcopy(ptr %t1378, ptr %t1360, i64 %t1361)
  %t1379 = getelementptr i8, ptr %t1378, i64 %t1361
  call void @olang_textcopy(ptr %t1379, ptr %t1363, i64 %t1364)
  %t1380 = getelementptr i8, ptr %t1379, i64 %t1364
  call void @olang_textcopy(ptr %t1380, ptr %t1367, i64 %t1368)
  %t1381 = getelementptr i8, ptr %t1380, i64 %t1368
  call void @olang_textcopy(ptr %t1381, ptr %t1370, i64 %t1371)
  %t1382 = insertvalue { i64, ptr } undef, i64 %t1372, 0
  %t1383 = insertvalue { i64, ptr } %t1382, ptr %t1373, 1
  %t1385 = extractvalue { i64, ptr } %t1383, 0
  %t1386 = extractvalue { i64, ptr } %t1383, 1
  %t1387 = mul i64 %t1385, 1
  %t1388 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t1387)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1388, ptr %t1386, i64 %t1387, i1 false)
  %t1389 = insertvalue { i64, ptr } undef, i64 %t1385, 0
  %t1390 = insertvalue { i64, ptr } %t1389, ptr %t1388, 1
  %t1391 = load ptr, ptr %l556, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s42, ptr %t1391, { i64, ptr } %t1390)
  br label %bb269
bb269:
  %t1393 = load ptr, ptr %l0, !tbaa !29
  %t1395 = getelementptr %"compiler/check:Checker", ptr %t1393, i32 0, i32 1
  %t1396 = load ptr, ptr %t1395, !tbaa !29
  %t1397 = load i32, ptr %l1, !tbaa !23
  %t1400 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t1396, i32 %t1397)
  store ptr %t1400, ptr %l585
  br label %bb270
bb270:
  %t1401 = load ptr, ptr %l585, !tbaa !29
  store ptr %t1401, ptr %l56, !tbaa !29
  %t1402 = load ptr, ptr %l56, !tbaa !29
  %t1404 = icmp eq ptr %t1402, null
  br i1 %t1404, label %bb271, label %bb272
bb271:
  call void @__olang_check_failed(ptr @olang_loc_b306a27fe8c8780a_4c00da05a7c42646)
  unreachable
bb272:
  br label %bb273
bb273:
  %t1406 = load ptr, ptr %l56, !tbaa !29
  %t1409 = getelementptr %"compiler/ast:TypeDecl", ptr %t1406, i32 0, i32 3
  %t1410 = load ptr, ptr %t1409, !tbaa !29
  store ptr %t1410, ptr %l57, !tbaa !29
  %t1412 = load ptr, ptr %l57, !tbaa !29
  store ptr %t1412, ptr %l591, !tbaa !29
  store i1 false, ptr %l592, !tbaa !21
  %t1413 = load ptr, ptr %l591, !tbaa !29
  %t1414 = icmp ne ptr %t1413, null
  br i1 %t1414, label %bb274, label %bb275
bb274:
  %t1416 = load ptr, ptr %l591, !tbaa !29
  %t1417 = load i64, ptr %t1416, !range !{i64 0, i64 5}
  %t1419 = icmp eq i64 %t1417, 0
  store i1 %t1419, ptr %l592, !tbaa !21
  br label %bb275
bb275:
  %t1420 = load i1, ptr %l592, !tbaa !21
  br i1 %t1420, label %bb276, label %bb277
bb276:
  %t1421 = load ptr, ptr %l57, !tbaa !29
  %t1423 = getelementptr { i64, [6 x i64] }, ptr %t1421, i32 0, i32 1
  %t1424 = getelementptr { ptr }, ptr %t1423, i32 0, i32 0
  %t1425 = load ptr, ptr %t1424
  store ptr %t1425, ptr %l58, !tbaa !29
  br label %bb278
bb277:
  br label %bb287
bb278:
  %t1427 = load ptr, ptr %l58, !tbaa !29
  %t1429 = getelementptr %"compiler/ast:StructBody", ptr %t1427, i32 0, i32 1
  %t1430 = load ptr, ptr %t1429, !tbaa !29
  %t1432 = icmp eq ptr %t1430, null
  %t1434 = xor i1 %t1432, true
  br i1 %t1434, label %bb279, label %bb280
bb279:
  store %olang.scope zeroinitializer, ptr %s45
  store ptr %l2, ptr %l601, !tbaa !29
  %t1436 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1436, ptr %l602, !tbaa !29
  %t1437 = load ptr, ptr %l58, !tbaa !29
  %t1439 = getelementptr %"compiler/ast:StructBody", ptr %t1437, i32 0, i32 1
  %t1440 = load ptr, ptr %t1439, !tbaa !29
  %t1442 = icmp eq ptr %t1440, null
  br i1 %t1442, label %bb281, label %bb282
bb280:
  br label %bb286
bb281:
  call void @__olang_check_failed(ptr @olang_loc_5d61f9982e85490b_19b97e7dc205ed37)
  unreachable
bb282:
  br label %bb283
bb283:
  %t1444 = load ptr, ptr %l58, !tbaa !29
  %t1446 = getelementptr %"compiler/ast:StructBody", ptr %t1444, i32 0, i32 1
  %t1447 = load ptr, ptr %t1446, !tbaa !29
  store ptr %t1447, ptr %l607, !tbaa !29
  %t1448 = load ptr, ptr %l0, !tbaa !29
  %t1450 = getelementptr %"compiler/check:Checker", ptr %t1448, i32 0, i32 1
  %t1451 = load ptr, ptr %t1450, !tbaa !29
  %t1452 = load i32, ptr %l1, !tbaa !23
  %t1455 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t1451, i32 %t1452)
  store i64 %t1455, ptr %l611
  br label %bb284
bb284:
  %t1456 = load ptr, ptr %l601, !tbaa !29
  %t1457 = load ptr, ptr %l602, !tbaa !29
  %t1458 = load ptr, ptr %l607, !tbaa !29
  %t1459 = load i64, ptr %l611, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s45, ptr %t1456, ptr %t1457, ptr %t1458, i64 %t1459, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) })
  br label %bb285
bb285:
  call void @__olang_scope_close(ptr %s45)
  br label %bb286
bb286:
  br label %bb292
bb287:
  br i1 true, label %bb288, label %bb289
bb288:
  br label %bb290
bb289:
  br label %bb291
bb290:
  br label %bb292
bb291:
  call void @__olang_check_failed(ptr @olang_loc_3df602fba2cf8b3_3b7d9b6ebe07120f)
  unreachable
bb292:
  %t1460 = load ptr, ptr %l0, !tbaa !29
  %t1461 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2efields(ptr %s0, ptr %v0, ptr %l2, ptr %t1460, i32 %t1461)
  br label %bb293
bb293:
  call void @__olang_scope_close(ptr %s42)
  br label %bb295
bb294:
  call void @__olang_check_failed(ptr @olang_loc_94295b17b6f8c92c_4d0fd7ff7c3c10d0)
  unreachable
bb295:
  %t1465 = load ptr, ptr %l0, !tbaa !29
  %t1466 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fexplain_2ebuilders(ptr %s0, ptr %v0, ptr %l2, ptr %t1465, i32 %t1466)
  br label %bb296
bb296:
  %t1470 = load ptr, ptr %l0, !tbaa !29
  %t1471 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2emethods(ptr %s0, ptr %v0, ptr %l2, ptr %t1470, i32 %t1471)
  br label %bb297
bb297:
  %t1475 = load ptr, ptr %l0, !tbaa !29
  %t1476 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2etraitsMet(ptr %s0, ptr %v0, ptr %l2, ptr %t1475, i32 %t1476)
  br label %bb298
bb298:
  %t1481 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t1481, ptr %l625
  br label %bb299
bb299:
  call void @__olang_scope_close(ptr %s0)
  %t1482 = load { i64, ptr }, ptr %l625, !tbaa !27
  store { i64, ptr } %t1482, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %a2)
  store i32 %t19, ptr %l12
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l5, !tbaa !29
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t20, i64 %t21, i32 %t22)
  store i64 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load i64, ptr %l13, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i32 -1, ptr %l16, !tbaa !23
  br label %bb6
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t38 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t32, i64 %t33, i64 %t34)
  store i32 %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = load i32, ptr %l21, !tbaa !23
  store i32 %t39, ptr %l16, !tbaa !23
  br label %bb6
bb6:
  %t40 = load i32, ptr %l16, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:varRow"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca i64
  %l37 = alloca i64
  %l59 = alloca %"compiler/generic:varRow"
  %l64 = alloca i1
  %l65 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l19
  br label %bb1
bb1:
  %t9 = load i64, ptr %l19, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sle i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d130, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t16, ptr %l24, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l25, !tbaa !24
  %t19 = load i64, ptr %l25, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l26, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l25, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t30, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t32 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t32, ptr %l27
  br label %bb5
bb5:
  %t33 = load %"std/prelude/text:StringBuilder", ptr %l27
  store %"std/prelude/text:StringBuilder" %t33, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 60)
  br label %bb6
bb6:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l37, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  br label %bb51
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t94 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t88, i64 %t89, i64 %t90)
  store %"compiler/generic:varRow" %t94, ptr %l59
  br label %bb17
bb17:
  %t95 = load %"compiler/generic:varRow", ptr %l59
  store %"compiler/generic:varRow" %t95, ptr %l11
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i64, ptr %l1, !tbaa !24
  %t101 = load i64, ptr %l10, !tbaa !24
  %t105 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %t99, i64 %t100, i64 %t101)
  store i1 %t105, ptr %l64
  br label %bb18
bb18:
  %t106 = load i1, ptr %l64, !tbaa !21
  br i1 %t106, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l4, ptr %l65, !tbaa !29
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l2, !tbaa !24
  %t111 = icmp sgt i64 %t107, %t108
  br i1 %t111, label %bb21, label %bb22
bb20:
  br label %bb26
bb21:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d131, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d132, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb23
bb23:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/load:Loader", ptr %t119, i32 0, i32 3
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t123 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 1
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s4, ptr %t122, i32 %t124)
  store { i64, ptr } %t127, ptr %l75
  br label %bb24
bb24:
  %t128 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = add i64 %t130, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t129, i64 %t130)
  %t136 = getelementptr i8, ptr %t135, i64 %t130
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t146 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t146, { i64, ptr } %t145)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb26:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t149 = load i64, ptr %l2, !tbaa !24
  %t152 = icmp sgt i64 %t148, %t149
  br i1 %t152, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l4, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  store ptr %l4, ptr %l82, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/generic:Program", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/load:Loader", ptr %t161, i32 0, i32 3
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t165 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 1
  %t166 = load i32, ptr %t165, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t164, i32 %t166)
  store { i64, ptr } %t169, ptr %l88
  br label %bb31
bb31:
  %t170 = load ptr, ptr %l82, !tbaa !29
  %t171 = load { i64, ptr }, ptr %l88, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t170, { i64, ptr } %t171)
  br label %bb32
bb32:
  %t172 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t173 = load i32, ptr %t172, !tbaa !23
  %t174 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t177 = icmp ne i32 %t173, %t174
  br i1 %t177, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l4, ptr %l92, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t181 = load i32, ptr %t180, !tbaa !23
  %t184 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s7, ptr %t179, i32 %t181)
  store { i64, ptr } %t184, ptr %l95
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t185 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t187 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = add i64 %t186, %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t185, i64 %t186)
  %t192 = getelementptr i8, ptr %t191, i64 %t186
  call void @olang_textcopy(ptr %t192, ptr %t188, i64 %t189)
  %t193 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t191, 1
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t197 = extractvalue { i64, ptr } %t194, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  %t202 = load ptr, ptr %l92, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t202, { i64, ptr } %t201)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  %t204 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t205 = load i32, ptr %t204, !tbaa !23
  %t206 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t209 = icmp ne i32 %t205, %t206
  br i1 %t209, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t216 = load i32, ptr %t215, !tbaa !23
  %t219 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %s10, ptr %t214, i32 %t216)
  store { i64, ptr } %t219, ptr %l104
  br label %bb40
bb39:
  br label %bb49
bb40:
  %t220 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  %t222 = extractvalue { i64, ptr } %t220, 1
  %t223 = mul i64 %t221, 4
  %t224 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t223)
  call void @llvm.memcpy.p0.p0.i64(ptr %t224, ptr %t222, i64 %t223, i1 false)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  store { i64, ptr } %t226, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  store i64 %t230, ptr %l14, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s11
  %t232 = load i64, ptr %l13, !tbaa !24
  %t233 = load i64, ptr %l14, !tbaa !24
  %t236 = icmp slt i64 %t232, %t233
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s11)
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t240 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t240, ptr %l112, !tbaa !27
  %t241 = load i64, ptr %l13, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i32, ptr %t244, i64 %t241
  %t246 = load i32, ptr %t245, !tbaa !33
  store ptr %l4, ptr %l115, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t252 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s11, ptr %t248, i32 %t246)
  store { i64, ptr } %t252, ptr %l118
  br label %bb45
bb45:
  %t253 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t255 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = add i64 %t254, %t257
  %t259 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t253, i64 %t254)
  %t260 = getelementptr i8, ptr %t259, i64 %t254
  call void @olang_textcopy(ptr %t260, ptr %t256, i64 %t257)
  %t261 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t259, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } %t262, 1
  %t266 = mul i64 %t264, 1
  %t267 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t267, ptr %t265, i64 %t266, i1 false)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t270 = load ptr, ptr %l115, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t270, { i64, ptr } %t269)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb47
bb47:
  %t272 = load i64, ptr %l13, !tbaa !24
  %t274 = add i64 %t272, 1
  store i64 %t274, ptr %l13, !tbaa !24
  br label %bb41
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t276 = load i64, ptr %l9, !tbaa !24
  %t278 = add i64 %t276, 1
  store i64 %t278, ptr %l9, !tbaa !24
  br label %bb13
bb51:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 62)
  br label %bb52
bb52:
  %t282 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l4)
  store { i64, ptr } %t282, ptr %l127
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t283 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t283, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ewithDefaults(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l17 = alloca i1
  %l27 = alloca ptr
  %l35 = alloca %"std/prelude/text:StringBuilder"
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l56 = alloca i1
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l79 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l105 = alloca { i64, ptr }
  %l107 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l117 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  store i1 %t9, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l17, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t14, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 10
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store ptr %t32, ptr %l27
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l27, !tbaa !29
  %t35 = getelementptr %"compiler/load:Module", ptr %t33, i32 0, i32 6
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l5, !tbaa !29
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ff0e4b22591d4baf_6e63db52d9d49f33)
  unreachable
bb9:
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr %"compiler/source:Source", ptr %t42, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l6, !tbaa !27
  %t48 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t48, ptr %l35
  br label %bb11
bb11:
  %t49 = load %"std/prelude/text:StringBuilder", ptr %l35
  store %"std/prelude/text:StringBuilder" %t49, ptr %l7
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t52 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t56 = icmp sgt i64 %t54, 0
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  br label %bb61
bb14:
  br label %bb15
bb15:
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = call i64 @compiler_2fexplain_2efirstItemEnd(ptr %v1, { i64, ptr } %t60)
  store i64 %t62, ptr %l42
  br label %bb16
bb16:
  %t63 = load i64, ptr %l42, !tbaa !24
  store i64 %t63, ptr %l10, !tbaa !24
  store ptr %l7, ptr %l43, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t64, ptr %l44, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  store i64 %t65, ptr %l45, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l46, !tbaa !24
  %t68 = icmp sge i64 0, 0
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load i64, ptr %l45, !tbaa !24
  %t71 = icmp sle i64 0, %t70
  br i1 %t71, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9a288766c4af6878_87d82d450b86e5bc)
  unreachable
bb19:
  %t73 = load i64, ptr %l45, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_9a288766c4af6878_87d82d450b86e5bc)
  unreachable
bb21:
  %t77 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l45, !tbaa !24
  %t80 = getelementptr i8, ptr %t78, i64 0
  %t81 = sub i64 %t79, 0
  %t82 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  %t84 = load ptr, ptr %l43, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t84, { i64, ptr } %t83)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9a288766c4af6878_87d82d450b86e5bc)
  unreachable
bb23:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t90 = sub i64 %t86, %a4
  store i64 %t90, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp sge i64 %t92, 0
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  store i1 %t102, ptr %l56, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t104 = load i1, ptr %l56, !tbaa !21
  br i1 %t104, label %bb27, label %bb28
bb27:
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l62, !tbaa !27
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr ptr, ptr %t109, i64 %t106
  %t111 = load ptr, ptr %t110, !tbaa !39
  %t113 = getelementptr %"compiler/ast:Param", ptr %t111, i32 0, i32 3
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  %t118 = xor i1 %t116, true
  store i1 %t118, ptr %l61, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb29
bb29:
  %t120 = load i1, ptr %l61, !tbaa !21
  br i1 %t120, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t121 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t121, ptr %l68, !tbaa !27
  %t122 = load i64, ptr %l11, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  %t129 = getelementptr %"compiler/ast:Param", ptr %t127, i32 0, i32 3
  %t130 = load ptr, ptr %t129, !tbaa !29
  store ptr %t130, ptr %l12, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb32, label %bb33
bb31:
  br label %bb43
bb32:
  call void @__olang_check_failed(ptr @olang_loc_dff7162f9e8224a5_8282e6f3b3a12619)
  unreachable
bb33:
  br label %bb34
bb34:
  %t136 = load ptr, ptr %l12, !tbaa !29
  %t138 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t136)
  store %"compiler/source:Span" %t138, ptr %l75
  br label %bb35
bb35:
  %t139 = load %"compiler/source:Span", ptr %l75
  store %"compiler/source:Span" %t139, ptr %l13
  store ptr %l7, ptr %l76, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t140, ptr %l77, !tbaa !27
  %t141 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t142 = load i32, ptr %t141, !tbaa !23
  %t144 = sext i32 %t142 to i64
  store i64 %t144, ptr %l79, !tbaa !24
  %t145 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t146 = load i32, ptr %t145, !tbaa !23
  %t148 = sext i32 %t146 to i64
  store i64 %t148, ptr %l81, !tbaa !24
  %t149 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  store i64 %t150, ptr %l82, !tbaa !24
  %t151 = load i64, ptr %l79, !tbaa !24
  %t152 = icmp sge i64 %t151, 0
  br i1 %t152, label %bb36, label %bb37
bb36:
  %t154 = load i64, ptr %l79, !tbaa !24
  %t155 = load i64, ptr %l81, !tbaa !24
  %t156 = icmp sle i64 %t154, %t155
  br i1 %t156, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a)
  unreachable
bb38:
  %t158 = load i64, ptr %l81, !tbaa !24
  %t159 = load i64, ptr %l82, !tbaa !24
  %t160 = icmp sle i64 %t158, %t159
  br i1 %t160, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a)
  unreachable
bb40:
  %t162 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = load i64, ptr %l79, !tbaa !24
  %t165 = load i64, ptr %l81, !tbaa !24
  %t166 = getelementptr i8, ptr %t163, i64 %t164
  %t167 = sub i64 %t165, %t164
  %t168 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t166, 1
  %t170 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t173 = extractvalue { i64, ptr } %t169, 1
  %t174 = extractvalue { i64, ptr } %t169, 0
  %t175 = add i64 %t171, %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = getelementptr i8, ptr %t176, i64 %t171
  call void @olang_textcopy(ptr %t177, ptr %t173, i64 %t174)
  %t178 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t176, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = extractvalue { i64, ptr } %t179, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  %t187 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t187, { i64, ptr } %t186)
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb43:
  %t189 = load i64, ptr %l9, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l9, !tbaa !24
  %t193 = load i64, ptr %l10, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t199 = icmp sge i64 %t193, %t196
  br i1 %t199, label %bb44, label %bb45
bb44:
  br label %bb61
bb45:
  br label %bb46
bb46:
  store ptr %l7, ptr %l95, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t201, ptr %l96, !tbaa !27
  %t202 = load i64, ptr %l10, !tbaa !24
  store i64 %t202, ptr %l97, !tbaa !24
  %t203 = load i64, ptr %l10, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l99, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  store i64 %t207, ptr %l100, !tbaa !24
  %t208 = load i64, ptr %l97, !tbaa !24
  %t209 = icmp sge i64 %t208, 0
  br i1 %t209, label %bb47, label %bb48
bb47:
  %t211 = load i64, ptr %l97, !tbaa !24
  %t212 = load i64, ptr %l99, !tbaa !24
  %t213 = icmp sle i64 %t211, %t212
  br i1 %t213, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405)
  unreachable
bb49:
  %t215 = load i64, ptr %l99, !tbaa !24
  %t216 = load i64, ptr %l100, !tbaa !24
  %t217 = icmp sle i64 %t215, %t216
  br i1 %t217, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405)
  unreachable
bb51:
  %t219 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = load i64, ptr %l97, !tbaa !24
  %t222 = load i64, ptr %l99, !tbaa !24
  %t223 = getelementptr i8, ptr %t220, i64 %t221
  %t224 = sub i64 %t222, %t221
  %t225 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t223, 1
  %t227 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t227, { i64, ptr } %t226)
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405)
  unreachable
bb53:
  %t229 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t229, ptr %l105, !tbaa !27
  %t230 = load i64, ptr %l10, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l107, !tbaa !24
  %t233 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t233, 0
  store i64 %t236, ptr %l110, !tbaa !24
  %t237 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  store i64 %t238, ptr %l111, !tbaa !24
  %t239 = load i64, ptr %l107, !tbaa !24
  %t240 = icmp sge i64 %t239, 0
  br i1 %t240, label %bb54, label %bb55
bb54:
  %t242 = load i64, ptr %l107, !tbaa !24
  %t243 = load i64, ptr %l110, !tbaa !24
  %t244 = icmp sle i64 %t242, %t243
  br i1 %t244, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_6ea1601f041f7d0c_6257690dec820828)
  unreachable
bb56:
  %t246 = load i64, ptr %l110, !tbaa !24
  %t247 = load i64, ptr %l111, !tbaa !24
  %t248 = icmp sle i64 %t246, %t247
  br i1 %t248, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_6ea1601f041f7d0c_6257690dec820828)
  unreachable
bb58:
  %t250 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l107, !tbaa !24
  %t253 = load i64, ptr %l110, !tbaa !24
  %t254 = getelementptr i8, ptr %t251, i64 %t252
  %t255 = sub i64 %t253, %t252
  %t256 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t254, 1
  store { i64, ptr } %t257, ptr %l8, !tbaa !27
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_6ea1601f041f7d0c_6257690dec820828)
  unreachable
bb60:
  br label %bb12
bb61:
  %t260 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l7)
  store { i64, ptr } %t260, ptr %l117
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  %t261 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t261, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2ewordPayload(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l37 = alloca i32
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v1, ptr %t4, i32 %a2)
  store i32 %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load i32, ptr %l9, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load i32, ptr %l4, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l4, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v1, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l20
  br label %bb5
bb5:
  %t32 = load ptr, ptr %l15, !tbaa !29
  %t33 = load i32, ptr %l20, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %v1, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l21
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  %t36 = load i64, ptr %l3, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp sge i64 %t36, %t39
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb9
bb8:
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t44, ptr %l27, !tbaa !27
  %t45 = load i64, ptr %l3, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i32, ptr %t48, i64 %t45
  %t50 = load i32, ptr %t49, !tbaa !33
  %t52 = icmp eq i32 %t50, 0
  store i1 %t52, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  store ptr %a0, ptr %l31, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l32, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l4, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l37
  br label %bb13
bb13:
  %t67 = load i32, ptr %l4, !tbaa !23
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load ptr, ptr %l31, !tbaa !29
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  call void @compiler_2fexplain_2epushPayload(ptr %v0, ptr %v1, ptr %t69, ptr %t70, i32 %t71, i32 %t67, i64 %t68)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fexplain_2ewrittenMethod(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca ptr
  %l47 = alloca i64
  %l50 = alloca i1
  %l54 = alloca i1
  %l64 = alloca { i64, ptr }
  %l67 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t4)
  br label %bb1
bb1:
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l22, !tbaa !24
  store i64 %t39, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l19, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i64, ptr %l9, !tbaa !24
  %t66 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l43
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l43, !tbaa !29
  store ptr %t67, ptr %l10, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t71, i64 %t72)
  store i64 %t75, ptr %l47
  br label %bb14
bb14:
  %t77 = load i64, ptr %l47, !tbaa !24
  %t79 = icmp ne i64 %t77, %a1
  br i1 %t79, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb17
bb16:
  %t81 = load ptr, ptr %l10, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Func", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  store i1 %t86, ptr %l50, !tbaa !21
  br label %bb17
bb17:
  %t88 = load i1, ptr %l50, !tbaa !21
  br i1 %t88, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb20
bb19:
  %t89 = load ptr, ptr %l10, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %t91, !tbaa !23
  %t96 = icmp ne i32 %t92, %a3
  store i1 %t96, ptr %l54, !tbaa !21
  br label %bb20
bb20:
  %t98 = load i1, ptr %l54, !tbaa !21
  br i1 %t98, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb22:
  br label %bb23
bb23:
  %t99 = load ptr, ptr %l10, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/load:Loader", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t112 = call { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v0, ptr %s2, ptr %t99, ptr %t109)
  store { i64, ptr } %t112, ptr %l64
  br label %bb24
bb24:
  %t113 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %v1, { i64, ptr } %t119, { i64, ptr } %a2)
  store i1 %t123, ptr %l67
  br label %bb25
bb25:
  %t124 = load i1, ptr %l67, !tbaa !21
  br i1 %t124, label %bb26, label %bb27
bb26:
  %t125 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t125, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t127 = load i64, ptr %l8, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l8, !tbaa !24
  br label %bb9
bb30:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/explain:Code" @compiler_2fexplain_3aCode_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/explain:Code"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/explain:Code" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/explain:Code" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/explain:Code" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/explain:Code" %t14, { i64, ptr } %a3, 3
  store %"compiler/explain:Code" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/explain:Code", ptr %rv
  ret %"compiler/explain:Code" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"   " }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d4 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"instance " }>, align 8
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d7 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"a method is called as one (M19) - a lambda calling it is a value" }>, align 8
@.d8 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"an extern fn is called by its name (X1) - a lambda calling it is a value" }>, align 8
@.d9 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"it is compiled once per length of an array it takes by value (G29) - pass a lambda calling it" }>, align 8
@.d10 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"a generic builder is a value only named with its type arguments, '" }>, align 8
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"<...>." }>, align 8
@.d12 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"' (G12, D19)" }>, align 8
@.d13 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a generic is a value only named with its type arguments, '" }>, align 8
@.d14 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"<...>' (G12)" }>, align 8
@.d15 = private constant <{ i64, [181 x i8] }> <{ i64 0, [181 x i8] c"its scope obligations (# scopes, above) tie where what it is given lives to what it keeps or gives back, which a call through a function value cannot check (T22a) - call it directly" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d20 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".h" }>, align 8
@.d24 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d25 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"# commutes: the operator applies with its operands the other way round too (E31c)\0A" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]\0A" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn&(" }>, align 8
@.d29 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" immut" }>, align 8
@.d31 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" unique" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"# effects: " }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d46 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d47 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"    # " }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d49 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d50 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    instance " }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d53 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d54 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d56 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Generator" }>, align 8
@.d57 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Iterator" }>, align 8
@.d58 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"   # a generator: a call gives a " }>, align 8
@.d59 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ViewGenerator<" }>, align 8
@.d60 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Iterator" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d62 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"   # a generator: a call gives a " }>, align 8
@.d63 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@.d64 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d67 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d69 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" mut " }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d71 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"   # set at startup\0A" }>, align 8
@.d72 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"   # set at startup\0A" }>, align 8
@.d73 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d74 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"...   # " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d75 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" characters\0A" }>, align 8
@.d76 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d78 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d79 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d81 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d82 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d83 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d85 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"# not a value: " }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d87 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"# scopes: " }>, align 8
@.d88 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d90 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cn" }>, align 8
@.d91 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Ct" }>, align 8
@.d92 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"   # its error set inferred" }>, align 8
@.d93 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d94 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"    meets " }>, align 8
@.d95 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d96 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d97 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d98 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"extern type " }>, align 8
@.d101 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d102 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"error " }>, align 8
@.d103 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"   # declared where it is raised (R3b)\0A" }>, align 8
@.d104 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d105 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" error" }>, align 8
@.d106 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d109 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d110 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d111 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" trait" }>, align 8
@.d112 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" extends " }>, align 8
@.d113 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d114 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d115 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d116 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d117 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d118 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" enum\0A" }>, align 8
@.d119 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d120 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" extends " }>, align 8
@.d121 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d122 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d123 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" packed" }>, align 8
@.d124 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d125 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d126 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" struct(" }>, align 8
@.d127 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d129 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d130 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d131 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d132 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d133 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d134 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d136 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerOf(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H6c17f05b74a2ea6689cdfc72c602a991(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %v0)
@olang_loc_91de52063b71ca44_3ab230bc0b47a90 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eModuleOf(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2eMerge(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
@G_2ecompiler_2feffects_2eCapCount = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2feffects_2eCapText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2ePush_3ccompiler_2fexplain_3aCode_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/explain:Code" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerVarCount(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eValueCovered(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e4b17f5ad4d0393_dacada4c9c892187 = external constant [0 x i8]
@olang_loc_31b785093080fa1c_de0f6dc4f3b337d0 = external constant [0 x i8]
declare { i64, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAttrsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_654ac6e7d4d962a_57fceb1b72d2ae56 = external constant [0 x i8]
@olang_loc_d0280248a738559f_8af1b7358df9134b = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_430839a36fc86f5_d60a2ea9e5c9a99 = external constant [0 x i8]
@olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3 = external constant [0 x i8]
@olang_loc_5177bd7d484351dd_5d0dbb04dc509331 = external constant [0 x i8]
@olang_loc_e7ca39a48e286d3f_b849249cb4ab4933 = external constant [0 x i8]
@olang_loc_ec0929e0cef23b20_10aa079683981964 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67 = external constant [0 x i8]
@olang_loc_6448edf003c535f3_ebaded49d6e07c97 = external constant [0 x i8]
@olang_loc_979fe2e14fb6de05_5947910940c194f1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_559eb4fe50ed7f04_5fd8618740f13e0 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaredUnique(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98928cfde749f632_385db913ea7e7976 = external constant [0 x i8]
declare { i64, ptr } @compiler_2feffects_2eDescribe(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_8f9ce818ff296c0e_932c83e6c6076d82 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1ab09a44950d5518_36fac77ffd6769bc = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021 = external constant [0 x i8]
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4)
@olang_loc_b65b7d917c440185_24d12a03c9296209 = external constant [0 x i8]
@olang_loc_6896438a508f3415_b4ea8b5a918f5051 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fneeds_2eLines(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_fc7f64fd7b454af3_cf2a3e2278d9fc1f = external constant [0 x i8]
@olang_loc_499d9639469ba124_2d1e6838c6dcdf80 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546 = external constant [0 x i8]
@olang_loc_904aca603cad2e45_e62ac09e4cb76009 = external constant [0 x i8]
@olang_loc_e59c902bb0ddc268_5b11d99e1c27629c = external constant [0 x i8]
@olang_loc_f3704e37964cb683_929f8ce39c458747 = external constant [0 x i8]
@olang_loc_87334f8237d1e26_d87acd2b8515436a = external constant [0 x i8]
@olang_loc_96b8876366bd9a81_fe1335b03e31611d = external constant [0 x i8]
@olang_loc_83191eb44b7384_f52b74cb91a30b30 = external constant [0 x i8]
@olang_loc_b6495ab5ccd815f1_8b49adc496fcf80d = external constant [0 x i8]
@olang_loc_f77a02592a0a9372_4ac4ccf0828b43ae = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
@olang_loc_85b05f6e7a1e78ef_648f77bc98c82cab = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i32, { i64, ptr } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %a0)
@olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b = external constant [0 x i8]
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
@olang_loc_24a71f1628ab63b4_59f385be22d57b28 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_267284e461664677_b2c2386ba62ab5d3 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_66f7703ccaf4f658_ca46a1b97aa24804 = external constant [0 x i8]
@olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H1e7e683fc0332c06b6c705cd46691777(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_a185ff5f85e75430_c999a61f9f0eedcc = external constant [0 x i8]
@olang_loc_60d3429e949e0f0f_c9b6e73225d64a3b = external constant [0 x i8]
@olang_loc_9e7f77c067ece8f1_2a0afb54e00d35 = external constant [0 x i8]
@olang_loc_7b101762ff8ffda9_ced5d247097fb61d = external constant [0 x i8]
@olang_loc_e7cf316846733e6c_5d444c1e6a143730 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_4e8cd845c965dada_c1eb458e34ff6f7e = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_12615553f525a8d6_4928bb51d62e2722 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d47c24bdc65fe2cb_f786417b6ea94537 = external constant [0 x i8]
@olang_loc_6531017cd55dbf94_87ab3d542028c5d8 = external constant [0 x i8]
@olang_loc_fdc41c6a76f01a06_9680a398378cbf4a = external constant [0 x i8]
@olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41 = external constant [0 x i8]
@olang_loc_5a4859640df0add8_178cc34ee3f1765c = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_731041b9517c977f_a1670725ff3ccc5b = external constant [0 x i8]
@olang_loc_b306a27fe8c8780a_4c00da05a7c42646 = external constant [0 x i8]
@olang_loc_5d61f9982e85490b_19b97e7dc205ed37 = external constant [0 x i8]
@olang_loc_3df602fba2cf8b3_3b7d9b6ebe07120f = external constant [0 x i8]
@olang_loc_94295b17b6f8c92c_4d0fd7ff7c3c10d0 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ff0e4b22591d4baf_6e63db52d9d49f33 = external constant [0 x i8]
@olang_loc_9a288766c4af6878_87d82d450b86e5bc = external constant [0 x i8]
@olang_loc_dff7162f9e8224a5_8282e6f3b3a12619 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a = external constant [0 x i8]
@olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405 = external constant [0 x i8]
@olang_loc_6ea1601f041f7d0c_6257690dec820828 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
