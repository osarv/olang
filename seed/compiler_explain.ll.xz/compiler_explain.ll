; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Table" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
define dso_local { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/names:Entry"
  %l16 = alloca i64
  %l17 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i32
  %l42 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l59 = alloca i32
  %l60 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca i32
  %l76 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i32
  %l93 = alloca { i64, ptr }
  %l105 = alloca i64
  %l111 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l127 = alloca i32
  %l132 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l5, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v3, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 1, ptr @.d0 })
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l25
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb2, label %ok.18
ok.18:
  store i64 %t15, ptr %l24
  br label %bb1
bb1:
  %t19 = load i64, ptr %l24, !tbaa !24
  store i64 %t19, ptr %l22, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb4
bb4:
  %t20 = load i64, ptr %l22, !tbaa !24
  store i64 %t20, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l28, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l29, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l30, !tbaa !27
  %t28 = load i64, ptr %l6, !tbaa !24
  store i64 %t28, ptr %l31, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l32, !tbaa !24
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb7, label %bb8
bb6:
  br label %bb30
bb7:
  %t33 = load i64, ptr %l31, !tbaa !24
  %t34 = icmp sle i64 0, %t33
  br i1 %t34, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb9:
  %t36 = load i64, ptr %l31, !tbaa !24
  %t37 = load i64, ptr %l32, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb11:
  %t40 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = getelementptr i8, ptr %t41, i64 0
  %t44 = sub i64 %t42, 0
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load ptr, ptr %l28, !tbaa !29
  %t48 = load i64, ptr %l29, !tbaa !24
  %t50 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t47, i64 %t48, { i64, ptr } %t46)
  store i32 %t50, ptr %l37
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb13:
  %t51 = load i32, ptr %l37, !tbaa !23
  store i32 %t51, ptr %l7, !tbaa !23
  %t52 = load i32, ptr %l7, !tbaa !23
  %t54 = icmp slt i32 %t52, 0
  br i1 %t54, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t57 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t57, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l42, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load i32, ptr %l7, !tbaa !23
  %t69 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l46
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l5, !tbaa !29
  store ptr %t70, ptr %l47, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l48, !tbaa !27
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l50, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t75, 0
  store i64 %t78, ptr %l53, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l54, !tbaa !24
  %t81 = load i64, ptr %l50, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = load i64, ptr %l50, !tbaa !24
  %t85 = load i64, ptr %l53, !tbaa !24
  %t86 = icmp sle i64 %t84, %t85
  br i1 %t86, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb20:
  %t88 = load i64, ptr %l53, !tbaa !24
  %t89 = load i64, ptr %l54, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb22:
  %t92 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l50, !tbaa !24
  %t95 = load i64, ptr %l53, !tbaa !24
  %t96 = getelementptr i8, ptr %t93, i64 %t94
  %t97 = sub i64 %t95, %t94
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t102 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v3, ptr %t100, { i64, ptr } %t99)
  store i32 %t102, ptr %l59
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb24:
  %t103 = load ptr, ptr %l42, !tbaa !29
  %t104 = load i32, ptr %l46, !tbaa !23
  %t105 = load i32, ptr %l59, !tbaa !23
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t103, i32 %t104, i32 %t105)
  store i64 %t106, ptr %l60
  br label %bb25
bb25:
  %t107 = load i64, ptr %l60, !tbaa !24
  store i64 %t107, ptr %l8, !tbaa !24
  %t108 = load i64, ptr %l8, !tbaa !24
  %t110 = icmp slt i64 %t108, 0
  br i1 %t110, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t113 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t113, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t116 = load i64, ptr %l8, !tbaa !24
  %t120 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t114, ptr %t115, i64 %t116)
  store { i64, ptr } %t120, ptr %l67
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t121 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t122 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t121, 1
  store { i32, { i64, ptr } } %t122, ptr %rv
  br label %ret
bb30:
  %t123 = load ptr, ptr %l5, !tbaa !29
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t127 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v3, ptr %t123, { i64, ptr } %t124)
  store i32 %t127, ptr %l70
  br label %bb31
bb31:
  %t128 = load i32, ptr %l70, !tbaa !23
  store i32 %t128, ptr %l9, !tbaa !23
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/names:Resolver", ptr %t135, i32 0, i32 1
  %t138 = load i64, ptr %l3, !tbaa !24
  %t141 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t137, i64 %t138)
  store ptr %t141, ptr %l76
  br label %bb32
bb32:
  %t142 = load ptr, ptr %l76, !tbaa !29
  %t144 = getelementptr %"compiler/names:Table", ptr %t142, i32 0, i32 0
  store ptr %t144, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t146 = load ptr, ptr %l10, !tbaa !29
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t146, i64 %t147)
  %t151 = extractvalue { i32, { i64, ptr } } %t150, 1
  %t152 = extractvalue { i32, { i64, ptr } } %t150, 0
  store i32 %t152, ptr %l83
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb35, label %ok.154
ok.154:
  store { i64, ptr } %t151, ptr %l82
  br label %bb34
bb34:
  %t155 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t155, ptr %l79, !tbaa !27
  br label %bb39
bb35:
  %t156 = load i32, ptr %l83, !tbaa !23
  %t157 = ashr i32 %t156, 16
  %t159 = icmp eq i32 %t157, 1
  br i1 %t159, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  %t161 = load i32, ptr %l83, !tbaa !23
  %t162 = lshr i32 %t161, 16
  %t163 = and i32 %t161, 65535
  %t164 = icmp eq i32 %t162, 1
  %t165 = select i1 %t164, i32 0, i32 0
  %t166 = icmp eq i32 %t161, 0
  %t167 = shl i32 %t165, 16
  %t168 = or i32 %t167, %t163
  %t169 = select i1 %t166, i32 0, i32 %t168
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t171 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t169, 0
  store { i32, { i64, ptr } } %t171, ptr %rv
  br label %ret
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb39:
  %t172 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t172, ptr %l12, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t177 = load i64, ptr %l14, !tbaa !24
  %t178 = load i64, ptr %l13, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb42:
  br label %bb43
bb43:
  %t185 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t185, ptr %l93, !tbaa !27
  %t186 = load i64, ptr %l14, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr %"compiler/names:Entry", ptr %t189, i64 %t186
  %t191 = load %"compiler/names:Entry", ptr %t190
  store %"compiler/names:Entry" %t191, ptr %l15
  %t193 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 0
  %t194 = load i32, ptr %t193, !tbaa !23
  %t195 = load i32, ptr %l9, !tbaa !23
  %t198 = icmp ne i32 %t194, %t195
  br i1 %t198, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb45:
  br label %bb46
bb46:
  %t200 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 2
  %t201 = load i32, ptr %t200
  %t203 = trunc i64 3 to i32
  %t204 = icmp eq i32 %t201, %t203
  br i1 %t204, label %bb47, label %bb48
bb47:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t210 = load i64, ptr %l3, !tbaa !24
  %t211 = load i32, ptr %l9, !tbaa !23
  %t215 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t209, i64 %t210, i32 %t211)
  store i64 %t215, ptr %l105
  br label %bb49
bb48:
  br label %bb54
bb49:
  %t216 = load i64, ptr %l105, !tbaa !24
  store i64 %t216, ptr %l16, !tbaa !24
  %t217 = load i64, ptr %l16, !tbaa !24
  %t219 = icmp sge i64 %t217, 0
  br i1 %t219, label %bb50, label %bb51
bb50:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t223 = load i64, ptr %l16, !tbaa !24
  %t227 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t221, ptr %t222, i64 %t223)
  store { i64, ptr } %t227, ptr %l111
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t228 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t229 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t228, 1
  store { i32, { i64, ptr } } %t229, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t230 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 2
  %t231 = load i32, ptr %t230
  %t233 = trunc i64 2 to i32
  %t234 = icmp eq i32 %t231, %t233
  br i1 %t234, label %bb55, label %bb56
bb55:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i64, ptr %l3, !tbaa !24
  %t239 = load %"compiler/names:Entry", ptr %l15
  %t244 = call { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v2, ptr %v0, ptr %v4, ptr %t236, ptr %a2, i64 %t238, %"compiler/names:Entry" %t239)
  store { i64, ptr } %t244, ptr %l118
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t245 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t246 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t245, 1
  store { i32, { i64, ptr } } %t246, ptr %rv
  br label %ret
bb58:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb59:
  %t247 = load i64, ptr %l14, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l14, !tbaa !24
  br label %bb40
bb60:
  %t251 = load i64, ptr %l11, !tbaa !24
  %t252 = load i64, ptr %l13, !tbaa !24
  %t255 = add i64 %t251, %t252
  store i64 %t255, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb61:
  br label %bb33
bb62:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i64, ptr %l3, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t263 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t257, i64 %t258, { i64, ptr } %t259)
  store i32 %t263, ptr %l127
  br label %bb63
bb63:
  %t264 = load i32, ptr %l127, !tbaa !23
  store i32 %t264, ptr %l17, !tbaa !23
  %t265 = load i32, ptr %l17, !tbaa !23
  %t267 = icmp sge i32 %t265, 0
  br i1 %t267, label %bb64, label %bb65
bb64:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i32, ptr %l17, !tbaa !23
  %t273 = call { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v4, ptr %t269, i32 %t270)
  store { i64, ptr } %t273, ptr %l132
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s0)
  %t274 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t275 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t274, 1
  store { i32, { i64, ptr } } %t275, ptr %rv
  br label %ret
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t277 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t277, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [2 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = icmp sle i64 0, 1152921504606846975
  br i1 %t34, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb12:
  %t36 = mul i64 0, 8
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 0, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fexplain_2ecaseWhole(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [2 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 3
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5177bd7d484351dd_5d0dbb04dc509331)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [2 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:StructBody", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = icmp sle i64 0, 1152921504606846975
  br i1 %t28, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb12:
  %t30 = mul i64 0, 8
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 0, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_979fe2e14fb6de05_5947910940c194f1)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr @.d1 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr @.d2 }, ptr %l9, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  br label %bb13
bb6:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load i64, ptr %l1, !tbaa !24
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t18, 0
  store i64 %t21, ptr %l15, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l16, !tbaa !24
  %t24 = load i64, ptr %l12, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load i64, ptr %l12, !tbaa !24
  %t28 = load i64, ptr %l15, !tbaa !24
  %t29 = icmp sle i64 %t27, %t28
  br i1 %t29, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb9:
  %t31 = load i64, ptr %l15, !tbaa !24
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb11:
  %t35 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = load i64, ptr %l12, !tbaa !24
  %t38 = load i64, ptr %l15, !tbaa !24
  %t39 = getelementptr i8, ptr %t36, i64 %t37
  %t40 = sub i64 %t38, %t37
  %t41 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t39, 1
  store { i64, ptr } %t42, ptr %l8, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb13:
  %t45 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l22, !tbaa !24
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l23, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l22, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2efields(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/typed:Local"
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l39 = alloca { i64, ptr }
  %l52 = alloca i32
  %l56 = alloca i1
  %l61 = alloca i32
  %l66 = alloca i32
  %l68 = alloca i1
  %l73 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l85 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i64
  %l92 = alloca ptr
  %l102 = alloca i64
  %l106 = alloca i64
  %l109 = alloca i64
  %l128 = alloca ptr
  %l132 = alloca i32
  %l134 = alloca %"compiler/typed:Local"
  %l139 = alloca i32
  %l140 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l162 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l164 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l30
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l29
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t14, ptr %l26, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l30, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_d16c6b36ae6c900f_110b33433d32ce53)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb7:
  %t20 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb72
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l39, !tbaa !27
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  store ptr %t39, ptr %l8, !tbaa !29
  %t41 = load ptr, ptr %l8, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 1
  %t44 = load { i64, [2 x i64] }, ptr %t43
  store { i64, [2 x i64] } %t44, ptr %l9
  %t46 = load { i64, [2 x i64] }, ptr %l9
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l10, !tbaa !23
  %t55 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t56 = getelementptr { i32, i32 }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l11, !tbaa !23
  br label %bb14
bb13:
  br label %bb65
bb14:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l10, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l52
  br label %bb15
bb15:
  %t69 = load i32, ptr %l52
  %t71 = trunc i64 18 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb20
bb17:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l10, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l61
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %l2, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l66
  br label %bb19
bb19:
  %t96 = load i32, ptr %l61, !tbaa !23
  %t97 = load i32, ptr %l66, !tbaa !23
  %t98 = icmp ne i32 %t96, %t97
  store i1 %t98, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t100 = load i1, ptr %l56, !tbaa !21
  br i1 %t100, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb23
bb22:
  %t101 = load i32, ptr %l11, !tbaa !23
  %t103 = icmp ne i32 %t101, 0
  store i1 %t103, ptr %l68, !tbaa !21
  br label %bb23
bb23:
  %t105 = load i1, ptr %l68, !tbaa !21
  br i1 %t105, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb25:
  br label %bb26
bb26:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  store ptr %t111, ptr %l73, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t118 = load i32, ptr %l2, !tbaa !23
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v1, ptr %t117, i32 %t118)
  store i32 %t121, ptr %l78
  br label %bb27
bb27:
  %t122 = load ptr, ptr %l73, !tbaa !29
  %t123 = load i32, ptr %l78, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %t122, i32 %t123)
  store { i64, ptr } %t124, ptr %l79
  br label %bb28
bb28:
  %t125 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t125, ptr %l12, !tbaa !27
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/load:Loader", ptr %t132, i32 0, i32 5
  store ptr %t134, ptr %l83, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %l85, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l2, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l90
  br label %bb29
bb29:
  %t149 = load ptr, ptr %l85, !tbaa !29
  %t150 = load i32, ptr %l90, !tbaa !23
  %t151 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v1, ptr %t149, i32 %t150)
  store i64 %t151, ptr %l91
  br label %bb30
bb30:
  %t152 = load ptr, ptr %l83, !tbaa !29
  %t153 = load i64, ptr %l91, !tbaa !24
  %t154 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v1, ptr %v1, ptr %t152, i64 %t153)
  store ptr %t154, ptr %l92
  br label %bb31
bb31:
  %t155 = load ptr, ptr %l92, !tbaa !29
  %t157 = getelementptr %"compiler/load:Module", ptr %t155, i32 0, i32 6
  %t158 = load ptr, ptr %t157, !tbaa !29
  store ptr %t158, ptr %l13, !tbaa !29
  %t160 = load ptr, ptr %l13, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  br i1 %t162, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_35ffc19e50bbc737_e52638f1e81552b)
  unreachable
bb33:
  br label %bb34
bb34:
  %t164 = load ptr, ptr %l13, !tbaa !29
  %t167 = getelementptr %"compiler/source:Source", ptr %t164, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  store { i64, ptr } %t168, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t170 = load ptr, ptr %l8, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Body", ptr %t170, i32 0, i32 10
  %t174 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t172)
  store i64 %t174, ptr %l102
  br label %bb35
bb35:
  %t175 = load i64, ptr %l102, !tbaa !24
  store i64 %t175, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t176 = load i64, ptr %l16, !tbaa !24
  %t177 = load i64, ptr %l15, !tbaa !24
  %t180 = icmp sgt i64 %t176, %t177
  br i1 %t180, label %bb36, label %bb37
bb36:
  %t182 = load i64, ptr %l17, !tbaa !24
  %t184 = icmp sgt i64 %t182, 0
  br i1 %t184, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb41
bb38:
  %t186 = load i64, ptr %l16, !tbaa !24
  %t187 = load i64, ptr %l15, !tbaa !24
  %t190 = sub i64 %t186, %t187
  %t191 = load i64, ptr %l17, !tbaa !24
  %t194 = add i64 %t190, %t191
  %t196 = sub i64 %t194, 1
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = sdiv i64 %t196, %t197
  store i64 %t200, ptr %l109, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb40
bb40:
  %t202 = load i64, ptr %l109, !tbaa !24
  store i64 %t202, ptr %l106, !tbaa !24
  br label %bb41
bb41:
  %t203 = load i64, ptr %l106, !tbaa !24
  store i64 %t203, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t204 = load i64, ptr %l19, !tbaa !24
  %t205 = load i64, ptr %l18, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb44:
  br label %bb45
bb45:
  %t212 = load i64, ptr %l15, !tbaa !24
  %t213 = load i64, ptr %l19, !tbaa !24
  %t214 = load i64, ptr %l17, !tbaa !24
  %t217 = mul i64 %t213, %t214
  %t220 = add i64 %t212, %t217
  store i64 %t220, ptr %l20, !tbaa !24
  %t222 = load ptr, ptr %l8, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Body", ptr %t222, i32 0, i32 7
  store ptr %t224, ptr %l128, !tbaa !29
  %t225 = load ptr, ptr %l8, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Body", ptr %t225, i32 0, i32 10
  %t228 = load i64, ptr %l20, !tbaa !24
  %t231 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t227, i64 %t228)
  store i32 %t231, ptr %l132
  br label %bb46
bb46:
  %t232 = load i32, ptr %l132, !tbaa !23
  %t233 = sext i32 %t232 to i64
  %t234 = load ptr, ptr %l128, !tbaa !29
  %t236 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t234, i64 %t233)
  store %"compiler/typed:Local" %t236, ptr %l134
  br label %bb47
bb47:
  %t237 = load %"compiler/typed:Local", ptr %l134
  store %"compiler/typed:Local" %t237, ptr %l21
  %t238 = load i64, ptr %l20, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t244 = icmp slt i64 %t238, %t241
  br i1 %t244, label %bb48, label %bb49
bb48:
  %t246 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t246, ptr %l140, !tbaa !27
  %t247 = load i64, ptr %l20, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i32, ptr %t250, i64 %t247
  %t252 = load i32, ptr %t251, !tbaa !33
  store i32 %t252, ptr %l139, !tbaa !23
  br label %bb50
bb49:
  %t254 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 2
  %t255 = load i32, ptr %t254, !tbaa !23
  store i32 %t255, ptr %l139, !tbaa !23
  br label %bb50
bb50:
  %t257 = load i32, ptr %l139, !tbaa !23
  store i32 %t257, ptr %l22, !tbaa !23
  %t258 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = icmp eq i32 %t259, 0
  br i1 %t261, label %bb51, label %bb52
bb51:
  %t263 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t263, ptr %l147, !tbaa !27
  %t264 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t265 = getelementptr %"compiler/source:Span", ptr %t264, i32 0, i32 0
  %t266 = load i32, ptr %t265, !tbaa !23
  %t268 = sext i32 %t266 to i64
  store i64 %t268, ptr %l149, !tbaa !24
  %t269 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t270 = getelementptr %"compiler/source:Span", ptr %t269, i32 0, i32 1
  %t271 = load i32, ptr %t270, !tbaa !23
  %t273 = sext i32 %t271 to i64
  store i64 %t273, ptr %l151, !tbaa !24
  %t274 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  store i64 %t275, ptr %l152, !tbaa !24
  %t276 = load i64, ptr %l149, !tbaa !24
  %t277 = icmp sge i64 %t276, 0
  br i1 %t277, label %bb53, label %bb54
bb52:
  %t279 = load ptr, ptr %l1, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/load:Loader", ptr %t285, i32 0, i32 3
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t289 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t290 = load i32, ptr %t289, !tbaa !23
  %t293 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %t288, i32 %t290)
  store { i64, ptr } %t293, ptr %l162
  br label %bb59
bb53:
  %t294 = load i64, ptr %l149, !tbaa !24
  %t295 = load i64, ptr %l151, !tbaa !24
  %t296 = icmp sle i64 %t294, %t295
  br i1 %t296, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2)
  unreachable
bb55:
  %t298 = load i64, ptr %l151, !tbaa !24
  %t299 = load i64, ptr %l152, !tbaa !24
  %t300 = icmp sle i64 %t298, %t299
  br i1 %t300, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2)
  unreachable
bb57:
  %t302 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = load i64, ptr %l149, !tbaa !24
  %t305 = load i64, ptr %l151, !tbaa !24
  %t306 = getelementptr i8, ptr %t303, i64 %t304
  %t307 = sub i64 %t305, %t304
  %t308 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t306, 1
  store { i64, ptr } %t309, ptr %l146, !tbaa !27
  br label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2)
  unreachable
bb59:
  %t311 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t311, ptr %l146, !tbaa !27
  br label %bb60
bb60:
  %t312 = load { i64, ptr }, ptr %l146, !tbaa !27
  store ptr %a0, ptr %l163, !tbaa !29
  store { i64, ptr } %t312, ptr %l164, !tbaa !27
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t316 = load i32, ptr %l22, !tbaa !23
  %t319 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s7, ptr %t315, i32 %t316)
  store { i64, ptr } %t319, ptr %l167
  br label %bb61
bb61:
  %t320 = extractvalue { i64, ptr } { i64 4, ptr @.d3 }, 1
  %t321 = extractvalue { i64, ptr } { i64 4, ptr @.d3 }, 0
  %t322 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 1
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t325 = add i64 %t321, %t324
  %t326 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 1
  %t327 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 0
  %t328 = add i64 %t325, %t327
  %t329 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = add i64 %t328, %t331
  %t333 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 1
  %t334 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 0
  %t335 = add i64 %t332, %t334
  %t336 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t335)
  call void @olang_textcopy(ptr %t336, ptr %t320, i64 %t321)
  %t337 = getelementptr i8, ptr %t336, i64 %t321
  call void @olang_textcopy(ptr %t337, ptr %t323, i64 %t324)
  %t338 = getelementptr i8, ptr %t337, i64 %t324
  call void @olang_textcopy(ptr %t338, ptr %t326, i64 %t327)
  %t339 = getelementptr i8, ptr %t338, i64 %t327
  call void @olang_textcopy(ptr %t339, ptr %t330, i64 %t331)
  %t340 = getelementptr i8, ptr %t339, i64 %t331
  call void @olang_textcopy(ptr %t340, ptr %t333, i64 %t334)
  %t341 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t336, 1
  %t344 = extractvalue { i64, ptr } %t342, 0
  %t345 = extractvalue { i64, ptr } %t342, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  %t350 = load ptr, ptr %l163, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t350, { i64, ptr } %t349)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb63:
  %t352 = load i64, ptr %l19, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l19, !tbaa !24
  br label %bb42
bb64:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_36a09f0a29856ad4_1f4c57e6e1803c38)
  unreachable
bb70:
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb71:
  %t356 = load i64, ptr %l7, !tbaa !24
  %t358 = add i64 %t356, 1
  store i64 %t358, ptr %l7, !tbaa !24
  br label %bb8
bb72:
  %t360 = load i64, ptr %l4, !tbaa !24
  %t361 = load i64, ptr %l6, !tbaa !24
  %t364 = add i64 %t360, %t361
  store i64 %t364, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb73:
  br label %bb1
bb74:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fexplain_2efirstClose(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t2, 0
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = icmp sge i64 3, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sle i64 3, %t10
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sle i64 %t13, %t14
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb5:
  %t17 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr i8, ptr %t18, i64 3
  %t21 = sub i64 %t19, 3
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = call i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %t23)
  store i64 %t25, ptr %l10
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb7:
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = add i64 3, %t26
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEnd(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l56, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = sub i64 %t96, 1
  store i64 %t98, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb30:
  br label %bb31
bb31:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = icmp eq i8 %t104, 44
  br i1 %t106, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb37
bb34:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb36
bb35:
  %t108 = load i8, ptr %l8, !tbaa !22
  %t110 = icmp eq i8 %t108, 41
  store i1 %t110, ptr %l66, !tbaa !21
  br label %bb36
bb36:
  %t112 = load i1, ptr %l66, !tbaa !21
  store i1 %t112, ptr %l63, !tbaa !21
  br label %bb37
bb37:
  %t113 = load i1, ptr %l63, !tbaa !21
  br i1 %t113, label %bb38, label %bb39
bb38:
  %t114 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t114, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l6, !tbaa !24
  br label %bb7
bb42:
  %t120 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  store i64 %t122, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb28, label %bb29
bb27:
  br label %bb31
bb28:
  %t95 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t95, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t97 = load i64, ptr %l1, !tbaa !24
  %t99 = sub i64 %t97, 1
  store i64 %t99, ptr %l1, !tbaa !24
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l6, !tbaa !24
  br label %bb7
bb33:
  %t105 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i64
  %l37 = alloca i32
  %l39 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i64
  %l95 = alloca i64
  %l100 = alloca i64
  %l103 = alloca ptr
  %l107 = alloca i32
  %l113 = alloca i32
  %l114 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l126 = alloca i32
  %l127 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca i64
  %l144 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t3)
  store i64 %t5, ptr %l18
  br label %bb2
bb2:
  %t6 = load i64, ptr %l18, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t10, i64 %t6)
  store i64 %t14, ptr %l22
  br label %bb3
bb3:
  %t15 = load i64, ptr %l22, !tbaa !24
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t21, i64 %t22, i32 0)
  store i64 %t25, ptr %l27
  br label %bb6
bb5:
  br label %bb13
bb6:
  %t26 = load i64, ptr %l27, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l30
  br label %bb7
bb7:
  %t32 = load i64, ptr %l30, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store ptr %l3, ptr %l31, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l32, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l33, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t38, i64 %t39)
  store i32 %t42, ptr %l37
  br label %bb8
bb8:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load ptr, ptr %l32, !tbaa !29
  %t45 = load i64, ptr %l33, !tbaa !24
  %t46 = load i32, ptr %l37, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s1, ptr %t44, i64 %t45, i32 %t46, i64 %t43)
  store { i64, ptr } %t48, ptr %l39
  br label %bb9
bb9:
  %t49 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } { i64 1, ptr @.d6 }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr @.d6 }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = getelementptr i8, ptr %t55, i64 %t51
  call void @olang_textcopy(ptr %t56, ptr %t52, i64 %t53)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t66, { i64, ptr } %t65)
  br label %bb10
bb10:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t70 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s1, ptr %l3, ptr %t68, ptr %t69, i64 %t70, { i64, ptr } { i64 4, ptr @.d7 })
  br label %bb11
bb11:
  %t76 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t76, ptr %l47
  br label %bb12
bb12:
  %t77 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t77, ptr %l48, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l49, !tbaa !24
  %t80 = load i64, ptr %l49, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l49, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t91, ptr %l48, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb13:
  store ptr %l3, ptr %l51, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l52, !tbaa !29
  %t94 = load i64, ptr %l2, !tbaa !24
  store i64 %t94, ptr %l53, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load i64, ptr %l2, !tbaa !24
  %t102 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t98, i64 %t99)
  store i32 %t102, ptr %l57
  br label %bb14
bb14:
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = load i64, ptr %l53, !tbaa !24
  %t105 = load i32, ptr %l57, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s0, ptr %t103, i64 %t104, i32 %t105, i64 -1)
  store { i64, ptr } %t106, ptr %l58
  br label %bb15
bb15:
  %t107 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 1
  %t111 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 0
  %t112 = add i64 %t109, %t111
  %t113 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t108, i64 %t109)
  %t114 = getelementptr i8, ptr %t113, i64 %t109
  call void @olang_textcopy(ptr %t114, ptr %t110, i64 %t111)
  %t115 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t113, 1
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = extractvalue { i64, ptr } %t116, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t124 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t124, { i64, ptr } %t123)
  br label %bb16
bb16:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load i64, ptr %l2, !tbaa !24
  %t133 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t129, i64 %t130)
  store ptr %t133, ptr %l64
  br label %bb17
bb17:
  %t134 = load ptr, ptr %l64, !tbaa !29
  store ptr %t134, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %t138)
  store i64 %t140, ptr %l67
  br label %bb18
bb18:
  %t141 = load i64, ptr %l67, !tbaa !24
  store i64 %t141, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t143 = load i64, ptr %l8, !tbaa !24
  %t146 = icmp sgt i64 %t142, %t143
  br i1 %t146, label %bb19, label %bb20
bb19:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t150 = icmp sgt i64 %t148, 0
  br i1 %t150, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb24
bb21:
  %t152 = load i64, ptr %l9, !tbaa !24
  %t153 = load i64, ptr %l8, !tbaa !24
  %t156 = sub i64 %t152, %t153
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = add i64 %t156, %t157
  %t162 = sub i64 %t160, 1
  %t163 = load i64, ptr %l10, !tbaa !24
  %t166 = sdiv i64 %t162, %t163
  store i64 %t166, ptr %l74, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb23
bb23:
  %t168 = load i64, ptr %l74, !tbaa !24
  store i64 %t168, ptr %l71, !tbaa !24
  br label %bb24
bb24:
  %t169 = load i64, ptr %l71, !tbaa !24
  store i64 %t169, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l11, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb46
bb27:
  br label %bb28
bb28:
  %t178 = load i64, ptr %l8, !tbaa !24
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = load i64, ptr %l10, !tbaa !24
  %t183 = mul i64 %t179, %t180
  %t186 = add i64 %t178, %t183
  store i64 %t186, ptr %l13, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = load i64, ptr %l13, !tbaa !24
  %t195 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t191, i64 %t192)
  store i64 %t195, ptr %l95
  br label %bb29
bb29:
  %t196 = load i64, ptr %l2, !tbaa !24
  %t197 = load i64, ptr %l95, !tbaa !24
  %t199 = icmp ne i64 %t197, %t196
  br i1 %t199, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb31:
  br label %bb32
bb32:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i64, ptr %l13, !tbaa !24
  %t205 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t201, i64 %t202)
  store i64 %t205, ptr %l100
  br label %bb33
bb33:
  %t206 = load i64, ptr %l100, !tbaa !24
  store i64 %t206, ptr %l14, !tbaa !24
  %t207 = load i64, ptr %l14, !tbaa !24
  %t209 = icmp slt i64 %t207, 0
  br i1 %t209, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb35:
  br label %bb36
bb36:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l103, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t216 = load i64, ptr %l13, !tbaa !24
  %t219 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t215, i64 %t216)
  store i32 %t219, ptr %l107
  br label %bb37
bb37:
  %t220 = load ptr, ptr %l7, !tbaa !29
  %t222 = getelementptr %"compiler/ast:Func", ptr %t220, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t224 = load ptr, ptr %l7, !tbaa !29
  %t226 = getelementptr %"compiler/ast:Func", ptr %t224, i32 0, i32 3
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/ast:Sig", ptr %t227, i32 0, i32 0
  %t230 = load { i64, ptr }, ptr %t229, !tbaa !27
  %t231 = load ptr, ptr %l103, !tbaa !29
  %t232 = load i32, ptr %l107, !tbaa !23
  %t235 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t231, i32 %t232, ptr %t223, { i64, ptr } %t230)
  store i32 %t235, ptr %l113
  br label %bb38
bb38:
  %t236 = load i32, ptr %l113, !tbaa !23
  store i32 %t236, ptr %l15, !tbaa !23
  store ptr %l3, ptr %l114, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Program", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/load:Loader", ptr %t243, i32 0, i32 3
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t247 = load ptr, ptr %l7, !tbaa !29
  %t249 = getelementptr %"compiler/ast:Func", ptr %t247, i32 0, i32 2
  %t250 = load i32, ptr %t249, !tbaa !23
  %t253 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t246, i32 %t250)
  store { i64, ptr } %t253, ptr %l121
  br label %bb39
bb39:
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l122, !tbaa !29
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/check:Checker", ptr %t255, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t259 = load i64, ptr %l13, !tbaa !24
  %t262 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t258, i64 %t259)
  store i32 %t262, ptr %l126
  br label %bb40
bb40:
  %t263 = load ptr, ptr %l122, !tbaa !29
  %t264 = load i32, ptr %l126, !tbaa !23
  %t265 = call { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %s5, ptr %t263, i32 %t264)
  store { i64, ptr } %t265, ptr %l127
  br label %bb41
bb41:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i32, ptr %l15, !tbaa !23
  %t268 = load i64, ptr %l14, !tbaa !24
  %t272 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s5, ptr %t266, i32 %t267, i64 %t268)
  store { i64, ptr } %t272, ptr %l131
  br label %bb42
bb42:
  %t273 = extractvalue { i64, ptr } { i64 13, ptr @.d9 }, 1
  %t274 = extractvalue { i64, ptr } { i64 13, ptr @.d9 }, 0
  %t275 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = add i64 %t274, %t277
  %t279 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 1
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t282 = add i64 %t278, %t281
  %t283 = extractvalue { i64, ptr } { i64 2, ptr @.d10 }, 1
  %t284 = extractvalue { i64, ptr } { i64 2, ptr @.d10 }, 0
  %t285 = add i64 %t282, %t284
  %t286 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = add i64 %t285, %t288
  %t290 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 1
  %t291 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 0
  %t292 = add i64 %t289, %t291
  %t293 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t292)
  call void @olang_textcopy(ptr %t293, ptr %t273, i64 %t274)
  %t294 = getelementptr i8, ptr %t293, i64 %t274
  call void @olang_textcopy(ptr %t294, ptr %t276, i64 %t277)
  %t295 = getelementptr i8, ptr %t294, i64 %t277
  call void @olang_textcopy(ptr %t295, ptr %t280, i64 %t281)
  %t296 = getelementptr i8, ptr %t295, i64 %t281
  call void @olang_textcopy(ptr %t296, ptr %t283, i64 %t284)
  %t297 = getelementptr i8, ptr %t296, i64 %t284
  call void @olang_textcopy(ptr %t297, ptr %t287, i64 %t288)
  %t298 = getelementptr i8, ptr %t297, i64 %t288
  call void @olang_textcopy(ptr %t298, ptr %t290, i64 %t291)
  %t299 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t293, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = extractvalue { i64, ptr } %t300, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  %t308 = load ptr, ptr %l114, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t308, { i64, ptr } %t307)
  br label %bb43
bb43:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t312 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s5, ptr %l3, ptr %t310, ptr %t311, i64 %t312, { i64, ptr } { i64 8, ptr @.d12 })
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb45:
  %t317 = load i64, ptr %l12, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l12, !tbaa !24
  br label %bb25
bb46:
  %t322 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t322, ptr %l141
  br label %bb47
bb47:
  %t323 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t323, ptr %l142, !tbaa !27
  %t324 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t324, 0
  store i64 %t325, ptr %l143, !tbaa !24
  %t326 = load i64, ptr %l143, !tbaa !24
  %t327 = mul i64 %t326, 1
  %t328 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t327)
  %t329 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t328, 1
  store { i64, ptr } %t330, ptr %l144, !tbaa !27
  %t331 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = load i64, ptr %l143, !tbaa !24
  %t336 = mul i64 %t335, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t332, ptr %t334, i64 %t336, i1 false)
  %t337 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t337, ptr %l142, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t338 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t338, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l25 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l39 = alloca i32
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t19, i32 %t23)
  store { i64, ptr } %t26, ptr %l22
  br label %bb2
bb2:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l23, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t28)
  store i64 %t30, ptr %l25
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l28
  br label %bb4
bb4:
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load i64, ptr %l25, !tbaa !24
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t36, i64 %t37, i64 %t38)
  store { i64, ptr } %t39, ptr %l29
  br label %bb5
bb5:
  %t40 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = add i64 %t42, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t41, i64 %t42)
  %t48 = getelementptr i8, ptr %t47, i64 %t42
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l31, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Func", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Sig", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t70 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t53, i32 %a2, ptr %t58, { i64, ptr } %t65)
  store i32 %t70, ptr %l39
  br label %bb6
bb6:
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t73 = load i32, ptr %l39, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s0, ptr %t72, i32 %t73, i64 %a3)
  store { i64, ptr } %t75, ptr %l41
  br label %bb7
bb7:
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t76, ptr %l6, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i64, ptr %l1, !tbaa !24
  %t84 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t80, i64 %t81)
  store i1 %t84, ptr %l45
  br label %bb8
bb8:
  %t85 = load i1, ptr %l45, !tbaa !21
  br i1 %t85, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 10, ptr @.d13 }, ptr %l46, !tbaa !27
  br label %bb11
bb10:
  store { i64, ptr } { i64 3, ptr @.d14 }, ptr %l46, !tbaa !27
  br label %bb11
bb11:
  %t86 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  store i64 %t89, ptr %l48, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l49, !tbaa !24
  %t92 = icmp sge i64 3, 0
  br i1 %t92, label %bb12, label %bb13
bb12:
  %t94 = load i64, ptr %l48, !tbaa !24
  %t95 = icmp sle i64 3, %t94
  br i1 %t95, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb14:
  %t97 = load i64, ptr %l48, !tbaa !24
  %t98 = load i64, ptr %l49, !tbaa !24
  %t99 = icmp sle i64 %t97, %t98
  br i1 %t99, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb16:
  %t101 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l48, !tbaa !24
  %t104 = getelementptr i8, ptr %t102, i64 3
  %t105 = sub i64 %t103, 3
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %l8, !tbaa !27
  %t109 = load ptr, ptr %l4, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Func", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  br i1 %t114, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb18:
  %t116 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t116, 1
  %t121 = extractvalue { i64, ptr } %t116, 0
  %t123 = extractvalue { i64, ptr } %t117, 1
  %t124 = extractvalue { i64, ptr } %t117, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 1
  %t127 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 0
  %t128 = add i64 %t125, %t127
  %t130 = extractvalue { i64, ptr } %t118, 1
  %t131 = extractvalue { i64, ptr } %t118, 0
  %t132 = add i64 %t128, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t120, i64 %t121)
  %t134 = getelementptr i8, ptr %t133, i64 %t121
  call void @olang_textcopy(ptr %t134, ptr %t123, i64 %t124)
  %t135 = getelementptr i8, ptr %t134, i64 %t124
  call void @olang_textcopy(ptr %t135, ptr %t126, i64 %t127)
  %t136 = getelementptr i8, ptr %t135, i64 %t127
  call void @olang_textcopy(ptr %t136, ptr %t130, i64 %t131)
  %t137 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t133, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t138, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t140 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t142 = call i64 @compiler_2fexplain_2efirstItemEnd(ptr %s0, { i64, ptr } %t140)
  store i64 %t142, ptr %l62
  br label %bb21
bb21:
  %t143 = load i64, ptr %l62, !tbaa !24
  store i64 %t143, ptr %l9, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t144, ptr %l63, !tbaa !27
  %t145 = load i64, ptr %l9, !tbaa !24
  store i64 %t145, ptr %l64, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  store i64 %t147, ptr %l65, !tbaa !24
  %t148 = icmp sge i64 0, 0
  br i1 %t148, label %bb22, label %bb23
bb22:
  %t150 = load i64, ptr %l64, !tbaa !24
  %t151 = icmp sle i64 0, %t150
  br i1 %t151, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb24:
  %t153 = load i64, ptr %l64, !tbaa !24
  %t154 = load i64, ptr %l65, !tbaa !24
  %t155 = icmp sle i64 %t153, %t154
  br i1 %t155, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb26:
  %t157 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l64, !tbaa !24
  %t160 = getelementptr i8, ptr %t158, i64 0
  %t161 = sub i64 %t159, 0
  %t162 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t160, 1
  store { i64, ptr } %t163, ptr %l10, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t165, ptr %l70, !tbaa !27
  %t166 = load i64, ptr %l9, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i8, ptr %t169, i64 %t166
  %t171 = load i8, ptr %t170, !tbaa !32
  %t173 = icmp eq i8 %t171, 44
  br i1 %t173, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb28:
  %t175 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t175, ptr %l75, !tbaa !27
  %t176 = load i64, ptr %l9, !tbaa !24
  %t178 = add i64 %t176, 2
  store i64 %t178, ptr %l77, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t179, 0
  store i64 %t182, ptr %l80, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  store i64 %t184, ptr %l81, !tbaa !24
  %t185 = load i64, ptr %l77, !tbaa !24
  %t186 = icmp sge i64 %t185, 0
  br i1 %t186, label %bb30, label %bb31
bb29:
  %t188 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t188, ptr %l86, !tbaa !27
  %t189 = load i64, ptr %l9, !tbaa !24
  store i64 %t189, ptr %l87, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t190, 0
  store i64 %t193, ptr %l90, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  store i64 %t195, ptr %l91, !tbaa !24
  %t196 = load i64, ptr %l87, !tbaa !24
  %t197 = icmp sge i64 %t196, 0
  br i1 %t197, label %bb36, label %bb37
bb30:
  %t199 = load i64, ptr %l77, !tbaa !24
  %t200 = load i64, ptr %l80, !tbaa !24
  %t201 = icmp sle i64 %t199, %t200
  br i1 %t201, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb32:
  %t203 = load i64, ptr %l80, !tbaa !24
  %t204 = load i64, ptr %l81, !tbaa !24
  %t205 = icmp sle i64 %t203, %t204
  br i1 %t205, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb34:
  %t207 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l77, !tbaa !24
  %t210 = load i64, ptr %l80, !tbaa !24
  %t211 = getelementptr i8, ptr %t208, i64 %t209
  %t212 = sub i64 %t210, %t209
  %t213 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t211, 1
  store { i64, ptr } %t214, ptr %l74, !tbaa !27
  br label %bb42
bb35:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb36:
  %t216 = load i64, ptr %l87, !tbaa !24
  %t217 = load i64, ptr %l90, !tbaa !24
  %t218 = icmp sle i64 %t216, %t217
  br i1 %t218, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb38:
  %t220 = load i64, ptr %l90, !tbaa !24
  %t221 = load i64, ptr %l91, !tbaa !24
  %t222 = icmp sle i64 %t220, %t221
  br i1 %t222, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb40:
  %t224 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = load i64, ptr %l87, !tbaa !24
  %t227 = load i64, ptr %l90, !tbaa !24
  %t228 = getelementptr i8, ptr %t225, i64 %t226
  %t229 = sub i64 %t227, %t226
  %t230 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t228, 1
  store { i64, ptr } %t231, ptr %l74, !tbaa !27
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb42:
  %t233 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t234, 1
  %t240 = extractvalue { i64, ptr } %t234, 0
  %t241 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 1
  %t242 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 0
  %t243 = add i64 %t240, %t242
  %t245 = extractvalue { i64, ptr } %t235, 1
  %t246 = extractvalue { i64, ptr } %t235, 0
  %t247 = add i64 %t243, %t246
  %t248 = extractvalue { i64, ptr } { i64 2, ptr @.d17 }, 1
  %t249 = extractvalue { i64, ptr } { i64 2, ptr @.d17 }, 0
  %t250 = add i64 %t247, %t249
  %t252 = extractvalue { i64, ptr } %t236, 1
  %t253 = extractvalue { i64, ptr } %t236, 0
  %t254 = add i64 %t250, %t253
  %t255 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 1
  %t256 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 0
  %t257 = add i64 %t254, %t256
  %t259 = extractvalue { i64, ptr } %t233, 1
  %t260 = extractvalue { i64, ptr } %t233, 0
  %t261 = add i64 %t257, %t260
  %t262 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t261)
  call void @olang_textcopy(ptr %t262, ptr %t239, i64 %t240)
  %t263 = getelementptr i8, ptr %t262, i64 %t240
  call void @olang_textcopy(ptr %t263, ptr %t241, i64 %t242)
  %t264 = getelementptr i8, ptr %t263, i64 %t242
  call void @olang_textcopy(ptr %t264, ptr %t245, i64 %t246)
  %t265 = getelementptr i8, ptr %t264, i64 %t246
  call void @olang_textcopy(ptr %t265, ptr %t248, i64 %t249)
  %t266 = getelementptr i8, ptr %t265, i64 %t249
  call void @olang_textcopy(ptr %t266, ptr %t252, i64 %t253)
  %t267 = getelementptr i8, ptr %t266, i64 %t253
  call void @olang_textcopy(ptr %t267, ptr %t255, i64 %t256)
  %t268 = getelementptr i8, ptr %t267, i64 %t256
  call void @olang_textcopy(ptr %t268, ptr %t259, i64 %t260)
  %t269 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t262, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t270, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, %"compiler/names:Entry" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/names:Entry"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l8 = alloca { { i64, ptr }, i1 }
  %l9 = alloca { i64, ptr }
  %l19 = alloca i32
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca { { i64, ptr }, i1 }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l52 = alloca i32
  %l55 = alloca i32
  %l60 = alloca i32
  %l62 = alloca i32
  %l64 = alloca i32
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/names:Entry" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %t12, i64 %t13, i32 %t15)
  store i32 %t19, ptr %l19
  br label %bb1
bb1:
  %t20 = load i32, ptr %l19, !tbaa !23
  store i32 %t20, ptr %l5, !tbaa !23
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t21, i32 %t23)
  store { i64, ptr } %t26, ptr %l22
  br label %bb2
bb2:
  %t27 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr @.d19 }, ptr %l24, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 1, ptr @.d20 }, ptr %l24, !tbaa !27
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l5, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t30, i32 %t31)
  store { i64, ptr } %t34, ptr %l27
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t36, i64 %t37)
  %t47 = getelementptr i8, ptr %t46, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = getelementptr i8, ptr %t47, i64 %t40
  call void @olang_textcopy(ptr %t48, ptr %t43, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  %t52 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = extractvalue { i64, ptr } { i64 20, ptr @.d21 }, 1
  %t60 = extractvalue { i64, ptr } { i64 20, ptr @.d21 }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = getelementptr i8, ptr %t62, i64 %t58
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 1
  %t72 = load %"compiler/source:Span", ptr %t71
  %t77 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %t67, i64 %t68, i32 %t70, %"compiler/source:Span" %t72)
  store i64 %t77, ptr %l36
  br label %bb10
bb10:
  %t78 = load i64, ptr %l36, !tbaa !24
  %t83 = call { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v1, ptr %s0, ptr %a1, i64 %t78)
  store { { i64, ptr }, i1 } %t83, ptr %l39
  br label %bb11
bb11:
  %t84 = load { { i64, ptr }, i1 }, ptr %l39
  store { { i64, ptr }, i1 } %t84, ptr %l8
  %t85 = getelementptr { { i64, ptr }, i1 }, ptr %l8, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l40, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l41, !tbaa !24
  %t89 = load i64, ptr %l41, !tbaa !24
  %t90 = mul i64 %t89, 1
  %t91 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t90)
  %t92 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l42, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l41, !tbaa !24
  %t99 = mul i64 %t98, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t95, ptr %t97, i64 %t99, i1 false)
  %t100 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t100, ptr %l9, !tbaa !27
  %t101 = getelementptr { { i64, ptr }, i1 }, ptr %l8, i32 0, i32 1
  %t102 = load i1, ptr %t101, !tbaa !21
  %t106 = xor i1 %t102, true
  br i1 %t106, label %bb12, label %bb13
bb12:
  %t108 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = extractvalue { i64, ptr } %t108, 0
  %t112 = extractvalue { i64, ptr } { i64 20, ptr @.d22 }, 1
  %t113 = extractvalue { i64, ptr } { i64 20, ptr @.d22 }, 0
  %t114 = add i64 %t111, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t110, i64 %t111)
  %t116 = getelementptr i8, ptr %t115, i64 %t111
  call void @olang_textcopy(ptr %t116, ptr %t112, i64 %t113)
  %t117 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t118, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l5, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l52
  br label %bb15
bb15:
  %t130 = load i32, ptr %l52
  %t132 = trunc i64 20 to i32
  %t133 = icmp eq i32 %t130, %t132
  br i1 %t133, label %bb16, label %bb17
bb16:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l5, !tbaa !23
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t140, i32 %t141)
  store i32 %t144, ptr %l60
  br label %bb18
bb17:
  %t145 = load i32, ptr %l5, !tbaa !23
  store i32 %t145, ptr %l55, !tbaa !23
  br label %bb19
bb18:
  %t147 = load i32, ptr %l60, !tbaa !23
  store i32 %t147, ptr %l55, !tbaa !23
  br label %bb19
bb19:
  %t148 = load i32, ptr %l55, !tbaa !23
  store i32 %t148, ptr %l62, !tbaa !23
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %t150)
  store i32 %t152, ptr %l64
  br label %bb20
bb20:
  %t153 = load i32, ptr %l62, !tbaa !23
  %t154 = load i32, ptr %l64, !tbaa !23
  %t155 = icmp eq i32 %t153, %t154
  br i1 %t155, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t157 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t157, ptr %l66, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t160 = call { i64, ptr } @compiler_2fexplain_2equoted(ptr %s0, ptr %s6, { i64, ptr } %t158)
  store { i64, ptr } %t160, ptr %l68
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t161 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t164 = extractvalue { i64, ptr } { i64 3, ptr @.d23 }, 1
  %t165 = extractvalue { i64, ptr } { i64 3, ptr @.d23 }, 0
  %t166 = add i64 %t163, %t165
  %t167 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = add i64 %t166, %t169
  %t171 = extractvalue { i64, ptr } { i64 1, ptr @.d24 }, 1
  %t172 = extractvalue { i64, ptr } { i64 1, ptr @.d24 }, 0
  %t173 = add i64 %t170, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t162, i64 %t163)
  %t175 = getelementptr i8, ptr %t174, i64 %t163
  call void @olang_textcopy(ptr %t175, ptr %t164, i64 %t165)
  %t176 = getelementptr i8, ptr %t175, i64 %t165
  call void @olang_textcopy(ptr %t176, ptr %t168, i64 %t169)
  %t177 = getelementptr i8, ptr %t176, i64 %t169
  call void @olang_textcopy(ptr %t177, ptr %t171, i64 %t172)
  %t178 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t174, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t179, ptr %rv
  br label %ret
bb24:
  %t181 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = extractvalue { i64, ptr } %t181, 0
  %t186 = extractvalue { i64, ptr } { i64 3, ptr @.d25 }, 1
  %t187 = extractvalue { i64, ptr } { i64 3, ptr @.d25 }, 0
  %t188 = add i64 %t185, %t187
  %t190 = extractvalue { i64, ptr } %t182, 1
  %t191 = extractvalue { i64, ptr } %t182, 0
  %t192 = add i64 %t188, %t191
  %t193 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 1
  %t194 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 0
  %t195 = add i64 %t192, %t194
  %t196 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t195)
  call void @olang_textcopy(ptr %t196, ptr %t184, i64 %t185)
  %t197 = getelementptr i8, ptr %t196, i64 %t185
  call void @olang_textcopy(ptr %t197, ptr %t186, i64 %t187)
  %t198 = getelementptr i8, ptr %t197, i64 %t187
  call void @olang_textcopy(ptr %t198, ptr %t190, i64 %t191)
  %t199 = getelementptr i8, ptr %t198, i64 %t191
  call void @olang_textcopy(ptr %t199, ptr %t193, i64 %t194)
  %t200 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t196, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t201, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2emethods(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca i1
  %l54 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l75 = alloca i32
  %l82 = alloca i32
  %l87 = alloca i32
  %l91 = alloca i1
  %l96 = alloca i32
  %l101 = alloca i32
  %l104 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i64
  %l119 = alloca i32
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i64
  %l132 = alloca i32
  %l133 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v1, ptr %t4)
  br label %bb1
bb1:
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb2
bb2:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v1, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l44
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l44, !tbaa !29
  store ptr %t67, ptr %l9, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v1, ptr %t78, i32 %t79, i32 %t83)
  store i64 %t87, ptr %l54
  br label %bb16
bb16:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l54, !tbaa !24
  %t91 = icmp ne i64 %t89, %t88
  store i1 %t91, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t93 = load i1, ptr %l48, !tbaa !21
  br i1 %t93, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb19:
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l59, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t105, ptr %l62, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t109, i64 %t110)
  store i32 %t113, ptr %l66
  br label %bb21
bb21:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load i32, ptr %l66, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t114, i32 %t115)
  store i32 %t116, ptr %l67
  br label %bb22
bb22:
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load i32, ptr %l67, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %t117, i32 %t118)
  store { i64, ptr } %t119, ptr %l68
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t120, ptr %l69, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i32, ptr %t122, i64 0
  %t124 = load i32, ptr %t123, !tbaa !33
  store i32 %t124, ptr %l10, !tbaa !23
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l10, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l75
  br label %bb24
bb24:
  %t136 = load i32, ptr %l75
  %t138 = trunc i64 20 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb25, label %bb26
bb25:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l10, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v1, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l82
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t151 = load i32, ptr %l82, !tbaa !23
  store i32 %t151, ptr %l10, !tbaa !23
  br label %bb28
bb28:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  %t158 = load i32, ptr %l10, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t157, i32 %t158)
  store i32 %t161, ptr %l87
  br label %bb29
bb29:
  %t162 = load i32, ptr %l87
  %t164 = trunc i64 18 to i32
  %t165 = icmp eq i32 %t162, %t164
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb34
bb31:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/generic:Program", ptr %t172, i32 0, i32 2
  %t175 = load i32, ptr %l10, !tbaa !23
  %t178 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t174, i32 %t175)
  store i32 %t178, ptr %l96
  br label %bb32
bb32:
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l2, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l101
  br label %bb33
bb33:
  %t189 = load i32, ptr %l96, !tbaa !23
  %t190 = load i32, ptr %l101, !tbaa !23
  %t191 = icmp ne i32 %t189, %t190
  store i1 %t191, ptr %l91, !tbaa !21
  br label %bb34
bb34:
  %t193 = load i1, ptr %l91, !tbaa !21
  br i1 %t193, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb36:
  br label %bb37
bb37:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  store ptr %t197, ptr %l104, !tbaa !29
  %t198 = load i64, ptr %l8, !tbaa !24
  %t200 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t198)
  store i64 %t200, ptr %l106
  br label %bb38
bb38:
  %t201 = load ptr, ptr %l104, !tbaa !29
  %t202 = load i64, ptr %l106, !tbaa !24
  %t203 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t201, i64 %t202)
  store i64 %t203, ptr %l107
  br label %bb39
bb39:
  %t204 = load i64, ptr %l107, !tbaa !24
  %t205 = icmp eq i64 %t204, 0
  br i1 %t205, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v1, ptr %t210, i64 %t211, i32 0)
  store i64 %t214, ptr %l112
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l126, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  store ptr %t216, ptr %l127, !tbaa !29
  %t217 = load i64, ptr %l8, !tbaa !24
  store i64 %t217, ptr %l128, !tbaa !24
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t222 = load i64, ptr %l8, !tbaa !24
  %t225 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t221, i64 %t222)
  store i32 %t225, ptr %l132
  br label %bb47
bb42:
  %t226 = load i64, ptr %l112, !tbaa !24
  store i64 %t226, ptr %l11, !tbaa !24
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l113, !tbaa !29
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l114, !tbaa !29
  %t229 = load i64, ptr %l8, !tbaa !24
  store i64 %t229, ptr %l115, !tbaa !24
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v1, ptr %t233, i64 %t234)
  store i32 %t237, ptr %l119
  br label %bb43
bb43:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t239 = load i64, ptr %l11, !tbaa !24
  %t242 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v1, ptr %t238, i64 %t239)
  store i64 %t242, ptr %l122
  br label %bb44
bb44:
  %t243 = load ptr, ptr %l114, !tbaa !29
  %t244 = load i64, ptr %l115, !tbaa !24
  %t245 = load i32, ptr %l119, !tbaa !23
  %t246 = load i64, ptr %l122, !tbaa !24
  %t247 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s6, ptr %t243, i64 %t244, i32 %t245, i64 %t246)
  store { i64, ptr } %t247, ptr %l123
  br label %bb45
bb45:
  %t248 = extractvalue { i64, ptr } { i64 4, ptr @.d27 }, 1
  %t249 = extractvalue { i64, ptr } { i64 4, ptr @.d27 }, 0
  %t250 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t269 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t269, { i64, ptr } %t268)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb47:
  %t271 = load ptr, ptr %l127, !tbaa !29
  %t272 = load i64, ptr %l128, !tbaa !24
  %t273 = load i32, ptr %l132, !tbaa !23
  %t274 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s8, ptr %t271, i64 %t272, i32 %t273, i64 -1)
  store { i64, ptr } %t274, ptr %l133
  br label %bb48
bb48:
  %t275 = extractvalue { i64, ptr } { i64 4, ptr @.d29 }, 1
  %t276 = extractvalue { i64, ptr } { i64 4, ptr @.d29 }, 0
  %t277 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = add i64 %t276, %t279
  %t281 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 1
  %t282 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 0
  %t283 = add i64 %t280, %t282
  %t284 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t283)
  call void @olang_textcopy(ptr %t284, ptr %t275, i64 %t276)
  %t285 = getelementptr i8, ptr %t284, i64 %t276
  call void @olang_textcopy(ptr %t285, ptr %t278, i64 %t279)
  %t286 = getelementptr i8, ptr %t285, i64 %t279
  call void @olang_textcopy(ptr %t286, ptr %t281, i64 %t282)
  %t287 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t284, 1
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t291 = extractvalue { i64, ptr } %t288, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t296 = load ptr, ptr %l126, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t296, { i64, ptr } %t295)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb51:
  %t298 = load i64, ptr %l7, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l7, !tbaa !24
  br label %bb9
bb52:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca { i64, ptr }
  %l37 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l9
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Param", ptr %t10, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t15)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l7, !tbaa !24
  br label %bb8
bb7:
  br label %bb15
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t38 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t38, ptr %l27, !tbaa !27
  %t39 = load i64, ptr %l6, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  %t48 = getelementptr %"compiler/ast:Param", ptr %t44, i32 0, i32 1
  %t49 = load i32, ptr %t48, !tbaa !23
  %t51 = sext i32 %t49 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t51)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  br label %bb15
bb15:
  %t59 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t59, ptr %l37
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l1, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l45
  br label %bb17
bb17:
  %t76 = load ptr, ptr %l40, !tbaa !29
  %t77 = load i32, ptr %l45, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t76, i32 %t77)
  store { i64, ptr } %t78, ptr %l46
  br label %bb18
bb18:
  %t79 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  %t81 = load i64, ptr %l37, !tbaa !24
  %t83 = icmp ne i64 %t81, %t80
  br i1 %t83, label %bb19, label %bb20
bb19:
  %t85 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t85, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  store ptr %t92, ptr %l52, !tbaa !29
  %t93 = load i32, ptr %l1, !tbaa !23
  store i32 %t93, ptr %l53, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l56, !tbaa !29
  %t101 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t101, ptr %l58
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l56, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t104 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %s0, ptr %t102, { i64, ptr } %t103)
  store i64 %t104, ptr %l59
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l52, !tbaa !29
  %t106 = load i32, ptr %l53, !tbaa !23
  %t107 = load i64, ptr %l59, !tbaa !24
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t105, i32 %t106, i64 %t107)
  store i32 %t108, ptr %l60
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load i32, ptr %l60, !tbaa !23
  store i32 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fexplain_2eobligations(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v2, ptr %v1, ptr %s2, ptr %a2, i64 %t6, ptr %t16)
  store { i64, ptr } %t20, ptr %l17
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 16
  %t25 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  %t53 = extractvalue { i64, ptr } %a4, 1
  %t54 = extractvalue { i64, ptr } %a4, 0
  %t55 = extractvalue { i64, ptr } { i64 1, ptr @.d31 }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr @.d31 }, 0
  %t57 = add i64 %t54, %t56
  %t59 = extractvalue { i64, ptr } %t47, 1
  %t60 = extractvalue { i64, ptr } %t47, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 2, ptr @.d32 }, 1
  %t63 = extractvalue { i64, ptr } { i64 2, ptr @.d32 }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = getelementptr i8, ptr %t65, i64 %t54
  call void @olang_textcopy(ptr %t66, ptr %t55, i64 %t56)
  %t67 = getelementptr i8, ptr %t66, i64 %t56
  call void @olang_textcopy(ptr %t67, ptr %t59, i64 %t60)
  %t68 = getelementptr i8, ptr %t67, i64 %t60
  call void @olang_textcopy(ptr %t68, ptr %t62, i64 %t63)
  %t69 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t65, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %a0, { i64, ptr } %t77)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb5
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2equoted(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb2
bb2:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t19
  %t24 = load i8, ptr %t23, !tbaa !32
  store i8 %t24, ptr %l5, !tbaa !22
  %t26 = load i8, ptr %l5, !tbaa !22
  %t28 = icmp eq i8 %t26, 34
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 92
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb12
bb11:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 10
  br i1 %t38, label %bb14, label %bb15
bb12:
  %t40 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t40)
  br label %bb13
bb13:
  br label %bb23
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr @.d33 })
  br label %bb16
bb15:
  %t44 = load i8, ptr %l5, !tbaa !22
  %t46 = icmp eq i8 %t44, 9
  br i1 %t46, label %bb17, label %bb18
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 2, ptr @.d34 })
  br label %bb19
bb18:
  %t49 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t49)
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s7)
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb3
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb26
bb26:
  %t58 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t58, ptr %l38
  br label %bb27
bb27:
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t59, ptr %l39, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l40, !tbaa !24
  %t62 = load i64, ptr %l40, !tbaa !24
  %t63 = mul i64 %t62, 1
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l41, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = mul i64 %t71, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t68, ptr %t70, i64 %t72, i1 false)
  %t73 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t73, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l6 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l29 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Func", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l20
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load i32, ptr %l20, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l13, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 0
  %t47 = load i32, ptr %t46, !tbaa !33
  store i32 %t47, ptr %l2, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l29
  br label %bb8
bb8:
  %t59 = load i32, ptr %l29
  %t61 = trunc i64 20 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l36
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t74 = load i32, ptr %l36, !tbaa !23
  store i32 %t74, ptr %l2, !tbaa !23
  br label %bb12
bb12:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l41
  br label %bb13
bb13:
  %t85 = load i32, ptr %l41
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb14, label %bb15
bb14:
  store i64 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l48, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l2, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l53
  br label %bb17
bb17:
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t110 = load i32, ptr %l53, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l54
  br label %bb18
bb18:
  %t112 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i64
  %l42 = alloca i32
  %l45 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l10
  br label %bb3
bb3:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %t14, i32 %t15)
  store { i64, ptr } %t18, ptr %l14
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t24, ptr %l17
  br label %bb9
bb9:
  %t25 = load i32, ptr %l17, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l25
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb11
bb11:
  %t52 = load i32, ptr %l3, !tbaa !23
  store i32 %t52, ptr %l31, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l36
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t72, ptr %l41
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l20, !tbaa !29
  %t74 = load i32, ptr %l25, !tbaa !23
  %t75 = load i32, ptr %l30, !tbaa !23
  %t76 = load i32, ptr %l31, !tbaa !23
  %t77 = load i32, ptr %l36, !tbaa !23
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 %t74, i32 %t75, i32 %t76, i32 %t77, i64 %t78)
  store i32 %t79, ptr %l42
  br label %bb14
bb14:
  %t80 = load i32, ptr %l42, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t81, i32 %t80)
  store { i64, ptr } %t85, ptr %l45
  br label %bb15
bb15:
  %t86 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } { i64 27, ptr @.d35 }, 1
  %t90 = extractvalue { i64, ptr } { i64 27, ptr @.d35 }, 0
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = getelementptr i8, ptr %t92, i64 %t88
  call void @olang_textcopy(ptr %t93, ptr %t89, i64 %t90)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2etraitsMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca %"compiler/names:Entry"
  %l89 = alloca i1
  %l93 = alloca %"compiler/names:Entry"
  %l100 = alloca i32
  %l105 = alloca i32
  %l109 = alloca i1
  %l111 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i32
  %l124 = alloca i1
  %l125 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca ptr
  %l139 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l19
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/names:Resolver", ptr %t10, i32 0, i32 1
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_Hb234e65a2b42ee429ada36859295662b(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l24, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l31, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l31, !tbaa !24
  store i64 %t42, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/names:Resolver", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v1, ptr %v1, ptr %t70, i64 %t71)
  store ptr %t74, ptr %l54
  br label %bb13
bb13:
  %t75 = load ptr, ptr %l54, !tbaa !29
  store ptr %t75, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  %t76 = load ptr, ptr %l10, !tbaa !29
  %t78 = getelementptr %"compiler/names:Table", ptr %t76, i32 0, i32 0
  %t80 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %t78)
  store i64 %t80, ptr %l57
  br label %bb14
bb14:
  %t81 = load i64, ptr %l57, !tbaa !24
  store i64 %t81, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t82 = load i64, ptr %l12, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb15, label %bb16
bb15:
  %t88 = load i64, ptr %l13, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb20
bb17:
  %t92 = load i64, ptr %l12, !tbaa !24
  %t93 = load i64, ptr %l11, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l13, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l64, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb19
bb19:
  %t108 = load i64, ptr %l64, !tbaa !24
  store i64 %t108, ptr %l61, !tbaa !24
  br label %bb20
bb20:
  %t109 = load i64, ptr %l61, !tbaa !24
  store i64 %t109, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t110 = load i64, ptr %l15, !tbaa !24
  %t111 = load i64, ptr %l14, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb23:
  br label %bb24
bb24:
  %t118 = load i64, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l15, !tbaa !24
  %t120 = load i64, ptr %l13, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  store i64 %t126, ptr %l16, !tbaa !24
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t130 = getelementptr %"compiler/names:Table", ptr %t128, i32 0, i32 0
  %t131 = load i64, ptr %l16, !tbaa !24
  %t134 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %s4, ptr %t130, i64 %t131)
  store %"compiler/names:Entry" %t134, ptr %l85
  br label %bb25
bb25:
  %t135 = getelementptr %"compiler/names:Entry", ptr %l85, i32 0, i32 2
  %t136 = load i32, ptr %t135
  %t138 = trunc i64 4 to i32
  %t139 = icmp eq i32 %t136, %t138
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb29
bb27:
  %t143 = load ptr, ptr %l10, !tbaa !29
  %t145 = getelementptr %"compiler/names:Table", ptr %t143, i32 0, i32 0
  %t146 = load i64, ptr %l16, !tbaa !24
  %t149 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %v1, ptr %t145, i64 %t146)
  store %"compiler/names:Entry" %t149, ptr %l93
  br label %bb28
bb28:
  %t150 = getelementptr %"compiler/names:Entry", ptr %l93, i32 0, i32 4
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  store i1 %t153, ptr %l89, !tbaa !21
  br label %bb29
bb29:
  %t155 = load i1, ptr %l89, !tbaa !21
  br i1 %t155, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb31:
  br label %bb32
bb32:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i64, ptr %l9, !tbaa !24
  %t161 = load i64, ptr %l16, !tbaa !24
  %t165 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v1, ptr %t159, i64 %t160, i64 %t161)
  store i32 %t165, ptr %l100
  br label %bb33
bb33:
  %t166 = load i32, ptr %l100, !tbaa !23
  store i32 %t166, ptr %l17, !tbaa !23
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l17, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v1, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l105
  br label %bb34
bb34:
  %t177 = load i32, ptr %l105
  %t179 = trunc i64 3 to i32
  %t180 = icmp eq i32 %t177, %t179
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb39
bb36:
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  store ptr %t187, ptr %l111, !tbaa !29
  %t188 = load i32, ptr %l17, !tbaa !23
  %t190 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t188)
  store i64 %t190, ptr %l113
  br label %bb37
bb37:
  %t191 = load ptr, ptr %l111, !tbaa !29
  %t192 = load i64, ptr %l113, !tbaa !24
  %t193 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t191, i64 %t192)
  store i64 %t193, ptr %l114
  br label %bb38
bb38:
  %t194 = load i64, ptr %l114, !tbaa !24
  %t195 = icmp sgt i64 %t194, 0
  store i1 %t195, ptr %l109, !tbaa !21
  br label %bb39
bb39:
  %t197 = load i1, ptr %l109, !tbaa !21
  br i1 %t197, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb41:
  br label %bb42
bb42:
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t202 = load i32, ptr %l17, !tbaa !23
  %t205 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v1, ptr %t201, i32 %t202)
  store i32 %t205, ptr %l119
  br label %bb43
bb43:
  %t206 = load i32, ptr %l119, !tbaa !23
  store i32 %t206, ptr %l18, !tbaa !23
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = load i32, ptr %l18, !tbaa !23
  %t216 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v1, ptr %t210, i32 %a2, i32 %t212)
  store i1 %t216, ptr %l124
  br label %bb44
bb44:
  %t217 = load i1, ptr %l124, !tbaa !21
  br i1 %t217, label %bb45, label %bb46
bb45:
  store ptr %l3, ptr %l125, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t219 = load i32, ptr %l18, !tbaa !23
  %t222 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s0, ptr %t218, i32 %t219)
  store { i64, ptr } %t222, ptr %l128
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t223 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = extractvalue { i64, ptr } %t223, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  %t230 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t230, { i64, ptr } %t229)
  br label %bb48
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb50:
  %t232 = load i64, ptr %l15, !tbaa !24
  %t234 = add i64 %t232, 1
  store i64 %t234, ptr %l15, !tbaa !24
  br label %bb21
bb51:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb52:
  %t236 = load i64, ptr %l8, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l8, !tbaa !24
  br label %bb9
bb53:
  %t241 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l3)
  store i64 %t241, ptr %l135
  br label %bb54
bb54:
  %t242 = load i64, ptr %l135, !tbaa !24
  %t243 = icmp sgt i64 %t242, 0
  br i1 %t243, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %a0, ptr %l137, !tbaa !29
  %t247 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s10, ptr %s10, ptr %l3, { i64, ptr } { i64 2, ptr @.d36 })
  store { i64, ptr } %t247, ptr %l139
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t248 = extractvalue { i64, ptr } { i64 10, ptr @.d37 }, 1
  %t249 = extractvalue { i64, ptr } { i64 10, ptr @.d37 }, 0
  %t250 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr @.d38 }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr @.d38 }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t269 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s10, ptr %t269, { i64, ptr } %t268)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 60)
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t9, i32 %a1)
  store { i64, ptr } %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb6:
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  store i32 %t33, ptr %l7, !tbaa !23
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr @.d39 })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb11:
  store ptr %l2, ptr %l27, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l7, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s2, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l30
  br label %bb12
bb12:
  %t45 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t52 = load ptr, ptr %l27, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t52, { i64, ptr } %t51)
  br label %bb13
bb13:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb4
bb15:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 62)
  br label %bb16
bb16:
  %t64 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t64, ptr %l38
  br label %bb17
bb17:
  %t65 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t65, ptr %l39, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l40, !tbaa !24
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l41, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l40, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t79, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t80 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca %"std/prelude/text:StringBuilder"
  %l44 = alloca i32
  %l48 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l69 = alloca i32
  %l79 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l115 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca i1
  %l132 = alloca ptr
  %l147 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l154 = alloca i64
  %l157 = alloca i64
  %l158 = alloca i64
  %l163 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca i64
  %l172 = alloca { i64, ptr }
  %l181 = alloca ptr
  %l186 = alloca i32
  %l187 = alloca { i64, ptr }
  %l192 = alloca { i64, ptr }
  %l198 = alloca i64
  %l201 = alloca i64
  %l219 = alloca ptr
  %l221 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l231 = alloca i1
  %l232 = alloca { i64, ptr }
  %l239 = alloca ptr
  %l244 = alloca i1
  %l245 = alloca ptr
  %l246 = alloca ptr
  %l249 = alloca ptr
  %l252 = alloca ptr
  %l257 = alloca i32
  %l258 = alloca i32
  %l259 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l265 = alloca ptr
  %l266 = alloca ptr
  %l271 = alloca i32
  %l275 = alloca ptr
  %l280 = alloca { i64, ptr }
  %l281 = alloca i32
  %l282 = alloca { i64, ptr }
  %l283 = alloca ptr
  %l285 = alloca i64
  %l286 = alloca i64
  %l287 = alloca i64
  %l297 = alloca ptr
  %l298 = alloca { i64, ptr }
  %l302 = alloca i1
  %l303 = alloca { i64, ptr }
  %l304 = alloca ptr
  %l309 = alloca i32
  %l310 = alloca { i64, ptr }
  %l316 = alloca ptr
  %l322 = alloca ptr
  %l323 = alloca i1
  %l331 = alloca ptr
  %l332 = alloca ptr
  %l336 = alloca i32
  %l340 = alloca i32
  %l341 = alloca { i64, ptr }
  %l343 = alloca i64
  %l344 = alloca ptr
  %l346 = alloca i64
  %l347 = alloca i64
  %l351 = alloca { i64, ptr }
  %l353 = alloca i64
  %l355 = alloca i64
  %l356 = alloca i64
  %l361 = alloca { i64, ptr }
  %l367 = alloca ptr
  %l368 = alloca ptr
  %l372 = alloca i32
  %l376 = alloca ptr
  %l380 = alloca { i64, ptr }
  %l381 = alloca i32
  %l382 = alloca { i64, ptr }
  %l384 = alloca i64
  %l385 = alloca ptr
  %l386 = alloca { i64, ptr }
  %l388 = alloca i64
  %l389 = alloca i64
  %l393 = alloca { i64, ptr }
  %l395 = alloca i64
  %l397 = alloca i64
  %l398 = alloca i64
  %l403 = alloca { i64, ptr }
  %l416 = alloca { i64, ptr }
  %l417 = alloca { i64, ptr }
  %l418 = alloca i64
  %l419 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l40
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l40
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l44
  br label %bb2
bb2:
  %t11 = load i32, ptr %l44, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l48
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l4, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  store ptr %t31, ptr %l53, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l58
  br label %bb4
bb4:
  %t42 = load ptr, ptr %l53, !tbaa !29
  %t43 = load i32, ptr %l58, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l59
  br label %bb5
bb5:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l60, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t48 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t46)
  store i64 %t48, ptr %l62
  br label %bb6
bb6:
  %t49 = load ptr, ptr %l60, !tbaa !29
  %t50 = load i64, ptr %l62, !tbaa !24
  %t51 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t49, i64 %t50, i64 0)
  store { i64, ptr } %t51, ptr %l63
  br label %bb7
bb7:
  %t52 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = add i64 %t54, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t53, i64 %t54)
  %t60 = getelementptr i8, ptr %t59, i64 %t54
  call void @olang_textcopy(ptr %t60, ptr %t56, i64 %t57)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  store { i64, ptr } %t62, ptr %l5, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l69
  br label %bb8
bb8:
  %t74 = load i32, ptr %l69
  store i32 %t74, ptr %l6
  %t75 = load i32, ptr %l6
  %t77 = trunc i64 2 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb23
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = extractvalue { i64, ptr } { i64 6, ptr @.d40 }, 1
  %t82 = extractvalue { i64, ptr } { i64 6, ptr @.d40 }, 0
  %t84 = extractvalue { i64, ptr } %t80, 1
  %t85 = extractvalue { i64, ptr } %t80, 0
  %t86 = add i64 %t82, %t85
  %t87 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 1
  %t88 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 0
  %t89 = add i64 %t86, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t81, i64 %t82)
  %t91 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t91, ptr %t84, i64 %t85)
  %t92 = getelementptr i8, ptr %t91, i64 %t85
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t90, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = extractvalue { i64, ptr } %t94, 1
  %t98 = mul i64 %t96, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t97, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t101)
  br label %bb12
bb12:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l79
  br label %bb13
bb13:
  %t112 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t112, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t117 = load i64, ptr %l8, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb16:
  br label %bb17
bb17:
  %t125 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t125, ptr %l86, !tbaa !27
  %t126 = load i64, ptr %l8, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i32, ptr %t129, i64 %t126
  %t131 = load i32, ptr %t130, !tbaa !33
  store ptr %l2, ptr %l89, !tbaa !29
  %t133 = load ptr, ptr %l4, !tbaa !29
  %t137 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t133, i32 %t131)
  store { i64, ptr } %t137, ptr %l92
  br label %bb18
bb18:
  %t138 = extractvalue { i64, ptr } { i64 4, ptr @.d42 }, 1
  %t139 = extractvalue { i64, ptr } { i64 4, ptr @.d42 }, 0
  %t140 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = add i64 %t139, %t142
  %t144 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 0
  %t146 = add i64 %t143, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t138, i64 %t139)
  %t148 = getelementptr i8, ptr %t147, i64 %t139
  call void @olang_textcopy(ptr %t148, ptr %t141, i64 %t142)
  %t149 = getelementptr i8, ptr %t148, i64 %t142
  call void @olang_textcopy(ptr %t149, ptr %t144, i64 %t145)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t147, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t159 = load ptr, ptr %l89, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t159, { i64, ptr } %t158)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t161 = load i64, ptr %l8, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l8, !tbaa !24
  br label %bb14
bb21:
  %t166 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t166, ptr %l98
  br label %bb22
bb22:
  %t167 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t167, ptr %l99, !tbaa !27
  %t168 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  store i64 %t169, ptr %l100, !tbaa !24
  %t170 = load i64, ptr %l100, !tbaa !24
  %t171 = mul i64 %t170, 1
  %t172 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l101, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = load i64, ptr %l100, !tbaa !24
  %t180 = mul i64 %t179, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t176, ptr %t178, i64 %t180, i1 false)
  %t181 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t181, ptr %l99, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t182 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t182, ptr %rv
  br label %ret
bb23:
  %t183 = load i32, ptr %l6
  %t185 = trunc i64 3 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb63
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t188 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t189 = extractvalue { i64, ptr } { i64 5, ptr @.d44 }, 1
  %t190 = extractvalue { i64, ptr } { i64 5, ptr @.d44 }, 0
  %t192 = extractvalue { i64, ptr } %t188, 1
  %t193 = extractvalue { i64, ptr } %t188, 0
  %t194 = add i64 %t190, %t193
  %t195 = extractvalue { i64, ptr } { i64 7, ptr @.d45 }, 1
  %t196 = extractvalue { i64, ptr } { i64 7, ptr @.d45 }, 0
  %t197 = add i64 %t194, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t189, i64 %t190)
  %t199 = getelementptr i8, ptr %t198, i64 %t190
  call void @olang_textcopy(ptr %t199, ptr %t192, i64 %t193)
  %t200 = getelementptr i8, ptr %t199, i64 %t193
  call void @olang_textcopy(ptr %t200, ptr %t195, i64 %t196)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t198, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l2, { i64, ptr } %t209)
  br label %bb27
bb27:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t216 = load i32, ptr %l1, !tbaa !23
  %t219 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t215, i32 %t216)
  store ptr %t219, ptr %l111
  br label %bb28
bb28:
  %t220 = load ptr, ptr %l111, !tbaa !29
  store ptr %t220, ptr %l11, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t225 = load i32, ptr %l1, !tbaa !23
  %t228 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t224, i32 %t225)
  store i64 %t228, ptr %l115
  br label %bb29
bb29:
  %t229 = load i64, ptr %l115, !tbaa !24
  store i64 %t229, ptr %l12, !tbaa !24
  %t230 = load ptr, ptr %l11, !tbaa !29
  %t232 = icmp eq ptr %t230, null
  br i1 %t232, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a)
  unreachable
bb31:
  br label %bb32
bb32:
  %t234 = load ptr, ptr %l11, !tbaa !29
  %t237 = getelementptr %"compiler/ast:TypeDecl", ptr %t234, i32 0, i32 3
  %t238 = load ptr, ptr %t237, !tbaa !29
  store ptr %t238, ptr %l13, !tbaa !29
  %t240 = load ptr, ptr %l13, !tbaa !29
  store ptr %t240, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t241 = load ptr, ptr %l121, !tbaa !29
  %t242 = icmp ne ptr %t241, null
  br i1 %t242, label %bb33, label %bb34
bb33:
  %t244 = load ptr, ptr %l121, !tbaa !29
  %t245 = load i64, ptr %t244
  %t247 = icmp eq i64 %t245, 2
  store i1 %t247, ptr %l122, !tbaa !21
  br label %bb34
bb34:
  %t248 = load i1, ptr %l122, !tbaa !21
  br i1 %t248, label %bb35, label %bb36
bb35:
  %t249 = load ptr, ptr %l13, !tbaa !29
  %t251 = getelementptr { i64, [2 x i64] }, ptr %t249, i32 0, i32 1
  %t252 = getelementptr { { i64, ptr } }, ptr %t251, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252
  store { i64, ptr } %t253, ptr %l14, !tbaa !27
  br label %bb37
bb36:
  br label %bb56
bb37:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/check:Checker", ptr %t255, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t260 = getelementptr %"compiler/generic:Program", ptr %t258, i32 0, i32 0
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t263 = getelementptr %"compiler/load:Loader", ptr %t261, i32 0, i32 5
  %t264 = load i64, ptr %l12, !tbaa !24
  %t267 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t263, i64 %t264)
  store ptr %t267, ptr %l132
  br label %bb38
bb38:
  %t268 = load ptr, ptr %l132, !tbaa !29
  %t270 = getelementptr %"compiler/load:Module", ptr %t268, i32 0, i32 6
  %t271 = load ptr, ptr %t270, !tbaa !29
  store ptr %t271, ptr %l15, !tbaa !29
  %t273 = load ptr, ptr %l15, !tbaa !29
  %t275 = icmp eq ptr %t273, null
  br i1 %t275, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_9d3c9a5d5d1efd85_5425f31610037701)
  unreachable
bb40:
  br label %bb41
bb41:
  %t277 = load ptr, ptr %l15, !tbaa !29
  %t280 = getelementptr %"compiler/source:Source", ptr %t277, i32 0, i32 1
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !27
  store { i64, ptr } %t281, ptr %l16, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t283, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t285 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t285, 0
  store i64 %t287, ptr %l19, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s12
  %t289 = load i64, ptr %l18, !tbaa !24
  %t290 = load i64, ptr %l19, !tbaa !24
  %t293 = icmp slt i64 %t289, %t290
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s12)
  br label %bb55
bb44:
  br label %bb45
bb45:
  %t297 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t297, ptr %l147, !tbaa !27
  %t298 = load i64, ptr %l18, !tbaa !24
  %t300 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr ptr, ptr %t301, i64 %t298
  %t303 = load ptr, ptr %t302, !tbaa !39
  store ptr %t303, ptr %l20, !tbaa !29
  store ptr %l2, ptr %l150, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t305, ptr %l151, !tbaa !27
  %t306 = load ptr, ptr %l20, !tbaa !29
  %t308 = getelementptr %"compiler/ast:Func", ptr %t306, i32 0, i32 0
  %t309 = getelementptr %"compiler/source:Span", ptr %t308, i32 0, i32 0
  %t310 = load i32, ptr %t309, !tbaa !23
  %t312 = sext i32 %t310 to i64
  store i64 %t312, ptr %l154, !tbaa !24
  %t313 = load ptr, ptr %l20, !tbaa !29
  %t315 = getelementptr %"compiler/ast:Func", ptr %t313, i32 0, i32 0
  %t316 = getelementptr %"compiler/source:Span", ptr %t315, i32 0, i32 1
  %t317 = load i32, ptr %t316, !tbaa !23
  %t319 = sext i32 %t317 to i64
  store i64 %t319, ptr %l157, !tbaa !24
  %t320 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 0
  store i64 %t321, ptr %l158, !tbaa !24
  %t322 = load i64, ptr %l154, !tbaa !24
  %t323 = icmp sge i64 %t322, 0
  br i1 %t323, label %bb46, label %bb47
bb46:
  %t325 = load i64, ptr %l154, !tbaa !24
  %t326 = load i64, ptr %l157, !tbaa !24
  %t327 = icmp sle i64 %t325, %t326
  br i1 %t327, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_5a53f5e20717fed8_f65869ca84068ea4)
  unreachable
bb48:
  %t329 = load i64, ptr %l157, !tbaa !24
  %t330 = load i64, ptr %l158, !tbaa !24
  %t331 = icmp sle i64 %t329, %t330
  br i1 %t331, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_5a53f5e20717fed8_f65869ca84068ea4)
  unreachable
bb50:
  %t333 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = load i64, ptr %l154, !tbaa !24
  %t336 = load i64, ptr %l157, !tbaa !24
  %t337 = getelementptr i8, ptr %t334, i64 %t335
  %t338 = sub i64 %t336, %t335
  %t339 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t337, 1
  %t342 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t340)
  store { i64, ptr } %t342, ptr %l163
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_5a53f5e20717fed8_f65869ca84068ea4)
  unreachable
bb52:
  %t343 = extractvalue { i64, ptr } { i64 4, ptr @.d46 }, 1
  %t344 = extractvalue { i64, ptr } { i64 4, ptr @.d46 }, 0
  %t345 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t346 = extractvalue { i64, ptr } %t345, 1
  %t347 = extractvalue { i64, ptr } %t345, 0
  %t348 = add i64 %t344, %t347
  %t349 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 1
  %t350 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 0
  %t351 = add i64 %t348, %t350
  %t352 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t351)
  call void @olang_textcopy(ptr %t352, ptr %t343, i64 %t344)
  %t353 = getelementptr i8, ptr %t352, i64 %t344
  call void @olang_textcopy(ptr %t353, ptr %t346, i64 %t347)
  %t354 = getelementptr i8, ptr %t353, i64 %t347
  call void @olang_textcopy(ptr %t354, ptr %t349, i64 %t350)
  %t355 = insertvalue { i64, ptr } undef, i64 %t351, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t352, 1
  %t358 = extractvalue { i64, ptr } %t356, 0
  %t359 = extractvalue { i64, ptr } %t356, 1
  %t360 = mul i64 %t358, 1
  %t361 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t360)
  call void @llvm.memcpy.p0.p0.i64(ptr %t361, ptr %t359, i64 %t360, i1 false)
  %t362 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  %t364 = load ptr, ptr %l150, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t364, { i64, ptr } %t363)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s12)
  br label %bb54
bb54:
  %t366 = load i64, ptr %l18, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l18, !tbaa !24
  br label %bb42
bb55:
  br label %bb61
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_9dc6315c1529a356_ea501a6f2f322362)
  unreachable
bb61:
  %t371 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t371, ptr %l169
  br label %bb62
bb62:
  %t372 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t372, ptr %l170, !tbaa !27
  %t373 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t373, 0
  store i64 %t374, ptr %l171, !tbaa !24
  %t375 = load i64, ptr %l171, !tbaa !24
  %t376 = mul i64 %t375, 1
  %t377 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t376)
  %t378 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t377, 1
  store { i64, ptr } %t379, ptr %l172, !tbaa !27
  %t380 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !27
  %t382 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = load i64, ptr %l171, !tbaa !24
  %t385 = mul i64 %t384, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t381, ptr %t383, i64 %t385, i1 false)
  %t386 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t386, ptr %l170, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t387 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t387, ptr %rv
  br label %ret
bb63:
  %t388 = load i32, ptr %l6
  %t390 = trunc i64 1 to i32
  %t391 = icmp eq i32 %t388, %t390
  br i1 %t391, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb121
bb66:
  store %olang.scope zeroinitializer, ptr %s16
  %t393 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t394 = extractvalue { i64, ptr } { i64 5, ptr @.d48 }, 1
  %t395 = extractvalue { i64, ptr } { i64 5, ptr @.d48 }, 0
  %t397 = extractvalue { i64, ptr } %t393, 1
  %t398 = extractvalue { i64, ptr } %t393, 0
  %t399 = add i64 %t395, %t398
  %t400 = extractvalue { i64, ptr } { i64 6, ptr @.d49 }, 1
  %t401 = extractvalue { i64, ptr } { i64 6, ptr @.d49 }, 0
  %t402 = add i64 %t399, %t401
  %t403 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t394, i64 %t395)
  %t404 = getelementptr i8, ptr %t403, i64 %t395
  call void @olang_textcopy(ptr %t404, ptr %t397, i64 %t398)
  %t405 = getelementptr i8, ptr %t404, i64 %t398
  call void @olang_textcopy(ptr %t405, ptr %t400, i64 %t401)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t403, 1
  %t409 = extractvalue { i64, ptr } %t407, 0
  %t410 = extractvalue { i64, ptr } %t407, 1
  %t411 = mul i64 %t409, 1
  %t412 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t411)
  call void @llvm.memcpy.p0.p0.i64(ptr %t412, ptr %t410, i64 %t411, i1 false)
  %t413 = insertvalue { i64, ptr } undef, i64 %t409, 0
  %t414 = insertvalue { i64, ptr } %t413, ptr %t412, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l2, { i64, ptr } %t414)
  br label %bb67
bb67:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/check:Checker", ptr %t417, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t422 = getelementptr %"compiler/generic:Program", ptr %t420, i32 0, i32 2
  store ptr %t422, ptr %l181, !tbaa !29
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !29
  %t428 = getelementptr %"compiler/generic:Program", ptr %t426, i32 0, i32 2
  %t429 = load i32, ptr %l3, !tbaa !23
  %t432 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t428, i32 %t429)
  store i32 %t432, ptr %l186
  br label %bb68
bb68:
  %t433 = load ptr, ptr %l181, !tbaa !29
  %t434 = load i32, ptr %l186, !tbaa !23
  %t435 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t433, i32 %t434)
  store { i64, ptr } %t435, ptr %l187
  br label %bb69
bb69:
  %t436 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t436, ptr %l21, !tbaa !27
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/check:Checker", ptr %t437, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !29
  %t442 = getelementptr %"compiler/generic:Program", ptr %t440, i32 0, i32 2
  %t443 = load i32, ptr %l3, !tbaa !23
  %t446 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t442, i32 %t443)
  store { i64, ptr } %t446, ptr %l192
  br label %bb70
bb70:
  %t447 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t447, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t448 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t450 = extractvalue { i64, ptr } %t448, 0
  store i64 %t450, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t452 = load i64, ptr %l24, !tbaa !24
  %t453 = load i64, ptr %l23, !tbaa !24
  %t456 = icmp sgt i64 %t452, %t453
  br i1 %t456, label %bb71, label %bb72
bb71:
  %t458 = load i64, ptr %l25, !tbaa !24
  %t460 = icmp sgt i64 %t458, 0
  br i1 %t460, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb76
bb73:
  %t462 = load i64, ptr %l24, !tbaa !24
  %t463 = load i64, ptr %l23, !tbaa !24
  %t466 = sub i64 %t462, %t463
  %t467 = load i64, ptr %l25, !tbaa !24
  %t470 = add i64 %t466, %t467
  %t472 = sub i64 %t470, 1
  %t473 = load i64, ptr %l25, !tbaa !24
  %t476 = sdiv i64 %t472, %t473
  store i64 %t476, ptr %l201, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb75
bb75:
  %t478 = load i64, ptr %l201, !tbaa !24
  store i64 %t478, ptr %l198, !tbaa !24
  br label %bb76
bb76:
  %t479 = load i64, ptr %l198, !tbaa !24
  store i64 %t479, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s19
  %t480 = load i64, ptr %l27, !tbaa !24
  %t481 = load i64, ptr %l26, !tbaa !24
  %t484 = icmp slt i64 %t480, %t481
  %t486 = xor i1 %t484, true
  br i1 %t486, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s19)
  br label %bb120
bb79:
  br label %bb80
bb80:
  %t488 = load i64, ptr %l23, !tbaa !24
  %t489 = load i64, ptr %l27, !tbaa !24
  %t490 = load i64, ptr %l25, !tbaa !24
  %t493 = mul i64 %t489, %t490
  %t496 = add i64 %t488, %t493
  store i64 %t496, ptr %l28, !tbaa !24
  store ptr %l2, ptr %l219, !tbaa !29
  %t498 = load ptr, ptr %l4, !tbaa !29
  %t499 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t499, ptr %l221, !tbaa !27
  %t500 = load i64, ptr %l28, !tbaa !24
  %t502 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t503 = load ptr, ptr %t502, !tbaa !27
  %t504 = getelementptr i32, ptr %t503, i64 %t500
  %t505 = load i32, ptr %t504, !tbaa !33
  %t508 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t498, i32 %t505)
  store { i64, ptr } %t508, ptr %l224
  br label %bb81
bb81:
  %t509 = extractvalue { i64, ptr } { i64 4, ptr @.d50 }, 1
  %t510 = extractvalue { i64, ptr } { i64 4, ptr @.d50 }, 0
  %t511 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t512 = extractvalue { i64, ptr } %t511, 1
  %t513 = extractvalue { i64, ptr } %t511, 0
  %t514 = add i64 %t510, %t513
  %t515 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t514)
  call void @olang_textcopy(ptr %t515, ptr %t509, i64 %t510)
  %t516 = getelementptr i8, ptr %t515, i64 %t510
  call void @olang_textcopy(ptr %t516, ptr %t512, i64 %t513)
  %t517 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t518 = insertvalue { i64, ptr } %t517, ptr %t515, 1
  %t520 = extractvalue { i64, ptr } %t518, 0
  %t521 = extractvalue { i64, ptr } %t518, 1
  %t522 = mul i64 %t520, 1
  %t523 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t522)
  call void @llvm.memcpy.p0.p0.i64(ptr %t523, ptr %t521, i64 %t522, i1 false)
  %t524 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t525 = insertvalue { i64, ptr } %t524, ptr %t523, 1
  %t526 = load ptr, ptr %l219, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s19, ptr %t526, { i64, ptr } %t525)
  br label %bb82
bb82:
  %t528 = load i64, ptr %l28, !tbaa !24
  %t529 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t531 = extractvalue { i64, ptr } %t529, 0
  %t534 = icmp slt i64 %t528, %t531
  br i1 %t534, label %bb83, label %bb84
bb83:
  %t536 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t536, ptr %l232, !tbaa !27
  %t537 = load i64, ptr %l28, !tbaa !24
  %t539 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t540 = load ptr, ptr %t539, !tbaa !27
  %t541 = getelementptr i32, ptr %t540, i64 %t537
  %t542 = load i32, ptr %t541, !tbaa !33
  %t544 = icmp ne i32 %t542, 0
  store i1 %t544, ptr %l231, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l231, !tbaa !21
  br label %bb85
bb85:
  %t546 = load i1, ptr %l231, !tbaa !21
  br i1 %t546, label %bb86, label %bb87
bb86:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t549 = getelementptr %"compiler/check:Checker", ptr %t547, i32 0, i32 1
  %t550 = load ptr, ptr %t549, !tbaa !29
  %t551 = load i32, ptr %l1, !tbaa !23
  %t554 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t550, i32 %t551)
  store ptr %t554, ptr %l239
  br label %bb88
bb87:
  br label %bb117
bb88:
  %t555 = load ptr, ptr %l239, !tbaa !29
  store ptr %t555, ptr %l29, !tbaa !29
  %t556 = load ptr, ptr %l29, !tbaa !29
  %t558 = icmp eq ptr %t556, null
  br i1 %t558, label %bb89, label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_4d095160ba2e11c2_99802ec0c9206b6)
  unreachable
bb90:
  br label %bb91
bb91:
  %t560 = load ptr, ptr %l29, !tbaa !29
  %t561 = load i64, ptr %l28, !tbaa !24
  %t564 = call i1 @compiler_2fexplain_2ecaseWhole(ptr %v0, ptr %t560, i64 %t561)
  store i1 %t564, ptr %l244
  br label %bb92
bb92:
  %t565 = load i1, ptr %l244, !tbaa !21
  br i1 %t565, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s22
  store ptr %l2, ptr %l245, !tbaa !29
  %t566 = load ptr, ptr %l0, !tbaa !29
  store ptr %t566, ptr %l246, !tbaa !29
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t569 = getelementptr %"compiler/check:Checker", ptr %t567, i32 0, i32 1
  %t570 = load ptr, ptr %t569, !tbaa !29
  %t572 = getelementptr %"compiler/generic:Program", ptr %t570, i32 0, i32 2
  store ptr %t572, ptr %l249, !tbaa !29
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t575 = getelementptr %"compiler/check:Checker", ptr %t573, i32 0, i32 1
  %t576 = load ptr, ptr %t575, !tbaa !29
  %t578 = getelementptr %"compiler/generic:Program", ptr %t576, i32 0, i32 2
  store ptr %t578, ptr %l252, !tbaa !29
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t581 = getelementptr %"compiler/check:Checker", ptr %t579, i32 0, i32 1
  %t582 = load ptr, ptr %t581, !tbaa !29
  %t583 = load i32, ptr %l3, !tbaa !23
  %t584 = load i64, ptr %l28, !tbaa !24
  %t588 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t582, i32 %t583, i64 %t584)
  store i32 %t588, ptr %l257
  br label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s24
  %t589 = load ptr, ptr %l0, !tbaa !29
  store ptr %t589, ptr %l265, !tbaa !29
  %t590 = load ptr, ptr %l0, !tbaa !29
  store ptr %t590, ptr %l266, !tbaa !29
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t593 = getelementptr %"compiler/check:Checker", ptr %t591, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !29
  %t595 = load i32, ptr %l3, !tbaa !23
  %t596 = load i64, ptr %l28, !tbaa !24
  %t600 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t594, i32 %t595, i64 %t596)
  store i32 %t600, ptr %l271
  br label %bb100
bb95:
  %t601 = load ptr, ptr %l252, !tbaa !29
  %t602 = load i32, ptr %l257, !tbaa !23
  %t603 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t601, i32 %t602)
  store i32 %t603, ptr %l258
  br label %bb96
bb96:
  %t604 = load ptr, ptr %l249, !tbaa !29
  %t605 = load i32, ptr %l258, !tbaa !23
  %t606 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t604, i32 %t605)
  store { i64, ptr } %t606, ptr %l259
  br label %bb97
bb97:
  %t607 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t607, ptr %l260, !tbaa !27
  %t608 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t609 = load ptr, ptr %t608, !tbaa !27
  %t610 = getelementptr i32, ptr %t609, i64 0
  %t611 = load i32, ptr %t610, !tbaa !33
  %t612 = load ptr, ptr %l246, !tbaa !29
  %t614 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s22, ptr %t612, i32 %t611)
  store { i64, ptr } %t614, ptr %l262
  br label %bb98
bb98:
  %t615 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 1
  %t616 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 0
  %t617 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t618 = extractvalue { i64, ptr } %t617, 1
  %t619 = extractvalue { i64, ptr } %t617, 0
  %t620 = add i64 %t616, %t619
  %t621 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t620)
  call void @olang_textcopy(ptr %t621, ptr %t615, i64 %t616)
  %t622 = getelementptr i8, ptr %t621, i64 %t616
  call void @olang_textcopy(ptr %t622, ptr %t618, i64 %t619)
  %t623 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t624 = insertvalue { i64, ptr } %t623, ptr %t621, 1
  %t626 = extractvalue { i64, ptr } %t624, 0
  %t627 = extractvalue { i64, ptr } %t624, 1
  %t628 = mul i64 %t626, 1
  %t629 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t628)
  call void @llvm.memcpy.p0.p0.i64(ptr %t629, ptr %t627, i64 %t628, i1 false)
  %t630 = insertvalue { i64, ptr } undef, i64 %t626, 0
  %t631 = insertvalue { i64, ptr } %t630, ptr %t629, 1
  %t632 = load ptr, ptr %l245, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %t632, { i64, ptr } %t631)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s22)
  br label %bb116
bb100:
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t636 = getelementptr %"compiler/check:Checker", ptr %t634, i32 0, i32 1
  %t637 = load ptr, ptr %t636, !tbaa !29
  %t638 = load i32, ptr %l1, !tbaa !23
  %t641 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t637, i32 %t638)
  store ptr %t641, ptr %l275
  br label %bb101
bb101:
  %t642 = load ptr, ptr %l275, !tbaa !29
  store ptr %t642, ptr %l30, !tbaa !29
  %t643 = load ptr, ptr %l30, !tbaa !29
  %t645 = icmp eq ptr %t643, null
  br i1 %t645, label %bb102, label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_7b101762ff8ffda9_ced5d247097fb61d)
  unreachable
bb103:
  br label %bb104
bb104:
  %t647 = load ptr, ptr %l30, !tbaa !29
  %t648 = load i64, ptr %l28, !tbaa !24
  %t651 = call { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v0, ptr %t647, i64 %t648)
  store { i64, ptr } %t651, ptr %l280
  br label %bb105
bb105:
  %t652 = load ptr, ptr %l266, !tbaa !29
  %t653 = load i32, ptr %l271, !tbaa !23
  %t654 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t655 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s24, ptr %v0, ptr %t652, i32 %t653, ptr null, { i64, ptr } %t654)
  store i32 %t655, ptr %l281
  br label %bb106
bb106:
  %t656 = load ptr, ptr %l265, !tbaa !29
  %t657 = load i32, ptr %l281, !tbaa !23
  %t658 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s24, ptr %t656, i32 %t657)
  store { i64, ptr } %t658, ptr %l282
  br label %bb107
bb107:
  %t659 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t659, ptr %l31, !tbaa !27
  store ptr %l2, ptr %l283, !tbaa !29
  %t660 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t662 = call i64 @compiler_2fexplain_2efirstClose(ptr %s24, { i64, ptr } %t660)
  store i64 %t662, ptr %l285
  br label %bb108
bb108:
  %t663 = load i64, ptr %l285, !tbaa !24
  %t664 = add i64 %t663, 1
  store i64 %t664, ptr %l286, !tbaa !24
  %t665 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t665, 0
  store i64 %t666, ptr %l287, !tbaa !24
  %t667 = icmp sge i64 2, 0
  br i1 %t667, label %bb109, label %bb110
bb109:
  %t669 = load i64, ptr %l286, !tbaa !24
  %t670 = icmp sle i64 2, %t669
  br i1 %t670, label %bb111, label %bb112
bb110:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb111:
  %t672 = load i64, ptr %l286, !tbaa !24
  %t673 = load i64, ptr %l287, !tbaa !24
  %t674 = icmp sle i64 %t672, %t673
  br i1 %t674, label %bb113, label %bb114
bb112:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb113:
  %t676 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t677 = load ptr, ptr %t676, !tbaa !27
  %t678 = load i64, ptr %l286, !tbaa !24
  %t679 = getelementptr i8, ptr %t677, i64 2
  %t680 = sub i64 %t678, 2
  %t681 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t682 = insertvalue { i64, ptr } %t681, ptr %t679, 1
  %t683 = load ptr, ptr %l283, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s24, ptr %t683, { i64, ptr } %t682)
  br label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb115:
  call void @__olang_scope_close(ptr %s24)
  br label %bb116
bb116:
  br label %bb117
bb117:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s19)
  br label %bb119
bb119:
  %t686 = load i64, ptr %l27, !tbaa !24
  %t688 = add i64 %t686, 1
  store i64 %t688, ptr %l27, !tbaa !24
  br label %bb77
bb120:
  call void @__olang_scope_close(ptr %s16)
  br label %bb198
bb121:
  %t690 = load i32, ptr %l6
  %t692 = trunc i64 4 to i32
  %t693 = icmp eq i32 %t690, %t692
  br i1 %t693, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb169
bb124:
  store %olang.scope zeroinitializer, ptr %s26
  store ptr %l2, ptr %l297, !tbaa !29
  %t695 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t695, ptr %l298, !tbaa !27
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t698 = getelementptr %"compiler/check:Checker", ptr %t696, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !29
  %t700 = load i32, ptr %l3, !tbaa !23
  %t703 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t699, i32 %t700)
  store i1 %t703, ptr %l302
  br label %bb125
bb125:
  %t704 = load i1, ptr %l302, !tbaa !21
  br i1 %t704, label %bb126, label %bb127
bb126:
  store { i64, ptr } { i64 9, ptr @.d52 }, ptr %l303, !tbaa !27
  br label %bb128
bb127:
  store { i64, ptr } { i64 1, ptr @.d53 }, ptr %l303, !tbaa !27
  br label %bb128
bb128:
  %t705 = load ptr, ptr %l0, !tbaa !29
  store ptr %t705, ptr %l304, !tbaa !29
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t708 = getelementptr %"compiler/check:Checker", ptr %t706, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !29
  %t711 = getelementptr %"compiler/generic:Program", ptr %t709, i32 0, i32 2
  %t712 = load i32, ptr %l3, !tbaa !23
  %t715 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t711, i32 %t712)
  store i32 %t715, ptr %l309
  br label %bb129
bb129:
  %t716 = load ptr, ptr %l304, !tbaa !29
  %t717 = load i32, ptr %l309, !tbaa !23
  %t718 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s26, ptr %t716, i32 %t717)
  store { i64, ptr } %t718, ptr %l310
  br label %bb130
bb130:
  %t719 = extractvalue { i64, ptr } { i64 5, ptr @.d54 }, 1
  %t720 = extractvalue { i64, ptr } { i64 5, ptr @.d54 }, 0
  %t721 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t722 = extractvalue { i64, ptr } %t721, 1
  %t723 = extractvalue { i64, ptr } %t721, 0
  %t724 = add i64 %t720, %t723
  %t725 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t726 = extractvalue { i64, ptr } %t725, 1
  %t727 = extractvalue { i64, ptr } %t725, 0
  %t728 = add i64 %t724, %t727
  %t729 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t730 = extractvalue { i64, ptr } %t729, 1
  %t731 = extractvalue { i64, ptr } %t729, 0
  %t732 = add i64 %t728, %t731
  %t733 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t732)
  call void @olang_textcopy(ptr %t733, ptr %t719, i64 %t720)
  %t734 = getelementptr i8, ptr %t733, i64 %t720
  call void @olang_textcopy(ptr %t734, ptr %t722, i64 %t723)
  %t735 = getelementptr i8, ptr %t734, i64 %t723
  call void @olang_textcopy(ptr %t735, ptr %t726, i64 %t727)
  %t736 = getelementptr i8, ptr %t735, i64 %t727
  call void @olang_textcopy(ptr %t736, ptr %t730, i64 %t731)
  %t737 = insertvalue { i64, ptr } undef, i64 %t732, 0
  %t738 = insertvalue { i64, ptr } %t737, ptr %t733, 1
  %t740 = extractvalue { i64, ptr } %t738, 0
  %t741 = extractvalue { i64, ptr } %t738, 1
  %t742 = mul i64 %t740, 1
  %t743 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t742)
  call void @llvm.memcpy.p0.p0.i64(ptr %t743, ptr %t741, i64 %t742, i1 false)
  %t744 = insertvalue { i64, ptr } undef, i64 %t740, 0
  %t745 = insertvalue { i64, ptr } %t744, ptr %t743, 1
  %t746 = load ptr, ptr %l297, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s26, ptr %t746, { i64, ptr } %t745)
  br label %bb131
bb131:
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t750 = getelementptr %"compiler/check:Checker", ptr %t748, i32 0, i32 1
  %t751 = load ptr, ptr %t750, !tbaa !29
  %t752 = load i32, ptr %l1, !tbaa !23
  %t755 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t751, i32 %t752)
  store ptr %t755, ptr %l316
  br label %bb132
bb132:
  %t756 = load ptr, ptr %l316, !tbaa !29
  store ptr %t756, ptr %l32, !tbaa !29
  %t757 = load ptr, ptr %l32, !tbaa !29
  %t759 = icmp eq ptr %t757, null
  br i1 %t759, label %bb133, label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_ec478a9a38770143_a832df5ab537b567)
  unreachable
bb134:
  br label %bb135
bb135:
  %t761 = load ptr, ptr %l32, !tbaa !29
  %t764 = getelementptr %"compiler/ast:TypeDecl", ptr %t761, i32 0, i32 3
  %t765 = load ptr, ptr %t764, !tbaa !29
  store ptr %t765, ptr %l33, !tbaa !29
  %t767 = load ptr, ptr %l33, !tbaa !29
  store ptr %t767, ptr %l322, !tbaa !29
  store i1 false, ptr %l323, !tbaa !21
  %t768 = load ptr, ptr %l322, !tbaa !29
  %t769 = icmp ne ptr %t768, null
  br i1 %t769, label %bb136, label %bb137
bb136:
  %t771 = load ptr, ptr %l322, !tbaa !29
  %t772 = load i64, ptr %t771
  %t774 = icmp eq i64 %t772, 3
  store i1 %t774, ptr %l323, !tbaa !21
  br label %bb137
bb137:
  %t775 = load i1, ptr %l323, !tbaa !21
  br i1 %t775, label %bb138, label %bb139
bb138:
  %t776 = load ptr, ptr %l33, !tbaa !29
  %t778 = getelementptr { i64, [2 x i64] }, ptr %t776, i32 0, i32 1
  %t779 = getelementptr { ptr, ptr }, ptr %t778, i32 0, i32 1
  %t780 = load ptr, ptr %t779
  store ptr %t780, ptr %l34, !tbaa !29
  br label %bb140
bb139:
  br label %bb162
bb140:
  %t782 = load ptr, ptr %l34, !tbaa !29
  %t784 = icmp eq ptr %t782, null
  %t786 = xor i1 %t784, true
  br i1 %t786, label %bb141, label %bb142
bb141:
  store %olang.scope zeroinitializer, ptr %s29
  %t788 = load ptr, ptr %l0, !tbaa !29
  store ptr %t788, ptr %l331, !tbaa !29
  %t789 = load ptr, ptr %l0, !tbaa !29
  store ptr %t789, ptr %l332, !tbaa !29
  %t790 = load ptr, ptr %l0, !tbaa !29
  %t792 = getelementptr %"compiler/check:Checker", ptr %t790, i32 0, i32 1
  %t793 = load ptr, ptr %t792, !tbaa !29
  %t794 = load i32, ptr %l3, !tbaa !23
  %t797 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t793, i32 %t794)
  store i32 %t797, ptr %l336
  br label %bb143
bb142:
  br label %bb161
bb143:
  %t798 = load ptr, ptr %l34, !tbaa !29
  %t800 = getelementptr %"compiler/ast:Func", ptr %t798, i32 0, i32 3
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t803 = getelementptr %"compiler/ast:Sig", ptr %t801, i32 0, i32 0
  %t804 = load { i64, ptr }, ptr %t803, !tbaa !27
  %t805 = load ptr, ptr %l332, !tbaa !29
  %t806 = load i32, ptr %l336, !tbaa !23
  %t808 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s29, ptr %v0, ptr %t805, i32 %t806, ptr null, { i64, ptr } %t804)
  store i32 %t808, ptr %l340
  br label %bb144
bb144:
  %t809 = load ptr, ptr %l331, !tbaa !29
  %t810 = load i32, ptr %l340, !tbaa !23
  %t811 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s29, ptr %t809, i32 %t810)
  store { i64, ptr } %t811, ptr %l341
  br label %bb145
bb145:
  %t812 = load { i64, ptr }, ptr %l341, !tbaa !27
  store { i64, ptr } %t812, ptr %l35, !tbaa !27
  %t813 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t815 = call i64 @compiler_2fexplain_2efirstClose(ptr %s29, { i64, ptr } %t813)
  store i64 %t815, ptr %l343
  br label %bb146
bb146:
  %t816 = load i64, ptr %l343, !tbaa !24
  store i64 %t816, ptr %l36, !tbaa !24
  store ptr %l2, ptr %l344, !tbaa !29
  %t817 = load i64, ptr %l36, !tbaa !24
  %t819 = add i64 %t817, 1
  store i64 %t819, ptr %l346, !tbaa !24
  %t820 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t821 = extractvalue { i64, ptr } %t820, 0
  store i64 %t821, ptr %l347, !tbaa !24
  %t822 = icmp sge i64 2, 0
  br i1 %t822, label %bb147, label %bb148
bb147:
  %t824 = load i64, ptr %l346, !tbaa !24
  %t825 = icmp sle i64 2, %t824
  br i1 %t825, label %bb149, label %bb150
bb148:
  call void @__olang_check_failed(ptr @olang_loc_9c563feafedd44ce_b85d3928399923da)
  unreachable
bb149:
  %t827 = load i64, ptr %l346, !tbaa !24
  %t828 = load i64, ptr %l347, !tbaa !24
  %t829 = icmp sle i64 %t827, %t828
  br i1 %t829, label %bb151, label %bb152
bb150:
  call void @__olang_check_failed(ptr @olang_loc_9c563feafedd44ce_b85d3928399923da)
  unreachable
bb151:
  %t831 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t832 = load ptr, ptr %t831, !tbaa !27
  %t833 = load i64, ptr %l346, !tbaa !24
  %t834 = getelementptr i8, ptr %t832, i64 2
  %t835 = sub i64 %t833, 2
  %t836 = insertvalue { i64, ptr } undef, i64 %t835, 0
  %t837 = insertvalue { i64, ptr } %t836, ptr %t834, 1
  store { i64, ptr } %t837, ptr %l351, !tbaa !27
  %t838 = load i64, ptr %l36, !tbaa !24
  %t840 = add i64 %t838, 1
  store i64 %t840, ptr %l353, !tbaa !24
  %t841 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t843 = extractvalue { i64, ptr } %t841, 0
  store i64 %t843, ptr %l355, !tbaa !24
  %t844 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t845 = extractvalue { i64, ptr } %t844, 0
  store i64 %t845, ptr %l356, !tbaa !24
  %t846 = load i64, ptr %l353, !tbaa !24
  %t847 = icmp sge i64 %t846, 0
  br i1 %t847, label %bb153, label %bb154
bb152:
  call void @__olang_check_failed(ptr @olang_loc_9c563feafedd44ce_b85d3928399923da)
  unreachable
bb153:
  %t849 = load i64, ptr %l353, !tbaa !24
  %t850 = load i64, ptr %l355, !tbaa !24
  %t851 = icmp sle i64 %t849, %t850
  br i1 %t851, label %bb155, label %bb156
bb154:
  call void @__olang_check_failed(ptr @olang_loc_9c563feafedd44ce_b85d3928399923da)
  unreachable
bb155:
  %t853 = load i64, ptr %l355, !tbaa !24
  %t854 = load i64, ptr %l356, !tbaa !24
  %t855 = icmp sle i64 %t853, %t854
  br i1 %t855, label %bb157, label %bb158
bb156:
  call void @__olang_check_failed(ptr @olang_loc_9c563feafedd44ce_b85d3928399923da)
  unreachable
bb157:
  %t857 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t858 = load ptr, ptr %t857, !tbaa !27
  %t859 = load i64, ptr %l353, !tbaa !24
  %t860 = load i64, ptr %l355, !tbaa !24
  %t861 = getelementptr i8, ptr %t858, i64 %t859
  %t862 = sub i64 %t860, %t859
  %t863 = insertvalue { i64, ptr } undef, i64 %t862, 0
  %t864 = insertvalue { i64, ptr } %t863, ptr %t861, 1
  %t866 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s29, ptr %s29, { i64, ptr } %t864)
  store { i64, ptr } %t866, ptr %l361
  br label %bb159
bb158:
  call void @__olang_check_failed(ptr @olang_loc_9c563feafedd44ce_b85d3928399923da)
  unreachable
bb159:
  %t867 = load { i64, ptr }, ptr %l351, !tbaa !27
  %t868 = extractvalue { i64, ptr } %t867, 1
  %t869 = extractvalue { i64, ptr } %t867, 0
  %t870 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t871 = extractvalue { i64, ptr } %t870, 1
  %t872 = extractvalue { i64, ptr } %t870, 0
  %t873 = add i64 %t869, %t872
  %t874 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t873)
  call void @olang_textcopy(ptr %t874, ptr %t868, i64 %t869)
  %t875 = getelementptr i8, ptr %t874, i64 %t869
  call void @olang_textcopy(ptr %t875, ptr %t871, i64 %t872)
  %t876 = insertvalue { i64, ptr } undef, i64 %t873, 0
  %t877 = insertvalue { i64, ptr } %t876, ptr %t874, 1
  %t879 = extractvalue { i64, ptr } %t877, 0
  %t880 = extractvalue { i64, ptr } %t877, 1
  %t881 = mul i64 %t879, 1
  %t882 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t881)
  call void @llvm.memcpy.p0.p0.i64(ptr %t882, ptr %t880, i64 %t881, i1 false)
  %t883 = insertvalue { i64, ptr } undef, i64 %t879, 0
  %t884 = insertvalue { i64, ptr } %t883, ptr %t882, 1
  %t885 = load ptr, ptr %l344, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s29, ptr %t885, { i64, ptr } %t884)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s29)
  br label %bb161
bb161:
  br label %bb167
bb162:
  br i1 true, label %bb163, label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb166
bb165:
  br label %bb167
bb166:
  call void @__olang_check_failed(ptr @olang_loc_59444906d9a5f4e4_cce5daf1bd4cf840)
  unreachable
bb167:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb168
bb168:
  call void @__olang_scope_close(ptr %s26)
  br label %bb198
bb169:
  %t888 = load i32, ptr %l6
  %t890 = trunc i64 0 to i32
  %t891 = icmp eq i32 %t888, %t890
  br i1 %t891, label %bb170, label %bb171
bb170:
  br label %bb172
bb171:
  br label %bb197
bb172:
  store %olang.scope zeroinitializer, ptr %s32
  %t893 = load ptr, ptr %l0, !tbaa !29
  store ptr %t893, ptr %l367, !tbaa !29
  %t894 = load ptr, ptr %l0, !tbaa !29
  store ptr %t894, ptr %l368, !tbaa !29
  %t895 = load ptr, ptr %l0, !tbaa !29
  %t897 = getelementptr %"compiler/check:Checker", ptr %t895, i32 0, i32 1
  %t898 = load ptr, ptr %t897, !tbaa !29
  %t899 = load i32, ptr %l3, !tbaa !23
  %t902 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t898, i32 %t899)
  store i32 %t902, ptr %l372
  br label %bb173
bb173:
  %t903 = load ptr, ptr %l0, !tbaa !29
  %t905 = getelementptr %"compiler/check:Checker", ptr %t903, i32 0, i32 1
  %t906 = load ptr, ptr %t905, !tbaa !29
  %t907 = load i32, ptr %l1, !tbaa !23
  %t910 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t906, i32 %t907)
  store ptr %t910, ptr %l376
  br label %bb174
bb174:
  %t911 = load ptr, ptr %l376, !tbaa !29
  store ptr %t911, ptr %l37, !tbaa !29
  %t912 = load ptr, ptr %l37, !tbaa !29
  %t914 = icmp eq ptr %t912, null
  br i1 %t914, label %bb175, label %bb176
bb175:
  call void @__olang_check_failed(ptr @olang_loc_ffe4b19b507d3ced_b2545c707833b851)
  unreachable
bb176:
  br label %bb177
bb177:
  %t916 = load ptr, ptr %l37, !tbaa !29
  %t918 = call { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %t916)
  store { i64, ptr } %t918, ptr %l380
  br label %bb178
bb178:
  %t919 = load ptr, ptr %l368, !tbaa !29
  %t920 = load i32, ptr %l372, !tbaa !23
  %t921 = load { i64, ptr }, ptr %l380, !tbaa !27
  %t922 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s32, ptr %v0, ptr %t919, i32 %t920, ptr null, { i64, ptr } %t921)
  store i32 %t922, ptr %l381
  br label %bb179
bb179:
  %t923 = load ptr, ptr %l367, !tbaa !29
  %t924 = load i32, ptr %l381, !tbaa !23
  %t925 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s32, ptr %t923, i32 %t924)
  store { i64, ptr } %t925, ptr %l382
  br label %bb180
bb180:
  %t926 = load { i64, ptr }, ptr %l382, !tbaa !27
  store { i64, ptr } %t926, ptr %l38, !tbaa !27
  %t927 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t929 = call i64 @compiler_2fexplain_2efirstClose(ptr %s32, { i64, ptr } %t927)
  store i64 %t929, ptr %l384
  br label %bb181
bb181:
  %t930 = load i64, ptr %l384, !tbaa !24
  store i64 %t930, ptr %l39, !tbaa !24
  store ptr %l2, ptr %l385, !tbaa !29
  %t931 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t931, ptr %l386, !tbaa !27
  %t932 = load i64, ptr %l39, !tbaa !24
  %t934 = add i64 %t932, 1
  store i64 %t934, ptr %l388, !tbaa !24
  %t935 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t936 = extractvalue { i64, ptr } %t935, 0
  store i64 %t936, ptr %l389, !tbaa !24
  %t937 = icmp sge i64 2, 0
  br i1 %t937, label %bb182, label %bb183
bb182:
  %t939 = load i64, ptr %l388, !tbaa !24
  %t940 = icmp sle i64 2, %t939
  br i1 %t940, label %bb184, label %bb185
bb183:
  call void @__olang_check_failed(ptr @olang_loc_ce9c7831b1423e9e_3f49d747eab61c42)
  unreachable
bb184:
  %t942 = load i64, ptr %l388, !tbaa !24
  %t943 = load i64, ptr %l389, !tbaa !24
  %t944 = icmp sle i64 %t942, %t943
  br i1 %t944, label %bb186, label %bb187
bb185:
  call void @__olang_check_failed(ptr @olang_loc_ce9c7831b1423e9e_3f49d747eab61c42)
  unreachable
bb186:
  %t946 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t947 = load ptr, ptr %t946, !tbaa !27
  %t948 = load i64, ptr %l388, !tbaa !24
  %t949 = getelementptr i8, ptr %t947, i64 2
  %t950 = sub i64 %t948, 2
  %t951 = insertvalue { i64, ptr } undef, i64 %t950, 0
  %t952 = insertvalue { i64, ptr } %t951, ptr %t949, 1
  store { i64, ptr } %t952, ptr %l393, !tbaa !27
  %t953 = load i64, ptr %l39, !tbaa !24
  %t955 = add i64 %t953, 1
  store i64 %t955, ptr %l395, !tbaa !24
  %t956 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t958 = extractvalue { i64, ptr } %t956, 0
  store i64 %t958, ptr %l397, !tbaa !24
  %t959 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t960 = extractvalue { i64, ptr } %t959, 0
  store i64 %t960, ptr %l398, !tbaa !24
  %t961 = load i64, ptr %l395, !tbaa !24
  %t962 = icmp sge i64 %t961, 0
  br i1 %t962, label %bb188, label %bb189
bb187:
  call void @__olang_check_failed(ptr @olang_loc_ce9c7831b1423e9e_3f49d747eab61c42)
  unreachable
bb188:
  %t964 = load i64, ptr %l395, !tbaa !24
  %t965 = load i64, ptr %l397, !tbaa !24
  %t966 = icmp sle i64 %t964, %t965
  br i1 %t966, label %bb190, label %bb191
bb189:
  call void @__olang_check_failed(ptr @olang_loc_ce9c7831b1423e9e_3f49d747eab61c42)
  unreachable
bb190:
  %t968 = load i64, ptr %l397, !tbaa !24
  %t969 = load i64, ptr %l398, !tbaa !24
  %t970 = icmp sle i64 %t968, %t969
  br i1 %t970, label %bb192, label %bb193
bb191:
  call void @__olang_check_failed(ptr @olang_loc_ce9c7831b1423e9e_3f49d747eab61c42)
  unreachable
bb192:
  %t972 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t973 = load ptr, ptr %t972, !tbaa !27
  %t974 = load i64, ptr %l395, !tbaa !24
  %t975 = load i64, ptr %l397, !tbaa !24
  %t976 = getelementptr i8, ptr %t973, i64 %t974
  %t977 = sub i64 %t975, %t974
  %t978 = insertvalue { i64, ptr } undef, i64 %t977, 0
  %t979 = insertvalue { i64, ptr } %t978, ptr %t976, 1
  %t981 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s32, ptr %s32, { i64, ptr } %t979)
  store { i64, ptr } %t981, ptr %l403
  br label %bb194
bb193:
  call void @__olang_check_failed(ptr @olang_loc_ce9c7831b1423e9e_3f49d747eab61c42)
  unreachable
bb194:
  %t982 = extractvalue { i64, ptr } { i64 5, ptr @.d55 }, 1
  %t983 = extractvalue { i64, ptr } { i64 5, ptr @.d55 }, 0
  %t984 = load { i64, ptr }, ptr %l386, !tbaa !27
  %t985 = extractvalue { i64, ptr } %t984, 1
  %t986 = extractvalue { i64, ptr } %t984, 0
  %t987 = add i64 %t983, %t986
  %t988 = extractvalue { i64, ptr } { i64 7, ptr @.d56 }, 1
  %t989 = extractvalue { i64, ptr } { i64 7, ptr @.d56 }, 0
  %t990 = add i64 %t987, %t989
  %t991 = load { i64, ptr }, ptr %l393, !tbaa !27
  %t992 = extractvalue { i64, ptr } %t991, 1
  %t993 = extractvalue { i64, ptr } %t991, 0
  %t994 = add i64 %t990, %t993
  %t995 = load { i64, ptr }, ptr %l403, !tbaa !27
  %t996 = extractvalue { i64, ptr } %t995, 1
  %t997 = extractvalue { i64, ptr } %t995, 0
  %t998 = add i64 %t994, %t997
  %t999 = extractvalue { i64, ptr } { i64 1, ptr @.d57 }, 1
  %t1000 = extractvalue { i64, ptr } { i64 1, ptr @.d57 }, 0
  %t1001 = add i64 %t998, %t1000
  %t1002 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t1001)
  call void @olang_textcopy(ptr %t1002, ptr %t982, i64 %t983)
  %t1003 = getelementptr i8, ptr %t1002, i64 %t983
  call void @olang_textcopy(ptr %t1003, ptr %t985, i64 %t986)
  %t1004 = getelementptr i8, ptr %t1003, i64 %t986
  call void @olang_textcopy(ptr %t1004, ptr %t988, i64 %t989)
  %t1005 = getelementptr i8, ptr %t1004, i64 %t989
  call void @olang_textcopy(ptr %t1005, ptr %t992, i64 %t993)
  %t1006 = getelementptr i8, ptr %t1005, i64 %t993
  call void @olang_textcopy(ptr %t1006, ptr %t996, i64 %t997)
  %t1007 = getelementptr i8, ptr %t1006, i64 %t997
  call void @olang_textcopy(ptr %t1007, ptr %t999, i64 %t1000)
  %t1008 = insertvalue { i64, ptr } undef, i64 %t1001, 0
  %t1009 = insertvalue { i64, ptr } %t1008, ptr %t1002, 1
  %t1011 = extractvalue { i64, ptr } %t1009, 0
  %t1012 = extractvalue { i64, ptr } %t1009, 1
  %t1013 = mul i64 %t1011, 1
  %t1014 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t1013)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1014, ptr %t1012, i64 %t1013, i1 false)
  %t1015 = insertvalue { i64, ptr } undef, i64 %t1011, 0
  %t1016 = insertvalue { i64, ptr } %t1015, ptr %t1014, 1
  %t1017 = load ptr, ptr %l385, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s32, ptr %t1017, { i64, ptr } %t1016)
  br label %bb195
bb195:
  %t1019 = load ptr, ptr %l0, !tbaa !29
  %t1020 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2efields(ptr %s0, ptr %v0, ptr %l2, ptr %t1019, i32 %t1020)
  br label %bb196
bb196:
  call void @__olang_scope_close(ptr %s32)
  br label %bb198
bb197:
  call void @__olang_check_failed(ptr @olang_loc_328924b9ee62318e_d428045f5155d072)
  unreachable
bb198:
  %t1024 = load ptr, ptr %l0, !tbaa !29
  %t1025 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2emethods(ptr %s0, ptr %v0, ptr %l2, ptr %t1024, i32 %t1025)
  br label %bb199
bb199:
  %t1029 = load ptr, ptr %l0, !tbaa !29
  %t1030 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2etraitsMet(ptr %s0, ptr %v0, ptr %l2, ptr %t1029, i32 %t1030)
  br label %bb200
bb200:
  %t1035 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t1035, ptr %l416
  br label %bb201
bb201:
  %t1036 = load { i64, ptr }, ptr %l416, !tbaa !27
  store { i64, ptr } %t1036, ptr %l417, !tbaa !27
  %t1037 = load { i64, ptr }, ptr %l417, !tbaa !27
  %t1038 = extractvalue { i64, ptr } %t1037, 0
  store i64 %t1038, ptr %l418, !tbaa !24
  %t1039 = load i64, ptr %l418, !tbaa !24
  %t1040 = mul i64 %t1039, 1
  %t1041 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t1040)
  %t1042 = insertvalue { i64, ptr } undef, i64 %t1039, 0
  %t1043 = insertvalue { i64, ptr } %t1042, ptr %t1041, 1
  store { i64, ptr } %t1043, ptr %l419, !tbaa !27
  %t1044 = getelementptr { i64, ptr }, ptr %l419, i32 0, i32 1
  %t1045 = load ptr, ptr %t1044, !tbaa !27
  %t1046 = getelementptr { i64, ptr }, ptr %l417, i32 0, i32 1
  %t1047 = load ptr, ptr %t1046, !tbaa !27
  %t1048 = load i64, ptr %l418, !tbaa !24
  %t1049 = mul i64 %t1048, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1045, ptr %t1047, i64 %t1049, i1 false)
  %t1050 = load { i64, ptr }, ptr %l419, !tbaa !27
  store { i64, ptr } %t1050, ptr %l417, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t1051 = load { i64, ptr }, ptr %l417, !tbaa !27
  store { i64, ptr } %t1051, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %a2)
  store i32 %t19, ptr %l12
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l5, !tbaa !29
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t20, i64 %t21, i32 %t22)
  store i64 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load i64, ptr %l13, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i32 -1, ptr %l16, !tbaa !23
  br label %bb6
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t38 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t32, i64 %t33, i64 %t34)
  store i32 %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = load i32, ptr %l21, !tbaa !23
  store i32 %t39, ptr %l16, !tbaa !23
  br label %bb6
bb6:
  %t40 = load i32, ptr %l16, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:varRow"
  %l15 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l30 = alloca i64
  %l33 = alloca i64
  %l55 = alloca %"compiler/generic:varRow"
  %l60 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i64, ptr %l15, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sle i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr @.d58 }, ptr %l19, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t16, ptr %l20, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l21, !tbaa !24
  %t19 = load i64, ptr %l21, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l21, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t30, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t32 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t32, ptr %l23
  br label %bb5
bb5:
  %t33 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t33, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 60)
  br label %bb6
bb6:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb12
bb9:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l33, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l33, !tbaa !24
  store i64 %t65, ptr %l30, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l30, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t94 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t88, i64 %t89, i64 %t90)
  store %"compiler/generic:varRow" %t94, ptr %l55
  br label %bb17
bb17:
  %t95 = load %"compiler/generic:varRow", ptr %l55
  store %"compiler/generic:varRow" %t95, ptr %l11
  %t96 = load i64, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l2, !tbaa !24
  %t100 = icmp sgt i64 %t96, %t97
  br i1 %t100, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l4, { i64, ptr } { i64 2, ptr @.d59 })
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  store ptr %l4, ptr %l60, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 3
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 1
  %t114 = load i32, ptr %t113, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t112, i32 %t114)
  store { i64, ptr } %t117, ptr %l66
  br label %bb22
bb22:
  %t118 = load ptr, ptr %l60, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l66, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t118, { i64, ptr } %t119)
  br label %bb23
bb23:
  %t120 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t125 = icmp ne i32 %t121, %t122
  br i1 %t125, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l4, ptr %l70, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t129 = load i32, ptr %t128, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s5, ptr %t127, i32 %t129)
  store { i64, ptr } %t132, ptr %l73
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t133 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 0
  %t135 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = add i64 %t134, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t133, i64 %t134)
  %t140 = getelementptr i8, ptr %t139, i64 %t134
  call void @olang_textcopy(ptr %t140, ptr %t136, i64 %t137)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  %t150 = load ptr, ptr %l70, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t150, { i64, ptr } %t149)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t152 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t153 = load i32, ptr %t152, !tbaa !23
  %t154 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t157 = icmp ne i32 %t153, %t154
  br i1 %t157, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l4, ptr %l79, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t161 = load i32, ptr %t160, !tbaa !23
  %t164 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s7, ptr %t159, i32 %t161)
  store { i64, ptr } %t164, ptr %l82
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t165 = extractvalue { i64, ptr } { i64 1, ptr @.d61 }, 1
  %t166 = extractvalue { i64, ptr } { i64 1, ptr @.d61 }, 0
  %t167 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = add i64 %t166, %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t165, i64 %t166)
  %t172 = getelementptr i8, ptr %t171, i64 %t166
  call void @olang_textcopy(ptr %t172, ptr %t168, i64 %t169)
  %t173 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t171, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = extractvalue { i64, ptr } %t174, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  %t182 = load ptr, ptr %l79, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t182, { i64, ptr } %t181)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  %t184 = load i64, ptr %l9, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l9, !tbaa !24
  br label %bb13
bb35:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 62)
  br label %bb36
bb36:
  %t190 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l4)
  store { i64, ptr } %t190, ptr %l89
  br label %bb37
bb37:
  %t191 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t191, ptr %l90, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l91, !tbaa !24
  %t194 = load i64, ptr %l91, !tbaa !24
  %t195 = mul i64 %t194, 1
  %t196 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t195)
  %t197 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  store { i64, ptr } %t198, ptr %l92, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = load i64, ptr %l91, !tbaa !24
  %t204 = mul i64 %t203, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t200, ptr %t202, i64 %t204, i1 false)
  %t205 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t205, ptr %l90, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t206 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t206, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d0 = private constant [1 x i8] c"."
declare void @__olang_check_failed(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d1 = private constant [2 x i8] c" ?"
@.d2 = private constant [0 x i8] c""
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d3 = private constant [4 x i8] c"    "
@.d4 = private constant [1 x i8] c" "
@.d5 = private constant [1 x i8] c"\0A"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant [1 x i8] c"\0A"
@.d7 = private constant [4 x i8] c"    "
@.d8 = private constant [1 x i8] c"\0A"
@.d9 = private constant [13 x i8] c"    instance "
@.d10 = private constant [2 x i8] c": "
@.d11 = private constant [1 x i8] c"\0A"
@.d12 = private constant [8 x i8] c"        "
@.d13 = private constant [10 x i8] c"extern fn "
@.d14 = private constant [3 x i8] c"fn "
@.d15 = private constant [1 x i8] c"("
@.d16 = private constant [1 x i8] c"("
@.d17 = private constant [2 x i8] c") "
@.d18 = private constant [1 x i8] c"("
@.d19 = private constant [5 x i8] c" mut "
@.d20 = private constant [1 x i8] c" "
@.d21 = private constant [20 x i8] c"   # set at startup\0A"
@.d22 = private constant [20 x i8] c"   # set at startup\0A"
@.d23 = private constant [3 x i8] c" = "
@.d24 = private constant [1 x i8] c"\0A"
@.d25 = private constant [3 x i8] c" = "
@.d26 = private constant [1 x i8] c"\0A"
@.d27 = private constant [4 x i8] c"    "
@.d28 = private constant [1 x i8] c"\0A"
@.d29 = private constant [4 x i8] c"    "
@.d30 = private constant [1 x i8] c"\0A"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d31 = private constant [1 x i8] c"["
@.d32 = private constant [2 x i8] c"]\0A"
@.d33 = private constant [2 x i8] c"\5Cn"
@.d34 = private constant [2 x i8] c"\5Ct"
@.d35 = private constant [27 x i8] c"   # its error set inferred"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d36 = private constant [2 x i8] c", "
@.d37 = private constant [10 x i8] c"    meets "
@.d38 = private constant [1 x i8] c"\0A"
@.d39 = private constant [2 x i8] c", "
@.d40 = private constant [6 x i8] c"error "
@.d41 = private constant [1 x i8] c"\0A"
@.d42 = private constant [4 x i8] c"    "
@.d43 = private constant [1 x i8] c"\0A"
@.d44 = private constant [5 x i8] c"type "
@.d45 = private constant [7 x i8] c" trait\0A"
@.d46 = private constant [4 x i8] c"    "
@.d47 = private constant [1 x i8] c"\0A"
@.d48 = private constant [5 x i8] c"type "
@.d49 = private constant [6 x i8] c" enum\0A"
@.d50 = private constant [4 x i8] c"    "
@.d51 = private constant [1 x i8] c" "
@.d52 = private constant [9 x i8] c" extends "
@.d53 = private constant [1 x i8] c" "
@.d54 = private constant [5 x i8] c"type "
@.d55 = private constant [5 x i8] c"type "
@.d56 = private constant [7 x i8] c" struct"
@.d57 = private constant [1 x i8] c"\0A"
@.d58 = private constant [0 x i8] c""
@.d59 = private constant [2 x i8] c", "
@.d60 = private constant [1 x i8] c" "
@.d61 = private constant [1 x i8] c" "
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_35c12625cc2f75ee_5b08f4318e637d4a = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_430839a36fc86f5_d60a2ea9e5c9a99 = external constant [0 x i8]
@olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3 = external constant [0 x i8]
@olang_loc_5177bd7d484351dd_5d0dbb04dc509331 = external constant [0 x i8]
@olang_loc_6448edf003c535f3_ebaded49d6e07c97 = external constant [0 x i8]
@olang_loc_979fe2e14fb6de05_5947910940c194f1 = external constant [0 x i8]
@olang_loc_8f9ce818ff296c0e_932c83e6c6076d82 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d16c6b36ae6c900f_110b33433d32ce53 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_35ffc19e50bbc737_e52638f1e81552b = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_36a09f0a29856ad4_1f4c57e6e1803c38 = external constant [0 x i8]
@olang_loc_6896438a508f3415_b4ea8b5a918f5051 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2d047dc2e8ba79e9_b3960442abafce65 = external constant [0 x i8]
@olang_loc_62f5937584004bfc_64dbf784650d4808 = external constant [0 x i8]
@olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_Hb234e65a2b42ee429ada36859295662b(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a = external constant [0 x i8]
@olang_loc_9d3c9a5d5d1efd85_5425f31610037701 = external constant [0 x i8]
@olang_loc_5a53f5e20717fed8_f65869ca84068ea4 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
@olang_loc_9dc6315c1529a356_ea501a6f2f322362 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4d095160ba2e11c2_99802ec0c9206b6 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_7b101762ff8ffda9_ced5d247097fb61d = external constant [0 x i8]
@olang_loc_e7cf316846733e6c_5d444c1e6a143730 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ec478a9a38770143_a832df5ab537b567 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9c563feafedd44ce_b85d3928399923da = external constant [0 x i8]
@olang_loc_59444906d9a5f4e4_cce5daf1bd4cf840 = external constant [0 x i8]
@olang_loc_ffe4b19b507d3ced_b2545c707833b851 = external constant [0 x i8]
@olang_loc_ce9c7831b1423e9e_3f49d747eab61c42 = external constant [0 x i8]
@olang_loc_328924b9ee62318e_d428045f5155d072 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
