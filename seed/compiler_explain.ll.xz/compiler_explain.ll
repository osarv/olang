; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Attr" = type { %"compiler/source:Span", ptr, i32 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
@G_2ecompiler_2fexplain_2eLongValue = constant <{ [8 x i8] }> <{ [8 x i8] c"\90\01\00\00\00\00\00\00" }>, align 8
define dso_local i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l24 = alloca i32
  %l31 = alloca i32
  %l36 = alloca i32
  %l45 = alloca i32
  %l50 = alloca i32
  %l54 = alloca i1
  %l58 = alloca i1
  %l66 = alloca i64
  %l70 = alloca i64
  %l72 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 -1, ptr %l2, !tbaa !23
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t10, i64 %t11)
  store i32 %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t15, i32 %t16)
  store { i64, ptr } %t17, ptr %l14
  br label %bb2
bb2:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp ne i64 %t21, 1
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t25, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t27 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 0
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l4, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l4, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb6
bb6:
  %t42 = load i32, ptr %l24, !range !{i32 0, i32 33}
  %t44 = trunc i64 20 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l4, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l31
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t57 = load i32, ptr %l31, !tbaa !23
  store i32 %t57, ptr %l4, !tbaa !23
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l36
  br label %bb11
bb11:
  %t68 = load i32, ptr %l36, !range !{i32 0, i32 33}
  %t70 = trunc i64 18 to i32
  %t71 = icmp eq i32 %t68, %t70
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb12, label %bb13
bb12:
  %t75 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t75, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l45
  br label %bb15
bb15:
  %t87 = load i32, ptr %l45, !tbaa !23
  store i32 %t87, ptr %l5, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l5, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l50
  br label %bb16
bb16:
  %t98 = load i32, ptr %l50, !range !{i32 0, i32 6}
  store i32 %t98, ptr %l6
  %t99 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t101 = trunc i64 0 to i32
  %t102 = icmp eq i32 %t99, %t101
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb17, label %bb18
bb17:
  %t106 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t108 = trunc i64 1 to i32
  %t109 = icmp eq i32 %t106, %t108
  %t111 = xor i1 %t109, true
  store i1 %t111, ptr %l54, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb19
bb19:
  %t113 = load i1, ptr %l54, !tbaa !21
  br i1 %t113, label %bb20, label %bb21
bb20:
  %t114 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t116 = trunc i64 4 to i32
  %t117 = icmp eq i32 %t114, %t116
  %t119 = xor i1 %t117, true
  store i1 %t119, ptr %l58, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t121 = load i1, ptr %l58, !tbaa !21
  br i1 %t121, label %bb23, label %bb24
bb23:
  %t122 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t122, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t128 = load i32, ptr %l5, !tbaa !23
  %t131 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t127, i32 %t128)
  store i64 %t131, ptr %l66
  br label %bb26
bb26:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t136 = load i64, ptr %l1, !tbaa !24
  %t139 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t135, i64 %t136)
  store i64 %t139, ptr %l70
  br label %bb27
bb27:
  %t140 = load i64, ptr %l66, !tbaa !24
  %t141 = load i64, ptr %l70, !tbaa !24
  %t142 = icmp eq i64 %t140, %t141
  br i1 %t142, label %bb28, label %bb29
bb28:
  %t144 = load i32, ptr %l5, !tbaa !23
  store i32 %t144, ptr %l72, !tbaa !23
  br label %bb30
bb29:
  %t146 = load i32, ptr %l2, !tbaa !23
  store i32 %t146, ptr %l72, !tbaa !23
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t148 = load i32, ptr %l72, !tbaa !23
  store i32 %t148, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l61 = alloca %"compiler/names:Entry"
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca i64
  %l83 = alloca %"compiler/names:Entry"
  %l89 = alloca i64
  %l92 = alloca i1
  %l96 = alloca ptr
  %l101 = alloca i1
  %l105 = alloca i1
  %l111 = alloca { i64, ptr }
  %l115 = alloca i1
  %l119 = alloca i1
  %l121 = alloca i1
  %l125 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t105 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t8, i32 %t9)
  store i64 %t12, ptr %l23
  br label %bb2
bb2:
  %t13 = load i64, ptr %l23, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/names:Resolver", ptr %t20, i32 0, i32 1
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t22, i64 %t23)
  store ptr %t26, ptr %l29
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l29, !tbaa !29
  store ptr %t27, ptr %l5, !tbaa !29
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l30
  br label %bb4
bb4:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/names:Table", ptr %t30, i32 0, i32 0
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l33
  br label %bb5
bb5:
  %t35 = load i64, ptr %l33, !tbaa !24
  store i64 %t35, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load i64, ptr %l9, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb8:
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l9, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l40, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb10
bb10:
  %t62 = load i64, ptr %l40, !tbaa !24
  store i64 %t62, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l37, !tbaa !24
  store i64 %t63, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t64 = load i64, ptr %l11, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb14:
  br label %bb15
bb15:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l12, !tbaa !24
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/names:Table", ptr %t82, i32 0, i32 0
  %t85 = load i64, ptr %l12, !tbaa !24
  %t88 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s2, ptr %t84, i64 %t85)
  store %"compiler/names:Entry" %t88, ptr %l61
  br label %bb16
bb16:
  %t89 = getelementptr %"compiler/names:Entry", ptr %l61, i32 0, i32 2
  %t90 = load i32, ptr %t89, !range !{i32 0, i32 9}
  %t92 = trunc i64 3 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb17, label %bb18
bb17:
  %t95 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t95)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t98 = load i64, ptr %l11, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l11, !tbaa !24
  br label %bb12
bb22:
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t103 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t104 = ptrtoint ptr %t103 to i64
  %t106 = getelementptr { ptr, ptr }, ptr %t105, i32 0, i32 0
  store ptr %t102, ptr %t106, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t108 = getelementptr { ptr, ptr }, ptr %t105, i32 0, i32 1
  store ptr %v0, ptr %t108, !tbaa !28
  %t109 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t110 = insertvalue { ptr, ptr } %t109, ptr %t105, 1
  %t113 = extractvalue { ptr, ptr } %t110, 0
  %t114 = extractvalue { ptr, ptr } %t110, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l6, ptr %t113, ptr %t114)
  br label %bb23
bb23:
  store ptr %l6, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = load i64, ptr %l14, !tbaa !24
  store i64 %t116, ptr %l72, !tbaa !24
  %t117 = load ptr, ptr %l13, !tbaa !29
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t117)
  store i64 %t119, ptr %l74
  br label %bb25
bb25:
  %t120 = load i64, ptr %l72, !tbaa !24
  %t121 = load i64, ptr %l74, !tbaa !24
  %t122 = icmp slt i64 %t120, %t121
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb27:
  br label %bb28
bb28:
  %t126 = load ptr, ptr %l13, !tbaa !29
  %t127 = load i64, ptr %l14, !tbaa !24
  %t130 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t126, i64 %t127)
  store i64 %t130, ptr %l79
  br label %bb29
bb29:
  %t131 = load i64, ptr %l79, !tbaa !24
  %t132 = load ptr, ptr %l5, !tbaa !29
  %t134 = getelementptr %"compiler/names:Table", ptr %t132, i32 0, i32 0
  %t138 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s6, ptr %t134, i64 %t131)
  store %"compiler/names:Entry" %t138, ptr %l83
  br label %bb30
bb30:
  %t139 = getelementptr %"compiler/names:Entry", ptr %l83, i32 0, i32 0
  %t140 = load i32, ptr %t139, !tbaa !23
  store i32 %t140, ptr %l16, !tbaa !23
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t146 = load i64, ptr %l4, !tbaa !24
  %t147 = load i32, ptr %l16, !tbaa !23
  %t151 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t145, i64 %t146, i32 %t147)
  store i64 %t151, ptr %l89
  br label %bb31
bb31:
  %t152 = load i64, ptr %l89, !tbaa !24
  store i64 %t152, ptr %l17, !tbaa !24
  %t153 = load i64, ptr %l17, !tbaa !24
  %t155 = icmp slt i64 %t153, 0
  br i1 %t155, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb35
bb33:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t161 = load i64, ptr %l17, !tbaa !24
  %t164 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t160, i64 %t161)
  store ptr %t164, ptr %l96
  br label %bb34
bb34:
  %t165 = load ptr, ptr %l96, !tbaa !29
  %t167 = getelementptr %"compiler/ast:Func", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = icmp eq ptr %t168, null
  %t172 = xor i1 %t170, true
  store i1 %t172, ptr %l92, !tbaa !21
  br label %bb35
bb35:
  %t174 = load i1, ptr %l92, !tbaa !21
  br i1 %t174, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb39
bb37:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t179 = load i64, ptr %l17, !tbaa !24
  %t182 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t178, i64 %t179)
  store i1 %t182, ptr %l105
  br label %bb38
bb38:
  %t183 = load i1, ptr %l105, !tbaa !21
  store i1 %t183, ptr %l101, !tbaa !21
  br label %bb39
bb39:
  %t184 = load i1, ptr %l101, !tbaa !21
  br i1 %t184, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb41:
  br label %bb42
bb42:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/load:Loader", ptr %t191, i32 0, i32 3
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t195 = load i32, ptr %l16, !tbaa !23
  %t198 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s6, ptr %t194, i32 %t195)
  store { i64, ptr } %t198, ptr %l111
  br label %bb43
bb43:
  %t199 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 1
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t202 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t201)
  call void @olang_textcopy(ptr %t202, ptr %t200, i64 %t201)
  %t203 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  store { i64, ptr } %t204, ptr %l18, !tbaa !27
  %t208 = xor i1 %a2, true
  br i1 %t208, label %bb44, label %bb45
bb44:
  %t210 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t214 = icmp sgt i64 %t212, 0
  br i1 %t214, label %bb46, label %bb47
bb45:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb50
bb46:
  %t216 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr i8, ptr %t217, i64 0
  %t219 = load i8, ptr %t218, !tbaa !32
  %t221 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t219)
  store i1 %t221, ptr %l121
  br label %bb48
bb47:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb49
bb48:
  %t222 = load i1, ptr %l121, !tbaa !21
  store i1 %t222, ptr %l119, !tbaa !21
  br label %bb49
bb49:
  %t223 = load i1, ptr %l119, !tbaa !21
  %t224 = xor i1 %t223, true
  store i1 %t224, ptr %l115, !tbaa !21
  br label %bb50
bb50:
  %t226 = load i1, ptr %l115, !tbaa !21
  br i1 %t226, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb52:
  br label %bb53
bb53:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i64, ptr %l17, !tbaa !24
  %t231 = call i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %t227, i64 %t228)
  store i32 %t231, ptr %l125
  br label %bb54
bb54:
  %t232 = load i32, ptr %l1, !tbaa !23
  %t233 = load i32, ptr %l125, !tbaa !23
  %t235 = icmp eq i32 %t233, %t232
  br i1 %t235, label %bb55, label %bb56
bb55:
  %t237 = load ptr, ptr %lp3
  %t238 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t237, i64 %t238)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb59:
  %t241 = load i64, ptr %l14, !tbaa !24
  %t243 = add i64 %t241, 1
  store i64 %t243, ptr %l14, !tbaa !24
  br label %bb24
bb60:
  %t245 = load ptr, ptr %lp3
  %t246 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t245
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t246, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eCaps(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca %"compiler/effects:Facts"
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca %"compiler/effects:Facts"
  %l54 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l81 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca %"compiler/effects:Facts"
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l100 = alloca { i64, ptr }
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l121 = alloca i64
  %l124 = alloca i64
  %l148 = alloca i1
  %l149 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l157 = alloca i1
  %l163 = alloca i64
  %l165 = alloca i64
  %l170 = alloca i64
  %l173 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l183 = alloca %"std/prelude/text:StringBuilder"
  %l185 = alloca i64
  %l187 = alloca i64
  %l192 = alloca i64
  %l199 = alloca i64
  %l202 = alloca i64
  %l227 = alloca ptr
  %l229 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l231 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l237 = alloca i64
  %l238 = alloca { i64, ptr }
  %l240 = alloca i1
  %l242 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l251 = alloca i64
  %l252 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t31 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l40
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l40, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 10
  %t15 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H6c17f05b74a2ea6689cdfc72c602a991(ptr %v0, ptr %v0, ptr %t13)
  store { i64, ptr } %t15, ptr %l45
  br label %bb2
bb2:
  %t16 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l47, !tbaa !24
  %t20 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t20, ptr %l48
  br label %bb3
bb3:
  %t21 = load i64, ptr %l47, !tbaa !24
  %t22 = icmp sge i64 %t21, 0
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load i64, ptr %l47, !tbaa !24
  %t25 = icmp sle i64 %t24, 115292150460684697
  br i1 %t25, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_91de52063b71ca44_3ab230bc0b47a90)
  unreachable
bb6:
  %t27 = load i64, ptr %l47, !tbaa !24
  %t28 = mul i64 %t27, 80
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  %t30 = load %"compiler/effects:Facts", ptr %l48
  store i64 0, ptr %t31
  br label %fill.32
fill.32:
  %t35 = load i64, ptr %t31
  %t36 = icmp slt i64 %t35, %t27
  br i1 %t36, label %fillb.33, label %filld.34
fillb.33:
  %t37 = getelementptr %"compiler/effects:Facts", ptr %t29, i64 %t35
  store %"compiler/effects:Facts" %t30, ptr %t37
  %t38 = add i64 %t35, 1
  store i64 %t38, ptr %t31
  br label %fill.32
filld.34:
  %t39 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t29, 1
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 14
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l54
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_91de52063b71ca44_3ab230bc0b47a90)
  unreachable
bb8:
  %t47 = load i64, ptr %l54, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = icmp sgt i64 %t48, %t49
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb14
bb11:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = sub i64 %t58, %t59
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = sub i64 %t66, 1
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = sdiv i64 %t68, %t69
  store i64 %t72, ptr %l61, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb13
bb13:
  %t74 = load i64, ptr %l61, !tbaa !24
  store i64 %t74, ptr %l58, !tbaa !24
  br label %bb14
bb14:
  %t75 = load i64, ptr %l58, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb16, label %bb17
bb16:
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t84 = load i64, ptr %l4, !tbaa !24
  %t85 = load i64, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = mul i64 %t85, %t86
  %t92 = add i64 %t84, %t89
  store i64 %t92, ptr %l9, !tbaa !24
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t95 = load i64, ptr %l9, !tbaa !24
  %t98 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eModuleOf(ptr %v0, ptr %t94, i64 %t95)
  store i64 %t98, ptr %l81
  br label %bb19
bb19:
  %t99 = load i64, ptr %l81, !tbaa !24
  store i64 %t99, ptr %l10, !tbaa !24
  %t100 = load i64, ptr %l10, !tbaa !24
  %t102 = icmp sge i64 %t100, 0
  br i1 %t102, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr %"compiler/effects:Facts", ptr %t107, i64 %t104
  store ptr %t108, ptr %l85, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t110 = load i64, ptr %l9, !tbaa !24
  %t113 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t109, i64 %t110)
  store %"compiler/effects:Facts" %t113, ptr %l88
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t114 = load ptr, ptr %l85, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s3, ptr %t114, ptr %l88)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l8, !tbaa !24
  br label %bb15
bb26:
  %t120 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l92
  br label %bb27
bb27:
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l11
  %t122 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t122, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  store i64 %t126, ptr %l14, !tbaa !24
  br label %bb28
bb28:
  %t128 = load i64, ptr %l13, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb29, label %bb30
bb29:
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t136 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t136, ptr %l100, !tbaa !27
  %t137 = load i64, ptr %l13, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr ptr, ptr %t140, i64 %t137
  %t142 = load ptr, ptr %t141, !tbaa !39
  %t146 = getelementptr %"compiler/load:Module", ptr %t142, i32 0, i32 2
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = extractvalue { i64, ptr } %t147, 0
  %t151 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t149, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l11, { i64, ptr } %t160)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t163 = load i64, ptr %l13, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l13, !tbaa !24
  br label %bb28
bb34:
  %t167 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167, ptr %l110
  br label %bb35
bb35:
  %t168 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %l16
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/generic:Program", ptr %t172, i32 0, i32 0
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/load:Loader", ptr %t175, i32 0, i32 12
  %t178 = load i64, ptr %t177, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l16, i64 %t178)
  br label %bb36
bb36:
  store i64 0, ptr %l17, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  store i64 %t183, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l18, !tbaa !24
  %t186 = load i64, ptr %l17, !tbaa !24
  %t189 = icmp sgt i64 %t185, %t186
  br i1 %t189, label %bb37, label %bb38
bb37:
  %t191 = load i64, ptr %l19, !tbaa !24
  %t193 = icmp sgt i64 %t191, 0
  br i1 %t193, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb42
bb39:
  %t195 = load i64, ptr %l18, !tbaa !24
  %t196 = load i64, ptr %l17, !tbaa !24
  %t199 = sub i64 %t195, %t196
  %t200 = load i64, ptr %l19, !tbaa !24
  %t203 = add i64 %t199, %t200
  %t205 = sub i64 %t203, 1
  %t206 = load i64, ptr %l19, !tbaa !24
  %t209 = sdiv i64 %t205, %t206
  store i64 %t209, ptr %l124, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb41
bb41:
  %t211 = load i64, ptr %l124, !tbaa !24
  store i64 %t211, ptr %l121, !tbaa !24
  br label %bb42
bb42:
  %t212 = load i64, ptr %l121, !tbaa !24
  store i64 %t212, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb43
bb43:
  %t213 = load i64, ptr %l21, !tbaa !24
  %t214 = load i64, ptr %l20, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb44, label %bb45
bb44:
  br label %bb56
bb45:
  br label %bb46
bb46:
  %t221 = load i64, ptr %l17, !tbaa !24
  %t222 = load i64, ptr %l21, !tbaa !24
  %t223 = load i64, ptr %l19, !tbaa !24
  %t226 = mul i64 %t222, %t223
  %t229 = add i64 %t221, %t226
  store i64 %t229, ptr %l22, !tbaa !24
  %t231 = load i64, ptr %l22, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 0
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/load:Loader", ptr %t238, i32 0, i32 12
  %t241 = load i64, ptr %t240, !tbaa !24
  %t244 = icmp ne i64 %t231, %t241
  br i1 %t244, label %bb47, label %bb48
bb47:
  %t246 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t246, ptr %l149, !tbaa !27
  %t247 = load i64, ptr %l22, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr ptr, ptr %t250, i64 %t247
  %t252 = load ptr, ptr %t251, !tbaa !39
  %t254 = getelementptr %"compiler/load:Module", ptr %t252, i32 0, i32 2
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t256, ptr %l153, !tbaa !27
  %t257 = load i64, ptr %l22, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr ptr, ptr %t260, i64 %t257
  %t262 = load ptr, ptr %t261, !tbaa !39
  %t264 = getelementptr %"compiler/load:Module", ptr %t262, i32 0, i32 3
  %t265 = load i1, ptr %t264, !tbaa !21
  %t268 = call i1 @compiler_2fexplain_2ecapsShown(ptr %v0, { i64, ptr } %t255, i1 %t265)
  store i1 %t268, ptr %l157
  br label %bb49
bb48:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb50
bb49:
  %t269 = load i1, ptr %l157, !tbaa !21
  store i1 %t269, ptr %l148, !tbaa !21
  br label %bb50
bb50:
  %t270 = load i1, ptr %l148, !tbaa !21
  br i1 %t270, label %bb51, label %bb52
bb51:
  %t271 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l16, i64 %t271)
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t274 = load i64, ptr %l21, !tbaa !24
  %t276 = add i64 %t274, 1
  store i64 %t276, ptr %l21, !tbaa !24
  br label %bb43
bb56:
  store i64 0, ptr %l23, !tbaa !24
  store ptr %l16, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s14
  %t279 = load i64, ptr %l25, !tbaa !24
  store i64 %t279, ptr %l163, !tbaa !24
  %t280 = load ptr, ptr %l24, !tbaa !29
  %t282 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t280)
  store i64 %t282, ptr %l165
  br label %bb58
bb58:
  %t283 = load i64, ptr %l163, !tbaa !24
  %t284 = load i64, ptr %l165, !tbaa !24
  %t285 = icmp slt i64 %t283, %t284
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s14)
  br label %bb69
bb60:
  br label %bb61
bb61:
  %t289 = load ptr, ptr %l24, !tbaa !29
  %t290 = load i64, ptr %l25, !tbaa !24
  %t293 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t289, i64 %t290)
  store i64 %t293, ptr %l170
  br label %bb62
bb62:
  %t294 = load i64, ptr %l170, !tbaa !24
  store i64 %t294, ptr %l26, !tbaa !24
  %t295 = load i64, ptr %l26, !tbaa !24
  %t298 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s14, ptr %l11, i64 %t295)
  store { i64, ptr } %t298, ptr %l173
  br label %bb63
bb63:
  %t299 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 0
  %t301 = load i64, ptr %l23, !tbaa !24
  %t304 = icmp sgt i64 %t300, %t301
  br i1 %t304, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s15
  %t306 = load i64, ptr %l26, !tbaa !24
  %t309 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s15, ptr %l11, i64 %t306)
  store { i64, ptr } %t309, ptr %l179
  br label %bb66
bb65:
  br label %bb67
bb66:
  %t310 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 0
  store i64 %t311, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s14)
  br label %bb68
bb68:
  %t313 = load i64, ptr %l25, !tbaa !24
  %t315 = add i64 %t313, 1
  store i64 %t315, ptr %l25, !tbaa !24
  br label %bb57
bb69:
  %t317 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t317, ptr %l183
  br label %bb70
bb70:
  %t318 = load %"std/prelude/text:StringBuilder", ptr %l183
  store %"std/prelude/text:StringBuilder" %t318, ptr %l27
  store ptr %l16, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s18
  %t320 = load i64, ptr %l29, !tbaa !24
  store i64 %t320, ptr %l185, !tbaa !24
  %t321 = load ptr, ptr %l28, !tbaa !29
  %t323 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t321)
  store i64 %t323, ptr %l187
  br label %bb72
bb72:
  %t324 = load i64, ptr %l185, !tbaa !24
  %t325 = load i64, ptr %l187, !tbaa !24
  %t326 = icmp slt i64 %t324, %t325
  %t328 = xor i1 %t326, true
  br i1 %t328, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s18)
  br label %bb102
bb74:
  br label %bb75
bb75:
  %t330 = load ptr, ptr %l28, !tbaa !29
  %t331 = load i64, ptr %l29, !tbaa !24
  %t334 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t330, i64 %t331)
  store i64 %t334, ptr %l192
  br label %bb76
bb76:
  %t335 = load i64, ptr %l192, !tbaa !24
  store i64 %t335, ptr %l30, !tbaa !24
  %t336 = load i64, ptr %l30, !tbaa !24
  %t338 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr %"compiler/effects:Facts", ptr %t339, i64 %t336
  %t341 = load %"compiler/effects:Facts", ptr %t340
  store %"compiler/effects:Facts" %t341, ptr %l31
  store i64 0, ptr %l32, !tbaa !24
  %t343 = load i64, ptr @G_2ecompiler_2feffects_2eCapCount, !tbaa !24
  store i64 %t343, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t345 = load i64, ptr %l33, !tbaa !24
  %t346 = load i64, ptr %l32, !tbaa !24
  %t349 = icmp sgt i64 %t345, %t346
  br i1 %t349, label %bb77, label %bb78
bb77:
  %t351 = load i64, ptr %l34, !tbaa !24
  %t353 = icmp sgt i64 %t351, 0
  br i1 %t353, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb82
bb79:
  %t355 = load i64, ptr %l33, !tbaa !24
  %t356 = load i64, ptr %l32, !tbaa !24
  %t359 = sub i64 %t355, %t356
  %t360 = load i64, ptr %l34, !tbaa !24
  %t363 = add i64 %t359, %t360
  %t365 = sub i64 %t363, 1
  %t366 = load i64, ptr %l34, !tbaa !24
  %t369 = sdiv i64 %t365, %t366
  store i64 %t369, ptr %l202, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb81
bb81:
  %t371 = load i64, ptr %l202, !tbaa !24
  store i64 %t371, ptr %l199, !tbaa !24
  br label %bb82
bb82:
  %t372 = load i64, ptr %l199, !tbaa !24
  store i64 %t372, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb83
bb83:
  %t373 = load i64, ptr %l36, !tbaa !24
  %t374 = load i64, ptr %l35, !tbaa !24
  %t377 = icmp slt i64 %t373, %t374
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb84, label %bb85
bb84:
  br label %bb91
bb85:
  br label %bb86
bb86:
  %t381 = load i64, ptr %l32, !tbaa !24
  %t382 = load i64, ptr %l36, !tbaa !24
  %t383 = load i64, ptr %l34, !tbaa !24
  %t386 = mul i64 %t382, %t383
  %t389 = add i64 %t381, %t386
  store i64 %t389, ptr %l37, !tbaa !24
  %t391 = load i64, ptr %l37, !tbaa !24
  %t392 = getelementptr %"compiler/effects:Facts", ptr %l31, i32 0, i32 15
  %t394 = getelementptr [6 x i64], ptr %t392, i64 0, i64 %t391
  %t395 = load i64, ptr %t394, !tbaa !34
  %t396 = load i64, ptr %l30, !tbaa !24
  %t399 = icmp eq i64 %t395, %t396
  br i1 %t399, label %bb87, label %bb88
bb87:
  %t401 = load i64, ptr %l37, !tbaa !24
  %t402 = getelementptr %"compiler/effects:Facts", ptr %l31, i32 0, i32 15
  %t404 = getelementptr [6 x i64], ptr %t402, i64 0, i64 %t401
  store i64 -1, ptr %t404, !tbaa !34
  br label %bb89
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t405 = load i64, ptr %l36, !tbaa !24
  %t407 = add i64 %t405, 1
  store i64 %t407, ptr %l36, !tbaa !24
  br label %bb83
bb91:
  store ptr %l31, ptr %l227, !tbaa !29
  %t410 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l11)
  store { i64, ptr } %t410, ptr %l229
  br label %bb92
bb92:
  %t411 = load ptr, ptr %l227, !tbaa !29
  %t412 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t413 = call { i64, ptr } @compiler_2feffects_2eCapText(ptr %s18, ptr %s0, ptr %s18, ptr %t411, { i64, ptr } %t412)
  store { i64, ptr } %t413, ptr %l230
  br label %bb93
bb93:
  %t414 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t414, ptr %l38, !tbaa !27
  store ptr %l27, ptr %l231, !tbaa !29
  %t415 = load i64, ptr %l30, !tbaa !24
  %t418 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l11, i64 %t415)
  store { i64, ptr } %t418, ptr %l234
  br label %bb94
bb94:
  %t419 = load i64, ptr %l23, !tbaa !24
  %t420 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t422 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s0, ptr %s18, { i64, ptr } %t420, i64 %t419, i8 32)
  store { i64, ptr } %t422, ptr %l236
  br label %bb95
bb95:
  %t423 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t423, 0
  store i64 %t424, ptr %l237, !tbaa !24
  %t425 = load i64, ptr %l237, !tbaa !24
  %t426 = mul i64 %t425, 1
  %t427 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t426)
  %t428 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t429 = insertvalue { i64, ptr } %t428, ptr %t427, 1
  store { i64, ptr } %t429, ptr %l238, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = load i64, ptr %l237, !tbaa !24
  %t435 = mul i64 %t434, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t431, ptr %t433, i64 %t435, i1 false)
  %t436 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t438 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s18, ptr %s18, { i64, ptr } %t436, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t438, ptr %l240
  br label %bb96
bb96:
  %t439 = load i1, ptr %l240, !tbaa !21
  %t440 = xor i1 %t439, true
  br i1 %t440, label %bb97, label %bb98
bb97:
  %t442 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t442, ptr %l242, !tbaa !27
  br label %bb99
bb98:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l242, !tbaa !27
  br label %bb99
bb99:
  %t444 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 1
  %t446 = extractvalue { i64, ptr } %t444, 0
  %t447 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t448 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t449 = add i64 %t446, %t448
  %t450 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t450, 1
  %t452 = extractvalue { i64, ptr } %t450, 0
  %t453 = add i64 %t449, %t452
  %t454 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t455 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t456 = add i64 %t453, %t455
  %t457 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t456)
  call void @olang_textcopy(ptr %t457, ptr %t445, i64 %t446)
  %t458 = getelementptr i8, ptr %t457, i64 %t446
  call void @olang_textcopy(ptr %t458, ptr %t447, i64 %t448)
  %t459 = getelementptr i8, ptr %t458, i64 %t448
  call void @olang_textcopy(ptr %t459, ptr %t451, i64 %t452)
  %t460 = getelementptr i8, ptr %t459, i64 %t452
  call void @olang_textcopy(ptr %t460, ptr %t454, i64 %t455)
  %t461 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t462 = insertvalue { i64, ptr } %t461, ptr %t457, 1
  %t464 = extractvalue { i64, ptr } %t462, 0
  %t465 = extractvalue { i64, ptr } %t462, 1
  %t466 = mul i64 %t464, 1
  %t467 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t466)
  call void @llvm.memcpy.p0.p0.i64(ptr %t467, ptr %t465, i64 %t466, i1 false)
  %t468 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t469 = insertvalue { i64, ptr } %t468, ptr %t467, 1
  %t470 = load ptr, ptr %l231, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %t470, { i64, ptr } %t469)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s18)
  br label %bb101
bb101:
  %t472 = load i64, ptr %l29, !tbaa !24
  %t474 = add i64 %t472, 1
  store i64 %t474, ptr %l29, !tbaa !24
  br label %bb71
bb102:
  %t477 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l27)
  store { i64, ptr } %t477, ptr %l249
  br label %bb103
bb103:
  %t478 = load { i64, ptr }, ptr %l249, !tbaa !27
  store { i64, ptr } %t478, ptr %l250, !tbaa !27
  %t479 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t479, 0
  store i64 %t480, ptr %l251, !tbaa !24
  %t481 = load i64, ptr %l251, !tbaa !24
  %t482 = mul i64 %t481, 1
  %t483 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t482)
  %t484 = insertvalue { i64, ptr } undef, i64 %t481, 0
  %t485 = insertvalue { i64, ptr } %t484, ptr %t483, 1
  store { i64, ptr } %t485, ptr %l252, !tbaa !27
  %t486 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t487 = load ptr, ptr %t486, !tbaa !27
  %t488 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t489 = load ptr, ptr %t488, !tbaa !27
  %t490 = load i64, ptr %l251, !tbaa !24
  %t491 = mul i64 %t490, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t487, ptr %t489, i64 %t491, i1 false)
  %t492 = load { i64, ptr }, ptr %l252, !tbaa !27
  store { i64, ptr } %t492, ptr %l250, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t493 = load { i64, ptr }, ptr %l250, !tbaa !27
  store { i64, ptr } %t493, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eFnLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l18 = alloca i32
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i64
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t5)
  store i64 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t8, i64 %t9)
  store i64 %t10, ptr %l7
  br label %bb2
bb2:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t17, i64 %t18, i32 0)
  store i64 %t21, ptr %l12
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i64, ptr %l12, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l14, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t33, i64 %t34)
  store i64 %t37, ptr %l21
  br label %bb7
bb7:
  %t38 = load ptr, ptr %l13, !tbaa !29
  %t39 = load i64, ptr %l14, !tbaa !24
  %t40 = load i32, ptr %l18, !tbaa !23
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %t38, i64 %t39, i32 %t40, i64 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l23, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  store i64 %t45, ptr %l24, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t49, i64 %t50)
  store i32 %t53, ptr %l28
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l23, !tbaa !29
  %t55 = load i64, ptr %l24, !tbaa !24
  %t56 = load i32, ptr %l28, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %t54, i64 %t55, i32 %t56, i64 -1)
  store { i64, ptr } %t57, ptr %l29
  br label %bb11
bb11:
  %t58 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/names:Entry"
  %l13 = alloca i64
  %l14 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l36 = alloca i32
  %l41 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l49 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l58 = alloca i32
  %l59 = alloca i64
  %l66 = alloca { i64, ptr }
  %l69 = alloca i32
  %l75 = alloca ptr
  %l78 = alloca i64
  %l80 = alloca i64
  %l85 = alloca %"compiler/names:Entry"
  %l95 = alloca i64
  %l101 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l114 = alloca i32
  %l119 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 3
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v3, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) })
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l24
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb3, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l23
  br label %bb2
bb2:
  %t23 = load i64, ptr %l23, !tbaa !24
  store i64 %t23, ptr %l21, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb5
bb5:
  %t24 = load i64, ptr %l21, !tbaa !24
  store i64 %t24, ptr %l6, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l27, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l28, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %l29, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  store i64 %t32, ptr %l30, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l31, !tbaa !24
  %t35 = icmp sge i64 0, 0
  br i1 %t35, label %bb8, label %bb9
bb7:
  br label %bb31
bb8:
  %t37 = load i64, ptr %l30, !tbaa !24
  %t38 = icmp sle i64 0, %t37
  br i1 %t38, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb10:
  %t40 = load i64, ptr %l30, !tbaa !24
  %t41 = load i64, ptr %l31, !tbaa !24
  %t42 = icmp sle i64 %t40, %t41
  br i1 %t42, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb12:
  %t44 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l30, !tbaa !24
  %t47 = getelementptr i8, ptr %t45, i64 0
  %t48 = sub i64 %t46, 0
  %t49 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  %t51 = load ptr, ptr %l27, !tbaa !29
  %t52 = load i64, ptr %l28, !tbaa !24
  %t54 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t51, i64 %t52, { i64, ptr } %t50)
  store i32 %t54, ptr %l36
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb14:
  %t55 = load i32, ptr %l36, !tbaa !23
  store i32 %t55, ptr %l7, !tbaa !23
  %t56 = load i32, ptr %l7, !tbaa !23
  %t58 = icmp slt i32 %t56, 0
  br i1 %t58, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t61 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t61, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l41, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load i32, ptr %l7, !tbaa !23
  %t73 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l45
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l5, !tbaa !29
  store ptr %t74, ptr %l46, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t75, ptr %l47, !tbaa !27
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l49, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t79, 0
  store i64 %t82, ptr %l52, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l53, !tbaa !24
  %t85 = load i64, ptr %l49, !tbaa !24
  %t86 = icmp sge i64 %t85, 0
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t88 = load i64, ptr %l49, !tbaa !24
  %t89 = load i64, ptr %l52, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb21:
  %t92 = load i64, ptr %l52, !tbaa !24
  %t93 = load i64, ptr %l53, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb23:
  %t96 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l49, !tbaa !24
  %t99 = load i64, ptr %l52, !tbaa !24
  %t100 = getelementptr i8, ptr %t97, i64 %t98
  %t101 = sub i64 %t99, %t98
  %t102 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  %t104 = load ptr, ptr %l46, !tbaa !29
  %t106 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v3, ptr %t104, { i64, ptr } %t103)
  store i32 %t106, ptr %l58
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb25:
  %t107 = load ptr, ptr %l41, !tbaa !29
  %t108 = load i32, ptr %l45, !tbaa !23
  %t109 = load i32, ptr %l58, !tbaa !23
  %t110 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t107, i32 %t108, i32 %t109)
  store i64 %t110, ptr %l59
  br label %bb26
bb26:
  %t111 = load i64, ptr %l59, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  %t112 = load i64, ptr %l8, !tbaa !24
  %t114 = icmp slt i64 %t112, 0
  br i1 %t114, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t117 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t117, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t120 = load i64, ptr %l8, !tbaa !24
  %t124 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t118, ptr %t119, i64 %t120)
  store { i64, ptr } %t124, ptr %l66
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t125 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t126 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t125, 1
  store { i32, { i64, ptr } } %t126, ptr %rv
  br label %ret
bb31:
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t131 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v3, ptr %t127, { i64, ptr } %t128)
  store i32 %t131, ptr %l69
  br label %bb32
bb32:
  %t132 = load i32, ptr %l69, !tbaa !23
  store i32 %t132, ptr %l9, !tbaa !23
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/names:Resolver", ptr %t139, i32 0, i32 1
  %t142 = load i64, ptr %l3, !tbaa !24
  %t145 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t141, i64 %t142)
  store ptr %t145, ptr %l75
  br label %bb33
bb33:
  %t146 = load ptr, ptr %l75, !tbaa !29
  %t148 = getelementptr %"compiler/names:Table", ptr %t146, i32 0, i32 0
  store ptr %t148, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb34
bb34:
  %t150 = load i64, ptr %l11, !tbaa !24
  store i64 %t150, ptr %l78, !tbaa !24
  %t151 = load ptr, ptr %l10, !tbaa !29
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t151)
  store i64 %t153, ptr %l80
  br label %bb35
bb35:
  %t154 = load i64, ptr %l78, !tbaa !24
  %t155 = load i64, ptr %l80, !tbaa !24
  %t156 = icmp slt i64 %t154, %t155
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb36, label %bb37
bb36:
  br label %bb56
bb37:
  br label %bb38
bb38:
  %t160 = load ptr, ptr %l10, !tbaa !29
  %t161 = load i64, ptr %l11, !tbaa !24
  %t164 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t160, i64 %t161)
  store %"compiler/names:Entry" %t164, ptr %l85
  br label %bb39
bb39:
  %t165 = load %"compiler/names:Entry", ptr %l85
  store %"compiler/names:Entry" %t165, ptr %l12
  %t166 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 0
  %t167 = load i32, ptr %t166, !tbaa !23
  %t168 = load i32, ptr %l9, !tbaa !23
  %t171 = icmp ne i32 %t167, %t168
  br i1 %t171, label %bb40, label %bb41
bb40:
  br label %bb55
bb41:
  br label %bb42
bb42:
  %t173 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 2
  %t174 = load i32, ptr %t173, !range !{i32 0, i32 9}
  %t176 = trunc i64 3 to i32
  %t177 = icmp eq i32 %t174, %t176
  br i1 %t177, label %bb43, label %bb44
bb43:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t183 = load i64, ptr %l3, !tbaa !24
  %t184 = load i32, ptr %l9, !tbaa !23
  %t188 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t182, i64 %t183, i32 %t184)
  store i64 %t188, ptr %l95
  br label %bb45
bb44:
  br label %bb50
bb45:
  %t189 = load i64, ptr %l95, !tbaa !24
  store i64 %t189, ptr %l13, !tbaa !24
  %t190 = load i64, ptr %l13, !tbaa !24
  %t192 = icmp sge i64 %t190, 0
  br i1 %t192, label %bb46, label %bb47
bb46:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t196 = load i64, ptr %l13, !tbaa !24
  %t200 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t194, ptr %t195, i64 %t196)
  store { i64, ptr } %t200, ptr %l101
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t201 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t202 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t201, 1
  store { i32, { i64, ptr } } %t202, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t203 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 2
  %t204 = load i32, ptr %t203, !range !{i32 0, i32 9}
  %t206 = trunc i64 2 to i32
  %t207 = icmp eq i32 %t204, %t206
  br i1 %t207, label %bb51, label %bb52
bb51:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i64, ptr %l3, !tbaa !24
  %t212 = load %"compiler/names:Entry", ptr %l12
  %t217 = call { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v2, ptr %v0, ptr %v4, ptr %t209, ptr %a2, i64 %t211, %"compiler/names:Entry" %t212)
  store { i64, ptr } %t217, ptr %l108
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t218 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t219 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t218, 1
  store { i32, { i64, ptr } } %t219, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t220 = load i64, ptr %l11, !tbaa !24
  %t222 = add i64 %t220, 1
  store i64 %t222, ptr %l11, !tbaa !24
  br label %bb34
bb56:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load i64, ptr %l3, !tbaa !24
  %t226 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t230 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t224, i64 %t225, { i64, ptr } %t226)
  store i32 %t230, ptr %l114
  br label %bb57
bb57:
  %t231 = load i32, ptr %l114, !tbaa !23
  store i32 %t231, ptr %l14, !tbaa !23
  %t232 = load i32, ptr %l14, !tbaa !23
  %t234 = icmp sge i32 %t232, 0
  br i1 %t234, label %bb58, label %bb59
bb58:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i32, ptr %l14, !tbaa !23
  %t240 = call { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v4, ptr %t236, i32 %t237)
  store { i64, ptr } %t240, ptr %l119
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s0)
  %t241 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t242 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t241, 1
  store { i32, { i64, ptr } } %t242, ptr %rv
  br label %ret
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t244 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t244, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eNoValueWhy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l10 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l39 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l51 = alloca i64
  %l57 = alloca i1
  %l64 = alloca { i64, ptr }
  %l67 = alloca i1
  %l70 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l10, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t19, i32 %t23)
  store { i64, ptr } %t26, ptr %l17
  br label %bb2
bb2:
  %t27 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Func", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load i64, ptr %l24, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l25, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l24, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t51, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t56, i64 %t57)
  store i1 %t60, ptr %l29
  br label %bb6
bb6:
  %t61 = load i1, ptr %l29, !tbaa !21
  br i1 %t61, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t62, ptr %l31, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l32, !tbaa !24
  %t65 = load i64, ptr %l32, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l33, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l32, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t76, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t77 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t80 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t78)
  store i64 %t80, ptr %l35
  br label %bb10
bb10:
  %t81 = load i64, ptr %l35, !tbaa !24
  store i64 %t81, ptr %l6, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t85, i64 %t86)
  store i64 %t89, ptr %l39
  br label %bb11
bb11:
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t92 = getelementptr %"compiler/ast:Func", ptr %t90, i32 0, i32 5
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = load i64, ptr %l39, !tbaa !24
  %t98 = icmp sgt i64 %t96, %t95
  br i1 %t98, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t100, ptr %l45, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l46, !tbaa !24
  %t103 = load i64, ptr %l46, !tbaa !24
  %t104 = mul i64 %t103, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l47, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l46, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  %t114 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t114, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t115 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t115, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load i64, ptr %l6, !tbaa !24
  %t123 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t119, i64 %t120)
  store i64 %t123, ptr %l51
  br label %bb15
bb15:
  %t124 = load i64, ptr %l51, !tbaa !24
  %t125 = icmp sgt i64 %t124, 0
  br i1 %t125, label %bb16, label %bb17
bb16:
  %t127 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t128 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t131 = extractvalue { i64, ptr } %t127, 1
  %t132 = extractvalue { i64, ptr } %t127, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t128, i64 %t129)
  %t138 = getelementptr i8, ptr %t137, i64 %t129
  call void @olang_textcopy(ptr %t138, ptr %t131, i64 %t132)
  %t139 = getelementptr i8, ptr %t138, i64 %t132
  call void @olang_textcopy(ptr %t139, ptr %t134, i64 %t135)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t137, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t141, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t143 = load i64, ptr %l3, !tbaa !24
  %t145 = icmp sge i64 %t143, 0
  br i1 %t145, label %bb19, label %bb20
bb19:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t148 = load i64, ptr %l3, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/load:Loader", ptr %t155, i32 0, i32 3
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t162 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v1, ptr %v0, ptr %s0, ptr %t147, i64 %t148, ptr %t158)
  store { i64, ptr } %t162, ptr %l64
  br label %bb21
bb20:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb22
bb21:
  %t163 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  %t166 = icmp sgt i64 %t164, 0
  store i1 %t166, ptr %l57, !tbaa !21
  br label %bb22
bb22:
  %t168 = load i1, ptr %l57, !tbaa !21
  br i1 %t168, label %bb23, label %bb24
bb23:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t170 = load i64, ptr %l3, !tbaa !24
  %t173 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eValueCovered(ptr %v1, ptr %t169, i64 %t170)
  store i1 %t173, ptr %l70
  br label %bb25
bb24:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb26
bb25:
  %t174 = load i1, ptr %l70, !tbaa !21
  %t175 = xor i1 %t174, true
  store i1 %t175, ptr %l67, !tbaa !21
  br label %bb26
bb26:
  %t177 = load i1, ptr %l67, !tbaa !21
  br i1 %t177, label %bb27, label %bb28
bb27:
  store { i64, ptr } { i64 181, ptr getelementptr inbounds (<{ i64, [181 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l72, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t178, ptr %l73, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l74, !tbaa !24
  %t181 = load i64, ptr %l74, !tbaa !24
  %t182 = mul i64 %t181, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l75, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = load i64, ptr %l74, !tbaa !24
  %t191 = mul i64 %t190, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t187, ptr %t189, i64 %t191, i1 false)
  %t192 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t192, ptr %l73, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t193 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t193, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l76, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t194, ptr %l77, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l78, !tbaa !24
  %t197 = load i64, ptr %l78, !tbaa !24
  %t198 = mul i64 %t197, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t198)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  store { i64, ptr } %t201, ptr %l79, !tbaa !27
  %t202 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = load i64, ptr %l78, !tbaa !24
  %t207 = mul i64 %t206, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t203, ptr %t205, i64 %t207, i1 false)
  %t208 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t208, ptr %l77, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t209 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t209, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2eattrLines(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l19 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %s3 = alloca %olang.scope
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 10
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t15, i64 %a2)
  store ptr %t19, ptr %l19
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l19, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l5, !tbaa !29
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_e4b17f5ad4d0393_dacada4c9c892187)
  unreachable
bb6:
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l6, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t49 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t49, ptr %l34, !tbaa !27
  %t50 = load i64, ptr %l8, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr ptr, ptr %t53, i64 %t50
  %t55 = load ptr, ptr %t54, !tbaa !39
  store ptr %t55, ptr %l10, !tbaa !29
  store ptr %a0, ptr %l37, !tbaa !29
  store { i64, ptr } %a4, ptr %l38, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t59, ptr %l39, !tbaa !27
  %t60 = load ptr, ptr %l10, !tbaa !29
  %t62 = getelementptr %"compiler/ast:Attr", ptr %t60, i32 0, i32 0
  %t63 = getelementptr %"compiler/source:Span", ptr %t62, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l42, !tbaa !24
  %t67 = load ptr, ptr %l10, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Attr", ptr %t67, i32 0, i32 0
  %t70 = getelementptr %"compiler/source:Span", ptr %t69, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = sext i32 %t71 to i64
  store i64 %t73, ptr %l45, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l46, !tbaa !24
  %t76 = load i64, ptr %l42, !tbaa !24
  %t77 = icmp sge i64 %t76, 0
  br i1 %t77, label %bb12, label %bb13
bb12:
  %t79 = load i64, ptr %l42, !tbaa !24
  %t80 = load i64, ptr %l45, !tbaa !24
  %t81 = icmp sle i64 %t79, %t80
  br i1 %t81, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_31b785093080fa1c_de0f6dc4f3b337d0)
  unreachable
bb14:
  %t83 = load i64, ptr %l45, !tbaa !24
  %t84 = load i64, ptr %l46, !tbaa !24
  %t85 = icmp sle i64 %t83, %t84
  br i1 %t85, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_31b785093080fa1c_de0f6dc4f3b337d0)
  unreachable
bb16:
  %t87 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l42, !tbaa !24
  %t90 = load i64, ptr %l45, !tbaa !24
  %t91 = getelementptr i8, ptr %t88, i64 %t89
  %t92 = sub i64 %t90, %t89
  %t93 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t91, 1
  %t95 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = extractvalue { i64, ptr } %t94, 1
  %t100 = extractvalue { i64, ptr } %t94, 0
  %t101 = add i64 %t97, %t100
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t96, i64 %t97)
  %t106 = getelementptr i8, ptr %t105, i64 %t97
  call void @olang_textcopy(ptr %t106, ptr %t99, i64 %t100)
  %t107 = getelementptr i8, ptr %t106, i64 %t100
  call void @olang_textcopy(ptr %t107, ptr %t102, i64 %t103)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t105, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = extractvalue { i64, ptr } %t109, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t117 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t117, { i64, ptr } %t116)
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_31b785093080fa1c_de0f6dc4f3b337d0)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l8, !tbaa !24
  br label %bb8
bb20:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2eattrsBefore(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, { i64, ptr } }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca { i64, { i64, ptr } }
  %l20 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l41 = alloca %"std/prelude/text:StringBuilder"
  %l49 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAttrsOf(ptr %v0, ptr %s0, ptr %t4, i32 %a1)
  store { i64, { i64, ptr } } %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load { i64, { i64, ptr } }, ptr %l15
  store { i64, { i64, ptr } } %t9, ptr %l2
  %t10 = getelementptr { i64, { i64, ptr } }, ptr %l2, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, { i64, ptr } }, ptr %l2, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t16, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb4
bb3:
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp eq i64 %t22, 0
  store i1 %t24, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t27, ptr %l25, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l26, !tbaa !24
  %t30 = load i64, ptr %l26, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l27, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l26, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t42 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t42, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/load:Loader", ptr %t49, i32 0, i32 10
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l33
  br label %bb8
bb8:
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t58 = getelementptr %"compiler/load:Module", ptr %t56, i32 0, i32 6
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l5, !tbaa !29
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  br i1 %t63, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_654ac6e7d4d962a_57fceb1b72d2ae56)
  unreachable
bb10:
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/source:Source", ptr %t65, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l6, !tbaa !27
  %t71 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t71, ptr %l41
  br label %bb12
bb12:
  %t72 = load %"std/prelude/text:StringBuilder", ptr %l41
  store %"std/prelude/text:StringBuilder" %t72, ptr %l7
  %t73 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t73, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t87 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t87, ptr %l49, !tbaa !27
  %t88 = load i64, ptr %l9, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr ptr, ptr %t91, i64 %t88
  %t93 = load ptr, ptr %t92, !tbaa !39
  store ptr %t93, ptr %l11, !tbaa !29
  store ptr %l7, ptr %l52, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t95, ptr %l53, !tbaa !27
  %t96 = load ptr, ptr %l11, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Attr", ptr %t96, i32 0, i32 0
  %t99 = getelementptr %"compiler/source:Span", ptr %t98, i32 0, i32 0
  %t100 = load i32, ptr %t99, !tbaa !23
  %t102 = sext i32 %t100 to i64
  store i64 %t102, ptr %l56, !tbaa !24
  %t103 = load ptr, ptr %l11, !tbaa !29
  %t105 = getelementptr %"compiler/ast:Attr", ptr %t103, i32 0, i32 0
  %t106 = getelementptr %"compiler/source:Span", ptr %t105, i32 0, i32 1
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = sext i32 %t107 to i64
  store i64 %t109, ptr %l59, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %l60, !tbaa !24
  %t112 = load i64, ptr %l56, !tbaa !24
  %t113 = icmp sge i64 %t112, 0
  br i1 %t113, label %bb17, label %bb18
bb17:
  %t115 = load i64, ptr %l56, !tbaa !24
  %t116 = load i64, ptr %l59, !tbaa !24
  %t117 = icmp sle i64 %t115, %t116
  br i1 %t117, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d0280248a738559f_8af1b7358df9134b)
  unreachable
bb19:
  %t119 = load i64, ptr %l59, !tbaa !24
  %t120 = load i64, ptr %l60, !tbaa !24
  %t121 = icmp sle i64 %t119, %t120
  br i1 %t121, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d0280248a738559f_8af1b7358df9134b)
  unreachable
bb21:
  %t123 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = load i64, ptr %l59, !tbaa !24
  %t127 = getelementptr i8, ptr %t124, i64 %t125
  %t128 = sub i64 %t126, %t125
  %t129 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t127, 1
  %t132 = extractvalue { i64, ptr } %t130, 1
  %t133 = extractvalue { i64, ptr } %t130, 0
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t132, i64 %t133)
  %t138 = getelementptr i8, ptr %t137, i64 %t133
  call void @olang_textcopy(ptr %t138, ptr %t134, i64 %t135)
  %t139 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = extractvalue { i64, ptr } %t140, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t148 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t148, { i64, ptr } %t147)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d0280248a738559f_8af1b7358df9134b)
  unreachable
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t150 = load i64, ptr %l9, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l9, !tbaa !24
  br label %bb13
bb25:
  %t155 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l7)
  store { i64, ptr } %t155, ptr %l70
  br label %bb26
bb26:
  %t156 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t156, ptr %l71, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  store i64 %t158, ptr %l72, !tbaa !24
  %t159 = load i64, ptr %l72, !tbaa !24
  %t160 = mul i64 %t159, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t160)
  %t162 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, ptr } %t163, ptr %l73, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = load i64, ptr %l72, !tbaa !24
  %t169 = mul i64 %t168, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t165, ptr %t167, i64 %t169, i1 false)
  %t170 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t170, ptr %l71, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t171 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t171, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2ebuilders(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fexplain_2eBuilders(ptr %v1, ptr %s1, ptr %t1, i32 %a2, i1 false)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t7 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  store ptr %t7, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l10, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t10)
  store i64 %t12, ptr %l12
  br label %bb3
bb3:
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l17
  br label %bb7
bb7:
  %t24 = load i64, ptr %l17, !tbaa !24
  store ptr %a0, ptr %l18, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2fexplain_2eFnLine(ptr %v1, ptr %s2, ptr %t26, i64 %t24)
  store { i64, ptr } %t30, ptr %l21
  br label %bb8
bb8:
  %t31 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t33 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t34, i64 %t35)
  %t42 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t40, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t52 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t52, { i64, ptr } %t51)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l4, !tbaa !24
  br label %bb2
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fexplain_2ecapsShown(ptr %v0, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = xor i1 %a1, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t7, ptr %l6
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t8 = load i1, ptr %l6, !tbaa !21
  %t9 = xor i1 %t8, true
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t14, ptr %l10
  br label %bb7
bb6:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb8
bb7:
  %t15 = load i1, ptr %l10, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t21, ptr %l14
  br label %bb11
bb10:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t22 = load i1, ptr %l14, !tbaa !21
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i1, ptr %l12, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = icmp sle i64 0, 1152921504606846975
  br i1 %t34, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb12:
  %t36 = mul i64 0, 8
  %t37 = insertvalue { i64, ptr } undef, i64 0, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fexplain_2ecaseWhole(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 3
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5177bd7d484351dd_5d0dbb04dc509331)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fexplain_2econtract(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l25 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca i64
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca i64
  %l60 = alloca i64
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = getelementptr i8, ptr %t14, i64 %t10
  call void @olang_textcopy(ptr %t15, ptr %t11, i64 %t12)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t14, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t6, { i64, ptr } %t24)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Sig", ptr %t27, i32 0, i32 5
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t36 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/load:Loader", ptr %t40, i32 0, i32 10
  %t46 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t42, i64 %a3)
  store ptr %t46, ptr %l25
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t49 = getelementptr %"compiler/load:Module", ptr %t47, i32 0, i32 6
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  br i1 %t54, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e7ca39a48e286d3f_b849249cb4ab4933)
  unreachable
bb10:
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/source:Source", ptr %t56, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l6, !tbaa !27
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Sig", ptr %t62, i32 0, i32 5
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_ec0929e0cef23b20_10aa079683981964)
  unreachable
bb13:
  br label %bb14
bb14:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Sig", ptr %t69, i32 0, i32 5
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t75 = getelementptr %"compiler/ast:ContractBlock", ptr %t72, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb17:
  br label %bb18
bb18:
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l46, !tbaa !27
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr ptr, ptr %t94, i64 %t91
  %t96 = load ptr, ptr %t95, !tbaa !39
  store ptr %t96, ptr %l10, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l49, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t99, ptr %l50, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t100, ptr %l51, !tbaa !27
  %t101 = load ptr, ptr %l10, !tbaa !29
  %t103 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v2, ptr %t101)
  store %"compiler/source:Span" %t103, ptr %l53
  br label %bb19
bb19:
  %t104 = getelementptr %"compiler/source:Span", ptr %l53, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = sext i32 %t105 to i64
  store i64 %t107, ptr %l55, !tbaa !24
  %t108 = load ptr, ptr %l10, !tbaa !29
  %t110 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v2, ptr %t108)
  store %"compiler/source:Span" %t110, ptr %l57
  br label %bb20
bb20:
  %t111 = getelementptr %"compiler/source:Span", ptr %l57, i32 0, i32 1
  %t112 = load i32, ptr %t111, !tbaa !23
  %t114 = sext i32 %t112 to i64
  store i64 %t114, ptr %l59, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l60, !tbaa !24
  %t117 = load i64, ptr %l55, !tbaa !24
  %t118 = icmp sge i64 %t117, 0
  br i1 %t118, label %bb21, label %bb22
bb21:
  %t120 = load i64, ptr %l55, !tbaa !24
  %t121 = load i64, ptr %l59, !tbaa !24
  %t122 = icmp sle i64 %t120, %t121
  br i1 %t122, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb23:
  %t124 = load i64, ptr %l59, !tbaa !24
  %t125 = load i64, ptr %l60, !tbaa !24
  %t126 = icmp sle i64 %t124, %t125
  br i1 %t126, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb25:
  %t128 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l55, !tbaa !24
  %t131 = load i64, ptr %l59, !tbaa !24
  %t132 = getelementptr i8, ptr %t129, i64 %t130
  %t133 = sub i64 %t131, %t130
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  %t136 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t143 = extractvalue { i64, ptr } %t135, 1
  %t144 = extractvalue { i64, ptr } %t135, 0
  %t145 = add i64 %t141, %t144
  %t146 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t137, i64 %t138)
  %t150 = getelementptr i8, ptr %t149, i64 %t138
  call void @olang_textcopy(ptr %t150, ptr %t139, i64 %t140)
  %t151 = getelementptr i8, ptr %t150, i64 %t140
  call void @olang_textcopy(ptr %t151, ptr %t143, i64 %t144)
  %t152 = getelementptr i8, ptr %t151, i64 %t144
  call void @olang_textcopy(ptr %t152, ptr %t146, i64 %t147)
  %t153 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t149, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = extractvalue { i64, ptr } %t154, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  %t162 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t162, { i64, ptr } %t161)
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t164 = load i64, ptr %l8, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l8, !tbaa !24
  br label %bb15
bb29:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:StructBody", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = icmp sle i64 0, 1152921504606846975
  br i1 %t28, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb12:
  %t30 = mul i64 0, 8
  %t31 = insertvalue { i64, ptr } undef, i64 0, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t32, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_979fe2e14fb6de05_5947910940c194f1)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l11, !tbaa !24
  %t16 = icmp sge i64 3, 0
  br i1 %t16, label %bb5, label %bb6
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 1
  %t21 = extractvalue { i64, ptr } %t18, 0
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t20, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l8, !tbaa !27
  br label %bb11
bb5:
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 3, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_559eb4fe50ed7f04_5fd8618740f13e0)
  unreachable
bb7:
  %t29 = load i64, ptr %l10, !tbaa !24
  %t30 = load i64, ptr %l11, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_559eb4fe50ed7f04_5fd8618740f13e0)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l10, !tbaa !24
  %t36 = getelementptr i8, ptr %t34, i64 3
  %t37 = sub i64 %t35, 3
  %t38 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  %t40 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t43 = extractvalue { i64, ptr } %t39, 1
  %t44 = extractvalue { i64, ptr } %t39, 0
  %t45 = add i64 %t41, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t40, i64 %t41)
  %t47 = getelementptr i8, ptr %t46, i64 %t41
  call void @olang_textcopy(ptr %t47, ptr %t43, i64 %t44)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t46, 1
  store { i64, ptr } %t49, ptr %l8, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_559eb4fe50ed7f04_5fd8618740f13e0)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2eeffectLine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i1
  %l18 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca ptr
  %l32 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l73 = alloca %"compiler/effects:Facts"
  %l74 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v1, ptr %t8, i64 %t9)
  store i1 %t12, ptr %l18
  br label %bb3
bb3:
  %t13 = load i1, ptr %l18, !tbaa !21
  store i1 %t13, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v1, ptr %v1, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l22
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l22, !tbaa !29
  store ptr %t23, ptr %l5, !tbaa !29
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l23
  br label %bb9
bb9:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l6
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  store ptr %l6, ptr %l28, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/load:Loader", ptr %t41, i32 0, i32 3
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l32, !tbaa !29
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  br i1 %t50, label %bb12, label %bb13
bb11:
  br label %bb17
bb12:
  call void @__olang_check_failed(ptr @olang_loc_98928cfde749f632_385db913ea7e7976)
  unreachable
bb13:
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t54 = getelementptr %"compiler/ast:Func", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Param", ptr %t55, i32 0, i32 1
  %t59 = load i32, ptr %t58, !tbaa !23
  %t60 = load ptr, ptr %l32, !tbaa !29
  %t62 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s2, ptr %t60, i32 %t59)
  store { i64, ptr } %t62, ptr %l40
  br label %bb15
bb15:
  %t63 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t64, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load ptr, ptr %l28, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t76, { i64, ptr } %t75)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t80 = getelementptr %"compiler/ast:Func", ptr %t78, i32 0, i32 3
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Sig", ptr %t81, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l9, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb20:
  br label %bb21
bb21:
  %t98 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t98, ptr %l52, !tbaa !27
  %t99 = load i64, ptr %l8, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr ptr, ptr %t102, i64 %t99
  %t104 = load ptr, ptr %t103, !tbaa !39
  store ptr %l6, ptr %l55, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/load:Loader", ptr %t112, i32 0, i32 3
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t118 = getelementptr %"compiler/ast:Param", ptr %t104, i32 0, i32 1
  %t119 = load i32, ptr %t118, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s5, ptr %t115, i32 %t119)
  store { i64, ptr } %t122, ptr %l62
  br label %bb22
bb22:
  %t123 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t124, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t136 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t136, { i64, ptr } %t135)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l8, !tbaa !24
  br label %bb18
bb25:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v1, ptr %v1, ptr %t142)
  store ptr %t144, ptr %l68
  br label %bb26
bb26:
  %t145 = load ptr, ptr %l68, !tbaa !29
  store ptr %a0, ptr %l69, !tbaa !29
  store { i64, ptr } %a4, ptr %l70, !tbaa !27
  %t149 = load i64, ptr %l3, !tbaa !24
  %t152 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v1, ptr %t145, i64 %t149)
  store %"compiler/effects:Facts" %t152, ptr %l73
  br label %bb27
bb27:
  store ptr %l73, ptr %l74, !tbaa !29
  %t154 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t154, ptr %l76
  br label %bb28
bb28:
  %t155 = load ptr, ptr %l74, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t157 = call { i64, ptr } @compiler_2feffects_2eDescribe(ptr %s0, ptr %s0, ptr %s0, ptr %t155, { i64, ptr } %t156)
  store { i64, ptr } %t157, ptr %l77
  br label %bb29
bb29:
  %t158 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t164 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = add i64 %t163, %t166
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t159, i64 %t160)
  %t172 = getelementptr i8, ptr %t171, i64 %t160
  call void @olang_textcopy(ptr %t172, ptr %t161, i64 %t162)
  %t173 = getelementptr i8, ptr %t172, i64 %t162
  call void @olang_textcopy(ptr %t173, ptr %t165, i64 %t166)
  %t174 = getelementptr i8, ptr %t173, i64 %t166
  call void @olang_textcopy(ptr %t174, ptr %t168, i64 %t169)
  %t175 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t171, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } %t176, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t184 = load ptr, ptr %l69, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t184, { i64, ptr } %t183)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb51
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l56, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = sub i64 %t96, 1
  store i64 %t98, ptr %l1, !tbaa !24
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = icmp eq i8 %t104, 63
  store i1 %t106, ptr %l63, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb34
bb34:
  %t108 = load i1, ptr %l63, !tbaa !21
  br i1 %t108, label %bb35, label %bb36
bb35:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t111 = icmp sgt i64 %t109, 0
  store i1 %t111, ptr %l66, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb37
bb37:
  %t113 = load i1, ptr %l66, !tbaa !21
  br i1 %t113, label %bb38, label %bb39
bb38:
  %t114 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t114, ptr %l70, !tbaa !27
  %t115 = load i64, ptr %l7, !tbaa !24
  %t117 = sub i64 %t115, 1
  %t119 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i8, ptr %t120, i64 %t117
  %t122 = load i8, ptr %t121, !tbaa !32
  %t124 = icmp eq i8 %t122, 32
  store i1 %t124, ptr %l69, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb40
bb40:
  %t126 = load i1, ptr %l69, !tbaa !21
  br i1 %t126, label %bb41, label %bb42
bb41:
  %t127 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t127, ptr %l75, !tbaa !27
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = sub i64 %t128, 1
  store i64 %t130, ptr %l77, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t131, 0
  store i64 %t134, ptr %l80, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l81, !tbaa !24
  %t137 = load i64, ptr %l77, !tbaa !24
  %t138 = icmp sge i64 %t137, 0
  br i1 %t138, label %bb43, label %bb44
bb42:
  br label %bb49
bb43:
  %t140 = load i64, ptr %l77, !tbaa !24
  %t141 = load i64, ptr %l80, !tbaa !24
  %t142 = icmp sle i64 %t140, %t141
  br i1 %t142, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb45:
  %t144 = load i64, ptr %l80, !tbaa !24
  %t145 = load i64, ptr %l81, !tbaa !24
  %t146 = icmp sle i64 %t144, %t145
  br i1 %t146, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb47:
  %t148 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = load i64, ptr %l77, !tbaa !24
  %t151 = load i64, ptr %l80, !tbaa !24
  %t152 = getelementptr i8, ptr %t149, i64 %t150
  %t153 = sub i64 %t151, %t150
  %t154 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t152, 1
  store { i64, ptr } %t155, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb49:
  br label %bb50
bb50:
  %t158 = load i64, ptr %l6, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l6, !tbaa !24
  br label %bb7
bb51:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l89, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t162, ptr %l90, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l91, !tbaa !24
  %t165 = load i64, ptr %l91, !tbaa !24
  %t166 = mul i64 %t165, 1
  %t167 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t166)
  %t168 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l92, !tbaa !27
  %t170 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = load i64, ptr %l91, !tbaa !24
  %t175 = mul i64 %t174, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t171, ptr %t173, i64 %t175, i1 false)
  %t176 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t176, ptr %l90, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t177, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2efields(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/typed:Local"
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l23 = alloca i64
  %l25 = alloca i64
  %l30 = alloca ptr
  %l41 = alloca i32
  %l45 = alloca i1
  %l50 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i1
  %l62 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l74 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca i64
  %l81 = alloca ptr
  %l91 = alloca i64
  %l95 = alloca i64
  %l98 = alloca i64
  %l117 = alloca ptr
  %l121 = alloca i32
  %l123 = alloca %"compiler/typed:Local"
  %l128 = alloca i32
  %l129 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l138 = alloca i64
  %l140 = alloca i64
  %l141 = alloca i64
  %l151 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l153 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l23, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l25
  br label %bb2
bb2:
  %t9 = load i64, ptr %l23, !tbaa !24
  %t10 = load i64, ptr %l25, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb69
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l30
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l30, !tbaa !29
  store ptr %t20, ptr %l5, !tbaa !29
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 1
  %t24 = load { i64, [2 x i64] }, ptr %t23
  store { i64, [2 x i64] } %t24, ptr %l6
  %t26 = load { i64, [2 x i64] }, ptr %l6
  %t28 = extractvalue { i64, [2 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 1
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t32 = getelementptr { i32, i32 }, ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l7, !tbaa !23
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t36 = getelementptr { i32, i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l8, !tbaa !23
  br label %bb9
bb8:
  br label %bb62
bb9:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l7, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l41
  br label %bb10
bb10:
  %t49 = load i32, ptr %l41, !range !{i32 0, i32 33}
  %t51 = trunc i64 18 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb15
bb12:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l7, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l50
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l2, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l55
  br label %bb14
bb14:
  %t76 = load i32, ptr %l50, !tbaa !23
  %t77 = load i32, ptr %l55, !tbaa !23
  %t78 = icmp ne i32 %t76, %t77
  store i1 %t78, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t80 = load i1, ptr %l45, !tbaa !21
  br i1 %t80, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb18
bb17:
  %t81 = load i32, ptr %l8, !tbaa !23
  %t83 = icmp ne i32 %t81, 0
  store i1 %t83, ptr %l57, !tbaa !21
  br label %bb18
bb18:
  %t85 = load i1, ptr %l57, !tbaa !21
  br i1 %t85, label %bb19, label %bb20
bb19:
  br label %bb68
bb20:
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  store ptr %t91, ptr %l62, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l2, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v1, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l67
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l62, !tbaa !29
  %t103 = load i32, ptr %l67, !tbaa !23
  %t104 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %v1, ptr %t102, i32 %t103)
  store { i64, ptr } %t104, ptr %l68
  br label %bb23
bb23:
  %t105 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t105, ptr %l9, !tbaa !27
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/load:Loader", ptr %t112, i32 0, i32 10
  store ptr %t114, ptr %l72, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  store ptr %t118, ptr %l74, !tbaa !29
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l2, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l79
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l74, !tbaa !29
  %t130 = load i32, ptr %l79, !tbaa !23
  %t131 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v1, ptr %t129, i32 %t130)
  store i64 %t131, ptr %l80
  br label %bb25
bb25:
  %t132 = load ptr, ptr %l72, !tbaa !29
  %t133 = load i64, ptr %l80, !tbaa !24
  %t134 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t132, i64 %t133)
  store ptr %t134, ptr %l81
  br label %bb26
bb26:
  %t135 = load ptr, ptr %l81, !tbaa !29
  %t137 = getelementptr %"compiler/load:Module", ptr %t135, i32 0, i32 6
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %l10, !tbaa !29
  %t140 = load ptr, ptr %l10, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_1ab09a44950d5518_36fac77ffd6769bc)
  unreachable
bb28:
  br label %bb29
bb29:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t147 = getelementptr %"compiler/source:Source", ptr %t144, i32 0, i32 1
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t150 = load ptr, ptr %l5, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Body", ptr %t150, i32 0, i32 10
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t152)
  store i64 %t154, ptr %l91
  br label %bb30
bb30:
  %t155 = load i64, ptr %l91, !tbaa !24
  store i64 %t155, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l12, !tbaa !24
  %t160 = icmp sgt i64 %t156, %t157
  br i1 %t160, label %bb31, label %bb32
bb31:
  %t162 = load i64, ptr %l14, !tbaa !24
  %t164 = icmp sgt i64 %t162, 0
  br i1 %t164, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb36
bb33:
  %t166 = load i64, ptr %l13, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = sub i64 %t166, %t167
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = add i64 %t170, %t171
  %t176 = sub i64 %t174, 1
  %t177 = load i64, ptr %l14, !tbaa !24
  %t180 = sdiv i64 %t176, %t177
  store i64 %t180, ptr %l98, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb35
bb35:
  %t182 = load i64, ptr %l98, !tbaa !24
  store i64 %t182, ptr %l95, !tbaa !24
  br label %bb36
bb36:
  %t183 = load i64, ptr %l95, !tbaa !24
  store i64 %t183, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb61
bb39:
  br label %bb40
bb40:
  %t192 = load i64, ptr %l12, !tbaa !24
  %t193 = load i64, ptr %l16, !tbaa !24
  %t194 = load i64, ptr %l14, !tbaa !24
  %t197 = mul i64 %t193, %t194
  %t200 = add i64 %t192, %t197
  store i64 %t200, ptr %l17, !tbaa !24
  %t202 = load ptr, ptr %l5, !tbaa !29
  %t204 = getelementptr %"compiler/typed:Body", ptr %t202, i32 0, i32 7
  store ptr %t204, ptr %l117, !tbaa !29
  %t205 = load ptr, ptr %l5, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Body", ptr %t205, i32 0, i32 10
  %t208 = load i64, ptr %l17, !tbaa !24
  %t211 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t207, i64 %t208)
  store i32 %t211, ptr %l121
  br label %bb41
bb41:
  %t212 = load i32, ptr %l121, !tbaa !23
  %t213 = sext i32 %t212 to i64
  %t214 = load ptr, ptr %l117, !tbaa !29
  %t216 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t214, i64 %t213)
  store %"compiler/typed:Local" %t216, ptr %l123
  br label %bb42
bb42:
  %t217 = load %"compiler/typed:Local", ptr %l123
  store %"compiler/typed:Local" %t217, ptr %l18
  %t218 = load i64, ptr %l17, !tbaa !24
  %t219 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t224 = icmp slt i64 %t218, %t221
  br i1 %t224, label %bb43, label %bb44
bb43:
  %t226 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t226, ptr %l129, !tbaa !27
  %t227 = load i64, ptr %l17, !tbaa !24
  %t229 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr i32, ptr %t230, i64 %t227
  %t232 = load i32, ptr %t231, !tbaa !33
  store i32 %t232, ptr %l128, !tbaa !23
  br label %bb45
bb44:
  %t234 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 2
  %t235 = load i32, ptr %t234, !tbaa !23
  store i32 %t235, ptr %l128, !tbaa !23
  br label %bb45
bb45:
  %t237 = load i32, ptr %l128, !tbaa !23
  store i32 %t237, ptr %l19, !tbaa !23
  %t238 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 0
  %t239 = load i32, ptr %t238, !tbaa !23
  %t241 = icmp eq i32 %t239, 0
  br i1 %t241, label %bb46, label %bb47
bb46:
  %t243 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t243, ptr %l136, !tbaa !27
  %t244 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t245 = getelementptr %"compiler/source:Span", ptr %t244, i32 0, i32 0
  %t246 = load i32, ptr %t245, !tbaa !23
  %t248 = sext i32 %t246 to i64
  store i64 %t248, ptr %l138, !tbaa !24
  %t249 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t250 = getelementptr %"compiler/source:Span", ptr %t249, i32 0, i32 1
  %t251 = load i32, ptr %t250, !tbaa !23
  %t253 = sext i32 %t251 to i64
  store i64 %t253, ptr %l140, !tbaa !24
  %t254 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  store i64 %t255, ptr %l141, !tbaa !24
  %t256 = load i64, ptr %l138, !tbaa !24
  %t257 = icmp sge i64 %t256, 0
  br i1 %t257, label %bb48, label %bb49
bb47:
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t259, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !29
  %t264 = getelementptr %"compiler/generic:Program", ptr %t262, i32 0, i32 0
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = getelementptr %"compiler/load:Loader", ptr %t265, i32 0, i32 3
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 0
  %t270 = load i32, ptr %t269, !tbaa !23
  %t273 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s6, ptr %t268, i32 %t270)
  store { i64, ptr } %t273, ptr %l151
  br label %bb54
bb48:
  %t274 = load i64, ptr %l138, !tbaa !24
  %t275 = load i64, ptr %l140, !tbaa !24
  %t276 = icmp sle i64 %t274, %t275
  br i1 %t276, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021)
  unreachable
bb50:
  %t278 = load i64, ptr %l140, !tbaa !24
  %t279 = load i64, ptr %l141, !tbaa !24
  %t280 = icmp sle i64 %t278, %t279
  br i1 %t280, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021)
  unreachable
bb52:
  %t282 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = load i64, ptr %l138, !tbaa !24
  %t285 = load i64, ptr %l140, !tbaa !24
  %t286 = getelementptr i8, ptr %t283, i64 %t284
  %t287 = sub i64 %t285, %t284
  %t288 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t286, 1
  store { i64, ptr } %t289, ptr %l135, !tbaa !27
  br label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021)
  unreachable
bb54:
  %t291 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t291, ptr %l135, !tbaa !27
  br label %bb55
bb55:
  %t292 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t292, ptr %l20, !tbaa !27
  store ptr %a0, ptr %l152, !tbaa !29
  %t294 = load ptr, ptr %l1, !tbaa !29
  store ptr %t294, ptr %l153, !tbaa !29
  %t295 = load ptr, ptr %l1, !tbaa !29
  %t297 = getelementptr %"compiler/check:Checker", ptr %t295, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t299 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t300 = load i32, ptr %l2, !tbaa !23
  %t301 = load i64, ptr %l17, !tbaa !24
  %t306 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v1, ptr %t298, i64 %t299, i32 %t300, i64 0, i64 %t301)
  store i32 %t306, ptr %l159
  br label %bb56
bb56:
  %t307 = load ptr, ptr %l153, !tbaa !29
  %t308 = load i32, ptr %l159, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2fexplain_2eattrsBefore(ptr %v1, ptr %s6, ptr %t307, i32 %t308)
  store { i64, ptr } %t309, ptr %l160
  br label %bb57
bb57:
  %t310 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t310, ptr %l161, !tbaa !27
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t312 = load i32, ptr %l19, !tbaa !23
  %t315 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s6, ptr %t311, i32 %t312)
  store { i64, ptr } %t315, ptr %l164
  br label %bb58
bb58:
  %t316 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t318 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 1
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t321 = add i64 %t317, %t320
  %t322 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 1
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t325 = add i64 %t321, %t324
  %t326 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t327 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t328 = add i64 %t325, %t327
  %t329 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = add i64 %t328, %t331
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t334 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t335 = add i64 %t332, %t334
  %t336 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t335)
  call void @olang_textcopy(ptr %t336, ptr %t316, i64 %t317)
  %t337 = getelementptr i8, ptr %t336, i64 %t317
  call void @olang_textcopy(ptr %t337, ptr %t319, i64 %t320)
  %t338 = getelementptr i8, ptr %t337, i64 %t320
  call void @olang_textcopy(ptr %t338, ptr %t323, i64 %t324)
  %t339 = getelementptr i8, ptr %t338, i64 %t324
  call void @olang_textcopy(ptr %t339, ptr %t326, i64 %t327)
  %t340 = getelementptr i8, ptr %t339, i64 %t327
  call void @olang_textcopy(ptr %t340, ptr %t330, i64 %t331)
  %t341 = getelementptr i8, ptr %t340, i64 %t331
  call void @olang_textcopy(ptr %t341, ptr %t333, i64 %t334)
  %t342 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t336, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = extractvalue { i64, ptr } %t343, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  %t351 = load ptr, ptr %l152, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t351, { i64, ptr } %t350)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb60:
  %t353 = load i64, ptr %l16, !tbaa !24
  %t355 = add i64 %t353, 1
  store i64 %t355, ptr %l16, !tbaa !24
  br label %bb37
bb61:
  br label %ret
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_b65b7d917c440185_24d12a03c9296209)
  unreachable
bb67:
  br label %bb68
bb68:
  %t357 = load i64, ptr %l4, !tbaa !24
  %t359 = add i64 %t357, 1
  store i64 %t359, ptr %l4, !tbaa !24
  br label %bb1
bb69:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fexplain_2efirstClose(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t2, 0
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = icmp sge i64 3, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sle i64 3, %t10
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sle i64 %t13, %t14
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb5:
  %t17 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr i8, ptr %t18, i64 3
  %t21 = sub i64 %t19, 3
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = call i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %t23)
  store i64 %t25, ptr %l10
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb7:
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = add i64 3, %t26
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEnd(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb42
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l56, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = sub i64 %t96, 1
  store i64 %t98, ptr %l1, !tbaa !24
  br label %bb41
bb30:
  br label %bb31
bb31:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = icmp eq i8 %t104, 44
  br i1 %t106, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb37
bb34:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb36
bb35:
  %t108 = load i8, ptr %l8, !tbaa !22
  %t110 = icmp eq i8 %t108, 41
  store i1 %t110, ptr %l66, !tbaa !21
  br label %bb36
bb36:
  %t112 = load i1, ptr %l66, !tbaa !21
  store i1 %t112, ptr %l63, !tbaa !21
  br label %bb37
bb37:
  %t113 = load i1, ptr %l63, !tbaa !21
  br i1 %t113, label %bb38, label %bb39
bb38:
  %t114 = load i64, ptr %l7, !tbaa !24
  store i64 %t114, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l6, !tbaa !24
  br label %bb7
bb42:
  %t120 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  store i64 %t122, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb28, label %bb29
bb27:
  br label %bb31
bb28:
  %t95 = load i64, ptr %l7, !tbaa !24
  store i64 %t95, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t97 = load i64, ptr %l1, !tbaa !24
  %t99 = sub i64 %t97, 1
  store i64 %t99, ptr %l1, !tbaa !24
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l6, !tbaa !24
  br label %bb7
bb33:
  %t105 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i64
  %l30 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i64
  %l53 = alloca i32
  %l55 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca i64
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l103 = alloca ptr
  %l105 = alloca ptr
  %l109 = alloca i64
  %l112 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l139 = alloca i64
  %l143 = alloca i64
  %l146 = alloca i64
  %l167 = alloca i64
  %l172 = alloca i64
  %l175 = alloca ptr
  %l179 = alloca i32
  %l185 = alloca i32
  %l186 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l194 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l218 = alloca { i64, ptr }
  %l219 = alloca i64
  %l220 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l20
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  store ptr %l3, ptr %l21, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l22, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t7, i64 %t8)
  store i64 %t11, ptr %l26
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l30
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l30, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 8
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t24 = load ptr, ptr %l21, !tbaa !29
  %t25 = load ptr, ptr %l22, !tbaa !29
  %t26 = load i64, ptr %l26, !tbaa !24
  call void @compiler_2fexplain_2eattrLines(ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t24, ptr %t25, i64 %t26, { i64, ptr } %t23, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb4
bb4:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t28)
  store i64 %t30, ptr %l34
  br label %bb5
bb5:
  %t31 = load i64, ptr %l34, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t35, i64 %t31)
  store i64 %t39, ptr %l38
  br label %bb6
bb6:
  %t40 = load i64, ptr %l38, !tbaa !24
  %t41 = icmp eq i64 %t40, 0
  br i1 %t41, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i64, ptr %l2, !tbaa !24
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t46, i64 %t47, i32 0)
  store i64 %t50, ptr %l43
  br label %bb9
bb8:
  br label %bb21
bb9:
  %t51 = load i64, ptr %l43, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l46
  br label %bb10
bb10:
  %t57 = load i64, ptr %l46, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  store ptr %l3, ptr %l47, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l48, !tbaa !29
  %t59 = load i64, ptr %l2, !tbaa !24
  store i64 %t59, ptr %l49, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t63, i64 %t64)
  store i32 %t67, ptr %l53
  br label %bb11
bb11:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t69 = load ptr, ptr %l48, !tbaa !29
  %t70 = load i64, ptr %l49, !tbaa !24
  %t71 = load i32, ptr %l53, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s1, ptr %t69, i64 %t70, i32 %t71, i64 %t68)
  store { i64, ptr } %t73, ptr %l55
  br label %bb12
bb12:
  %t74 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t75, i64 %t76)
  %t81 = getelementptr i8, ptr %t80, i64 %t76
  call void @olang_textcopy(ptr %t81, ptr %t77, i64 %t78)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t91, { i64, ptr } %t90)
  br label %bb13
bb13:
  store ptr %l3, ptr %l58, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l59, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t98 = load i64, ptr %l2, !tbaa !24
  %t101 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t97, i64 %t98)
  store ptr %t101, ptr %l63
  br label %bb14
bb14:
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Func", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  store ptr %t105, ptr %l65, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l2, !tbaa !24
  %t113 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t109, i64 %t110)
  store i64 %t113, ptr %l69
  br label %bb15
bb15:
  %t114 = load ptr, ptr %l58, !tbaa !29
  %t115 = load ptr, ptr %l59, !tbaa !29
  %t116 = load ptr, ptr %l65, !tbaa !29
  %t117 = load i64, ptr %l69, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s1, ptr %t114, ptr %t115, ptr %t116, i64 %t117, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb16
bb16:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t120 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s1, ptr %l3, ptr %t118, ptr %t119, i64 %t120, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb17
bb17:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t127 = load i64, ptr %l2, !tbaa !24
  %t128 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2enoValue(ptr %s0, ptr %v0, ptr %v1, ptr %s1, ptr %l3, ptr %t125, ptr %t126, i64 %t127, i64 %t128, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb18
bb18:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l2, !tbaa !24
  %t136 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2eeffectLine(ptr %s0, ptr %v0, ptr %s1, ptr %l3, ptr %t134, i64 %t135, i64 %t136, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb19
bb19:
  %t142 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t142, ptr %l84
  br label %bb20
bb20:
  %t143 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t143, ptr %l85, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l86, !tbaa !24
  %t146 = load i64, ptr %l86, !tbaa !24
  %t147 = mul i64 %t146, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t147)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l87, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l86, !tbaa !24
  %t156 = mul i64 %t155, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t152, ptr %t154, i64 %t156, i1 false)
  %t157 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t157, ptr %l85, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t158 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t158, ptr %rv
  br label %ret
bb21:
  store ptr %l3, ptr %l88, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l89, !tbaa !29
  %t160 = load i64, ptr %l2, !tbaa !24
  store i64 %t160, ptr %l90, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t165 = load i64, ptr %l2, !tbaa !24
  %t168 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t164, i64 %t165)
  store i32 %t168, ptr %l94
  br label %bb22
bb22:
  %t169 = load ptr, ptr %l89, !tbaa !29
  %t170 = load i64, ptr %l90, !tbaa !24
  %t171 = load i32, ptr %l94, !tbaa !23
  %t172 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s0, ptr %t169, i64 %t170, i32 %t171, i64 -1)
  store { i64, ptr } %t172, ptr %l95
  br label %bb23
bb23:
  %t173 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t178 = add i64 %t175, %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t174, i64 %t175)
  %t180 = getelementptr i8, ptr %t179, i64 %t175
  call void @olang_textcopy(ptr %t180, ptr %t176, i64 %t177)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t179, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = extractvalue { i64, ptr } %t182, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  %t190 = load ptr, ptr %l88, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t190, { i64, ptr } %t189)
  br label %bb24
bb24:
  store ptr %l3, ptr %l98, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l99, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t197 = load i64, ptr %l2, !tbaa !24
  %t200 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t196, i64 %t197)
  store ptr %t200, ptr %l103
  br label %bb25
bb25:
  %t201 = load ptr, ptr %l103, !tbaa !29
  %t203 = getelementptr %"compiler/ast:Func", ptr %t201, i32 0, i32 3
  %t204 = load ptr, ptr %t203, !tbaa !29
  store ptr %t204, ptr %l105, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t209 = load i64, ptr %l2, !tbaa !24
  %t212 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t208, i64 %t209)
  store i64 %t212, ptr %l109
  br label %bb26
bb26:
  %t213 = load ptr, ptr %l98, !tbaa !29
  %t214 = load ptr, ptr %l99, !tbaa !29
  %t215 = load ptr, ptr %l105, !tbaa !29
  %t216 = load i64, ptr %l109, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t213, ptr %t214, ptr %t215, i64 %t216, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i64, ptr %l2, !tbaa !24
  %t221 = call { i64, ptr } @compiler_2fneeds_2eLines(ptr %v0, ptr %s4, ptr %t217, i64 %t218)
  store { i64, ptr } %t221, ptr %l112
  br label %bb28
bb28:
  %t222 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = mul i64 %t223, 16
  %t226 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  store { i64, ptr } %t228, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t230 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  store i64 %t232, ptr %l9, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t234 = load i64, ptr %l8, !tbaa !24
  %t235 = load i64, ptr %l9, !tbaa !24
  %t238 = icmp slt i64 %t234, %t235
  %t240 = xor i1 %t238, true
  br i1 %t240, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t242 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t242, ptr %l120, !tbaa !27
  %t243 = load i64, ptr %l8, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr { i64, ptr }, ptr %t246, i64 %t243
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !37
  %t251 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t252 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t254 = extractvalue { i64, ptr } %t248, 1
  %t255 = extractvalue { i64, ptr } %t248, 0
  %t256 = add i64 %t252, %t255
  %t257 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t259 = add i64 %t256, %t258
  %t260 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t259)
  call void @olang_textcopy(ptr %t260, ptr %t251, i64 %t252)
  %t261 = getelementptr i8, ptr %t260, i64 %t252
  call void @olang_textcopy(ptr %t261, ptr %t254, i64 %t255)
  %t262 = getelementptr i8, ptr %t261, i64 %t255
  call void @olang_textcopy(ptr %t262, ptr %t257, i64 %t258)
  %t263 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t260, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = extractvalue { i64, ptr } %t264, 1
  %t268 = mul i64 %t266, 1
  %t269 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t268)
  call void @llvm.memcpy.p0.p0.i64(ptr %t269, ptr %t267, i64 %t268, i1 false)
  %t270 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l3, { i64, ptr } %t271)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  %t274 = load i64, ptr %l8, !tbaa !24
  %t276 = add i64 %t274, 1
  store i64 %t276, ptr %l8, !tbaa !24
  br label %bb29
bb35:
  call void @__olang_scope_close(ptr %s4)
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l1, !tbaa !29
  %t280 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fexplain_2enoValue(ptr %s0, ptr %v0, ptr %v1, ptr %s0, ptr %l3, ptr %t278, ptr %t279, i64 %t280, i64 -1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb36
bb36:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t289 = load i64, ptr %l2, !tbaa !24
  %t292 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t288, i64 %t289)
  store ptr %t292, ptr %l136
  br label %bb37
bb37:
  %t293 = load ptr, ptr %l136, !tbaa !29
  store ptr %t293, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/check:Checker", ptr %t294, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %t297)
  store i64 %t299, ptr %l139
  br label %bb38
bb38:
  %t300 = load i64, ptr %l139, !tbaa !24
  store i64 %t300, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t301 = load i64, ptr %l13, !tbaa !24
  %t302 = load i64, ptr %l12, !tbaa !24
  %t305 = icmp sgt i64 %t301, %t302
  br i1 %t305, label %bb39, label %bb40
bb39:
  %t307 = load i64, ptr %l14, !tbaa !24
  %t309 = icmp sgt i64 %t307, 0
  br i1 %t309, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb44
bb41:
  %t311 = load i64, ptr %l13, !tbaa !24
  %t312 = load i64, ptr %l12, !tbaa !24
  %t315 = sub i64 %t311, %t312
  %t316 = load i64, ptr %l14, !tbaa !24
  %t319 = add i64 %t315, %t316
  %t321 = sub i64 %t319, 1
  %t322 = load i64, ptr %l14, !tbaa !24
  %t325 = sdiv i64 %t321, %t322
  store i64 %t325, ptr %l146, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb43
bb43:
  %t327 = load i64, ptr %l146, !tbaa !24
  store i64 %t327, ptr %l143, !tbaa !24
  br label %bb44
bb44:
  %t328 = load i64, ptr %l143, !tbaa !24
  store i64 %t328, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t329 = load i64, ptr %l16, !tbaa !24
  %t330 = load i64, ptr %l15, !tbaa !24
  %t333 = icmp slt i64 %t329, %t330
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb67
bb47:
  br label %bb48
bb48:
  %t337 = load i64, ptr %l12, !tbaa !24
  %t338 = load i64, ptr %l16, !tbaa !24
  %t339 = load i64, ptr %l14, !tbaa !24
  %t342 = mul i64 %t338, %t339
  %t345 = add i64 %t337, %t342
  store i64 %t345, ptr %l17, !tbaa !24
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/check:Checker", ptr %t347, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !29
  %t351 = load i64, ptr %l17, !tbaa !24
  %t354 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t350, i64 %t351)
  store i64 %t354, ptr %l167
  br label %bb49
bb49:
  %t355 = load i64, ptr %l2, !tbaa !24
  %t356 = load i64, ptr %l167, !tbaa !24
  %t358 = icmp ne i64 %t356, %t355
  br i1 %t358, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb51:
  br label %bb52
bb52:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load i64, ptr %l17, !tbaa !24
  %t364 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t360, i64 %t361)
  store i64 %t364, ptr %l172
  br label %bb53
bb53:
  %t365 = load i64, ptr %l172, !tbaa !24
  store i64 %t365, ptr %l18, !tbaa !24
  %t366 = load i64, ptr %l18, !tbaa !24
  %t368 = icmp slt i64 %t366, 0
  br i1 %t368, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb55:
  br label %bb56
bb56:
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l175, !tbaa !29
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/check:Checker", ptr %t371, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t375 = load i64, ptr %l17, !tbaa !24
  %t378 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t374, i64 %t375)
  store i32 %t378, ptr %l179
  br label %bb57
bb57:
  %t379 = load ptr, ptr %l11, !tbaa !29
  %t381 = getelementptr %"compiler/ast:Func", ptr %t379, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !29
  %t383 = load ptr, ptr %l11, !tbaa !29
  %t385 = getelementptr %"compiler/ast:Func", ptr %t383, i32 0, i32 3
  %t386 = load ptr, ptr %t385, !tbaa !29
  %t388 = getelementptr %"compiler/ast:Sig", ptr %t386, i32 0, i32 0
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  %t390 = load ptr, ptr %l175, !tbaa !29
  %t391 = load i32, ptr %l179, !tbaa !23
  %t394 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t390, i32 %t391, ptr %t382, { i64, ptr } %t389)
  store i32 %t394, ptr %l185
  br label %bb58
bb58:
  %t395 = load i32, ptr %l185, !tbaa !23
  store i32 %t395, ptr %l19, !tbaa !23
  store ptr %l3, ptr %l186, !tbaa !29
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/check:Checker", ptr %t396, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !29
  %t401 = getelementptr %"compiler/generic:Program", ptr %t399, i32 0, i32 0
  %t402 = load ptr, ptr %t401, !tbaa !29
  %t404 = getelementptr %"compiler/load:Loader", ptr %t402, i32 0, i32 3
  %t405 = load ptr, ptr %t404, !tbaa !29
  %t406 = load ptr, ptr %l11, !tbaa !29
  %t408 = getelementptr %"compiler/ast:Func", ptr %t406, i32 0, i32 2
  %t409 = load i32, ptr %t408, !tbaa !23
  %t412 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s9, ptr %t405, i32 %t409)
  store { i64, ptr } %t412, ptr %l193
  br label %bb59
bb59:
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l194, !tbaa !29
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = getelementptr %"compiler/check:Checker", ptr %t414, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !29
  %t418 = load i64, ptr %l17, !tbaa !24
  %t421 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t417, i64 %t418)
  store i32 %t421, ptr %l198
  br label %bb60
bb60:
  %t422 = load ptr, ptr %l194, !tbaa !29
  %t423 = load i32, ptr %l198, !tbaa !23
  %t424 = call { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %s9, ptr %t422, i32 %t423)
  store { i64, ptr } %t424, ptr %l199
  br label %bb61
bb61:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = load i32, ptr %l19, !tbaa !23
  %t427 = load i64, ptr %l18, !tbaa !24
  %t431 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s9, ptr %t425, i32 %t426, i64 %t427)
  store { i64, ptr } %t431, ptr %l203
  br label %bb62
bb62:
  %t432 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t433 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t434 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t434, 1
  %t436 = extractvalue { i64, ptr } %t434, 0
  %t437 = add i64 %t433, %t436
  %t438 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t439 = extractvalue { i64, ptr } %t438, 1
  %t440 = extractvalue { i64, ptr } %t438, 0
  %t441 = add i64 %t437, %t440
  %t442 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t443 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t444 = add i64 %t441, %t443
  %t445 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t445, 1
  %t447 = extractvalue { i64, ptr } %t445, 0
  %t448 = add i64 %t444, %t447
  %t449 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t450 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t451 = add i64 %t448, %t450
  %t452 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t451)
  call void @olang_textcopy(ptr %t452, ptr %t432, i64 %t433)
  %t453 = getelementptr i8, ptr %t452, i64 %t433
  call void @olang_textcopy(ptr %t453, ptr %t435, i64 %t436)
  %t454 = getelementptr i8, ptr %t453, i64 %t436
  call void @olang_textcopy(ptr %t454, ptr %t439, i64 %t440)
  %t455 = getelementptr i8, ptr %t454, i64 %t440
  call void @olang_textcopy(ptr %t455, ptr %t442, i64 %t443)
  %t456 = getelementptr i8, ptr %t455, i64 %t443
  call void @olang_textcopy(ptr %t456, ptr %t446, i64 %t447)
  %t457 = getelementptr i8, ptr %t456, i64 %t447
  call void @olang_textcopy(ptr %t457, ptr %t449, i64 %t450)
  %t458 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t452, 1
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t462 = extractvalue { i64, ptr } %t459, 1
  %t463 = mul i64 %t461, 1
  %t464 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t463)
  call void @llvm.memcpy.p0.p0.i64(ptr %t464, ptr %t462, i64 %t463, i1 false)
  %t465 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t466 = insertvalue { i64, ptr } %t465, ptr %t464, 1
  %t467 = load ptr, ptr %l186, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t467, { i64, ptr } %t466)
  br label %bb63
bb63:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load ptr, ptr %l1, !tbaa !29
  %t471 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s9, ptr %l3, ptr %t469, ptr %t470, i64 %t471, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb64
bb64:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load i64, ptr %l2, !tbaa !24
  %t478 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fexplain_2eeffectLine(ptr %s0, ptr %v0, ptr %s9, ptr %l3, ptr %t476, i64 %t477, i64 %t478, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d47, i32 0, i32 1) })
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb66:
  %t483 = load i64, ptr %l16, !tbaa !24
  %t485 = add i64 %t483, 1
  store i64 %t485, ptr %l16, !tbaa !24
  br label %bb45
bb67:
  %t488 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t488, ptr %l217
  br label %bb68
bb68:
  %t489 = load { i64, ptr }, ptr %l217, !tbaa !27
  store { i64, ptr } %t489, ptr %l218, !tbaa !27
  %t490 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t491 = extractvalue { i64, ptr } %t490, 0
  store i64 %t491, ptr %l219, !tbaa !24
  %t492 = load i64, ptr %l219, !tbaa !24
  %t493 = mul i64 %t492, 1
  %t494 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t493)
  %t495 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t496 = insertvalue { i64, ptr } %t495, ptr %t494, 1
  store { i64, ptr } %t496, ptr %l220, !tbaa !27
  %t497 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !27
  %t499 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t500 = load ptr, ptr %t499, !tbaa !27
  %t501 = load i64, ptr %l219, !tbaa !24
  %t502 = mul i64 %t501, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t498, ptr %t500, i64 %t502, i1 false)
  %t503 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t503, ptr %l218, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t504 = load { i64, ptr }, ptr %l218, !tbaa !27
  store { i64, ptr } %t504, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i8
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l37 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l51 = alloca i32
  %l53 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l75 = alloca i64
  %l76 = alloca i64
  %l80 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i64
  %l89 = alloca { i64, ptr }
  %l91 = alloca i64
  %l95 = alloca i1
  %l96 = alloca i1
  %l98 = alloca i1
  %l100 = alloca i64
  %l101 = alloca i64
  %l114 = alloca i64
  %l117 = alloca i64
  %l135 = alloca { i64, ptr }
  %l140 = alloca i1
  %l147 = alloca i1
  %l150 = alloca i1
  %l157 = alloca i1
  %l160 = alloca i1
  %l163 = alloca i1
  %l166 = alloca i1
  %l172 = alloca i1
  %l173 = alloca { i64, ptr }
  %l185 = alloca i64
  %l186 = alloca i64
  %l190 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l192 = alloca i64
  %l193 = alloca i64
  %l197 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l199 = alloca i64
  %l202 = alloca i64
  %l203 = alloca i64
  %l209 = alloca { i64, ptr }
  %l211 = alloca i64
  %l216 = alloca i1
  %l217 = alloca { i64, ptr }
  %l219 = alloca i64
  %l220 = alloca ptr
  %l221 = alloca i64
  %l222 = alloca i64
  %l226 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l233 = alloca i64
  %l238 = alloca i64
  %l239 = alloca { i64, ptr }
  %l240 = alloca i64
  %l242 = alloca i64
  %l243 = alloca i64
  %l257 = alloca i64
  %l258 = alloca i64
  %l259 = alloca i64
  %l267 = alloca { i64, ptr }
  %l269 = alloca i64
  %l271 = alloca i64
  %l272 = alloca i64
  %l277 = alloca i64
  %l279 = alloca i64
  %l280 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l27
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l27, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t19, i32 %t23)
  store { i64, ptr } %t26, ptr %l34
  br label %bb2
bb2:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l35, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t28)
  store i64 %t30, ptr %l37
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l40
  br label %bb4
bb4:
  %t36 = load ptr, ptr %l35, !tbaa !29
  %t37 = load i64, ptr %l37, !tbaa !24
  %t38 = load i64, ptr %l40, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t36, i64 %t37, i64 %t38)
  store { i64, ptr } %t39, ptr %l41
  br label %bb5
bb5:
  %t40 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = add i64 %t42, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t41, i64 %t42)
  %t48 = getelementptr i8, ptr %t47, i64 %t42
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l43, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Func", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Sig", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t70 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t53, i32 %t54, ptr %t58, { i64, ptr } %t65)
  store i32 %t70, ptr %l51
  br label %bb6
bb6:
  %t72 = load ptr, ptr %l43, !tbaa !29
  %t73 = load i32, ptr %l51, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s0, ptr %t72, i32 %t73, i64 %a3)
  store { i64, ptr } %t75, ptr %l53
  br label %bb7
bb7:
  %t76 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t76, ptr %l6, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i64, ptr %l1, !tbaa !24
  %t84 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t80, i64 %t81)
  store i1 %t84, ptr %l57
  br label %bb8
bb8:
  %t85 = load i1, ptr %l57, !tbaa !21
  br i1 %t85, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l58, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l2, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l63
  br label %bb11
bb10:
  br label %bb116
bb11:
  %t97 = load ptr, ptr %l58, !tbaa !29
  %t98 = load i32, ptr %l63, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s2, ptr %t97, i32 %t98)
  store { i64, ptr } %t99, ptr %l64
  br label %bb12
bb12:
  %t100 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t100, ptr %l7, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t105 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t101, { i64, ptr } %t102)
  store i1 %t105, ptr %l67
  br label %bb13
bb13:
  %t106 = load i1, ptr %l67, !tbaa !21
  br i1 %t106, label %bb14, label %bb15
bb14:
  %t107 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t109 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s2, { i64, ptr } %t107, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t109, ptr %l70
  br label %bb16
bb15:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb17
bb16:
  %t110 = load i1, ptr %l70, !tbaa !21
  store i1 %t110, ptr %l68, !tbaa !21
  br label %bb17
bb17:
  %t111 = load i1, ptr %l68, !tbaa !21
  br i1 %t111, label %bb18, label %bb19
bb18:
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t120 = sub i64 %t114, %t117
  store i64 %t120, ptr %l75, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l76, !tbaa !24
  %t123 = icmp sge i64 0, 0
  br i1 %t123, label %bb20, label %bb21
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t125, { i64, ptr } %t126)
  store i1 %t129, ptr %l95
  br label %bb35
bb20:
  %t130 = load i64, ptr %l75, !tbaa !24
  %t131 = icmp sle i64 0, %t130
  br i1 %t131, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb22:
  %t133 = load i64, ptr %l75, !tbaa !24
  %t134 = load i64, ptr %l76, !tbaa !24
  %t135 = icmp sle i64 %t133, %t134
  br i1 %t135, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb24:
  %t137 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = load i64, ptr %l75, !tbaa !24
  %t140 = getelementptr i8, ptr %t138, i64 0
  %t141 = sub i64 %t139, 0
  %t142 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t140, 1
  store { i64, ptr } %t143, ptr %l80, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 0
  store i64 %t146, ptr %l82, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l83, !tbaa !24
  %t149 = icmp sge i64 9, 0
  br i1 %t149, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb26:
  %t151 = load i64, ptr %l82, !tbaa !24
  %t152 = icmp sle i64 9, %t151
  br i1 %t152, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb28:
  %t154 = load i64, ptr %l82, !tbaa !24
  %t155 = load i64, ptr %l83, !tbaa !24
  %t156 = icmp sle i64 %t154, %t155
  br i1 %t156, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb30:
  %t158 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = load i64, ptr %l82, !tbaa !24
  %t161 = getelementptr i8, ptr %t159, i64 9
  %t162 = sub i64 %t160, 9
  %t163 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t161, 1
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t170 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t171 = add i64 %t168, %t170
  %t173 = extractvalue { i64, ptr } %t164, 1
  %t174 = extractvalue { i64, ptr } %t164, 0
  %t175 = add i64 %t171, %t174
  %t176 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t178 = add i64 %t175, %t177
  %t180 = extractvalue { i64, ptr } %t165, 1
  %t181 = extractvalue { i64, ptr } %t165, 0
  %t182 = add i64 %t178, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t167, i64 %t168)
  %t184 = getelementptr i8, ptr %t183, i64 %t168
  call void @olang_textcopy(ptr %t184, ptr %t169, i64 %t170)
  %t185 = getelementptr i8, ptr %t184, i64 %t170
  call void @olang_textcopy(ptr %t185, ptr %t173, i64 %t174)
  %t186 = getelementptr i8, ptr %t185, i64 %t174
  call void @olang_textcopy(ptr %t186, ptr %t176, i64 %t177)
  %t187 = getelementptr i8, ptr %t186, i64 %t177
  call void @olang_textcopy(ptr %t187, ptr %t180, i64 %t181)
  %t188 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t183, 1
  store { i64, ptr } %t189, ptr %l89, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t192 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l91, !tbaa !24
  %t195 = load i64, ptr %l91, !tbaa !24
  %t196 = icmp eq i64 %t191, %t195
  br i1 %t196, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb32:
  %t198 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l91, !tbaa !24
  %t203 = mul i64 %t202, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t199, ptr %t201, i64 %t203, i1 false)
  br label %bb34
bb33:
  %t204 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t204, ptr %l6, !tbaa !27
  br label %bb34
bb34:
  br label %bb115
bb35:
  %t205 = load i1, ptr %l95, !tbaa !21
  br i1 %t205, label %bb36, label %bb37
bb36:
  %t206 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t208 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s5, { i64, ptr } %t206, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t208, ptr %l98
  br label %bb38
bb37:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb39
bb38:
  %t209 = load i1, ptr %l98, !tbaa !21
  store i1 %t209, ptr %l96, !tbaa !21
  br label %bb39
bb39:
  %t210 = load i1, ptr %l96, !tbaa !21
  br i1 %t210, label %bb40, label %bb41
bb40:
  %t211 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  store i64 %t213, ptr %l100, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 0
  store i64 %t215, ptr %l101, !tbaa !24
  %t216 = icmp sge i64 13, 0
  br i1 %t216, label %bb42, label %bb43
bb41:
  br label %bb114
bb42:
  %t218 = load i64, ptr %l100, !tbaa !24
  %t219 = icmp sle i64 13, %t218
  br i1 %t219, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb44:
  %t221 = load i64, ptr %l100, !tbaa !24
  %t222 = load i64, ptr %l101, !tbaa !24
  %t223 = icmp sle i64 %t221, %t222
  br i1 %t223, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb46:
  %t225 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = load i64, ptr %l100, !tbaa !24
  %t228 = getelementptr i8, ptr %t226, i64 13
  %t229 = sub i64 %t227, 13
  %t230 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t228, 1
  store { i64, ptr } %t231, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t233 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t237 = sub i64 %t235, 1
  store i64 %t237, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  store i64 %t241, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t243 = load i64, ptr %l12, !tbaa !24
  %t244 = load i64, ptr %l11, !tbaa !24
  %t247 = icmp sgt i64 %t243, %t244
  br i1 %t247, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb48:
  %t249 = load i64, ptr %l13, !tbaa !24
  %t251 = icmp sgt i64 %t249, 0
  br i1 %t251, label %bb50, label %bb51
bb49:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb53
bb50:
  %t253 = load i64, ptr %l12, !tbaa !24
  %t254 = load i64, ptr %l11, !tbaa !24
  %t257 = sub i64 %t253, %t254
  %t258 = load i64, ptr %l13, !tbaa !24
  %t261 = add i64 %t257, %t258
  %t263 = sub i64 %t261, 1
  %t264 = load i64, ptr %l13, !tbaa !24
  %t267 = sdiv i64 %t263, %t264
  store i64 %t267, ptr %l117, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb52
bb52:
  %t269 = load i64, ptr %l117, !tbaa !24
  store i64 %t269, ptr %l114, !tbaa !24
  br label %bb53
bb53:
  %t270 = load i64, ptr %l114, !tbaa !24
  store i64 %t270, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb54
bb54:
  %t271 = load i64, ptr %l15, !tbaa !24
  %t272 = load i64, ptr %l14, !tbaa !24
  %t275 = icmp slt i64 %t271, %t272
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb55, label %bb56
bb55:
  br label %bb92
bb56:
  br label %bb57
bb57:
  %t279 = load i64, ptr %l11, !tbaa !24
  %t280 = load i64, ptr %l15, !tbaa !24
  %t281 = load i64, ptr %l13, !tbaa !24
  %t284 = mul i64 %t280, %t281
  %t287 = add i64 %t279, %t284
  store i64 %t287, ptr %l16, !tbaa !24
  %t289 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t289, ptr %l135, !tbaa !27
  %t290 = load i64, ptr %l16, !tbaa !24
  %t292 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr i8, ptr %t293, i64 %t290
  %t295 = load i8, ptr %t294, !tbaa !32
  store i8 %t295, ptr %l17, !tbaa !22
  %t297 = load i8, ptr %l17, !tbaa !22
  %t299 = icmp eq i8 %t297, 60
  br i1 %t299, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb60
bb59:
  %t301 = load i8, ptr %l17, !tbaa !22
  %t303 = icmp eq i8 %t301, 40
  store i1 %t303, ptr %l140, !tbaa !21
  br label %bb60
bb60:
  %t305 = load i1, ptr %l140, !tbaa !21
  br i1 %t305, label %bb61, label %bb62
bb61:
  %t306 = load i64, ptr %l9, !tbaa !24
  %t308 = add i64 %t306, 1
  store i64 %t308, ptr %l9, !tbaa !24
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t310 = load i8, ptr %l17, !tbaa !22
  %t312 = icmp eq i8 %t310, 62
  br i1 %t312, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb66
bb65:
  %t314 = load i8, ptr %l17, !tbaa !22
  %t316 = icmp eq i8 %t314, 41
  store i1 %t316, ptr %l147, !tbaa !21
  br label %bb66
bb66:
  %t318 = load i1, ptr %l147, !tbaa !21
  br i1 %t318, label %bb67, label %bb68
bb67:
  %t319 = load i64, ptr %l9, !tbaa !24
  %t321 = icmp sgt i64 %t319, 0
  store i1 %t321, ptr %l150, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb69
bb69:
  %t323 = load i1, ptr %l150, !tbaa !21
  br i1 %t323, label %bb70, label %bb71
bb70:
  %t324 = load i64, ptr %l9, !tbaa !24
  %t326 = sub i64 %t324, 1
  store i64 %t326, ptr %l9, !tbaa !24
  br label %bb91
bb71:
  br label %bb72
bb72:
  %t328 = load i64, ptr %l9, !tbaa !24
  %t330 = icmp eq i64 %t328, 0
  br i1 %t330, label %bb73, label %bb74
bb73:
  %t332 = load i8, ptr %l17, !tbaa !22
  %t334 = icmp eq i8 %t332, 62
  br i1 %t334, label %bb75, label %bb76
bb74:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb87
bb75:
  store i1 true, ptr %l160, !tbaa !21
  br label %bb77
bb76:
  %t336 = load i8, ptr %l17, !tbaa !22
  %t338 = icmp eq i8 %t336, 44
  store i1 %t338, ptr %l160, !tbaa !21
  br label %bb77
bb77:
  %t340 = load i1, ptr %l160, !tbaa !21
  br i1 %t340, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l163, !tbaa !21
  br label %bb86
bb79:
  %t341 = load i8, ptr %l17, !tbaa !22
  %t343 = icmp eq i8 %t341, 32
  br i1 %t343, label %bb80, label %bb81
bb80:
  %t345 = load i64, ptr %l16, !tbaa !24
  %t347 = add i64 %t345, 1
  %t348 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t348, 0
  %t353 = icmp slt i64 %t347, %t350
  store i1 %t353, ptr %l166, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb82
bb82:
  %t355 = load i1, ptr %l166, !tbaa !21
  br i1 %t355, label %bb83, label %bb84
bb83:
  %t356 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t356, ptr %l173, !tbaa !27
  %t357 = load i64, ptr %l16, !tbaa !24
  %t359 = add i64 %t357, 1
  %t361 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr i8, ptr %t362, i64 %t359
  %t364 = load i8, ptr %t363, !tbaa !32
  %t366 = icmp eq i8 %t364, 63
  store i1 %t366, ptr %l172, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb85
bb85:
  %t368 = load i1, ptr %l172, !tbaa !21
  store i1 %t368, ptr %l163, !tbaa !21
  br label %bb86
bb86:
  %t369 = load i1, ptr %l163, !tbaa !21
  store i1 %t369, ptr %l157, !tbaa !21
  br label %bb87
bb87:
  %t370 = load i1, ptr %l157, !tbaa !21
  br i1 %t370, label %bb88, label %bb89
bb88:
  %t371 = load i64, ptr %l16, !tbaa !24
  store i64 %t371, ptr %l10, !tbaa !24
  br label %bb92
bb89:
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t373 = load i64, ptr %l15, !tbaa !24
  %t375 = add i64 %t373, 1
  store i64 %t375, ptr %l15, !tbaa !24
  br label %bb54
bb92:
  %t377 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t379 = extractvalue { i64, ptr } %t377, 0
  %t380 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t380, 0
  %t385 = sub i64 %t379, %t382
  store i64 %t385, ptr %l185, !tbaa !24
  %t386 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t386, 0
  store i64 %t387, ptr %l186, !tbaa !24
  %t388 = icmp sge i64 0, 0
  br i1 %t388, label %bb93, label %bb94
bb93:
  %t390 = load i64, ptr %l185, !tbaa !24
  %t391 = icmp sle i64 0, %t390
  br i1 %t391, label %bb95, label %bb96
bb94:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb95:
  %t393 = load i64, ptr %l185, !tbaa !24
  %t394 = load i64, ptr %l186, !tbaa !24
  %t395 = icmp sle i64 %t393, %t394
  br i1 %t395, label %bb97, label %bb98
bb96:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb97:
  %t397 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t398 = load ptr, ptr %t397, !tbaa !27
  %t399 = load i64, ptr %l185, !tbaa !24
  %t400 = getelementptr i8, ptr %t398, i64 0
  %t401 = sub i64 %t399, 0
  %t402 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t400, 1
  store { i64, ptr } %t403, ptr %l190, !tbaa !27
  %t404 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t404, ptr %l191, !tbaa !27
  %t405 = load i64, ptr %l10, !tbaa !24
  store i64 %t405, ptr %l192, !tbaa !24
  %t406 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  store i64 %t407, ptr %l193, !tbaa !24
  %t408 = icmp sge i64 0, 0
  br i1 %t408, label %bb99, label %bb100
bb98:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb99:
  %t410 = load i64, ptr %l192, !tbaa !24
  %t411 = icmp sle i64 0, %t410
  br i1 %t411, label %bb101, label %bb102
bb100:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb101:
  %t413 = load i64, ptr %l192, !tbaa !24
  %t414 = load i64, ptr %l193, !tbaa !24
  %t415 = icmp sle i64 %t413, %t414
  br i1 %t415, label %bb103, label %bb104
bb102:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb103:
  %t417 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = load i64, ptr %l192, !tbaa !24
  %t420 = getelementptr i8, ptr %t418, i64 0
  %t421 = sub i64 %t419, 0
  %t422 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t423 = insertvalue { i64, ptr } %t422, ptr %t420, 1
  store { i64, ptr } %t423, ptr %l197, !tbaa !27
  %t424 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t424, ptr %l198, !tbaa !27
  %t425 = load i64, ptr %l10, !tbaa !24
  store i64 %t425, ptr %l199, !tbaa !24
  %t426 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t429 = extractvalue { i64, ptr } %t426, 0
  store i64 %t429, ptr %l202, !tbaa !24
  %t430 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t430, 0
  store i64 %t431, ptr %l203, !tbaa !24
  %t432 = load i64, ptr %l199, !tbaa !24
  %t433 = icmp sge i64 %t432, 0
  br i1 %t433, label %bb105, label %bb106
bb104:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb105:
  %t435 = load i64, ptr %l199, !tbaa !24
  %t436 = load i64, ptr %l202, !tbaa !24
  %t437 = icmp sle i64 %t435, %t436
  br i1 %t437, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb107:
  %t439 = load i64, ptr %l202, !tbaa !24
  %t440 = load i64, ptr %l203, !tbaa !24
  %t441 = icmp sle i64 %t439, %t440
  br i1 %t441, label %bb109, label %bb110
bb108:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb109:
  %t443 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = load i64, ptr %l199, !tbaa !24
  %t446 = load i64, ptr %l202, !tbaa !24
  %t447 = getelementptr i8, ptr %t444, i64 %t445
  %t448 = sub i64 %t446, %t445
  %t449 = insertvalue { i64, ptr } undef, i64 %t448, 0
  %t450 = insertvalue { i64, ptr } %t449, ptr %t447, 1
  %t451 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t452 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 1
  %t454 = extractvalue { i64, ptr } %t452, 0
  %t455 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t456 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t457 = add i64 %t454, %t456
  %t458 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t458, 1
  %t460 = extractvalue { i64, ptr } %t458, 0
  %t461 = add i64 %t457, %t460
  %t462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t463 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t464 = add i64 %t461, %t463
  %t466 = extractvalue { i64, ptr } %t450, 1
  %t467 = extractvalue { i64, ptr } %t450, 0
  %t468 = add i64 %t464, %t467
  %t469 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t470 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t471 = add i64 %t468, %t470
  %t473 = extractvalue { i64, ptr } %t451, 1
  %t474 = extractvalue { i64, ptr } %t451, 0
  %t475 = add i64 %t471, %t474
  %t476 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t475)
  call void @olang_textcopy(ptr %t476, ptr %t453, i64 %t454)
  %t477 = getelementptr i8, ptr %t476, i64 %t454
  call void @olang_textcopy(ptr %t477, ptr %t455, i64 %t456)
  %t478 = getelementptr i8, ptr %t477, i64 %t456
  call void @olang_textcopy(ptr %t478, ptr %t459, i64 %t460)
  %t479 = getelementptr i8, ptr %t478, i64 %t460
  call void @olang_textcopy(ptr %t479, ptr %t462, i64 %t463)
  %t480 = getelementptr i8, ptr %t479, i64 %t463
  call void @olang_textcopy(ptr %t480, ptr %t466, i64 %t467)
  %t481 = getelementptr i8, ptr %t480, i64 %t467
  call void @olang_textcopy(ptr %t481, ptr %t469, i64 %t470)
  %t482 = getelementptr i8, ptr %t481, i64 %t470
  call void @olang_textcopy(ptr %t482, ptr %t473, i64 %t474)
  %t483 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t484 = insertvalue { i64, ptr } %t483, ptr %t476, 1
  store { i64, ptr } %t484, ptr %l209, !tbaa !27
  %t485 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t485, 0
  %t487 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t487, 0
  store i64 %t488, ptr %l211, !tbaa !24
  %t490 = load i64, ptr %l211, !tbaa !24
  %t491 = icmp eq i64 %t486, %t490
  br i1 %t491, label %bb111, label %bb112
bb110:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb111:
  %t493 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !27
  %t497 = load i64, ptr %l211, !tbaa !24
  %t498 = mul i64 %t497, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t494, ptr %t496, i64 %t498, i1 false)
  br label %bb113
bb112:
  %t499 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t499, ptr %l6, !tbaa !27
  br label %bb113
bb113:
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s5)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s2)
  br label %bb116
bb116:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/check:Checker", ptr %t500, i32 0, i32 1
  %t503 = load ptr, ptr %t502, !tbaa !29
  %t504 = load i64, ptr %l1, !tbaa !24
  %t507 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t503, i64 %t504)
  store i1 %t507, ptr %l216
  br label %bb117
bb117:
  %t508 = load i1, ptr %l216, !tbaa !21
  br i1 %t508, label %bb118, label %bb119
bb118:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l217, !tbaa !27
  br label %bb120
bb119:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l217, !tbaa !27
  br label %bb120
bb120:
  %t509 = load { i64, ptr }, ptr %l217, !tbaa !27
  store { i64, ptr } %t509, ptr %l18, !tbaa !27
  %t510 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t512 = call i64 @compiler_2fexplain_2efirstClose(ptr %s0, { i64, ptr } %t510)
  store i64 %t512, ptr %l219
  br label %bb121
bb121:
  %t513 = load i64, ptr %l219, !tbaa !24
  store i64 %t513, ptr %l19, !tbaa !24
  %t514 = load ptr, ptr %l0, !tbaa !29
  store ptr %t514, ptr %l220, !tbaa !29
  %t515 = load i64, ptr %l19, !tbaa !24
  store i64 %t515, ptr %l221, !tbaa !24
  %t516 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t516, 0
  store i64 %t517, ptr %l222, !tbaa !24
  %t518 = icmp sge i64 3, 0
  br i1 %t518, label %bb122, label %bb123
bb122:
  %t520 = load i64, ptr %l221, !tbaa !24
  %t521 = icmp sle i64 3, %t520
  br i1 %t521, label %bb124, label %bb125
bb123:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb124:
  %t523 = load i64, ptr %l221, !tbaa !24
  %t524 = load i64, ptr %l222, !tbaa !24
  %t525 = icmp sle i64 %t523, %t524
  br i1 %t525, label %bb126, label %bb127
bb125:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb126:
  %t527 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = load i64, ptr %l221, !tbaa !24
  %t530 = getelementptr i8, ptr %t528, i64 3
  %t531 = sub i64 %t529, 3
  %t532 = insertvalue { i64, ptr } undef, i64 %t531, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t530, 1
  store { i64, ptr } %t533, ptr %l226, !tbaa !27
  %t534 = load ptr, ptr %l4, !tbaa !29
  %t536 = getelementptr %"compiler/ast:Func", ptr %t534, i32 0, i32 3
  %t537 = load ptr, ptr %t536, !tbaa !29
  %t539 = getelementptr %"compiler/ast:Sig", ptr %t537, i32 0, i32 0
  %t540 = load { i64, ptr }, ptr %t539, !tbaa !27
  store { i64, ptr } %t540, ptr %l229, !tbaa !27
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t543 = getelementptr %"compiler/check:Checker", ptr %t541, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !29
  %t545 = load i64, ptr %l1, !tbaa !24
  %t548 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t544, i64 %t545)
  store i64 %t548, ptr %l233
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb128:
  %t549 = load ptr, ptr %l4, !tbaa !29
  %t551 = getelementptr %"compiler/ast:Func", ptr %t549, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !29
  %t554 = icmp eq ptr %t552, null
  %t556 = xor i1 %t554, true
  br i1 %t556, label %bb129, label %bb130
bb129:
  store i64 1, ptr %l238, !tbaa !24
  br label %bb131
bb130:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb131
bb131:
  %t558 = load ptr, ptr %l220, !tbaa !29
  %t559 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t560 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t561 = load i64, ptr %l233, !tbaa !24
  %t562 = load i64, ptr %l238, !tbaa !24
  %t563 = call { i64, ptr } @compiler_2fexplain_2ewithDefaults(ptr %v0, ptr %s0, ptr %v0, ptr %s0, ptr %t558, { i64, ptr } %t559, { i64, ptr } %t560, i64 %t561, i64 %t562)
  store { i64, ptr } %t563, ptr %l239
  br label %bb132
bb132:
  %t564 = load i64, ptr %l19, !tbaa !24
  store i64 %t564, ptr %l240, !tbaa !24
  %t565 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t567 = extractvalue { i64, ptr } %t565, 0
  store i64 %t567, ptr %l242, !tbaa !24
  %t568 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 0
  store i64 %t569, ptr %l243, !tbaa !24
  %t570 = load i64, ptr %l240, !tbaa !24
  %t571 = icmp sge i64 %t570, 0
  br i1 %t571, label %bb133, label %bb134
bb133:
  %t573 = load i64, ptr %l240, !tbaa !24
  %t574 = load i64, ptr %l242, !tbaa !24
  %t575 = icmp sle i64 %t573, %t574
  br i1 %t575, label %bb135, label %bb136
bb134:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb135:
  %t577 = load i64, ptr %l242, !tbaa !24
  %t578 = load i64, ptr %l243, !tbaa !24
  %t579 = icmp sle i64 %t577, %t578
  br i1 %t579, label %bb137, label %bb138
bb136:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb137:
  %t581 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t582 = load ptr, ptr %t581, !tbaa !27
  %t583 = load i64, ptr %l240, !tbaa !24
  %t584 = load i64, ptr %l242, !tbaa !24
  %t585 = getelementptr i8, ptr %t582, i64 %t583
  %t586 = sub i64 %t584, %t583
  %t587 = insertvalue { i64, ptr } undef, i64 %t586, 0
  %t588 = insertvalue { i64, ptr } %t587, ptr %t585, 1
  %t589 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t590 = extractvalue { i64, ptr } %t589, 1
  %t591 = extractvalue { i64, ptr } %t589, 0
  %t593 = extractvalue { i64, ptr } %t588, 1
  %t594 = extractvalue { i64, ptr } %t588, 0
  %t595 = add i64 %t591, %t594
  %t596 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t595)
  call void @olang_textcopy(ptr %t596, ptr %t590, i64 %t591)
  %t597 = getelementptr i8, ptr %t596, i64 %t591
  call void @olang_textcopy(ptr %t597, ptr %t593, i64 %t594)
  %t598 = insertvalue { i64, ptr } undef, i64 %t595, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t596, 1
  store { i64, ptr } %t599, ptr %l20, !tbaa !27
  %t601 = load ptr, ptr %l4, !tbaa !29
  %t603 = getelementptr %"compiler/ast:Func", ptr %t601, i32 0, i32 1
  %t604 = load ptr, ptr %t603, !tbaa !29
  %t606 = icmp eq ptr %t604, null
  br i1 %t606, label %bb139, label %bb140
bb138:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb139:
  %t608 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t609 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t610 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t612 = extractvalue { i64, ptr } %t608, 1
  %t613 = extractvalue { i64, ptr } %t608, 0
  %t615 = extractvalue { i64, ptr } %t609, 1
  %t616 = extractvalue { i64, ptr } %t609, 0
  %t617 = add i64 %t613, %t616
  %t618 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t619 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t620 = add i64 %t617, %t619
  %t622 = extractvalue { i64, ptr } %t610, 1
  %t623 = extractvalue { i64, ptr } %t610, 0
  %t624 = add i64 %t620, %t623
  %t625 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t624)
  call void @olang_textcopy(ptr %t625, ptr %t612, i64 %t613)
  %t626 = getelementptr i8, ptr %t625, i64 %t613
  call void @olang_textcopy(ptr %t626, ptr %t615, i64 %t616)
  %t627 = getelementptr i8, ptr %t626, i64 %t616
  call void @olang_textcopy(ptr %t627, ptr %t618, i64 %t619)
  %t628 = getelementptr i8, ptr %t627, i64 %t619
  call void @olang_textcopy(ptr %t628, ptr %t622, i64 %t623)
  %t629 = insertvalue { i64, ptr } undef, i64 %t624, 0
  %t630 = insertvalue { i64, ptr } %t629, ptr %t625, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t630, ptr %rv
  br label %ret
bb140:
  br label %bb141
bb141:
  %t632 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t634 = call i64 @compiler_2fexplain_2efirstItemEnd(ptr %s0, { i64, ptr } %t632)
  store i64 %t634, ptr %l257
  br label %bb142
bb142:
  %t635 = load i64, ptr %l257, !tbaa !24
  store i64 %t635, ptr %l21, !tbaa !24
  %t636 = load i64, ptr %l21, !tbaa !24
  store i64 %t636, ptr %l258, !tbaa !24
  %t637 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t637, 0
  store i64 %t638, ptr %l259, !tbaa !24
  %t639 = icmp sge i64 0, 0
  br i1 %t639, label %bb143, label %bb144
bb143:
  %t641 = load i64, ptr %l258, !tbaa !24
  %t642 = icmp sle i64 0, %t641
  br i1 %t642, label %bb145, label %bb146
bb144:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb145:
  %t644 = load i64, ptr %l258, !tbaa !24
  %t645 = load i64, ptr %l259, !tbaa !24
  %t646 = icmp sle i64 %t644, %t645
  br i1 %t646, label %bb147, label %bb148
bb146:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb147:
  %t648 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t649 = load ptr, ptr %t648, !tbaa !27
  %t650 = load i64, ptr %l258, !tbaa !24
  %t651 = getelementptr i8, ptr %t649, i64 0
  %t652 = sub i64 %t650, 0
  %t653 = insertvalue { i64, ptr } undef, i64 %t652, 0
  %t654 = insertvalue { i64, ptr } %t653, ptr %t651, 1
  store { i64, ptr } %t654, ptr %l22, !tbaa !27
  %t656 = load i64, ptr %l21, !tbaa !24
  %t658 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t659 = load ptr, ptr %t658, !tbaa !27
  %t660 = getelementptr i8, ptr %t659, i64 %t656
  %t661 = load i8, ptr %t660, !tbaa !32
  %t663 = icmp eq i8 %t661, 44
  br i1 %t663, label %bb149, label %bb150
bb148:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb149:
  %t665 = load i64, ptr %l21, !tbaa !24
  %t667 = add i64 %t665, 2
  store i64 %t667, ptr %l269, !tbaa !24
  %t668 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t670 = extractvalue { i64, ptr } %t668, 0
  store i64 %t670, ptr %l271, !tbaa !24
  %t671 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t672 = extractvalue { i64, ptr } %t671, 0
  store i64 %t672, ptr %l272, !tbaa !24
  %t673 = load i64, ptr %l269, !tbaa !24
  %t674 = icmp sge i64 %t673, 0
  br i1 %t674, label %bb151, label %bb152
bb150:
  %t676 = load i64, ptr %l21, !tbaa !24
  store i64 %t676, ptr %l277, !tbaa !24
  %t677 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t679 = extractvalue { i64, ptr } %t677, 0
  store i64 %t679, ptr %l279, !tbaa !24
  %t680 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t681 = extractvalue { i64, ptr } %t680, 0
  store i64 %t681, ptr %l280, !tbaa !24
  %t682 = load i64, ptr %l277, !tbaa !24
  %t683 = icmp sge i64 %t682, 0
  br i1 %t683, label %bb157, label %bb158
bb151:
  %t685 = load i64, ptr %l269, !tbaa !24
  %t686 = load i64, ptr %l271, !tbaa !24
  %t687 = icmp sle i64 %t685, %t686
  br i1 %t687, label %bb153, label %bb154
bb152:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb153:
  %t689 = load i64, ptr %l271, !tbaa !24
  %t690 = load i64, ptr %l272, !tbaa !24
  %t691 = icmp sle i64 %t689, %t690
  br i1 %t691, label %bb155, label %bb156
bb154:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb155:
  %t693 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t694 = load ptr, ptr %t693, !tbaa !27
  %t695 = load i64, ptr %l269, !tbaa !24
  %t696 = load i64, ptr %l271, !tbaa !24
  %t697 = getelementptr i8, ptr %t694, i64 %t695
  %t698 = sub i64 %t696, %t695
  %t699 = insertvalue { i64, ptr } undef, i64 %t698, 0
  %t700 = insertvalue { i64, ptr } %t699, ptr %t697, 1
  store { i64, ptr } %t700, ptr %l267, !tbaa !27
  br label %bb163
bb156:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb157:
  %t702 = load i64, ptr %l277, !tbaa !24
  %t703 = load i64, ptr %l279, !tbaa !24
  %t704 = icmp sle i64 %t702, %t703
  br i1 %t704, label %bb159, label %bb160
bb158:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb159:
  %t706 = load i64, ptr %l279, !tbaa !24
  %t707 = load i64, ptr %l280, !tbaa !24
  %t708 = icmp sle i64 %t706, %t707
  br i1 %t708, label %bb161, label %bb162
bb160:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb161:
  %t710 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t711 = load ptr, ptr %t710, !tbaa !27
  %t712 = load i64, ptr %l277, !tbaa !24
  %t713 = load i64, ptr %l279, !tbaa !24
  %t714 = getelementptr i8, ptr %t711, i64 %t712
  %t715 = sub i64 %t713, %t712
  %t716 = insertvalue { i64, ptr } undef, i64 %t715, 0
  %t717 = insertvalue { i64, ptr } %t716, ptr %t714, 1
  store { i64, ptr } %t717, ptr %l267, !tbaa !27
  br label %bb163
bb162:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb163:
  %t719 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t720 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t721 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t722 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t725 = extractvalue { i64, ptr } %t720, 1
  %t726 = extractvalue { i64, ptr } %t720, 0
  %t727 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t728 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t729 = add i64 %t726, %t728
  %t731 = extractvalue { i64, ptr } %t721, 1
  %t732 = extractvalue { i64, ptr } %t721, 0
  %t733 = add i64 %t729, %t732
  %t734 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t735 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t736 = add i64 %t733, %t735
  %t738 = extractvalue { i64, ptr } %t722, 1
  %t739 = extractvalue { i64, ptr } %t722, 0
  %t740 = add i64 %t736, %t739
  %t741 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t742 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t743 = add i64 %t740, %t742
  %t745 = extractvalue { i64, ptr } %t719, 1
  %t746 = extractvalue { i64, ptr } %t719, 0
  %t747 = add i64 %t743, %t746
  %t748 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t747)
  call void @olang_textcopy(ptr %t748, ptr %t725, i64 %t726)
  %t749 = getelementptr i8, ptr %t748, i64 %t726
  call void @olang_textcopy(ptr %t749, ptr %t727, i64 %t728)
  %t750 = getelementptr i8, ptr %t749, i64 %t728
  call void @olang_textcopy(ptr %t750, ptr %t731, i64 %t732)
  %t751 = getelementptr i8, ptr %t750, i64 %t732
  call void @olang_textcopy(ptr %t751, ptr %t734, i64 %t735)
  %t752 = getelementptr i8, ptr %t751, i64 %t735
  call void @olang_textcopy(ptr %t752, ptr %t738, i64 %t739)
  %t753 = getelementptr i8, ptr %t752, i64 %t739
  call void @olang_textcopy(ptr %t753, ptr %t741, i64 %t742)
  %t754 = getelementptr i8, ptr %t753, i64 %t742
  call void @olang_textcopy(ptr %t754, ptr %t745, i64 %t746)
  %t755 = insertvalue { i64, ptr } undef, i64 %t747, 0
  %t756 = insertvalue { i64, ptr } %t755, ptr %t748, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t756, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, %"compiler/names:Entry" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/names:Entry"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l18 = alloca i32
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l47 = alloca i32
  %l50 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i32
  %l59 = alloca i32
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/names:Entry" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %t12, i64 %t13, i32 %t15)
  store i32 %t19, ptr %l18
  br label %bb1
bb1:
  %t20 = load i32, ptr %l18, !tbaa !23
  store i32 %t20, ptr %l5, !tbaa !23
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t21, i32 %t23)
  store { i64, ptr } %t26, ptr %l21
  br label %bb2
bb2:
  %t27 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l5, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t30, i32 %t31)
  store { i64, ptr } %t34, ptr %l26
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t36, i64 %t37)
  %t47 = getelementptr i8, ptr %t46, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = getelementptr i8, ptr %t47, i64 %t40
  call void @olang_textcopy(ptr %t48, ptr %t43, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  %t52 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = getelementptr i8, ptr %t62, i64 %t58
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 1
  %t72 = load %"compiler/source:Span", ptr %t71
  %t77 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %t67, i64 %t68, i32 %t70, %"compiler/source:Span" %t72)
  store i64 %t77, ptr %l35
  br label %bb10
bb10:
  %t78 = load i64, ptr %l35, !tbaa !24
  %t83 = call { i32, { i64, ptr } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v1, ptr %s0, ptr %a1, i64 %t78)
  %t84 = extractvalue { i32, { i64, ptr } } %t83, 1
  %t85 = extractvalue { i32, { i64, ptr } } %t83, 0
  store i32 %t85, ptr %l40
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb12, label %ok.87, !prof !99
ok.87:
  store { i64, ptr } %t84, ptr %l39
  br label %bb11
bb11:
  %t88 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t88, ptr %l36, !tbaa !27
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  %t89 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t91, i64 %t92)
  %t97 = getelementptr i8, ptr %t96, i64 %t92
  call void @olang_textcopy(ptr %t97, ptr %t93, i64 %t94)
  %t98 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t99, ptr %rv
  br label %ret
bb14:
  %t101 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t101, ptr %l8, !tbaa !27
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l5, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l47
  br label %bb15
bb15:
  %t112 = load i32, ptr %l47, !range !{i32 0, i32 33}
  %t114 = trunc i64 20 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb16, label %bb17
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l5, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l55
  br label %bb18
bb17:
  %t127 = load i32, ptr %l5, !tbaa !23
  store i32 %t127, ptr %l50, !tbaa !23
  br label %bb19
bb18:
  %t129 = load i32, ptr %l55, !tbaa !23
  store i32 %t129, ptr %l50, !tbaa !23
  br label %bb19
bb19:
  %t130 = load i32, ptr %l50, !tbaa !23
  store i32 %t130, ptr %l57, !tbaa !23
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %t132)
  store i32 %t134, ptr %l59
  br label %bb20
bb20:
  %t135 = load i32, ptr %l57, !tbaa !23
  %t136 = load i32, ptr %l59, !tbaa !23
  %t137 = icmp eq i32 %t135, %t136
  br i1 %t137, label %bb21, label %bb22
bb21:
  %t139 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t141 = call { i64, ptr } @compiler_2fexplain_2equoted(ptr %s0, ptr %s0, { i64, ptr } %t139)
  store { i64, ptr } %t141, ptr %l63
  br label %bb23
bb22:
  %t142 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = extractvalue { i64, ptr } %t142, 0
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t144, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l61, !tbaa !27
  br label %bb24
bb23:
  %t150 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t151, i64 %t152)
  %t154 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l61, !tbaa !27
  br label %bb24
bb24:
  %t157 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t157, ptr %l10, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = load i64, ptr @G_2ecompiler_2fexplain_2eLongValue, !tbaa !24
  %t164 = icmp sgt i64 %t160, %t161
  br i1 %t164, label %bb25, label %bb26
bb25:
  %t166 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t166, ptr %l71, !tbaa !27
  %t167 = load i64, ptr @G_2ecompiler_2fexplain_2eLongValue, !tbaa !24
  store i64 %t167, ptr %l72, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  store i64 %t169, ptr %l73, !tbaa !24
  %t170 = icmp sge i64 0, 0
  br i1 %t170, label %bb27, label %bb28
bb26:
  br label %bb33
bb27:
  %t172 = load i64, ptr %l72, !tbaa !24
  %t173 = icmp sle i64 0, %t172
  br i1 %t173, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb29:
  %t175 = load i64, ptr %l72, !tbaa !24
  %t176 = load i64, ptr %l73, !tbaa !24
  %t177 = icmp sle i64 %t175, %t176
  br i1 %t177, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb31:
  %t179 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l72, !tbaa !24
  %t182 = getelementptr i8, ptr %t180, i64 0
  %t183 = sub i64 %t181, 0
  %t184 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t182, 1
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t194 = add i64 %t191, %t193
  %t196 = extractvalue { i64, ptr } %t185, 1
  %t197 = extractvalue { i64, ptr } %t185, 0
  %t198 = add i64 %t194, %t197
  %t199 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t203 = call i64 @__olang_fmt_i64(ptr null, i64 %t188)
  %t204 = add i64 %t201, %t203
  %t205 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t207 = add i64 %t204, %t206
  %t208 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t190, i64 %t191)
  %t209 = getelementptr i8, ptr %t208, i64 %t191
  call void @olang_textcopy(ptr %t209, ptr %t192, i64 %t193)
  %t210 = getelementptr i8, ptr %t209, i64 %t193
  call void @olang_textcopy(ptr %t210, ptr %t196, i64 %t197)
  %t211 = getelementptr i8, ptr %t210, i64 %t197
  call void @olang_textcopy(ptr %t211, ptr %t199, i64 %t200)
  %t212 = getelementptr i8, ptr %t211, i64 %t200
  %t213 = call i64 @__olang_fmt_i64(ptr %t212, i64 %t188)
  %t214 = getelementptr i8, ptr %t212, i64 %t203
  call void @olang_textcopy(ptr %t214, ptr %t205, i64 %t206)
  %t215 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t208, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t216, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb33:
  %t218 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t218, 1
  %t222 = extractvalue { i64, ptr } %t218, 0
  %t223 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t227 = extractvalue { i64, ptr } %t219, 1
  %t228 = extractvalue { i64, ptr } %t219, 0
  %t229 = add i64 %t225, %t228
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t221, i64 %t222)
  %t234 = getelementptr i8, ptr %t233, i64 %t222
  call void @olang_textcopy(ptr %t234, ptr %t223, i64 %t224)
  %t235 = getelementptr i8, ptr %t234, i64 %t224
  call void @olang_textcopy(ptr %t235, ptr %t227, i64 %t228)
  %t236 = getelementptr i8, ptr %t235, i64 %t228
  call void @olang_textcopy(ptr %t236, ptr %t230, i64 %t231)
  %t237 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t233, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t238, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l27 = alloca i64
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca i64
  %l32 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t26 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load i64, ptr %l19, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d69, i32 0, i32 1) })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  store ptr %l2, ptr %l22, !tbaa !29
  store { i64, ptr } %a0, ptr %l23, !tbaa !27
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l25
  br label %bb11
bb11:
  %t35 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l27, !tbaa !24
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t41 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t39)
  store %"compiler/source:Span" %t41, ptr %l29
  br label %bb12
bb12:
  %t42 = getelementptr %"compiler/source:Span", ptr %l29, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = sext i32 %t43 to i64
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l32, !tbaa !24
  %t48 = load i64, ptr %l27, !tbaa !24
  %t49 = icmp sge i64 %t48, 0
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb15:
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb17:
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l27, !tbaa !24
  %t62 = load i64, ptr %l31, !tbaa !24
  %t63 = getelementptr i8, ptr %t60, i64 %t61
  %t64 = sub i64 %t62, %t61
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t67 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t67, { i64, ptr } %t66)
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb19:
  br label %bb20
bb20:
  %t69 = load i64, ptr %l4, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l4, !tbaa !24
  br label %bb2
bb21:
  %t74 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t74, ptr %l40
  br label %bb22
bb22:
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t75, ptr %l41, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l42, !tbaa !24
  %t78 = load i64, ptr %l42, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l43, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l42, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t89, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2emethods(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca i1
  %l54 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l75 = alloca i32
  %l82 = alloca i32
  %l87 = alloca i32
  %l91 = alloca i1
  %l96 = alloca i32
  %l101 = alloca i32
  %l104 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i64
  %l119 = alloca i32
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i64
  %l131 = alloca i64
  %l132 = alloca ptr
  %l133 = alloca ptr
  %l134 = alloca i64
  %l138 = alloca i32
  %l139 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v1, ptr %t4)
  br label %bb1
bb1:
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb2
bb2:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v1, ptr %v1, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l44
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l44, !tbaa !29
  store ptr %t67, ptr %l9, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v1, ptr %t78, i32 %t79, i32 %t83)
  store i64 %t87, ptr %l54
  br label %bb16
bb16:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l54, !tbaa !24
  %t91 = icmp ne i64 %t89, %t88
  store i1 %t91, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t93 = load i1, ptr %l48, !tbaa !21
  br i1 %t93, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb19:
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l59, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t105, ptr %l62, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t109, i64 %t110)
  store i32 %t113, ptr %l66
  br label %bb21
bb21:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load i32, ptr %l66, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t114, i32 %t115)
  store i32 %t116, ptr %l67
  br label %bb22
bb22:
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load i32, ptr %l67, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %s2, ptr %t117, i32 %t118)
  store { i64, ptr } %t119, ptr %l68
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t120, ptr %l69, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i32, ptr %t122, i64 0
  %t124 = load i32, ptr %t123, !tbaa !33
  store i32 %t124, ptr %l10, !tbaa !23
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l10, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l75
  br label %bb24
bb24:
  %t136 = load i32, ptr %l75, !range !{i32 0, i32 33}
  %t138 = trunc i64 20 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb25, label %bb26
bb25:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l10, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v1, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l82
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t151 = load i32, ptr %l82, !tbaa !23
  store i32 %t151, ptr %l10, !tbaa !23
  br label %bb28
bb28:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  %t158 = load i32, ptr %l10, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t157, i32 %t158)
  store i32 %t161, ptr %l87
  br label %bb29
bb29:
  %t162 = load i32, ptr %l87, !range !{i32 0, i32 33}
  %t164 = trunc i64 18 to i32
  %t165 = icmp eq i32 %t162, %t164
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb34
bb31:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/generic:Program", ptr %t172, i32 0, i32 2
  %t175 = load i32, ptr %l10, !tbaa !23
  %t178 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t174, i32 %t175)
  store i32 %t178, ptr %l96
  br label %bb32
bb32:
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l2, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l101
  br label %bb33
bb33:
  %t189 = load i32, ptr %l96, !tbaa !23
  %t190 = load i32, ptr %l101, !tbaa !23
  %t191 = icmp ne i32 %t189, %t190
  store i1 %t191, ptr %l91, !tbaa !21
  br label %bb34
bb34:
  %t193 = load i1, ptr %l91, !tbaa !21
  br i1 %t193, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb36:
  br label %bb37
bb37:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  store ptr %t197, ptr %l104, !tbaa !29
  %t198 = load i64, ptr %l8, !tbaa !24
  %t200 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t198)
  store i64 %t200, ptr %l106
  br label %bb38
bb38:
  %t201 = load ptr, ptr %l104, !tbaa !29
  %t202 = load i64, ptr %l106, !tbaa !24
  %t203 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t201, i64 %t202)
  store i64 %t203, ptr %l107
  br label %bb39
bb39:
  %t204 = load i64, ptr %l107, !tbaa !24
  %t205 = icmp eq i64 %t204, 0
  br i1 %t205, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v1, ptr %t210, i64 %t211, i32 0)
  store i64 %t214, ptr %l112
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l132, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  store ptr %t216, ptr %l133, !tbaa !29
  %t217 = load i64, ptr %l8, !tbaa !24
  store i64 %t217, ptr %l134, !tbaa !24
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t222 = load i64, ptr %l8, !tbaa !24
  %t225 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t221, i64 %t222)
  store i32 %t225, ptr %l138
  br label %bb49
bb42:
  %t226 = load i64, ptr %l112, !tbaa !24
  store i64 %t226, ptr %l11, !tbaa !24
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l113, !tbaa !29
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l114, !tbaa !29
  %t229 = load i64, ptr %l8, !tbaa !24
  store i64 %t229, ptr %l115, !tbaa !24
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v1, ptr %t233, i64 %t234)
  store i32 %t237, ptr %l119
  br label %bb43
bb43:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t239 = load i64, ptr %l11, !tbaa !24
  %t242 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v1, ptr %t238, i64 %t239)
  store i64 %t242, ptr %l122
  br label %bb44
bb44:
  %t243 = load ptr, ptr %l114, !tbaa !29
  %t244 = load i64, ptr %l115, !tbaa !24
  %t245 = load i32, ptr %l119, !tbaa !23
  %t246 = load i64, ptr %l122, !tbaa !24
  %t247 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s6, ptr %t243, i64 %t244, i32 %t245, i64 %t246)
  store { i64, ptr } %t247, ptr %l123
  br label %bb45
bb45:
  %t248 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t250 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t269 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t269, { i64, ptr } %t268)
  br label %bb46
bb46:
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l126, !tbaa !29
  %t272 = load ptr, ptr %l1, !tbaa !29
  store ptr %t272, ptr %l127, !tbaa !29
  %t273 = load i64, ptr %l8, !tbaa !24
  store i64 %t273, ptr %l128, !tbaa !24
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t275 = load i64, ptr %l11, !tbaa !24
  %t278 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v1, ptr %t274, i64 %t275)
  store i64 %t278, ptr %l131
  br label %bb47
bb47:
  %t279 = load ptr, ptr %l126, !tbaa !29
  %t280 = load ptr, ptr %l127, !tbaa !29
  %t281 = load i64, ptr %l128, !tbaa !24
  %t282 = load i64, ptr %l131, !tbaa !24
  call void @compiler_2fexplain_2eeffectLine(ptr %v0, ptr %v1, ptr %s6, ptr %t279, ptr %t280, i64 %t281, i64 %t282, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d72, i32 0, i32 1) })
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb52
bb49:
  %t283 = load ptr, ptr %l133, !tbaa !29
  %t284 = load i64, ptr %l134, !tbaa !24
  %t285 = load i32, ptr %l138, !tbaa !23
  %t286 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s8, ptr %t283, i64 %t284, i32 %t285, i64 -1)
  store { i64, ptr } %t286, ptr %l139
  br label %bb50
bb50:
  %t287 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t289 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t292 = add i64 %t288, %t291
  %t293 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t295 = add i64 %t292, %t294
  %t296 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t295)
  call void @olang_textcopy(ptr %t296, ptr %t287, i64 %t288)
  %t297 = getelementptr i8, ptr %t296, i64 %t288
  call void @olang_textcopy(ptr %t297, ptr %t290, i64 %t291)
  %t298 = getelementptr i8, ptr %t297, i64 %t291
  call void @olang_textcopy(ptr %t298, ptr %t293, i64 %t294)
  %t299 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t296, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = extractvalue { i64, ptr } %t300, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  %t308 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t308, { i64, ptr } %t307)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb53:
  %t310 = load i64, ptr %l7, !tbaa !24
  %t312 = add i64 %t310, 1
  store i64 %t312, ptr %l7, !tbaa !24
  br label %bb9
bb54:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca { i64, ptr }
  %l37 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = icmp eq ptr %t3, null
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = sext i32 %t12 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t14)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l7, !tbaa !24
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  %t47 = getelementptr %"compiler/ast:Param", ptr %t43, i32 0, i32 1
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = sext i32 %t48 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t50)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t53 = load i64, ptr %l6, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  br label %bb15
bb15:
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t58, ptr %l37
  br label %bb16
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  store ptr %t64, ptr %l40, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l1, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l45
  br label %bb17
bb17:
  %t75 = load ptr, ptr %l40, !tbaa !29
  %t76 = load i32, ptr %l45, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t75, i32 %t76)
  store { i64, ptr } %t77, ptr %l46
  br label %bb18
bb18:
  %t78 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = load i64, ptr %l37, !tbaa !24
  %t82 = icmp ne i64 %t80, %t79
  br i1 %t82, label %bb19, label %bb20
bb19:
  %t84 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t84, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  store ptr %t91, ptr %l52, !tbaa !29
  %t92 = load i32, ptr %l1, !tbaa !23
  store i32 %t92, ptr %l53, !tbaa !23
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l56, !tbaa !29
  %t100 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t100, ptr %l58
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l56, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t103 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %s0, ptr %t101, { i64, ptr } %t102)
  store i64 %t103, ptr %l59
  br label %bb23
bb23:
  %t104 = load ptr, ptr %l52, !tbaa !29
  %t105 = load i32, ptr %l53, !tbaa !23
  %t106 = load i64, ptr %l59, !tbaa !24
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t104, i32 %t105, i64 %t106)
  store i32 %t107, ptr %l60
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i32, ptr %l60, !tbaa !23
  store i32 %t108, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fexplain_2enoValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t9 = call { i64, ptr } @compiler_2fexplain_2eNoValueWhy(ptr %v1, ptr %v2, ptr %s0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
  store { i64, ptr } %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t10, ptr %l6, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i1 %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load i1, ptr %l13, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t21 = extractvalue { i64, ptr } %a5, 1
  %t22 = extractvalue { i64, ptr } %a5, 0
  %t23 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %t19, 1
  %t28 = extractvalue { i64, ptr } %t19, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t21, i64 %t22)
  %t34 = getelementptr i8, ptr %t33, i64 %t22
  call void @olang_textcopy(ptr %t34, ptr %t23, i64 %t24)
  %t35 = getelementptr i8, ptr %t34, i64 %t24
  call void @olang_textcopy(ptr %t35, ptr %t27, i64 %t28)
  %t36 = getelementptr i8, ptr %t35, i64 %t28
  call void @olang_textcopy(ptr %t36, ptr %t30, i64 %t31)
  %t37 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t33, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %a0, { i64, ptr } %t45)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fexplain_2eobligations(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v2, ptr %v1, ptr %s2, ptr %a2, i64 %t6, ptr %t16)
  store { i64, ptr } %t20, ptr %l17
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 16
  %t25 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  %t53 = extractvalue { i64, ptr } %a4, 1
  %t54 = extractvalue { i64, ptr } %a4, 0
  %t55 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t59 = extractvalue { i64, ptr } %t47, 1
  %t60 = extractvalue { i64, ptr } %t47, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = getelementptr i8, ptr %t65, i64 %t54
  call void @olang_textcopy(ptr %t66, ptr %t55, i64 %t56)
  %t67 = getelementptr i8, ptr %t66, i64 %t56
  call void @olang_textcopy(ptr %t67, ptr %t59, i64 %t60)
  %t68 = getelementptr i8, ptr %t67, i64 %t60
  call void @olang_textcopy(ptr %t68, ptr %t62, i64 %t63)
  %t69 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t65, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %a0, { i64, ptr } %t77)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb5
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fexplain_2epushPayload(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l24 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l43 = alloca i32
  %l47 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v1, ptr %v1, ptr %t4, i32 %t5)
  store ptr %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_267284e461664677_b2c2386ba62ab5d3)
  unreachable
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = call i1 @compiler_2fexplain_2ecaseWhole(ptr %v1, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l16
  br label %bb5
bb5:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l18, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  store ptr %t27, ptr %l21, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  store ptr %t33, ptr %l24, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t39 = load i64, ptr %l4, !tbaa !24
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v1, ptr %t37, i32 %t38, i64 %t39)
  store i32 %t43, ptr %l29
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = load i32, ptr %l29, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t44, i32 %t45)
  store i32 %t46, ptr %l30
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = load i32, ptr %l30, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %s1, ptr %t47, i32 %t48)
  store { i64, ptr } %t49, ptr %l31
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i32, ptr %t52, i64 0
  %t54 = load i32, ptr %t53, !tbaa !33
  %t55 = load ptr, ptr %l18, !tbaa !29
  %t57 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s1, ptr %t55, i32 %t54)
  store { i64, ptr } %t57, ptr %l34
  br label %bb11
bb11:
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t60 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = add i64 %t59, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t58, i64 %t59)
  %t65 = getelementptr i8, ptr %t64, i64 %t59
  call void @olang_textcopy(ptr %t65, ptr %t61, i64 %t62)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t64, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t75, { i64, ptr } %t74)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l37, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i32, ptr %l3, !tbaa !23
  %t84 = load i64, ptr %l4, !tbaa !24
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v1, ptr %t82, i32 %t83, i64 %t84)
  store i32 %t88, ptr %l43
  br label %bb14
bb14:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  %t96 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v1, ptr %v1, ptr %t92, i32 %t93)
  store ptr %t96, ptr %l47
  br label %bb15
bb15:
  %t97 = load ptr, ptr %l47, !tbaa !29
  store ptr %t97, ptr %l6, !tbaa !29
  %t98 = load ptr, ptr %l6, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_66f7703ccaf4f658_ca46a1b97aa24804)
  unreachable
bb17:
  br label %bb18
bb18:
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t103 = load i64, ptr %l4, !tbaa !24
  %t106 = call { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v1, ptr %s0, ptr %t102, i64 %t103)
  store { i64, ptr } %t106, ptr %l52
  br label %bb19
bb19:
  %t107 = load ptr, ptr %l38, !tbaa !29
  %t108 = load i32, ptr %l43, !tbaa !23
  %t109 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t110 = call i32 @compiler_2fexplain_2enamed(ptr %v1, ptr %s0, ptr %s0, ptr %t107, i32 %t108, ptr null, { i64, ptr } %t109)
  store i32 %t110, ptr %l53
  br label %bb20
bb20:
  %t111 = load ptr, ptr %l37, !tbaa !29
  %t112 = load i32, ptr %l53, !tbaa !23
  %t113 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v1, ptr %s0, ptr %t111, i32 %t112)
  store { i64, ptr } %t113, ptr %l54
  br label %bb21
bb21:
  %t114 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t114, ptr %l7, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l55, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = call i64 @compiler_2fexplain_2efirstClose(ptr %s0, { i64, ptr } %t116)
  store i64 %t118, ptr %l57
  br label %bb22
bb22:
  %t119 = load i64, ptr %l57, !tbaa !24
  %t120 = add i64 %t119, 1
  store i64 %t120, ptr %l58, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l59, !tbaa !24
  %t123 = icmp sge i64 2, 0
  br i1 %t123, label %bb23, label %bb24
bb23:
  %t125 = load i64, ptr %l58, !tbaa !24
  %t126 = icmp sle i64 2, %t125
  br i1 %t126, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887)
  unreachable
bb25:
  %t128 = load i64, ptr %l58, !tbaa !24
  %t129 = load i64, ptr %l59, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887)
  unreachable
bb27:
  %t132 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l58, !tbaa !24
  %t135 = getelementptr i8, ptr %t133, i64 2
  %t136 = sub i64 %t134, 2
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  %t139 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t139, { i64, ptr } %t138)
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2equoted(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb2
bb2:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb25
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t19
  %t24 = load i8, ptr %t23, !tbaa !32
  store i8 %t24, ptr %l5, !tbaa !22
  %t26 = load i8, ptr %l5, !tbaa !22
  %t28 = icmp eq i8 %t26, 34
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 92
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb12
bb11:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 10
  br i1 %t38, label %bb14, label %bb15
bb12:
  %t40 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t40)
  br label %bb13
bb13:
  br label %bb23
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d81, i32 0, i32 1) })
  br label %bb16
bb15:
  %t44 = load i8, ptr %l5, !tbaa !22
  %t46 = icmp eq i8 %t44, 9
  br i1 %t46, label %bb17, label %bb18
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d82, i32 0, i32 1) })
  br label %bb19
bb18:
  %t49 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t49)
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s7)
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb3
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb26
bb26:
  %t58 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t58, ptr %l38
  br label %bb27
bb27:
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t59, ptr %l39, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l40, !tbaa !24
  %t62 = load i64, ptr %l40, !tbaa !24
  %t63 = mul i64 %t62, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l41, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = mul i64 %t71, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t68, ptr %t70, i64 %t72, i1 false)
  %t73 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t73, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l6 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l29 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Func", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l20
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load i32, ptr %l20, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l13, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 0
  %t47 = load i32, ptr %t46, !tbaa !33
  store i32 %t47, ptr %l2, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l29
  br label %bb8
bb8:
  %t59 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t61 = trunc i64 20 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l36
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t74 = load i32, ptr %l36, !tbaa !23
  store i32 %t74, ptr %l2, !tbaa !23
  br label %bb12
bb12:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l41
  br label %bb13
bb13:
  %t85 = load i32, ptr %l41, !range !{i32 0, i32 33}
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l48, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l2, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l53
  br label %bb17
bb17:
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t110 = load i32, ptr %l53, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l54
  br label %bb18
bb18:
  %t112 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  call void @__olang_scope_close(ptr %s0)
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i64
  %l42 = alloca i32
  %l45 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l10
  br label %bb3
bb3:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %v1, ptr %t14, i32 %t15)
  store { i64, ptr } %t18, ptr %l14
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t24, ptr %l17
  br label %bb9
bb9:
  %t25 = load i32, ptr %l17, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l25
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb11
bb11:
  %t52 = load i32, ptr %l3, !tbaa !23
  store i32 %t52, ptr %l31, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l36
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t72, ptr %l41
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l20, !tbaa !29
  %t74 = load i32, ptr %l25, !tbaa !23
  %t75 = load i32, ptr %l30, !tbaa !23
  %t76 = load i32, ptr %l31, !tbaa !23
  %t77 = load i32, ptr %l36, !tbaa !23
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 %t74, i32 %t75, i32 %t76, i32 %t77, i64 %t78, i1 false, i32 0)
  store i32 %t79, ptr %l42
  br label %bb14
bb14:
  %t80 = load i32, ptr %l42, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t85 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %s0, ptr %t81, i32 %t80)
  store { i64, ptr } %t85, ptr %l45
  br label %bb15
bb15:
  %t86 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = getelementptr i8, ptr %t92, i64 %t88
  call void @olang_textcopy(ptr %t93, ptr %t89, i64 %t90)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2etraitsMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca %"compiler/names:Entry"
  %l89 = alloca i1
  %l93 = alloca %"compiler/names:Entry"
  %l100 = alloca i32
  %l105 = alloca i32
  %l109 = alloca i1
  %l111 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i32
  %l124 = alloca i1
  %l125 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca ptr
  %l139 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 1
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H1e7e683fc0332c06b6c705cd46691777(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l24, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb5:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l31, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  br label %bb53
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l9, !tbaa !24
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/names:Resolver", ptr %t67, i32 0, i32 1
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v1, ptr %v1, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l54
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l54, !tbaa !29
  store ptr %t74, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  %t75 = load ptr, ptr %l10, !tbaa !29
  %t77 = getelementptr %"compiler/names:Table", ptr %t75, i32 0, i32 0
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %t77)
  store i64 %t79, ptr %l57
  br label %bb14
bb14:
  %t80 = load i64, ptr %l57, !tbaa !24
  store i64 %t80, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t81 = load i64, ptr %l12, !tbaa !24
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb15, label %bb16
bb15:
  %t87 = load i64, ptr %l13, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb20
bb17:
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load i64, ptr %l11, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l13, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l13, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l64, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb19
bb19:
  %t107 = load i64, ptr %l64, !tbaa !24
  store i64 %t107, ptr %l61, !tbaa !24
  br label %bb20
bb20:
  %t108 = load i64, ptr %l61, !tbaa !24
  store i64 %t108, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t109 = load i64, ptr %l15, !tbaa !24
  %t110 = load i64, ptr %l14, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb23:
  br label %bb24
bb24:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l15, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t125 = add i64 %t117, %t122
  store i64 %t125, ptr %l16, !tbaa !24
  %t127 = load ptr, ptr %l10, !tbaa !29
  %t129 = getelementptr %"compiler/names:Table", ptr %t127, i32 0, i32 0
  %t130 = load i64, ptr %l16, !tbaa !24
  %t133 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %s4, ptr %t129, i64 %t130)
  store %"compiler/names:Entry" %t133, ptr %l85
  br label %bb25
bb25:
  %t134 = getelementptr %"compiler/names:Entry", ptr %l85, i32 0, i32 2
  %t135 = load i32, ptr %t134, !range !{i32 0, i32 9}
  %t137 = trunc i64 4 to i32
  %t138 = icmp eq i32 %t135, %t137
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb29
bb27:
  %t142 = load ptr, ptr %l10, !tbaa !29
  %t144 = getelementptr %"compiler/names:Table", ptr %t142, i32 0, i32 0
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %v1, ptr %t144, i64 %t145)
  store %"compiler/names:Entry" %t148, ptr %l93
  br label %bb28
bb28:
  %t149 = getelementptr %"compiler/names:Entry", ptr %l93, i32 0, i32 4
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  store i1 %t152, ptr %l89, !tbaa !21
  br label %bb29
bb29:
  %t154 = load i1, ptr %l89, !tbaa !21
  br i1 %t154, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb31:
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i64, ptr %l9, !tbaa !24
  %t160 = load i64, ptr %l16, !tbaa !24
  %t164 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v1, ptr %t158, i64 %t159, i64 %t160)
  store i32 %t164, ptr %l100
  br label %bb33
bb33:
  %t165 = load i32, ptr %l100, !tbaa !23
  store i32 %t165, ptr %l17, !tbaa !23
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  %t172 = load i32, ptr %l17, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v1, ptr %t171, i32 %t172)
  store i32 %t175, ptr %l105
  br label %bb34
bb34:
  %t176 = load i32, ptr %l105, !range !{i32 0, i32 6}
  %t178 = trunc i64 3 to i32
  %t179 = icmp eq i32 %t176, %t178
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb39
bb36:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l111, !tbaa !29
  %t187 = load i32, ptr %l17, !tbaa !23
  %t189 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t187)
  store i64 %t189, ptr %l113
  br label %bb37
bb37:
  %t190 = load ptr, ptr %l111, !tbaa !29
  %t191 = load i64, ptr %l113, !tbaa !24
  %t192 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t190, i64 %t191)
  store i64 %t192, ptr %l114
  br label %bb38
bb38:
  %t193 = load i64, ptr %l114, !tbaa !24
  %t194 = icmp sgt i64 %t193, 0
  store i1 %t194, ptr %l109, !tbaa !21
  br label %bb39
bb39:
  %t196 = load i1, ptr %l109, !tbaa !21
  br i1 %t196, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb41:
  br label %bb42
bb42:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t201 = load i32, ptr %l17, !tbaa !23
  %t204 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v1, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l119
  br label %bb43
bb43:
  %t205 = load i32, ptr %l119, !tbaa !23
  store i32 %t205, ptr %l18, !tbaa !23
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = load i32, ptr %l18, !tbaa !23
  %t215 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v1, ptr %t209, i32 %a2, i32 %t211)
  store i1 %t215, ptr %l124
  br label %bb44
bb44:
  %t216 = load i1, ptr %l124, !tbaa !21
  br i1 %t216, label %bb45, label %bb46
bb45:
  store ptr %l3, ptr %l125, !tbaa !29
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t218 = load i32, ptr %l18, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s0, ptr %t217, i32 %t218)
  store { i64, ptr } %t221, ptr %l128
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t222 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t229 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t229, { i64, ptr } %t228)
  br label %bb48
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb50:
  %t231 = load i64, ptr %l15, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l15, !tbaa !24
  br label %bb21
bb51:
  br label %bb52
bb52:
  %t235 = load i64, ptr %l8, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l8, !tbaa !24
  br label %bb9
bb53:
  %t240 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t240, ptr %l135
  br label %bb54
bb54:
  %t241 = load i64, ptr %l135, !tbaa !24
  %t242 = icmp sgt i64 %t241, 0
  br i1 %t242, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %a0, ptr %l137, !tbaa !29
  %t246 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s10, ptr %s10, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store { i64, ptr } %t246, ptr %l139
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t247 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t249 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = add i64 %t248, %t251
  %t253 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t247, i64 %t248)
  %t257 = getelementptr i8, ptr %t256, i64 %t248
  call void @olang_textcopy(ptr %t257, ptr %t250, i64 %t251)
  %t258 = getelementptr i8, ptr %t257, i64 %t251
  call void @olang_textcopy(ptr %t258, ptr %t253, i64 %t254)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t256, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } %t260, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t268 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s10, ptr %t268, { i64, ptr } %t267)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l28 = alloca i32
  %l35 = alloca i32
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 60)
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t9, i32 %a1)
  store { i64, ptr } %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb6:
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  store i32 %t33, ptr %l7, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l7, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l28
  br label %bb8
bb8:
  %t45 = load i32, ptr %l28, !range !{i32 0, i32 33}
  %t47 = trunc i64 30 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l7, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb11
bb10:
  br label %bb20
bb11:
  %t60 = load i32, ptr %l35, !tbaa !23
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l37, !tbaa !29
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb14, label %bb15
bb13:
  br label %bb19
bb14:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l7, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s4, ptr %t67, i32 %t68)
  store { i64, ptr } %t71, ptr %l43
  br label %bb17
bb17:
  %t72 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t73, i64 %t74)
  %t80 = getelementptr i8, ptr %t79, i64 %t74
  call void @olang_textcopy(ptr %t80, ptr %t76, i64 %t77)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } %t82, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  %t90 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t90, { i64, ptr } %t89)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb20:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb24:
  store ptr %l2, ptr %l49, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l7, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s2, ptr %t97, i32 %t98)
  store { i64, ptr } %t101, ptr %l52
  br label %bb25
bb25:
  %t102 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t109, { i64, ptr } %t108)
  br label %bb26
bb26:
  %t111 = load i64, ptr %l3, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t115 = load i64, ptr %l5, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l5, !tbaa !24
  br label %bb4
bb28:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 62)
  br label %bb29
bb29:
  %t121 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t121, ptr %l60
  br label %bb30
bb30:
  %t122 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t122, ptr %l61, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l62, !tbaa !24
  %t125 = load i64, ptr %l62, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l63, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l62, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t136, ptr %l61, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca %"std/prelude/text:StringBuilder"
  %l60 = alloca i32
  %l64 = alloca i1
  %l68 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l77 = alloca i64
  %l84 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l100 = alloca i32
  %l110 = alloca i1
  %l116 = alloca ptr
  %l120 = alloca i64
  %l121 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l142 = alloca i64
  %l145 = alloca i64
  %l163 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l172 = alloca i64
  %l173 = alloca { i64, ptr }
  %l177 = alloca i64
  %l178 = alloca i64
  %l191 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l201 = alloca ptr
  %l204 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l212 = alloca i64
  %l213 = alloca { i64, ptr }
  %l219 = alloca ptr
  %l223 = alloca i64
  %l229 = alloca ptr
  %l246 = alloca ptr
  %l247 = alloca i1
  %l257 = alloca ptr
  %l260 = alloca { i64, ptr }
  %l266 = alloca ptr
  %l269 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l279 = alloca i1
  %l291 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l295 = alloca { i64, ptr }
  %l298 = alloca i64
  %l301 = alloca i64
  %l302 = alloca i64
  %l307 = alloca { i64, ptr }
  %l313 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l315 = alloca i64
  %l316 = alloca { i64, ptr }
  %l319 = alloca ptr
  %l320 = alloca { i64, ptr }
  %l324 = alloca i1
  %l325 = alloca { i64, ptr }
  %l330 = alloca ptr
  %l335 = alloca i32
  %l336 = alloca { i64, ptr }
  %l341 = alloca { i64, ptr }
  %l347 = alloca i64
  %l350 = alloca i64
  %l369 = alloca ptr
  %l370 = alloca ptr
  %l376 = alloca i32
  %l377 = alloca { i64, ptr }
  %l379 = alloca ptr
  %l381 = alloca { i64, ptr }
  %l384 = alloca { i64, ptr }
  %l389 = alloca i1
  %l390 = alloca { i64, ptr }
  %l408 = alloca i32
  %l409 = alloca ptr
  %l410 = alloca { i64, ptr }
  %l414 = alloca i1
  %l415 = alloca { i64, ptr }
  %l419 = alloca i1
  %l420 = alloca { i64, ptr }
  %l425 = alloca i32
  %l428 = alloca { i64, ptr }
  %l431 = alloca { i64, ptr }
  %l434 = alloca { i64, ptr }
  %l440 = alloca ptr
  %l446 = alloca ptr
  %l447 = alloca i1
  %l455 = alloca ptr
  %l456 = alloca ptr
  %l460 = alloca i32
  %l464 = alloca i32
  %l465 = alloca { i64, ptr }
  %l467 = alloca i64
  %l468 = alloca ptr
  %l470 = alloca i64
  %l471 = alloca i64
  %l475 = alloca { i64, ptr }
  %l477 = alloca i64
  %l479 = alloca i64
  %l480 = alloca i64
  %l485 = alloca { i64, ptr }
  %l486 = alloca i64
  %l487 = alloca { i64, ptr }
  %l493 = alloca ptr
  %l494 = alloca ptr
  %l498 = alloca i32
  %l502 = alloca ptr
  %l506 = alloca { i64, ptr }
  %l507 = alloca i32
  %l508 = alloca { i64, ptr }
  %l510 = alloca i64
  %l511 = alloca ptr
  %l512 = alloca i64
  %l513 = alloca i64
  %l517 = alloca { i64, ptr }
  %l521 = alloca ptr
  %l525 = alloca { i64, ptr }
  %l529 = alloca i64
  %l530 = alloca { i64, ptr }
  %l531 = alloca ptr
  %l532 = alloca { i64, ptr }
  %l536 = alloca i1
  %l537 = alloca { i64, ptr }
  %l538 = alloca { i64, ptr }
  %l540 = alloca i64
  %l542 = alloca i64
  %l543 = alloca i64
  %l548 = alloca { i64, ptr }
  %l549 = alloca i64
  %l550 = alloca { i64, ptr }
  %l556 = alloca ptr
  %l562 = alloca ptr
  %l563 = alloca i1
  %l572 = alloca ptr
  %l573 = alloca ptr
  %l578 = alloca ptr
  %l582 = alloca i64
  %l596 = alloca { i64, ptr }
  %l597 = alloca { i64, ptr }
  %l598 = alloca i64
  %l599 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l56
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l56
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l60
  br label %bb2
bb2:
  %t11 = load i32, ptr %l60, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l64
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t23, i32 %t24)
  store ptr %t27, ptr %l68
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l68, !tbaa !29
  store ptr %t28, ptr %l4, !tbaa !29
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l2, ptr %l72, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l73, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l77
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TypeDecl", ptr %t44, i32 0, i32 4
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = load ptr, ptr %l72, !tbaa !29
  %t49 = load ptr, ptr %l73, !tbaa !29
  %t50 = load i64, ptr %l77, !tbaa !24
  call void @compiler_2fexplain_2eattrLines(ptr %s0, ptr %v0, ptr %v0, ptr %s1, ptr %t48, ptr %t49, i64 %t50, { i64, ptr } %t47, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/load:Loader", ptr %t58, i32 0, i32 3
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l5, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  store ptr %t63, ptr %l84, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l89
  br label %bb10
bb10:
  %t74 = load ptr, ptr %l84, !tbaa !29
  %t75 = load i32, ptr %l89, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t74, i32 %t75)
  store { i64, ptr } %t76, ptr %l90
  br label %bb11
bb11:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l91, !tbaa !29
  %t78 = load i32, ptr %l1, !tbaa !23
  %t80 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t78)
  store i64 %t80, ptr %l93
  br label %bb12
bb12:
  %t81 = load ptr, ptr %l91, !tbaa !29
  %t82 = load i64, ptr %l93, !tbaa !24
  %t83 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t81, i64 %t82, i64 0)
  store { i64, ptr } %t83, ptr %l94
  br label %bb13
bb13:
  %t84 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = add i64 %t86, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t85, i64 %t86)
  %t92 = getelementptr i8, ptr %t91, i64 %t86
  call void @olang_textcopy(ptr %t92, ptr %t88, i64 %t89)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t91, 1
  store { i64, ptr } %t94, ptr %l6, !tbaa !27
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l1, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l100
  br label %bb14
bb14:
  %t106 = load i32, ptr %l100, !range !{i32 0, i32 6}
  store i32 %t106, ptr %l7
  %t107 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t109 = trunc i64 5 to i32
  %t110 = icmp eq i32 %t107, %t109
  br i1 %t110, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t113 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t116 = extractvalue { i64, ptr } %t112, 1
  %t117 = extractvalue { i64, ptr } %t112, 0
  %t118 = add i64 %t114, %t117
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t121 = add i64 %t118, %t120
  %t122 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t113, i64 %t114)
  %t123 = getelementptr i8, ptr %t122, i64 %t114
  call void @olang_textcopy(ptr %t123, ptr %t116, i64 %t117)
  %t124 = getelementptr i8, ptr %t123, i64 %t117
  call void @olang_textcopy(ptr %t124, ptr %t119, i64 %t120)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t122, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t126, ptr %rv
  br label %ret
bb18:
  %t128 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t130 = trunc i64 2 to i32
  %t131 = icmp eq i32 %t128, %t130
  br i1 %t131, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb66
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load i32, ptr %l1, !tbaa !23
  %t140 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t140, ptr %l110
  br label %bb22
bb22:
  %t141 = load i1, ptr %l110, !tbaa !21
  br i1 %t141, label %bb23, label %bb24
bb23:
  %t142 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t143 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t146 = extractvalue { i64, ptr } %t142, 1
  %t147 = extractvalue { i64, ptr } %t142, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t143, i64 %t144)
  %t153 = getelementptr i8, ptr %t152, i64 %t144
  call void @olang_textcopy(ptr %t153, ptr %t146, i64 %t147)
  %t154 = getelementptr i8, ptr %t153, i64 %t147
  call void @olang_textcopy(ptr %t154, ptr %t149, i64 %t150)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t152, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t156, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 0
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/load:Loader", ptr %t164, i32 0, i32 10
  store ptr %t166, ptr %l116, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t171 = load i32, ptr %l1, !tbaa !23
  %t174 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t170, i32 %t171)
  store i64 %t174, ptr %l120
  br label %bb26
bb26:
  %t175 = load ptr, ptr %l116, !tbaa !29
  %t176 = load i64, ptr %l120, !tbaa !24
  %t177 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t175, i64 %t176)
  store ptr %t177, ptr %l121
  br label %bb27
bb27:
  %t178 = load ptr, ptr %l121, !tbaa !29
  %t180 = getelementptr %"compiler/load:Module", ptr %t178, i32 0, i32 6
  %t181 = load ptr, ptr %t180, !tbaa !29
  store ptr %t181, ptr %l8, !tbaa !29
  %t183 = load ptr, ptr %l8, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a)
  unreachable
bb29:
  br label %bb30
bb30:
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t190 = getelementptr %"compiler/source:Source", ptr %t187, i32 0, i32 1
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l9, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t194 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t197 = extractvalue { i64, ptr } %t193, 1
  %t198 = extractvalue { i64, ptr } %t193, 0
  %t199 = add i64 %t195, %t198
  %t200 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t202 = add i64 %t199, %t201
  %t203 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t202)
  call void @olang_textcopy(ptr %t203, ptr %t194, i64 %t195)
  %t204 = getelementptr i8, ptr %t203, i64 %t195
  call void @olang_textcopy(ptr %t204, ptr %t197, i64 %t198)
  %t205 = getelementptr i8, ptr %t204, i64 %t198
  call void @olang_textcopy(ptr %t205, ptr %t200, i64 %t201)
  %t206 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t203, 1
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = extractvalue { i64, ptr } %t207, 1
  %t211 = mul i64 %t209, 1
  %t212 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t211)
  call void @llvm.memcpy.p0.p0.i64(ptr %t212, ptr %t210, i64 %t211, i1 false)
  %t213 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l2, { i64, ptr } %t214)
  br label %bb31
bb31:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/check:Checker", ptr %t217, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t221 = load i32, ptr %l1, !tbaa !23
  %t224 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %s5, ptr %t220, i32 %t221)
  store { i64, ptr } %t224, ptr %l136
  br label %bb32
bb32:
  %t225 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t225, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t226 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t226, 0
  store i64 %t228, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t230 = load i64, ptr %l12, !tbaa !24
  %t231 = load i64, ptr %l11, !tbaa !24
  %t234 = icmp sgt i64 %t230, %t231
  br i1 %t234, label %bb33, label %bb34
bb33:
  %t236 = load i64, ptr %l13, !tbaa !24
  %t238 = icmp sgt i64 %t236, 0
  br i1 %t238, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l142, !tbaa !24
  br label %bb38
bb35:
  %t240 = load i64, ptr %l12, !tbaa !24
  %t241 = load i64, ptr %l11, !tbaa !24
  %t244 = sub i64 %t240, %t241
  %t245 = load i64, ptr %l13, !tbaa !24
  %t248 = add i64 %t244, %t245
  %t250 = sub i64 %t248, 1
  %t251 = load i64, ptr %l13, !tbaa !24
  %t254 = sdiv i64 %t250, %t251
  store i64 %t254, ptr %l145, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb37
bb37:
  %t256 = load i64, ptr %l145, !tbaa !24
  store i64 %t256, ptr %l142, !tbaa !24
  br label %bb38
bb38:
  %t257 = load i64, ptr %l142, !tbaa !24
  store i64 %t257, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  %t258 = load i64, ptr %l15, !tbaa !24
  %t259 = load i64, ptr %l14, !tbaa !24
  %t262 = icmp slt i64 %t258, %t259
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s10)
  br label %bb54
bb41:
  br label %bb42
bb42:
  %t266 = load i64, ptr %l11, !tbaa !24
  %t267 = load i64, ptr %l15, !tbaa !24
  %t268 = load i64, ptr %l13, !tbaa !24
  %t271 = mul i64 %t267, %t268
  %t274 = add i64 %t266, %t271
  store i64 %t274, ptr %l16, !tbaa !24
  store ptr %l2, ptr %l163, !tbaa !29
  %t276 = load i64, ptr %l16, !tbaa !24
  %t278 = icmp sgt i64 %t276, 0
  br i1 %t278, label %bb43, label %bb44
bb43:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l166, !tbaa !27
  br label %bb45
bb44:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l166, !tbaa !27
  br label %bb45
bb45:
  %t280 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t280, ptr %l167, !tbaa !27
  %t281 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t281, ptr %l168, !tbaa !27
  %t282 = load i64, ptr %l16, !tbaa !24
  %t284 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr ptr, ptr %t285, i64 %t282
  %t287 = load ptr, ptr %t286, !tbaa !39
  %t289 = getelementptr %"compiler/ast:Path", ptr %t287, i32 0, i32 0
  %t290 = getelementptr %"compiler/source:Span", ptr %t289, i32 0, i32 0
  %t291 = load i32, ptr %t290, !tbaa !23
  %t293 = sext i32 %t291 to i64
  store i64 %t293, ptr %l172, !tbaa !24
  %t294 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t294, ptr %l173, !tbaa !27
  %t295 = load i64, ptr %l16, !tbaa !24
  %t297 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = getelementptr ptr, ptr %t298, i64 %t295
  %t300 = load ptr, ptr %t299, !tbaa !39
  %t302 = getelementptr %"compiler/ast:Path", ptr %t300, i32 0, i32 0
  %t303 = getelementptr %"compiler/source:Span", ptr %t302, i32 0, i32 1
  %t304 = load i32, ptr %t303, !tbaa !23
  %t306 = sext i32 %t304 to i64
  store i64 %t306, ptr %l177, !tbaa !24
  %t307 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t308 = extractvalue { i64, ptr } %t307, 0
  store i64 %t308, ptr %l178, !tbaa !24
  %t309 = load i64, ptr %l172, !tbaa !24
  %t310 = icmp sge i64 %t309, 0
  br i1 %t310, label %bb46, label %bb47
bb46:
  %t312 = load i64, ptr %l172, !tbaa !24
  %t313 = load i64, ptr %l177, !tbaa !24
  %t314 = icmp sle i64 %t312, %t313
  br i1 %t314, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb48:
  %t316 = load i64, ptr %l177, !tbaa !24
  %t317 = load i64, ptr %l178, !tbaa !24
  %t318 = icmp sle i64 %t316, %t317
  br i1 %t318, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb50:
  %t320 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = load i64, ptr %l172, !tbaa !24
  %t323 = load i64, ptr %l177, !tbaa !24
  %t324 = getelementptr i8, ptr %t321, i64 %t322
  %t325 = sub i64 %t323, %t322
  %t326 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t324, 1
  %t328 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 1
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t332 = extractvalue { i64, ptr } %t327, 1
  %t333 = extractvalue { i64, ptr } %t327, 0
  %t334 = add i64 %t330, %t333
  %t335 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t334)
  call void @olang_textcopy(ptr %t335, ptr %t329, i64 %t330)
  %t336 = getelementptr i8, ptr %t335, i64 %t330
  call void @olang_textcopy(ptr %t336, ptr %t332, i64 %t333)
  %t337 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t335, 1
  %t340 = extractvalue { i64, ptr } %t338, 0
  %t341 = extractvalue { i64, ptr } %t338, 1
  %t342 = mul i64 %t340, 1
  %t343 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t342)
  call void @llvm.memcpy.p0.p0.i64(ptr %t343, ptr %t341, i64 %t342, i1 false)
  %t344 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  %t346 = load ptr, ptr %l163, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t346, { i64, ptr } %t345)
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb52:
  call void @__olang_scope_close(ptr %s10)
  br label %bb53
bb53:
  %t348 = load i64, ptr %l15, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l15, !tbaa !24
  br label %bb39
bb54:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s13
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/check:Checker", ptr %t353, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !29
  %t357 = load i32, ptr %l1, !tbaa !23
  %t360 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s13, ptr %t356, i32 %t357)
  store { i64, ptr } %t360, ptr %l191
  br label %bb56
bb56:
  %t361 = load { i64, ptr }, ptr %l191, !tbaa !27
  store { i64, ptr } %t361, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t362 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  store i64 %t364, ptr %l19, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s14
  %t366 = load i64, ptr %l18, !tbaa !24
  %t367 = load i64, ptr %l19, !tbaa !24
  %t370 = icmp slt i64 %t366, %t367
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s14)
  br label %bb64
bb59:
  br label %bb60
bb60:
  %t374 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t374, ptr %l198, !tbaa !27
  %t375 = load i64, ptr %l18, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr i32, ptr %t378, i64 %t375
  %t380 = load i32, ptr %t379, !tbaa !33
  store ptr %l2, ptr %l201, !tbaa !29
  %t382 = load ptr, ptr %l5, !tbaa !29
  %t386 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s14, ptr %t382, i32 %t380)
  store { i64, ptr } %t386, ptr %l204
  br label %bb61
bb61:
  %t387 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t389 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = add i64 %t388, %t391
  %t393 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t394 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t395 = add i64 %t392, %t394
  %t396 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t395)
  call void @olang_textcopy(ptr %t396, ptr %t387, i64 %t388)
  %t397 = getelementptr i8, ptr %t396, i64 %t388
  call void @olang_textcopy(ptr %t397, ptr %t390, i64 %t391)
  %t398 = getelementptr i8, ptr %t397, i64 %t391
  call void @olang_textcopy(ptr %t398, ptr %t393, i64 %t394)
  %t399 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t396, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = extractvalue { i64, ptr } %t400, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  %t408 = load ptr, ptr %l201, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %t408, { i64, ptr } %t407)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s14)
  br label %bb63
bb63:
  %t410 = load i64, ptr %l18, !tbaa !24
  %t412 = add i64 %t410, 1
  store i64 %t412, ptr %l18, !tbaa !24
  br label %bb57
bb64:
  call void @__olang_scope_close(ptr %s13)
  %t415 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t415, ptr %l210
  br label %bb65
bb65:
  %t416 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t416, ptr %l211, !tbaa !27
  %t417 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t418 = extractvalue { i64, ptr } %t417, 0
  store i64 %t418, ptr %l212, !tbaa !24
  %t419 = load i64, ptr %l212, !tbaa !24
  %t420 = mul i64 %t419, 1
  %t421 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t420)
  %t422 = insertvalue { i64, ptr } undef, i64 %t419, 0
  %t423 = insertvalue { i64, ptr } %t422, ptr %t421, 1
  store { i64, ptr } %t423, ptr %l213, !tbaa !27
  %t424 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !27
  %t428 = load i64, ptr %l212, !tbaa !24
  %t429 = mul i64 %t428, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t425, ptr %t427, i64 %t429, i1 false)
  %t430 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t430, ptr %l211, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t431 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t431, ptr %rv
  br label %ret
bb66:
  %t432 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t434 = trunc i64 3 to i32
  %t435 = icmp eq i32 %t432, %t434
  br i1 %t435, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb131
bb69:
  store %olang.scope zeroinitializer, ptr %s17
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/check:Checker", ptr %t437, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !29
  %t441 = load i32, ptr %l1, !tbaa !23
  %t444 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t440, i32 %t441)
  store ptr %t444, ptr %l219
  br label %bb70
bb70:
  %t445 = load ptr, ptr %l219, !tbaa !29
  store ptr %t445, ptr %l21, !tbaa !29
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/check:Checker", ptr %t446, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t450 = load i32, ptr %l1, !tbaa !23
  %t453 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t449, i32 %t450)
  store i64 %t453, ptr %l223
  br label %bb71
bb71:
  %t454 = load i64, ptr %l223, !tbaa !24
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/check:Checker", ptr %t455, i32 0, i32 1
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t460 = getelementptr %"compiler/generic:Program", ptr %t458, i32 0, i32 0
  %t461 = load ptr, ptr %t460, !tbaa !29
  %t463 = getelementptr %"compiler/load:Loader", ptr %t461, i32 0, i32 10
  %t467 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t463, i64 %t454)
  store ptr %t467, ptr %l229
  br label %bb72
bb72:
  %t468 = load ptr, ptr %l229, !tbaa !29
  %t470 = getelementptr %"compiler/load:Module", ptr %t468, i32 0, i32 6
  %t471 = load ptr, ptr %t470, !tbaa !29
  store ptr %t471, ptr %l23, !tbaa !29
  %t473 = load ptr, ptr %l23, !tbaa !29
  %t475 = icmp eq ptr %t473, null
  br i1 %t475, label %bb73, label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_a185ff5f85e75430_c999a61f9f0eedcc)
  unreachable
bb74:
  br label %bb75
bb75:
  %t477 = load ptr, ptr %l23, !tbaa !29
  %t480 = getelementptr %"compiler/source:Source", ptr %t477, i32 0, i32 1
  %t481 = load { i64, ptr }, ptr %t480, !tbaa !27
  store { i64, ptr } %t481, ptr %l24, !tbaa !27
  %t483 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t484 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t487 = extractvalue { i64, ptr } %t483, 1
  %t488 = extractvalue { i64, ptr } %t483, 0
  %t489 = add i64 %t485, %t488
  %t490 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t491 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t492 = add i64 %t489, %t491
  %t493 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t492)
  call void @olang_textcopy(ptr %t493, ptr %t484, i64 %t485)
  %t494 = getelementptr i8, ptr %t493, i64 %t485
  call void @olang_textcopy(ptr %t494, ptr %t487, i64 %t488)
  %t495 = getelementptr i8, ptr %t494, i64 %t488
  call void @olang_textcopy(ptr %t495, ptr %t490, i64 %t491)
  %t496 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t493, 1
  %t499 = extractvalue { i64, ptr } %t497, 0
  %t500 = extractvalue { i64, ptr } %t497, 1
  %t501 = mul i64 %t499, 1
  %t502 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t501)
  call void @llvm.memcpy.p0.p0.i64(ptr %t502, ptr %t500, i64 %t501, i1 false)
  %t503 = insertvalue { i64, ptr } undef, i64 %t499, 0
  %t504 = insertvalue { i64, ptr } %t503, ptr %t502, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %l2, { i64, ptr } %t504)
  br label %bb76
bb76:
  %t507 = load ptr, ptr %l21, !tbaa !29
  %t509 = icmp eq ptr %t507, null
  br i1 %t509, label %bb77, label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_60d3429e949e0f0f_c9b6e73225d64a3b)
  unreachable
bb78:
  br label %bb79
bb79:
  %t511 = load ptr, ptr %l21, !tbaa !29
  %t514 = getelementptr %"compiler/ast:TypeDecl", ptr %t511, i32 0, i32 3
  %t515 = load ptr, ptr %t514, !tbaa !29
  store ptr %t515, ptr %l25, !tbaa !29
  %t517 = load ptr, ptr %l25, !tbaa !29
  store ptr %t517, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t518 = load ptr, ptr %l246, !tbaa !29
  %t519 = icmp ne ptr %t518, null
  br i1 %t519, label %bb80, label %bb81
bb80:
  %t521 = load ptr, ptr %l246, !tbaa !29
  %t522 = load i64, ptr %t521, !range !{i64 0, i64 5}
  %t524 = icmp eq i64 %t522, 2
  store i1 %t524, ptr %l247, !tbaa !21
  br label %bb81
bb81:
  %t525 = load i1, ptr %l247, !tbaa !21
  br i1 %t525, label %bb82, label %bb83
bb82:
  %t526 = load ptr, ptr %l25, !tbaa !29
  %t528 = getelementptr { i64, [6 x i64] }, ptr %t526, i32 0, i32 1
  %t529 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t528, i32 0, i32 1
  %t530 = load { i64, ptr }, ptr %t529
  store { i64, ptr } %t530, ptr %l26, !tbaa !27
  %t532 = load ptr, ptr %l25, !tbaa !29
  %t534 = getelementptr { i64, [6 x i64] }, ptr %t532, i32 0, i32 1
  %t535 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t534, i32 0, i32 2
  %t536 = load { i64, ptr }, ptr %t535
  store { i64, ptr } %t536, ptr %l27, !tbaa !27
  br label %bb84
bb83:
  br label %bb95
bb84:
  %t538 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t538, 0
  %t542 = icmp sgt i64 %t540, 0
  br i1 %t542, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s20
  store ptr %l2, ptr %l257, !tbaa !29
  %t544 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t545 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t548 = call { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v0, ptr %s20, { i64, ptr } %t544, { i64, ptr } %t545)
  store { i64, ptr } %t548, ptr %l260
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t549 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t550 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t551 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t551, 1
  %t553 = extractvalue { i64, ptr } %t551, 0
  %t554 = add i64 %t550, %t553
  %t555 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t554)
  call void @olang_textcopy(ptr %t555, ptr %t549, i64 %t550)
  %t556 = getelementptr i8, ptr %t555, i64 %t550
  call void @olang_textcopy(ptr %t556, ptr %t552, i64 %t553)
  %t557 = insertvalue { i64, ptr } undef, i64 %t554, 0
  %t558 = insertvalue { i64, ptr } %t557, ptr %t555, 1
  %t560 = extractvalue { i64, ptr } %t558, 0
  %t561 = extractvalue { i64, ptr } %t558, 1
  %t562 = mul i64 %t560, 1
  %t563 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t562)
  call void @llvm.memcpy.p0.p0.i64(ptr %t563, ptr %t561, i64 %t562, i1 false)
  %t564 = insertvalue { i64, ptr } undef, i64 %t560, 0
  %t565 = insertvalue { i64, ptr } %t564, ptr %t563, 1
  %t566 = load ptr, ptr %l257, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %t566, { i64, ptr } %t565)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s20)
  br label %bb89
bb89:
  %t568 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t570 = extractvalue { i64, ptr } %t568, 0
  %t572 = icmp sgt i64 %t570, 0
  br i1 %t572, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s22
  store ptr %l2, ptr %l266, !tbaa !29
  %t574 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t575 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t578 = call { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v0, ptr %s22, { i64, ptr } %t574, { i64, ptr } %t575)
  store { i64, ptr } %t578, ptr %l269
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t579 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t580 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t581 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t582 = extractvalue { i64, ptr } %t581, 1
  %t583 = extractvalue { i64, ptr } %t581, 0
  %t584 = add i64 %t580, %t583
  %t585 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t584)
  call void @olang_textcopy(ptr %t585, ptr %t579, i64 %t580)
  %t586 = getelementptr i8, ptr %t585, i64 %t580
  call void @olang_textcopy(ptr %t586, ptr %t582, i64 %t583)
  %t587 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t588 = insertvalue { i64, ptr } %t587, ptr %t585, 1
  %t590 = extractvalue { i64, ptr } %t588, 0
  %t591 = extractvalue { i64, ptr } %t588, 1
  %t592 = mul i64 %t590, 1
  %t593 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t592)
  call void @llvm.memcpy.p0.p0.i64(ptr %t593, ptr %t591, i64 %t592, i1 false)
  %t594 = insertvalue { i64, ptr } undef, i64 %t590, 0
  %t595 = insertvalue { i64, ptr } %t594, ptr %t593, 1
  %t596 = load ptr, ptr %l266, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %t596, { i64, ptr } %t595)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s22)
  br label %bb94
bb94:
  br label %bb100
bb95:
  br i1 true, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_9e7f77c067ece8f1_2a0afb54e00d35)
  unreachable
bb100:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) })
  br label %bb101
bb101:
  %t599 = load ptr, ptr %l21, !tbaa !29
  %t601 = icmp eq ptr %t599, null
  br i1 %t601, label %bb102, label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_7b101762ff8ffda9_ced5d247097fb61d)
  unreachable
bb103:
  br label %bb104
bb104:
  %t603 = load ptr, ptr %l21, !tbaa !29
  %t606 = getelementptr %"compiler/ast:TypeDecl", ptr %t603, i32 0, i32 3
  %t607 = load ptr, ptr %t606, !tbaa !29
  store ptr %t607, ptr %l28, !tbaa !29
  %t609 = load ptr, ptr %l28, !tbaa !29
  store ptr %t609, ptr %l278, !tbaa !29
  store i1 false, ptr %l279, !tbaa !21
  %t610 = load ptr, ptr %l278, !tbaa !29
  %t611 = icmp ne ptr %t610, null
  br i1 %t611, label %bb105, label %bb106
bb105:
  %t613 = load ptr, ptr %l278, !tbaa !29
  %t614 = load i64, ptr %t613, !range !{i64 0, i64 5}
  %t616 = icmp eq i64 %t614, 2
  store i1 %t616, ptr %l279, !tbaa !21
  br label %bb106
bb106:
  %t617 = load i1, ptr %l279, !tbaa !21
  br i1 %t617, label %bb107, label %bb108
bb107:
  %t618 = load ptr, ptr %l28, !tbaa !29
  %t620 = getelementptr { i64, [6 x i64] }, ptr %t618, i32 0, i32 1
  %t621 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t620, i32 0, i32 0
  %t622 = load { i64, ptr }, ptr %t621
  store { i64, ptr } %t622, ptr %l29, !tbaa !27
  br label %bb109
bb108:
  br label %bb124
bb109:
  %t624 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t624, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t626 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t628 = extractvalue { i64, ptr } %t626, 0
  store i64 %t628, ptr %l32, !tbaa !24
  br label %bb110
bb110:
  store %olang.scope zeroinitializer, ptr %s27
  %t630 = load i64, ptr %l31, !tbaa !24
  %t631 = load i64, ptr %l32, !tbaa !24
  %t634 = icmp slt i64 %t630, %t631
  %t636 = xor i1 %t634, true
  br i1 %t636, label %bb111, label %bb112
bb111:
  call void @__olang_scope_close(ptr %s27)
  br label %bb123
bb112:
  br label %bb113
bb113:
  %t638 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t638, ptr %l291, !tbaa !27
  %t639 = load i64, ptr %l31, !tbaa !24
  %t641 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t642 = load ptr, ptr %t641, !tbaa !27
  %t643 = getelementptr ptr, ptr %t642, i64 %t639
  %t644 = load ptr, ptr %t643, !tbaa !39
  store ptr %t644, ptr %l33, !tbaa !29
  store ptr %l2, ptr %l294, !tbaa !29
  %t646 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t646, ptr %l295, !tbaa !27
  %t647 = load ptr, ptr %l33, !tbaa !29
  %t649 = getelementptr %"compiler/ast:Func", ptr %t647, i32 0, i32 0
  %t650 = getelementptr %"compiler/source:Span", ptr %t649, i32 0, i32 0
  %t651 = load i32, ptr %t650, !tbaa !23
  %t653 = sext i32 %t651 to i64
  store i64 %t653, ptr %l298, !tbaa !24
  %t654 = load ptr, ptr %l33, !tbaa !29
  %t656 = getelementptr %"compiler/ast:Func", ptr %t654, i32 0, i32 0
  %t657 = getelementptr %"compiler/source:Span", ptr %t656, i32 0, i32 1
  %t658 = load i32, ptr %t657, !tbaa !23
  %t660 = sext i32 %t658 to i64
  store i64 %t660, ptr %l301, !tbaa !24
  %t661 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t662 = extractvalue { i64, ptr } %t661, 0
  store i64 %t662, ptr %l302, !tbaa !24
  %t663 = load i64, ptr %l298, !tbaa !24
  %t664 = icmp sge i64 %t663, 0
  br i1 %t664, label %bb114, label %bb115
bb114:
  %t666 = load i64, ptr %l298, !tbaa !24
  %t667 = load i64, ptr %l301, !tbaa !24
  %t668 = icmp sle i64 %t666, %t667
  br i1 %t668, label %bb116, label %bb117
bb115:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb116:
  %t670 = load i64, ptr %l301, !tbaa !24
  %t671 = load i64, ptr %l302, !tbaa !24
  %t672 = icmp sle i64 %t670, %t671
  br i1 %t672, label %bb118, label %bb119
bb117:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb118:
  %t674 = getelementptr { i64, ptr }, ptr %l295, i32 0, i32 1
  %t675 = load ptr, ptr %t674, !tbaa !27
  %t676 = load i64, ptr %l298, !tbaa !24
  %t677 = load i64, ptr %l301, !tbaa !24
  %t678 = getelementptr i8, ptr %t675, i64 %t676
  %t679 = sub i64 %t677, %t676
  %t680 = insertvalue { i64, ptr } undef, i64 %t679, 0
  %t681 = insertvalue { i64, ptr } %t680, ptr %t678, 1
  %t683 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s27, { i64, ptr } %t681)
  store { i64, ptr } %t683, ptr %l307
  br label %bb120
bb119:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb120:
  %t684 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t685 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t686 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t687 = extractvalue { i64, ptr } %t686, 1
  %t688 = extractvalue { i64, ptr } %t686, 0
  %t689 = add i64 %t685, %t688
  %t690 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t691 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t692 = add i64 %t689, %t691
  %t693 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t692)
  call void @olang_textcopy(ptr %t693, ptr %t684, i64 %t685)
  %t694 = getelementptr i8, ptr %t693, i64 %t685
  call void @olang_textcopy(ptr %t694, ptr %t687, i64 %t688)
  %t695 = getelementptr i8, ptr %t694, i64 %t688
  call void @olang_textcopy(ptr %t695, ptr %t690, i64 %t691)
  %t696 = insertvalue { i64, ptr } undef, i64 %t692, 0
  %t697 = insertvalue { i64, ptr } %t696, ptr %t693, 1
  %t699 = extractvalue { i64, ptr } %t697, 0
  %t700 = extractvalue { i64, ptr } %t697, 1
  %t701 = mul i64 %t699, 1
  %t702 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t701)
  call void @llvm.memcpy.p0.p0.i64(ptr %t702, ptr %t700, i64 %t701, i1 false)
  %t703 = insertvalue { i64, ptr } undef, i64 %t699, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t702, 1
  %t705 = load ptr, ptr %l294, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %t705, { i64, ptr } %t704)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s27)
  br label %bb122
bb122:
  %t707 = load i64, ptr %l31, !tbaa !24
  %t709 = add i64 %t707, 1
  store i64 %t709, ptr %l31, !tbaa !24
  br label %bb110
bb123:
  br label %bb129
bb124:
  br i1 true, label %bb125, label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  call void @__olang_check_failed(ptr @olang_loc_4e8cd845c965dada_c1eb458e34ff6f7e)
  unreachable
bb129:
  %t712 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t712, ptr %l313
  br label %bb130
bb130:
  %t713 = load { i64, ptr }, ptr %l313, !tbaa !27
  store { i64, ptr } %t713, ptr %l314, !tbaa !27
  %t714 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t715 = extractvalue { i64, ptr } %t714, 0
  store i64 %t715, ptr %l315, !tbaa !24
  %t716 = load i64, ptr %l315, !tbaa !24
  %t717 = mul i64 %t716, 1
  %t718 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t717)
  %t719 = insertvalue { i64, ptr } undef, i64 %t716, 0
  %t720 = insertvalue { i64, ptr } %t719, ptr %t718, 1
  store { i64, ptr } %t720, ptr %l316, !tbaa !27
  %t721 = getelementptr { i64, ptr }, ptr %l316, i32 0, i32 1
  %t722 = load ptr, ptr %t721, !tbaa !27
  %t723 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t724 = load ptr, ptr %t723, !tbaa !27
  %t725 = load i64, ptr %l315, !tbaa !24
  %t726 = mul i64 %t725, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t722, ptr %t724, i64 %t726, i1 false)
  %t727 = load { i64, ptr }, ptr %l316, !tbaa !27
  store { i64, ptr } %t727, ptr %l314, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t728 = load { i64, ptr }, ptr %l314, !tbaa !27
  store { i64, ptr } %t728, ptr %rv
  br label %ret
bb131:
  %t729 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t731 = trunc i64 1 to i32
  %t732 = icmp eq i32 %t729, %t731
  br i1 %t732, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb169
bb134:
  store %olang.scope zeroinitializer, ptr %s31
  store ptr %l2, ptr %l319, !tbaa !29
  %t734 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t734, ptr %l320, !tbaa !27
  %t735 = load ptr, ptr %l0, !tbaa !29
  %t737 = getelementptr %"compiler/check:Checker", ptr %t735, i32 0, i32 1
  %t738 = load ptr, ptr %t737, !tbaa !29
  %t739 = load i32, ptr %l3, !tbaa !23
  %t742 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t738, i32 %t739)
  store i1 %t742, ptr %l324
  br label %bb135
bb135:
  %t743 = load i1, ptr %l324, !tbaa !21
  br i1 %t743, label %bb136, label %bb137
bb136:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d109, i32 0, i32 1) }, ptr %l325, !tbaa !27
  br label %bb138
bb137:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d110, i32 0, i32 1) }, ptr %l325, !tbaa !27
  br label %bb138
bb138:
  %t744 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t745 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t746 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t747 = extractvalue { i64, ptr } %t746, 1
  %t748 = extractvalue { i64, ptr } %t746, 0
  %t749 = add i64 %t745, %t748
  %t750 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t751 = extractvalue { i64, ptr } %t750, 1
  %t752 = extractvalue { i64, ptr } %t750, 0
  %t753 = add i64 %t749, %t752
  %t754 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t755 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t756 = add i64 %t753, %t755
  %t757 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t756)
  call void @olang_textcopy(ptr %t757, ptr %t744, i64 %t745)
  %t758 = getelementptr i8, ptr %t757, i64 %t745
  call void @olang_textcopy(ptr %t758, ptr %t747, i64 %t748)
  %t759 = getelementptr i8, ptr %t758, i64 %t748
  call void @olang_textcopy(ptr %t759, ptr %t751, i64 %t752)
  %t760 = getelementptr i8, ptr %t759, i64 %t752
  call void @olang_textcopy(ptr %t760, ptr %t754, i64 %t755)
  %t761 = insertvalue { i64, ptr } undef, i64 %t756, 0
  %t762 = insertvalue { i64, ptr } %t761, ptr %t757, 1
  %t764 = extractvalue { i64, ptr } %t762, 0
  %t765 = extractvalue { i64, ptr } %t762, 1
  %t766 = mul i64 %t764, 1
  %t767 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t766)
  call void @llvm.memcpy.p0.p0.i64(ptr %t767, ptr %t765, i64 %t766, i1 false)
  %t768 = insertvalue { i64, ptr } undef, i64 %t764, 0
  %t769 = insertvalue { i64, ptr } %t768, ptr %t767, 1
  %t770 = load ptr, ptr %l319, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s31, ptr %t770, { i64, ptr } %t769)
  br label %bb139
bb139:
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t774 = getelementptr %"compiler/check:Checker", ptr %t772, i32 0, i32 1
  %t775 = load ptr, ptr %t774, !tbaa !29
  %t777 = getelementptr %"compiler/generic:Program", ptr %t775, i32 0, i32 2
  store ptr %t777, ptr %l330, !tbaa !29
  %t778 = load ptr, ptr %l0, !tbaa !29
  %t780 = getelementptr %"compiler/check:Checker", ptr %t778, i32 0, i32 1
  %t781 = load ptr, ptr %t780, !tbaa !29
  %t783 = getelementptr %"compiler/generic:Program", ptr %t781, i32 0, i32 2
  %t784 = load i32, ptr %l3, !tbaa !23
  %t787 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t783, i32 %t784)
  store i32 %t787, ptr %l335
  br label %bb140
bb140:
  %t788 = load ptr, ptr %l330, !tbaa !29
  %t789 = load i32, ptr %l335, !tbaa !23
  %t790 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t788, i32 %t789)
  store { i64, ptr } %t790, ptr %l336
  br label %bb141
bb141:
  %t791 = load { i64, ptr }, ptr %l336, !tbaa !27
  store { i64, ptr } %t791, ptr %l34, !tbaa !27
  %t792 = load ptr, ptr %l0, !tbaa !29
  %t794 = getelementptr %"compiler/check:Checker", ptr %t792, i32 0, i32 1
  %t795 = load ptr, ptr %t794, !tbaa !29
  %t797 = getelementptr %"compiler/generic:Program", ptr %t795, i32 0, i32 2
  %t798 = load i32, ptr %l3, !tbaa !23
  %t801 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s31, ptr %t797, i32 %t798)
  store { i64, ptr } %t801, ptr %l341
  br label %bb142
bb142:
  %t802 = load { i64, ptr }, ptr %l341, !tbaa !27
  store { i64, ptr } %t802, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t803 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t805 = extractvalue { i64, ptr } %t803, 0
  store i64 %t805, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t807 = load i64, ptr %l37, !tbaa !24
  %t808 = load i64, ptr %l36, !tbaa !24
  %t811 = icmp sgt i64 %t807, %t808
  br i1 %t811, label %bb143, label %bb144
bb143:
  %t813 = load i64, ptr %l38, !tbaa !24
  %t815 = icmp sgt i64 %t813, 0
  br i1 %t815, label %bb145, label %bb146
bb144:
  store i64 0, ptr %l347, !tbaa !24
  br label %bb148
bb145:
  %t817 = load i64, ptr %l37, !tbaa !24
  %t818 = load i64, ptr %l36, !tbaa !24
  %t821 = sub i64 %t817, %t818
  %t822 = load i64, ptr %l38, !tbaa !24
  %t825 = add i64 %t821, %t822
  %t827 = sub i64 %t825, 1
  %t828 = load i64, ptr %l38, !tbaa !24
  %t831 = sdiv i64 %t827, %t828
  store i64 %t831, ptr %l350, !tbaa !24
  br label %bb147
bb146:
  store i64 0, ptr %l350, !tbaa !24
  br label %bb147
bb147:
  %t833 = load i64, ptr %l350, !tbaa !24
  store i64 %t833, ptr %l347, !tbaa !24
  br label %bb148
bb148:
  %t834 = load i64, ptr %l347, !tbaa !24
  store i64 %t834, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb149
bb149:
  store %olang.scope zeroinitializer, ptr %s34
  %t835 = load i64, ptr %l40, !tbaa !24
  %t836 = load i64, ptr %l39, !tbaa !24
  %t839 = icmp slt i64 %t835, %t836
  %t841 = xor i1 %t839, true
  br i1 %t841, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s34)
  br label %bb168
bb151:
  br label %bb152
bb152:
  %t843 = load i64, ptr %l36, !tbaa !24
  %t844 = load i64, ptr %l40, !tbaa !24
  %t845 = load i64, ptr %l38, !tbaa !24
  %t848 = mul i64 %t844, %t845
  %t851 = add i64 %t843, %t848
  store i64 %t851, ptr %l41, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s34, ptr %l2, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb153
bb153:
  store ptr %l2, ptr %l369, !tbaa !29
  %t854 = load ptr, ptr %l0, !tbaa !29
  store ptr %t854, ptr %l370, !tbaa !29
  %t855 = load ptr, ptr %l0, !tbaa !29
  %t857 = getelementptr %"compiler/check:Checker", ptr %t855, i32 0, i32 1
  %t858 = load ptr, ptr %t857, !tbaa !29
  %t859 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t860 = load i32, ptr %l3, !tbaa !23
  %t861 = load i64, ptr %l41, !tbaa !24
  %t866 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %t858, i64 %t859, i32 %t860, i64 %t861, i64 0)
  store i32 %t866, ptr %l376
  br label %bb154
bb154:
  %t867 = load ptr, ptr %l370, !tbaa !29
  %t868 = load i32, ptr %l376, !tbaa !23
  %t869 = call { i64, ptr } @compiler_2fexplain_2eattrsBefore(ptr %v0, ptr %s34, ptr %t867, i32 %t868)
  store { i64, ptr } %t869, ptr %l377
  br label %bb155
bb155:
  %t870 = load { i64, ptr }, ptr %l377, !tbaa !27
  %t871 = extractvalue { i64, ptr } %t870, 0
  %t872 = extractvalue { i64, ptr } %t870, 1
  %t873 = mul i64 %t871, 1
  %t874 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t873)
  call void @llvm.memcpy.p0.p0.i64(ptr %t874, ptr %t872, i64 %t873, i1 false)
  %t875 = insertvalue { i64, ptr } undef, i64 %t871, 0
  %t876 = insertvalue { i64, ptr } %t875, ptr %t874, 1
  %t877 = load ptr, ptr %l369, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s34, ptr %t877, { i64, ptr } %t876)
  br label %bb156
bb156:
  store ptr %l2, ptr %l379, !tbaa !29
  %t879 = load ptr, ptr %l5, !tbaa !29
  %t880 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t880, ptr %l381, !tbaa !27
  %t881 = load i64, ptr %l41, !tbaa !24
  %t883 = getelementptr { i64, ptr }, ptr %l381, i32 0, i32 1
  %t884 = load ptr, ptr %t883, !tbaa !27
  %t885 = getelementptr i32, ptr %t884, i64 %t881
  %t886 = load i32, ptr %t885, !tbaa !33
  %t889 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t879, i32 %t886)
  store { i64, ptr } %t889, ptr %l384
  br label %bb157
bb157:
  %t890 = load ptr, ptr %l379, !tbaa !29
  %t891 = load { i64, ptr }, ptr %l384, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t890, { i64, ptr } %t891)
  br label %bb158
bb158:
  %t892 = load i64, ptr %l41, !tbaa !24
  %t893 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t895 = extractvalue { i64, ptr } %t893, 0
  %t898 = icmp slt i64 %t892, %t895
  br i1 %t898, label %bb159, label %bb160
bb159:
  %t900 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t900, ptr %l390, !tbaa !27
  %t901 = load i64, ptr %l41, !tbaa !24
  %t903 = getelementptr { i64, ptr }, ptr %l390, i32 0, i32 1
  %t904 = load ptr, ptr %t903, !tbaa !27
  %t905 = getelementptr i32, ptr %t904, i64 %t901
  %t906 = load i32, ptr %t905, !tbaa !33
  %t908 = icmp ne i32 %t906, 0
  store i1 %t908, ptr %l389, !tbaa !21
  br label %bb161
bb160:
  store i1 false, ptr %l389, !tbaa !21
  br label %bb161
bb161:
  %t910 = load i1, ptr %l389, !tbaa !21
  br i1 %t910, label %bb162, label %bb163
bb162:
  %t911 = load ptr, ptr %l0, !tbaa !29
  %t912 = load i32, ptr %l1, !tbaa !23
  %t913 = load i32, ptr %l3, !tbaa !23
  %t914 = load i64, ptr %l41, !tbaa !24
  call void @compiler_2fexplain_2epushPayload(ptr %s0, ptr %v0, ptr %l2, ptr %t911, i32 %t912, i32 %t913, i64 %t914)
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb165
bb165:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s34)
  br label %bb167
bb167:
  %t921 = load i64, ptr %l40, !tbaa !24
  %t923 = add i64 %t921, 1
  store i64 %t923, ptr %l40, !tbaa !24
  br label %bb149
bb168:
  call void @__olang_scope_close(ptr %s31)
  br label %bb288
bb169:
  %t925 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t927 = trunc i64 4 to i32
  %t928 = icmp eq i32 %t925, %t927
  br i1 %t928, label %bb170, label %bb171
bb170:
  br label %bb172
bb171:
  br label %bb225
bb172:
  store %olang.scope zeroinitializer, ptr %s37
  %t930 = load ptr, ptr %l0, !tbaa !29
  %t932 = getelementptr %"compiler/check:Checker", ptr %t930, i32 0, i32 1
  %t933 = load ptr, ptr %t932, !tbaa !29
  %t935 = getelementptr %"compiler/generic:Program", ptr %t933, i32 0, i32 2
  %t936 = load i32, ptr %l3, !tbaa !23
  %t939 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t935, i32 %t936)
  store i32 %t939, ptr %l408
  br label %bb173
bb173:
  %t940 = load i32, ptr %l408, !tbaa !23
  store i32 %t940, ptr %l42, !tbaa !23
  store ptr %l2, ptr %l409, !tbaa !29
  %t941 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t941, ptr %l410, !tbaa !27
  %t942 = load ptr, ptr %l0, !tbaa !29
  %t944 = getelementptr %"compiler/check:Checker", ptr %t942, i32 0, i32 1
  %t945 = load ptr, ptr %t944, !tbaa !29
  %t946 = load i32, ptr %l3, !tbaa !23
  %t949 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t945, i32 %t946)
  store i1 %t949, ptr %l414
  br label %bb174
bb174:
  %t950 = load i1, ptr %l414, !tbaa !21
  br i1 %t950, label %bb175, label %bb176
bb175:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %l415, !tbaa !27
  br label %bb177
bb176:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d115, i32 0, i32 1) }, ptr %l415, !tbaa !27
  br label %bb177
bb177:
  %t951 = load ptr, ptr %l0, !tbaa !29
  %t953 = getelementptr %"compiler/check:Checker", ptr %t951, i32 0, i32 1
  %t954 = load ptr, ptr %t953, !tbaa !29
  %t955 = load i32, ptr %l3, !tbaa !23
  %t958 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t954, i32 %t955)
  store i1 %t958, ptr %l419
  br label %bb178
bb178:
  %t959 = load i1, ptr %l419, !tbaa !21
  br i1 %t959, label %bb179, label %bb180
bb179:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d116, i32 0, i32 1) }, ptr %l420, !tbaa !27
  br label %bb181
bb180:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, ptr %l420, !tbaa !27
  br label %bb181
bb181:
  %t960 = load ptr, ptr %l0, !tbaa !29
  %t962 = getelementptr %"compiler/check:Checker", ptr %t960, i32 0, i32 1
  %t963 = load ptr, ptr %t962, !tbaa !29
  %t965 = getelementptr %"compiler/generic:Program", ptr %t963, i32 0, i32 2
  %t966 = load i32, ptr %l42, !tbaa !23
  %t969 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t965, i32 %t966)
  store i32 %t969, ptr %l425
  br label %bb182
bb182:
  %t970 = load i32, ptr %l425, !range !{i32 0, i32 33}
  %t972 = trunc i64 21 to i32
  %t973 = icmp eq i32 %t970, %t972
  br i1 %t973, label %bb183, label %bb184
bb183:
  %t975 = load ptr, ptr %l0, !tbaa !29
  %t976 = load i32, ptr %l42, !tbaa !23
  %t979 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %s37, ptr %t975, i32 %t976)
  store { i64, ptr } %t979, ptr %l431
  br label %bb185
bb184:
  %t980 = load ptr, ptr %l0, !tbaa !29
  %t981 = load i32, ptr %l42, !tbaa !23
  %t984 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s37, ptr %t980, i32 %t981)
  store { i64, ptr } %t984, ptr %l434
  br label %bb186
bb185:
  %t985 = load { i64, ptr }, ptr %l431, !tbaa !27
  store { i64, ptr } %t985, ptr %l428, !tbaa !27
  br label %bb187
bb186:
  %t986 = load { i64, ptr }, ptr %l434, !tbaa !27
  store { i64, ptr } %t986, ptr %l428, !tbaa !27
  br label %bb187
bb187:
  %t987 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t988 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t989 = load { i64, ptr }, ptr %l410, !tbaa !27
  %t990 = extractvalue { i64, ptr } %t989, 1
  %t991 = extractvalue { i64, ptr } %t989, 0
  %t992 = add i64 %t988, %t991
  %t993 = load { i64, ptr }, ptr %l415, !tbaa !27
  %t994 = extractvalue { i64, ptr } %t993, 1
  %t995 = extractvalue { i64, ptr } %t993, 0
  %t996 = add i64 %t992, %t995
  %t997 = load { i64, ptr }, ptr %l420, !tbaa !27
  %t998 = extractvalue { i64, ptr } %t997, 1
  %t999 = extractvalue { i64, ptr } %t997, 0
  %t1000 = add i64 %t996, %t999
  %t1001 = load { i64, ptr }, ptr %l428, !tbaa !27
  %t1002 = extractvalue { i64, ptr } %t1001, 1
  %t1003 = extractvalue { i64, ptr } %t1001, 0
  %t1004 = add i64 %t1000, %t1003
  %t1005 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1004)
  call void @olang_textcopy(ptr %t1005, ptr %t987, i64 %t988)
  %t1006 = getelementptr i8, ptr %t1005, i64 %t988
  call void @olang_textcopy(ptr %t1006, ptr %t990, i64 %t991)
  %t1007 = getelementptr i8, ptr %t1006, i64 %t991
  call void @olang_textcopy(ptr %t1007, ptr %t994, i64 %t995)
  %t1008 = getelementptr i8, ptr %t1007, i64 %t995
  call void @olang_textcopy(ptr %t1008, ptr %t998, i64 %t999)
  %t1009 = getelementptr i8, ptr %t1008, i64 %t999
  call void @olang_textcopy(ptr %t1009, ptr %t1002, i64 %t1003)
  %t1010 = insertvalue { i64, ptr } undef, i64 %t1004, 0
  %t1011 = insertvalue { i64, ptr } %t1010, ptr %t1005, 1
  %t1013 = extractvalue { i64, ptr } %t1011, 0
  %t1014 = extractvalue { i64, ptr } %t1011, 1
  %t1015 = mul i64 %t1013, 1
  %t1016 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1015)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1016, ptr %t1014, i64 %t1015, i1 false)
  %t1017 = insertvalue { i64, ptr } undef, i64 %t1013, 0
  %t1018 = insertvalue { i64, ptr } %t1017, ptr %t1016, 1
  %t1019 = load ptr, ptr %l409, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s37, ptr %t1019, { i64, ptr } %t1018)
  br label %bb188
bb188:
  %t1021 = load ptr, ptr %l0, !tbaa !29
  %t1023 = getelementptr %"compiler/check:Checker", ptr %t1021, i32 0, i32 1
  %t1024 = load ptr, ptr %t1023, !tbaa !29
  %t1025 = load i32, ptr %l1, !tbaa !23
  %t1028 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t1024, i32 %t1025)
  store ptr %t1028, ptr %l440
  br label %bb189
bb189:
  %t1029 = load ptr, ptr %l440, !tbaa !29
  store ptr %t1029, ptr %l43, !tbaa !29
  %t1030 = load ptr, ptr %l43, !tbaa !29
  %t1032 = icmp eq ptr %t1030, null
  br i1 %t1032, label %bb190, label %bb191
bb190:
  call void @__olang_check_failed(ptr @olang_loc_12615553f525a8d6_4928bb51d62e2722)
  unreachable
bb191:
  br label %bb192
bb192:
  %t1034 = load ptr, ptr %l43, !tbaa !29
  %t1037 = getelementptr %"compiler/ast:TypeDecl", ptr %t1034, i32 0, i32 3
  %t1038 = load ptr, ptr %t1037, !tbaa !29
  store ptr %t1038, ptr %l44, !tbaa !29
  %t1040 = load ptr, ptr %l44, !tbaa !29
  store ptr %t1040, ptr %l446, !tbaa !29
  store i1 false, ptr %l447, !tbaa !21
  %t1041 = load ptr, ptr %l446, !tbaa !29
  %t1042 = icmp ne ptr %t1041, null
  br i1 %t1042, label %bb193, label %bb194
bb193:
  %t1044 = load ptr, ptr %l446, !tbaa !29
  %t1045 = load i64, ptr %t1044, !range !{i64 0, i64 5}
  %t1047 = icmp eq i64 %t1045, 3
  store i1 %t1047, ptr %l447, !tbaa !21
  br label %bb194
bb194:
  %t1048 = load i1, ptr %l447, !tbaa !21
  br i1 %t1048, label %bb195, label %bb196
bb195:
  %t1049 = load ptr, ptr %l44, !tbaa !29
  %t1051 = getelementptr { i64, [6 x i64] }, ptr %t1049, i32 0, i32 1
  %t1052 = getelementptr { ptr, ptr }, ptr %t1051, i32 0, i32 1
  %t1053 = load ptr, ptr %t1052
  store ptr %t1053, ptr %l45, !tbaa !29
  br label %bb197
bb196:
  br label %bb218
bb197:
  %t1055 = load ptr, ptr %l45, !tbaa !29
  %t1057 = icmp eq ptr %t1055, null
  %t1059 = xor i1 %t1057, true
  br i1 %t1059, label %bb198, label %bb199
bb198:
  store %olang.scope zeroinitializer, ptr %s39
  %t1061 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1061, ptr %l455, !tbaa !29
  %t1062 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1062, ptr %l456, !tbaa !29
  %t1063 = load ptr, ptr %l0, !tbaa !29
  %t1065 = getelementptr %"compiler/check:Checker", ptr %t1063, i32 0, i32 1
  %t1066 = load ptr, ptr %t1065, !tbaa !29
  %t1067 = load i32, ptr %l3, !tbaa !23
  %t1070 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t1066, i32 %t1067)
  store i32 %t1070, ptr %l460
  br label %bb200
bb199:
  br label %bb218
bb200:
  %t1071 = load ptr, ptr %l45, !tbaa !29
  %t1073 = getelementptr %"compiler/ast:Func", ptr %t1071, i32 0, i32 3
  %t1074 = load ptr, ptr %t1073, !tbaa !29
  %t1076 = getelementptr %"compiler/ast:Sig", ptr %t1074, i32 0, i32 0
  %t1077 = load { i64, ptr }, ptr %t1076, !tbaa !27
  %t1078 = load ptr, ptr %l456, !tbaa !29
  %t1079 = load i32, ptr %l460, !tbaa !23
  %t1081 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s39, ptr %v0, ptr %t1078, i32 %t1079, ptr null, { i64, ptr } %t1077)
  store i32 %t1081, ptr %l464
  br label %bb201
bb201:
  %t1082 = load ptr, ptr %l455, !tbaa !29
  %t1083 = load i32, ptr %l464, !tbaa !23
  %t1084 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %s39, ptr %t1082, i32 %t1083)
  store { i64, ptr } %t1084, ptr %l465
  br label %bb202
bb202:
  %t1085 = load { i64, ptr }, ptr %l465, !tbaa !27
  store { i64, ptr } %t1085, ptr %l46, !tbaa !27
  %t1086 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1088 = call i64 @compiler_2fexplain_2efirstClose(ptr %s39, { i64, ptr } %t1086)
  store i64 %t1088, ptr %l467
  br label %bb203
bb203:
  %t1089 = load i64, ptr %l467, !tbaa !24
  store i64 %t1089, ptr %l47, !tbaa !24
  store ptr %l2, ptr %l468, !tbaa !29
  %t1090 = load i64, ptr %l47, !tbaa !24
  %t1092 = add i64 %t1090, 1
  store i64 %t1092, ptr %l470, !tbaa !24
  %t1093 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1094 = extractvalue { i64, ptr } %t1093, 0
  store i64 %t1094, ptr %l471, !tbaa !24
  %t1095 = icmp sge i64 2, 0
  br i1 %t1095, label %bb204, label %bb205
bb204:
  %t1097 = load i64, ptr %l470, !tbaa !24
  %t1098 = icmp sle i64 2, %t1097
  br i1 %t1098, label %bb206, label %bb207
bb205:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb206:
  %t1100 = load i64, ptr %l470, !tbaa !24
  %t1101 = load i64, ptr %l471, !tbaa !24
  %t1102 = icmp sle i64 %t1100, %t1101
  br i1 %t1102, label %bb208, label %bb209
bb207:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb208:
  %t1104 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t1105 = load ptr, ptr %t1104, !tbaa !27
  %t1106 = load i64, ptr %l470, !tbaa !24
  %t1107 = getelementptr i8, ptr %t1105, i64 2
  %t1108 = sub i64 %t1106, 2
  %t1109 = insertvalue { i64, ptr } undef, i64 %t1108, 0
  %t1110 = insertvalue { i64, ptr } %t1109, ptr %t1107, 1
  store { i64, ptr } %t1110, ptr %l475, !tbaa !27
  %t1111 = load i64, ptr %l47, !tbaa !24
  %t1113 = add i64 %t1111, 1
  store i64 %t1113, ptr %l477, !tbaa !24
  %t1114 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1116 = extractvalue { i64, ptr } %t1114, 0
  store i64 %t1116, ptr %l479, !tbaa !24
  %t1117 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1118 = extractvalue { i64, ptr } %t1117, 0
  store i64 %t1118, ptr %l480, !tbaa !24
  %t1119 = load i64, ptr %l477, !tbaa !24
  %t1120 = icmp sge i64 %t1119, 0
  br i1 %t1120, label %bb210, label %bb211
bb209:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb210:
  %t1122 = load i64, ptr %l477, !tbaa !24
  %t1123 = load i64, ptr %l479, !tbaa !24
  %t1124 = icmp sle i64 %t1122, %t1123
  br i1 %t1124, label %bb212, label %bb213
bb211:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb212:
  %t1126 = load i64, ptr %l479, !tbaa !24
  %t1127 = load i64, ptr %l480, !tbaa !24
  %t1128 = icmp sle i64 %t1126, %t1127
  br i1 %t1128, label %bb214, label %bb215
bb213:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb214:
  %t1130 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t1131 = load ptr, ptr %t1130, !tbaa !27
  %t1132 = load i64, ptr %l477, !tbaa !24
  %t1133 = load i64, ptr %l479, !tbaa !24
  %t1134 = getelementptr i8, ptr %t1131, i64 %t1132
  %t1135 = sub i64 %t1133, %t1132
  %t1136 = insertvalue { i64, ptr } undef, i64 %t1135, 0
  %t1137 = insertvalue { i64, ptr } %t1136, ptr %t1134, 1
  %t1139 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s39, ptr %s39, { i64, ptr } %t1137)
  store { i64, ptr } %t1139, ptr %l485
  br label %bb216
bb215:
  call void @__olang_check_failed(ptr @olang_loc_d47c24bdc65fe2cb_f786417b6ea94537)
  unreachable
bb216:
  %t1140 = load { i64, ptr }, ptr %l485, !tbaa !27
  %t1141 = extractvalue { i64, ptr } %t1140, 0
  store i64 %t1141, ptr %l486, !tbaa !24
  %t1142 = load i64, ptr %l486, !tbaa !24
  %t1143 = mul i64 %t1142, 1
  %t1144 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1143)
  %t1145 = insertvalue { i64, ptr } undef, i64 %t1142, 0
  %t1146 = insertvalue { i64, ptr } %t1145, ptr %t1144, 1
  store { i64, ptr } %t1146, ptr %l487, !tbaa !27
  %t1147 = getelementptr { i64, ptr }, ptr %l487, i32 0, i32 1
  %t1148 = load ptr, ptr %t1147, !tbaa !27
  %t1149 = getelementptr { i64, ptr }, ptr %l485, i32 0, i32 1
  %t1150 = load ptr, ptr %t1149, !tbaa !27
  %t1151 = load i64, ptr %l486, !tbaa !24
  %t1152 = mul i64 %t1151, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1148, ptr %t1150, i64 %t1152, i1 false)
  %t1153 = load { i64, ptr }, ptr %l475, !tbaa !27
  %t1154 = extractvalue { i64, ptr } %t1153, 1
  %t1155 = extractvalue { i64, ptr } %t1153, 0
  %t1156 = load { i64, ptr }, ptr %l487, !tbaa !27
  %t1157 = extractvalue { i64, ptr } %t1156, 1
  %t1158 = extractvalue { i64, ptr } %t1156, 0
  %t1159 = add i64 %t1155, %t1158
  %t1160 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1159)
  call void @olang_textcopy(ptr %t1160, ptr %t1154, i64 %t1155)
  %t1161 = getelementptr i8, ptr %t1160, i64 %t1155
  call void @olang_textcopy(ptr %t1161, ptr %t1157, i64 %t1158)
  %t1162 = insertvalue { i64, ptr } undef, i64 %t1159, 0
  %t1163 = insertvalue { i64, ptr } %t1162, ptr %t1160, 1
  %t1165 = extractvalue { i64, ptr } %t1163, 0
  %t1166 = extractvalue { i64, ptr } %t1163, 1
  %t1167 = mul i64 %t1165, 1
  %t1168 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1168, ptr %t1166, i64 %t1167, i1 false)
  %t1169 = insertvalue { i64, ptr } undef, i64 %t1165, 0
  %t1170 = insertvalue { i64, ptr } %t1169, ptr %t1168, 1
  %t1171 = load ptr, ptr %l468, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %t1171, { i64, ptr } %t1170)
  br label %bb217
bb217:
  call void @__olang_scope_close(ptr %s39)
  br label %bb223
bb218:
  br i1 true, label %bb219, label %bb220
bb219:
  br label %bb221
bb220:
  br label %bb222
bb221:
  br label %bb223
bb222:
  call void @__olang_check_failed(ptr @olang_loc_6531017cd55dbf94_87ab3d542028c5d8)
  unreachable
bb223:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb224
bb224:
  call void @__olang_scope_close(ptr %s37)
  br label %bb288
bb225:
  %t1174 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t1176 = trunc i64 0 to i32
  %t1177 = icmp eq i32 %t1174, %t1176
  br i1 %t1177, label %bb226, label %bb227
bb226:
  br label %bb228
bb227:
  br label %bb287
bb228:
  store %olang.scope zeroinitializer, ptr %s42
  %t1179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1179, ptr %l493, !tbaa !29
  %t1180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1180, ptr %l494, !tbaa !29
  %t1181 = load ptr, ptr %l0, !tbaa !29
  %t1183 = getelementptr %"compiler/check:Checker", ptr %t1181, i32 0, i32 1
  %t1184 = load ptr, ptr %t1183, !tbaa !29
  %t1185 = load i32, ptr %l3, !tbaa !23
  %t1188 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t1184, i32 %t1185)
  store i32 %t1188, ptr %l498
  br label %bb229
bb229:
  %t1189 = load ptr, ptr %l0, !tbaa !29
  %t1191 = getelementptr %"compiler/check:Checker", ptr %t1189, i32 0, i32 1
  %t1192 = load ptr, ptr %t1191, !tbaa !29
  %t1193 = load i32, ptr %l1, !tbaa !23
  %t1196 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t1192, i32 %t1193)
  store ptr %t1196, ptr %l502
  br label %bb230
bb230:
  %t1197 = load ptr, ptr %l502, !tbaa !29
  store ptr %t1197, ptr %l48, !tbaa !29
  %t1198 = load ptr, ptr %l48, !tbaa !29
  %t1200 = icmp eq ptr %t1198, null
  br i1 %t1200, label %bb231, label %bb232
bb231:
  call void @__olang_check_failed(ptr @olang_loc_fdc41c6a76f01a06_9680a398378cbf4a)
  unreachable
bb232:
  br label %bb233
bb233:
  %t1202 = load ptr, ptr %l48, !tbaa !29
  %t1204 = call { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %s42, ptr %t1202)
  store { i64, ptr } %t1204, ptr %l506
  br label %bb234
bb234:
  %t1205 = load ptr, ptr %l494, !tbaa !29
  %t1206 = load i32, ptr %l498, !tbaa !23
  %t1207 = load { i64, ptr }, ptr %l506, !tbaa !27
  %t1208 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s42, ptr %s42, ptr %t1205, i32 %t1206, ptr null, { i64, ptr } %t1207)
  store i32 %t1208, ptr %l507
  br label %bb235
bb235:
  %t1209 = load ptr, ptr %l493, !tbaa !29
  %t1210 = load i32, ptr %l507, !tbaa !23
  %t1211 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %s42, ptr %t1209, i32 %t1210)
  store { i64, ptr } %t1211, ptr %l508
  br label %bb236
bb236:
  %t1212 = load { i64, ptr }, ptr %l508, !tbaa !27
  store { i64, ptr } %t1212, ptr %l49, !tbaa !27
  %t1213 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1215 = call i64 @compiler_2fexplain_2efirstClose(ptr %s42, { i64, ptr } %t1213)
  store i64 %t1215, ptr %l510
  br label %bb237
bb237:
  %t1216 = load i64, ptr %l510, !tbaa !24
  store i64 %t1216, ptr %l50, !tbaa !24
  %t1217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1217, ptr %l511, !tbaa !29
  %t1218 = load i64, ptr %l50, !tbaa !24
  store i64 %t1218, ptr %l512, !tbaa !24
  %t1219 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1220 = extractvalue { i64, ptr } %t1219, 0
  store i64 %t1220, ptr %l513, !tbaa !24
  %t1221 = icmp sge i64 3, 0
  br i1 %t1221, label %bb238, label %bb239
bb238:
  %t1223 = load i64, ptr %l512, !tbaa !24
  %t1224 = icmp sle i64 3, %t1223
  br i1 %t1224, label %bb240, label %bb241
bb239:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb240:
  %t1226 = load i64, ptr %l512, !tbaa !24
  %t1227 = load i64, ptr %l513, !tbaa !24
  %t1228 = icmp sle i64 %t1226, %t1227
  br i1 %t1228, label %bb242, label %bb243
bb241:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb242:
  %t1230 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t1231 = load ptr, ptr %t1230, !tbaa !27
  %t1232 = load i64, ptr %l512, !tbaa !24
  %t1233 = getelementptr i8, ptr %t1231, i64 3
  %t1234 = sub i64 %t1232, 3
  %t1235 = insertvalue { i64, ptr } undef, i64 %t1234, 0
  %t1236 = insertvalue { i64, ptr } %t1235, ptr %t1233, 1
  store { i64, ptr } %t1236, ptr %l517, !tbaa !27
  %t1237 = load ptr, ptr %l0, !tbaa !29
  %t1239 = getelementptr %"compiler/check:Checker", ptr %t1237, i32 0, i32 1
  %t1240 = load ptr, ptr %t1239, !tbaa !29
  %t1241 = load i32, ptr %l1, !tbaa !23
  %t1244 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t1240, i32 %t1241)
  store ptr %t1244, ptr %l521
  br label %bb244
bb243:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb244:
  %t1245 = load ptr, ptr %l521, !tbaa !29
  store ptr %t1245, ptr %l51, !tbaa !29
  %t1246 = load ptr, ptr %l51, !tbaa !29
  %t1248 = icmp eq ptr %t1246, null
  br i1 %t1248, label %bb245, label %bb246
bb245:
  call void @__olang_check_failed(ptr @olang_loc_5a4859640df0add8_178cc34ee3f1765c)
  unreachable
bb246:
  br label %bb247
bb247:
  %t1250 = load ptr, ptr %l51, !tbaa !29
  %t1252 = call { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %s42, ptr %t1250)
  store { i64, ptr } %t1252, ptr %l525
  br label %bb248
bb248:
  %t1253 = load ptr, ptr %l0, !tbaa !29
  %t1255 = getelementptr %"compiler/check:Checker", ptr %t1253, i32 0, i32 1
  %t1256 = load ptr, ptr %t1255, !tbaa !29
  %t1257 = load i32, ptr %l1, !tbaa !23
  %t1260 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t1256, i32 %t1257)
  store i64 %t1260, ptr %l529
  br label %bb249
bb249:
  %t1261 = load ptr, ptr %l511, !tbaa !29
  %t1262 = load { i64, ptr }, ptr %l517, !tbaa !27
  %t1263 = load { i64, ptr }, ptr %l525, !tbaa !27
  %t1264 = load i64, ptr %l529, !tbaa !24
  %t1265 = call { i64, ptr } @compiler_2fexplain_2ewithDefaults(ptr %v0, ptr %s42, ptr %s42, ptr %s42, ptr %t1261, { i64, ptr } %t1262, { i64, ptr } %t1263, i64 %t1264, i64 0)
  store { i64, ptr } %t1265, ptr %l530
  br label %bb250
bb250:
  %t1266 = load { i64, ptr }, ptr %l530, !tbaa !27
  store { i64, ptr } %t1266, ptr %l52, !tbaa !27
  store ptr %l2, ptr %l531, !tbaa !29
  %t1267 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t1267, ptr %l532, !tbaa !27
  %t1268 = load ptr, ptr %l0, !tbaa !29
  %t1270 = getelementptr %"compiler/check:Checker", ptr %t1268, i32 0, i32 1
  %t1271 = load ptr, ptr %t1270, !tbaa !29
  %t1272 = load i32, ptr %l3, !tbaa !23
  %t1275 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t1271, i32 %t1272)
  store i1 %t1275, ptr %l536
  br label %bb251
bb251:
  %t1276 = load i1, ptr %l536, !tbaa !21
  br i1 %t1276, label %bb252, label %bb253
bb252:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d119, i32 0, i32 1) }, ptr %l537, !tbaa !27
  br label %bb254
bb253:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d120, i32 0, i32 1) }, ptr %l537, !tbaa !27
  br label %bb254
bb254:
  %t1277 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t1277, ptr %l538, !tbaa !27
  %t1278 = load i64, ptr %l50, !tbaa !24
  %t1280 = add i64 %t1278, 1
  store i64 %t1280, ptr %l540, !tbaa !24
  %t1281 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1283 = extractvalue { i64, ptr } %t1281, 0
  store i64 %t1283, ptr %l542, !tbaa !24
  %t1284 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1285 = extractvalue { i64, ptr } %t1284, 0
  store i64 %t1285, ptr %l543, !tbaa !24
  %t1286 = load i64, ptr %l540, !tbaa !24
  %t1287 = icmp sge i64 %t1286, 0
  br i1 %t1287, label %bb255, label %bb256
bb255:
  %t1289 = load i64, ptr %l540, !tbaa !24
  %t1290 = load i64, ptr %l542, !tbaa !24
  %t1291 = icmp sle i64 %t1289, %t1290
  br i1 %t1291, label %bb257, label %bb258
bb256:
  call void @__olang_check_failed(ptr @olang_loc_731041b9517c977f_a1670725ff3ccc5b)
  unreachable
bb257:
  %t1293 = load i64, ptr %l542, !tbaa !24
  %t1294 = load i64, ptr %l543, !tbaa !24
  %t1295 = icmp sle i64 %t1293, %t1294
  br i1 %t1295, label %bb259, label %bb260
bb258:
  call void @__olang_check_failed(ptr @olang_loc_731041b9517c977f_a1670725ff3ccc5b)
  unreachable
bb259:
  %t1297 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t1298 = load ptr, ptr %t1297, !tbaa !27
  %t1299 = load i64, ptr %l540, !tbaa !24
  %t1300 = load i64, ptr %l542, !tbaa !24
  %t1301 = getelementptr i8, ptr %t1298, i64 %t1299
  %t1302 = sub i64 %t1300, %t1299
  %t1303 = insertvalue { i64, ptr } undef, i64 %t1302, 0
  %t1304 = insertvalue { i64, ptr } %t1303, ptr %t1301, 1
  %t1306 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s42, ptr %s42, { i64, ptr } %t1304)
  store { i64, ptr } %t1306, ptr %l548
  br label %bb261
bb260:
  call void @__olang_check_failed(ptr @olang_loc_731041b9517c977f_a1670725ff3ccc5b)
  unreachable
bb261:
  %t1307 = load { i64, ptr }, ptr %l548, !tbaa !27
  %t1308 = extractvalue { i64, ptr } %t1307, 0
  store i64 %t1308, ptr %l549, !tbaa !24
  %t1309 = load i64, ptr %l549, !tbaa !24
  %t1310 = mul i64 %t1309, 1
  %t1311 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t1310)
  %t1312 = insertvalue { i64, ptr } undef, i64 %t1309, 0
  %t1313 = insertvalue { i64, ptr } %t1312, ptr %t1311, 1
  store { i64, ptr } %t1313, ptr %l550, !tbaa !27
  %t1314 = getelementptr { i64, ptr }, ptr %l550, i32 0, i32 1
  %t1315 = load ptr, ptr %t1314, !tbaa !27
  %t1316 = getelementptr { i64, ptr }, ptr %l548, i32 0, i32 1
  %t1317 = load ptr, ptr %t1316, !tbaa !27
  %t1318 = load i64, ptr %l549, !tbaa !24
  %t1319 = mul i64 %t1318, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1315, ptr %t1317, i64 %t1319, i1 false)
  %t1320 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t1321 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t1322 = load { i64, ptr }, ptr %l532, !tbaa !27
  %t1323 = extractvalue { i64, ptr } %t1322, 1
  %t1324 = extractvalue { i64, ptr } %t1322, 0
  %t1325 = add i64 %t1321, %t1324
  %t1326 = load { i64, ptr }, ptr %l537, !tbaa !27
  %t1327 = extractvalue { i64, ptr } %t1326, 1
  %t1328 = extractvalue { i64, ptr } %t1326, 0
  %t1329 = add i64 %t1325, %t1328
  %t1330 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t1331 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t1332 = add i64 %t1329, %t1331
  %t1333 = load { i64, ptr }, ptr %l538, !tbaa !27
  %t1334 = extractvalue { i64, ptr } %t1333, 1
  %t1335 = extractvalue { i64, ptr } %t1333, 0
  %t1336 = add i64 %t1332, %t1335
  %t1337 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t1338 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t1339 = add i64 %t1336, %t1338
  %t1340 = load { i64, ptr }, ptr %l550, !tbaa !27
  %t1341 = extractvalue { i64, ptr } %t1340, 1
  %t1342 = extractvalue { i64, ptr } %t1340, 0
  %t1343 = add i64 %t1339, %t1342
  %t1344 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t1345 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t1346 = add i64 %t1343, %t1345
  %t1347 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t1346)
  call void @olang_textcopy(ptr %t1347, ptr %t1320, i64 %t1321)
  %t1348 = getelementptr i8, ptr %t1347, i64 %t1321
  call void @olang_textcopy(ptr %t1348, ptr %t1323, i64 %t1324)
  %t1349 = getelementptr i8, ptr %t1348, i64 %t1324
  call void @olang_textcopy(ptr %t1349, ptr %t1327, i64 %t1328)
  %t1350 = getelementptr i8, ptr %t1349, i64 %t1328
  call void @olang_textcopy(ptr %t1350, ptr %t1330, i64 %t1331)
  %t1351 = getelementptr i8, ptr %t1350, i64 %t1331
  call void @olang_textcopy(ptr %t1351, ptr %t1334, i64 %t1335)
  %t1352 = getelementptr i8, ptr %t1351, i64 %t1335
  call void @olang_textcopy(ptr %t1352, ptr %t1337, i64 %t1338)
  %t1353 = getelementptr i8, ptr %t1352, i64 %t1338
  call void @olang_textcopy(ptr %t1353, ptr %t1341, i64 %t1342)
  %t1354 = getelementptr i8, ptr %t1353, i64 %t1342
  call void @olang_textcopy(ptr %t1354, ptr %t1344, i64 %t1345)
  %t1355 = insertvalue { i64, ptr } undef, i64 %t1346, 0
  %t1356 = insertvalue { i64, ptr } %t1355, ptr %t1347, 1
  %t1358 = extractvalue { i64, ptr } %t1356, 0
  %t1359 = extractvalue { i64, ptr } %t1356, 1
  %t1360 = mul i64 %t1358, 1
  %t1361 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t1360)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1361, ptr %t1359, i64 %t1360, i1 false)
  %t1362 = insertvalue { i64, ptr } undef, i64 %t1358, 0
  %t1363 = insertvalue { i64, ptr } %t1362, ptr %t1361, 1
  %t1364 = load ptr, ptr %l531, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s42, ptr %t1364, { i64, ptr } %t1363)
  br label %bb262
bb262:
  %t1366 = load ptr, ptr %l0, !tbaa !29
  %t1368 = getelementptr %"compiler/check:Checker", ptr %t1366, i32 0, i32 1
  %t1369 = load ptr, ptr %t1368, !tbaa !29
  %t1370 = load i32, ptr %l1, !tbaa !23
  %t1373 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t1369, i32 %t1370)
  store ptr %t1373, ptr %l556
  br label %bb263
bb263:
  %t1374 = load ptr, ptr %l556, !tbaa !29
  store ptr %t1374, ptr %l53, !tbaa !29
  %t1375 = load ptr, ptr %l53, !tbaa !29
  %t1377 = icmp eq ptr %t1375, null
  br i1 %t1377, label %bb264, label %bb265
bb264:
  call void @__olang_check_failed(ptr @olang_loc_b306a27fe8c8780a_4c00da05a7c42646)
  unreachable
bb265:
  br label %bb266
bb266:
  %t1379 = load ptr, ptr %l53, !tbaa !29
  %t1382 = getelementptr %"compiler/ast:TypeDecl", ptr %t1379, i32 0, i32 3
  %t1383 = load ptr, ptr %t1382, !tbaa !29
  store ptr %t1383, ptr %l54, !tbaa !29
  %t1385 = load ptr, ptr %l54, !tbaa !29
  store ptr %t1385, ptr %l562, !tbaa !29
  store i1 false, ptr %l563, !tbaa !21
  %t1386 = load ptr, ptr %l562, !tbaa !29
  %t1387 = icmp ne ptr %t1386, null
  br i1 %t1387, label %bb267, label %bb268
bb267:
  %t1389 = load ptr, ptr %l562, !tbaa !29
  %t1390 = load i64, ptr %t1389, !range !{i64 0, i64 5}
  %t1392 = icmp eq i64 %t1390, 0
  store i1 %t1392, ptr %l563, !tbaa !21
  br label %bb268
bb268:
  %t1393 = load i1, ptr %l563, !tbaa !21
  br i1 %t1393, label %bb269, label %bb270
bb269:
  %t1394 = load ptr, ptr %l54, !tbaa !29
  %t1396 = getelementptr { i64, [6 x i64] }, ptr %t1394, i32 0, i32 1
  %t1397 = getelementptr { ptr }, ptr %t1396, i32 0, i32 0
  %t1398 = load ptr, ptr %t1397
  store ptr %t1398, ptr %l55, !tbaa !29
  br label %bb271
bb270:
  br label %bb280
bb271:
  %t1400 = load ptr, ptr %l55, !tbaa !29
  %t1402 = getelementptr %"compiler/ast:StructBody", ptr %t1400, i32 0, i32 1
  %t1403 = load ptr, ptr %t1402, !tbaa !29
  %t1405 = icmp eq ptr %t1403, null
  %t1407 = xor i1 %t1405, true
  br i1 %t1407, label %bb272, label %bb273
bb272:
  store %olang.scope zeroinitializer, ptr %s45
  store ptr %l2, ptr %l572, !tbaa !29
  %t1409 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1409, ptr %l573, !tbaa !29
  %t1410 = load ptr, ptr %l55, !tbaa !29
  %t1412 = getelementptr %"compiler/ast:StructBody", ptr %t1410, i32 0, i32 1
  %t1413 = load ptr, ptr %t1412, !tbaa !29
  %t1415 = icmp eq ptr %t1413, null
  br i1 %t1415, label %bb274, label %bb275
bb273:
  br label %bb279
bb274:
  call void @__olang_check_failed(ptr @olang_loc_5d61f9982e85490b_19b97e7dc205ed37)
  unreachable
bb275:
  br label %bb276
bb276:
  %t1417 = load ptr, ptr %l55, !tbaa !29
  %t1419 = getelementptr %"compiler/ast:StructBody", ptr %t1417, i32 0, i32 1
  %t1420 = load ptr, ptr %t1419, !tbaa !29
  store ptr %t1420, ptr %l578, !tbaa !29
  %t1421 = load ptr, ptr %l0, !tbaa !29
  %t1423 = getelementptr %"compiler/check:Checker", ptr %t1421, i32 0, i32 1
  %t1424 = load ptr, ptr %t1423, !tbaa !29
  %t1425 = load i32, ptr %l1, !tbaa !23
  %t1428 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t1424, i32 %t1425)
  store i64 %t1428, ptr %l582
  br label %bb277
bb277:
  %t1429 = load ptr, ptr %l572, !tbaa !29
  %t1430 = load ptr, ptr %l573, !tbaa !29
  %t1431 = load ptr, ptr %l578, !tbaa !29
  %t1432 = load i64, ptr %l582, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s45, ptr %t1429, ptr %t1430, ptr %t1431, i64 %t1432, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d125, i32 0, i32 1) })
  br label %bb278
bb278:
  call void @__olang_scope_close(ptr %s45)
  br label %bb279
bb279:
  br label %bb285
bb280:
  br i1 true, label %bb281, label %bb282
bb281:
  br label %bb283
bb282:
  br label %bb284
bb283:
  br label %bb285
bb284:
  call void @__olang_check_failed(ptr @olang_loc_3df602fba2cf8b3_3b7d9b6ebe07120f)
  unreachable
bb285:
  %t1433 = load ptr, ptr %l0, !tbaa !29
  %t1434 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2efields(ptr %s0, ptr %v0, ptr %l2, ptr %t1433, i32 %t1434)
  br label %bb286
bb286:
  call void @__olang_scope_close(ptr %s42)
  br label %bb288
bb287:
  call void @__olang_check_failed(ptr @olang_loc_94295b17b6f8c92c_4d0fd7ff7c3c10d0)
  unreachable
bb288:
  %t1438 = load ptr, ptr %l0, !tbaa !29
  %t1439 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fexplain_2ebuilders(ptr %s0, ptr %v0, ptr %l2, ptr %t1438, i32 %t1439)
  br label %bb289
bb289:
  %t1443 = load ptr, ptr %l0, !tbaa !29
  %t1444 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2emethods(ptr %s0, ptr %v0, ptr %l2, ptr %t1443, i32 %t1444)
  br label %bb290
bb290:
  %t1448 = load ptr, ptr %l0, !tbaa !29
  %t1449 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2etraitsMet(ptr %s0, ptr %v0, ptr %l2, ptr %t1448, i32 %t1449)
  br label %bb291
bb291:
  %t1454 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t1454, ptr %l596
  br label %bb292
bb292:
  %t1455 = load { i64, ptr }, ptr %l596, !tbaa !27
  store { i64, ptr } %t1455, ptr %l597, !tbaa !27
  %t1456 = load { i64, ptr }, ptr %l597, !tbaa !27
  %t1457 = extractvalue { i64, ptr } %t1456, 0
  store i64 %t1457, ptr %l598, !tbaa !24
  %t1458 = load i64, ptr %l598, !tbaa !24
  %t1459 = mul i64 %t1458, 1
  %t1460 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1459)
  %t1461 = insertvalue { i64, ptr } undef, i64 %t1458, 0
  %t1462 = insertvalue { i64, ptr } %t1461, ptr %t1460, 1
  store { i64, ptr } %t1462, ptr %l599, !tbaa !27
  %t1463 = getelementptr { i64, ptr }, ptr %l599, i32 0, i32 1
  %t1464 = load ptr, ptr %t1463, !tbaa !27
  %t1465 = getelementptr { i64, ptr }, ptr %l597, i32 0, i32 1
  %t1466 = load ptr, ptr %t1465, !tbaa !27
  %t1467 = load i64, ptr %l598, !tbaa !24
  %t1468 = mul i64 %t1467, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1464, ptr %t1466, i64 %t1468, i1 false)
  %t1469 = load { i64, ptr }, ptr %l599, !tbaa !27
  store { i64, ptr } %t1469, ptr %l597, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t1470 = load { i64, ptr }, ptr %l597, !tbaa !27
  store { i64, ptr } %t1470, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %a2)
  store i32 %t19, ptr %l12
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l5, !tbaa !29
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t20, i64 %t21, i32 %t22)
  store i64 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load i64, ptr %l13, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i32 -1, ptr %l16, !tbaa !23
  br label %bb6
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t38 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t32, i64 %t33, i64 %t34)
  store i32 %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = load i32, ptr %l21, !tbaa !23
  store i32 %t39, ptr %l16, !tbaa !23
  br label %bb6
bb6:
  %t40 = load i32, ptr %l16, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:varRow"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca i64
  %l37 = alloca i64
  %l59 = alloca %"compiler/generic:varRow"
  %l64 = alloca i1
  %l65 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l130 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l19
  br label %bb1
bb1:
  %t9 = load i64, ptr %l19, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sle i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t16, ptr %l24, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l25, !tbaa !24
  %t19 = load i64, ptr %l25, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l26, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l25, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t30, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t32 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t32, ptr %l27
  br label %bb5
bb5:
  %t33 = load %"std/prelude/text:StringBuilder", ptr %l27
  store %"std/prelude/text:StringBuilder" %t33, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 60)
  br label %bb6
bb6:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l37, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  br label %bb51
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t94 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t88, i64 %t89, i64 %t90)
  store %"compiler/generic:varRow" %t94, ptr %l59
  br label %bb17
bb17:
  %t95 = load %"compiler/generic:varRow", ptr %l59
  store %"compiler/generic:varRow" %t95, ptr %l11
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i64, ptr %l1, !tbaa !24
  %t101 = load i64, ptr %l10, !tbaa !24
  %t105 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %t99, i64 %t100, i64 %t101)
  store i1 %t105, ptr %l64
  br label %bb18
bb18:
  %t106 = load i1, ptr %l64, !tbaa !21
  br i1 %t106, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l4, ptr %l65, !tbaa !29
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l2, !tbaa !24
  %t111 = icmp sgt i64 %t107, %t108
  br i1 %t111, label %bb21, label %bb22
bb20:
  br label %bb26
bb21:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d127, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb23
bb23:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/load:Loader", ptr %t119, i32 0, i32 3
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t123 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 1
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s4, ptr %t122, i32 %t124)
  store { i64, ptr } %t127, ptr %l75
  br label %bb24
bb24:
  %t128 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = add i64 %t130, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t129, i64 %t130)
  %t136 = getelementptr i8, ptr %t135, i64 %t130
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t146 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t146, { i64, ptr } %t145)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb26:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t149 = load i64, ptr %l2, !tbaa !24
  %t152 = icmp sgt i64 %t148, %t149
  br i1 %t152, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l4, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d129, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  store ptr %l4, ptr %l82, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/generic:Program", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/load:Loader", ptr %t161, i32 0, i32 3
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t165 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 1
  %t166 = load i32, ptr %t165, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t164, i32 %t166)
  store { i64, ptr } %t169, ptr %l88
  br label %bb31
bb31:
  %t170 = load ptr, ptr %l82, !tbaa !29
  %t171 = load { i64, ptr }, ptr %l88, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t170, { i64, ptr } %t171)
  br label %bb32
bb32:
  %t172 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t173 = load i32, ptr %t172, !tbaa !23
  %t174 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t177 = icmp ne i32 %t173, %t174
  br i1 %t177, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l4, ptr %l92, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t181 = load i32, ptr %t180, !tbaa !23
  %t184 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s7, ptr %t179, i32 %t181)
  store { i64, ptr } %t184, ptr %l95
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t185 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t187 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = add i64 %t186, %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t185, i64 %t186)
  %t192 = getelementptr i8, ptr %t191, i64 %t186
  call void @olang_textcopy(ptr %t192, ptr %t188, i64 %t189)
  %t193 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t191, 1
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t197 = extractvalue { i64, ptr } %t194, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  %t202 = load ptr, ptr %l92, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t202, { i64, ptr } %t201)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  %t204 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t205 = load i32, ptr %t204, !tbaa !23
  %t206 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t209 = icmp ne i32 %t205, %t206
  br i1 %t209, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t216 = load i32, ptr %t215, !tbaa !23
  %t219 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %s10, ptr %t214, i32 %t216)
  store { i64, ptr } %t219, ptr %l104
  br label %bb40
bb39:
  br label %bb49
bb40:
  %t220 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  %t222 = extractvalue { i64, ptr } %t220, 1
  %t223 = mul i64 %t221, 4
  %t224 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t223)
  call void @llvm.memcpy.p0.p0.i64(ptr %t224, ptr %t222, i64 %t223, i1 false)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  store { i64, ptr } %t226, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  store i64 %t230, ptr %l14, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s11
  %t232 = load i64, ptr %l13, !tbaa !24
  %t233 = load i64, ptr %l14, !tbaa !24
  %t236 = icmp slt i64 %t232, %t233
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s11)
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t240 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t240, ptr %l112, !tbaa !27
  %t241 = load i64, ptr %l13, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i32, ptr %t244, i64 %t241
  %t246 = load i32, ptr %t245, !tbaa !33
  store ptr %l4, ptr %l115, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t252 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s11, ptr %t248, i32 %t246)
  store { i64, ptr } %t252, ptr %l118
  br label %bb45
bb45:
  %t253 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t255 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = add i64 %t254, %t257
  %t259 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t253, i64 %t254)
  %t260 = getelementptr i8, ptr %t259, i64 %t254
  call void @olang_textcopy(ptr %t260, ptr %t256, i64 %t257)
  %t261 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t259, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } %t262, 1
  %t266 = mul i64 %t264, 1
  %t267 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t267, ptr %t265, i64 %t266, i1 false)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t270 = load ptr, ptr %l115, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t270, { i64, ptr } %t269)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb47
bb47:
  %t272 = load i64, ptr %l13, !tbaa !24
  %t274 = add i64 %t272, 1
  store i64 %t274, ptr %l13, !tbaa !24
  br label %bb41
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t276 = load i64, ptr %l9, !tbaa !24
  %t278 = add i64 %t276, 1
  store i64 %t278, ptr %l9, !tbaa !24
  br label %bb13
bb51:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 62)
  br label %bb52
bb52:
  %t282 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l4)
  store { i64, ptr } %t282, ptr %l127
  br label %bb53
bb53:
  %t283 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t283, ptr %l128, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  store i64 %t285, ptr %l129, !tbaa !24
  %t286 = load i64, ptr %l129, !tbaa !24
  %t287 = mul i64 %t286, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t287)
  %t289 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  store { i64, ptr } %t290, ptr %l130, !tbaa !27
  %t291 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = load i64, ptr %l129, !tbaa !24
  %t296 = mul i64 %t295, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t292, ptr %t294, i64 %t296, i1 false)
  %t297 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t297, ptr %l128, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t298 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t298, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ewithDefaults(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l17 = alloca i1
  %l27 = alloca ptr
  %l35 = alloca %"std/prelude/text:StringBuilder"
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l56 = alloca i1
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l79 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l105 = alloca { i64, ptr }
  %l107 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca i64
  %l120 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  store i1 %t9, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l17, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t14, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 10
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store ptr %t32, ptr %l27
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l27, !tbaa !29
  %t35 = getelementptr %"compiler/load:Module", ptr %t33, i32 0, i32 6
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l5, !tbaa !29
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ff0e4b22591d4baf_6e63db52d9d49f33)
  unreachable
bb9:
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr %"compiler/source:Source", ptr %t42, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l6, !tbaa !27
  %t48 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t48, ptr %l35
  br label %bb11
bb11:
  %t49 = load %"std/prelude/text:StringBuilder", ptr %l35
  store %"std/prelude/text:StringBuilder" %t49, ptr %l7
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t52 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t56 = icmp sgt i64 %t54, 0
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  br label %bb61
bb14:
  br label %bb15
bb15:
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = call i64 @compiler_2fexplain_2efirstItemEnd(ptr %v1, { i64, ptr } %t60)
  store i64 %t62, ptr %l42
  br label %bb16
bb16:
  %t63 = load i64, ptr %l42, !tbaa !24
  store i64 %t63, ptr %l10, !tbaa !24
  store ptr %l7, ptr %l43, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t64, ptr %l44, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  store i64 %t65, ptr %l45, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l46, !tbaa !24
  %t68 = icmp sge i64 0, 0
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load i64, ptr %l45, !tbaa !24
  %t71 = icmp sle i64 0, %t70
  br i1 %t71, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9a288766c4af6878_87d82d450b86e5bc)
  unreachable
bb19:
  %t73 = load i64, ptr %l45, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_9a288766c4af6878_87d82d450b86e5bc)
  unreachable
bb21:
  %t77 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l45, !tbaa !24
  %t80 = getelementptr i8, ptr %t78, i64 0
  %t81 = sub i64 %t79, 0
  %t82 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  %t84 = load ptr, ptr %l43, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t84, { i64, ptr } %t83)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9a288766c4af6878_87d82d450b86e5bc)
  unreachable
bb23:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t90 = sub i64 %t86, %a4
  store i64 %t90, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp sge i64 %t92, 0
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  store i1 %t102, ptr %l56, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t104 = load i1, ptr %l56, !tbaa !21
  br i1 %t104, label %bb27, label %bb28
bb27:
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l62, !tbaa !27
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr ptr, ptr %t109, i64 %t106
  %t111 = load ptr, ptr %t110, !tbaa !39
  %t113 = getelementptr %"compiler/ast:Param", ptr %t111, i32 0, i32 3
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  %t118 = xor i1 %t116, true
  store i1 %t118, ptr %l61, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb29
bb29:
  %t120 = load i1, ptr %l61, !tbaa !21
  br i1 %t120, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t121 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t121, ptr %l68, !tbaa !27
  %t122 = load i64, ptr %l11, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  %t129 = getelementptr %"compiler/ast:Param", ptr %t127, i32 0, i32 3
  %t130 = load ptr, ptr %t129, !tbaa !29
  store ptr %t130, ptr %l12, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb32, label %bb33
bb31:
  br label %bb43
bb32:
  call void @__olang_check_failed(ptr @olang_loc_dff7162f9e8224a5_8282e6f3b3a12619)
  unreachable
bb33:
  br label %bb34
bb34:
  %t136 = load ptr, ptr %l12, !tbaa !29
  %t138 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t136)
  store %"compiler/source:Span" %t138, ptr %l75
  br label %bb35
bb35:
  %t139 = load %"compiler/source:Span", ptr %l75
  store %"compiler/source:Span" %t139, ptr %l13
  store ptr %l7, ptr %l76, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t140, ptr %l77, !tbaa !27
  %t141 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t142 = load i32, ptr %t141, !tbaa !23
  %t144 = sext i32 %t142 to i64
  store i64 %t144, ptr %l79, !tbaa !24
  %t145 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t146 = load i32, ptr %t145, !tbaa !23
  %t148 = sext i32 %t146 to i64
  store i64 %t148, ptr %l81, !tbaa !24
  %t149 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  store i64 %t150, ptr %l82, !tbaa !24
  %t151 = load i64, ptr %l79, !tbaa !24
  %t152 = icmp sge i64 %t151, 0
  br i1 %t152, label %bb36, label %bb37
bb36:
  %t154 = load i64, ptr %l79, !tbaa !24
  %t155 = load i64, ptr %l81, !tbaa !24
  %t156 = icmp sle i64 %t154, %t155
  br i1 %t156, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a)
  unreachable
bb38:
  %t158 = load i64, ptr %l81, !tbaa !24
  %t159 = load i64, ptr %l82, !tbaa !24
  %t160 = icmp sle i64 %t158, %t159
  br i1 %t160, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a)
  unreachable
bb40:
  %t162 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = load i64, ptr %l79, !tbaa !24
  %t165 = load i64, ptr %l81, !tbaa !24
  %t166 = getelementptr i8, ptr %t163, i64 %t164
  %t167 = sub i64 %t165, %t164
  %t168 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t166, 1
  %t170 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t173 = extractvalue { i64, ptr } %t169, 1
  %t174 = extractvalue { i64, ptr } %t169, 0
  %t175 = add i64 %t171, %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = getelementptr i8, ptr %t176, i64 %t171
  call void @olang_textcopy(ptr %t177, ptr %t173, i64 %t174)
  %t178 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t176, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = extractvalue { i64, ptr } %t179, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  %t187 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t187, { i64, ptr } %t186)
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb43:
  %t189 = load i64, ptr %l9, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l9, !tbaa !24
  %t193 = load i64, ptr %l10, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t199 = icmp sge i64 %t193, %t196
  br i1 %t199, label %bb44, label %bb45
bb44:
  br label %bb61
bb45:
  br label %bb46
bb46:
  store ptr %l7, ptr %l95, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t201, ptr %l96, !tbaa !27
  %t202 = load i64, ptr %l10, !tbaa !24
  store i64 %t202, ptr %l97, !tbaa !24
  %t203 = load i64, ptr %l10, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l99, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  store i64 %t207, ptr %l100, !tbaa !24
  %t208 = load i64, ptr %l97, !tbaa !24
  %t209 = icmp sge i64 %t208, 0
  br i1 %t209, label %bb47, label %bb48
bb47:
  %t211 = load i64, ptr %l97, !tbaa !24
  %t212 = load i64, ptr %l99, !tbaa !24
  %t213 = icmp sle i64 %t211, %t212
  br i1 %t213, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405)
  unreachable
bb49:
  %t215 = load i64, ptr %l99, !tbaa !24
  %t216 = load i64, ptr %l100, !tbaa !24
  %t217 = icmp sle i64 %t215, %t216
  br i1 %t217, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405)
  unreachable
bb51:
  %t219 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = load i64, ptr %l97, !tbaa !24
  %t222 = load i64, ptr %l99, !tbaa !24
  %t223 = getelementptr i8, ptr %t220, i64 %t221
  %t224 = sub i64 %t222, %t221
  %t225 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t223, 1
  %t227 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t227, { i64, ptr } %t226)
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405)
  unreachable
bb53:
  %t229 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t229, ptr %l105, !tbaa !27
  %t230 = load i64, ptr %l10, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l107, !tbaa !24
  %t233 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t233, 0
  store i64 %t236, ptr %l110, !tbaa !24
  %t237 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  store i64 %t238, ptr %l111, !tbaa !24
  %t239 = load i64, ptr %l107, !tbaa !24
  %t240 = icmp sge i64 %t239, 0
  br i1 %t240, label %bb54, label %bb55
bb54:
  %t242 = load i64, ptr %l107, !tbaa !24
  %t243 = load i64, ptr %l110, !tbaa !24
  %t244 = icmp sle i64 %t242, %t243
  br i1 %t244, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_6ea1601f041f7d0c_6257690dec820828)
  unreachable
bb56:
  %t246 = load i64, ptr %l110, !tbaa !24
  %t247 = load i64, ptr %l111, !tbaa !24
  %t248 = icmp sle i64 %t246, %t247
  br i1 %t248, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_6ea1601f041f7d0c_6257690dec820828)
  unreachable
bb58:
  %t250 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l107, !tbaa !24
  %t253 = load i64, ptr %l110, !tbaa !24
  %t254 = getelementptr i8, ptr %t251, i64 %t252
  %t255 = sub i64 %t253, %t252
  %t256 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t254, 1
  store { i64, ptr } %t257, ptr %l8, !tbaa !27
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_6ea1601f041f7d0c_6257690dec820828)
  unreachable
bb60:
  br label %bb12
bb61:
  %t260 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l7)
  store { i64, ptr } %t260, ptr %l117
  br label %bb62
bb62:
  %t261 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t261, ptr %l118, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  store i64 %t263, ptr %l119, !tbaa !24
  %t264 = load i64, ptr %l119, !tbaa !24
  %t265 = mul i64 %t264, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t265)
  %t267 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l120, !tbaa !27
  %t269 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = load i64, ptr %l119, !tbaa !24
  %t274 = mul i64 %t273, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t270, ptr %t272, i64 %t274, i1 false)
  %t275 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t275, ptr %l118, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t276 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t276, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_0(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca %"compiler/names:Entry"
  %l7 = alloca i32
  %l11 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/names:Table", ptr %t1, i32 0, i32 0
  %t7 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t3, i64 %a0)
  store %"compiler/names:Entry" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/names:Entry", ptr %l6, i32 0, i32 1
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/names:Table", ptr %t11, i32 0, i32 0
  %t17 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t13, i64 %a1)
  store %"compiler/names:Entry" %t17, ptr %l11
  br label %bb2
bb2:
  %t18 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 1
  %t19 = getelementptr %"compiler/source:Span", ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t21 = load i32, ptr %l7, !tbaa !23
  %t23 = icmp slt i32 %t21, %t20
  call void @__olang_scope_close(ptr %s0)
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"   " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @__olang_ert_req_clear()
@.d6 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"a method is called as one (M19) - a lambda calling it is a value" }>, align 8
@.d7 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"an extern fn is called by its name (X1) - a lambda calling it is a value" }>, align 8
@.d8 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"it is compiled once per length of an array it takes by value (G29) - pass a lambda calling it" }>, align 8
@.d9 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a generic is a value only named with its type arguments, '" }>, align 8
@.d10 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"<...>' (G12)" }>, align 8
@.d11 = private constant <{ i64, [181 x i8] }> <{ i64 0, [181 x i8] c"its scope obligations (# scopes, above) tie where what it is given lives to what it keeps or gives back, which a call through a function value cannot check (T22a) - call it directly" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".h" }>, align 8
@.d20 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d21 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"# commutes: the operator applies with its operands the other way round too (E31c)\0A" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]\0A" }>, align 8
@.d24 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn&(" }>, align 8
@.d25 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d26 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"# effects: " }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d34 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d40 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"    # " }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d43 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    instance " }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d46 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d47 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d48 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Generator" }>, align 8
@.d49 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Iterator" }>, align 8
@.d50 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"   # a generator: a call gives a " }>, align 8
@.d51 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ViewGenerator<" }>, align 8
@.d52 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Iterator" }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d54 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"   # a generator: a call gives a " }>, align 8
@.d55 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@.d56 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d59 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d60 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" mut " }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d62 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"   # set at startup\0A" }>, align 8
@.d63 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"   # set at startup\0A" }>, align 8
@.d64 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d65 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"...   # " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d66 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" characters\0A" }>, align 8
@.d67 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d69 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d70 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d72 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d73 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"# not a value: " }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d78 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"# scopes: " }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d81 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cn" }>, align 8
@.d82 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Ct" }>, align 8
@.d83 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"   # its error set inferred" }>, align 8
@.d84 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d85 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"    meets " }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d87 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d88 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d89 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"extern type " }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d93 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"error " }>, align 8
@.d94 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"   # declared where it is raised (R3b)\0A" }>, align 8
@.d95 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d96 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" error" }>, align 8
@.d97 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d98 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d100 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d101 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d102 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d103 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" trait" }>, align 8
@.d104 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" extends " }>, align 8
@.d105 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d106 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d107 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d109 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" immut" }>, align 8
@.d110 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d111 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d112 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" enum\0A" }>, align 8
@.d113 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d114 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" immut" }>, align 8
@.d115 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d116 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" extends " }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d118 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d119 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" immut" }>, align 8
@.d120 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d121 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d122 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" struct(" }>, align 8
@.d123 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d124 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d125 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d127 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d128 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d129 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d130 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d131 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d132 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H6c17f05b74a2ea6689cdfc72c602a991(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %v0)
@olang_loc_91de52063b71ca44_3ab230bc0b47a90 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eModuleOf(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2eMerge(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
@G_2ecompiler_2feffects_2eCapCount = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2feffects_2eCapText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_35c12625cc2f75ee_5b08f4318e637d4a = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eValueCovered(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_e4b17f5ad4d0393_dacada4c9c892187 = external constant [0 x i8]
@olang_loc_31b785093080fa1c_de0f6dc4f3b337d0 = external constant [0 x i8]
declare { i64, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAttrsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_654ac6e7d4d962a_57fceb1b72d2ae56 = external constant [0 x i8]
@olang_loc_d0280248a738559f_8af1b7358df9134b = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_430839a36fc86f5_d60a2ea9e5c9a99 = external constant [0 x i8]
@olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3 = external constant [0 x i8]
@olang_loc_5177bd7d484351dd_5d0dbb04dc509331 = external constant [0 x i8]
@olang_loc_e7ca39a48e286d3f_b849249cb4ab4933 = external constant [0 x i8]
@olang_loc_ec0929e0cef23b20_10aa079683981964 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67 = external constant [0 x i8]
@olang_loc_6448edf003c535f3_ebaded49d6e07c97 = external constant [0 x i8]
@olang_loc_979fe2e14fb6de05_5947910940c194f1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_559eb4fe50ed7f04_5fd8618740f13e0 = external constant [0 x i8]
@olang_loc_98928cfde749f632_385db913ea7e7976 = external constant [0 x i8]
declare { i64, ptr } @compiler_2feffects_2eDescribe(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_8f9ce818ff296c0e_932c83e6c6076d82 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_1ab09a44950d5518_36fac77ffd6769bc = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021 = external constant [0 x i8]
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4)
@olang_loc_b65b7d917c440185_24d12a03c9296209 = external constant [0 x i8]
@olang_loc_6896438a508f3415_b4ea8b5a918f5051 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fneeds_2eLines(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_2d047dc2e8ba79e9_b3960442abafce65 = external constant [0 x i8]
@olang_loc_62f5937584004bfc_64dbf784650d4808 = external constant [0 x i8]
@olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23 = external constant [0 x i8]
@olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546 = external constant [0 x i8]
@olang_loc_904aca603cad2e45_e62ac09e4cb76009 = external constant [0 x i8]
@olang_loc_e59c902bb0ddc268_5b11d99e1c27629c = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i32, { i64, ptr } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %a0)
@olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b = external constant [0 x i8]
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@olang_loc_24a71f1628ab63b4_59f385be22d57b28 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_267284e461664677_b2c2386ba62ab5d3 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_66f7703ccaf4f658_ca46a1b97aa24804 = external constant [0 x i8]
@olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H1e7e683fc0332c06b6c705cd46691777(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_a185ff5f85e75430_c999a61f9f0eedcc = external constant [0 x i8]
@olang_loc_60d3429e949e0f0f_c9b6e73225d64a3b = external constant [0 x i8]
@olang_loc_9e7f77c067ece8f1_2a0afb54e00d35 = external constant [0 x i8]
@olang_loc_7b101762ff8ffda9_ced5d247097fb61d = external constant [0 x i8]
@olang_loc_e7cf316846733e6c_5d444c1e6a143730 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_4e8cd845c965dada_c1eb458e34ff6f7e = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_12615553f525a8d6_4928bb51d62e2722 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d47c24bdc65fe2cb_f786417b6ea94537 = external constant [0 x i8]
@olang_loc_6531017cd55dbf94_87ab3d542028c5d8 = external constant [0 x i8]
@olang_loc_fdc41c6a76f01a06_9680a398378cbf4a = external constant [0 x i8]
@olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41 = external constant [0 x i8]
@olang_loc_5a4859640df0add8_178cc34ee3f1765c = external constant [0 x i8]
@olang_loc_731041b9517c977f_a1670725ff3ccc5b = external constant [0 x i8]
@olang_loc_b306a27fe8c8780a_4c00da05a7c42646 = external constant [0 x i8]
@olang_loc_5d61f9982e85490b_19b97e7dc205ed37 = external constant [0 x i8]
@olang_loc_3df602fba2cf8b3_3b7d9b6ebe07120f = external constant [0 x i8]
@olang_loc_94295b17b6f8c92c_4d0fd7ff7c3c10d0 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ff0e4b22591d4baf_6e63db52d9d49f33 = external constant [0 x i8]
@olang_loc_9a288766c4af6878_87d82d450b86e5bc = external constant [0 x i8]
@olang_loc_dff7162f9e8224a5_8282e6f3b3a12619 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a = external constant [0 x i8]
@olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405 = external constant [0 x i8]
@olang_loc_6ea1601f041f7d0c_6257690dec820828 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
