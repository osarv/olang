; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:Checker" = type { ptr, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, { i64, ptr } }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Table" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
define dso_local { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/names:Entry"
  %l16 = alloca i64
  %l17 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i32
  %l42 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l59 = alloca i32
  %l60 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca i32
  %l76 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i32
  %l93 = alloca { i64, ptr }
  %l99 = alloca i32
  %l101 = alloca i32
  %l103 = alloca i1
  %l108 = alloca i64
  %l114 = alloca { i64, ptr }
  %l115 = alloca i32
  %l117 = alloca i32
  %l119 = alloca i1
  %l124 = alloca { i64, ptr }
  %l133 = alloca i32
  %l138 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l5, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v3, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 1, ptr @.d0 })
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l25
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb2, label %ok.18
ok.18:
  store i64 %t15, ptr %l24
  br label %bb1
bb1:
  %t19 = load i64, ptr %l24, !tbaa !24
  store i64 %t19, ptr %l22, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb4
bb4:
  %t20 = load i64, ptr %l22, !tbaa !24
  store i64 %t20, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l28, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l29, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l30, !tbaa !27
  %t28 = load i64, ptr %l6, !tbaa !24
  store i64 %t28, ptr %l31, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l32, !tbaa !24
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb7, label %bb8
bb6:
  br label %bb30
bb7:
  %t33 = load i64, ptr %l31, !tbaa !24
  %t34 = icmp sle i64 0, %t33
  br i1 %t34, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb9:
  %t36 = load i64, ptr %l31, !tbaa !24
  %t37 = load i64, ptr %l32, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb11:
  %t40 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = getelementptr i8, ptr %t41, i64 0
  %t44 = sub i64 %t42, 0
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load ptr, ptr %l28, !tbaa !29
  %t48 = load i64, ptr %l29, !tbaa !24
  %t50 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t47, i64 %t48, { i64, ptr } %t46)
  store i32 %t50, ptr %l37
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb13:
  %t51 = load i32, ptr %l37, !tbaa !23
  store i32 %t51, ptr %l7, !tbaa !23
  %t52 = load i32, ptr %l7, !tbaa !23
  %t54 = icmp slt i32 %t52, 0
  br i1 %t54, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t57 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t57, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l42, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load i32, ptr %l7, !tbaa !23
  %t69 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l46
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l5, !tbaa !29
  store ptr %t70, ptr %l47, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l48, !tbaa !27
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l50, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t75, 0
  store i64 %t78, ptr %l53, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l54, !tbaa !24
  %t81 = load i64, ptr %l50, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = load i64, ptr %l50, !tbaa !24
  %t85 = load i64, ptr %l53, !tbaa !24
  %t86 = icmp sle i64 %t84, %t85
  br i1 %t86, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb20:
  %t88 = load i64, ptr %l53, !tbaa !24
  %t89 = load i64, ptr %l54, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb22:
  %t92 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l50, !tbaa !24
  %t95 = load i64, ptr %l53, !tbaa !24
  %t96 = getelementptr i8, ptr %t93, i64 %t94
  %t97 = sub i64 %t95, %t94
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t102 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v3, ptr %t100, { i64, ptr } %t99)
  store i32 %t102, ptr %l59
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb24:
  %t103 = load ptr, ptr %l42, !tbaa !29
  %t104 = load i32, ptr %l46, !tbaa !23
  %t105 = load i32, ptr %l59, !tbaa !23
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t103, i32 %t104, i32 %t105)
  store i64 %t106, ptr %l60
  br label %bb25
bb25:
  %t107 = load i64, ptr %l60, !tbaa !24
  store i64 %t107, ptr %l8, !tbaa !24
  %t108 = load i64, ptr %l8, !tbaa !24
  %t110 = icmp slt i64 %t108, 0
  br i1 %t110, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t113 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t113, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t116 = load i64, ptr %l8, !tbaa !24
  %t120 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t114, ptr %t115, i64 %t116)
  store { i64, ptr } %t120, ptr %l67
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t121 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t122 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t121, 1
  store { i32, { i64, ptr } } %t122, ptr %rv
  br label %ret
bb30:
  %t123 = load ptr, ptr %l5, !tbaa !29
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t127 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v3, ptr %t123, { i64, ptr } %t124)
  store i32 %t127, ptr %l70
  br label %bb31
bb31:
  %t128 = load i32, ptr %l70, !tbaa !23
  store i32 %t128, ptr %l9, !tbaa !23
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/names:Resolver", ptr %t135, i32 0, i32 1
  %t138 = load i64, ptr %l3, !tbaa !24
  %t141 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t137, i64 %t138)
  store ptr %t141, ptr %l76
  br label %bb32
bb32:
  %t142 = load ptr, ptr %l76, !tbaa !29
  %t144 = getelementptr %"compiler/names:Table", ptr %t142, i32 0, i32 0
  store ptr %t144, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t146 = load ptr, ptr %l10, !tbaa !29
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t146, i64 %t147)
  %t151 = extractvalue { i32, { i64, ptr } } %t150, 1
  %t152 = extractvalue { i32, { i64, ptr } } %t150, 0
  store i32 %t152, ptr %l83
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb35, label %ok.154
ok.154:
  store { i64, ptr } %t151, ptr %l82
  br label %bb34
bb34:
  %t155 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t155, ptr %l79, !tbaa !27
  br label %bb39
bb35:
  %t156 = load i32, ptr %l83, !tbaa !23
  %t157 = ashr i32 %t156, 16
  %t159 = icmp eq i32 %t157, 1
  br i1 %t159, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  %t161 = load i32, ptr %l83, !tbaa !23
  %t162 = lshr i32 %t161, 16
  %t163 = and i32 %t161, 65535
  %t164 = icmp eq i32 %t162, 1
  %t165 = select i1 %t164, i32 0, i32 0
  %t166 = icmp eq i32 %t161, 0
  %t167 = shl i32 %t165, 16
  %t168 = or i32 %t167, %t163
  %t169 = select i1 %t166, i32 0, i32 %t168
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t171 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t169, 0
  store { i32, { i64, ptr } } %t171, ptr %rv
  br label %ret
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb64
bb39:
  %t172 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t172, ptr %l12, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t177 = load i64, ptr %l14, !tbaa !24
  %t178 = load i64, ptr %l13, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb62
bb42:
  br label %bb43
bb43:
  %t185 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t185, ptr %l93, !tbaa !27
  %t186 = load i64, ptr %l14, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr %"compiler/names:Entry", ptr %t189, i64 %t186
  %t191 = load %"compiler/names:Entry", ptr %t190
  store %"compiler/names:Entry" %t191, ptr %l15
  %t193 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 0
  %t194 = load i32, ptr %t193, !tbaa !23
  %t195 = load i32, ptr %l9, !tbaa !23
  %t198 = icmp ne i32 %t194, %t195
  br i1 %t198, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb61
bb45:
  br label %bb46
bb46:
  %t200 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 2
  %t201 = load i32, ptr %t200
  store i32 %t201, ptr %l99
  store i32 3, ptr %l101
  %t204 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l99, ptr %l101)
  store i1 %t204, ptr %l103
  br label %bb47
bb47:
  %t205 = load i1, ptr %l103, !tbaa !21
  br i1 %t205, label %bb48, label %bb49
bb48:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 0
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t210 = load i64, ptr %l3, !tbaa !24
  %t211 = load i32, ptr %l9, !tbaa !23
  %t215 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t209, i64 %t210, i32 %t211)
  store i64 %t215, ptr %l108
  br label %bb50
bb49:
  br label %bb55
bb50:
  %t216 = load i64, ptr %l108, !tbaa !24
  store i64 %t216, ptr %l16, !tbaa !24
  %t217 = load i64, ptr %l16, !tbaa !24
  %t219 = icmp sge i64 %t217, 0
  br i1 %t219, label %bb51, label %bb52
bb51:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t223 = load i64, ptr %l16, !tbaa !24
  %t227 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t221, ptr %t222, i64 %t223)
  store { i64, ptr } %t227, ptr %l114
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t228 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t229 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t228, 1
  store { i32, { i64, ptr } } %t229, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t230 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 2
  %t231 = load i32, ptr %t230
  store i32 %t231, ptr %l115
  store i32 2, ptr %l117
  %t234 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l115, ptr %l117)
  store i1 %t234, ptr %l119
  br label %bb56
bb56:
  %t235 = load i1, ptr %l119, !tbaa !21
  br i1 %t235, label %bb57, label %bb58
bb57:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i64, ptr %l3, !tbaa !24
  %t239 = load %"compiler/names:Entry", ptr %l15
  %t244 = call { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v2, ptr %v0, ptr %v4, ptr %t236, ptr %a2, i64 %t238, %"compiler/names:Entry" %t239)
  store { i64, ptr } %t244, ptr %l124
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t245 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t246 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t245, 1
  store { i32, { i64, ptr } } %t246, ptr %rv
  br label %ret
bb60:
  call void @__olang_scope_close(ptr %s6)
  br label %bb61
bb61:
  %t247 = load i64, ptr %l14, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l14, !tbaa !24
  br label %bb40
bb62:
  %t251 = load i64, ptr %l11, !tbaa !24
  %t252 = load i64, ptr %l13, !tbaa !24
  %t255 = add i64 %t251, %t252
  store i64 %t255, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb63
bb63:
  br label %bb33
bb64:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i64, ptr %l3, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t263 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t257, i64 %t258, { i64, ptr } %t259)
  store i32 %t263, ptr %l133
  br label %bb65
bb65:
  %t264 = load i32, ptr %l133, !tbaa !23
  store i32 %t264, ptr %l17, !tbaa !23
  %t265 = load i32, ptr %l17, !tbaa !23
  %t267 = icmp sge i32 %t265, 0
  br i1 %t267, label %bb66, label %bb67
bb66:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i32, ptr %l17, !tbaa !23
  %t273 = call { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v4, ptr %t269, i32 %t270)
  store { i64, ptr } %t273, ptr %l138
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t274 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t275 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t274, 1
  store { i32, { i64, ptr } } %t275, ptr %rv
  br label %ret
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t277 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t277, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [2 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } zeroinitializer, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [2 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:StructBody", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } zeroinitializer, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr @.d5 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr @.d6 }, ptr %l9, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  br label %bb13
bb6:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load i64, ptr %l1, !tbaa !24
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t18, 0
  store i64 %t21, ptr %l15, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l16, !tbaa !24
  %t24 = load i64, ptr %l12, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load i64, ptr %l12, !tbaa !24
  %t28 = load i64, ptr %l15, !tbaa !24
  %t29 = icmp sle i64 %t27, %t28
  br i1 %t29, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c7)
  unreachable
bb9:
  %t31 = load i64, ptr %l15, !tbaa !24
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c7)
  unreachable
bb11:
  %t35 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = load i64, ptr %l12, !tbaa !24
  %t38 = load i64, ptr %l15, !tbaa !24
  %t39 = getelementptr i8, ptr %t36, i64 %t37
  %t40 = sub i64 %t38, %t37
  %t41 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t39, 1
  store { i64, ptr } %t42, ptr %l8, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @.c7)
  unreachable
bb13:
  %t45 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l22, !tbaa !24
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l23, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l22, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2efields(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/typed:Local"
  %l21 = alloca i32
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l38 = alloca { i64, ptr }
  %l51 = alloca i32
  %l53 = alloca i32
  %l55 = alloca i1
  %l57 = alloca i1
  %l62 = alloca i32
  %l67 = alloca i32
  %l69 = alloca i1
  %l74 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l86 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca i64
  %l93 = alloca ptr
  %l99 = alloca i64
  %l103 = alloca i64
  %l106 = alloca i64
  %l125 = alloca ptr
  %l129 = alloca i32
  %l131 = alloca %"compiler/typed:Local"
  %l136 = alloca i32
  %l137 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l146 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i64
  %l159 = alloca { i64, ptr }
  %l160 = alloca ptr
  %l161 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 6
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l29
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l28
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t14, ptr %l25, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l29, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c8)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb72
bb7:
  %t20 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb70
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l38, !tbaa !27
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  store ptr %t39, ptr %l8, !tbaa !29
  %t41 = load ptr, ptr %l8, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 1
  %t44 = load { i64, [2 x i64] }, ptr %t43
  store { i64, [2 x i64] } %t44, ptr %l9
  %t46 = load { i64, [2 x i64] }, ptr %l9
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l10, !tbaa !23
  %t55 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t56 = getelementptr { i32, i32 }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l11, !tbaa !23
  br label %bb14
bb13:
  br label %bb63
bb14:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l10, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l51
  br label %bb15
bb15:
  store i32 18, ptr %l53
  %t71 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l51, ptr %l53)
  store i1 %t71, ptr %l55
  br label %bb16
bb16:
  %t72 = load i1, ptr %l55, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb21
bb18:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  %t81 = load i32, ptr %l10, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l62
  br label %bb19
bb19:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l2, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l67
  br label %bb20
bb20:
  %t95 = load i32, ptr %l62, !tbaa !23
  %t96 = load i32, ptr %l67, !tbaa !23
  %t97 = icmp ne i32 %t95, %t96
  store i1 %t97, ptr %l57, !tbaa !21
  br label %bb21
bb21:
  %t99 = load i1, ptr %l57, !tbaa !21
  br i1 %t99, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb24
bb23:
  %t100 = load i32, ptr %l11, !tbaa !23
  %t102 = icmp ne i32 %t100, 0
  store i1 %t102, ptr %l69, !tbaa !21
  br label %bb24
bb24:
  %t104 = load i1, ptr %l69, !tbaa !21
  br i1 %t104, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb26:
  br label %bb27
bb27:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  store ptr %t110, ptr %l74, !tbaa !29
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l2, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v1, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l79
  br label %bb28
bb28:
  %t121 = load ptr, ptr %l74, !tbaa !29
  %t122 = load i32, ptr %l79, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %t121, i32 %t122)
  store { i64, ptr } %t123, ptr %l80
  br label %bb29
bb29:
  %t124 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t124, ptr %l12, !tbaa !27
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 0
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/load:Loader", ptr %t131, i32 0, i32 5
  store ptr %t133, ptr %l84, !tbaa !29
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 0
  %t137 = load ptr, ptr %t136, !tbaa !29
  store ptr %t137, ptr %l86, !tbaa !29
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l2, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l91
  br label %bb30
bb30:
  %t148 = load ptr, ptr %l86, !tbaa !29
  %t149 = load i32, ptr %l91, !tbaa !23
  %t150 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v1, ptr %t148, i32 %t149)
  store i64 %t150, ptr %l92
  br label %bb31
bb31:
  %t151 = load ptr, ptr %l84, !tbaa !29
  %t152 = load i64, ptr %l92, !tbaa !24
  %t153 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v1, ptr %v1, ptr %t151, i64 %t152)
  store ptr %t153, ptr %l93
  br label %bb32
bb32:
  %t154 = load ptr, ptr %l93, !tbaa !29
  %t156 = getelementptr %"compiler/load:Module", ptr %t154, i32 0, i32 6
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/source:Source", ptr %t157, i32 0, i32 1
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  store { i64, ptr } %t160, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t162 = load ptr, ptr %l8, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t162, i32 0, i32 10
  %t166 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t164)
  store i64 %t166, ptr %l99
  br label %bb33
bb33:
  %t167 = load i64, ptr %l99, !tbaa !24
  store i64 %t167, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t168 = load i64, ptr %l15, !tbaa !24
  %t169 = load i64, ptr %l14, !tbaa !24
  %t172 = icmp sgt i64 %t168, %t169
  br i1 %t172, label %bb34, label %bb35
bb34:
  %t174 = load i64, ptr %l16, !tbaa !24
  %t176 = icmp sgt i64 %t174, 0
  br i1 %t176, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb39
bb36:
  %t178 = load i64, ptr %l15, !tbaa !24
  %t179 = load i64, ptr %l14, !tbaa !24
  %t182 = sub i64 %t178, %t179
  %t183 = load i64, ptr %l16, !tbaa !24
  %t186 = add i64 %t182, %t183
  %t188 = sub i64 %t186, 1
  %t189 = load i64, ptr %l16, !tbaa !24
  %t192 = sdiv i64 %t188, %t189
  store i64 %t192, ptr %l106, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb38
bb38:
  %t194 = load i64, ptr %l106, !tbaa !24
  store i64 %t194, ptr %l103, !tbaa !24
  br label %bb39
bb39:
  %t195 = load i64, ptr %l103, !tbaa !24
  store i64 %t195, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t196 = load i64, ptr %l18, !tbaa !24
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = icmp slt i64 %t196, %t197
  %t202 = xor i1 %t200, true
  br i1 %t202, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb62
bb42:
  br label %bb43
bb43:
  %t204 = load i64, ptr %l14, !tbaa !24
  %t205 = load i64, ptr %l18, !tbaa !24
  %t206 = load i64, ptr %l16, !tbaa !24
  %t209 = mul i64 %t205, %t206
  %t212 = add i64 %t204, %t209
  store i64 %t212, ptr %l19, !tbaa !24
  %t214 = load ptr, ptr %l8, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Body", ptr %t214, i32 0, i32 7
  store ptr %t216, ptr %l125, !tbaa !29
  %t217 = load ptr, ptr %l8, !tbaa !29
  %t219 = getelementptr %"compiler/typed:Body", ptr %t217, i32 0, i32 10
  %t220 = load i64, ptr %l19, !tbaa !24
  %t223 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t219, i64 %t220)
  store i32 %t223, ptr %l129
  br label %bb44
bb44:
  %t224 = load i32, ptr %l129, !tbaa !23
  %t225 = sext i32 %t224 to i64
  %t226 = load ptr, ptr %l125, !tbaa !29
  %t228 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t226, i64 %t225)
  store %"compiler/typed:Local" %t228, ptr %l131
  br label %bb45
bb45:
  %t229 = load %"compiler/typed:Local", ptr %l131
  store %"compiler/typed:Local" %t229, ptr %l20
  %t230 = load i64, ptr %l19, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t236 = icmp slt i64 %t230, %t233
  br i1 %t236, label %bb46, label %bb47
bb46:
  %t238 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t238, ptr %l137, !tbaa !27
  %t239 = load i64, ptr %l19, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i32, ptr %t242, i64 %t239
  %t244 = load i32, ptr %t243, !tbaa !33
  store i32 %t244, ptr %l136, !tbaa !23
  br label %bb48
bb47:
  %t246 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 2
  %t247 = load i32, ptr %t246, !tbaa !23
  store i32 %t247, ptr %l136, !tbaa !23
  br label %bb48
bb48:
  %t249 = load i32, ptr %l136, !tbaa !23
  store i32 %t249, ptr %l21, !tbaa !23
  %t250 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 0
  %t251 = load i32, ptr %t250, !tbaa !23
  %t253 = icmp eq i32 %t251, 0
  br i1 %t253, label %bb49, label %bb50
bb49:
  %t255 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t255, ptr %l144, !tbaa !27
  %t256 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 1
  %t257 = getelementptr %"compiler/source:Span", ptr %t256, i32 0, i32 0
  %t258 = load i32, ptr %t257, !tbaa !23
  %t260 = sext i32 %t258 to i64
  store i64 %t260, ptr %l146, !tbaa !24
  %t261 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 1
  %t262 = getelementptr %"compiler/source:Span", ptr %t261, i32 0, i32 1
  %t263 = load i32, ptr %t262, !tbaa !23
  %t265 = sext i32 %t263 to i64
  store i64 %t265, ptr %l148, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 0
  store i64 %t267, ptr %l149, !tbaa !24
  %t268 = load i64, ptr %l146, !tbaa !24
  %t269 = icmp sge i64 %t268, 0
  br i1 %t269, label %bb51, label %bb52
bb50:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr %"compiler/check:Checker", ptr %t271, i32 0, i32 0
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = getelementptr %"compiler/generic:Program", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/load:Loader", ptr %t277, i32 0, i32 3
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t281 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 0
  %t282 = load i32, ptr %t281, !tbaa !23
  %t285 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %t280, i32 %t282)
  store { i64, ptr } %t285, ptr %l159
  br label %bb57
bb51:
  %t286 = load i64, ptr %l146, !tbaa !24
  %t287 = load i64, ptr %l148, !tbaa !24
  %t288 = icmp sle i64 %t286, %t287
  br i1 %t288, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
bb53:
  %t290 = load i64, ptr %l148, !tbaa !24
  %t291 = load i64, ptr %l149, !tbaa !24
  %t292 = icmp sle i64 %t290, %t291
  br i1 %t292, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
bb55:
  %t294 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = load i64, ptr %l146, !tbaa !24
  %t297 = load i64, ptr %l148, !tbaa !24
  %t298 = getelementptr i8, ptr %t295, i64 %t296
  %t299 = sub i64 %t297, %t296
  %t300 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t298, 1
  store { i64, ptr } %t301, ptr %l143, !tbaa !27
  br label %bb58
bb56:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
bb57:
  %t303 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t303, ptr %l143, !tbaa !27
  br label %bb58
bb58:
  %t304 = load { i64, ptr }, ptr %l143, !tbaa !27
  store ptr %a0, ptr %l160, !tbaa !29
  store { i64, ptr } %t304, ptr %l161, !tbaa !27
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t308 = load i32, ptr %l21, !tbaa !23
  %t311 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s7, ptr %t307, i32 %t308)
  store { i64, ptr } %t311, ptr %l164
  br label %bb59
bb59:
  %t312 = extractvalue { i64, ptr } { i64 4, ptr @.d10 }, 1
  %t313 = extractvalue { i64, ptr } { i64 4, ptr @.d10 }, 0
  %t314 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 1
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t317 = add i64 %t313, %t316
  %t318 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 1
  %t319 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 0
  %t320 = add i64 %t317, %t319
  %t321 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 1, ptr @.d12 }, 1
  %t326 = extractvalue { i64, ptr } { i64 1, ptr @.d12 }, 0
  %t327 = add i64 %t324, %t326
  %t328 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t327)
  call void @olang_textcopy(ptr %t328, ptr %t312, i64 %t313)
  %t329 = getelementptr i8, ptr %t328, i64 %t313
  call void @olang_textcopy(ptr %t329, ptr %t315, i64 %t316)
  %t330 = getelementptr i8, ptr %t329, i64 %t316
  call void @olang_textcopy(ptr %t330, ptr %t318, i64 %t319)
  %t331 = getelementptr i8, ptr %t330, i64 %t319
  call void @olang_textcopy(ptr %t331, ptr %t322, i64 %t323)
  %t332 = getelementptr i8, ptr %t331, i64 %t323
  call void @olang_textcopy(ptr %t332, ptr %t325, i64 %t326)
  %t333 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t328, 1
  %t336 = extractvalue { i64, ptr } %t334, 0
  %t337 = extractvalue { i64, ptr } %t334, 1
  %t338 = mul i64 %t336, 1
  %t339 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t338)
  call void @llvm.memcpy.p0.p0.i64(ptr %t339, ptr %t337, i64 %t338, i1 false)
  %t340 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  %t342 = load ptr, ptr %l160, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t342, { i64, ptr } %t341)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s7)
  br label %bb61
bb61:
  %t344 = load i64, ptr %l18, !tbaa !24
  %t346 = add i64 %t344, 1
  store i64 %t346, ptr %l18, !tbaa !24
  br label %bb40
bb62:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb68:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb69:
  %t348 = load i64, ptr %l7, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l7, !tbaa !24
  br label %bb8
bb70:
  %t352 = load i64, ptr %l4, !tbaa !24
  %t353 = load i64, ptr %l6, !tbaa !24
  %t356 = add i64 %t352, %t353
  store i64 %t356, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb71:
  br label %bb1
bb72:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fexplain_2efirstClose(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t2, 0
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = icmp sge i64 3, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sle i64 3, %t10
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sle i64 %t13, %t14
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb5:
  %t17 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr i8, ptr %t18, i64 3
  %t21 = sub i64 %t19, 3
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = call i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %t23)
  store i64 %t25, ptr %l10
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb7:
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = add i64 3, %t26
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEnd(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l56, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = sub i64 %t96, 1
  store i64 %t98, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb30:
  br label %bb31
bb31:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = icmp eq i8 %t104, 44
  br i1 %t106, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb37
bb34:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb36
bb35:
  %t108 = load i8, ptr %l8, !tbaa !22
  %t110 = icmp eq i8 %t108, 41
  store i1 %t110, ptr %l66, !tbaa !21
  br label %bb36
bb36:
  %t112 = load i1, ptr %l66, !tbaa !21
  store i1 %t112, ptr %l63, !tbaa !21
  br label %bb37
bb37:
  %t113 = load i1, ptr %l63, !tbaa !21
  br i1 %t113, label %bb38, label %bb39
bb38:
  %t114 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t114, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l6, !tbaa !24
  br label %bb7
bb42:
  %t120 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  store i64 %t122, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb28, label %bb29
bb27:
  br label %bb31
bb28:
  %t95 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t95, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t97 = load i64, ptr %l1, !tbaa !24
  %t99 = sub i64 %t97, 1
  store i64 %t99, ptr %l1, !tbaa !24
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l6, !tbaa !24
  br label %bb7
bb33:
  %t105 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i64
  %l37 = alloca i32
  %l39 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i64
  %l95 = alloca i64
  %l100 = alloca i64
  %l103 = alloca ptr
  %l107 = alloca i32
  %l113 = alloca i32
  %l114 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l126 = alloca i32
  %l127 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca i64
  %l144 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t3)
  store i64 %t5, ptr %l18
  br label %bb2
bb2:
  %t6 = load i64, ptr %l18, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t10, i64 %t6)
  store i64 %t14, ptr %l22
  br label %bb3
bb3:
  %t15 = load i64, ptr %l22, !tbaa !24
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t21, i64 %t22, i32 0)
  store i64 %t25, ptr %l27
  br label %bb6
bb5:
  br label %bb13
bb6:
  %t26 = load i64, ptr %l27, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l30
  br label %bb7
bb7:
  %t32 = load i64, ptr %l30, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store ptr %l3, ptr %l31, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l32, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l33, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t38, i64 %t39)
  store i32 %t42, ptr %l37
  br label %bb8
bb8:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load ptr, ptr %l32, !tbaa !29
  %t45 = load i64, ptr %l33, !tbaa !24
  %t46 = load i32, ptr %l37, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s1, ptr %t44, i64 %t45, i32 %t46, i64 %t43)
  store { i64, ptr } %t48, ptr %l39
  br label %bb9
bb9:
  %t49 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = getelementptr i8, ptr %t55, i64 %t51
  call void @olang_textcopy(ptr %t56, ptr %t52, i64 %t53)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t66, { i64, ptr } %t65)
  br label %bb10
bb10:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t70 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s1, ptr %l3, ptr %t68, ptr %t69, i64 %t70, { i64, ptr } { i64 4, ptr @.d16 })
  br label %bb11
bb11:
  %t76 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t76, ptr %l47
  br label %bb12
bb12:
  %t77 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t77, ptr %l48, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l49, !tbaa !24
  %t80 = load i64, ptr %l49, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l49, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t91, ptr %l48, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb13:
  store ptr %l3, ptr %l51, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l52, !tbaa !29
  %t94 = load i64, ptr %l2, !tbaa !24
  store i64 %t94, ptr %l53, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load i64, ptr %l2, !tbaa !24
  %t102 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t98, i64 %t99)
  store i32 %t102, ptr %l57
  br label %bb14
bb14:
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = load i64, ptr %l53, !tbaa !24
  %t105 = load i32, ptr %l57, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s0, ptr %t103, i64 %t104, i32 %t105, i64 -1)
  store { i64, ptr } %t106, ptr %l58
  br label %bb15
bb15:
  %t107 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 1
  %t111 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 0
  %t112 = add i64 %t109, %t111
  %t113 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t108, i64 %t109)
  %t114 = getelementptr i8, ptr %t113, i64 %t109
  call void @olang_textcopy(ptr %t114, ptr %t110, i64 %t111)
  %t115 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t113, 1
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = extractvalue { i64, ptr } %t116, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t124 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t124, { i64, ptr } %t123)
  br label %bb16
bb16:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load i64, ptr %l2, !tbaa !24
  %t133 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t129, i64 %t130)
  store ptr %t133, ptr %l64
  br label %bb17
bb17:
  %t134 = load ptr, ptr %l64, !tbaa !29
  store ptr %t134, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %t138)
  store i64 %t140, ptr %l67
  br label %bb18
bb18:
  %t141 = load i64, ptr %l67, !tbaa !24
  store i64 %t141, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t143 = load i64, ptr %l8, !tbaa !24
  %t146 = icmp sgt i64 %t142, %t143
  br i1 %t146, label %bb19, label %bb20
bb19:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t150 = icmp sgt i64 %t148, 0
  br i1 %t150, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb24
bb21:
  %t152 = load i64, ptr %l9, !tbaa !24
  %t153 = load i64, ptr %l8, !tbaa !24
  %t156 = sub i64 %t152, %t153
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = add i64 %t156, %t157
  %t162 = sub i64 %t160, 1
  %t163 = load i64, ptr %l10, !tbaa !24
  %t166 = sdiv i64 %t162, %t163
  store i64 %t166, ptr %l74, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb23
bb23:
  %t168 = load i64, ptr %l74, !tbaa !24
  store i64 %t168, ptr %l71, !tbaa !24
  br label %bb24
bb24:
  %t169 = load i64, ptr %l71, !tbaa !24
  store i64 %t169, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l11, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb46
bb27:
  br label %bb28
bb28:
  %t178 = load i64, ptr %l8, !tbaa !24
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = load i64, ptr %l10, !tbaa !24
  %t183 = mul i64 %t179, %t180
  %t186 = add i64 %t178, %t183
  store i64 %t186, ptr %l13, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = load i64, ptr %l13, !tbaa !24
  %t195 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t191, i64 %t192)
  store i64 %t195, ptr %l95
  br label %bb29
bb29:
  %t196 = load i64, ptr %l2, !tbaa !24
  %t197 = load i64, ptr %l95, !tbaa !24
  %t199 = icmp ne i64 %t197, %t196
  br i1 %t199, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb31:
  br label %bb32
bb32:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i64, ptr %l13, !tbaa !24
  %t205 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t201, i64 %t202)
  store i64 %t205, ptr %l100
  br label %bb33
bb33:
  %t206 = load i64, ptr %l100, !tbaa !24
  store i64 %t206, ptr %l14, !tbaa !24
  %t207 = load i64, ptr %l14, !tbaa !24
  %t209 = icmp slt i64 %t207, 0
  br i1 %t209, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb35:
  br label %bb36
bb36:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l103, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 0
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t216 = load i64, ptr %l13, !tbaa !24
  %t219 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t215, i64 %t216)
  store i32 %t219, ptr %l107
  br label %bb37
bb37:
  %t220 = load ptr, ptr %l7, !tbaa !29
  %t222 = getelementptr %"compiler/ast:Func", ptr %t220, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t224 = load ptr, ptr %l7, !tbaa !29
  %t226 = getelementptr %"compiler/ast:Func", ptr %t224, i32 0, i32 3
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/ast:Sig", ptr %t227, i32 0, i32 0
  %t230 = load { i64, ptr }, ptr %t229, !tbaa !27
  %t231 = load ptr, ptr %l103, !tbaa !29
  %t232 = load i32, ptr %l107, !tbaa !23
  %t235 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t231, i32 %t232, ptr %t223, { i64, ptr } %t230)
  store i32 %t235, ptr %l113
  br label %bb38
bb38:
  %t236 = load i32, ptr %l113, !tbaa !23
  store i32 %t236, ptr %l15, !tbaa !23
  store ptr %l3, ptr %l114, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 0
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Program", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/load:Loader", ptr %t243, i32 0, i32 3
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t247 = load ptr, ptr %l7, !tbaa !29
  %t249 = getelementptr %"compiler/ast:Func", ptr %t247, i32 0, i32 2
  %t250 = load i32, ptr %t249, !tbaa !23
  %t253 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t246, i32 %t250)
  store { i64, ptr } %t253, ptr %l121
  br label %bb39
bb39:
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l122, !tbaa !29
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/check:Checker", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t259 = load i64, ptr %l13, !tbaa !24
  %t262 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t258, i64 %t259)
  store i32 %t262, ptr %l126
  br label %bb40
bb40:
  %t263 = load ptr, ptr %l122, !tbaa !29
  %t264 = load i32, ptr %l126, !tbaa !23
  %t265 = call { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %s5, ptr %t263, i32 %t264)
  store { i64, ptr } %t265, ptr %l127
  br label %bb41
bb41:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i32, ptr %l15, !tbaa !23
  %t268 = load i64, ptr %l14, !tbaa !24
  %t272 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s5, ptr %t266, i32 %t267, i64 %t268)
  store { i64, ptr } %t272, ptr %l131
  br label %bb42
bb42:
  %t273 = extractvalue { i64, ptr } { i64 13, ptr @.d18 }, 1
  %t274 = extractvalue { i64, ptr } { i64 13, ptr @.d18 }, 0
  %t275 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = add i64 %t274, %t277
  %t279 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 1
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t282 = add i64 %t278, %t281
  %t283 = extractvalue { i64, ptr } { i64 2, ptr @.d19 }, 1
  %t284 = extractvalue { i64, ptr } { i64 2, ptr @.d19 }, 0
  %t285 = add i64 %t282, %t284
  %t286 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = add i64 %t285, %t288
  %t290 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t291 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  %t292 = add i64 %t289, %t291
  %t293 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t292)
  call void @olang_textcopy(ptr %t293, ptr %t273, i64 %t274)
  %t294 = getelementptr i8, ptr %t293, i64 %t274
  call void @olang_textcopy(ptr %t294, ptr %t276, i64 %t277)
  %t295 = getelementptr i8, ptr %t294, i64 %t277
  call void @olang_textcopy(ptr %t295, ptr %t280, i64 %t281)
  %t296 = getelementptr i8, ptr %t295, i64 %t281
  call void @olang_textcopy(ptr %t296, ptr %t283, i64 %t284)
  %t297 = getelementptr i8, ptr %t296, i64 %t284
  call void @olang_textcopy(ptr %t297, ptr %t287, i64 %t288)
  %t298 = getelementptr i8, ptr %t297, i64 %t288
  call void @olang_textcopy(ptr %t298, ptr %t290, i64 %t291)
  %t299 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t293, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = extractvalue { i64, ptr } %t300, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  %t308 = load ptr, ptr %l114, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t308, { i64, ptr } %t307)
  br label %bb43
bb43:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t312 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s5, ptr %l3, ptr %t310, ptr %t311, i64 %t312, { i64, ptr } { i64 8, ptr @.d21 })
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb45:
  %t317 = load i64, ptr %l12, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l12, !tbaa !24
  br label %bb25
bb46:
  %t322 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t322, ptr %l141
  br label %bb47
bb47:
  %t323 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t323, ptr %l142, !tbaa !27
  %t324 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t324, 0
  store i64 %t325, ptr %l143, !tbaa !24
  %t326 = load i64, ptr %l143, !tbaa !24
  %t327 = mul i64 %t326, 1
  %t328 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t327)
  %t329 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t328, 1
  store { i64, ptr } %t330, ptr %l144, !tbaa !27
  %t331 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = load i64, ptr %l143, !tbaa !24
  %t336 = mul i64 %t335, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t332, ptr %t334, i64 %t336, i1 false)
  %t337 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t337, ptr %l142, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t338 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t338, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l25 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l39 = alloca i32
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t19, i32 %t23)
  store { i64, ptr } %t26, ptr %l22
  br label %bb2
bb2:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l23, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t28)
  store i64 %t30, ptr %l25
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l28
  br label %bb4
bb4:
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load i64, ptr %l25, !tbaa !24
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t36, i64 %t37, i64 %t38)
  store { i64, ptr } %t39, ptr %l29
  br label %bb5
bb5:
  %t40 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = add i64 %t42, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t41, i64 %t42)
  %t48 = getelementptr i8, ptr %t47, i64 %t42
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l31, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Func", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Sig", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t70 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t53, i32 %a2, ptr %t58, { i64, ptr } %t65)
  store i32 %t70, ptr %l39
  br label %bb6
bb6:
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t73 = load i32, ptr %l39, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s0, ptr %t72, i32 %t73, i64 %a3)
  store { i64, ptr } %t75, ptr %l41
  br label %bb7
bb7:
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t76, ptr %l6, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i64, ptr %l1, !tbaa !24
  %t84 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t80, i64 %t81)
  store i1 %t84, ptr %l45
  br label %bb8
bb8:
  %t85 = load i1, ptr %l45, !tbaa !21
  br i1 %t85, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 10, ptr @.d22 }, ptr %l46, !tbaa !27
  br label %bb11
bb10:
  store { i64, ptr } { i64 3, ptr @.d23 }, ptr %l46, !tbaa !27
  br label %bb11
bb11:
  %t86 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  store i64 %t89, ptr %l48, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l49, !tbaa !24
  %t92 = icmp sge i64 3, 0
  br i1 %t92, label %bb12, label %bb13
bb12:
  %t94 = load i64, ptr %l48, !tbaa !24
  %t95 = icmp sle i64 3, %t94
  br i1 %t95, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @.c24)
  unreachable
bb14:
  %t97 = load i64, ptr %l48, !tbaa !24
  %t98 = load i64, ptr %l49, !tbaa !24
  %t99 = icmp sle i64 %t97, %t98
  br i1 %t99, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @.c24)
  unreachable
bb16:
  %t101 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l48, !tbaa !24
  %t104 = getelementptr i8, ptr %t102, i64 3
  %t105 = sub i64 %t103, 3
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %l8, !tbaa !27
  %t109 = load ptr, ptr %l4, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Func", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  br i1 %t114, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @.c24)
  unreachable
bb18:
  %t116 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t116, 1
  %t121 = extractvalue { i64, ptr } %t116, 0
  %t123 = extractvalue { i64, ptr } %t117, 1
  %t124 = extractvalue { i64, ptr } %t117, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 1
  %t127 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 0
  %t128 = add i64 %t125, %t127
  %t130 = extractvalue { i64, ptr } %t118, 1
  %t131 = extractvalue { i64, ptr } %t118, 0
  %t132 = add i64 %t128, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t120, i64 %t121)
  %t134 = getelementptr i8, ptr %t133, i64 %t121
  call void @olang_textcopy(ptr %t134, ptr %t123, i64 %t124)
  %t135 = getelementptr i8, ptr %t134, i64 %t124
  call void @olang_textcopy(ptr %t135, ptr %t126, i64 %t127)
  %t136 = getelementptr i8, ptr %t135, i64 %t127
  call void @olang_textcopy(ptr %t136, ptr %t130, i64 %t131)
  %t137 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t133, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t138, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t140 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t142 = call i64 @compiler_2fexplain_2efirstItemEnd(ptr %s0, { i64, ptr } %t140)
  store i64 %t142, ptr %l62
  br label %bb21
bb21:
  %t143 = load i64, ptr %l62, !tbaa !24
  store i64 %t143, ptr %l9, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t144, ptr %l63, !tbaa !27
  %t145 = load i64, ptr %l9, !tbaa !24
  store i64 %t145, ptr %l64, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  store i64 %t147, ptr %l65, !tbaa !24
  %t148 = icmp sge i64 0, 0
  br i1 %t148, label %bb22, label %bb23
bb22:
  %t150 = load i64, ptr %l64, !tbaa !24
  %t151 = icmp sle i64 0, %t150
  br i1 %t151, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb24:
  %t153 = load i64, ptr %l64, !tbaa !24
  %t154 = load i64, ptr %l65, !tbaa !24
  %t155 = icmp sle i64 %t153, %t154
  br i1 %t155, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb26:
  %t157 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l64, !tbaa !24
  %t160 = getelementptr i8, ptr %t158, i64 0
  %t161 = sub i64 %t159, 0
  %t162 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t160, 1
  store { i64, ptr } %t163, ptr %l10, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t165, ptr %l70, !tbaa !27
  %t166 = load i64, ptr %l9, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i8, ptr %t169, i64 %t166
  %t171 = load i8, ptr %t170, !tbaa !32
  %t173 = icmp eq i8 %t171, 44
  br i1 %t173, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb28:
  %t175 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t175, ptr %l75, !tbaa !27
  %t176 = load i64, ptr %l9, !tbaa !24
  %t178 = add i64 %t176, 2
  store i64 %t178, ptr %l77, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t179, 0
  store i64 %t182, ptr %l80, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  store i64 %t184, ptr %l81, !tbaa !24
  %t185 = load i64, ptr %l77, !tbaa !24
  %t186 = icmp sge i64 %t185, 0
  br i1 %t186, label %bb30, label %bb31
bb29:
  %t188 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t188, ptr %l86, !tbaa !27
  %t189 = load i64, ptr %l9, !tbaa !24
  store i64 %t189, ptr %l87, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t190, 0
  store i64 %t193, ptr %l90, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  store i64 %t195, ptr %l91, !tbaa !24
  %t196 = load i64, ptr %l87, !tbaa !24
  %t197 = icmp sge i64 %t196, 0
  br i1 %t197, label %bb36, label %bb37
bb30:
  %t199 = load i64, ptr %l77, !tbaa !24
  %t200 = load i64, ptr %l80, !tbaa !24
  %t201 = icmp sle i64 %t199, %t200
  br i1 %t201, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb32:
  %t203 = load i64, ptr %l80, !tbaa !24
  %t204 = load i64, ptr %l81, !tbaa !24
  %t205 = icmp sle i64 %t203, %t204
  br i1 %t205, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb34:
  %t207 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l77, !tbaa !24
  %t210 = load i64, ptr %l80, !tbaa !24
  %t211 = getelementptr i8, ptr %t208, i64 %t209
  %t212 = sub i64 %t210, %t209
  %t213 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t211, 1
  store { i64, ptr } %t214, ptr %l74, !tbaa !27
  br label %bb42
bb35:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb36:
  %t216 = load i64, ptr %l87, !tbaa !24
  %t217 = load i64, ptr %l90, !tbaa !24
  %t218 = icmp sle i64 %t216, %t217
  br i1 %t218, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb38:
  %t220 = load i64, ptr %l90, !tbaa !24
  %t221 = load i64, ptr %l91, !tbaa !24
  %t222 = icmp sle i64 %t220, %t221
  br i1 %t222, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb40:
  %t224 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = load i64, ptr %l87, !tbaa !24
  %t227 = load i64, ptr %l90, !tbaa !24
  %t228 = getelementptr i8, ptr %t225, i64 %t226
  %t229 = sub i64 %t227, %t226
  %t230 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t228, 1
  store { i64, ptr } %t231, ptr %l74, !tbaa !27
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb42:
  %t233 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t234, 1
  %t240 = extractvalue { i64, ptr } %t234, 0
  %t241 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 1
  %t242 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 0
  %t243 = add i64 %t240, %t242
  %t245 = extractvalue { i64, ptr } %t235, 1
  %t246 = extractvalue { i64, ptr } %t235, 0
  %t247 = add i64 %t243, %t246
  %t248 = extractvalue { i64, ptr } { i64 2, ptr @.d29 }, 1
  %t249 = extractvalue { i64, ptr } { i64 2, ptr @.d29 }, 0
  %t250 = add i64 %t247, %t249
  %t252 = extractvalue { i64, ptr } %t236, 1
  %t253 = extractvalue { i64, ptr } %t236, 0
  %t254 = add i64 %t250, %t253
  %t255 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 1
  %t256 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 0
  %t257 = add i64 %t254, %t256
  %t259 = extractvalue { i64, ptr } %t233, 1
  %t260 = extractvalue { i64, ptr } %t233, 0
  %t261 = add i64 %t257, %t260
  %t262 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t261)
  call void @olang_textcopy(ptr %t262, ptr %t239, i64 %t240)
  %t263 = getelementptr i8, ptr %t262, i64 %t240
  call void @olang_textcopy(ptr %t263, ptr %t241, i64 %t242)
  %t264 = getelementptr i8, ptr %t263, i64 %t242
  call void @olang_textcopy(ptr %t264, ptr %t245, i64 %t246)
  %t265 = getelementptr i8, ptr %t264, i64 %t246
  call void @olang_textcopy(ptr %t265, ptr %t248, i64 %t249)
  %t266 = getelementptr i8, ptr %t265, i64 %t249
  call void @olang_textcopy(ptr %t266, ptr %t252, i64 %t253)
  %t267 = getelementptr i8, ptr %t266, i64 %t253
  call void @olang_textcopy(ptr %t267, ptr %t255, i64 %t256)
  %t268 = getelementptr i8, ptr %t267, i64 %t256
  call void @olang_textcopy(ptr %t268, ptr %t259, i64 %t260)
  %t269 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t262, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t270, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, %"compiler/names:Entry" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/names:Entry"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l8 = alloca { { i64, ptr }, i1 }
  %l9 = alloca { i64, ptr }
  %l19 = alloca i32
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca { { i64, ptr }, i1 }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l52 = alloca i32
  %l54 = alloca i32
  %l56 = alloca i1
  %l57 = alloca i32
  %l62 = alloca i32
  %l64 = alloca i32
  %l66 = alloca i32
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/names:Entry" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %t12, i64 %t13, i32 %t15)
  store i32 %t19, ptr %l19
  br label %bb1
bb1:
  %t20 = load i32, ptr %l19, !tbaa !23
  store i32 %t20, ptr %l5, !tbaa !23
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t21, i32 %t23)
  store { i64, ptr } %t26, ptr %l22
  br label %bb2
bb2:
  %t27 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr @.d31 }, ptr %l24, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 1, ptr @.d32 }, ptr %l24, !tbaa !27
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l5, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t30, i32 %t31)
  store { i64, ptr } %t34, ptr %l27
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t36, i64 %t37)
  %t47 = getelementptr i8, ptr %t46, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = getelementptr i8, ptr %t47, i64 %t40
  call void @olang_textcopy(ptr %t48, ptr %t43, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  %t52 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = extractvalue { i64, ptr } { i64 20, ptr @.d33 }, 1
  %t60 = extractvalue { i64, ptr } { i64 20, ptr @.d33 }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = getelementptr i8, ptr %t62, i64 %t58
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 1
  %t72 = load %"compiler/source:Span", ptr %t71
  %t77 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %t67, i64 %t68, i32 %t70, %"compiler/source:Span" %t72)
  store i64 %t77, ptr %l36
  br label %bb10
bb10:
  %t78 = load i64, ptr %l36, !tbaa !24
  %t83 = call { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v1, ptr %s0, ptr %a1, i64 %t78)
  store { { i64, ptr }, i1 } %t83, ptr %l39
  br label %bb11
bb11:
  %t84 = load { { i64, ptr }, i1 }, ptr %l39
  store { { i64, ptr }, i1 } %t84, ptr %l8
  %t85 = getelementptr { { i64, ptr }, i1 }, ptr %l8, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l40, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l41, !tbaa !24
  %t89 = load i64, ptr %l41, !tbaa !24
  %t90 = mul i64 %t89, 1
  %t91 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t90)
  %t92 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l42, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l41, !tbaa !24
  %t99 = mul i64 %t98, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t95, ptr %t97, i64 %t99, i1 false)
  %t100 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t100, ptr %l9, !tbaa !27
  %t101 = getelementptr { { i64, ptr }, i1 }, ptr %l8, i32 0, i32 1
  %t102 = load i1, ptr %t101, !tbaa !21
  %t106 = xor i1 %t102, true
  br i1 %t106, label %bb12, label %bb13
bb12:
  %t108 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = extractvalue { i64, ptr } %t108, 0
  %t112 = extractvalue { i64, ptr } { i64 20, ptr @.d34 }, 1
  %t113 = extractvalue { i64, ptr } { i64 20, ptr @.d34 }, 0
  %t114 = add i64 %t111, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t110, i64 %t111)
  %t116 = getelementptr i8, ptr %t115, i64 %t111
  call void @olang_textcopy(ptr %t116, ptr %t112, i64 %t113)
  %t117 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t118, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l5, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l52
  br label %bb15
bb15:
  store i32 20, ptr %l54
  %t132 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l52, ptr %l54)
  store i1 %t132, ptr %l56
  br label %bb16
bb16:
  %t133 = load i1, ptr %l56, !tbaa !21
  br i1 %t133, label %bb17, label %bb18
bb17:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 0
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l5, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l62
  br label %bb19
bb18:
  %t144 = load i32, ptr %l5, !tbaa !23
  store i32 %t144, ptr %l57, !tbaa !23
  br label %bb20
bb19:
  %t146 = load i32, ptr %l62, !tbaa !23
  store i32 %t146, ptr %l57, !tbaa !23
  br label %bb20
bb20:
  %t147 = load i32, ptr %l57, !tbaa !23
  store i32 %t147, ptr %l64, !tbaa !23
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %t149)
  store i32 %t151, ptr %l66
  br label %bb21
bb21:
  %t152 = load i32, ptr %l64, !tbaa !23
  %t153 = load i32, ptr %l66, !tbaa !23
  %t154 = icmp eq i32 %t152, %t153
  br i1 %t154, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t156 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t156, ptr %l68, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t159 = call { i64, ptr } @compiler_2fexplain_2equoted(ptr %s0, ptr %s6, { i64, ptr } %t157)
  store { i64, ptr } %t159, ptr %l70
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t160 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = extractvalue { i64, ptr } { i64 3, ptr @.d35 }, 1
  %t164 = extractvalue { i64, ptr } { i64 3, ptr @.d35 }, 0
  %t165 = add i64 %t162, %t164
  %t166 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t161, i64 %t162)
  %t174 = getelementptr i8, ptr %t173, i64 %t162
  call void @olang_textcopy(ptr %t174, ptr %t163, i64 %t164)
  %t175 = getelementptr i8, ptr %t174, i64 %t164
  call void @olang_textcopy(ptr %t175, ptr %t167, i64 %t168)
  %t176 = getelementptr i8, ptr %t175, i64 %t168
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t173, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t178, ptr %rv
  br label %ret
bb25:
  %t180 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t180, 1
  %t184 = extractvalue { i64, ptr } %t180, 0
  %t185 = extractvalue { i64, ptr } { i64 3, ptr @.d37 }, 1
  %t186 = extractvalue { i64, ptr } { i64 3, ptr @.d37 }, 0
  %t187 = add i64 %t184, %t186
  %t189 = extractvalue { i64, ptr } %t181, 1
  %t190 = extractvalue { i64, ptr } %t181, 0
  %t191 = add i64 %t187, %t190
  %t192 = extractvalue { i64, ptr } { i64 1, ptr @.d38 }, 1
  %t193 = extractvalue { i64, ptr } { i64 1, ptr @.d38 }, 0
  %t194 = add i64 %t191, %t193
  %t195 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t183, i64 %t184)
  %t196 = getelementptr i8, ptr %t195, i64 %t184
  call void @olang_textcopy(ptr %t196, ptr %t185, i64 %t186)
  %t197 = getelementptr i8, ptr %t196, i64 %t186
  call void @olang_textcopy(ptr %t197, ptr %t189, i64 %t190)
  %t198 = getelementptr i8, ptr %t197, i64 %t190
  call void @olang_textcopy(ptr %t198, ptr %t192, i64 %t193)
  %t199 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t195, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t200, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2emethods(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca i1
  %l54 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l75 = alloca i32
  %l77 = alloca i32
  %l79 = alloca i1
  %l84 = alloca i32
  %l89 = alloca i32
  %l91 = alloca i32
  %l93 = alloca i1
  %l95 = alloca i1
  %l100 = alloca i32
  %l105 = alloca i32
  %l108 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca i64
  %l116 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca i64
  %l123 = alloca i32
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca i64
  %l136 = alloca i32
  %l137 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v1, ptr %t4)
  br label %bb1
bb1:
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb2
bb2:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v1, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l44
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l44, !tbaa !29
  store ptr %t67, ptr %l9, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v1, ptr %t78, i32 %t79, i32 %t83)
  store i64 %t87, ptr %l54
  br label %bb16
bb16:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l54, !tbaa !24
  %t91 = icmp ne i64 %t89, %t88
  store i1 %t91, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t93 = load i1, ptr %l48, !tbaa !21
  br i1 %t93, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb19:
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 0
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l59, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t105, ptr %l62, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t109, i64 %t110)
  store i32 %t113, ptr %l66
  br label %bb21
bb21:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load i32, ptr %l66, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t114, i32 %t115)
  store i32 %t116, ptr %l67
  br label %bb22
bb22:
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load i32, ptr %l67, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %t117, i32 %t118)
  store { i64, ptr } %t119, ptr %l68
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t120, ptr %l69, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i32, ptr %t122, i64 0
  %t124 = load i32, ptr %t123, !tbaa !33
  store i32 %t124, ptr %l10, !tbaa !23
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l10, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l75
  br label %bb24
bb24:
  store i32 20, ptr %l77
  %t138 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l75, ptr %l77)
  store i1 %t138, ptr %l79
  br label %bb25
bb25:
  %t139 = load i1, ptr %l79, !tbaa !21
  br i1 %t139, label %bb26, label %bb27
bb26:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %l10, !tbaa !23
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v1, ptr %t145, i32 %t146)
  store i32 %t149, ptr %l84
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t150 = load i32, ptr %l84, !tbaa !23
  store i32 %t150, ptr %l10, !tbaa !23
  br label %bb29
bb29:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  %t157 = load i32, ptr %l10, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l89
  br label %bb30
bb30:
  store i32 18, ptr %l91
  %t163 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l89, ptr %l91)
  store i1 %t163, ptr %l93
  br label %bb31
bb31:
  %t164 = load i1, ptr %l93, !tbaa !21
  %t165 = xor i1 %t164, true
  br i1 %t165, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb36
bb33:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 0
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l10, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l100
  br label %bb34
bb34:
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 0
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l2, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l105
  br label %bb35
bb35:
  %t187 = load i32, ptr %l100, !tbaa !23
  %t188 = load i32, ptr %l105, !tbaa !23
  %t189 = icmp ne i32 %t187, %t188
  store i1 %t189, ptr %l95, !tbaa !21
  br label %bb36
bb36:
  %t191 = load i1, ptr %l95, !tbaa !21
  br i1 %t191, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb38:
  br label %bb39
bb39:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 0
  %t195 = load ptr, ptr %t194, !tbaa !29
  store ptr %t195, ptr %l108, !tbaa !29
  %t196 = load i64, ptr %l8, !tbaa !24
  %t198 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t196)
  store i64 %t198, ptr %l110
  br label %bb40
bb40:
  %t199 = load ptr, ptr %l108, !tbaa !29
  %t200 = load i64, ptr %l110, !tbaa !24
  %t201 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t199, i64 %t200)
  store i64 %t201, ptr %l111
  br label %bb41
bb41:
  %t202 = load i64, ptr %l111, !tbaa !24
  %t203 = icmp eq i64 %t202, 0
  br i1 %t203, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 0
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t209 = load i64, ptr %l8, !tbaa !24
  %t212 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v1, ptr %t208, i64 %t209, i32 0)
  store i64 %t212, ptr %l116
  br label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l130, !tbaa !29
  %t214 = load ptr, ptr %l1, !tbaa !29
  store ptr %t214, ptr %l131, !tbaa !29
  %t215 = load i64, ptr %l8, !tbaa !24
  store i64 %t215, ptr %l132, !tbaa !24
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t220 = load i64, ptr %l8, !tbaa !24
  %t223 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t219, i64 %t220)
  store i32 %t223, ptr %l136
  br label %bb49
bb44:
  %t224 = load i64, ptr %l116, !tbaa !24
  store i64 %t224, ptr %l11, !tbaa !24
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l117, !tbaa !29
  %t226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t226, ptr %l118, !tbaa !29
  %t227 = load i64, ptr %l8, !tbaa !24
  store i64 %t227, ptr %l119, !tbaa !24
  %t228 = load ptr, ptr %l1, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 0
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t232 = load i64, ptr %l11, !tbaa !24
  %t235 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v1, ptr %t231, i64 %t232)
  store i32 %t235, ptr %l123
  br label %bb45
bb45:
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t237 = load i64, ptr %l11, !tbaa !24
  %t240 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v1, ptr %t236, i64 %t237)
  store i64 %t240, ptr %l126
  br label %bb46
bb46:
  %t241 = load ptr, ptr %l118, !tbaa !29
  %t242 = load i64, ptr %l119, !tbaa !24
  %t243 = load i32, ptr %l123, !tbaa !23
  %t244 = load i64, ptr %l126, !tbaa !24
  %t245 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s6, ptr %t241, i64 %t242, i32 %t243, i64 %t244)
  store { i64, ptr } %t245, ptr %l127
  br label %bb47
bb47:
  %t246 = extractvalue { i64, ptr } { i64 4, ptr @.d39 }, 1
  %t247 = extractvalue { i64, ptr } { i64 4, ptr @.d39 }, 0
  %t248 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t248, 1
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t251 = add i64 %t247, %t250
  %t252 = extractvalue { i64, ptr } { i64 1, ptr @.d40 }, 1
  %t253 = extractvalue { i64, ptr } { i64 1, ptr @.d40 }, 0
  %t254 = add i64 %t251, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t246, i64 %t247)
  %t256 = getelementptr i8, ptr %t255, i64 %t247
  call void @olang_textcopy(ptr %t256, ptr %t249, i64 %t250)
  %t257 = getelementptr i8, ptr %t256, i64 %t250
  call void @olang_textcopy(ptr %t257, ptr %t252, i64 %t253)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t255, 1
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t262 = extractvalue { i64, ptr } %t259, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t267 = load ptr, ptr %l117, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t267, { i64, ptr } %t266)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb52
bb49:
  %t269 = load ptr, ptr %l131, !tbaa !29
  %t270 = load i64, ptr %l132, !tbaa !24
  %t271 = load i32, ptr %l136, !tbaa !23
  %t272 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s8, ptr %t269, i64 %t270, i32 %t271, i64 -1)
  store { i64, ptr } %t272, ptr %l137
  br label %bb50
bb50:
  %t273 = extractvalue { i64, ptr } { i64 4, ptr @.d41 }, 1
  %t274 = extractvalue { i64, ptr } { i64 4, ptr @.d41 }, 0
  %t275 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = add i64 %t274, %t277
  %t279 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 1
  %t280 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 0
  %t281 = add i64 %t278, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t273, i64 %t274)
  %t283 = getelementptr i8, ptr %t282, i64 %t274
  call void @olang_textcopy(ptr %t283, ptr %t276, i64 %t277)
  %t284 = getelementptr i8, ptr %t283, i64 %t277
  call void @olang_textcopy(ptr %t284, ptr %t279, i64 %t280)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t282, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = extractvalue { i64, ptr } %t286, 1
  %t290 = mul i64 %t288, 1
  %t291 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t290)
  call void @llvm.memcpy.p0.p0.i64(ptr %t291, ptr %t289, i64 %t290, i1 false)
  %t292 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  %t294 = load ptr, ptr %l130, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t294, { i64, ptr } %t293)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb53:
  %t296 = load i64, ptr %l7, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l7, !tbaa !24
  br label %bb9
bb54:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l9
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = icmp ne ptr %t4, null
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Param", ptr %t8, i32 0, i32 1
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = sext i32 %t11 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t13)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = extractvalue { i64, ptr } zeroinitializer, 0
  %t20 = icmp eq i64 %t18, %t19
  %t21 = extractvalue { i64, ptr } %t16, 1
  %t22 = extractvalue { i64, ptr } zeroinitializer, 1
  %t23 = icmp eq ptr %t21, %t22
  %t24 = and i1 %t20, %t23
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l7, !tbaa !24
  br label %bb8
bb7:
  br label %bb15
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr ptr, ptr %t45, i64 %t42
  %t47 = load ptr, ptr %t46, !tbaa !39
  %t51 = getelementptr %"compiler/ast:Param", ptr %t47, i32 0, i32 1
  %t52 = load i32, ptr %t51, !tbaa !23
  %t54 = sext i32 %t52 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t54)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  br label %bb15
bb15:
  %t62 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t62, ptr %l35
  br label %bb16
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l38, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l1, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l43
  br label %bb17
bb17:
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = load i32, ptr %l43, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l44
  br label %bb18
bb18:
  %t82 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  %t84 = load i64, ptr %l35, !tbaa !24
  %t86 = icmp ne i64 %t84, %t83
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t88 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t88, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  store ptr %t95, ptr %l50, !tbaa !29
  %t96 = load i32, ptr %l1, !tbaa !23
  store i32 %t96, ptr %l51, !tbaa !23
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l54, !tbaa !29
  %t104 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t104, ptr %l56
  br label %bb22
bb22:
  %t105 = load ptr, ptr %l54, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t107 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %s0, ptr %t105, { i64, ptr } %t106)
  store i64 %t107, ptr %l57
  br label %bb23
bb23:
  %t108 = load ptr, ptr %l50, !tbaa !29
  %t109 = load i32, ptr %l51, !tbaa !23
  %t110 = load i64, ptr %l57, !tbaa !24
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t108, i32 %t109, i64 %t110)
  store i32 %t111, ptr %l58
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t112 = load i32, ptr %l58, !tbaa !23
  store i32 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fexplain_2eobligations(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v2, ptr %v1, ptr %s2, ptr %a2, i64 %t6, ptr %t16)
  store { i64, ptr } %t20, ptr %l17
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 16
  %t25 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  %t53 = extractvalue { i64, ptr } %a4, 1
  %t54 = extractvalue { i64, ptr } %a4, 0
  %t55 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 0
  %t57 = add i64 %t54, %t56
  %t59 = extractvalue { i64, ptr } %t47, 1
  %t60 = extractvalue { i64, ptr } %t47, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 2, ptr @.d44 }, 1
  %t63 = extractvalue { i64, ptr } { i64 2, ptr @.d44 }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = getelementptr i8, ptr %t65, i64 %t54
  call void @olang_textcopy(ptr %t66, ptr %t55, i64 %t56)
  %t67 = getelementptr i8, ptr %t66, i64 %t56
  call void @olang_textcopy(ptr %t67, ptr %t59, i64 %t60)
  %t68 = getelementptr i8, ptr %t67, i64 %t60
  call void @olang_textcopy(ptr %t68, ptr %t62, i64 %t63)
  %t69 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t65, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %a0, { i64, ptr } %t77)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb5
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2equoted(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb2
bb2:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t19
  %t24 = load i8, ptr %t23, !tbaa !32
  store i8 %t24, ptr %l5, !tbaa !22
  %t26 = load i8, ptr %l5, !tbaa !22
  %t28 = icmp eq i8 %t26, 34
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 92
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb12
bb11:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 10
  br i1 %t38, label %bb14, label %bb15
bb12:
  %t40 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t40)
  br label %bb13
bb13:
  br label %bb23
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr @.d45 })
  br label %bb16
bb15:
  %t44 = load i8, ptr %l5, !tbaa !22
  %t46 = icmp eq i8 %t44, 9
  br i1 %t46, label %bb17, label %bb18
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 2, ptr @.d46 })
  br label %bb19
bb18:
  %t49 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t49)
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s7)
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb3
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb26
bb26:
  %t58 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t58, ptr %l38
  br label %bb27
bb27:
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t59, ptr %l39, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l40, !tbaa !24
  %t62 = load i64, ptr %l40, !tbaa !24
  %t63 = mul i64 %t62, 1
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l41, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = mul i64 %t71, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t68, ptr %t70, i64 %t72, i1 false)
  %t73 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t73, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l6 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l29 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %l38 = alloca i32
  %l43 = alloca i32
  %l45 = alloca i32
  %l47 = alloca i1
  %l52 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Func", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l20
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load i32, ptr %l20, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l13, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 0
  %t47 = load i32, ptr %t46, !tbaa !33
  store i32 %t47, ptr %l2, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l29
  br label %bb8
bb8:
  store i32 20, ptr %l31
  %t61 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l29, ptr %l31)
  store i1 %t61, ptr %l33
  br label %bb9
bb9:
  %t62 = load i1, ptr %l33, !tbaa !21
  br i1 %t62, label %bb10, label %bb11
bb10:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l38
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t73 = load i32, ptr %l38, !tbaa !23
  store i32 %t73, ptr %l2, !tbaa !23
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l43
  br label %bb14
bb14:
  store i32 18, ptr %l45
  %t86 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l43, ptr %l45)
  store i1 %t86, ptr %l47
  br label %bb15
bb15:
  %t87 = load i1, ptr %l47, !tbaa !21
  %t88 = xor i1 %t87, true
  br i1 %t88, label %bb16, label %bb17
bb16:
  store i64 0, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  store ptr %t96, ptr %l52, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l2, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l57
  br label %bb19
bb19:
  %t107 = load ptr, ptr %l52, !tbaa !29
  %t108 = load i32, ptr %l57, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t107, i32 %t108)
  store { i64, ptr } %t109, ptr %l58
  br label %bb20
bb20:
  %t110 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i64
  %l42 = alloca i32
  %l45 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l10
  br label %bb3
bb3:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %t14, i32 %t15)
  store { i64, ptr } %t18, ptr %l14
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t24, ptr %l17
  br label %bb9
bb9:
  %t25 = load i32, ptr %l17, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l25
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb11
bb11:
  %t52 = load i32, ptr %l3, !tbaa !23
  store i32 %t52, ptr %l31, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l36
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t72, ptr %l41
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l20, !tbaa !29
  %t74 = load i32, ptr %l25, !tbaa !23
  %t75 = load i32, ptr %l30, !tbaa !23
  %t76 = load i32, ptr %l31, !tbaa !23
  %t77 = load i32, ptr %l36, !tbaa !23
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 %t74, i32 %t75, i32 %t76, i32 %t77, i64 %t78)
  store i32 %t79, ptr %l42
  br label %bb14
bb14:
  %t80 = load i32, ptr %l42, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t81, i32 %t80)
  store { i64, ptr } %t85, ptr %l45
  br label %bb15
bb15:
  %t86 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } { i64 27, ptr @.d47 }, 1
  %t90 = extractvalue { i64, ptr } { i64 27, ptr @.d47 }, 0
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = getelementptr i8, ptr %t92, i64 %t88
  call void @olang_textcopy(ptr %t93, ptr %t89, i64 %t90)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2etraitsMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca %"compiler/names:Entry"
  %l86 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i1
  %l92 = alloca i1
  %l96 = alloca %"compiler/names:Entry"
  %l103 = alloca i32
  %l108 = alloca i32
  %l110 = alloca i32
  %l112 = alloca i1
  %l114 = alloca i1
  %l116 = alloca ptr
  %l118 = alloca i64
  %l119 = alloca i64
  %l124 = alloca i32
  %l129 = alloca i1
  %l130 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l140 = alloca i64
  %l142 = alloca ptr
  %l144 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l19
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/names:Resolver", ptr %t10, i32 0, i32 1
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_Hb234e65a2b42ee429ada36859295662b(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l24, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l31, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l31, !tbaa !24
  store i64 %t42, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/names:Resolver", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v1, ptr %v1, ptr %t70, i64 %t71)
  store ptr %t74, ptr %l54
  br label %bb13
bb13:
  %t75 = load ptr, ptr %l54, !tbaa !29
  store ptr %t75, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  %t76 = load ptr, ptr %l10, !tbaa !29
  %t78 = getelementptr %"compiler/names:Table", ptr %t76, i32 0, i32 0
  %t80 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %t78)
  store i64 %t80, ptr %l57
  br label %bb14
bb14:
  %t81 = load i64, ptr %l57, !tbaa !24
  store i64 %t81, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t82 = load i64, ptr %l12, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb15, label %bb16
bb15:
  %t88 = load i64, ptr %l13, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb20
bb17:
  %t92 = load i64, ptr %l12, !tbaa !24
  %t93 = load i64, ptr %l11, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l13, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l64, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb19
bb19:
  %t108 = load i64, ptr %l64, !tbaa !24
  store i64 %t108, ptr %l61, !tbaa !24
  br label %bb20
bb20:
  %t109 = load i64, ptr %l61, !tbaa !24
  store i64 %t109, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t110 = load i64, ptr %l15, !tbaa !24
  %t111 = load i64, ptr %l14, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb53
bb23:
  br label %bb24
bb24:
  %t118 = load i64, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l15, !tbaa !24
  %t120 = load i64, ptr %l13, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  store i64 %t126, ptr %l16, !tbaa !24
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t130 = getelementptr %"compiler/names:Table", ptr %t128, i32 0, i32 0
  %t131 = load i64, ptr %l16, !tbaa !24
  %t134 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %s4, ptr %t130, i64 %t131)
  store %"compiler/names:Entry" %t134, ptr %l85
  br label %bb25
bb25:
  %t135 = getelementptr %"compiler/names:Entry", ptr %l85, i32 0, i32 2
  %t136 = load i32, ptr %t135
  store i32 %t136, ptr %l86
  store i32 4, ptr %l88
  %t139 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l86, ptr %l88)
  store i1 %t139, ptr %l90
  br label %bb26
bb26:
  %t140 = load i1, ptr %l90, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb30
bb28:
  %t143 = load ptr, ptr %l10, !tbaa !29
  %t145 = getelementptr %"compiler/names:Table", ptr %t143, i32 0, i32 0
  %t146 = load i64, ptr %l16, !tbaa !24
  %t149 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %v1, ptr %t145, i64 %t146)
  store %"compiler/names:Entry" %t149, ptr %l96
  br label %bb29
bb29:
  %t150 = getelementptr %"compiler/names:Entry", ptr %l96, i32 0, i32 4
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  store i1 %t153, ptr %l92, !tbaa !21
  br label %bb30
bb30:
  %t155 = load i1, ptr %l92, !tbaa !21
  br i1 %t155, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb32:
  br label %bb33
bb33:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 0
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i64, ptr %l9, !tbaa !24
  %t161 = load i64, ptr %l16, !tbaa !24
  %t165 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v1, ptr %t159, i64 %t160, i64 %t161)
  store i32 %t165, ptr %l103
  br label %bb34
bb34:
  %t166 = load i32, ptr %l103, !tbaa !23
  store i32 %t166, ptr %l17, !tbaa !23
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 0
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l17, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v1, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l108
  br label %bb35
bb35:
  store i32 3, ptr %l110
  %t179 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aDeclKind(ptr %l108, ptr %l110)
  store i1 %t179, ptr %l112
  br label %bb36
bb36:
  %t180 = load i1, ptr %l112, !tbaa !21
  %t181 = xor i1 %t180, true
  br i1 %t181, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb41
bb38:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l116, !tbaa !29
  %t187 = load i32, ptr %l17, !tbaa !23
  %t189 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t187)
  store i64 %t189, ptr %l118
  br label %bb39
bb39:
  %t190 = load ptr, ptr %l116, !tbaa !29
  %t191 = load i64, ptr %l118, !tbaa !24
  %t192 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t190, i64 %t191)
  store i64 %t192, ptr %l119
  br label %bb40
bb40:
  %t193 = load i64, ptr %l119, !tbaa !24
  %t194 = icmp sgt i64 %t193, 0
  store i1 %t194, ptr %l114, !tbaa !21
  br label %bb41
bb41:
  %t196 = load i1, ptr %l114, !tbaa !21
  br i1 %t196, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb43:
  br label %bb44
bb44:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 0
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t201 = load i32, ptr %l17, !tbaa !23
  %t204 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v1, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l124
  br label %bb45
bb45:
  %t205 = load i32, ptr %l124, !tbaa !23
  store i32 %t205, ptr %l18, !tbaa !23
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 0
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = load i32, ptr %l18, !tbaa !23
  %t215 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v1, ptr %t209, i32 %a2, i32 %t211)
  store i1 %t215, ptr %l129
  br label %bb46
bb46:
  %t216 = load i1, ptr %l129, !tbaa !21
  br i1 %t216, label %bb47, label %bb48
bb47:
  store ptr %l3, ptr %l130, !tbaa !29
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t218 = load i32, ptr %l18, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s0, ptr %t217, i32 %t218)
  store { i64, ptr } %t221, ptr %l133
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t222 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t229 = load ptr, ptr %l130, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t229, { i64, ptr } %t228)
  br label %bb50
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb52:
  %t231 = load i64, ptr %l15, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l15, !tbaa !24
  br label %bb21
bb53:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb54:
  %t235 = load i64, ptr %l8, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l8, !tbaa !24
  br label %bb9
bb55:
  %t240 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l3)
  store i64 %t240, ptr %l140
  br label %bb56
bb56:
  %t241 = load i64, ptr %l140, !tbaa !24
  %t242 = icmp sgt i64 %t241, 0
  br i1 %t242, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %a0, ptr %l142, !tbaa !29
  %t246 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s10, ptr %s10, ptr %l3, { i64, ptr } { i64 2, ptr @.d48 })
  store { i64, ptr } %t246, ptr %l144
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t247 = extractvalue { i64, ptr } { i64 10, ptr @.d49 }, 1
  %t248 = extractvalue { i64, ptr } { i64 10, ptr @.d49 }, 0
  %t249 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = add i64 %t248, %t251
  %t253 = extractvalue { i64, ptr } { i64 1, ptr @.d50 }, 1
  %t254 = extractvalue { i64, ptr } { i64 1, ptr @.d50 }, 0
  %t255 = add i64 %t252, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t247, i64 %t248)
  %t257 = getelementptr i8, ptr %t256, i64 %t248
  call void @olang_textcopy(ptr %t257, ptr %t250, i64 %t251)
  %t258 = getelementptr i8, ptr %t257, i64 %t251
  call void @olang_textcopy(ptr %t258, ptr %t253, i64 %t254)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t256, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } %t260, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t268 = load ptr, ptr %l142, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s10, ptr %t268, { i64, ptr } %t267)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 60)
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t9, i32 %a1)
  store { i64, ptr } %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb6:
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  store i32 %t33, ptr %l7, !tbaa !23
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr @.d51 })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb11:
  store ptr %l2, ptr %l27, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l7, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s2, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l30
  br label %bb12
bb12:
  %t45 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t52 = load ptr, ptr %l27, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t52, { i64, ptr } %t51)
  br label %bb13
bb13:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb4
bb15:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 62)
  br label %bb16
bb16:
  %t64 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t64, ptr %l38
  br label %bb17
bb17:
  %t65 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t65, ptr %l39, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l40, !tbaa !24
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l41, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l40, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t79, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t80 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca %"std/prelude/text:StringBuilder"
  %l39 = alloca i32
  %l43 = alloca i1
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l64 = alloca i32
  %l74 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l110 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca i1
  %l124 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l142 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i64
  %l151 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l159 = alloca i64
  %l160 = alloca { i64, ptr }
  %l169 = alloca ptr
  %l174 = alloca i32
  %l175 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l186 = alloca i64
  %l189 = alloca i64
  %l207 = alloca ptr
  %l209 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l219 = alloca i1
  %l220 = alloca { i64, ptr }
  %l224 = alloca ptr
  %l225 = alloca ptr
  %l230 = alloca i32
  %l234 = alloca ptr
  %l236 = alloca { i64, ptr }
  %l237 = alloca i32
  %l238 = alloca { i64, ptr }
  %l239 = alloca ptr
  %l241 = alloca i64
  %l242 = alloca i64
  %l243 = alloca i64
  %l253 = alloca ptr
  %l254 = alloca { i64, ptr }
  %l258 = alloca i1
  %l259 = alloca { i64, ptr }
  %l260 = alloca ptr
  %l265 = alloca i32
  %l266 = alloca { i64, ptr }
  %l272 = alloca ptr
  %l275 = alloca ptr
  %l276 = alloca i1
  %l283 = alloca ptr
  %l284 = alloca ptr
  %l288 = alloca i32
  %l292 = alloca i32
  %l293 = alloca { i64, ptr }
  %l295 = alloca i64
  %l296 = alloca ptr
  %l298 = alloca i64
  %l299 = alloca i64
  %l303 = alloca { i64, ptr }
  %l305 = alloca i64
  %l307 = alloca i64
  %l308 = alloca i64
  %l313 = alloca { i64, ptr }
  %l319 = alloca ptr
  %l320 = alloca ptr
  %l324 = alloca i32
  %l328 = alloca ptr
  %l329 = alloca { i64, ptr }
  %l330 = alloca i32
  %l331 = alloca { i64, ptr }
  %l333 = alloca i64
  %l334 = alloca ptr
  %l335 = alloca { i64, ptr }
  %l337 = alloca i64
  %l338 = alloca i64
  %l342 = alloca { i64, ptr }
  %l344 = alloca i64
  %l346 = alloca i64
  %l347 = alloca i64
  %l352 = alloca { i64, ptr }
  %l365 = alloca { i64, ptr }
  %l366 = alloca { i64, ptr }
  %l367 = alloca i64
  %l368 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l35
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l35
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l39
  br label %bb2
bb2:
  %t11 = load i32, ptr %l39, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l43
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l4, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  store ptr %t31, ptr %l48, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l53
  br label %bb4
bb4:
  %t42 = load ptr, ptr %l48, !tbaa !29
  %t43 = load i32, ptr %l53, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l54
  br label %bb5
bb5:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l55, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t48 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t46)
  store i64 %t48, ptr %l57
  br label %bb6
bb6:
  %t49 = load ptr, ptr %l55, !tbaa !29
  %t50 = load i64, ptr %l57, !tbaa !24
  %t51 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t49, i64 %t50, i64 0)
  store { i64, ptr } %t51, ptr %l58
  br label %bb7
bb7:
  %t52 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = add i64 %t54, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t53, i64 %t54)
  %t60 = getelementptr i8, ptr %t59, i64 %t54
  call void @olang_textcopy(ptr %t60, ptr %t56, i64 %t57)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  store { i64, ptr } %t62, ptr %l5, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l64
  br label %bb8
bb8:
  %t74 = load i32, ptr %l64
  store i32 %t74, ptr %l6
  %t75 = load i32, ptr %l6
  %t77 = trunc i64 2 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb23
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = extractvalue { i64, ptr } { i64 6, ptr @.d52 }, 1
  %t82 = extractvalue { i64, ptr } { i64 6, ptr @.d52 }, 0
  %t84 = extractvalue { i64, ptr } %t80, 1
  %t85 = extractvalue { i64, ptr } %t80, 0
  %t86 = add i64 %t82, %t85
  %t87 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 1
  %t88 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 0
  %t89 = add i64 %t86, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t81, i64 %t82)
  %t91 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t91, ptr %t84, i64 %t85)
  %t92 = getelementptr i8, ptr %t91, i64 %t85
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t90, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = extractvalue { i64, ptr } %t94, 1
  %t98 = mul i64 %t96, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t97, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t101)
  br label %bb12
bb12:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l74
  br label %bb13
bb13:
  %t112 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t112, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t117 = load i64, ptr %l8, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb16:
  br label %bb17
bb17:
  %t125 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t125, ptr %l81, !tbaa !27
  %t126 = load i64, ptr %l8, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i32, ptr %t129, i64 %t126
  %t131 = load i32, ptr %t130, !tbaa !33
  store ptr %l2, ptr %l84, !tbaa !29
  %t133 = load ptr, ptr %l4, !tbaa !29
  %t137 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t133, i32 %t131)
  store { i64, ptr } %t137, ptr %l87
  br label %bb18
bb18:
  %t138 = extractvalue { i64, ptr } { i64 4, ptr @.d54 }, 1
  %t139 = extractvalue { i64, ptr } { i64 4, ptr @.d54 }, 0
  %t140 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = add i64 %t139, %t142
  %t144 = extractvalue { i64, ptr } { i64 1, ptr @.d55 }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr @.d55 }, 0
  %t146 = add i64 %t143, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t138, i64 %t139)
  %t148 = getelementptr i8, ptr %t147, i64 %t139
  call void @olang_textcopy(ptr %t148, ptr %t141, i64 %t142)
  %t149 = getelementptr i8, ptr %t148, i64 %t142
  call void @olang_textcopy(ptr %t149, ptr %t144, i64 %t145)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t147, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t159 = load ptr, ptr %l84, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t159, { i64, ptr } %t158)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t161 = load i64, ptr %l8, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l8, !tbaa !24
  br label %bb14
bb21:
  %t166 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t166, ptr %l93
  br label %bb22
bb22:
  %t167 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t167, ptr %l94, !tbaa !27
  %t168 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  store i64 %t169, ptr %l95, !tbaa !24
  %t170 = load i64, ptr %l95, !tbaa !24
  %t171 = mul i64 %t170, 1
  %t172 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l96, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = load i64, ptr %l95, !tbaa !24
  %t180 = mul i64 %t179, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t176, ptr %t178, i64 %t180, i1 false)
  %t181 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t181, ptr %l94, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t182 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t182, ptr %rv
  br label %ret
bb23:
  %t183 = load i32, ptr %l6
  %t185 = trunc i64 3 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb57
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t188 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t189 = extractvalue { i64, ptr } { i64 5, ptr @.d56 }, 1
  %t190 = extractvalue { i64, ptr } { i64 5, ptr @.d56 }, 0
  %t192 = extractvalue { i64, ptr } %t188, 1
  %t193 = extractvalue { i64, ptr } %t188, 0
  %t194 = add i64 %t190, %t193
  %t195 = extractvalue { i64, ptr } { i64 7, ptr @.d57 }, 1
  %t196 = extractvalue { i64, ptr } { i64 7, ptr @.d57 }, 0
  %t197 = add i64 %t194, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t189, i64 %t190)
  %t199 = getelementptr i8, ptr %t198, i64 %t190
  call void @olang_textcopy(ptr %t199, ptr %t192, i64 %t193)
  %t200 = getelementptr i8, ptr %t199, i64 %t193
  call void @olang_textcopy(ptr %t200, ptr %t195, i64 %t196)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t198, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l2, { i64, ptr } %t209)
  br label %bb27
bb27:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 0
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t216 = load i32, ptr %l1, !tbaa !23
  %t219 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t215, i32 %t216)
  store ptr %t219, ptr %l106
  br label %bb28
bb28:
  %t220 = load ptr, ptr %l106, !tbaa !29
  store ptr %t220, ptr %l11, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t225 = load i32, ptr %l1, !tbaa !23
  %t228 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t224, i32 %t225)
  store i64 %t228, ptr %l110
  br label %bb29
bb29:
  %t229 = load i64, ptr %l110, !tbaa !24
  store i64 %t229, ptr %l12, !tbaa !24
  %t230 = load ptr, ptr %l11, !tbaa !29
  %t232 = getelementptr %"compiler/ast:TypeDecl", ptr %t230, i32 0, i32 3
  %t233 = load ptr, ptr %t232, !tbaa !29
  store ptr %t233, ptr %l13, !tbaa !29
  %t235 = load ptr, ptr %l13, !tbaa !29
  store ptr %t235, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t236 = load ptr, ptr %l113, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb30, label %bb31
bb30:
  %t239 = load ptr, ptr %l113, !tbaa !29
  %t240 = load i64, ptr %t239
  %t242 = icmp eq i64 %t240, 2
  store i1 %t242, ptr %l114, !tbaa !21
  br label %bb31
bb31:
  %t243 = load i1, ptr %l114, !tbaa !21
  br i1 %t243, label %bb32, label %bb33
bb32:
  %t244 = load ptr, ptr %l13, !tbaa !29
  %t246 = getelementptr { i64, [2 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { { i64, ptr } }, ptr %t246, i32 0, i32 0
  %t248 = load { i64, ptr }, ptr %t247
  store { i64, ptr } %t248, ptr %l14, !tbaa !27
  br label %bb34
bb33:
  br label %bb50
bb34:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 0
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 0
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = getelementptr %"compiler/load:Loader", ptr %t256, i32 0, i32 5
  %t259 = load i64, ptr %l12, !tbaa !24
  %t262 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t258, i64 %t259)
  store ptr %t262, ptr %l124
  br label %bb35
bb35:
  %t263 = load ptr, ptr %l124, !tbaa !29
  %t265 = getelementptr %"compiler/load:Module", ptr %t263, i32 0, i32 6
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = getelementptr %"compiler/source:Source", ptr %t266, i32 0, i32 1
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  store { i64, ptr } %t269, ptr %l15, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t271, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t273 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t273, 0
  store i64 %t275, ptr %l18, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s12
  %t277 = load i64, ptr %l17, !tbaa !24
  %t278 = load i64, ptr %l18, !tbaa !24
  %t281 = icmp slt i64 %t277, %t278
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s12)
  br label %bb49
bb38:
  br label %bb39
bb39:
  %t285 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t285, ptr %l135, !tbaa !27
  %t286 = load i64, ptr %l17, !tbaa !24
  %t288 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr ptr, ptr %t289, i64 %t286
  %t291 = load ptr, ptr %t290, !tbaa !39
  store ptr %t291, ptr %l19, !tbaa !29
  store ptr %l2, ptr %l138, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t293, ptr %l139, !tbaa !27
  %t294 = load ptr, ptr %l19, !tbaa !29
  %t296 = getelementptr %"compiler/ast:Func", ptr %t294, i32 0, i32 0
  %t297 = getelementptr %"compiler/source:Span", ptr %t296, i32 0, i32 0
  %t298 = load i32, ptr %t297, !tbaa !23
  %t300 = sext i32 %t298 to i64
  store i64 %t300, ptr %l142, !tbaa !24
  %t301 = load ptr, ptr %l19, !tbaa !29
  %t303 = getelementptr %"compiler/ast:Func", ptr %t301, i32 0, i32 0
  %t304 = getelementptr %"compiler/source:Span", ptr %t303, i32 0, i32 1
  %t305 = load i32, ptr %t304, !tbaa !23
  %t307 = sext i32 %t305 to i64
  store i64 %t307, ptr %l145, !tbaa !24
  %t308 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  store i64 %t309, ptr %l146, !tbaa !24
  %t310 = load i64, ptr %l142, !tbaa !24
  %t311 = icmp sge i64 %t310, 0
  br i1 %t311, label %bb40, label %bb41
bb40:
  %t313 = load i64, ptr %l142, !tbaa !24
  %t314 = load i64, ptr %l145, !tbaa !24
  %t315 = icmp sle i64 %t313, %t314
  br i1 %t315, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @.c58)
  unreachable
bb42:
  %t317 = load i64, ptr %l145, !tbaa !24
  %t318 = load i64, ptr %l146, !tbaa !24
  %t319 = icmp sle i64 %t317, %t318
  br i1 %t319, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @.c58)
  unreachable
bb44:
  %t321 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = load i64, ptr %l142, !tbaa !24
  %t324 = load i64, ptr %l145, !tbaa !24
  %t325 = getelementptr i8, ptr %t322, i64 %t323
  %t326 = sub i64 %t324, %t323
  %t327 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t325, 1
  %t330 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t328)
  store { i64, ptr } %t330, ptr %l151
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @.c58)
  unreachable
bb46:
  %t331 = extractvalue { i64, ptr } { i64 4, ptr @.d59 }, 1
  %t332 = extractvalue { i64, ptr } { i64 4, ptr @.d59 }, 0
  %t333 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t333, 1
  %t335 = extractvalue { i64, ptr } %t333, 0
  %t336 = add i64 %t332, %t335
  %t337 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 1
  %t338 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 0
  %t339 = add i64 %t336, %t338
  %t340 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t339)
  call void @olang_textcopy(ptr %t340, ptr %t331, i64 %t332)
  %t341 = getelementptr i8, ptr %t340, i64 %t332
  call void @olang_textcopy(ptr %t341, ptr %t334, i64 %t335)
  %t342 = getelementptr i8, ptr %t341, i64 %t335
  call void @olang_textcopy(ptr %t342, ptr %t337, i64 %t338)
  %t343 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t340, 1
  %t346 = extractvalue { i64, ptr } %t344, 0
  %t347 = extractvalue { i64, ptr } %t344, 1
  %t348 = mul i64 %t346, 1
  %t349 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t348)
  call void @llvm.memcpy.p0.p0.i64(ptr %t349, ptr %t347, i64 %t348, i1 false)
  %t350 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t349, 1
  %t352 = load ptr, ptr %l138, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t352, { i64, ptr } %t351)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s12)
  br label %bb48
bb48:
  %t354 = load i64, ptr %l17, !tbaa !24
  %t356 = add i64 %t354, 1
  store i64 %t356, ptr %l17, !tbaa !24
  br label %bb36
bb49:
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @.c61)
  unreachable
bb55:
  %t359 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t359, ptr %l157
  br label %bb56
bb56:
  %t360 = load { i64, ptr }, ptr %l157, !tbaa !27
  store { i64, ptr } %t360, ptr %l158, !tbaa !27
  %t361 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t361, 0
  store i64 %t362, ptr %l159, !tbaa !24
  %t363 = load i64, ptr %l159, !tbaa !24
  %t364 = mul i64 %t363, 1
  %t365 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t364)
  %t366 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t367 = insertvalue { i64, ptr } %t366, ptr %t365, 1
  store { i64, ptr } %t367, ptr %l160, !tbaa !27
  %t368 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = load i64, ptr %l159, !tbaa !24
  %t373 = mul i64 %t372, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t369, ptr %t371, i64 %t373, i1 false)
  %t374 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t374, ptr %l158, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t375 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t375, ptr %rv
  br label %ret
bb57:
  %t376 = load i32, ptr %l6
  %t378 = trunc i64 1 to i32
  %t379 = icmp eq i32 %t376, %t378
  br i1 %t379, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb99
bb60:
  store %olang.scope zeroinitializer, ptr %s16
  %t381 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t382 = extractvalue { i64, ptr } { i64 5, ptr @.d62 }, 1
  %t383 = extractvalue { i64, ptr } { i64 5, ptr @.d62 }, 0
  %t385 = extractvalue { i64, ptr } %t381, 1
  %t386 = extractvalue { i64, ptr } %t381, 0
  %t387 = add i64 %t383, %t386
  %t388 = extractvalue { i64, ptr } { i64 6, ptr @.d63 }, 1
  %t389 = extractvalue { i64, ptr } { i64 6, ptr @.d63 }, 0
  %t390 = add i64 %t387, %t389
  %t391 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t390)
  call void @olang_textcopy(ptr %t391, ptr %t382, i64 %t383)
  %t392 = getelementptr i8, ptr %t391, i64 %t383
  call void @olang_textcopy(ptr %t392, ptr %t385, i64 %t386)
  %t393 = getelementptr i8, ptr %t392, i64 %t386
  call void @olang_textcopy(ptr %t393, ptr %t388, i64 %t389)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t391, 1
  %t397 = extractvalue { i64, ptr } %t395, 0
  %t398 = extractvalue { i64, ptr } %t395, 1
  %t399 = mul i64 %t397, 1
  %t400 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t399)
  call void @llvm.memcpy.p0.p0.i64(ptr %t400, ptr %t398, i64 %t399, i1 false)
  %t401 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t402 = insertvalue { i64, ptr } %t401, ptr %t400, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l2, { i64, ptr } %t402)
  br label %bb61
bb61:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/check:Checker", ptr %t405, i32 0, i32 0
  %t408 = load ptr, ptr %t407, !tbaa !29
  %t410 = getelementptr %"compiler/generic:Program", ptr %t408, i32 0, i32 2
  store ptr %t410, ptr %l169, !tbaa !29
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/check:Checker", ptr %t411, i32 0, i32 0
  %t414 = load ptr, ptr %t413, !tbaa !29
  %t416 = getelementptr %"compiler/generic:Program", ptr %t414, i32 0, i32 2
  %t417 = load i32, ptr %l3, !tbaa !23
  %t420 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t416, i32 %t417)
  store i32 %t420, ptr %l174
  br label %bb62
bb62:
  %t421 = load ptr, ptr %l169, !tbaa !29
  %t422 = load i32, ptr %l174, !tbaa !23
  %t423 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t421, i32 %t422)
  store { i64, ptr } %t423, ptr %l175
  br label %bb63
bb63:
  %t424 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t424, ptr %l20, !tbaa !27
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/check:Checker", ptr %t425, i32 0, i32 0
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t430 = getelementptr %"compiler/generic:Program", ptr %t428, i32 0, i32 2
  %t431 = load i32, ptr %l3, !tbaa !23
  %t434 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t430, i32 %t431)
  store { i64, ptr } %t434, ptr %l180
  br label %bb64
bb64:
  %t435 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t435, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t436 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t436, 0
  store i64 %t438, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t440 = load i64, ptr %l23, !tbaa !24
  %t441 = load i64, ptr %l22, !tbaa !24
  %t444 = icmp sgt i64 %t440, %t441
  br i1 %t444, label %bb65, label %bb66
bb65:
  %t446 = load i64, ptr %l24, !tbaa !24
  %t448 = icmp sgt i64 %t446, 0
  br i1 %t448, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l186, !tbaa !24
  br label %bb70
bb67:
  %t450 = load i64, ptr %l23, !tbaa !24
  %t451 = load i64, ptr %l22, !tbaa !24
  %t454 = sub i64 %t450, %t451
  %t455 = load i64, ptr %l24, !tbaa !24
  %t458 = add i64 %t454, %t455
  %t460 = sub i64 %t458, 1
  %t461 = load i64, ptr %l24, !tbaa !24
  %t464 = sdiv i64 %t460, %t461
  store i64 %t464, ptr %l189, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l189, !tbaa !24
  br label %bb69
bb69:
  %t466 = load i64, ptr %l189, !tbaa !24
  store i64 %t466, ptr %l186, !tbaa !24
  br label %bb70
bb70:
  %t467 = load i64, ptr %l186, !tbaa !24
  store i64 %t467, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s19
  %t468 = load i64, ptr %l26, !tbaa !24
  %t469 = load i64, ptr %l25, !tbaa !24
  %t472 = icmp slt i64 %t468, %t469
  %t474 = xor i1 %t472, true
  br i1 %t474, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s19)
  br label %bb98
bb73:
  br label %bb74
bb74:
  %t476 = load i64, ptr %l22, !tbaa !24
  %t477 = load i64, ptr %l26, !tbaa !24
  %t478 = load i64, ptr %l24, !tbaa !24
  %t481 = mul i64 %t477, %t478
  %t484 = add i64 %t476, %t481
  store i64 %t484, ptr %l27, !tbaa !24
  store ptr %l2, ptr %l207, !tbaa !29
  %t486 = load ptr, ptr %l4, !tbaa !29
  %t487 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t487, ptr %l209, !tbaa !27
  %t488 = load i64, ptr %l27, !tbaa !24
  %t490 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !27
  %t492 = getelementptr i32, ptr %t491, i64 %t488
  %t493 = load i32, ptr %t492, !tbaa !33
  %t496 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t486, i32 %t493)
  store { i64, ptr } %t496, ptr %l212
  br label %bb75
bb75:
  %t497 = extractvalue { i64, ptr } { i64 4, ptr @.d64 }, 1
  %t498 = extractvalue { i64, ptr } { i64 4, ptr @.d64 }, 0
  %t499 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t500 = extractvalue { i64, ptr } %t499, 1
  %t501 = extractvalue { i64, ptr } %t499, 0
  %t502 = add i64 %t498, %t501
  %t503 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t502)
  call void @olang_textcopy(ptr %t503, ptr %t497, i64 %t498)
  %t504 = getelementptr i8, ptr %t503, i64 %t498
  call void @olang_textcopy(ptr %t504, ptr %t500, i64 %t501)
  %t505 = insertvalue { i64, ptr } undef, i64 %t502, 0
  %t506 = insertvalue { i64, ptr } %t505, ptr %t503, 1
  %t508 = extractvalue { i64, ptr } %t506, 0
  %t509 = extractvalue { i64, ptr } %t506, 1
  %t510 = mul i64 %t508, 1
  %t511 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t509, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  %t514 = load ptr, ptr %l207, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s19, ptr %t514, { i64, ptr } %t513)
  br label %bb76
bb76:
  %t516 = load i64, ptr %l27, !tbaa !24
  %t517 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t519 = extractvalue { i64, ptr } %t517, 0
  %t522 = icmp slt i64 %t516, %t519
  br i1 %t522, label %bb77, label %bb78
bb77:
  %t524 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t524, ptr %l220, !tbaa !27
  %t525 = load i64, ptr %l27, !tbaa !24
  %t527 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = getelementptr i32, ptr %t528, i64 %t525
  %t530 = load i32, ptr %t529, !tbaa !33
  %t532 = icmp ne i32 %t530, 0
  store i1 %t532, ptr %l219, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb79
bb79:
  %t534 = load i1, ptr %l219, !tbaa !21
  br i1 %t534, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s21
  %t535 = load ptr, ptr %l0, !tbaa !29
  store ptr %t535, ptr %l224, !tbaa !29
  %t536 = load ptr, ptr %l0, !tbaa !29
  store ptr %t536, ptr %l225, !tbaa !29
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr %"compiler/check:Checker", ptr %t537, i32 0, i32 0
  %t540 = load ptr, ptr %t539, !tbaa !29
  %t541 = load i32, ptr %l3, !tbaa !23
  %t542 = load i64, ptr %l27, !tbaa !24
  %t546 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t540, i32 %t541, i64 %t542)
  store i32 %t546, ptr %l230
  br label %bb82
bb81:
  br label %bb95
bb82:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t549 = getelementptr %"compiler/check:Checker", ptr %t547, i32 0, i32 0
  %t550 = load ptr, ptr %t549, !tbaa !29
  %t551 = load i32, ptr %l1, !tbaa !23
  %t554 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t550, i32 %t551)
  store ptr %t554, ptr %l234
  br label %bb83
bb83:
  %t555 = load i64, ptr %l27, !tbaa !24
  %t556 = load ptr, ptr %l234, !tbaa !29
  %t558 = call { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v0, ptr %t556, i64 %t555)
  store { i64, ptr } %t558, ptr %l236
  br label %bb84
bb84:
  %t559 = load ptr, ptr %l225, !tbaa !29
  %t560 = load i32, ptr %l230, !tbaa !23
  %t561 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t562 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s21, ptr %v0, ptr %t559, i32 %t560, ptr null, { i64, ptr } %t561)
  store i32 %t562, ptr %l237
  br label %bb85
bb85:
  %t563 = load ptr, ptr %l224, !tbaa !29
  %t564 = load i32, ptr %l237, !tbaa !23
  %t565 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s21, ptr %t563, i32 %t564)
  store { i64, ptr } %t565, ptr %l238
  br label %bb86
bb86:
  %t566 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t566, ptr %l28, !tbaa !27
  store ptr %l2, ptr %l239, !tbaa !29
  %t567 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t569 = call i64 @compiler_2fexplain_2efirstClose(ptr %s21, { i64, ptr } %t567)
  store i64 %t569, ptr %l241
  br label %bb87
bb87:
  %t570 = load i64, ptr %l241, !tbaa !24
  %t571 = add i64 %t570, 1
  store i64 %t571, ptr %l242, !tbaa !24
  %t572 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t573 = extractvalue { i64, ptr } %t572, 0
  store i64 %t573, ptr %l243, !tbaa !24
  %t574 = icmp sge i64 2, 0
  br i1 %t574, label %bb88, label %bb89
bb88:
  %t576 = load i64, ptr %l242, !tbaa !24
  %t577 = icmp sle i64 2, %t576
  br i1 %t577, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @.c65)
  unreachable
bb90:
  %t579 = load i64, ptr %l242, !tbaa !24
  %t580 = load i64, ptr %l243, !tbaa !24
  %t581 = icmp sle i64 %t579, %t580
  br i1 %t581, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @.c65)
  unreachable
bb92:
  %t583 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t584 = load ptr, ptr %t583, !tbaa !27
  %t585 = load i64, ptr %l242, !tbaa !24
  %t586 = getelementptr i8, ptr %t584, i64 2
  %t587 = sub i64 %t585, 2
  %t588 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t586, 1
  %t590 = load ptr, ptr %l239, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %t590, { i64, ptr } %t589)
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @.c65)
  unreachable
bb94:
  call void @__olang_scope_close(ptr %s21)
  br label %bb95
bb95:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s19)
  br label %bb97
bb97:
  %t593 = load i64, ptr %l26, !tbaa !24
  %t595 = add i64 %t593, 1
  store i64 %t595, ptr %l26, !tbaa !24
  br label %bb71
bb98:
  call void @__olang_scope_close(ptr %s16)
  br label %bb170
bb99:
  %t597 = load i32, ptr %l6
  %t599 = trunc i64 4 to i32
  %t600 = icmp eq i32 %t597, %t599
  br i1 %t600, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb144
bb102:
  store %olang.scope zeroinitializer, ptr %s23
  store ptr %l2, ptr %l253, !tbaa !29
  %t602 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t602, ptr %l254, !tbaa !27
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t605 = getelementptr %"compiler/check:Checker", ptr %t603, i32 0, i32 0
  %t606 = load ptr, ptr %t605, !tbaa !29
  %t607 = load i32, ptr %l3, !tbaa !23
  %t610 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t606, i32 %t607)
  store i1 %t610, ptr %l258
  br label %bb103
bb103:
  %t611 = load i1, ptr %l258, !tbaa !21
  br i1 %t611, label %bb104, label %bb105
bb104:
  store { i64, ptr } { i64 9, ptr @.d66 }, ptr %l259, !tbaa !27
  br label %bb106
bb105:
  store { i64, ptr } { i64 1, ptr @.d67 }, ptr %l259, !tbaa !27
  br label %bb106
bb106:
  %t612 = load ptr, ptr %l0, !tbaa !29
  store ptr %t612, ptr %l260, !tbaa !29
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t615 = getelementptr %"compiler/check:Checker", ptr %t613, i32 0, i32 0
  %t616 = load ptr, ptr %t615, !tbaa !29
  %t618 = getelementptr %"compiler/generic:Program", ptr %t616, i32 0, i32 2
  %t619 = load i32, ptr %l3, !tbaa !23
  %t622 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t618, i32 %t619)
  store i32 %t622, ptr %l265
  br label %bb107
bb107:
  %t623 = load ptr, ptr %l260, !tbaa !29
  %t624 = load i32, ptr %l265, !tbaa !23
  %t625 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s23, ptr %t623, i32 %t624)
  store { i64, ptr } %t625, ptr %l266
  br label %bb108
bb108:
  %t626 = extractvalue { i64, ptr } { i64 5, ptr @.d68 }, 1
  %t627 = extractvalue { i64, ptr } { i64 5, ptr @.d68 }, 0
  %t628 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t629 = extractvalue { i64, ptr } %t628, 1
  %t630 = extractvalue { i64, ptr } %t628, 0
  %t631 = add i64 %t627, %t630
  %t632 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t633 = extractvalue { i64, ptr } %t632, 1
  %t634 = extractvalue { i64, ptr } %t632, 0
  %t635 = add i64 %t631, %t634
  %t636 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t637 = extractvalue { i64, ptr } %t636, 1
  %t638 = extractvalue { i64, ptr } %t636, 0
  %t639 = add i64 %t635, %t638
  %t640 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t639)
  call void @olang_textcopy(ptr %t640, ptr %t626, i64 %t627)
  %t641 = getelementptr i8, ptr %t640, i64 %t627
  call void @olang_textcopy(ptr %t641, ptr %t629, i64 %t630)
  %t642 = getelementptr i8, ptr %t641, i64 %t630
  call void @olang_textcopy(ptr %t642, ptr %t633, i64 %t634)
  %t643 = getelementptr i8, ptr %t642, i64 %t634
  call void @olang_textcopy(ptr %t643, ptr %t637, i64 %t638)
  %t644 = insertvalue { i64, ptr } undef, i64 %t639, 0
  %t645 = insertvalue { i64, ptr } %t644, ptr %t640, 1
  %t647 = extractvalue { i64, ptr } %t645, 0
  %t648 = extractvalue { i64, ptr } %t645, 1
  %t649 = mul i64 %t647, 1
  %t650 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t649)
  call void @llvm.memcpy.p0.p0.i64(ptr %t650, ptr %t648, i64 %t649, i1 false)
  %t651 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t652 = insertvalue { i64, ptr } %t651, ptr %t650, 1
  %t653 = load ptr, ptr %l253, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t653, { i64, ptr } %t652)
  br label %bb109
bb109:
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t657 = getelementptr %"compiler/check:Checker", ptr %t655, i32 0, i32 0
  %t658 = load ptr, ptr %t657, !tbaa !29
  %t659 = load i32, ptr %l1, !tbaa !23
  %t662 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t658, i32 %t659)
  store ptr %t662, ptr %l272
  br label %bb110
bb110:
  %t663 = load ptr, ptr %l272, !tbaa !29
  %t665 = getelementptr %"compiler/ast:TypeDecl", ptr %t663, i32 0, i32 3
  %t666 = load ptr, ptr %t665, !tbaa !29
  store ptr %t666, ptr %l29, !tbaa !29
  %t668 = load ptr, ptr %l29, !tbaa !29
  store ptr %t668, ptr %l275, !tbaa !29
  store i1 false, ptr %l276, !tbaa !21
  %t669 = load ptr, ptr %l275, !tbaa !29
  %t670 = icmp ne ptr %t669, null
  br i1 %t670, label %bb111, label %bb112
bb111:
  %t672 = load ptr, ptr %l275, !tbaa !29
  %t673 = load i64, ptr %t672
  %t675 = icmp eq i64 %t673, 3
  store i1 %t675, ptr %l276, !tbaa !21
  br label %bb112
bb112:
  %t676 = load i1, ptr %l276, !tbaa !21
  br i1 %t676, label %bb113, label %bb114
bb113:
  %t677 = load ptr, ptr %l29, !tbaa !29
  %t679 = getelementptr { i64, [2 x i64] }, ptr %t677, i32 0, i32 1
  %t680 = getelementptr { ptr, ptr }, ptr %t679, i32 0, i32 1
  %t681 = load ptr, ptr %t680
  store ptr %t681, ptr %l30, !tbaa !29
  br label %bb115
bb114:
  br label %bb137
bb115:
  %t683 = load ptr, ptr %l30, !tbaa !29
  %t685 = icmp ne ptr %t683, null
  br i1 %t685, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s26
  %t687 = load ptr, ptr %l0, !tbaa !29
  store ptr %t687, ptr %l283, !tbaa !29
  %t688 = load ptr, ptr %l0, !tbaa !29
  store ptr %t688, ptr %l284, !tbaa !29
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t691 = getelementptr %"compiler/check:Checker", ptr %t689, i32 0, i32 0
  %t692 = load ptr, ptr %t691, !tbaa !29
  %t693 = load i32, ptr %l3, !tbaa !23
  %t696 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t692, i32 %t693)
  store i32 %t696, ptr %l288
  br label %bb118
bb117:
  br label %bb136
bb118:
  %t697 = load ptr, ptr %l30, !tbaa !29
  %t699 = getelementptr %"compiler/ast:Func", ptr %t697, i32 0, i32 3
  %t700 = load ptr, ptr %t699, !tbaa !29
  %t702 = getelementptr %"compiler/ast:Sig", ptr %t700, i32 0, i32 0
  %t703 = load { i64, ptr }, ptr %t702, !tbaa !27
  %t704 = load ptr, ptr %l284, !tbaa !29
  %t705 = load i32, ptr %l288, !tbaa !23
  %t707 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s26, ptr %v0, ptr %t704, i32 %t705, ptr null, { i64, ptr } %t703)
  store i32 %t707, ptr %l292
  br label %bb119
bb119:
  %t708 = load ptr, ptr %l283, !tbaa !29
  %t709 = load i32, ptr %l292, !tbaa !23
  %t710 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s26, ptr %t708, i32 %t709)
  store { i64, ptr } %t710, ptr %l293
  br label %bb120
bb120:
  %t711 = load { i64, ptr }, ptr %l293, !tbaa !27
  store { i64, ptr } %t711, ptr %l31, !tbaa !27
  %t712 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t714 = call i64 @compiler_2fexplain_2efirstClose(ptr %s26, { i64, ptr } %t712)
  store i64 %t714, ptr %l295
  br label %bb121
bb121:
  %t715 = load i64, ptr %l295, !tbaa !24
  store i64 %t715, ptr %l32, !tbaa !24
  store ptr %l2, ptr %l296, !tbaa !29
  %t716 = load i64, ptr %l32, !tbaa !24
  %t718 = add i64 %t716, 1
  store i64 %t718, ptr %l298, !tbaa !24
  %t719 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t720 = extractvalue { i64, ptr } %t719, 0
  store i64 %t720, ptr %l299, !tbaa !24
  %t721 = icmp sge i64 2, 0
  br i1 %t721, label %bb122, label %bb123
bb122:
  %t723 = load i64, ptr %l298, !tbaa !24
  %t724 = icmp sle i64 2, %t723
  br i1 %t724, label %bb124, label %bb125
bb123:
  call void @__olang_check_failed(ptr @.c69)
  unreachable
bb124:
  %t726 = load i64, ptr %l298, !tbaa !24
  %t727 = load i64, ptr %l299, !tbaa !24
  %t728 = icmp sle i64 %t726, %t727
  br i1 %t728, label %bb126, label %bb127
bb125:
  call void @__olang_check_failed(ptr @.c69)
  unreachable
bb126:
  %t730 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t731 = load ptr, ptr %t730, !tbaa !27
  %t732 = load i64, ptr %l298, !tbaa !24
  %t733 = getelementptr i8, ptr %t731, i64 2
  %t734 = sub i64 %t732, 2
  %t735 = insertvalue { i64, ptr } undef, i64 %t734, 0
  %t736 = insertvalue { i64, ptr } %t735, ptr %t733, 1
  store { i64, ptr } %t736, ptr %l303, !tbaa !27
  %t737 = load i64, ptr %l32, !tbaa !24
  %t739 = add i64 %t737, 1
  store i64 %t739, ptr %l305, !tbaa !24
  %t740 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t742 = extractvalue { i64, ptr } %t740, 0
  store i64 %t742, ptr %l307, !tbaa !24
  %t743 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t744 = extractvalue { i64, ptr } %t743, 0
  store i64 %t744, ptr %l308, !tbaa !24
  %t745 = load i64, ptr %l305, !tbaa !24
  %t746 = icmp sge i64 %t745, 0
  br i1 %t746, label %bb128, label %bb129
bb127:
  call void @__olang_check_failed(ptr @.c69)
  unreachable
bb128:
  %t748 = load i64, ptr %l305, !tbaa !24
  %t749 = load i64, ptr %l307, !tbaa !24
  %t750 = icmp sle i64 %t748, %t749
  br i1 %t750, label %bb130, label %bb131
bb129:
  call void @__olang_check_failed(ptr @.c69)
  unreachable
bb130:
  %t752 = load i64, ptr %l307, !tbaa !24
  %t753 = load i64, ptr %l308, !tbaa !24
  %t754 = icmp sle i64 %t752, %t753
  br i1 %t754, label %bb132, label %bb133
bb131:
  call void @__olang_check_failed(ptr @.c69)
  unreachable
bb132:
  %t756 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t757 = load ptr, ptr %t756, !tbaa !27
  %t758 = load i64, ptr %l305, !tbaa !24
  %t759 = load i64, ptr %l307, !tbaa !24
  %t760 = getelementptr i8, ptr %t757, i64 %t758
  %t761 = sub i64 %t759, %t758
  %t762 = insertvalue { i64, ptr } undef, i64 %t761, 0
  %t763 = insertvalue { i64, ptr } %t762, ptr %t760, 1
  %t765 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s26, ptr %s26, { i64, ptr } %t763)
  store { i64, ptr } %t765, ptr %l313
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @.c69)
  unreachable
bb134:
  %t766 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t767 = extractvalue { i64, ptr } %t766, 1
  %t768 = extractvalue { i64, ptr } %t766, 0
  %t769 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t769, 1
  %t771 = extractvalue { i64, ptr } %t769, 0
  %t772 = add i64 %t768, %t771
  %t773 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t772)
  call void @olang_textcopy(ptr %t773, ptr %t767, i64 %t768)
  %t774 = getelementptr i8, ptr %t773, i64 %t768
  call void @olang_textcopy(ptr %t774, ptr %t770, i64 %t771)
  %t775 = insertvalue { i64, ptr } undef, i64 %t772, 0
  %t776 = insertvalue { i64, ptr } %t775, ptr %t773, 1
  %t778 = extractvalue { i64, ptr } %t776, 0
  %t779 = extractvalue { i64, ptr } %t776, 1
  %t780 = mul i64 %t778, 1
  %t781 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t780)
  call void @llvm.memcpy.p0.p0.i64(ptr %t781, ptr %t779, i64 %t780, i1 false)
  %t782 = insertvalue { i64, ptr } undef, i64 %t778, 0
  %t783 = insertvalue { i64, ptr } %t782, ptr %t781, 1
  %t784 = load ptr, ptr %l296, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s26, ptr %t784, { i64, ptr } %t783)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s26)
  br label %bb136
bb136:
  br label %bb142
bb137:
  br i1 true, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb142
bb141:
  call void @__olang_check_failed(ptr @.c70)
  unreachable
bb142:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s23)
  br label %bb170
bb144:
  %t787 = load i32, ptr %l6
  %t789 = trunc i64 0 to i32
  %t790 = icmp eq i32 %t787, %t789
  br i1 %t790, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb169
bb147:
  store %olang.scope zeroinitializer, ptr %s29
  %t792 = load ptr, ptr %l0, !tbaa !29
  store ptr %t792, ptr %l319, !tbaa !29
  %t793 = load ptr, ptr %l0, !tbaa !29
  store ptr %t793, ptr %l320, !tbaa !29
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t796 = getelementptr %"compiler/check:Checker", ptr %t794, i32 0, i32 0
  %t797 = load ptr, ptr %t796, !tbaa !29
  %t798 = load i32, ptr %l3, !tbaa !23
  %t801 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t797, i32 %t798)
  store i32 %t801, ptr %l324
  br label %bb148
bb148:
  %t802 = load ptr, ptr %l0, !tbaa !29
  %t804 = getelementptr %"compiler/check:Checker", ptr %t802, i32 0, i32 0
  %t805 = load ptr, ptr %t804, !tbaa !29
  %t806 = load i32, ptr %l1, !tbaa !23
  %t809 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t805, i32 %t806)
  store ptr %t809, ptr %l328
  br label %bb149
bb149:
  %t810 = load ptr, ptr %l328, !tbaa !29
  %t811 = call { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %t810)
  store { i64, ptr } %t811, ptr %l329
  br label %bb150
bb150:
  %t812 = load ptr, ptr %l320, !tbaa !29
  %t813 = load i32, ptr %l324, !tbaa !23
  %t814 = load { i64, ptr }, ptr %l329, !tbaa !27
  %t815 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s29, ptr %v0, ptr %t812, i32 %t813, ptr null, { i64, ptr } %t814)
  store i32 %t815, ptr %l330
  br label %bb151
bb151:
  %t816 = load ptr, ptr %l319, !tbaa !29
  %t817 = load i32, ptr %l330, !tbaa !23
  %t818 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s29, ptr %t816, i32 %t817)
  store { i64, ptr } %t818, ptr %l331
  br label %bb152
bb152:
  %t819 = load { i64, ptr }, ptr %l331, !tbaa !27
  store { i64, ptr } %t819, ptr %l33, !tbaa !27
  %t820 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t822 = call i64 @compiler_2fexplain_2efirstClose(ptr %s29, { i64, ptr } %t820)
  store i64 %t822, ptr %l333
  br label %bb153
bb153:
  %t823 = load i64, ptr %l333, !tbaa !24
  store i64 %t823, ptr %l34, !tbaa !24
  store ptr %l2, ptr %l334, !tbaa !29
  %t824 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t824, ptr %l335, !tbaa !27
  %t825 = load i64, ptr %l34, !tbaa !24
  %t827 = add i64 %t825, 1
  store i64 %t827, ptr %l337, !tbaa !24
  %t828 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t829 = extractvalue { i64, ptr } %t828, 0
  store i64 %t829, ptr %l338, !tbaa !24
  %t830 = icmp sge i64 2, 0
  br i1 %t830, label %bb154, label %bb155
bb154:
  %t832 = load i64, ptr %l337, !tbaa !24
  %t833 = icmp sle i64 2, %t832
  br i1 %t833, label %bb156, label %bb157
bb155:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb156:
  %t835 = load i64, ptr %l337, !tbaa !24
  %t836 = load i64, ptr %l338, !tbaa !24
  %t837 = icmp sle i64 %t835, %t836
  br i1 %t837, label %bb158, label %bb159
bb157:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb158:
  %t839 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t840 = load ptr, ptr %t839, !tbaa !27
  %t841 = load i64, ptr %l337, !tbaa !24
  %t842 = getelementptr i8, ptr %t840, i64 2
  %t843 = sub i64 %t841, 2
  %t844 = insertvalue { i64, ptr } undef, i64 %t843, 0
  %t845 = insertvalue { i64, ptr } %t844, ptr %t842, 1
  store { i64, ptr } %t845, ptr %l342, !tbaa !27
  %t846 = load i64, ptr %l34, !tbaa !24
  %t848 = add i64 %t846, 1
  store i64 %t848, ptr %l344, !tbaa !24
  %t849 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t851 = extractvalue { i64, ptr } %t849, 0
  store i64 %t851, ptr %l346, !tbaa !24
  %t852 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t853 = extractvalue { i64, ptr } %t852, 0
  store i64 %t853, ptr %l347, !tbaa !24
  %t854 = load i64, ptr %l344, !tbaa !24
  %t855 = icmp sge i64 %t854, 0
  br i1 %t855, label %bb160, label %bb161
bb159:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb160:
  %t857 = load i64, ptr %l344, !tbaa !24
  %t858 = load i64, ptr %l346, !tbaa !24
  %t859 = icmp sle i64 %t857, %t858
  br i1 %t859, label %bb162, label %bb163
bb161:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb162:
  %t861 = load i64, ptr %l346, !tbaa !24
  %t862 = load i64, ptr %l347, !tbaa !24
  %t863 = icmp sle i64 %t861, %t862
  br i1 %t863, label %bb164, label %bb165
bb163:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb164:
  %t865 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t866 = load ptr, ptr %t865, !tbaa !27
  %t867 = load i64, ptr %l344, !tbaa !24
  %t868 = load i64, ptr %l346, !tbaa !24
  %t869 = getelementptr i8, ptr %t866, i64 %t867
  %t870 = sub i64 %t868, %t867
  %t871 = insertvalue { i64, ptr } undef, i64 %t870, 0
  %t872 = insertvalue { i64, ptr } %t871, ptr %t869, 1
  %t874 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s29, ptr %s29, { i64, ptr } %t872)
  store { i64, ptr } %t874, ptr %l352
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb166:
  %t875 = extractvalue { i64, ptr } { i64 5, ptr @.d72 }, 1
  %t876 = extractvalue { i64, ptr } { i64 5, ptr @.d72 }, 0
  %t877 = load { i64, ptr }, ptr %l335, !tbaa !27
  %t878 = extractvalue { i64, ptr } %t877, 1
  %t879 = extractvalue { i64, ptr } %t877, 0
  %t880 = add i64 %t876, %t879
  %t881 = extractvalue { i64, ptr } { i64 7, ptr @.d73 }, 1
  %t882 = extractvalue { i64, ptr } { i64 7, ptr @.d73 }, 0
  %t883 = add i64 %t880, %t882
  %t884 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t885 = extractvalue { i64, ptr } %t884, 1
  %t886 = extractvalue { i64, ptr } %t884, 0
  %t887 = add i64 %t883, %t886
  %t888 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t889 = extractvalue { i64, ptr } %t888, 1
  %t890 = extractvalue { i64, ptr } %t888, 0
  %t891 = add i64 %t887, %t890
  %t892 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 1
  %t893 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 0
  %t894 = add i64 %t891, %t893
  %t895 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t894)
  call void @olang_textcopy(ptr %t895, ptr %t875, i64 %t876)
  %t896 = getelementptr i8, ptr %t895, i64 %t876
  call void @olang_textcopy(ptr %t896, ptr %t878, i64 %t879)
  %t897 = getelementptr i8, ptr %t896, i64 %t879
  call void @olang_textcopy(ptr %t897, ptr %t881, i64 %t882)
  %t898 = getelementptr i8, ptr %t897, i64 %t882
  call void @olang_textcopy(ptr %t898, ptr %t885, i64 %t886)
  %t899 = getelementptr i8, ptr %t898, i64 %t886
  call void @olang_textcopy(ptr %t899, ptr %t889, i64 %t890)
  %t900 = getelementptr i8, ptr %t899, i64 %t890
  call void @olang_textcopy(ptr %t900, ptr %t892, i64 %t893)
  %t901 = insertvalue { i64, ptr } undef, i64 %t894, 0
  %t902 = insertvalue { i64, ptr } %t901, ptr %t895, 1
  %t904 = extractvalue { i64, ptr } %t902, 0
  %t905 = extractvalue { i64, ptr } %t902, 1
  %t906 = mul i64 %t904, 1
  %t907 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t906)
  call void @llvm.memcpy.p0.p0.i64(ptr %t907, ptr %t905, i64 %t906, i1 false)
  %t908 = insertvalue { i64, ptr } undef, i64 %t904, 0
  %t909 = insertvalue { i64, ptr } %t908, ptr %t907, 1
  %t910 = load ptr, ptr %l334, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s29, ptr %t910, { i64, ptr } %t909)
  br label %bb167
bb167:
  %t912 = load ptr, ptr %l0, !tbaa !29
  %t913 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2efields(ptr %s0, ptr %v0, ptr %l2, ptr %t912, i32 %t913)
  br label %bb168
bb168:
  call void @__olang_scope_close(ptr %s29)
  br label %bb170
bb169:
  call void @__olang_check_failed(ptr @.c75)
  unreachable
bb170:
  %t917 = load ptr, ptr %l0, !tbaa !29
  %t918 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2emethods(ptr %s0, ptr %v0, ptr %l2, ptr %t917, i32 %t918)
  br label %bb171
bb171:
  %t922 = load ptr, ptr %l0, !tbaa !29
  %t923 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2etraitsMet(ptr %s0, ptr %v0, ptr %l2, ptr %t922, i32 %t923)
  br label %bb172
bb172:
  %t928 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t928, ptr %l365
  br label %bb173
bb173:
  %t929 = load { i64, ptr }, ptr %l365, !tbaa !27
  store { i64, ptr } %t929, ptr %l366, !tbaa !27
  %t930 = load { i64, ptr }, ptr %l366, !tbaa !27
  %t931 = extractvalue { i64, ptr } %t930, 0
  store i64 %t931, ptr %l367, !tbaa !24
  %t932 = load i64, ptr %l367, !tbaa !24
  %t933 = mul i64 %t932, 1
  %t934 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t933)
  %t935 = insertvalue { i64, ptr } undef, i64 %t932, 0
  %t936 = insertvalue { i64, ptr } %t935, ptr %t934, 1
  store { i64, ptr } %t936, ptr %l368, !tbaa !27
  %t937 = getelementptr { i64, ptr }, ptr %l368, i32 0, i32 1
  %t938 = load ptr, ptr %t937, !tbaa !27
  %t939 = getelementptr { i64, ptr }, ptr %l366, i32 0, i32 1
  %t940 = load ptr, ptr %t939, !tbaa !27
  %t941 = load i64, ptr %l367, !tbaa !24
  %t942 = mul i64 %t941, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t938, ptr %t940, i64 %t942, i1 false)
  %t943 = load { i64, ptr }, ptr %l368, !tbaa !27
  store { i64, ptr } %t943, ptr %l366, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t944 = load { i64, ptr }, ptr %l366, !tbaa !27
  store { i64, ptr } %t944, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %a2)
  store i32 %t19, ptr %l12
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l5, !tbaa !29
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t20, i64 %t21, i32 %t22)
  store i64 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load i64, ptr %l13, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i32 -1, ptr %l16, !tbaa !23
  br label %bb6
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t38 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t32, i64 %t33, i64 %t34)
  store i32 %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = load i32, ptr %l21, !tbaa !23
  store i32 %t39, ptr %l16, !tbaa !23
  br label %bb6
bb6:
  %t40 = load i32, ptr %l16, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:varRow"
  %l15 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l30 = alloca i64
  %l33 = alloca i64
  %l55 = alloca %"compiler/generic:varRow"
  %l60 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i64, ptr %l15, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sle i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr @.d76 }, ptr %l19, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t16, ptr %l20, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l21, !tbaa !24
  %t19 = load i64, ptr %l21, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l21, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t30, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t32 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t32, ptr %l23
  br label %bb5
bb5:
  %t33 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t33, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 60)
  br label %bb6
bb6:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb12
bb9:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l33, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l33, !tbaa !24
  store i64 %t65, ptr %l30, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l30, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t94 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t88, i64 %t89, i64 %t90)
  store %"compiler/generic:varRow" %t94, ptr %l55
  br label %bb17
bb17:
  %t95 = load %"compiler/generic:varRow", ptr %l55
  store %"compiler/generic:varRow" %t95, ptr %l11
  %t96 = load i64, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l2, !tbaa !24
  %t100 = icmp sgt i64 %t96, %t97
  br i1 %t100, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l4, { i64, ptr } { i64 2, ptr @.d77 })
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  store ptr %l4, ptr %l60, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 3
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 1
  %t114 = load i32, ptr %t113, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t112, i32 %t114)
  store { i64, ptr } %t117, ptr %l66
  br label %bb22
bb22:
  %t118 = load ptr, ptr %l60, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l66, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t118, { i64, ptr } %t119)
  br label %bb23
bb23:
  %t120 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t125 = icmp ne i32 %t121, %t122
  br i1 %t125, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l4, ptr %l70, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t129 = load i32, ptr %t128, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s5, ptr %t127, i32 %t129)
  store { i64, ptr } %t132, ptr %l73
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t133 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 0
  %t135 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = add i64 %t134, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t133, i64 %t134)
  %t140 = getelementptr i8, ptr %t139, i64 %t134
  call void @olang_textcopy(ptr %t140, ptr %t136, i64 %t137)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  %t150 = load ptr, ptr %l70, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t150, { i64, ptr } %t149)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t152 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t153 = load i32, ptr %t152, !tbaa !23
  %t154 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t157 = icmp ne i32 %t153, %t154
  br i1 %t157, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l4, ptr %l79, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t161 = load i32, ptr %t160, !tbaa !23
  %t164 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s7, ptr %t159, i32 %t161)
  store { i64, ptr } %t164, ptr %l82
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t165 = extractvalue { i64, ptr } { i64 1, ptr @.d79 }, 1
  %t166 = extractvalue { i64, ptr } { i64 1, ptr @.d79 }, 0
  %t167 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = add i64 %t166, %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t165, i64 %t166)
  %t172 = getelementptr i8, ptr %t171, i64 %t166
  call void @olang_textcopy(ptr %t172, ptr %t168, i64 %t169)
  %t173 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t171, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = extractvalue { i64, ptr } %t174, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  %t182 = load ptr, ptr %l79, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t182, { i64, ptr } %t181)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  %t184 = load i64, ptr %l9, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l9, !tbaa !24
  br label %bb13
bb35:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 62)
  br label %bb36
bb36:
  %t190 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l4)
  store { i64, ptr } %t190, ptr %l89
  br label %bb37
bb37:
  %t191 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t191, ptr %l90, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l91, !tbaa !24
  %t194 = load i64, ptr %l91, !tbaa !24
  %t195 = mul i64 %t194, 1
  %t196 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t195)
  %t197 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  store { i64, ptr } %t198, ptr %l92, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = load i64, ptr %l91, !tbaa !24
  %t204 = mul i64 %t203, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t200, ptr %t202, i64 %t204, i1 false)
  %t205 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t205, ptr %l90, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t206 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t206, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d0 = private constant [1 x i8] c"."
declare void @__olang_check_failed(ptr)
@.c1 = private unnamed_addr constant [54 x i8] c"compiler/explain.olang:24: slice bounds out of range\0A\00"
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.c2 = private unnamed_addr constant [54 x i8] c"compiler/explain.olang:26: slice bounds out of range\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c3 = private unnamed_addr constant [49 x i8] c"compiler/explain.olang:236: unreachable reached\0A\00"
@.c4 = private unnamed_addr constant [49 x i8] c"compiler/explain.olang:243: unreachable reached\0A\00"
@.d5 = private constant [2 x i8] c" ?"
@.d6 = private constant [0 x i8] c""
@.c7 = private unnamed_addr constant [55 x i8] c"compiler/explain.olang:268: slice bounds out of range\0A\00"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.c8 = private unnamed_addr constant [49 x i8] c"compiler/explain.olang:273: unreachable reached\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c9 = private unnamed_addr constant [55 x i8] c"compiler/explain.olang:284: slice bounds out of range\0A\00"
@.d10 = private constant [4 x i8] c"    "
@.d11 = private constant [1 x i8] c" "
@.d12 = private constant [1 x i8] c"\0A"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.c13 = private unnamed_addr constant [49 x i8] c"compiler/explain.olang:274: unreachable reached\0A\00"
@.c14 = private unnamed_addr constant [55 x i8] c"compiler/explain.olang:250: slice bounds out of range\0A\00"
@.d15 = private constant [1 x i8] c"\0A"
@.d16 = private constant [4 x i8] c"    "
@.d17 = private constant [1 x i8] c"\0A"
@.d18 = private constant [13 x i8] c"    instance "
@.d19 = private constant [2 x i8] c": "
@.d20 = private constant [1 x i8] c"\0A"
@.d21 = private constant [8 x i8] c"        "
@.d22 = private constant [10 x i8] c"extern fn "
@.d23 = private constant [3 x i8] c"fn "
@.c24 = private unnamed_addr constant [54 x i8] c"compiler/explain.olang:81: slice bounds out of range\0A\00"
@.d25 = private constant [1 x i8] c"("
@.c26 = private unnamed_addr constant [54 x i8] c"compiler/explain.olang:84: slice bounds out of range\0A\00"
@.c27 = private unnamed_addr constant [54 x i8] c"compiler/explain.olang:85: slice bounds out of range\0A\00"
@.d28 = private constant [1 x i8] c"("
@.d29 = private constant [2 x i8] c") "
@.d30 = private constant [1 x i8] c"("
@.d31 = private constant [5 x i8] c" mut "
@.d32 = private constant [1 x i8] c" "
@.d33 = private constant [20 x i8] c"   # set at startup\0A"
@.d34 = private constant [20 x i8] c"   # set at startup\0A"
@.d35 = private constant [3 x i8] c" = "
@.d36 = private constant [1 x i8] c"\0A"
@.d37 = private constant [3 x i8] c" = "
@.d38 = private constant [1 x i8] c"\0A"
@.d39 = private constant [4 x i8] c"    "
@.d40 = private constant [1 x i8] c"\0A"
@.d41 = private constant [4 x i8] c"    "
@.d42 = private constant [1 x i8] c"\0A"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d43 = private constant [1 x i8] c"["
@.d44 = private constant [2 x i8] c"]\0A"
@.d45 = private constant [2 x i8] c"\5Cn"
@.d46 = private constant [2 x i8] c"\5Ct"
@.d47 = private constant [27 x i8] c"   # its error set inferred"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aDeclKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d48 = private constant [2 x i8] c", "
@.d49 = private constant [10 x i8] c"    meets "
@.d50 = private constant [1 x i8] c"\0A"
@.d51 = private constant [2 x i8] c", "
@.d52 = private constant [6 x i8] c"error "
@.d53 = private constant [1 x i8] c"\0A"
@.d54 = private constant [4 x i8] c"    "
@.d55 = private constant [1 x i8] c"\0A"
@.d56 = private constant [5 x i8] c"type "
@.d57 = private constant [7 x i8] c" trait\0A"
@.c58 = private unnamed_addr constant [55 x i8] c"compiler/explain.olang:189: slice bounds out of range\0A\00"
@.d59 = private constant [4 x i8] c"    "
@.d60 = private constant [1 x i8] c"\0A"
@.c61 = private unnamed_addr constant [49 x i8] c"compiler/explain.olang:186: unreachable reached\0A\00"
@.d62 = private constant [5 x i8] c"type "
@.d63 = private constant [6 x i8] c" enum\0A"
@.d64 = private constant [4 x i8] c"    "
@.c65 = private unnamed_addr constant [55 x i8] c"compiler/explain.olang:203: slice bounds out of range\0A\00"
@.d66 = private constant [9 x i8] c" extends "
@.d67 = private constant [1 x i8] c" "
@.d68 = private constant [5 x i8] c"type "
@.c69 = private unnamed_addr constant [55 x i8] c"compiler/explain.olang:216: slice bounds out of range\0A\00"
@.c70 = private unnamed_addr constant [49 x i8] c"compiler/explain.olang:211: unreachable reached\0A\00"
@.c71 = private unnamed_addr constant [55 x i8] c"compiler/explain.olang:226: slice bounds out of range\0A\00"
@.d72 = private constant [5 x i8] c"type "
@.d73 = private constant [7 x i8] c" struct"
@.d74 = private constant [1 x i8] c"\0A"
@.c75 = private unnamed_addr constant [49 x i8] c"compiler/explain.olang:176: unreachable reached\0A\00"
@.d76 = private constant [0 x i8] c""
@.d77 = private constant [2 x i8] c", "
@.d78 = private constant [1 x i8] c" "
@.d79 = private constant [1 x i8] c" "
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_Hb234e65a2b42ee429ada36859295662b(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
