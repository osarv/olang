; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Table" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
define dso_local { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/names:Entry"
  %l16 = alloca i64
  %l17 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i32
  %l42 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l59 = alloca i32
  %l60 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca i32
  %l76 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i32
  %l93 = alloca { i64, ptr }
  %l105 = alloca i64
  %l111 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l127 = alloca i32
  %l132 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l5, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v3, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 1, ptr @.d0 })
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l25
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb2, label %ok.18
ok.18:
  store i64 %t15, ptr %l24
  br label %bb1
bb1:
  %t19 = load i64, ptr %l24, !tbaa !24
  store i64 %t19, ptr %l22, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb4
bb4:
  %t20 = load i64, ptr %l22, !tbaa !24
  store i64 %t20, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l28, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l29, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l30, !tbaa !27
  %t28 = load i64, ptr %l6, !tbaa !24
  store i64 %t28, ptr %l31, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l32, !tbaa !24
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb7, label %bb8
bb6:
  br label %bb30
bb7:
  %t33 = load i64, ptr %l31, !tbaa !24
  %t34 = icmp sle i64 0, %t33
  br i1 %t34, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb9:
  %t36 = load i64, ptr %l31, !tbaa !24
  %t37 = load i64, ptr %l32, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb11:
  %t40 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = getelementptr i8, ptr %t41, i64 0
  %t44 = sub i64 %t42, 0
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load ptr, ptr %l28, !tbaa !29
  %t48 = load i64, ptr %l29, !tbaa !24
  %t50 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t47, i64 %t48, { i64, ptr } %t46)
  store i32 %t50, ptr %l37
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb13:
  %t51 = load i32, ptr %l37, !tbaa !23
  store i32 %t51, ptr %l7, !tbaa !23
  %t52 = load i32, ptr %l7, !tbaa !23
  %t54 = icmp slt i32 %t52, 0
  br i1 %t54, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t57 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t57, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l42, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load i32, ptr %l7, !tbaa !23
  %t69 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l46
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l5, !tbaa !29
  store ptr %t70, ptr %l47, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l48, !tbaa !27
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l50, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t75, 0
  store i64 %t78, ptr %l53, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l54, !tbaa !24
  %t81 = load i64, ptr %l50, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = load i64, ptr %l50, !tbaa !24
  %t85 = load i64, ptr %l53, !tbaa !24
  %t86 = icmp sle i64 %t84, %t85
  br i1 %t86, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb20:
  %t88 = load i64, ptr %l53, !tbaa !24
  %t89 = load i64, ptr %l54, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb22:
  %t92 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l50, !tbaa !24
  %t95 = load i64, ptr %l53, !tbaa !24
  %t96 = getelementptr i8, ptr %t93, i64 %t94
  %t97 = sub i64 %t95, %t94
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t102 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v3, ptr %t100, { i64, ptr } %t99)
  store i32 %t102, ptr %l59
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb24:
  %t103 = load ptr, ptr %l42, !tbaa !29
  %t104 = load i32, ptr %l46, !tbaa !23
  %t105 = load i32, ptr %l59, !tbaa !23
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t103, i32 %t104, i32 %t105)
  store i64 %t106, ptr %l60
  br label %bb25
bb25:
  %t107 = load i64, ptr %l60, !tbaa !24
  store i64 %t107, ptr %l8, !tbaa !24
  %t108 = load i64, ptr %l8, !tbaa !24
  %t110 = icmp slt i64 %t108, 0
  br i1 %t110, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t113 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t113, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t116 = load i64, ptr %l8, !tbaa !24
  %t120 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t114, ptr %t115, i64 %t116)
  store { i64, ptr } %t120, ptr %l67
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t121 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t122 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t121, 1
  store { i32, { i64, ptr } } %t122, ptr %rv
  br label %ret
bb30:
  %t123 = load ptr, ptr %l5, !tbaa !29
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t127 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v3, ptr %t123, { i64, ptr } %t124)
  store i32 %t127, ptr %l70
  br label %bb31
bb31:
  %t128 = load i32, ptr %l70, !tbaa !23
  store i32 %t128, ptr %l9, !tbaa !23
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/names:Resolver", ptr %t135, i32 0, i32 1
  %t138 = load i64, ptr %l3, !tbaa !24
  %t141 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t137, i64 %t138)
  store ptr %t141, ptr %l76
  br label %bb32
bb32:
  %t142 = load ptr, ptr %l76, !tbaa !29
  %t144 = getelementptr %"compiler/names:Table", ptr %t142, i32 0, i32 0
  store ptr %t144, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t146 = load ptr, ptr %l10, !tbaa !29
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t146, i64 %t147)
  %t151 = extractvalue { i32, { i64, ptr } } %t150, 1
  %t152 = extractvalue { i32, { i64, ptr } } %t150, 0
  store i32 %t152, ptr %l83
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb35, label %ok.154
ok.154:
  store { i64, ptr } %t151, ptr %l82
  br label %bb34
bb34:
  %t155 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t155, ptr %l79, !tbaa !27
  br label %bb39
bb35:
  %t156 = load i32, ptr %l83, !tbaa !23
  %t157 = ashr i32 %t156, 16
  %t159 = icmp eq i32 %t157, 1
  br i1 %t159, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  %t161 = load i32, ptr %l83, !tbaa !23
  %t162 = lshr i32 %t161, 16
  %t163 = and i32 %t161, 65535
  %t164 = icmp eq i32 %t162, 1
  %t165 = select i1 %t164, i32 0, i32 0
  %t166 = icmp eq i32 %t161, 0
  %t167 = shl i32 %t165, 16
  %t168 = or i32 %t167, %t163
  %t169 = select i1 %t166, i32 0, i32 %t168
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t171 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t169, 0
  store { i32, { i64, ptr } } %t171, ptr %rv
  br label %ret
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb39:
  %t172 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t172, ptr %l12, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t177 = load i64, ptr %l14, !tbaa !24
  %t178 = load i64, ptr %l13, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb42:
  br label %bb43
bb43:
  %t185 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t185, ptr %l93, !tbaa !27
  %t186 = load i64, ptr %l14, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr %"compiler/names:Entry", ptr %t189, i64 %t186
  %t191 = load %"compiler/names:Entry", ptr %t190
  store %"compiler/names:Entry" %t191, ptr %l15
  %t193 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 0
  %t194 = load i32, ptr %t193, !tbaa !23
  %t195 = load i32, ptr %l9, !tbaa !23
  %t198 = icmp ne i32 %t194, %t195
  br i1 %t198, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb45:
  br label %bb46
bb46:
  %t200 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 2
  %t201 = load i32, ptr %t200
  %t203 = trunc i64 3 to i32
  %t204 = icmp eq i32 %t201, %t203
  br i1 %t204, label %bb47, label %bb48
bb47:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t210 = load i64, ptr %l3, !tbaa !24
  %t211 = load i32, ptr %l9, !tbaa !23
  %t215 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t209, i64 %t210, i32 %t211)
  store i64 %t215, ptr %l105
  br label %bb49
bb48:
  br label %bb54
bb49:
  %t216 = load i64, ptr %l105, !tbaa !24
  store i64 %t216, ptr %l16, !tbaa !24
  %t217 = load i64, ptr %l16, !tbaa !24
  %t219 = icmp sge i64 %t217, 0
  br i1 %t219, label %bb50, label %bb51
bb50:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t223 = load i64, ptr %l16, !tbaa !24
  %t227 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t221, ptr %t222, i64 %t223)
  store { i64, ptr } %t227, ptr %l111
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t228 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t229 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t228, 1
  store { i32, { i64, ptr } } %t229, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t230 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 2
  %t231 = load i32, ptr %t230
  %t233 = trunc i64 2 to i32
  %t234 = icmp eq i32 %t231, %t233
  br i1 %t234, label %bb55, label %bb56
bb55:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i64, ptr %l3, !tbaa !24
  %t239 = load %"compiler/names:Entry", ptr %l15
  %t244 = call { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v2, ptr %v0, ptr %v4, ptr %t236, ptr %a2, i64 %t238, %"compiler/names:Entry" %t239)
  store { i64, ptr } %t244, ptr %l118
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t245 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t246 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t245, 1
  store { i32, { i64, ptr } } %t246, ptr %rv
  br label %ret
bb58:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb59:
  %t247 = load i64, ptr %l14, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l14, !tbaa !24
  br label %bb40
bb60:
  %t251 = load i64, ptr %l11, !tbaa !24
  %t252 = load i64, ptr %l13, !tbaa !24
  %t255 = add i64 %t251, %t252
  store i64 %t255, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb61:
  br label %bb33
bb62:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i64, ptr %l3, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t263 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t257, i64 %t258, { i64, ptr } %t259)
  store i32 %t263, ptr %l127
  br label %bb63
bb63:
  %t264 = load i32, ptr %l127, !tbaa !23
  store i32 %t264, ptr %l17, !tbaa !23
  %t265 = load i32, ptr %l17, !tbaa !23
  %t267 = icmp sge i32 %t265, 0
  br i1 %t267, label %bb64, label %bb65
bb64:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i32, ptr %l17, !tbaa !23
  %t273 = call { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v4, ptr %t269, i32 %t270)
  store { i64, ptr } %t273, ptr %l132
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s0)
  %t274 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t275 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t274, 1
  store { i32, { i64, ptr } } %t275, ptr %rv
  br label %ret
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t277 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t277, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = icmp sle i64 0, 1152921504606846975
  br i1 %t34, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb12:
  %t36 = mul i64 0, 8
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 0, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fexplain_2ecaseWhole(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 3
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5177bd7d484351dd_5d0dbb04dc509331)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fexplain_2econtract(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l25 = alloca ptr
  %l47 = alloca i64
  %l50 = alloca i64
  %l71 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l104 = alloca %"compiler/source:Span"
  %l106 = alloca i64
  %l108 = alloca %"compiler/source:Span"
  %l110 = alloca i64
  %l111 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 7
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 5
  %t20 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v1, ptr %v1, ptr %t16, i64 %a3)
  store ptr %t20, ptr %l25
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l25, !tbaa !29
  %t23 = getelementptr %"compiler/load:Module", ptr %t21, i32 0, i32 6
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_e7ca39a48e286d3f_b849249cb4ab4933)
  unreachable
bb6:
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"compiler/source:Source", ptr %t30, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l6, !tbaa !27
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Sig", ptr %t36, i32 0, i32 5
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 1
  %t49 = extractvalue { i64, ptr } %t46, 0
  %t50 = extractvalue { i64, ptr } { i64 15, ptr @.d1 }, 1
  %t51 = extractvalue { i64, ptr } { i64 15, ptr @.d1 }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t48, i64 %t49)
  %t54 = getelementptr i8, ptr %t53, i64 %t49
  call void @olang_textcopy(ptr %t54, ptr %t50, i64 %t51)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = extractvalue { i64, ptr } %t56, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t45, { i64, ptr } %t63)
  br label %bb10
bb9:
  br label %bb30
bb10:
  store i64 0, ptr %l7, !tbaa !24
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Sig", ptr %t66, i32 0, i32 5
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  store i64 %t71, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb11, label %bb12
bb11:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb16
bb13:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l50, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb15
bb15:
  %t99 = load i64, ptr %l50, !tbaa !24
  store i64 %t99, ptr %l47, !tbaa !24
  br label %bb16
bb16:
  %t100 = load i64, ptr %l47, !tbaa !24
  store i64 %t100, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t101 = load i64, ptr %l11, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb19:
  br label %bb20
bb20:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t110 = load i64, ptr %l11, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l12, !tbaa !24
  %t119 = load i64, ptr %l12, !tbaa !24
  %t121 = icmp sgt i64 %t119, 0
  br i1 %t121, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t123 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t123, { i64, ptr } { i64 2, ptr @.d2 })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb24:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l71, !tbaa !29
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/load:Loader", ptr %t132, i32 0, i32 3
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t136 = load ptr, ptr %l2, !tbaa !29
  %t138 = getelementptr %"compiler/ast:Sig", ptr %t136, i32 0, i32 5
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l77, !tbaa !27
  %t140 = load i64, ptr %l12, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i32, ptr %t143, i64 %t140
  %t145 = load i32, ptr %t144, !tbaa !33
  %t148 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %t135, i32 %t145)
  store { i64, ptr } %t148, ptr %l80
  br label %bb25
bb25:
  %t149 = load ptr, ptr %l71, !tbaa !29
  %t150 = load { i64, ptr }, ptr %l80, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t149, { i64, ptr } %t150)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  %t151 = load i64, ptr %l11, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l11, !tbaa !24
  br label %bb17
bb28:
  %t155 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t155, { i64, ptr } { i64 1, ptr @.d3 })
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t159 = getelementptr %"compiler/ast:Sig", ptr %t157, i32 0, i32 7
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  br i1 %t162, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_ec0929e0cef23b20_10aa079683981964)
  unreachable
bb32:
  br label %bb33
bb33:
  %t164 = load ptr, ptr %l2, !tbaa !29
  %t166 = getelementptr %"compiler/ast:Sig", ptr %t164, i32 0, i32 7
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t170 = getelementptr %"compiler/ast:ContractBlock", ptr %t167, i32 0, i32 1
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  store { i64, ptr } %t171, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l15, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t177 = load i64, ptr %l14, !tbaa !24
  %t178 = load i64, ptr %l15, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s9)
  br label %bb48
bb36:
  br label %bb37
bb37:
  %t185 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t185, ptr %l97, !tbaa !27
  %t186 = load i64, ptr %l14, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr ptr, ptr %t189, i64 %t186
  %t191 = load ptr, ptr %t190, !tbaa !39
  store ptr %t191, ptr %l16, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l100, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t194, ptr %l101, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t195, ptr %l102, !tbaa !27
  %t196 = load ptr, ptr %l16, !tbaa !29
  %t198 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v2, ptr %t196)
  store %"compiler/source:Span" %t198, ptr %l104
  br label %bb38
bb38:
  %t199 = getelementptr %"compiler/source:Span", ptr %l104, i32 0, i32 0
  %t200 = load i32, ptr %t199, !tbaa !23
  %t202 = sext i32 %t200 to i64
  store i64 %t202, ptr %l106, !tbaa !24
  %t203 = load ptr, ptr %l16, !tbaa !29
  %t205 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v2, ptr %t203)
  store %"compiler/source:Span" %t205, ptr %l108
  br label %bb39
bb39:
  %t206 = getelementptr %"compiler/source:Span", ptr %l108, i32 0, i32 1
  %t207 = load i32, ptr %t206, !tbaa !23
  %t209 = sext i32 %t207 to i64
  store i64 %t209, ptr %l110, !tbaa !24
  %t210 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  store i64 %t211, ptr %l111, !tbaa !24
  %t212 = load i64, ptr %l106, !tbaa !24
  %t213 = icmp sge i64 %t212, 0
  br i1 %t213, label %bb40, label %bb41
bb40:
  %t215 = load i64, ptr %l106, !tbaa !24
  %t216 = load i64, ptr %l110, !tbaa !24
  %t217 = icmp sle i64 %t215, %t216
  br i1 %t217, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb42:
  %t219 = load i64, ptr %l110, !tbaa !24
  %t220 = load i64, ptr %l111, !tbaa !24
  %t221 = icmp sle i64 %t219, %t220
  br i1 %t221, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb44:
  %t223 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = load i64, ptr %l106, !tbaa !24
  %t226 = load i64, ptr %l110, !tbaa !24
  %t227 = getelementptr i8, ptr %t224, i64 %t225
  %t228 = sub i64 %t226, %t225
  %t229 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t227, 1
  %t231 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 1
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t234 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 1
  %t235 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 0
  %t236 = add i64 %t233, %t235
  %t238 = extractvalue { i64, ptr } %t230, 1
  %t239 = extractvalue { i64, ptr } %t230, 0
  %t240 = add i64 %t236, %t239
  %t241 = extractvalue { i64, ptr } { i64 2, ptr @.d5 }, 1
  %t242 = extractvalue { i64, ptr } { i64 2, ptr @.d5 }, 0
  %t243 = add i64 %t240, %t242
  %t244 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t243)
  call void @olang_textcopy(ptr %t244, ptr %t232, i64 %t233)
  %t245 = getelementptr i8, ptr %t244, i64 %t233
  call void @olang_textcopy(ptr %t245, ptr %t234, i64 %t235)
  %t246 = getelementptr i8, ptr %t245, i64 %t235
  call void @olang_textcopy(ptr %t246, ptr %t238, i64 %t239)
  %t247 = getelementptr i8, ptr %t246, i64 %t239
  call void @olang_textcopy(ptr %t247, ptr %t241, i64 %t242)
  %t248 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t244, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = extractvalue { i64, ptr } %t249, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t257 = load ptr, ptr %l100, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s9, ptr %t257, { i64, ptr } %t256)
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb47
bb47:
  %t259 = load i64, ptr %l14, !tbaa !24
  %t261 = add i64 %t259, 1
  store i64 %t261, ptr %l14, !tbaa !24
  br label %bb34
bb48:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:StructBody", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = icmp sle i64 0, 1152921504606846975
  br i1 %t28, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb12:
  %t30 = mul i64 0, 8
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 0, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_979fe2e14fb6de05_5947910940c194f1)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr @.d6 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr @.d7 }, ptr %l9, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  br label %bb13
bb6:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load i64, ptr %l1, !tbaa !24
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t18, 0
  store i64 %t21, ptr %l15, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l16, !tbaa !24
  %t24 = load i64, ptr %l12, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load i64, ptr %l12, !tbaa !24
  %t28 = load i64, ptr %l15, !tbaa !24
  %t29 = icmp sle i64 %t27, %t28
  br i1 %t29, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb9:
  %t31 = load i64, ptr %l15, !tbaa !24
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb11:
  %t35 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = load i64, ptr %l12, !tbaa !24
  %t38 = load i64, ptr %l15, !tbaa !24
  %t39 = getelementptr i8, ptr %t36, i64 %t37
  %t40 = sub i64 %t38, %t37
  %t41 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t39, 1
  store { i64, ptr } %t42, ptr %l8, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb13:
  %t45 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l22, !tbaa !24
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l23, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l22, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2efields(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/typed:Local"
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l39 = alloca { i64, ptr }
  %l52 = alloca i32
  %l56 = alloca i1
  %l61 = alloca i32
  %l66 = alloca i32
  %l68 = alloca i1
  %l73 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l85 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i64
  %l92 = alloca ptr
  %l102 = alloca i64
  %l106 = alloca i64
  %l109 = alloca i64
  %l128 = alloca ptr
  %l132 = alloca i32
  %l134 = alloca %"compiler/typed:Local"
  %l139 = alloca i32
  %l140 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l162 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l164 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l30
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l29
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t14, ptr %l26, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l30, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_d16c6b36ae6c900f_110b33433d32ce53)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb7:
  %t20 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb72
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l39, !tbaa !27
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  store ptr %t39, ptr %l8, !tbaa !29
  %t41 = load ptr, ptr %l8, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 1
  %t44 = load { i64, [2 x i64] }, ptr %t43
  store { i64, [2 x i64] } %t44, ptr %l9
  %t46 = load { i64, [2 x i64] }, ptr %l9
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l10, !tbaa !23
  %t55 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t56 = getelementptr { i32, i32 }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l11, !tbaa !23
  br label %bb14
bb13:
  br label %bb65
bb14:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l10, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l52
  br label %bb15
bb15:
  %t69 = load i32, ptr %l52
  %t71 = trunc i64 18 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb20
bb17:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l10, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l61
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %l2, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l66
  br label %bb19
bb19:
  %t96 = load i32, ptr %l61, !tbaa !23
  %t97 = load i32, ptr %l66, !tbaa !23
  %t98 = icmp ne i32 %t96, %t97
  store i1 %t98, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t100 = load i1, ptr %l56, !tbaa !21
  br i1 %t100, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb23
bb22:
  %t101 = load i32, ptr %l11, !tbaa !23
  %t103 = icmp ne i32 %t101, 0
  store i1 %t103, ptr %l68, !tbaa !21
  br label %bb23
bb23:
  %t105 = load i1, ptr %l68, !tbaa !21
  br i1 %t105, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb25:
  br label %bb26
bb26:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  store ptr %t111, ptr %l73, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t118 = load i32, ptr %l2, !tbaa !23
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v1, ptr %t117, i32 %t118)
  store i32 %t121, ptr %l78
  br label %bb27
bb27:
  %t122 = load ptr, ptr %l73, !tbaa !29
  %t123 = load i32, ptr %l78, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %t122, i32 %t123)
  store { i64, ptr } %t124, ptr %l79
  br label %bb28
bb28:
  %t125 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t125, ptr %l12, !tbaa !27
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/load:Loader", ptr %t132, i32 0, i32 5
  store ptr %t134, ptr %l83, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %l85, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l2, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l90
  br label %bb29
bb29:
  %t149 = load ptr, ptr %l85, !tbaa !29
  %t150 = load i32, ptr %l90, !tbaa !23
  %t151 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v1, ptr %t149, i32 %t150)
  store i64 %t151, ptr %l91
  br label %bb30
bb30:
  %t152 = load ptr, ptr %l83, !tbaa !29
  %t153 = load i64, ptr %l91, !tbaa !24
  %t154 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v1, ptr %v1, ptr %t152, i64 %t153)
  store ptr %t154, ptr %l92
  br label %bb31
bb31:
  %t155 = load ptr, ptr %l92, !tbaa !29
  %t157 = getelementptr %"compiler/load:Module", ptr %t155, i32 0, i32 6
  %t158 = load ptr, ptr %t157, !tbaa !29
  store ptr %t158, ptr %l13, !tbaa !29
  %t160 = load ptr, ptr %l13, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  br i1 %t162, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_35ffc19e50bbc737_e52638f1e81552b)
  unreachable
bb33:
  br label %bb34
bb34:
  %t164 = load ptr, ptr %l13, !tbaa !29
  %t167 = getelementptr %"compiler/source:Source", ptr %t164, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  store { i64, ptr } %t168, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t170 = load ptr, ptr %l8, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Body", ptr %t170, i32 0, i32 10
  %t174 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t172)
  store i64 %t174, ptr %l102
  br label %bb35
bb35:
  %t175 = load i64, ptr %l102, !tbaa !24
  store i64 %t175, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t176 = load i64, ptr %l16, !tbaa !24
  %t177 = load i64, ptr %l15, !tbaa !24
  %t180 = icmp sgt i64 %t176, %t177
  br i1 %t180, label %bb36, label %bb37
bb36:
  %t182 = load i64, ptr %l17, !tbaa !24
  %t184 = icmp sgt i64 %t182, 0
  br i1 %t184, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb41
bb38:
  %t186 = load i64, ptr %l16, !tbaa !24
  %t187 = load i64, ptr %l15, !tbaa !24
  %t190 = sub i64 %t186, %t187
  %t191 = load i64, ptr %l17, !tbaa !24
  %t194 = add i64 %t190, %t191
  %t196 = sub i64 %t194, 1
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = sdiv i64 %t196, %t197
  store i64 %t200, ptr %l109, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb40
bb40:
  %t202 = load i64, ptr %l109, !tbaa !24
  store i64 %t202, ptr %l106, !tbaa !24
  br label %bb41
bb41:
  %t203 = load i64, ptr %l106, !tbaa !24
  store i64 %t203, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t204 = load i64, ptr %l19, !tbaa !24
  %t205 = load i64, ptr %l18, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb44:
  br label %bb45
bb45:
  %t212 = load i64, ptr %l15, !tbaa !24
  %t213 = load i64, ptr %l19, !tbaa !24
  %t214 = load i64, ptr %l17, !tbaa !24
  %t217 = mul i64 %t213, %t214
  %t220 = add i64 %t212, %t217
  store i64 %t220, ptr %l20, !tbaa !24
  %t222 = load ptr, ptr %l8, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Body", ptr %t222, i32 0, i32 7
  store ptr %t224, ptr %l128, !tbaa !29
  %t225 = load ptr, ptr %l8, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Body", ptr %t225, i32 0, i32 10
  %t228 = load i64, ptr %l20, !tbaa !24
  %t231 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t227, i64 %t228)
  store i32 %t231, ptr %l132
  br label %bb46
bb46:
  %t232 = load i32, ptr %l132, !tbaa !23
  %t233 = sext i32 %t232 to i64
  %t234 = load ptr, ptr %l128, !tbaa !29
  %t236 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t234, i64 %t233)
  store %"compiler/typed:Local" %t236, ptr %l134
  br label %bb47
bb47:
  %t237 = load %"compiler/typed:Local", ptr %l134
  store %"compiler/typed:Local" %t237, ptr %l21
  %t238 = load i64, ptr %l20, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t244 = icmp slt i64 %t238, %t241
  br i1 %t244, label %bb48, label %bb49
bb48:
  %t246 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t246, ptr %l140, !tbaa !27
  %t247 = load i64, ptr %l20, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i32, ptr %t250, i64 %t247
  %t252 = load i32, ptr %t251, !tbaa !33
  store i32 %t252, ptr %l139, !tbaa !23
  br label %bb50
bb49:
  %t254 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 2
  %t255 = load i32, ptr %t254, !tbaa !23
  store i32 %t255, ptr %l139, !tbaa !23
  br label %bb50
bb50:
  %t257 = load i32, ptr %l139, !tbaa !23
  store i32 %t257, ptr %l22, !tbaa !23
  %t258 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = icmp eq i32 %t259, 0
  br i1 %t261, label %bb51, label %bb52
bb51:
  %t263 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t263, ptr %l147, !tbaa !27
  %t264 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t265 = getelementptr %"compiler/source:Span", ptr %t264, i32 0, i32 0
  %t266 = load i32, ptr %t265, !tbaa !23
  %t268 = sext i32 %t266 to i64
  store i64 %t268, ptr %l149, !tbaa !24
  %t269 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t270 = getelementptr %"compiler/source:Span", ptr %t269, i32 0, i32 1
  %t271 = load i32, ptr %t270, !tbaa !23
  %t273 = sext i32 %t271 to i64
  store i64 %t273, ptr %l151, !tbaa !24
  %t274 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  store i64 %t275, ptr %l152, !tbaa !24
  %t276 = load i64, ptr %l149, !tbaa !24
  %t277 = icmp sge i64 %t276, 0
  br i1 %t277, label %bb53, label %bb54
bb52:
  %t279 = load ptr, ptr %l1, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/load:Loader", ptr %t285, i32 0, i32 3
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t289 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t290 = load i32, ptr %t289, !tbaa !23
  %t293 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %t288, i32 %t290)
  store { i64, ptr } %t293, ptr %l162
  br label %bb59
bb53:
  %t294 = load i64, ptr %l149, !tbaa !24
  %t295 = load i64, ptr %l151, !tbaa !24
  %t296 = icmp sle i64 %t294, %t295
  br i1 %t296, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2)
  unreachable
bb55:
  %t298 = load i64, ptr %l151, !tbaa !24
  %t299 = load i64, ptr %l152, !tbaa !24
  %t300 = icmp sle i64 %t298, %t299
  br i1 %t300, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2)
  unreachable
bb57:
  %t302 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = load i64, ptr %l149, !tbaa !24
  %t305 = load i64, ptr %l151, !tbaa !24
  %t306 = getelementptr i8, ptr %t303, i64 %t304
  %t307 = sub i64 %t305, %t304
  %t308 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t306, 1
  store { i64, ptr } %t309, ptr %l146, !tbaa !27
  br label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2)
  unreachable
bb59:
  %t311 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t311, ptr %l146, !tbaa !27
  br label %bb60
bb60:
  %t312 = load { i64, ptr }, ptr %l146, !tbaa !27
  store ptr %a0, ptr %l163, !tbaa !29
  store { i64, ptr } %t312, ptr %l164, !tbaa !27
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t316 = load i32, ptr %l22, !tbaa !23
  %t319 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s7, ptr %t315, i32 %t316)
  store { i64, ptr } %t319, ptr %l167
  br label %bb61
bb61:
  %t320 = extractvalue { i64, ptr } { i64 4, ptr @.d8 }, 1
  %t321 = extractvalue { i64, ptr } { i64 4, ptr @.d8 }, 0
  %t322 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 1
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t325 = add i64 %t321, %t324
  %t326 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 1
  %t327 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 0
  %t328 = add i64 %t325, %t327
  %t329 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = add i64 %t328, %t331
  %t333 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 1
  %t334 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 0
  %t335 = add i64 %t332, %t334
  %t336 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t335)
  call void @olang_textcopy(ptr %t336, ptr %t320, i64 %t321)
  %t337 = getelementptr i8, ptr %t336, i64 %t321
  call void @olang_textcopy(ptr %t337, ptr %t323, i64 %t324)
  %t338 = getelementptr i8, ptr %t337, i64 %t324
  call void @olang_textcopy(ptr %t338, ptr %t326, i64 %t327)
  %t339 = getelementptr i8, ptr %t338, i64 %t327
  call void @olang_textcopy(ptr %t339, ptr %t330, i64 %t331)
  %t340 = getelementptr i8, ptr %t339, i64 %t331
  call void @olang_textcopy(ptr %t340, ptr %t333, i64 %t334)
  %t341 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t336, 1
  %t344 = extractvalue { i64, ptr } %t342, 0
  %t345 = extractvalue { i64, ptr } %t342, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  %t350 = load ptr, ptr %l163, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t350, { i64, ptr } %t349)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb63:
  %t352 = load i64, ptr %l19, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l19, !tbaa !24
  br label %bb42
bb64:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_36a09f0a29856ad4_1f4c57e6e1803c38)
  unreachable
bb70:
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb71:
  %t356 = load i64, ptr %l7, !tbaa !24
  %t358 = add i64 %t356, 1
  store i64 %t358, ptr %l7, !tbaa !24
  br label %bb8
bb72:
  %t360 = load i64, ptr %l4, !tbaa !24
  %t361 = load i64, ptr %l6, !tbaa !24
  %t364 = add i64 %t360, %t361
  store i64 %t364, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb73:
  br label %bb1
bb74:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fexplain_2efirstClose(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t2, 0
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = icmp sge i64 3, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sle i64 3, %t10
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sle i64 %t13, %t14
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb5:
  %t17 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr i8, ptr %t18, i64 3
  %t21 = sub i64 %t19, 3
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = call i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %t23)
  store i64 %t25, ptr %l10
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb7:
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = add i64 3, %t26
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEnd(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l56, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = sub i64 %t96, 1
  store i64 %t98, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb30:
  br label %bb31
bb31:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = icmp eq i8 %t104, 44
  br i1 %t106, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb37
bb34:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb36
bb35:
  %t108 = load i8, ptr %l8, !tbaa !22
  %t110 = icmp eq i8 %t108, 41
  store i1 %t110, ptr %l66, !tbaa !21
  br label %bb36
bb36:
  %t112 = load i1, ptr %l66, !tbaa !21
  store i1 %t112, ptr %l63, !tbaa !21
  br label %bb37
bb37:
  %t113 = load i1, ptr %l63, !tbaa !21
  br i1 %t113, label %bb38, label %bb39
bb38:
  %t114 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t114, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l6, !tbaa !24
  br label %bb7
bb42:
  %t120 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  store i64 %t122, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb28, label %bb29
bb27:
  br label %bb31
bb28:
  %t95 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t95, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t97 = load i64, ptr %l1, !tbaa !24
  %t99 = sub i64 %t97, 1
  store i64 %t99, ptr %l1, !tbaa !24
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l6, !tbaa !24
  br label %bb7
bb33:
  %t105 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i64
  %l37 = alloca i32
  %l39 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i64
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l78 = alloca ptr
  %l80 = alloca ptr
  %l84 = alloca i64
  %l88 = alloca ptr
  %l91 = alloca i64
  %l95 = alloca i64
  %l98 = alloca i64
  %l119 = alloca i64
  %l124 = alloca i64
  %l127 = alloca ptr
  %l131 = alloca i32
  %l137 = alloca i32
  %l138 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l150 = alloca i32
  %l151 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca i64
  %l168 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t3)
  store i64 %t5, ptr %l18
  br label %bb2
bb2:
  %t6 = load i64, ptr %l18, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t10, i64 %t6)
  store i64 %t14, ptr %l22
  br label %bb3
bb3:
  %t15 = load i64, ptr %l22, !tbaa !24
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t21, i64 %t22, i32 0)
  store i64 %t25, ptr %l27
  br label %bb6
bb5:
  br label %bb16
bb6:
  %t26 = load i64, ptr %l27, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l30
  br label %bb7
bb7:
  %t32 = load i64, ptr %l30, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store ptr %l3, ptr %l31, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l32, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l33, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t38, i64 %t39)
  store i32 %t42, ptr %l37
  br label %bb8
bb8:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load ptr, ptr %l32, !tbaa !29
  %t45 = load i64, ptr %l33, !tbaa !24
  %t46 = load i32, ptr %l37, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s1, ptr %t44, i64 %t45, i32 %t46, i64 %t43)
  store { i64, ptr } %t48, ptr %l39
  br label %bb9
bb9:
  %t49 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = getelementptr i8, ptr %t55, i64 %t51
  call void @olang_textcopy(ptr %t56, ptr %t52, i64 %t53)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t66, { i64, ptr } %t65)
  br label %bb10
bb10:
  store ptr %l3, ptr %l42, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l43, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t73 = load i64, ptr %l2, !tbaa !24
  %t76 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t72, i64 %t73)
  store ptr %t76, ptr %l47
  br label %bb11
bb11:
  %t77 = load ptr, ptr %l47, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  store ptr %t80, ptr %l49, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load i64, ptr %l2, !tbaa !24
  %t88 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t84, i64 %t85)
  store i64 %t88, ptr %l53
  br label %bb12
bb12:
  %t89 = load ptr, ptr %l42, !tbaa !29
  %t90 = load ptr, ptr %l43, !tbaa !29
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = load i64, ptr %l53, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s1, ptr %t89, ptr %t90, ptr %t91, i64 %t92, { i64, ptr } { i64 4, ptr @.d12 })
  br label %bb13
bb13:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t95 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s1, ptr %l3, ptr %t93, ptr %t94, i64 %t95, { i64, ptr } { i64 4, ptr @.d13 })
  br label %bb14
bb14:
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t101, ptr %l59
  br label %bb15
bb15:
  %t102 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t102, ptr %l60, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l61, !tbaa !24
  %t105 = load i64, ptr %l61, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l62, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l61, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t116, ptr %l60, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb16:
  store ptr %l3, ptr %l63, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l64, !tbaa !29
  %t119 = load i64, ptr %l2, !tbaa !24
  store i64 %t119, ptr %l65, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t124 = load i64, ptr %l2, !tbaa !24
  %t127 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t123, i64 %t124)
  store i32 %t127, ptr %l69
  br label %bb17
bb17:
  %t128 = load ptr, ptr %l64, !tbaa !29
  %t129 = load i64, ptr %l65, !tbaa !24
  %t130 = load i32, ptr %l69, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s0, ptr %t128, i64 %t129, i32 %t130, i64 -1)
  store { i64, ptr } %t131, ptr %l70
  br label %bb18
bb18:
  %t132 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 0
  %t137 = add i64 %t134, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t133, i64 %t134)
  %t139 = getelementptr i8, ptr %t138, i64 %t134
  call void @olang_textcopy(ptr %t139, ptr %t135, i64 %t136)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t138, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } %t141, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t149 = load ptr, ptr %l63, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t149, { i64, ptr } %t148)
  br label %bb19
bb19:
  store ptr %l3, ptr %l73, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l74, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t156 = load i64, ptr %l2, !tbaa !24
  %t159 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t155, i64 %t156)
  store ptr %t159, ptr %l78
  br label %bb20
bb20:
  %t160 = load ptr, ptr %l78, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Func", ptr %t160, i32 0, i32 3
  %t163 = load ptr, ptr %t162, !tbaa !29
  store ptr %t163, ptr %l80, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t168 = load i64, ptr %l2, !tbaa !24
  %t171 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t167, i64 %t168)
  store i64 %t171, ptr %l84
  br label %bb21
bb21:
  %t172 = load ptr, ptr %l73, !tbaa !29
  %t173 = load ptr, ptr %l74, !tbaa !29
  %t174 = load ptr, ptr %l80, !tbaa !29
  %t175 = load i64, ptr %l84, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t172, ptr %t173, ptr %t174, i64 %t175, { i64, ptr } { i64 4, ptr @.d15 })
  br label %bb22
bb22:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t180 = load i64, ptr %l2, !tbaa !24
  %t183 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t179, i64 %t180)
  store ptr %t183, ptr %l88
  br label %bb23
bb23:
  %t184 = load ptr, ptr %l88, !tbaa !29
  store ptr %t184, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %t188)
  store i64 %t190, ptr %l91
  br label %bb24
bb24:
  %t191 = load i64, ptr %l91, !tbaa !24
  store i64 %t191, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t192 = load i64, ptr %l9, !tbaa !24
  %t193 = load i64, ptr %l8, !tbaa !24
  %t196 = icmp sgt i64 %t192, %t193
  br i1 %t196, label %bb25, label %bb26
bb25:
  %t198 = load i64, ptr %l10, !tbaa !24
  %t200 = icmp sgt i64 %t198, 0
  br i1 %t200, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb30
bb27:
  %t202 = load i64, ptr %l9, !tbaa !24
  %t203 = load i64, ptr %l8, !tbaa !24
  %t206 = sub i64 %t202, %t203
  %t207 = load i64, ptr %l10, !tbaa !24
  %t210 = add i64 %t206, %t207
  %t212 = sub i64 %t210, 1
  %t213 = load i64, ptr %l10, !tbaa !24
  %t216 = sdiv i64 %t212, %t213
  store i64 %t216, ptr %l98, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb29
bb29:
  %t218 = load i64, ptr %l98, !tbaa !24
  store i64 %t218, ptr %l95, !tbaa !24
  br label %bb30
bb30:
  %t219 = load i64, ptr %l95, !tbaa !24
  store i64 %t219, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t220 = load i64, ptr %l12, !tbaa !24
  %t221 = load i64, ptr %l11, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb33:
  br label %bb34
bb34:
  %t228 = load i64, ptr %l8, !tbaa !24
  %t229 = load i64, ptr %l12, !tbaa !24
  %t230 = load i64, ptr %l10, !tbaa !24
  %t233 = mul i64 %t229, %t230
  %t236 = add i64 %t228, %t233
  store i64 %t236, ptr %l13, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t242 = load i64, ptr %l13, !tbaa !24
  %t245 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t241, i64 %t242)
  store i64 %t245, ptr %l119
  br label %bb35
bb35:
  %t246 = load i64, ptr %l2, !tbaa !24
  %t247 = load i64, ptr %l119, !tbaa !24
  %t249 = icmp ne i64 %t247, %t246
  br i1 %t249, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb37:
  br label %bb38
bb38:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load i64, ptr %l13, !tbaa !24
  %t255 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t251, i64 %t252)
  store i64 %t255, ptr %l124
  br label %bb39
bb39:
  %t256 = load i64, ptr %l124, !tbaa !24
  store i64 %t256, ptr %l14, !tbaa !24
  %t257 = load i64, ptr %l14, !tbaa !24
  %t259 = icmp slt i64 %t257, 0
  br i1 %t259, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb41:
  br label %bb42
bb42:
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l127, !tbaa !29
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/check:Checker", ptr %t262, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t266 = load i64, ptr %l13, !tbaa !24
  %t269 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t265, i64 %t266)
  store i32 %t269, ptr %l131
  br label %bb43
bb43:
  %t270 = load ptr, ptr %l7, !tbaa !29
  %t272 = getelementptr %"compiler/ast:Func", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = load ptr, ptr %l7, !tbaa !29
  %t276 = getelementptr %"compiler/ast:Func", ptr %t274, i32 0, i32 3
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/ast:Sig", ptr %t277, i32 0, i32 0
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  %t281 = load ptr, ptr %l127, !tbaa !29
  %t282 = load i32, ptr %l131, !tbaa !23
  %t285 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t281, i32 %t282, ptr %t273, { i64, ptr } %t280)
  store i32 %t285, ptr %l137
  br label %bb44
bb44:
  %t286 = load i32, ptr %l137, !tbaa !23
  store i32 %t286, ptr %l15, !tbaa !23
  store ptr %l3, ptr %l138, !tbaa !29
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/check:Checker", ptr %t287, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !29
  %t292 = getelementptr %"compiler/generic:Program", ptr %t290, i32 0, i32 0
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t295 = getelementptr %"compiler/load:Loader", ptr %t293, i32 0, i32 3
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t297 = load ptr, ptr %l7, !tbaa !29
  %t299 = getelementptr %"compiler/ast:Func", ptr %t297, i32 0, i32 2
  %t300 = load i32, ptr %t299, !tbaa !23
  %t303 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t296, i32 %t300)
  store { i64, ptr } %t303, ptr %l145
  br label %bb45
bb45:
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l146, !tbaa !29
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/check:Checker", ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t309 = load i64, ptr %l13, !tbaa !24
  %t312 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t308, i64 %t309)
  store i32 %t312, ptr %l150
  br label %bb46
bb46:
  %t313 = load ptr, ptr %l146, !tbaa !29
  %t314 = load i32, ptr %l150, !tbaa !23
  %t315 = call { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %s5, ptr %t313, i32 %t314)
  store { i64, ptr } %t315, ptr %l151
  br label %bb47
bb47:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load i32, ptr %l15, !tbaa !23
  %t318 = load i64, ptr %l14, !tbaa !24
  %t322 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s5, ptr %t316, i32 %t317, i64 %t318)
  store { i64, ptr } %t322, ptr %l155
  br label %bb48
bb48:
  %t323 = extractvalue { i64, ptr } { i64 13, ptr @.d16 }, 1
  %t324 = extractvalue { i64, ptr } { i64 13, ptr @.d16 }, 0
  %t325 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t325, 1
  %t327 = extractvalue { i64, ptr } %t325, 0
  %t328 = add i64 %t324, %t327
  %t329 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = add i64 %t328, %t331
  %t333 = extractvalue { i64, ptr } { i64 2, ptr @.d17 }, 1
  %t334 = extractvalue { i64, ptr } { i64 2, ptr @.d17 }, 0
  %t335 = add i64 %t332, %t334
  %t336 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = add i64 %t335, %t338
  %t340 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 1
  %t341 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 0
  %t342 = add i64 %t339, %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t342)
  call void @olang_textcopy(ptr %t343, ptr %t323, i64 %t324)
  %t344 = getelementptr i8, ptr %t343, i64 %t324
  call void @olang_textcopy(ptr %t344, ptr %t326, i64 %t327)
  %t345 = getelementptr i8, ptr %t344, i64 %t327
  call void @olang_textcopy(ptr %t345, ptr %t330, i64 %t331)
  %t346 = getelementptr i8, ptr %t345, i64 %t331
  call void @olang_textcopy(ptr %t346, ptr %t333, i64 %t334)
  %t347 = getelementptr i8, ptr %t346, i64 %t334
  call void @olang_textcopy(ptr %t347, ptr %t337, i64 %t338)
  %t348 = getelementptr i8, ptr %t347, i64 %t338
  call void @olang_textcopy(ptr %t348, ptr %t340, i64 %t341)
  %t349 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t343, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } %t350, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  %t358 = load ptr, ptr %l138, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t358, { i64, ptr } %t357)
  br label %bb49
bb49:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t362 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s5, ptr %l3, ptr %t360, ptr %t361, i64 %t362, { i64, ptr } { i64 8, ptr @.d19 })
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb51:
  %t367 = load i64, ptr %l12, !tbaa !24
  %t369 = add i64 %t367, 1
  store i64 %t369, ptr %l12, !tbaa !24
  br label %bb31
bb52:
  %t372 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t372, ptr %l165
  br label %bb53
bb53:
  %t373 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t373, ptr %l166, !tbaa !27
  %t374 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 0
  store i64 %t375, ptr %l167, !tbaa !24
  %t376 = load i64, ptr %l167, !tbaa !24
  %t377 = mul i64 %t376, 1
  %t378 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t377)
  %t379 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t380 = insertvalue { i64, ptr } %t379, ptr %t378, 1
  store { i64, ptr } %t380, ptr %l168, !tbaa !27
  %t381 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !27
  %t383 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !27
  %t385 = load i64, ptr %l167, !tbaa !24
  %t386 = mul i64 %t385, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t382, ptr %t384, i64 %t386, i1 false)
  %t387 = load { i64, ptr }, ptr %l168, !tbaa !27
  store { i64, ptr } %t387, ptr %l166, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t388 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t388, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l25 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l39 = alloca i32
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t19, i32 %t23)
  store { i64, ptr } %t26, ptr %l22
  br label %bb2
bb2:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l23, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t28)
  store i64 %t30, ptr %l25
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l28
  br label %bb4
bb4:
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load i64, ptr %l25, !tbaa !24
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t36, i64 %t37, i64 %t38)
  store { i64, ptr } %t39, ptr %l29
  br label %bb5
bb5:
  %t40 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = add i64 %t42, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t41, i64 %t42)
  %t48 = getelementptr i8, ptr %t47, i64 %t42
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l31, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Func", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Sig", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t70 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t53, i32 %a2, ptr %t58, { i64, ptr } %t65)
  store i32 %t70, ptr %l39
  br label %bb6
bb6:
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t73 = load i32, ptr %l39, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s0, ptr %t72, i32 %t73, i64 %a3)
  store { i64, ptr } %t75, ptr %l41
  br label %bb7
bb7:
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t76, ptr %l6, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i64, ptr %l1, !tbaa !24
  %t84 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t80, i64 %t81)
  store i1 %t84, ptr %l45
  br label %bb8
bb8:
  %t85 = load i1, ptr %l45, !tbaa !21
  br i1 %t85, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 10, ptr @.d20 }, ptr %l46, !tbaa !27
  br label %bb11
bb10:
  store { i64, ptr } { i64 3, ptr @.d21 }, ptr %l46, !tbaa !27
  br label %bb11
bb11:
  %t86 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  store i64 %t89, ptr %l48, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l49, !tbaa !24
  %t92 = icmp sge i64 3, 0
  br i1 %t92, label %bb12, label %bb13
bb12:
  %t94 = load i64, ptr %l48, !tbaa !24
  %t95 = icmp sle i64 3, %t94
  br i1 %t95, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb14:
  %t97 = load i64, ptr %l48, !tbaa !24
  %t98 = load i64, ptr %l49, !tbaa !24
  %t99 = icmp sle i64 %t97, %t98
  br i1 %t99, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb16:
  %t101 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l48, !tbaa !24
  %t104 = getelementptr i8, ptr %t102, i64 3
  %t105 = sub i64 %t103, 3
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %l8, !tbaa !27
  %t109 = load ptr, ptr %l4, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Func", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  br i1 %t114, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb18:
  %t116 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t116, 1
  %t121 = extractvalue { i64, ptr } %t116, 0
  %t123 = extractvalue { i64, ptr } %t117, 1
  %t124 = extractvalue { i64, ptr } %t117, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 1
  %t127 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 0
  %t128 = add i64 %t125, %t127
  %t130 = extractvalue { i64, ptr } %t118, 1
  %t131 = extractvalue { i64, ptr } %t118, 0
  %t132 = add i64 %t128, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t120, i64 %t121)
  %t134 = getelementptr i8, ptr %t133, i64 %t121
  call void @olang_textcopy(ptr %t134, ptr %t123, i64 %t124)
  %t135 = getelementptr i8, ptr %t134, i64 %t124
  call void @olang_textcopy(ptr %t135, ptr %t126, i64 %t127)
  %t136 = getelementptr i8, ptr %t135, i64 %t127
  call void @olang_textcopy(ptr %t136, ptr %t130, i64 %t131)
  %t137 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t133, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t138, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t140 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t142 = call i64 @compiler_2fexplain_2efirstItemEnd(ptr %s0, { i64, ptr } %t140)
  store i64 %t142, ptr %l62
  br label %bb21
bb21:
  %t143 = load i64, ptr %l62, !tbaa !24
  store i64 %t143, ptr %l9, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t144, ptr %l63, !tbaa !27
  %t145 = load i64, ptr %l9, !tbaa !24
  store i64 %t145, ptr %l64, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  store i64 %t147, ptr %l65, !tbaa !24
  %t148 = icmp sge i64 0, 0
  br i1 %t148, label %bb22, label %bb23
bb22:
  %t150 = load i64, ptr %l64, !tbaa !24
  %t151 = icmp sle i64 0, %t150
  br i1 %t151, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb24:
  %t153 = load i64, ptr %l64, !tbaa !24
  %t154 = load i64, ptr %l65, !tbaa !24
  %t155 = icmp sle i64 %t153, %t154
  br i1 %t155, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb26:
  %t157 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l64, !tbaa !24
  %t160 = getelementptr i8, ptr %t158, i64 0
  %t161 = sub i64 %t159, 0
  %t162 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t160, 1
  store { i64, ptr } %t163, ptr %l10, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t165, ptr %l70, !tbaa !27
  %t166 = load i64, ptr %l9, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i8, ptr %t169, i64 %t166
  %t171 = load i8, ptr %t170, !tbaa !32
  %t173 = icmp eq i8 %t171, 44
  br i1 %t173, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb28:
  %t175 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t175, ptr %l75, !tbaa !27
  %t176 = load i64, ptr %l9, !tbaa !24
  %t178 = add i64 %t176, 2
  store i64 %t178, ptr %l77, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t179, 0
  store i64 %t182, ptr %l80, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  store i64 %t184, ptr %l81, !tbaa !24
  %t185 = load i64, ptr %l77, !tbaa !24
  %t186 = icmp sge i64 %t185, 0
  br i1 %t186, label %bb30, label %bb31
bb29:
  %t188 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t188, ptr %l86, !tbaa !27
  %t189 = load i64, ptr %l9, !tbaa !24
  store i64 %t189, ptr %l87, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t190, 0
  store i64 %t193, ptr %l90, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  store i64 %t195, ptr %l91, !tbaa !24
  %t196 = load i64, ptr %l87, !tbaa !24
  %t197 = icmp sge i64 %t196, 0
  br i1 %t197, label %bb36, label %bb37
bb30:
  %t199 = load i64, ptr %l77, !tbaa !24
  %t200 = load i64, ptr %l80, !tbaa !24
  %t201 = icmp sle i64 %t199, %t200
  br i1 %t201, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb32:
  %t203 = load i64, ptr %l80, !tbaa !24
  %t204 = load i64, ptr %l81, !tbaa !24
  %t205 = icmp sle i64 %t203, %t204
  br i1 %t205, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb34:
  %t207 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l77, !tbaa !24
  %t210 = load i64, ptr %l80, !tbaa !24
  %t211 = getelementptr i8, ptr %t208, i64 %t209
  %t212 = sub i64 %t210, %t209
  %t213 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t211, 1
  store { i64, ptr } %t214, ptr %l74, !tbaa !27
  br label %bb42
bb35:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb36:
  %t216 = load i64, ptr %l87, !tbaa !24
  %t217 = load i64, ptr %l90, !tbaa !24
  %t218 = icmp sle i64 %t216, %t217
  br i1 %t218, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb38:
  %t220 = load i64, ptr %l90, !tbaa !24
  %t221 = load i64, ptr %l91, !tbaa !24
  %t222 = icmp sle i64 %t220, %t221
  br i1 %t222, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb40:
  %t224 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = load i64, ptr %l87, !tbaa !24
  %t227 = load i64, ptr %l90, !tbaa !24
  %t228 = getelementptr i8, ptr %t225, i64 %t226
  %t229 = sub i64 %t227, %t226
  %t230 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t228, 1
  store { i64, ptr } %t231, ptr %l74, !tbaa !27
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb42:
  %t233 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t234, 1
  %t240 = extractvalue { i64, ptr } %t234, 0
  %t241 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 1
  %t242 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 0
  %t243 = add i64 %t240, %t242
  %t245 = extractvalue { i64, ptr } %t235, 1
  %t246 = extractvalue { i64, ptr } %t235, 0
  %t247 = add i64 %t243, %t246
  %t248 = extractvalue { i64, ptr } { i64 2, ptr @.d24 }, 1
  %t249 = extractvalue { i64, ptr } { i64 2, ptr @.d24 }, 0
  %t250 = add i64 %t247, %t249
  %t252 = extractvalue { i64, ptr } %t236, 1
  %t253 = extractvalue { i64, ptr } %t236, 0
  %t254 = add i64 %t250, %t253
  %t255 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 1
  %t256 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 0
  %t257 = add i64 %t254, %t256
  %t259 = extractvalue { i64, ptr } %t233, 1
  %t260 = extractvalue { i64, ptr } %t233, 0
  %t261 = add i64 %t257, %t260
  %t262 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t261)
  call void @olang_textcopy(ptr %t262, ptr %t239, i64 %t240)
  %t263 = getelementptr i8, ptr %t262, i64 %t240
  call void @olang_textcopy(ptr %t263, ptr %t241, i64 %t242)
  %t264 = getelementptr i8, ptr %t263, i64 %t242
  call void @olang_textcopy(ptr %t264, ptr %t245, i64 %t246)
  %t265 = getelementptr i8, ptr %t264, i64 %t246
  call void @olang_textcopy(ptr %t265, ptr %t248, i64 %t249)
  %t266 = getelementptr i8, ptr %t265, i64 %t249
  call void @olang_textcopy(ptr %t266, ptr %t252, i64 %t253)
  %t267 = getelementptr i8, ptr %t266, i64 %t253
  call void @olang_textcopy(ptr %t267, ptr %t255, i64 %t256)
  %t268 = getelementptr i8, ptr %t267, i64 %t256
  call void @olang_textcopy(ptr %t268, ptr %t259, i64 %t260)
  %t269 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t262, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t270, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, %"compiler/names:Entry" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/names:Entry"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l8 = alloca { { i64, ptr }, i1 }
  %l9 = alloca { i64, ptr }
  %l19 = alloca i32
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca { { i64, ptr }, i1 }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l52 = alloca i32
  %l55 = alloca i32
  %l60 = alloca i32
  %l62 = alloca i32
  %l64 = alloca i32
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/names:Entry" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %t12, i64 %t13, i32 %t15)
  store i32 %t19, ptr %l19
  br label %bb1
bb1:
  %t20 = load i32, ptr %l19, !tbaa !23
  store i32 %t20, ptr %l5, !tbaa !23
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t21, i32 %t23)
  store { i64, ptr } %t26, ptr %l22
  br label %bb2
bb2:
  %t27 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr @.d26 }, ptr %l24, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 1, ptr @.d27 }, ptr %l24, !tbaa !27
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l5, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t30, i32 %t31)
  store { i64, ptr } %t34, ptr %l27
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t36, i64 %t37)
  %t47 = getelementptr i8, ptr %t46, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = getelementptr i8, ptr %t47, i64 %t40
  call void @olang_textcopy(ptr %t48, ptr %t43, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  %t52 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = extractvalue { i64, ptr } { i64 20, ptr @.d28 }, 1
  %t60 = extractvalue { i64, ptr } { i64 20, ptr @.d28 }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = getelementptr i8, ptr %t62, i64 %t58
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 1
  %t72 = load %"compiler/source:Span", ptr %t71
  %t77 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %t67, i64 %t68, i32 %t70, %"compiler/source:Span" %t72)
  store i64 %t77, ptr %l36
  br label %bb10
bb10:
  %t78 = load i64, ptr %l36, !tbaa !24
  %t83 = call { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v1, ptr %s0, ptr %a1, i64 %t78)
  store { { i64, ptr }, i1 } %t83, ptr %l39
  br label %bb11
bb11:
  %t84 = load { { i64, ptr }, i1 }, ptr %l39
  store { { i64, ptr }, i1 } %t84, ptr %l8
  %t85 = getelementptr { { i64, ptr }, i1 }, ptr %l8, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l40, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l41, !tbaa !24
  %t89 = load i64, ptr %l41, !tbaa !24
  %t90 = mul i64 %t89, 1
  %t91 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t90)
  %t92 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l42, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l41, !tbaa !24
  %t99 = mul i64 %t98, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t95, ptr %t97, i64 %t99, i1 false)
  %t100 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t100, ptr %l9, !tbaa !27
  %t101 = getelementptr { { i64, ptr }, i1 }, ptr %l8, i32 0, i32 1
  %t102 = load i1, ptr %t101, !tbaa !21
  %t106 = xor i1 %t102, true
  br i1 %t106, label %bb12, label %bb13
bb12:
  %t108 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = extractvalue { i64, ptr } %t108, 0
  %t112 = extractvalue { i64, ptr } { i64 20, ptr @.d29 }, 1
  %t113 = extractvalue { i64, ptr } { i64 20, ptr @.d29 }, 0
  %t114 = add i64 %t111, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t110, i64 %t111)
  %t116 = getelementptr i8, ptr %t115, i64 %t111
  call void @olang_textcopy(ptr %t116, ptr %t112, i64 %t113)
  %t117 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t118, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l5, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l52
  br label %bb15
bb15:
  %t130 = load i32, ptr %l52
  %t132 = trunc i64 20 to i32
  %t133 = icmp eq i32 %t130, %t132
  br i1 %t133, label %bb16, label %bb17
bb16:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l5, !tbaa !23
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t140, i32 %t141)
  store i32 %t144, ptr %l60
  br label %bb18
bb17:
  %t145 = load i32, ptr %l5, !tbaa !23
  store i32 %t145, ptr %l55, !tbaa !23
  br label %bb19
bb18:
  %t147 = load i32, ptr %l60, !tbaa !23
  store i32 %t147, ptr %l55, !tbaa !23
  br label %bb19
bb19:
  %t148 = load i32, ptr %l55, !tbaa !23
  store i32 %t148, ptr %l62, !tbaa !23
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %t150)
  store i32 %t152, ptr %l64
  br label %bb20
bb20:
  %t153 = load i32, ptr %l62, !tbaa !23
  %t154 = load i32, ptr %l64, !tbaa !23
  %t155 = icmp eq i32 %t153, %t154
  br i1 %t155, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t157 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t157, ptr %l66, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t160 = call { i64, ptr } @compiler_2fexplain_2equoted(ptr %s0, ptr %s6, { i64, ptr } %t158)
  store { i64, ptr } %t160, ptr %l68
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t161 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t164 = extractvalue { i64, ptr } { i64 3, ptr @.d30 }, 1
  %t165 = extractvalue { i64, ptr } { i64 3, ptr @.d30 }, 0
  %t166 = add i64 %t163, %t165
  %t167 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = add i64 %t166, %t169
  %t171 = extractvalue { i64, ptr } { i64 1, ptr @.d31 }, 1
  %t172 = extractvalue { i64, ptr } { i64 1, ptr @.d31 }, 0
  %t173 = add i64 %t170, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t162, i64 %t163)
  %t175 = getelementptr i8, ptr %t174, i64 %t163
  call void @olang_textcopy(ptr %t175, ptr %t164, i64 %t165)
  %t176 = getelementptr i8, ptr %t175, i64 %t165
  call void @olang_textcopy(ptr %t176, ptr %t168, i64 %t169)
  %t177 = getelementptr i8, ptr %t176, i64 %t169
  call void @olang_textcopy(ptr %t177, ptr %t171, i64 %t172)
  %t178 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t174, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t179, ptr %rv
  br label %ret
bb24:
  %t181 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = extractvalue { i64, ptr } %t181, 0
  %t186 = extractvalue { i64, ptr } { i64 3, ptr @.d32 }, 1
  %t187 = extractvalue { i64, ptr } { i64 3, ptr @.d32 }, 0
  %t188 = add i64 %t185, %t187
  %t190 = extractvalue { i64, ptr } %t182, 1
  %t191 = extractvalue { i64, ptr } %t182, 0
  %t192 = add i64 %t188, %t191
  %t193 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 1
  %t194 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 0
  %t195 = add i64 %t192, %t194
  %t196 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t195)
  call void @olang_textcopy(ptr %t196, ptr %t184, i64 %t185)
  %t197 = getelementptr i8, ptr %t196, i64 %t185
  call void @olang_textcopy(ptr %t197, ptr %t186, i64 %t187)
  %t198 = getelementptr i8, ptr %t197, i64 %t187
  call void @olang_textcopy(ptr %t198, ptr %t190, i64 %t191)
  %t199 = getelementptr i8, ptr %t198, i64 %t191
  call void @olang_textcopy(ptr %t199, ptr %t193, i64 %t194)
  %t200 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t196, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t201, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l27 = alloca i64
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca i64
  %l32 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t26 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load i64, ptr %l19, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr @.d34 })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  store ptr %l2, ptr %l22, !tbaa !29
  store { i64, ptr } %a0, ptr %l23, !tbaa !27
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l25
  br label %bb11
bb11:
  %t35 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l27, !tbaa !24
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t41 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t39)
  store %"compiler/source:Span" %t41, ptr %l29
  br label %bb12
bb12:
  %t42 = getelementptr %"compiler/source:Span", ptr %l29, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = sext i32 %t43 to i64
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l32, !tbaa !24
  %t48 = load i64, ptr %l27, !tbaa !24
  %t49 = icmp sge i64 %t48, 0
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb15:
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb17:
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l27, !tbaa !24
  %t62 = load i64, ptr %l31, !tbaa !24
  %t63 = getelementptr i8, ptr %t60, i64 %t61
  %t64 = sub i64 %t62, %t61
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t67 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t67, { i64, ptr } %t66)
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t69 = load i64, ptr %l4, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l4, !tbaa !24
  br label %bb2
bb21:
  %t74 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t74, ptr %l40
  br label %bb22
bb22:
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t75, ptr %l41, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l42, !tbaa !24
  %t78 = load i64, ptr %l42, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l43, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l42, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t89, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2emethods(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca i1
  %l54 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l75 = alloca i32
  %l82 = alloca i32
  %l87 = alloca i32
  %l91 = alloca i1
  %l96 = alloca i32
  %l101 = alloca i32
  %l104 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i64
  %l119 = alloca i32
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i64
  %l132 = alloca i32
  %l133 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v1, ptr %t4)
  br label %bb1
bb1:
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb2
bb2:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v1, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l44
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l44, !tbaa !29
  store ptr %t67, ptr %l9, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v1, ptr %t78, i32 %t79, i32 %t83)
  store i64 %t87, ptr %l54
  br label %bb16
bb16:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l54, !tbaa !24
  %t91 = icmp ne i64 %t89, %t88
  store i1 %t91, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t93 = load i1, ptr %l48, !tbaa !21
  br i1 %t93, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb19:
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l59, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t105, ptr %l62, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t109, i64 %t110)
  store i32 %t113, ptr %l66
  br label %bb21
bb21:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load i32, ptr %l66, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t114, i32 %t115)
  store i32 %t116, ptr %l67
  br label %bb22
bb22:
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load i32, ptr %l67, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %t117, i32 %t118)
  store { i64, ptr } %t119, ptr %l68
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t120, ptr %l69, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i32, ptr %t122, i64 0
  %t124 = load i32, ptr %t123, !tbaa !33
  store i32 %t124, ptr %l10, !tbaa !23
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l10, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l75
  br label %bb24
bb24:
  %t136 = load i32, ptr %l75
  %t138 = trunc i64 20 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb25, label %bb26
bb25:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l10, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v1, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l82
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t151 = load i32, ptr %l82, !tbaa !23
  store i32 %t151, ptr %l10, !tbaa !23
  br label %bb28
bb28:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  %t158 = load i32, ptr %l10, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t157, i32 %t158)
  store i32 %t161, ptr %l87
  br label %bb29
bb29:
  %t162 = load i32, ptr %l87
  %t164 = trunc i64 18 to i32
  %t165 = icmp eq i32 %t162, %t164
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb34
bb31:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/generic:Program", ptr %t172, i32 0, i32 2
  %t175 = load i32, ptr %l10, !tbaa !23
  %t178 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t174, i32 %t175)
  store i32 %t178, ptr %l96
  br label %bb32
bb32:
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l2, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l101
  br label %bb33
bb33:
  %t189 = load i32, ptr %l96, !tbaa !23
  %t190 = load i32, ptr %l101, !tbaa !23
  %t191 = icmp ne i32 %t189, %t190
  store i1 %t191, ptr %l91, !tbaa !21
  br label %bb34
bb34:
  %t193 = load i1, ptr %l91, !tbaa !21
  br i1 %t193, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb36:
  br label %bb37
bb37:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  store ptr %t197, ptr %l104, !tbaa !29
  %t198 = load i64, ptr %l8, !tbaa !24
  %t200 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t198)
  store i64 %t200, ptr %l106
  br label %bb38
bb38:
  %t201 = load ptr, ptr %l104, !tbaa !29
  %t202 = load i64, ptr %l106, !tbaa !24
  %t203 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t201, i64 %t202)
  store i64 %t203, ptr %l107
  br label %bb39
bb39:
  %t204 = load i64, ptr %l107, !tbaa !24
  %t205 = icmp eq i64 %t204, 0
  br i1 %t205, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v1, ptr %t210, i64 %t211, i32 0)
  store i64 %t214, ptr %l112
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l126, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  store ptr %t216, ptr %l127, !tbaa !29
  %t217 = load i64, ptr %l8, !tbaa !24
  store i64 %t217, ptr %l128, !tbaa !24
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t222 = load i64, ptr %l8, !tbaa !24
  %t225 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t221, i64 %t222)
  store i32 %t225, ptr %l132
  br label %bb47
bb42:
  %t226 = load i64, ptr %l112, !tbaa !24
  store i64 %t226, ptr %l11, !tbaa !24
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l113, !tbaa !29
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l114, !tbaa !29
  %t229 = load i64, ptr %l8, !tbaa !24
  store i64 %t229, ptr %l115, !tbaa !24
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v1, ptr %t233, i64 %t234)
  store i32 %t237, ptr %l119
  br label %bb43
bb43:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t239 = load i64, ptr %l11, !tbaa !24
  %t242 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v1, ptr %t238, i64 %t239)
  store i64 %t242, ptr %l122
  br label %bb44
bb44:
  %t243 = load ptr, ptr %l114, !tbaa !29
  %t244 = load i64, ptr %l115, !tbaa !24
  %t245 = load i32, ptr %l119, !tbaa !23
  %t246 = load i64, ptr %l122, !tbaa !24
  %t247 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s6, ptr %t243, i64 %t244, i32 %t245, i64 %t246)
  store { i64, ptr } %t247, ptr %l123
  br label %bb45
bb45:
  %t248 = extractvalue { i64, ptr } { i64 4, ptr @.d35 }, 1
  %t249 = extractvalue { i64, ptr } { i64 4, ptr @.d35 }, 0
  %t250 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t269 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t269, { i64, ptr } %t268)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb47:
  %t271 = load ptr, ptr %l127, !tbaa !29
  %t272 = load i64, ptr %l128, !tbaa !24
  %t273 = load i32, ptr %l132, !tbaa !23
  %t274 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s8, ptr %t271, i64 %t272, i32 %t273, i64 -1)
  store { i64, ptr } %t274, ptr %l133
  br label %bb48
bb48:
  %t275 = extractvalue { i64, ptr } { i64 4, ptr @.d37 }, 1
  %t276 = extractvalue { i64, ptr } { i64 4, ptr @.d37 }, 0
  %t277 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = add i64 %t276, %t279
  %t281 = extractvalue { i64, ptr } { i64 1, ptr @.d38 }, 1
  %t282 = extractvalue { i64, ptr } { i64 1, ptr @.d38 }, 0
  %t283 = add i64 %t280, %t282
  %t284 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t283)
  call void @olang_textcopy(ptr %t284, ptr %t275, i64 %t276)
  %t285 = getelementptr i8, ptr %t284, i64 %t276
  call void @olang_textcopy(ptr %t285, ptr %t278, i64 %t279)
  %t286 = getelementptr i8, ptr %t285, i64 %t279
  call void @olang_textcopy(ptr %t286, ptr %t281, i64 %t282)
  %t287 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t284, 1
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t291 = extractvalue { i64, ptr } %t288, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t296 = load ptr, ptr %l126, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t296, { i64, ptr } %t295)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb51:
  %t298 = load i64, ptr %l7, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l7, !tbaa !24
  br label %bb9
bb52:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca { i64, ptr }
  %l37 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l9
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Param", ptr %t10, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t15)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l7, !tbaa !24
  br label %bb8
bb7:
  br label %bb15
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t38 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t38, ptr %l27, !tbaa !27
  %t39 = load i64, ptr %l6, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  %t48 = getelementptr %"compiler/ast:Param", ptr %t44, i32 0, i32 1
  %t49 = load i32, ptr %t48, !tbaa !23
  %t51 = sext i32 %t49 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t51)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  br label %bb15
bb15:
  %t59 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t59, ptr %l37
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l1, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l45
  br label %bb17
bb17:
  %t76 = load ptr, ptr %l40, !tbaa !29
  %t77 = load i32, ptr %l45, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t76, i32 %t77)
  store { i64, ptr } %t78, ptr %l46
  br label %bb18
bb18:
  %t79 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  %t81 = load i64, ptr %l37, !tbaa !24
  %t83 = icmp ne i64 %t81, %t80
  br i1 %t83, label %bb19, label %bb20
bb19:
  %t85 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t85, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  store ptr %t92, ptr %l52, !tbaa !29
  %t93 = load i32, ptr %l1, !tbaa !23
  store i32 %t93, ptr %l53, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l56, !tbaa !29
  %t101 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t101, ptr %l58
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l56, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t104 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %s0, ptr %t102, { i64, ptr } %t103)
  store i64 %t104, ptr %l59
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l52, !tbaa !29
  %t106 = load i32, ptr %l53, !tbaa !23
  %t107 = load i64, ptr %l59, !tbaa !24
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t105, i32 %t106, i64 %t107)
  store i32 %t108, ptr %l60
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load i32, ptr %l60, !tbaa !23
  store i32 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fexplain_2eobligations(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v2, ptr %v1, ptr %s2, ptr %a2, i64 %t6, ptr %t16)
  store { i64, ptr } %t20, ptr %l17
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 16
  %t25 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  %t53 = extractvalue { i64, ptr } %a4, 1
  %t54 = extractvalue { i64, ptr } %a4, 0
  %t55 = extractvalue { i64, ptr } { i64 1, ptr @.d39 }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr @.d39 }, 0
  %t57 = add i64 %t54, %t56
  %t59 = extractvalue { i64, ptr } %t47, 1
  %t60 = extractvalue { i64, ptr } %t47, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 2, ptr @.d40 }, 1
  %t63 = extractvalue { i64, ptr } { i64 2, ptr @.d40 }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = getelementptr i8, ptr %t65, i64 %t54
  call void @olang_textcopy(ptr %t66, ptr %t55, i64 %t56)
  %t67 = getelementptr i8, ptr %t66, i64 %t56
  call void @olang_textcopy(ptr %t67, ptr %t59, i64 %t60)
  %t68 = getelementptr i8, ptr %t67, i64 %t60
  call void @olang_textcopy(ptr %t68, ptr %t62, i64 %t63)
  %t69 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t65, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %a0, { i64, ptr } %t77)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb5
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2equoted(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb2
bb2:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t19
  %t24 = load i8, ptr %t23, !tbaa !32
  store i8 %t24, ptr %l5, !tbaa !22
  %t26 = load i8, ptr %l5, !tbaa !22
  %t28 = icmp eq i8 %t26, 34
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 92
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb12
bb11:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 10
  br i1 %t38, label %bb14, label %bb15
bb12:
  %t40 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t40)
  br label %bb13
bb13:
  br label %bb23
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr @.d41 })
  br label %bb16
bb15:
  %t44 = load i8, ptr %l5, !tbaa !22
  %t46 = icmp eq i8 %t44, 9
  br i1 %t46, label %bb17, label %bb18
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 2, ptr @.d42 })
  br label %bb19
bb18:
  %t49 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t49)
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s7)
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb3
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb26
bb26:
  %t58 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t58, ptr %l38
  br label %bb27
bb27:
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t59, ptr %l39, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l40, !tbaa !24
  %t62 = load i64, ptr %l40, !tbaa !24
  %t63 = mul i64 %t62, 1
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l41, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = mul i64 %t71, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t68, ptr %t70, i64 %t72, i1 false)
  %t73 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t73, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l6 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l29 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Func", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l20
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load i32, ptr %l20, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l13, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 0
  %t47 = load i32, ptr %t46, !tbaa !33
  store i32 %t47, ptr %l2, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l29
  br label %bb8
bb8:
  %t59 = load i32, ptr %l29
  %t61 = trunc i64 20 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l36
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t74 = load i32, ptr %l36, !tbaa !23
  store i32 %t74, ptr %l2, !tbaa !23
  br label %bb12
bb12:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l41
  br label %bb13
bb13:
  %t85 = load i32, ptr %l41
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb14, label %bb15
bb14:
  store i64 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l48, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l2, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l53
  br label %bb17
bb17:
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t110 = load i32, ptr %l53, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l54
  br label %bb18
bb18:
  %t112 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i64
  %l42 = alloca i32
  %l45 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l10
  br label %bb3
bb3:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %t14, i32 %t15)
  store { i64, ptr } %t18, ptr %l14
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t24, ptr %l17
  br label %bb9
bb9:
  %t25 = load i32, ptr %l17, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l25
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb11
bb11:
  %t52 = load i32, ptr %l3, !tbaa !23
  store i32 %t52, ptr %l31, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l36
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t72, ptr %l41
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l20, !tbaa !29
  %t74 = load i32, ptr %l25, !tbaa !23
  %t75 = load i32, ptr %l30, !tbaa !23
  %t76 = load i32, ptr %l31, !tbaa !23
  %t77 = load i32, ptr %l36, !tbaa !23
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 %t74, i32 %t75, i32 %t76, i32 %t77, i64 %t78)
  store i32 %t79, ptr %l42
  br label %bb14
bb14:
  %t80 = load i32, ptr %l42, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t81, i32 %t80)
  store { i64, ptr } %t85, ptr %l45
  br label %bb15
bb15:
  %t86 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } { i64 27, ptr @.d43 }, 1
  %t90 = extractvalue { i64, ptr } { i64 27, ptr @.d43 }, 0
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = getelementptr i8, ptr %t92, i64 %t88
  call void @olang_textcopy(ptr %t93, ptr %t89, i64 %t90)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2etraitsMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca %"compiler/names:Entry"
  %l89 = alloca i1
  %l93 = alloca %"compiler/names:Entry"
  %l100 = alloca i32
  %l105 = alloca i32
  %l109 = alloca i1
  %l111 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i32
  %l124 = alloca i1
  %l125 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca ptr
  %l139 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l19
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/names:Resolver", ptr %t10, i32 0, i32 1
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_Hb234e65a2b42ee429ada36859295662b(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l24, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l31, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l31, !tbaa !24
  store i64 %t42, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/names:Resolver", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v1, ptr %v1, ptr %t70, i64 %t71)
  store ptr %t74, ptr %l54
  br label %bb13
bb13:
  %t75 = load ptr, ptr %l54, !tbaa !29
  store ptr %t75, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  %t76 = load ptr, ptr %l10, !tbaa !29
  %t78 = getelementptr %"compiler/names:Table", ptr %t76, i32 0, i32 0
  %t80 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %t78)
  store i64 %t80, ptr %l57
  br label %bb14
bb14:
  %t81 = load i64, ptr %l57, !tbaa !24
  store i64 %t81, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t82 = load i64, ptr %l12, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb15, label %bb16
bb15:
  %t88 = load i64, ptr %l13, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb20
bb17:
  %t92 = load i64, ptr %l12, !tbaa !24
  %t93 = load i64, ptr %l11, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l13, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l64, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb19
bb19:
  %t108 = load i64, ptr %l64, !tbaa !24
  store i64 %t108, ptr %l61, !tbaa !24
  br label %bb20
bb20:
  %t109 = load i64, ptr %l61, !tbaa !24
  store i64 %t109, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t110 = load i64, ptr %l15, !tbaa !24
  %t111 = load i64, ptr %l14, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb23:
  br label %bb24
bb24:
  %t118 = load i64, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l15, !tbaa !24
  %t120 = load i64, ptr %l13, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  store i64 %t126, ptr %l16, !tbaa !24
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t130 = getelementptr %"compiler/names:Table", ptr %t128, i32 0, i32 0
  %t131 = load i64, ptr %l16, !tbaa !24
  %t134 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %s4, ptr %t130, i64 %t131)
  store %"compiler/names:Entry" %t134, ptr %l85
  br label %bb25
bb25:
  %t135 = getelementptr %"compiler/names:Entry", ptr %l85, i32 0, i32 2
  %t136 = load i32, ptr %t135
  %t138 = trunc i64 4 to i32
  %t139 = icmp eq i32 %t136, %t138
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb29
bb27:
  %t143 = load ptr, ptr %l10, !tbaa !29
  %t145 = getelementptr %"compiler/names:Table", ptr %t143, i32 0, i32 0
  %t146 = load i64, ptr %l16, !tbaa !24
  %t149 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %v1, ptr %t145, i64 %t146)
  store %"compiler/names:Entry" %t149, ptr %l93
  br label %bb28
bb28:
  %t150 = getelementptr %"compiler/names:Entry", ptr %l93, i32 0, i32 4
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  store i1 %t153, ptr %l89, !tbaa !21
  br label %bb29
bb29:
  %t155 = load i1, ptr %l89, !tbaa !21
  br i1 %t155, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb31:
  br label %bb32
bb32:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i64, ptr %l9, !tbaa !24
  %t161 = load i64, ptr %l16, !tbaa !24
  %t165 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v1, ptr %t159, i64 %t160, i64 %t161)
  store i32 %t165, ptr %l100
  br label %bb33
bb33:
  %t166 = load i32, ptr %l100, !tbaa !23
  store i32 %t166, ptr %l17, !tbaa !23
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l17, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v1, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l105
  br label %bb34
bb34:
  %t177 = load i32, ptr %l105
  %t179 = trunc i64 3 to i32
  %t180 = icmp eq i32 %t177, %t179
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb39
bb36:
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  store ptr %t187, ptr %l111, !tbaa !29
  %t188 = load i32, ptr %l17, !tbaa !23
  %t190 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t188)
  store i64 %t190, ptr %l113
  br label %bb37
bb37:
  %t191 = load ptr, ptr %l111, !tbaa !29
  %t192 = load i64, ptr %l113, !tbaa !24
  %t193 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t191, i64 %t192)
  store i64 %t193, ptr %l114
  br label %bb38
bb38:
  %t194 = load i64, ptr %l114, !tbaa !24
  %t195 = icmp sgt i64 %t194, 0
  store i1 %t195, ptr %l109, !tbaa !21
  br label %bb39
bb39:
  %t197 = load i1, ptr %l109, !tbaa !21
  br i1 %t197, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb41:
  br label %bb42
bb42:
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t202 = load i32, ptr %l17, !tbaa !23
  %t205 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v1, ptr %t201, i32 %t202)
  store i32 %t205, ptr %l119
  br label %bb43
bb43:
  %t206 = load i32, ptr %l119, !tbaa !23
  store i32 %t206, ptr %l18, !tbaa !23
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = load i32, ptr %l18, !tbaa !23
  %t216 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v1, ptr %t210, i32 %a2, i32 %t212)
  store i1 %t216, ptr %l124
  br label %bb44
bb44:
  %t217 = load i1, ptr %l124, !tbaa !21
  br i1 %t217, label %bb45, label %bb46
bb45:
  store ptr %l3, ptr %l125, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t219 = load i32, ptr %l18, !tbaa !23
  %t222 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s0, ptr %t218, i32 %t219)
  store { i64, ptr } %t222, ptr %l128
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t223 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = extractvalue { i64, ptr } %t223, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  %t230 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t230, { i64, ptr } %t229)
  br label %bb48
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb50:
  %t232 = load i64, ptr %l15, !tbaa !24
  %t234 = add i64 %t232, 1
  store i64 %t234, ptr %l15, !tbaa !24
  br label %bb21
bb51:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb52:
  %t236 = load i64, ptr %l8, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l8, !tbaa !24
  br label %bb9
bb53:
  %t241 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l3)
  store i64 %t241, ptr %l135
  br label %bb54
bb54:
  %t242 = load i64, ptr %l135, !tbaa !24
  %t243 = icmp sgt i64 %t242, 0
  br i1 %t243, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %a0, ptr %l137, !tbaa !29
  %t247 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s10, ptr %s10, ptr %l3, { i64, ptr } { i64 2, ptr @.d44 })
  store { i64, ptr } %t247, ptr %l139
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t248 = extractvalue { i64, ptr } { i64 10, ptr @.d45 }, 1
  %t249 = extractvalue { i64, ptr } { i64 10, ptr @.d45 }, 0
  %t250 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t269 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s10, ptr %t269, { i64, ptr } %t268)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 60)
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t9, i32 %a1)
  store { i64, ptr } %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb6:
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  store i32 %t33, ptr %l7, !tbaa !23
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr @.d47 })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb11:
  store ptr %l2, ptr %l27, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l7, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s2, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l30
  br label %bb12
bb12:
  %t45 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t52 = load ptr, ptr %l27, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t52, { i64, ptr } %t51)
  br label %bb13
bb13:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb4
bb15:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 62)
  br label %bb16
bb16:
  %t64 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t64, ptr %l38
  br label %bb17
bb17:
  %t65 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t65, ptr %l39, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l40, !tbaa !24
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l41, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l40, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t79, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t80 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"std/prelude/text:StringBuilder"
  %l50 = alloca i32
  %l54 = alloca i1
  %l59 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l75 = alloca i32
  %l85 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l95 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l117 = alloca i64
  %l123 = alloca ptr
  %l140 = alloca ptr
  %l141 = alloca i1
  %l151 = alloca ptr
  %l154 = alloca { i64, ptr }
  %l160 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l173 = alloca i1
  %l185 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l192 = alloca i64
  %l195 = alloca i64
  %l196 = alloca i64
  %l201 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l209 = alloca i64
  %l210 = alloca { i64, ptr }
  %l219 = alloca ptr
  %l224 = alloca i32
  %l225 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l236 = alloca i64
  %l239 = alloca i64
  %l257 = alloca ptr
  %l259 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l269 = alloca i1
  %l270 = alloca { i64, ptr }
  %l277 = alloca ptr
  %l282 = alloca i1
  %l283 = alloca ptr
  %l284 = alloca ptr
  %l287 = alloca ptr
  %l290 = alloca ptr
  %l295 = alloca i32
  %l296 = alloca i32
  %l297 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l304 = alloca ptr
  %l309 = alloca i32
  %l313 = alloca ptr
  %l318 = alloca { i64, ptr }
  %l319 = alloca i32
  %l320 = alloca { i64, ptr }
  %l321 = alloca ptr
  %l323 = alloca i64
  %l324 = alloca i64
  %l325 = alloca i64
  %l335 = alloca ptr
  %l336 = alloca { i64, ptr }
  %l340 = alloca i1
  %l341 = alloca { i64, ptr }
  %l342 = alloca ptr
  %l347 = alloca i32
  %l348 = alloca { i64, ptr }
  %l354 = alloca ptr
  %l360 = alloca ptr
  %l361 = alloca i1
  %l369 = alloca ptr
  %l370 = alloca ptr
  %l374 = alloca i32
  %l378 = alloca i32
  %l379 = alloca { i64, ptr }
  %l381 = alloca i64
  %l382 = alloca ptr
  %l384 = alloca i64
  %l385 = alloca i64
  %l389 = alloca { i64, ptr }
  %l391 = alloca i64
  %l393 = alloca i64
  %l394 = alloca i64
  %l399 = alloca { i64, ptr }
  %l405 = alloca ptr
  %l406 = alloca ptr
  %l410 = alloca i32
  %l414 = alloca ptr
  %l418 = alloca { i64, ptr }
  %l419 = alloca i32
  %l420 = alloca { i64, ptr }
  %l422 = alloca i64
  %l423 = alloca ptr
  %l424 = alloca { i64, ptr }
  %l426 = alloca i64
  %l427 = alloca i64
  %l431 = alloca { i64, ptr }
  %l433 = alloca i64
  %l435 = alloca i64
  %l436 = alloca i64
  %l441 = alloca { i64, ptr }
  %l447 = alloca ptr
  %l453 = alloca ptr
  %l454 = alloca i1
  %l463 = alloca ptr
  %l464 = alloca ptr
  %l469 = alloca ptr
  %l473 = alloca i64
  %l484 = alloca { i64, ptr }
  %l485 = alloca { i64, ptr }
  %l486 = alloca i64
  %l487 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l46
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l46
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l50
  br label %bb2
bb2:
  %t11 = load i32, ptr %l50, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l54
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l4, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  store ptr %t31, ptr %l59, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l64
  br label %bb4
bb4:
  %t42 = load ptr, ptr %l59, !tbaa !29
  %t43 = load i32, ptr %l64, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l65
  br label %bb5
bb5:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l66, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t48 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t46)
  store i64 %t48, ptr %l68
  br label %bb6
bb6:
  %t49 = load ptr, ptr %l66, !tbaa !29
  %t50 = load i64, ptr %l68, !tbaa !24
  %t51 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t49, i64 %t50, i64 0)
  store { i64, ptr } %t51, ptr %l69
  br label %bb7
bb7:
  %t52 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = add i64 %t54, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t53, i64 %t54)
  %t60 = getelementptr i8, ptr %t59, i64 %t54
  call void @olang_textcopy(ptr %t60, ptr %t56, i64 %t57)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  store { i64, ptr } %t62, ptr %l5, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l75
  br label %bb8
bb8:
  %t74 = load i32, ptr %l75
  store i32 %t74, ptr %l6
  %t75 = load i32, ptr %l6
  %t77 = trunc i64 2 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb23
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = extractvalue { i64, ptr } { i64 6, ptr @.d48 }, 1
  %t82 = extractvalue { i64, ptr } { i64 6, ptr @.d48 }, 0
  %t84 = extractvalue { i64, ptr } %t80, 1
  %t85 = extractvalue { i64, ptr } %t80, 0
  %t86 = add i64 %t82, %t85
  %t87 = extractvalue { i64, ptr } { i64 1, ptr @.d49 }, 1
  %t88 = extractvalue { i64, ptr } { i64 1, ptr @.d49 }, 0
  %t89 = add i64 %t86, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t81, i64 %t82)
  %t91 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t91, ptr %t84, i64 %t85)
  %t92 = getelementptr i8, ptr %t91, i64 %t85
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t90, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = extractvalue { i64, ptr } %t94, 1
  %t98 = mul i64 %t96, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t97, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t101)
  br label %bb12
bb12:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l85
  br label %bb13
bb13:
  %t112 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t112, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t117 = load i64, ptr %l8, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb16:
  br label %bb17
bb17:
  %t125 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t125, ptr %l92, !tbaa !27
  %t126 = load i64, ptr %l8, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i32, ptr %t129, i64 %t126
  %t131 = load i32, ptr %t130, !tbaa !33
  store ptr %l2, ptr %l95, !tbaa !29
  %t133 = load ptr, ptr %l4, !tbaa !29
  %t137 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t133, i32 %t131)
  store { i64, ptr } %t137, ptr %l98
  br label %bb18
bb18:
  %t138 = extractvalue { i64, ptr } { i64 4, ptr @.d50 }, 1
  %t139 = extractvalue { i64, ptr } { i64 4, ptr @.d50 }, 0
  %t140 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = add i64 %t139, %t142
  %t144 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 0
  %t146 = add i64 %t143, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t138, i64 %t139)
  %t148 = getelementptr i8, ptr %t147, i64 %t139
  call void @olang_textcopy(ptr %t148, ptr %t141, i64 %t142)
  %t149 = getelementptr i8, ptr %t148, i64 %t142
  call void @olang_textcopy(ptr %t149, ptr %t144, i64 %t145)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t147, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t159 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t159, { i64, ptr } %t158)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t161 = load i64, ptr %l8, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l8, !tbaa !24
  br label %bb14
bb21:
  %t166 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t166, ptr %l104
  br label %bb22
bb22:
  %t167 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t167, ptr %l105, !tbaa !27
  %t168 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  store i64 %t169, ptr %l106, !tbaa !24
  %t170 = load i64, ptr %l106, !tbaa !24
  %t171 = mul i64 %t170, 1
  %t172 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l107, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = load i64, ptr %l106, !tbaa !24
  %t180 = mul i64 %t179, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t176, ptr %t178, i64 %t180, i1 false)
  %t181 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t181, ptr %l105, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t182 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t182, ptr %rv
  br label %ret
bb23:
  %t183 = load i32, ptr %l6
  %t185 = trunc i64 3 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb88
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = load i32, ptr %l1, !tbaa !23
  %t195 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t191, i32 %t192)
  store ptr %t195, ptr %l113
  br label %bb27
bb27:
  %t196 = load ptr, ptr %l113, !tbaa !29
  store ptr %t196, ptr %l11, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t201 = load i32, ptr %l1, !tbaa !23
  %t204 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t200, i32 %t201)
  store i64 %t204, ptr %l117
  br label %bb28
bb28:
  %t205 = load i64, ptr %l117, !tbaa !24
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 0
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/load:Loader", ptr %t212, i32 0, i32 5
  %t218 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t214, i64 %t205)
  store ptr %t218, ptr %l123
  br label %bb29
bb29:
  %t219 = load ptr, ptr %l123, !tbaa !29
  %t221 = getelementptr %"compiler/load:Module", ptr %t219, i32 0, i32 6
  %t222 = load ptr, ptr %t221, !tbaa !29
  store ptr %t222, ptr %l13, !tbaa !29
  %t224 = load ptr, ptr %l13, !tbaa !29
  %t226 = icmp eq ptr %t224, null
  br i1 %t226, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a)
  unreachable
bb31:
  br label %bb32
bb32:
  %t228 = load ptr, ptr %l13, !tbaa !29
  %t231 = getelementptr %"compiler/source:Source", ptr %t228, i32 0, i32 1
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  store { i64, ptr } %t232, ptr %l14, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t235 = extractvalue { i64, ptr } { i64 5, ptr @.d52 }, 1
  %t236 = extractvalue { i64, ptr } { i64 5, ptr @.d52 }, 0
  %t238 = extractvalue { i64, ptr } %t234, 1
  %t239 = extractvalue { i64, ptr } %t234, 0
  %t240 = add i64 %t236, %t239
  %t241 = extractvalue { i64, ptr } { i64 6, ptr @.d53 }, 1
  %t242 = extractvalue { i64, ptr } { i64 6, ptr @.d53 }, 0
  %t243 = add i64 %t240, %t242
  %t244 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t243)
  call void @olang_textcopy(ptr %t244, ptr %t235, i64 %t236)
  %t245 = getelementptr i8, ptr %t244, i64 %t236
  call void @olang_textcopy(ptr %t245, ptr %t238, i64 %t239)
  %t246 = getelementptr i8, ptr %t245, i64 %t239
  call void @olang_textcopy(ptr %t246, ptr %t241, i64 %t242)
  %t247 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t244, 1
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t251 = extractvalue { i64, ptr } %t248, 1
  %t252 = mul i64 %t250, 1
  %t253 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t252)
  call void @llvm.memcpy.p0.p0.i64(ptr %t253, ptr %t251, i64 %t252, i1 false)
  %t254 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l2, { i64, ptr } %t255)
  br label %bb33
bb33:
  %t258 = load ptr, ptr %l11, !tbaa !29
  %t260 = icmp eq ptr %t258, null
  br i1 %t260, label %bb34, label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_9d3c9a5d5d1efd85_5425f31610037701)
  unreachable
bb35:
  br label %bb36
bb36:
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t265 = getelementptr %"compiler/ast:TypeDecl", ptr %t262, i32 0, i32 3
  %t266 = load ptr, ptr %t265, !tbaa !29
  store ptr %t266, ptr %l15, !tbaa !29
  %t268 = load ptr, ptr %l15, !tbaa !29
  store ptr %t268, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t269 = load ptr, ptr %l140, !tbaa !29
  %t270 = icmp ne ptr %t269, null
  br i1 %t270, label %bb37, label %bb38
bb37:
  %t272 = load ptr, ptr %l140, !tbaa !29
  %t273 = load i64, ptr %t272
  %t275 = icmp eq i64 %t273, 2
  store i1 %t275, ptr %l141, !tbaa !21
  br label %bb38
bb38:
  %t276 = load i1, ptr %l141, !tbaa !21
  br i1 %t276, label %bb39, label %bb40
bb39:
  %t277 = load ptr, ptr %l15, !tbaa !29
  %t279 = getelementptr { i64, [6 x i64] }, ptr %t277, i32 0, i32 1
  %t280 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t279, i32 0, i32 1
  %t281 = load { i64, ptr }, ptr %t280
  store { i64, ptr } %t281, ptr %l16, !tbaa !27
  %t283 = load ptr, ptr %l15, !tbaa !29
  %t285 = getelementptr { i64, [6 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t285, i32 0, i32 2
  %t287 = load { i64, ptr }, ptr %t286
  store { i64, ptr } %t287, ptr %l17, !tbaa !27
  br label %bb41
bb40:
  br label %bb52
bb41:
  %t289 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t293 = icmp sgt i64 %t291, 0
  br i1 %t293, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l2, ptr %l151, !tbaa !29
  %t295 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t296 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t299 = call { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v0, ptr %s11, { i64, ptr } %t295, { i64, ptr } %t296)
  store { i64, ptr } %t299, ptr %l154
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t300 = extractvalue { i64, ptr } { i64 9, ptr @.d54 }, 1
  %t301 = extractvalue { i64, ptr } { i64 9, ptr @.d54 }, 0
  %t302 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t302, 1
  %t304 = extractvalue { i64, ptr } %t302, 0
  %t305 = add i64 %t301, %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t300, i64 %t301)
  %t307 = getelementptr i8, ptr %t306, i64 %t301
  call void @olang_textcopy(ptr %t307, ptr %t303, i64 %t304)
  %t308 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t306, 1
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = extractvalue { i64, ptr } %t309, 1
  %t313 = mul i64 %t311, 1
  %t314 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t313)
  call void @llvm.memcpy.p0.p0.i64(ptr %t314, ptr %t312, i64 %t313, i1 false)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t314, 1
  %t317 = load ptr, ptr %l151, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t317, { i64, ptr } %t316)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s11)
  br label %bb46
bb46:
  %t319 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t323 = icmp sgt i64 %t321, 0
  br i1 %t323, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  store ptr %l2, ptr %l160, !tbaa !29
  %t325 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t326 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t329 = call { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v0, ptr %s13, { i64, ptr } %t325, { i64, ptr } %t326)
  store { i64, ptr } %t329, ptr %l163
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t330 = extractvalue { i64, ptr } { i64 5, ptr @.d55 }, 1
  %t331 = extractvalue { i64, ptr } { i64 5, ptr @.d55 }, 0
  %t332 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 1
  %t334 = extractvalue { i64, ptr } %t332, 0
  %t335 = add i64 %t331, %t334
  %t336 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t335)
  call void @olang_textcopy(ptr %t336, ptr %t330, i64 %t331)
  %t337 = getelementptr i8, ptr %t336, i64 %t331
  call void @olang_textcopy(ptr %t337, ptr %t333, i64 %t334)
  %t338 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t336, 1
  %t341 = extractvalue { i64, ptr } %t339, 0
  %t342 = extractvalue { i64, ptr } %t339, 1
  %t343 = mul i64 %t341, 1
  %t344 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t343)
  call void @llvm.memcpy.p0.p0.i64(ptr %t344, ptr %t342, i64 %t343, i1 false)
  %t345 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t344, 1
  %t347 = load ptr, ptr %l160, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %t347, { i64, ptr } %t346)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s13)
  br label %bb51
bb51:
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_7e9d681ab1b80777_86743e4a68c30163)
  unreachable
bb57:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l2, { i64, ptr } { i64 1, ptr @.d56 })
  br label %bb58
bb58:
  %t350 = load ptr, ptr %l11, !tbaa !29
  %t352 = icmp eq ptr %t350, null
  br i1 %t352, label %bb59, label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_60d3429e949e0f0f_c9b6e73225d64a3b)
  unreachable
bb60:
  br label %bb61
bb61:
  %t354 = load ptr, ptr %l11, !tbaa !29
  %t357 = getelementptr %"compiler/ast:TypeDecl", ptr %t354, i32 0, i32 3
  %t358 = load ptr, ptr %t357, !tbaa !29
  store ptr %t358, ptr %l18, !tbaa !29
  %t360 = load ptr, ptr %l18, !tbaa !29
  store ptr %t360, ptr %l172, !tbaa !29
  store i1 false, ptr %l173, !tbaa !21
  %t361 = load ptr, ptr %l172, !tbaa !29
  %t362 = icmp ne ptr %t361, null
  br i1 %t362, label %bb62, label %bb63
bb62:
  %t364 = load ptr, ptr %l172, !tbaa !29
  %t365 = load i64, ptr %t364
  %t367 = icmp eq i64 %t365, 2
  store i1 %t367, ptr %l173, !tbaa !21
  br label %bb63
bb63:
  %t368 = load i1, ptr %l173, !tbaa !21
  br i1 %t368, label %bb64, label %bb65
bb64:
  %t369 = load ptr, ptr %l18, !tbaa !29
  %t371 = getelementptr { i64, [6 x i64] }, ptr %t369, i32 0, i32 1
  %t372 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t371, i32 0, i32 0
  %t373 = load { i64, ptr }, ptr %t372
  store { i64, ptr } %t373, ptr %l19, !tbaa !27
  br label %bb66
bb65:
  br label %bb81
bb66:
  %t375 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t375, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t377 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t379 = extractvalue { i64, ptr } %t377, 0
  store i64 %t379, ptr %l22, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s18
  %t381 = load i64, ptr %l21, !tbaa !24
  %t382 = load i64, ptr %l22, !tbaa !24
  %t385 = icmp slt i64 %t381, %t382
  %t387 = xor i1 %t385, true
  br i1 %t387, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s18)
  br label %bb80
bb69:
  br label %bb70
bb70:
  %t389 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t389, ptr %l185, !tbaa !27
  %t390 = load i64, ptr %l21, !tbaa !24
  %t392 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr ptr, ptr %t393, i64 %t390
  %t395 = load ptr, ptr %t394, !tbaa !39
  store ptr %t395, ptr %l23, !tbaa !29
  store ptr %l2, ptr %l188, !tbaa !29
  %t397 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t397, ptr %l189, !tbaa !27
  %t398 = load ptr, ptr %l23, !tbaa !29
  %t400 = getelementptr %"compiler/ast:Func", ptr %t398, i32 0, i32 0
  %t401 = getelementptr %"compiler/source:Span", ptr %t400, i32 0, i32 0
  %t402 = load i32, ptr %t401, !tbaa !23
  %t404 = sext i32 %t402 to i64
  store i64 %t404, ptr %l192, !tbaa !24
  %t405 = load ptr, ptr %l23, !tbaa !29
  %t407 = getelementptr %"compiler/ast:Func", ptr %t405, i32 0, i32 0
  %t408 = getelementptr %"compiler/source:Span", ptr %t407, i32 0, i32 1
  %t409 = load i32, ptr %t408, !tbaa !23
  %t411 = sext i32 %t409 to i64
  store i64 %t411, ptr %l195, !tbaa !24
  %t412 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t412, 0
  store i64 %t413, ptr %l196, !tbaa !24
  %t414 = load i64, ptr %l192, !tbaa !24
  %t415 = icmp sge i64 %t414, 0
  br i1 %t415, label %bb71, label %bb72
bb71:
  %t417 = load i64, ptr %l192, !tbaa !24
  %t418 = load i64, ptr %l195, !tbaa !24
  %t419 = icmp sle i64 %t417, %t418
  br i1 %t419, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_750d58cd4bdb6bfa_b2dda4435afc6fae)
  unreachable
bb73:
  %t421 = load i64, ptr %l195, !tbaa !24
  %t422 = load i64, ptr %l196, !tbaa !24
  %t423 = icmp sle i64 %t421, %t422
  br i1 %t423, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_750d58cd4bdb6bfa_b2dda4435afc6fae)
  unreachable
bb75:
  %t425 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !27
  %t427 = load i64, ptr %l192, !tbaa !24
  %t428 = load i64, ptr %l195, !tbaa !24
  %t429 = getelementptr i8, ptr %t426, i64 %t427
  %t430 = sub i64 %t428, %t427
  %t431 = insertvalue { i64, ptr } undef, i64 %t430, 0
  %t432 = insertvalue { i64, ptr } %t431, ptr %t429, 1
  %t434 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t432)
  store { i64, ptr } %t434, ptr %l201
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_750d58cd4bdb6bfa_b2dda4435afc6fae)
  unreachable
bb77:
  %t435 = extractvalue { i64, ptr } { i64 4, ptr @.d57 }, 1
  %t436 = extractvalue { i64, ptr } { i64 4, ptr @.d57 }, 0
  %t437 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t437, 1
  %t439 = extractvalue { i64, ptr } %t437, 0
  %t440 = add i64 %t436, %t439
  %t441 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 1
  %t442 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 0
  %t443 = add i64 %t440, %t442
  %t444 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t443)
  call void @olang_textcopy(ptr %t444, ptr %t435, i64 %t436)
  %t445 = getelementptr i8, ptr %t444, i64 %t436
  call void @olang_textcopy(ptr %t445, ptr %t438, i64 %t439)
  %t446 = getelementptr i8, ptr %t445, i64 %t439
  call void @olang_textcopy(ptr %t446, ptr %t441, i64 %t442)
  %t447 = insertvalue { i64, ptr } undef, i64 %t443, 0
  %t448 = insertvalue { i64, ptr } %t447, ptr %t444, 1
  %t450 = extractvalue { i64, ptr } %t448, 0
  %t451 = extractvalue { i64, ptr } %t448, 1
  %t452 = mul i64 %t450, 1
  %t453 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t452)
  call void @llvm.memcpy.p0.p0.i64(ptr %t453, ptr %t451, i64 %t452, i1 false)
  %t454 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t455 = insertvalue { i64, ptr } %t454, ptr %t453, 1
  %t456 = load ptr, ptr %l188, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %t456, { i64, ptr } %t455)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s18)
  br label %bb79
bb79:
  %t458 = load i64, ptr %l21, !tbaa !24
  %t460 = add i64 %t458, 1
  store i64 %t460, ptr %l21, !tbaa !24
  br label %bb67
bb80:
  br label %bb86
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_9b5b2a94bb1064e0_bfbfac3114847e44)
  unreachable
bb86:
  %t463 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t463, ptr %l207
  br label %bb87
bb87:
  %t464 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t464, ptr %l208, !tbaa !27
  %t465 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 0
  store i64 %t466, ptr %l209, !tbaa !24
  %t467 = load i64, ptr %l209, !tbaa !24
  %t468 = mul i64 %t467, 1
  %t469 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t468)
  %t470 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  store { i64, ptr } %t471, ptr %l210, !tbaa !27
  %t472 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t473 = load ptr, ptr %t472, !tbaa !27
  %t474 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = load i64, ptr %l209, !tbaa !24
  %t477 = mul i64 %t476, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t473, ptr %t475, i64 %t477, i1 false)
  %t478 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t478, ptr %l208, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t479 = load { i64, ptr }, ptr %l208, !tbaa !27
  store { i64, ptr } %t479, ptr %rv
  br label %ret
bb88:
  %t480 = load i32, ptr %l6
  %t482 = trunc i64 1 to i32
  %t483 = icmp eq i32 %t480, %t482
  br i1 %t483, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb146
bb91:
  store %olang.scope zeroinitializer, ptr %s22
  %t485 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t486 = extractvalue { i64, ptr } { i64 5, ptr @.d59 }, 1
  %t487 = extractvalue { i64, ptr } { i64 5, ptr @.d59 }, 0
  %t489 = extractvalue { i64, ptr } %t485, 1
  %t490 = extractvalue { i64, ptr } %t485, 0
  %t491 = add i64 %t487, %t490
  %t492 = extractvalue { i64, ptr } { i64 6, ptr @.d60 }, 1
  %t493 = extractvalue { i64, ptr } { i64 6, ptr @.d60 }, 0
  %t494 = add i64 %t491, %t493
  %t495 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t494)
  call void @olang_textcopy(ptr %t495, ptr %t486, i64 %t487)
  %t496 = getelementptr i8, ptr %t495, i64 %t487
  call void @olang_textcopy(ptr %t496, ptr %t489, i64 %t490)
  %t497 = getelementptr i8, ptr %t496, i64 %t490
  call void @olang_textcopy(ptr %t497, ptr %t492, i64 %t493)
  %t498 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr %t495, 1
  %t501 = extractvalue { i64, ptr } %t499, 0
  %t502 = extractvalue { i64, ptr } %t499, 1
  %t503 = mul i64 %t501, 1
  %t504 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t503)
  call void @llvm.memcpy.p0.p0.i64(ptr %t504, ptr %t502, i64 %t503, i1 false)
  %t505 = insertvalue { i64, ptr } undef, i64 %t501, 0
  %t506 = insertvalue { i64, ptr } %t505, ptr %t504, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %l2, { i64, ptr } %t506)
  br label %bb92
bb92:
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t511 = getelementptr %"compiler/check:Checker", ptr %t509, i32 0, i32 1
  %t512 = load ptr, ptr %t511, !tbaa !29
  %t514 = getelementptr %"compiler/generic:Program", ptr %t512, i32 0, i32 2
  store ptr %t514, ptr %l219, !tbaa !29
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t517 = getelementptr %"compiler/check:Checker", ptr %t515, i32 0, i32 1
  %t518 = load ptr, ptr %t517, !tbaa !29
  %t520 = getelementptr %"compiler/generic:Program", ptr %t518, i32 0, i32 2
  %t521 = load i32, ptr %l3, !tbaa !23
  %t524 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t520, i32 %t521)
  store i32 %t524, ptr %l224
  br label %bb93
bb93:
  %t525 = load ptr, ptr %l219, !tbaa !29
  %t526 = load i32, ptr %l224, !tbaa !23
  %t527 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t525, i32 %t526)
  store { i64, ptr } %t527, ptr %l225
  br label %bb94
bb94:
  %t528 = load { i64, ptr }, ptr %l225, !tbaa !27
  store { i64, ptr } %t528, ptr %l24, !tbaa !27
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = getelementptr %"compiler/check:Checker", ptr %t529, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !29
  %t534 = getelementptr %"compiler/generic:Program", ptr %t532, i32 0, i32 2
  %t535 = load i32, ptr %l3, !tbaa !23
  %t538 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t534, i32 %t535)
  store { i64, ptr } %t538, ptr %l230
  br label %bb95
bb95:
  %t539 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t539, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t540, 0
  store i64 %t542, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t544 = load i64, ptr %l27, !tbaa !24
  %t545 = load i64, ptr %l26, !tbaa !24
  %t548 = icmp sgt i64 %t544, %t545
  br i1 %t548, label %bb96, label %bb97
bb96:
  %t550 = load i64, ptr %l28, !tbaa !24
  %t552 = icmp sgt i64 %t550, 0
  br i1 %t552, label %bb98, label %bb99
bb97:
  store i64 0, ptr %l236, !tbaa !24
  br label %bb101
bb98:
  %t554 = load i64, ptr %l27, !tbaa !24
  %t555 = load i64, ptr %l26, !tbaa !24
  %t558 = sub i64 %t554, %t555
  %t559 = load i64, ptr %l28, !tbaa !24
  %t562 = add i64 %t558, %t559
  %t564 = sub i64 %t562, 1
  %t565 = load i64, ptr %l28, !tbaa !24
  %t568 = sdiv i64 %t564, %t565
  store i64 %t568, ptr %l239, !tbaa !24
  br label %bb100
bb99:
  store i64 0, ptr %l239, !tbaa !24
  br label %bb100
bb100:
  %t570 = load i64, ptr %l239, !tbaa !24
  store i64 %t570, ptr %l236, !tbaa !24
  br label %bb101
bb101:
  %t571 = load i64, ptr %l236, !tbaa !24
  store i64 %t571, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb102
bb102:
  store %olang.scope zeroinitializer, ptr %s25
  %t572 = load i64, ptr %l30, !tbaa !24
  %t573 = load i64, ptr %l29, !tbaa !24
  %t576 = icmp slt i64 %t572, %t573
  %t578 = xor i1 %t576, true
  br i1 %t578, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s25)
  br label %bb145
bb104:
  br label %bb105
bb105:
  %t580 = load i64, ptr %l26, !tbaa !24
  %t581 = load i64, ptr %l30, !tbaa !24
  %t582 = load i64, ptr %l28, !tbaa !24
  %t585 = mul i64 %t581, %t582
  %t588 = add i64 %t580, %t585
  store i64 %t588, ptr %l31, !tbaa !24
  store ptr %l2, ptr %l257, !tbaa !29
  %t590 = load ptr, ptr %l4, !tbaa !29
  %t591 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t591, ptr %l259, !tbaa !27
  %t592 = load i64, ptr %l31, !tbaa !24
  %t594 = getelementptr { i64, ptr }, ptr %l259, i32 0, i32 1
  %t595 = load ptr, ptr %t594, !tbaa !27
  %t596 = getelementptr i32, ptr %t595, i64 %t592
  %t597 = load i32, ptr %t596, !tbaa !33
  %t600 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t590, i32 %t597)
  store { i64, ptr } %t600, ptr %l262
  br label %bb106
bb106:
  %t601 = extractvalue { i64, ptr } { i64 4, ptr @.d61 }, 1
  %t602 = extractvalue { i64, ptr } { i64 4, ptr @.d61 }, 0
  %t603 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t604 = extractvalue { i64, ptr } %t603, 1
  %t605 = extractvalue { i64, ptr } %t603, 0
  %t606 = add i64 %t602, %t605
  %t607 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t606)
  call void @olang_textcopy(ptr %t607, ptr %t601, i64 %t602)
  %t608 = getelementptr i8, ptr %t607, i64 %t602
  call void @olang_textcopy(ptr %t608, ptr %t604, i64 %t605)
  %t609 = insertvalue { i64, ptr } undef, i64 %t606, 0
  %t610 = insertvalue { i64, ptr } %t609, ptr %t607, 1
  %t612 = extractvalue { i64, ptr } %t610, 0
  %t613 = extractvalue { i64, ptr } %t610, 1
  %t614 = mul i64 %t612, 1
  %t615 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t614)
  call void @llvm.memcpy.p0.p0.i64(ptr %t615, ptr %t613, i64 %t614, i1 false)
  %t616 = insertvalue { i64, ptr } undef, i64 %t612, 0
  %t617 = insertvalue { i64, ptr } %t616, ptr %t615, 1
  %t618 = load ptr, ptr %l257, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s25, ptr %t618, { i64, ptr } %t617)
  br label %bb107
bb107:
  %t620 = load i64, ptr %l31, !tbaa !24
  %t621 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t623 = extractvalue { i64, ptr } %t621, 0
  %t626 = icmp slt i64 %t620, %t623
  br i1 %t626, label %bb108, label %bb109
bb108:
  %t628 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t628, ptr %l270, !tbaa !27
  %t629 = load i64, ptr %l31, !tbaa !24
  %t631 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t632 = load ptr, ptr %t631, !tbaa !27
  %t633 = getelementptr i32, ptr %t632, i64 %t629
  %t634 = load i32, ptr %t633, !tbaa !33
  %t636 = icmp ne i32 %t634, 0
  store i1 %t636, ptr %l269, !tbaa !21
  br label %bb110
bb109:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb110
bb110:
  %t638 = load i1, ptr %l269, !tbaa !21
  br i1 %t638, label %bb111, label %bb112
bb111:
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t641 = getelementptr %"compiler/check:Checker", ptr %t639, i32 0, i32 1
  %t642 = load ptr, ptr %t641, !tbaa !29
  %t643 = load i32, ptr %l1, !tbaa !23
  %t646 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t642, i32 %t643)
  store ptr %t646, ptr %l277
  br label %bb113
bb112:
  br label %bb142
bb113:
  %t647 = load ptr, ptr %l277, !tbaa !29
  store ptr %t647, ptr %l32, !tbaa !29
  %t648 = load ptr, ptr %l32, !tbaa !29
  %t650 = icmp eq ptr %t648, null
  br i1 %t650, label %bb114, label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_b92ab423e11bfbb4_4adf8d895fd79148)
  unreachable
bb115:
  br label %bb116
bb116:
  %t652 = load ptr, ptr %l32, !tbaa !29
  %t653 = load i64, ptr %l31, !tbaa !24
  %t656 = call i1 @compiler_2fexplain_2ecaseWhole(ptr %v0, ptr %t652, i64 %t653)
  store i1 %t656, ptr %l282
  br label %bb117
bb117:
  %t657 = load i1, ptr %l282, !tbaa !21
  br i1 %t657, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s28
  store ptr %l2, ptr %l283, !tbaa !29
  %t658 = load ptr, ptr %l0, !tbaa !29
  store ptr %t658, ptr %l284, !tbaa !29
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t661 = getelementptr %"compiler/check:Checker", ptr %t659, i32 0, i32 1
  %t662 = load ptr, ptr %t661, !tbaa !29
  %t664 = getelementptr %"compiler/generic:Program", ptr %t662, i32 0, i32 2
  store ptr %t664, ptr %l287, !tbaa !29
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t667 = getelementptr %"compiler/check:Checker", ptr %t665, i32 0, i32 1
  %t668 = load ptr, ptr %t667, !tbaa !29
  %t670 = getelementptr %"compiler/generic:Program", ptr %t668, i32 0, i32 2
  store ptr %t670, ptr %l290, !tbaa !29
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t673 = getelementptr %"compiler/check:Checker", ptr %t671, i32 0, i32 1
  %t674 = load ptr, ptr %t673, !tbaa !29
  %t675 = load i32, ptr %l3, !tbaa !23
  %t676 = load i64, ptr %l31, !tbaa !24
  %t680 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t674, i32 %t675, i64 %t676)
  store i32 %t680, ptr %l295
  br label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s30
  %t681 = load ptr, ptr %l0, !tbaa !29
  store ptr %t681, ptr %l303, !tbaa !29
  %t682 = load ptr, ptr %l0, !tbaa !29
  store ptr %t682, ptr %l304, !tbaa !29
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t685 = getelementptr %"compiler/check:Checker", ptr %t683, i32 0, i32 1
  %t686 = load ptr, ptr %t685, !tbaa !29
  %t687 = load i32, ptr %l3, !tbaa !23
  %t688 = load i64, ptr %l31, !tbaa !24
  %t692 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t686, i32 %t687, i64 %t688)
  store i32 %t692, ptr %l309
  br label %bb125
bb120:
  %t693 = load ptr, ptr %l290, !tbaa !29
  %t694 = load i32, ptr %l295, !tbaa !23
  %t695 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t693, i32 %t694)
  store i32 %t695, ptr %l296
  br label %bb121
bb121:
  %t696 = load ptr, ptr %l287, !tbaa !29
  %t697 = load i32, ptr %l296, !tbaa !23
  %t698 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t696, i32 %t697)
  store { i64, ptr } %t698, ptr %l297
  br label %bb122
bb122:
  %t699 = load { i64, ptr }, ptr %l297, !tbaa !27
  store { i64, ptr } %t699, ptr %l298, !tbaa !27
  %t700 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t701 = load ptr, ptr %t700, !tbaa !27
  %t702 = getelementptr i32, ptr %t701, i64 0
  %t703 = load i32, ptr %t702, !tbaa !33
  %t704 = load ptr, ptr %l284, !tbaa !29
  %t706 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s28, ptr %t704, i32 %t703)
  store { i64, ptr } %t706, ptr %l300
  br label %bb123
bb123:
  %t707 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 1
  %t708 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 0
  %t709 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t710 = extractvalue { i64, ptr } %t709, 1
  %t711 = extractvalue { i64, ptr } %t709, 0
  %t712 = add i64 %t708, %t711
  %t713 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t712)
  call void @olang_textcopy(ptr %t713, ptr %t707, i64 %t708)
  %t714 = getelementptr i8, ptr %t713, i64 %t708
  call void @olang_textcopy(ptr %t714, ptr %t710, i64 %t711)
  %t715 = insertvalue { i64, ptr } undef, i64 %t712, 0
  %t716 = insertvalue { i64, ptr } %t715, ptr %t713, 1
  %t718 = extractvalue { i64, ptr } %t716, 0
  %t719 = extractvalue { i64, ptr } %t716, 1
  %t720 = mul i64 %t718, 1
  %t721 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t720)
  call void @llvm.memcpy.p0.p0.i64(ptr %t721, ptr %t719, i64 %t720, i1 false)
  %t722 = insertvalue { i64, ptr } undef, i64 %t718, 0
  %t723 = insertvalue { i64, ptr } %t722, ptr %t721, 1
  %t724 = load ptr, ptr %l283, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s28, ptr %t724, { i64, ptr } %t723)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s28)
  br label %bb141
bb125:
  %t726 = load ptr, ptr %l0, !tbaa !29
  %t728 = getelementptr %"compiler/check:Checker", ptr %t726, i32 0, i32 1
  %t729 = load ptr, ptr %t728, !tbaa !29
  %t730 = load i32, ptr %l1, !tbaa !23
  %t733 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t729, i32 %t730)
  store ptr %t733, ptr %l313
  br label %bb126
bb126:
  %t734 = load ptr, ptr %l313, !tbaa !29
  store ptr %t734, ptr %l33, !tbaa !29
  %t735 = load ptr, ptr %l33, !tbaa !29
  %t737 = icmp eq ptr %t735, null
  br i1 %t737, label %bb127, label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_ec478a9a38770143_a832df5ab537b567)
  unreachable
bb128:
  br label %bb129
bb129:
  %t739 = load ptr, ptr %l33, !tbaa !29
  %t740 = load i64, ptr %l31, !tbaa !24
  %t743 = call { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v0, ptr %t739, i64 %t740)
  store { i64, ptr } %t743, ptr %l318
  br label %bb130
bb130:
  %t744 = load ptr, ptr %l304, !tbaa !29
  %t745 = load i32, ptr %l309, !tbaa !23
  %t746 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t747 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s30, ptr %v0, ptr %t744, i32 %t745, ptr null, { i64, ptr } %t746)
  store i32 %t747, ptr %l319
  br label %bb131
bb131:
  %t748 = load ptr, ptr %l303, !tbaa !29
  %t749 = load i32, ptr %l319, !tbaa !23
  %t750 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s30, ptr %t748, i32 %t749)
  store { i64, ptr } %t750, ptr %l320
  br label %bb132
bb132:
  %t751 = load { i64, ptr }, ptr %l320, !tbaa !27
  store { i64, ptr } %t751, ptr %l34, !tbaa !27
  store ptr %l2, ptr %l321, !tbaa !29
  %t752 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t754 = call i64 @compiler_2fexplain_2efirstClose(ptr %s30, { i64, ptr } %t752)
  store i64 %t754, ptr %l323
  br label %bb133
bb133:
  %t755 = load i64, ptr %l323, !tbaa !24
  %t756 = add i64 %t755, 1
  store i64 %t756, ptr %l324, !tbaa !24
  %t757 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t758 = extractvalue { i64, ptr } %t757, 0
  store i64 %t758, ptr %l325, !tbaa !24
  %t759 = icmp sge i64 2, 0
  br i1 %t759, label %bb134, label %bb135
bb134:
  %t761 = load i64, ptr %l324, !tbaa !24
  %t762 = icmp sle i64 2, %t761
  br i1 %t762, label %bb136, label %bb137
bb135:
  call void @__olang_check_failed(ptr @olang_loc_9c563feafedd44ce_b85d3928399923da)
  unreachable
bb136:
  %t764 = load i64, ptr %l324, !tbaa !24
  %t765 = load i64, ptr %l325, !tbaa !24
  %t766 = icmp sle i64 %t764, %t765
  br i1 %t766, label %bb138, label %bb139
bb137:
  call void @__olang_check_failed(ptr @olang_loc_9c563feafedd44ce_b85d3928399923da)
  unreachable
bb138:
  %t768 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t769 = load ptr, ptr %t768, !tbaa !27
  %t770 = load i64, ptr %l324, !tbaa !24
  %t771 = getelementptr i8, ptr %t769, i64 2
  %t772 = sub i64 %t770, 2
  %t773 = insertvalue { i64, ptr } undef, i64 %t772, 0
  %t774 = insertvalue { i64, ptr } %t773, ptr %t771, 1
  %t775 = load ptr, ptr %l321, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s30, ptr %t775, { i64, ptr } %t774)
  br label %bb140
bb139:
  call void @__olang_check_failed(ptr @olang_loc_9c563feafedd44ce_b85d3928399923da)
  unreachable
bb140:
  call void @__olang_scope_close(ptr %s30)
  br label %bb141
bb141:
  br label %bb142
bb142:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s25)
  br label %bb144
bb144:
  %t778 = load i64, ptr %l30, !tbaa !24
  %t780 = add i64 %t778, 1
  store i64 %t780, ptr %l30, !tbaa !24
  br label %bb102
bb145:
  call void @__olang_scope_close(ptr %s22)
  br label %bb246
bb146:
  %t782 = load i32, ptr %l6
  %t784 = trunc i64 4 to i32
  %t785 = icmp eq i32 %t782, %t784
  br i1 %t785, label %bb147, label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb194
bb149:
  store %olang.scope zeroinitializer, ptr %s32
  store ptr %l2, ptr %l335, !tbaa !29
  %t787 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t787, ptr %l336, !tbaa !27
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t790 = getelementptr %"compiler/check:Checker", ptr %t788, i32 0, i32 1
  %t791 = load ptr, ptr %t790, !tbaa !29
  %t792 = load i32, ptr %l3, !tbaa !23
  %t795 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t791, i32 %t792)
  store i1 %t795, ptr %l340
  br label %bb150
bb150:
  %t796 = load i1, ptr %l340, !tbaa !21
  br i1 %t796, label %bb151, label %bb152
bb151:
  store { i64, ptr } { i64 9, ptr @.d63 }, ptr %l341, !tbaa !27
  br label %bb153
bb152:
  store { i64, ptr } { i64 1, ptr @.d64 }, ptr %l341, !tbaa !27
  br label %bb153
bb153:
  %t797 = load ptr, ptr %l0, !tbaa !29
  store ptr %t797, ptr %l342, !tbaa !29
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t800 = getelementptr %"compiler/check:Checker", ptr %t798, i32 0, i32 1
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t803 = getelementptr %"compiler/generic:Program", ptr %t801, i32 0, i32 2
  %t804 = load i32, ptr %l3, !tbaa !23
  %t807 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t803, i32 %t804)
  store i32 %t807, ptr %l347
  br label %bb154
bb154:
  %t808 = load ptr, ptr %l342, !tbaa !29
  %t809 = load i32, ptr %l347, !tbaa !23
  %t810 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s32, ptr %t808, i32 %t809)
  store { i64, ptr } %t810, ptr %l348
  br label %bb155
bb155:
  %t811 = extractvalue { i64, ptr } { i64 5, ptr @.d65 }, 1
  %t812 = extractvalue { i64, ptr } { i64 5, ptr @.d65 }, 0
  %t813 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t814 = extractvalue { i64, ptr } %t813, 1
  %t815 = extractvalue { i64, ptr } %t813, 0
  %t816 = add i64 %t812, %t815
  %t817 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t818 = extractvalue { i64, ptr } %t817, 1
  %t819 = extractvalue { i64, ptr } %t817, 0
  %t820 = add i64 %t816, %t819
  %t821 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t822 = extractvalue { i64, ptr } %t821, 1
  %t823 = extractvalue { i64, ptr } %t821, 0
  %t824 = add i64 %t820, %t823
  %t825 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t824)
  call void @olang_textcopy(ptr %t825, ptr %t811, i64 %t812)
  %t826 = getelementptr i8, ptr %t825, i64 %t812
  call void @olang_textcopy(ptr %t826, ptr %t814, i64 %t815)
  %t827 = getelementptr i8, ptr %t826, i64 %t815
  call void @olang_textcopy(ptr %t827, ptr %t818, i64 %t819)
  %t828 = getelementptr i8, ptr %t827, i64 %t819
  call void @olang_textcopy(ptr %t828, ptr %t822, i64 %t823)
  %t829 = insertvalue { i64, ptr } undef, i64 %t824, 0
  %t830 = insertvalue { i64, ptr } %t829, ptr %t825, 1
  %t832 = extractvalue { i64, ptr } %t830, 0
  %t833 = extractvalue { i64, ptr } %t830, 1
  %t834 = mul i64 %t832, 1
  %t835 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t834)
  call void @llvm.memcpy.p0.p0.i64(ptr %t835, ptr %t833, i64 %t834, i1 false)
  %t836 = insertvalue { i64, ptr } undef, i64 %t832, 0
  %t837 = insertvalue { i64, ptr } %t836, ptr %t835, 1
  %t838 = load ptr, ptr %l335, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s32, ptr %t838, { i64, ptr } %t837)
  br label %bb156
bb156:
  %t840 = load ptr, ptr %l0, !tbaa !29
  %t842 = getelementptr %"compiler/check:Checker", ptr %t840, i32 0, i32 1
  %t843 = load ptr, ptr %t842, !tbaa !29
  %t844 = load i32, ptr %l1, !tbaa !23
  %t847 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t843, i32 %t844)
  store ptr %t847, ptr %l354
  br label %bb157
bb157:
  %t848 = load ptr, ptr %l354, !tbaa !29
  store ptr %t848, ptr %l35, !tbaa !29
  %t849 = load ptr, ptr %l35, !tbaa !29
  %t851 = icmp eq ptr %t849, null
  br i1 %t851, label %bb158, label %bb159
bb158:
  call void @__olang_check_failed(ptr @olang_loc_4a756130778b14bd_8f8d371a853a3189)
  unreachable
bb159:
  br label %bb160
bb160:
  %t853 = load ptr, ptr %l35, !tbaa !29
  %t856 = getelementptr %"compiler/ast:TypeDecl", ptr %t853, i32 0, i32 3
  %t857 = load ptr, ptr %t856, !tbaa !29
  store ptr %t857, ptr %l36, !tbaa !29
  %t859 = load ptr, ptr %l36, !tbaa !29
  store ptr %t859, ptr %l360, !tbaa !29
  store i1 false, ptr %l361, !tbaa !21
  %t860 = load ptr, ptr %l360, !tbaa !29
  %t861 = icmp ne ptr %t860, null
  br i1 %t861, label %bb161, label %bb162
bb161:
  %t863 = load ptr, ptr %l360, !tbaa !29
  %t864 = load i64, ptr %t863
  %t866 = icmp eq i64 %t864, 3
  store i1 %t866, ptr %l361, !tbaa !21
  br label %bb162
bb162:
  %t867 = load i1, ptr %l361, !tbaa !21
  br i1 %t867, label %bb163, label %bb164
bb163:
  %t868 = load ptr, ptr %l36, !tbaa !29
  %t870 = getelementptr { i64, [6 x i64] }, ptr %t868, i32 0, i32 1
  %t871 = getelementptr { ptr, ptr }, ptr %t870, i32 0, i32 1
  %t872 = load ptr, ptr %t871
  store ptr %t872, ptr %l37, !tbaa !29
  br label %bb165
bb164:
  br label %bb187
bb165:
  %t874 = load ptr, ptr %l37, !tbaa !29
  %t876 = icmp eq ptr %t874, null
  %t878 = xor i1 %t876, true
  br i1 %t878, label %bb166, label %bb167
bb166:
  store %olang.scope zeroinitializer, ptr %s35
  %t880 = load ptr, ptr %l0, !tbaa !29
  store ptr %t880, ptr %l369, !tbaa !29
  %t881 = load ptr, ptr %l0, !tbaa !29
  store ptr %t881, ptr %l370, !tbaa !29
  %t882 = load ptr, ptr %l0, !tbaa !29
  %t884 = getelementptr %"compiler/check:Checker", ptr %t882, i32 0, i32 1
  %t885 = load ptr, ptr %t884, !tbaa !29
  %t886 = load i32, ptr %l3, !tbaa !23
  %t889 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t885, i32 %t886)
  store i32 %t889, ptr %l374
  br label %bb168
bb167:
  br label %bb186
bb168:
  %t890 = load ptr, ptr %l37, !tbaa !29
  %t892 = getelementptr %"compiler/ast:Func", ptr %t890, i32 0, i32 3
  %t893 = load ptr, ptr %t892, !tbaa !29
  %t895 = getelementptr %"compiler/ast:Sig", ptr %t893, i32 0, i32 0
  %t896 = load { i64, ptr }, ptr %t895, !tbaa !27
  %t897 = load ptr, ptr %l370, !tbaa !29
  %t898 = load i32, ptr %l374, !tbaa !23
  %t900 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s35, ptr %v0, ptr %t897, i32 %t898, ptr null, { i64, ptr } %t896)
  store i32 %t900, ptr %l378
  br label %bb169
bb169:
  %t901 = load ptr, ptr %l369, !tbaa !29
  %t902 = load i32, ptr %l378, !tbaa !23
  %t903 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s35, ptr %t901, i32 %t902)
  store { i64, ptr } %t903, ptr %l379
  br label %bb170
bb170:
  %t904 = load { i64, ptr }, ptr %l379, !tbaa !27
  store { i64, ptr } %t904, ptr %l38, !tbaa !27
  %t905 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t907 = call i64 @compiler_2fexplain_2efirstClose(ptr %s35, { i64, ptr } %t905)
  store i64 %t907, ptr %l381
  br label %bb171
bb171:
  %t908 = load i64, ptr %l381, !tbaa !24
  store i64 %t908, ptr %l39, !tbaa !24
  store ptr %l2, ptr %l382, !tbaa !29
  %t909 = load i64, ptr %l39, !tbaa !24
  %t911 = add i64 %t909, 1
  store i64 %t911, ptr %l384, !tbaa !24
  %t912 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t913 = extractvalue { i64, ptr } %t912, 0
  store i64 %t913, ptr %l385, !tbaa !24
  %t914 = icmp sge i64 2, 0
  br i1 %t914, label %bb172, label %bb173
bb172:
  %t916 = load i64, ptr %l384, !tbaa !24
  %t917 = icmp sle i64 2, %t916
  br i1 %t917, label %bb174, label %bb175
bb173:
  call void @__olang_check_failed(ptr @olang_loc_b6c637a5f4084e9b_d531d6adfcd75e3f)
  unreachable
bb174:
  %t919 = load i64, ptr %l384, !tbaa !24
  %t920 = load i64, ptr %l385, !tbaa !24
  %t921 = icmp sle i64 %t919, %t920
  br i1 %t921, label %bb176, label %bb177
bb175:
  call void @__olang_check_failed(ptr @olang_loc_b6c637a5f4084e9b_d531d6adfcd75e3f)
  unreachable
bb176:
  %t923 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t924 = load ptr, ptr %t923, !tbaa !27
  %t925 = load i64, ptr %l384, !tbaa !24
  %t926 = getelementptr i8, ptr %t924, i64 2
  %t927 = sub i64 %t925, 2
  %t928 = insertvalue { i64, ptr } undef, i64 %t927, 0
  %t929 = insertvalue { i64, ptr } %t928, ptr %t926, 1
  store { i64, ptr } %t929, ptr %l389, !tbaa !27
  %t930 = load i64, ptr %l39, !tbaa !24
  %t932 = add i64 %t930, 1
  store i64 %t932, ptr %l391, !tbaa !24
  %t933 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t935 = extractvalue { i64, ptr } %t933, 0
  store i64 %t935, ptr %l393, !tbaa !24
  %t936 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t937 = extractvalue { i64, ptr } %t936, 0
  store i64 %t937, ptr %l394, !tbaa !24
  %t938 = load i64, ptr %l391, !tbaa !24
  %t939 = icmp sge i64 %t938, 0
  br i1 %t939, label %bb178, label %bb179
bb177:
  call void @__olang_check_failed(ptr @olang_loc_b6c637a5f4084e9b_d531d6adfcd75e3f)
  unreachable
bb178:
  %t941 = load i64, ptr %l391, !tbaa !24
  %t942 = load i64, ptr %l393, !tbaa !24
  %t943 = icmp sle i64 %t941, %t942
  br i1 %t943, label %bb180, label %bb181
bb179:
  call void @__olang_check_failed(ptr @olang_loc_b6c637a5f4084e9b_d531d6adfcd75e3f)
  unreachable
bb180:
  %t945 = load i64, ptr %l393, !tbaa !24
  %t946 = load i64, ptr %l394, !tbaa !24
  %t947 = icmp sle i64 %t945, %t946
  br i1 %t947, label %bb182, label %bb183
bb181:
  call void @__olang_check_failed(ptr @olang_loc_b6c637a5f4084e9b_d531d6adfcd75e3f)
  unreachable
bb182:
  %t949 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t950 = load ptr, ptr %t949, !tbaa !27
  %t951 = load i64, ptr %l391, !tbaa !24
  %t952 = load i64, ptr %l393, !tbaa !24
  %t953 = getelementptr i8, ptr %t950, i64 %t951
  %t954 = sub i64 %t952, %t951
  %t955 = insertvalue { i64, ptr } undef, i64 %t954, 0
  %t956 = insertvalue { i64, ptr } %t955, ptr %t953, 1
  %t958 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s35, ptr %s35, { i64, ptr } %t956)
  store { i64, ptr } %t958, ptr %l399
  br label %bb184
bb183:
  call void @__olang_check_failed(ptr @olang_loc_b6c637a5f4084e9b_d531d6adfcd75e3f)
  unreachable
bb184:
  %t959 = load { i64, ptr }, ptr %l389, !tbaa !27
  %t960 = extractvalue { i64, ptr } %t959, 1
  %t961 = extractvalue { i64, ptr } %t959, 0
  %t962 = load { i64, ptr }, ptr %l399, !tbaa !27
  %t963 = extractvalue { i64, ptr } %t962, 1
  %t964 = extractvalue { i64, ptr } %t962, 0
  %t965 = add i64 %t961, %t964
  %t966 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t965)
  call void @olang_textcopy(ptr %t966, ptr %t960, i64 %t961)
  %t967 = getelementptr i8, ptr %t966, i64 %t961
  call void @olang_textcopy(ptr %t967, ptr %t963, i64 %t964)
  %t968 = insertvalue { i64, ptr } undef, i64 %t965, 0
  %t969 = insertvalue { i64, ptr } %t968, ptr %t966, 1
  %t971 = extractvalue { i64, ptr } %t969, 0
  %t972 = extractvalue { i64, ptr } %t969, 1
  %t973 = mul i64 %t971, 1
  %t974 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t973)
  call void @llvm.memcpy.p0.p0.i64(ptr %t974, ptr %t972, i64 %t973, i1 false)
  %t975 = insertvalue { i64, ptr } undef, i64 %t971, 0
  %t976 = insertvalue { i64, ptr } %t975, ptr %t974, 1
  %t977 = load ptr, ptr %l382, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s35, ptr %t977, { i64, ptr } %t976)
  br label %bb185
bb185:
  call void @__olang_scope_close(ptr %s35)
  br label %bb186
bb186:
  br label %bb192
bb187:
  br i1 true, label %bb188, label %bb189
bb188:
  br label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb192
bb191:
  call void @__olang_check_failed(ptr @olang_loc_93210599a953f045_f6edd12d3f8198a9)
  unreachable
bb192:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb193
bb193:
  call void @__olang_scope_close(ptr %s32)
  br label %bb246
bb194:
  %t980 = load i32, ptr %l6
  %t982 = trunc i64 0 to i32
  %t983 = icmp eq i32 %t980, %t982
  br i1 %t983, label %bb195, label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb245
bb197:
  store %olang.scope zeroinitializer, ptr %s38
  %t985 = load ptr, ptr %l0, !tbaa !29
  store ptr %t985, ptr %l405, !tbaa !29
  %t986 = load ptr, ptr %l0, !tbaa !29
  store ptr %t986, ptr %l406, !tbaa !29
  %t987 = load ptr, ptr %l0, !tbaa !29
  %t989 = getelementptr %"compiler/check:Checker", ptr %t987, i32 0, i32 1
  %t990 = load ptr, ptr %t989, !tbaa !29
  %t991 = load i32, ptr %l3, !tbaa !23
  %t994 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t990, i32 %t991)
  store i32 %t994, ptr %l410
  br label %bb198
bb198:
  %t995 = load ptr, ptr %l0, !tbaa !29
  %t997 = getelementptr %"compiler/check:Checker", ptr %t995, i32 0, i32 1
  %t998 = load ptr, ptr %t997, !tbaa !29
  %t999 = load i32, ptr %l1, !tbaa !23
  %t1002 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t998, i32 %t999)
  store ptr %t1002, ptr %l414
  br label %bb199
bb199:
  %t1003 = load ptr, ptr %l414, !tbaa !29
  store ptr %t1003, ptr %l40, !tbaa !29
  %t1004 = load ptr, ptr %l40, !tbaa !29
  %t1006 = icmp eq ptr %t1004, null
  br i1 %t1006, label %bb200, label %bb201
bb200:
  call void @__olang_check_failed(ptr @olang_loc_19c36e0ba461fdf7_41869d9fd7da314b)
  unreachable
bb201:
  br label %bb202
bb202:
  %t1008 = load ptr, ptr %l40, !tbaa !29
  %t1010 = call { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %t1008)
  store { i64, ptr } %t1010, ptr %l418
  br label %bb203
bb203:
  %t1011 = load ptr, ptr %l406, !tbaa !29
  %t1012 = load i32, ptr %l410, !tbaa !23
  %t1013 = load { i64, ptr }, ptr %l418, !tbaa !27
  %t1014 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s38, ptr %v0, ptr %t1011, i32 %t1012, ptr null, { i64, ptr } %t1013)
  store i32 %t1014, ptr %l419
  br label %bb204
bb204:
  %t1015 = load ptr, ptr %l405, !tbaa !29
  %t1016 = load i32, ptr %l419, !tbaa !23
  %t1017 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s38, ptr %t1015, i32 %t1016)
  store { i64, ptr } %t1017, ptr %l420
  br label %bb205
bb205:
  %t1018 = load { i64, ptr }, ptr %l420, !tbaa !27
  store { i64, ptr } %t1018, ptr %l41, !tbaa !27
  %t1019 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1021 = call i64 @compiler_2fexplain_2efirstClose(ptr %s38, { i64, ptr } %t1019)
  store i64 %t1021, ptr %l422
  br label %bb206
bb206:
  %t1022 = load i64, ptr %l422, !tbaa !24
  store i64 %t1022, ptr %l42, !tbaa !24
  store ptr %l2, ptr %l423, !tbaa !29
  %t1023 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1023, ptr %l424, !tbaa !27
  %t1024 = load i64, ptr %l42, !tbaa !24
  %t1026 = add i64 %t1024, 1
  store i64 %t1026, ptr %l426, !tbaa !24
  %t1027 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1028 = extractvalue { i64, ptr } %t1027, 0
  store i64 %t1028, ptr %l427, !tbaa !24
  %t1029 = icmp sge i64 2, 0
  br i1 %t1029, label %bb207, label %bb208
bb207:
  %t1031 = load i64, ptr %l426, !tbaa !24
  %t1032 = icmp sle i64 2, %t1031
  br i1 %t1032, label %bb209, label %bb210
bb208:
  call void @__olang_check_failed(ptr @olang_loc_453513bb52bf33a0_d8a4f5739c816cd4)
  unreachable
bb209:
  %t1034 = load i64, ptr %l426, !tbaa !24
  %t1035 = load i64, ptr %l427, !tbaa !24
  %t1036 = icmp sle i64 %t1034, %t1035
  br i1 %t1036, label %bb211, label %bb212
bb210:
  call void @__olang_check_failed(ptr @olang_loc_453513bb52bf33a0_d8a4f5739c816cd4)
  unreachable
bb211:
  %t1038 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t1039 = load ptr, ptr %t1038, !tbaa !27
  %t1040 = load i64, ptr %l426, !tbaa !24
  %t1041 = getelementptr i8, ptr %t1039, i64 2
  %t1042 = sub i64 %t1040, 2
  %t1043 = insertvalue { i64, ptr } undef, i64 %t1042, 0
  %t1044 = insertvalue { i64, ptr } %t1043, ptr %t1041, 1
  store { i64, ptr } %t1044, ptr %l431, !tbaa !27
  %t1045 = load i64, ptr %l42, !tbaa !24
  %t1047 = add i64 %t1045, 1
  store i64 %t1047, ptr %l433, !tbaa !24
  %t1048 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1050 = extractvalue { i64, ptr } %t1048, 0
  store i64 %t1050, ptr %l435, !tbaa !24
  %t1051 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1052 = extractvalue { i64, ptr } %t1051, 0
  store i64 %t1052, ptr %l436, !tbaa !24
  %t1053 = load i64, ptr %l433, !tbaa !24
  %t1054 = icmp sge i64 %t1053, 0
  br i1 %t1054, label %bb213, label %bb214
bb212:
  call void @__olang_check_failed(ptr @olang_loc_453513bb52bf33a0_d8a4f5739c816cd4)
  unreachable
bb213:
  %t1056 = load i64, ptr %l433, !tbaa !24
  %t1057 = load i64, ptr %l435, !tbaa !24
  %t1058 = icmp sle i64 %t1056, %t1057
  br i1 %t1058, label %bb215, label %bb216
bb214:
  call void @__olang_check_failed(ptr @olang_loc_453513bb52bf33a0_d8a4f5739c816cd4)
  unreachable
bb215:
  %t1060 = load i64, ptr %l435, !tbaa !24
  %t1061 = load i64, ptr %l436, !tbaa !24
  %t1062 = icmp sle i64 %t1060, %t1061
  br i1 %t1062, label %bb217, label %bb218
bb216:
  call void @__olang_check_failed(ptr @olang_loc_453513bb52bf33a0_d8a4f5739c816cd4)
  unreachable
bb217:
  %t1064 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t1065 = load ptr, ptr %t1064, !tbaa !27
  %t1066 = load i64, ptr %l433, !tbaa !24
  %t1067 = load i64, ptr %l435, !tbaa !24
  %t1068 = getelementptr i8, ptr %t1065, i64 %t1066
  %t1069 = sub i64 %t1067, %t1066
  %t1070 = insertvalue { i64, ptr } undef, i64 %t1069, 0
  %t1071 = insertvalue { i64, ptr } %t1070, ptr %t1068, 1
  %t1073 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s38, ptr %s38, { i64, ptr } %t1071)
  store { i64, ptr } %t1073, ptr %l441
  br label %bb219
bb218:
  call void @__olang_check_failed(ptr @olang_loc_453513bb52bf33a0_d8a4f5739c816cd4)
  unreachable
bb219:
  %t1074 = extractvalue { i64, ptr } { i64 5, ptr @.d66 }, 1
  %t1075 = extractvalue { i64, ptr } { i64 5, ptr @.d66 }, 0
  %t1076 = load { i64, ptr }, ptr %l424, !tbaa !27
  %t1077 = extractvalue { i64, ptr } %t1076, 1
  %t1078 = extractvalue { i64, ptr } %t1076, 0
  %t1079 = add i64 %t1075, %t1078
  %t1080 = extractvalue { i64, ptr } { i64 7, ptr @.d67 }, 1
  %t1081 = extractvalue { i64, ptr } { i64 7, ptr @.d67 }, 0
  %t1082 = add i64 %t1079, %t1081
  %t1083 = load { i64, ptr }, ptr %l431, !tbaa !27
  %t1084 = extractvalue { i64, ptr } %t1083, 1
  %t1085 = extractvalue { i64, ptr } %t1083, 0
  %t1086 = add i64 %t1082, %t1085
  %t1087 = load { i64, ptr }, ptr %l441, !tbaa !27
  %t1088 = extractvalue { i64, ptr } %t1087, 1
  %t1089 = extractvalue { i64, ptr } %t1087, 0
  %t1090 = add i64 %t1086, %t1089
  %t1091 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 1
  %t1092 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 0
  %t1093 = add i64 %t1090, %t1092
  %t1094 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t1093)
  call void @olang_textcopy(ptr %t1094, ptr %t1074, i64 %t1075)
  %t1095 = getelementptr i8, ptr %t1094, i64 %t1075
  call void @olang_textcopy(ptr %t1095, ptr %t1077, i64 %t1078)
  %t1096 = getelementptr i8, ptr %t1095, i64 %t1078
  call void @olang_textcopy(ptr %t1096, ptr %t1080, i64 %t1081)
  %t1097 = getelementptr i8, ptr %t1096, i64 %t1081
  call void @olang_textcopy(ptr %t1097, ptr %t1084, i64 %t1085)
  %t1098 = getelementptr i8, ptr %t1097, i64 %t1085
  call void @olang_textcopy(ptr %t1098, ptr %t1088, i64 %t1089)
  %t1099 = getelementptr i8, ptr %t1098, i64 %t1089
  call void @olang_textcopy(ptr %t1099, ptr %t1091, i64 %t1092)
  %t1100 = insertvalue { i64, ptr } undef, i64 %t1093, 0
  %t1101 = insertvalue { i64, ptr } %t1100, ptr %t1094, 1
  %t1103 = extractvalue { i64, ptr } %t1101, 0
  %t1104 = extractvalue { i64, ptr } %t1101, 1
  %t1105 = mul i64 %t1103, 1
  %t1106 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t1105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1106, ptr %t1104, i64 %t1105, i1 false)
  %t1107 = insertvalue { i64, ptr } undef, i64 %t1103, 0
  %t1108 = insertvalue { i64, ptr } %t1107, ptr %t1106, 1
  %t1109 = load ptr, ptr %l423, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s38, ptr %t1109, { i64, ptr } %t1108)
  br label %bb220
bb220:
  %t1111 = load ptr, ptr %l0, !tbaa !29
  %t1113 = getelementptr %"compiler/check:Checker", ptr %t1111, i32 0, i32 1
  %t1114 = load ptr, ptr %t1113, !tbaa !29
  %t1115 = load i32, ptr %l1, !tbaa !23
  %t1118 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t1114, i32 %t1115)
  store ptr %t1118, ptr %l447
  br label %bb221
bb221:
  %t1119 = load ptr, ptr %l447, !tbaa !29
  store ptr %t1119, ptr %l43, !tbaa !29
  %t1120 = load ptr, ptr %l43, !tbaa !29
  %t1122 = icmp eq ptr %t1120, null
  br i1 %t1122, label %bb222, label %bb223
bb222:
  call void @__olang_check_failed(ptr @olang_loc_c0b6a28f79589111_a09bca6888f93f2d)
  unreachable
bb223:
  br label %bb224
bb224:
  %t1124 = load ptr, ptr %l43, !tbaa !29
  %t1127 = getelementptr %"compiler/ast:TypeDecl", ptr %t1124, i32 0, i32 3
  %t1128 = load ptr, ptr %t1127, !tbaa !29
  store ptr %t1128, ptr %l44, !tbaa !29
  %t1130 = load ptr, ptr %l44, !tbaa !29
  store ptr %t1130, ptr %l453, !tbaa !29
  store i1 false, ptr %l454, !tbaa !21
  %t1131 = load ptr, ptr %l453, !tbaa !29
  %t1132 = icmp ne ptr %t1131, null
  br i1 %t1132, label %bb225, label %bb226
bb225:
  %t1134 = load ptr, ptr %l453, !tbaa !29
  %t1135 = load i64, ptr %t1134
  %t1137 = icmp eq i64 %t1135, 0
  store i1 %t1137, ptr %l454, !tbaa !21
  br label %bb226
bb226:
  %t1138 = load i1, ptr %l454, !tbaa !21
  br i1 %t1138, label %bb227, label %bb228
bb227:
  %t1139 = load ptr, ptr %l44, !tbaa !29
  %t1141 = getelementptr { i64, [6 x i64] }, ptr %t1139, i32 0, i32 1
  %t1142 = getelementptr { ptr }, ptr %t1141, i32 0, i32 0
  %t1143 = load ptr, ptr %t1142
  store ptr %t1143, ptr %l45, !tbaa !29
  br label %bb229
bb228:
  br label %bb238
bb229:
  %t1145 = load ptr, ptr %l45, !tbaa !29
  %t1147 = getelementptr %"compiler/ast:StructBody", ptr %t1145, i32 0, i32 1
  %t1148 = load ptr, ptr %t1147, !tbaa !29
  %t1150 = icmp eq ptr %t1148, null
  %t1152 = xor i1 %t1150, true
  br i1 %t1152, label %bb230, label %bb231
bb230:
  store %olang.scope zeroinitializer, ptr %s41
  store ptr %l2, ptr %l463, !tbaa !29
  %t1154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1154, ptr %l464, !tbaa !29
  %t1155 = load ptr, ptr %l45, !tbaa !29
  %t1157 = getelementptr %"compiler/ast:StructBody", ptr %t1155, i32 0, i32 1
  %t1158 = load ptr, ptr %t1157, !tbaa !29
  %t1160 = icmp eq ptr %t1158, null
  br i1 %t1160, label %bb232, label %bb233
bb231:
  br label %bb237
bb232:
  call void @__olang_check_failed(ptr @olang_loc_b306a27fe8c8780a_4c00da05a7c42646)
  unreachable
bb233:
  br label %bb234
bb234:
  %t1162 = load ptr, ptr %l45, !tbaa !29
  %t1164 = getelementptr %"compiler/ast:StructBody", ptr %t1162, i32 0, i32 1
  %t1165 = load ptr, ptr %t1164, !tbaa !29
  store ptr %t1165, ptr %l469, !tbaa !29
  %t1166 = load ptr, ptr %l0, !tbaa !29
  %t1168 = getelementptr %"compiler/check:Checker", ptr %t1166, i32 0, i32 1
  %t1169 = load ptr, ptr %t1168, !tbaa !29
  %t1170 = load i32, ptr %l1, !tbaa !23
  %t1173 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t1169, i32 %t1170)
  store i64 %t1173, ptr %l473
  br label %bb235
bb235:
  %t1174 = load ptr, ptr %l463, !tbaa !29
  %t1175 = load ptr, ptr %l464, !tbaa !29
  %t1176 = load ptr, ptr %l469, !tbaa !29
  %t1177 = load i64, ptr %l473, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s41, ptr %t1174, ptr %t1175, ptr %t1176, i64 %t1177, { i64, ptr } { i64 4, ptr @.d69 })
  br label %bb236
bb236:
  call void @__olang_scope_close(ptr %s41)
  br label %bb237
bb237:
  br label %bb243
bb238:
  br i1 true, label %bb239, label %bb240
bb239:
  br label %bb241
bb240:
  br label %bb242
bb241:
  br label %bb243
bb242:
  call void @__olang_check_failed(ptr @olang_loc_3440d096e5114f32_3ca396a3e382dce)
  unreachable
bb243:
  %t1178 = load ptr, ptr %l0, !tbaa !29
  %t1179 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2efields(ptr %s0, ptr %v0, ptr %l2, ptr %t1178, i32 %t1179)
  br label %bb244
bb244:
  call void @__olang_scope_close(ptr %s38)
  br label %bb246
bb245:
  call void @__olang_check_failed(ptr @olang_loc_3df602fba2cf8b3_3b7d9b6ebe07120f)
  unreachable
bb246:
  %t1183 = load ptr, ptr %l0, !tbaa !29
  %t1184 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2emethods(ptr %s0, ptr %v0, ptr %l2, ptr %t1183, i32 %t1184)
  br label %bb247
bb247:
  %t1188 = load ptr, ptr %l0, !tbaa !29
  %t1189 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2etraitsMet(ptr %s0, ptr %v0, ptr %l2, ptr %t1188, i32 %t1189)
  br label %bb248
bb248:
  %t1194 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t1194, ptr %l484
  br label %bb249
bb249:
  %t1195 = load { i64, ptr }, ptr %l484, !tbaa !27
  store { i64, ptr } %t1195, ptr %l485, !tbaa !27
  %t1196 = load { i64, ptr }, ptr %l485, !tbaa !27
  %t1197 = extractvalue { i64, ptr } %t1196, 0
  store i64 %t1197, ptr %l486, !tbaa !24
  %t1198 = load i64, ptr %l486, !tbaa !24
  %t1199 = mul i64 %t1198, 1
  %t1200 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t1199)
  %t1201 = insertvalue { i64, ptr } undef, i64 %t1198, 0
  %t1202 = insertvalue { i64, ptr } %t1201, ptr %t1200, 1
  store { i64, ptr } %t1202, ptr %l487, !tbaa !27
  %t1203 = getelementptr { i64, ptr }, ptr %l487, i32 0, i32 1
  %t1204 = load ptr, ptr %t1203, !tbaa !27
  %t1205 = getelementptr { i64, ptr }, ptr %l485, i32 0, i32 1
  %t1206 = load ptr, ptr %t1205, !tbaa !27
  %t1207 = load i64, ptr %l486, !tbaa !24
  %t1208 = mul i64 %t1207, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1204, ptr %t1206, i64 %t1208, i1 false)
  %t1209 = load { i64, ptr }, ptr %l487, !tbaa !27
  store { i64, ptr } %t1209, ptr %l485, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t1210 = load { i64, ptr }, ptr %l485, !tbaa !27
  store { i64, ptr } %t1210, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %a2)
  store i32 %t19, ptr %l12
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l5, !tbaa !29
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t20, i64 %t21, i32 %t22)
  store i64 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load i64, ptr %l13, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i32 -1, ptr %l16, !tbaa !23
  br label %bb6
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t38 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t32, i64 %t33, i64 %t34)
  store i32 %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = load i32, ptr %l21, !tbaa !23
  store i32 %t39, ptr %l16, !tbaa !23
  br label %bb6
bb6:
  %t40 = load i32, ptr %l16, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:varRow"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca i64
  %l37 = alloca i64
  %l59 = alloca %"compiler/generic:varRow"
  %l64 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i64
  %l112 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l19
  br label %bb1
bb1:
  %t9 = load i64, ptr %l19, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sle i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr @.d70 }, ptr %l23, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t16, ptr %l24, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l25, !tbaa !24
  %t19 = load i64, ptr %l25, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l26, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l25, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t30, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t32 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t32, ptr %l27
  br label %bb5
bb5:
  %t33 = load %"std/prelude/text:StringBuilder", ptr %l27
  store %"std/prelude/text:StringBuilder" %t33, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 60)
  br label %bb6
bb6:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l37, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t94 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t88, i64 %t89, i64 %t90)
  store %"compiler/generic:varRow" %t94, ptr %l59
  br label %bb17
bb17:
  %t95 = load %"compiler/generic:varRow", ptr %l59
  store %"compiler/generic:varRow" %t95, ptr %l11
  %t96 = load i64, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l2, !tbaa !24
  %t100 = icmp sgt i64 %t96, %t97
  br i1 %t100, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l4, { i64, ptr } { i64 2, ptr @.d71 })
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  store ptr %l4, ptr %l64, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 3
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 1
  %t114 = load i32, ptr %t113, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t112, i32 %t114)
  store { i64, ptr } %t117, ptr %l70
  br label %bb22
bb22:
  %t118 = load ptr, ptr %l64, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l70, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t118, { i64, ptr } %t119)
  br label %bb23
bb23:
  %t120 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t125 = icmp ne i32 %t121, %t122
  br i1 %t125, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l4, ptr %l74, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t129 = load i32, ptr %t128, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s5, ptr %t127, i32 %t129)
  store { i64, ptr } %t132, ptr %l77
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t133 = extractvalue { i64, ptr } { i64 1, ptr @.d72 }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d72 }, 0
  %t135 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = add i64 %t134, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t133, i64 %t134)
  %t140 = getelementptr i8, ptr %t139, i64 %t134
  call void @olang_textcopy(ptr %t140, ptr %t136, i64 %t137)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  %t150 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t150, { i64, ptr } %t149)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t152 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t153 = load i32, ptr %t152, !tbaa !23
  %t154 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t157 = icmp ne i32 %t153, %t154
  br i1 %t157, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t163 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t164 = load i32, ptr %t163, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %s8, ptr %t162, i32 %t164)
  store { i64, ptr } %t167, ptr %l86
  br label %bb31
bb30:
  br label %bb40
bb31:
  %t168 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = extractvalue { i64, ptr } %t168, 1
  %t171 = mul i64 %t169, 4
  %t172 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  store i64 %t178, ptr %l14, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  %t180 = load i64, ptr %l13, !tbaa !24
  %t181 = load i64, ptr %l14, !tbaa !24
  %t184 = icmp slt i64 %t180, %t181
  %t186 = xor i1 %t184, true
  br i1 %t186, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb39
bb34:
  br label %bb35
bb35:
  %t188 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t188, ptr %l94, !tbaa !27
  %t189 = load i64, ptr %l13, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i32, ptr %t192, i64 %t189
  %t194 = load i32, ptr %t193, !tbaa !33
  store ptr %l4, ptr %l97, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t200 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s9, ptr %t196, i32 %t194)
  store { i64, ptr } %t200, ptr %l100
  br label %bb36
bb36:
  %t201 = extractvalue { i64, ptr } { i64 1, ptr @.d73 }, 1
  %t202 = extractvalue { i64, ptr } { i64 1, ptr @.d73 }, 0
  %t203 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = add i64 %t202, %t205
  %t207 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t206)
  call void @olang_textcopy(ptr %t207, ptr %t201, i64 %t202)
  %t208 = getelementptr i8, ptr %t207, i64 %t202
  call void @olang_textcopy(ptr %t208, ptr %t204, i64 %t205)
  %t209 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t207, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = extractvalue { i64, ptr } %t210, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t218 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t218, { i64, ptr } %t217)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s9)
  br label %bb38
bb38:
  %t220 = load i64, ptr %l13, !tbaa !24
  %t222 = add i64 %t220, 1
  store i64 %t222, ptr %l13, !tbaa !24
  br label %bb32
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  %t224 = load i64, ptr %l9, !tbaa !24
  %t226 = add i64 %t224, 1
  store i64 %t226, ptr %l9, !tbaa !24
  br label %bb13
bb42:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 62)
  br label %bb43
bb43:
  %t230 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l4)
  store { i64, ptr } %t230, ptr %l109
  br label %bb44
bb44:
  %t231 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t231, ptr %l110, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 0
  store i64 %t233, ptr %l111, !tbaa !24
  %t234 = load i64, ptr %l111, !tbaa !24
  %t235 = mul i64 %t234, 1
  %t236 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t235)
  %t237 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  store { i64, ptr } %t238, ptr %l112, !tbaa !27
  %t239 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = load i64, ptr %l111, !tbaa !24
  %t244 = mul i64 %t243, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t240, ptr %t242, i64 %t244, i1 false)
  %t245 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t245, ptr %l110, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t246 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t246, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d0 = private constant [1 x i8] c"."
declare void @__olang_check_failed(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d1 = private constant [15 x i8] c"# its results: "
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant [2 x i8] c", "
@.d3 = private constant [1 x i8] c"\0A"
@.d4 = private constant [1 x i8] c"["
@.d5 = private constant [2 x i8] c"]\0A"
@.d6 = private constant [2 x i8] c" ?"
@.d7 = private constant [0 x i8] c""
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d8 = private constant [4 x i8] c"    "
@.d9 = private constant [1 x i8] c" "
@.d10 = private constant [1 x i8] c"\0A"
@.d11 = private constant [1 x i8] c"\0A"
@.d12 = private constant [4 x i8] c"    "
@.d13 = private constant [4 x i8] c"    "
@.d14 = private constant [1 x i8] c"\0A"
@.d15 = private constant [4 x i8] c"    "
@.d16 = private constant [13 x i8] c"    instance "
@.d17 = private constant [2 x i8] c": "
@.d18 = private constant [1 x i8] c"\0A"
@.d19 = private constant [8 x i8] c"        "
@.d20 = private constant [10 x i8] c"extern fn "
@.d21 = private constant [3 x i8] c"fn "
@.d22 = private constant [1 x i8] c"("
@.d23 = private constant [1 x i8] c"("
@.d24 = private constant [2 x i8] c") "
@.d25 = private constant [1 x i8] c"("
@.d26 = private constant [5 x i8] c" mut "
@.d27 = private constant [1 x i8] c" "
@.d28 = private constant [20 x i8] c"   # set at startup\0A"
@.d29 = private constant [20 x i8] c"   # set at startup\0A"
@.d30 = private constant [3 x i8] c" = "
@.d31 = private constant [1 x i8] c"\0A"
@.d32 = private constant [3 x i8] c" = "
@.d33 = private constant [1 x i8] c"\0A"
@.d34 = private constant [2 x i8] c", "
@.d35 = private constant [4 x i8] c"    "
@.d36 = private constant [1 x i8] c"\0A"
@.d37 = private constant [4 x i8] c"    "
@.d38 = private constant [1 x i8] c"\0A"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d39 = private constant [1 x i8] c"["
@.d40 = private constant [2 x i8] c"]\0A"
@.d41 = private constant [2 x i8] c"\5Cn"
@.d42 = private constant [2 x i8] c"\5Ct"
@.d43 = private constant [27 x i8] c"   # its error set inferred"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d44 = private constant [2 x i8] c", "
@.d45 = private constant [10 x i8] c"    meets "
@.d46 = private constant [1 x i8] c"\0A"
@.d47 = private constant [2 x i8] c", "
@.d48 = private constant [6 x i8] c"error "
@.d49 = private constant [1 x i8] c"\0A"
@.d50 = private constant [4 x i8] c"    "
@.d51 = private constant [1 x i8] c"\0A"
@.d52 = private constant [5 x i8] c"type "
@.d53 = private constant [6 x i8] c" trait"
@.d54 = private constant [9 x i8] c" extends "
@.d55 = private constant [5 x i8] c" for "
@.d56 = private constant [1 x i8] c"\0A"
@.d57 = private constant [4 x i8] c"    "
@.d58 = private constant [1 x i8] c"\0A"
@.d59 = private constant [5 x i8] c"type "
@.d60 = private constant [6 x i8] c" enum\0A"
@.d61 = private constant [4 x i8] c"    "
@.d62 = private constant [1 x i8] c" "
@.d63 = private constant [9 x i8] c" extends "
@.d64 = private constant [1 x i8] c" "
@.d65 = private constant [5 x i8] c"type "
@.d66 = private constant [5 x i8] c"type "
@.d67 = private constant [7 x i8] c" struct"
@.d68 = private constant [1 x i8] c"\0A"
@.d69 = private constant [4 x i8] c"    "
@.d70 = private constant [0 x i8] c""
@.d71 = private constant [2 x i8] c", "
@.d72 = private constant [1 x i8] c" "
@.d73 = private constant [1 x i8] c" "
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_35c12625cc2f75ee_5b08f4318e637d4a = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_430839a36fc86f5_d60a2ea9e5c9a99 = external constant [0 x i8]
@olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3 = external constant [0 x i8]
@olang_loc_5177bd7d484351dd_5d0dbb04dc509331 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_e7ca39a48e286d3f_b849249cb4ab4933 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ec0929e0cef23b20_10aa079683981964 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67 = external constant [0 x i8]
@olang_loc_6448edf003c535f3_ebaded49d6e07c97 = external constant [0 x i8]
@olang_loc_979fe2e14fb6de05_5947910940c194f1 = external constant [0 x i8]
@olang_loc_8f9ce818ff296c0e_932c83e6c6076d82 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d16c6b36ae6c900f_110b33433d32ce53 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_35ffc19e50bbc737_e52638f1e81552b = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_36a09f0a29856ad4_1f4c57e6e1803c38 = external constant [0 x i8]
@olang_loc_6896438a508f3415_b4ea8b5a918f5051 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2d047dc2e8ba79e9_b3960442abafce65 = external constant [0 x i8]
@olang_loc_62f5937584004bfc_64dbf784650d4808 = external constant [0 x i8]
@olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@olang_loc_24a71f1628ab63b4_59f385be22d57b28 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_Hb234e65a2b42ee429ada36859295662b(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a = external constant [0 x i8]
@olang_loc_9d3c9a5d5d1efd85_5425f31610037701 = external constant [0 x i8]
@olang_loc_7e9d681ab1b80777_86743e4a68c30163 = external constant [0 x i8]
@olang_loc_60d3429e949e0f0f_c9b6e73225d64a3b = external constant [0 x i8]
@olang_loc_750d58cd4bdb6bfa_b2dda4435afc6fae = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
@olang_loc_9b5b2a94bb1064e0_bfbfac3114847e44 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b92ab423e11bfbb4_4adf8d895fd79148 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_ec478a9a38770143_a832df5ab537b567 = external constant [0 x i8]
@olang_loc_9c563feafedd44ce_b85d3928399923da = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4a756130778b14bd_8f8d371a853a3189 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b6c637a5f4084e9b_d531d6adfcd75e3f = external constant [0 x i8]
@olang_loc_93210599a953f045_f6edd12d3f8198a9 = external constant [0 x i8]
@olang_loc_19c36e0ba461fdf7_41869d9fd7da314b = external constant [0 x i8]
@olang_loc_453513bb52bf33a0_d8a4f5739c816cd4 = external constant [0 x i8]
@olang_loc_c0b6a28f79589111_a09bca6888f93f2d = external constant [0 x i8]
@olang_loc_b306a27fe8c8780a_4c00da05a7c42646 = external constant [0 x i8]
@olang_loc_3440d096e5114f32_3ca396a3e382dce = external constant [0 x i8]
@olang_loc_3df602fba2cf8b3_3b7d9b6ebe07120f = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
