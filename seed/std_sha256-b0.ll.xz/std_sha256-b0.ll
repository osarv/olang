; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/sha256:Hasher" = type { [8 x i32], [64 x i8], i64, i64 }
define dso_local { i64, ptr } @std_2fsha256_2eHmac(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca [64 x i8]
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"std/sha256:Hasher"
  %l17 = alloca %"std/sha256:Hasher"
  %l18 = alloca [64 x i8]
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca [64 x i8]
  %l40 = alloca { i64, ptr }
  %l44 = alloca i64
  %l47 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i1
  %l80 = alloca i64
  %l83 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i1
  %l106 = alloca { i64, ptr }
  %l112 = alloca %"std/sha256:Hasher"
  %l113 = alloca %"std/sha256:Hasher"
  %l117 = alloca i64
  %l120 = alloca i64
  %l129 = alloca i64
  %l132 = alloca i1
  %l159 = alloca { i64, ptr }
  %l170 = alloca i64
  %l173 = alloca i64
  %l182 = alloca i64
  %l185 = alloca i1
  %l205 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 64
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [64 x i8], ptr %l35, i64 0, i64 %t5
  store i8 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  %t9 = load [64 x i8], ptr %l35
  store [64 x i8] %t9, ptr %l2
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = icmp sgt i64 %t12, 64
  br i1 %t14, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = call { i64, ptr } @std_2fsha256_2eSum(ptr %v0, ptr %s1, { i64, ptr } %t16)
  store { i64, ptr } %t18, ptr %l40
  br label %bb3
bb2:
  store i64 0, ptr %l10, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t23 = load i64, ptr %l11, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb16, label %bb17
bb3:
  %t29 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  store i64 32, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb4, label %bb5
bb4:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb9
bb6:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l47, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb8
bb8:
  %t56 = load i64, ptr %l47, !tbaa !24
  store i64 %t56, ptr %l44, !tbaa !24
  br label %bb9
bb9:
  %t57 = load i64, ptr %l44, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = sub i64 %t58, 1
  store i64 %t59, ptr %l56, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp slt i64 %t60, 2147483648
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sge i64 %t62, 0
  %t66 = and i1 %t61, %t63
  store i1 %t66, ptr %l59, !tbaa !21
  br label %bb10
bb10:
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t75 = load i64, ptr %l4, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l9, !tbaa !24
  %t85 = load i64, ptr %l9, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 %t86
  %t91 = load i8, ptr %t90, !tbaa !32
  %t94 = getelementptr [64 x i8], ptr %l2, i64 0, i64 %t85
  store i8 %t91, ptr %t94, !tbaa !32
  br label %bb14
bb14:
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = add i64 %t95, 1
  store i64 %t98, ptr %l8, !tbaa !24
  br label %bb10
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb28
bb16:
  %t100 = load i64, ptr %l12, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb21
bb18:
  %t104 = load i64, ptr %l11, !tbaa !24
  %t105 = load i64, ptr %l10, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l12, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l83, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb20
bb20:
  %t120 = load i64, ptr %l83, !tbaa !24
  store i64 %t120, ptr %l80, !tbaa !24
  br label %bb21
bb21:
  %t121 = load i64, ptr %l80, !tbaa !24
  store i64 %t121, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  %t122 = load i64, ptr %l13, !tbaa !24
  %t123 = sub i64 %t122, 1
  store i64 %t123, ptr %l92, !tbaa !24
  %t124 = load i64, ptr %l13, !tbaa !24
  %t125 = icmp slt i64 %t124, 2147483648
  %t126 = load i64, ptr %l14, !tbaa !24
  %t127 = icmp sge i64 %t126, 0
  %t130 = and i1 %t125, %t127
  store i1 %t130, ptr %l95, !tbaa !21
  br label %bb22
bb22:
  %t131 = load i64, ptr %l14, !tbaa !24
  %t132 = load i64, ptr %l13, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t140 = load i64, ptr %l14, !tbaa !24
  %t141 = load i64, ptr %l12, !tbaa !24
  %t144 = mul i64 %t140, %t141
  %t147 = add i64 %t139, %t144
  store i64 %t147, ptr %l15, !tbaa !24
  %t149 = load i64, ptr %l15, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t150, ptr %l106, !tbaa !27
  %t151 = load i64, ptr %l15, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i8, ptr %t154, i64 %t151
  %t156 = load i8, ptr %t155, !tbaa !32
  %t159 = getelementptr [64 x i8], ptr %l2, i64 0, i64 %t149
  store i8 %t156, ptr %t159, !tbaa !32
  br label %bb26
bb26:
  %t160 = load i64, ptr %l14, !tbaa !24
  %t163 = add i64 %t160, 1
  store i64 %t163, ptr %l14, !tbaa !24
  br label %bb22
bb27:
  br label %bb28
bb28:
  %t165 = call %"std/sha256:Hasher" @std_2fsha256_3aHasher_2ector(ptr %s0)
  store %"std/sha256:Hasher" %t165, ptr %l112
  br label %bb29
bb29:
  %t166 = load %"std/sha256:Hasher", ptr %l112
  store %"std/sha256:Hasher" %t166, ptr %l16
  %t167 = call %"std/sha256:Hasher" @std_2fsha256_3aHasher_2ector(ptr %s0)
  store %"std/sha256:Hasher" %t167, ptr %l113
  br label %bb30
bb30:
  %t168 = load %"std/sha256:Hasher", ptr %l113
  store %"std/sha256:Hasher" %t168, ptr %l17
  store i64 0, ptr %l19, !tbaa !24
  store i64 64, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t169 = load i64, ptr %l20, !tbaa !24
  %t170 = load i64, ptr %l19, !tbaa !24
  %t173 = icmp sgt i64 %t169, %t170
  br i1 %t173, label %bb31, label %bb32
bb31:
  %t175 = load i64, ptr %l21, !tbaa !24
  %t177 = icmp sgt i64 %t175, 0
  br i1 %t177, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb36
bb33:
  %t179 = load i64, ptr %l20, !tbaa !24
  %t180 = load i64, ptr %l19, !tbaa !24
  %t183 = sub i64 %t179, %t180
  %t184 = load i64, ptr %l21, !tbaa !24
  %t187 = add i64 %t183, %t184
  %t189 = sub i64 %t187, 1
  %t190 = load i64, ptr %l21, !tbaa !24
  %t193 = sdiv i64 %t189, %t190
  store i64 %t193, ptr %l120, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb35
bb35:
  %t195 = load i64, ptr %l120, !tbaa !24
  store i64 %t195, ptr %l117, !tbaa !24
  br label %bb36
bb36:
  %t196 = load i64, ptr %l117, !tbaa !24
  store i64 %t196, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  %t197 = load i64, ptr %l22, !tbaa !24
  %t198 = sub i64 %t197, 1
  store i64 %t198, ptr %l129, !tbaa !24
  %t199 = load i64, ptr %l22, !tbaa !24
  %t200 = icmp slt i64 %t199, 2147483648
  %t201 = load i64, ptr %l23, !tbaa !24
  %t202 = icmp sge i64 %t201, 0
  %t205 = and i1 %t200, %t202
  store i1 %t205, ptr %l132, !tbaa !21
  br label %bb37
bb37:
  %t206 = load i64, ptr %l23, !tbaa !24
  %t207 = load i64, ptr %l22, !tbaa !24
  %t210 = icmp slt i64 %t206, %t207
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb38, label %bb39
bb38:
  br label %bb42
bb39:
  br label %bb40
bb40:
  %t214 = load i64, ptr %l19, !tbaa !24
  %t215 = load i64, ptr %l23, !tbaa !24
  %t216 = load i64, ptr %l21, !tbaa !24
  %t219 = mul i64 %t215, %t216
  %t222 = add i64 %t214, %t219
  store i64 %t222, ptr %l24, !tbaa !24
  %t224 = load i64, ptr %l24, !tbaa !24
  %t225 = load i64, ptr %l24, !tbaa !24
  %t227 = getelementptr [64 x i8], ptr %l2, i64 0, i64 %t225
  %t228 = load i8, ptr %t227, !tbaa !32
  %t230 = xor i8 %t228, 54
  %t233 = getelementptr [64 x i8], ptr %l18, i64 0, i64 %t224
  store i8 %t230, ptr %t233, !tbaa !32
  br label %bb41
bb41:
  %t234 = load i64, ptr %l23, !tbaa !24
  %t237 = add i64 %t234, 1
  store i64 %t237, ptr %l23, !tbaa !24
  br label %bb37
bb42:
  %t240 = insertvalue { i64, ptr } undef, i64 64, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %l18, 1
  call void @std_2fsha256_2estd_2fsha256_3aHasher_2ePush(ptr %s0, ptr %s0, ptr %l16, { i64, ptr } %t241)
  br label %bb43
bb43:
  store { i64, ptr } %a1, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t246 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 0
  store i64 %t248, ptr %l27, !tbaa !24
  br label %bb44
bb44:
  %t250 = load i64, ptr %l26, !tbaa !24
  %t251 = load i64, ptr %l27, !tbaa !24
  %t254 = icmp slt i64 %t250, %t251
  %t256 = xor i1 %t254, true
  br i1 %t256, label %bb45, label %bb46
bb45:
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t258 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t258, ptr %l159, !tbaa !27
  %t259 = load i64, ptr %l26, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %t262, i64 %t259
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !37
  call void @std_2fsha256_2estd_2fsha256_3aHasher_2ePush(ptr %s0, ptr %v1, ptr %l16, { i64, ptr } %t264)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t269 = load i64, ptr %l26, !tbaa !24
  %t272 = add i64 %t269, 1
  store i64 %t272, ptr %l26, !tbaa !24
  br label %bb44
bb50:
  store i64 0, ptr %l29, !tbaa !24
  store i64 64, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t274 = load i64, ptr %l30, !tbaa !24
  %t275 = load i64, ptr %l29, !tbaa !24
  %t278 = icmp sgt i64 %t274, %t275
  br i1 %t278, label %bb51, label %bb52
bb51:
  %t280 = load i64, ptr %l31, !tbaa !24
  %t282 = icmp sgt i64 %t280, 0
  br i1 %t282, label %bb53, label %bb54
bb52:
  store i64 0, ptr %l170, !tbaa !24
  br label %bb56
bb53:
  %t284 = load i64, ptr %l30, !tbaa !24
  %t285 = load i64, ptr %l29, !tbaa !24
  %t288 = sub i64 %t284, %t285
  %t289 = load i64, ptr %l31, !tbaa !24
  %t292 = add i64 %t288, %t289
  %t294 = sub i64 %t292, 1
  %t295 = load i64, ptr %l31, !tbaa !24
  %t298 = sdiv i64 %t294, %t295
  store i64 %t298, ptr %l173, !tbaa !24
  br label %bb55
bb54:
  store i64 0, ptr %l173, !tbaa !24
  br label %bb55
bb55:
  %t300 = load i64, ptr %l173, !tbaa !24
  store i64 %t300, ptr %l170, !tbaa !24
  br label %bb56
bb56:
  %t301 = load i64, ptr %l170, !tbaa !24
  store i64 %t301, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  %t302 = load i64, ptr %l32, !tbaa !24
  %t303 = sub i64 %t302, 1
  store i64 %t303, ptr %l182, !tbaa !24
  %t304 = load i64, ptr %l32, !tbaa !24
  %t305 = icmp slt i64 %t304, 2147483648
  %t306 = load i64, ptr %l33, !tbaa !24
  %t307 = icmp sge i64 %t306, 0
  %t310 = and i1 %t305, %t307
  store i1 %t310, ptr %l185, !tbaa !21
  br label %bb57
bb57:
  %t311 = load i64, ptr %l33, !tbaa !24
  %t312 = load i64, ptr %l32, !tbaa !24
  %t315 = icmp slt i64 %t311, %t312
  %t317 = xor i1 %t315, true
  br i1 %t317, label %bb58, label %bb59
bb58:
  br label %bb62
bb59:
  br label %bb60
bb60:
  %t319 = load i64, ptr %l29, !tbaa !24
  %t320 = load i64, ptr %l33, !tbaa !24
  %t321 = load i64, ptr %l31, !tbaa !24
  %t324 = mul i64 %t320, %t321
  %t327 = add i64 %t319, %t324
  store i64 %t327, ptr %l34, !tbaa !24
  %t329 = load i64, ptr %l34, !tbaa !24
  %t330 = load i64, ptr %l34, !tbaa !24
  %t332 = getelementptr [64 x i8], ptr %l2, i64 0, i64 %t330
  %t333 = load i8, ptr %t332, !tbaa !32
  %t335 = xor i8 %t333, 92
  %t338 = getelementptr [64 x i8], ptr %l18, i64 0, i64 %t329
  store i8 %t335, ptr %t338, !tbaa !32
  br label %bb61
bb61:
  %t339 = load i64, ptr %l33, !tbaa !24
  %t342 = add i64 %t339, 1
  store i64 %t342, ptr %l33, !tbaa !24
  br label %bb57
bb62:
  %t345 = insertvalue { i64, ptr } undef, i64 64, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %l18, 1
  call void @std_2fsha256_2estd_2fsha256_3aHasher_2ePush(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t346)
  br label %bb63
bb63:
  store ptr %l17, ptr %l205, !tbaa !29
  %t350 = call { i64, ptr } @std_2fsha256_2estd_2fsha256_3aHasher_2eSum(ptr %s0, ptr %s0, ptr %l16)
  store { i64, ptr } %t350, ptr %l207
  br label %bb64
bb64:
  %t351 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t352 = load ptr, ptr %l205, !tbaa !29
  call void @std_2fsha256_2estd_2fsha256_3aHasher_2ePush(ptr %s0, ptr %s0, ptr %t352, { i64, ptr } %t351)
  br label %bb65
bb65:
  %t355 = call { i64, ptr } @std_2fsha256_2estd_2fsha256_3aHasher_2eSum(ptr %s0, ptr %v2, ptr %l17)
  store { i64, ptr } %t355, ptr %l210
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  %t356 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t356, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @std_2fsha256_2esigma0(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l2 = alloca i32
  %l4 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !64
  %t3 = call i32 @std_2fsha256_2erotr(i32 %t1, i32 7)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l0, !tbaa !64
  %t6 = call i32 @std_2fsha256_2erotr(i32 %t4, i32 18)
  store i32 %t6, ptr %l4
  br label %bb2
bb2:
  %t7 = load i32, ptr %l2, !tbaa !64
  %t8 = load i32, ptr %l4, !tbaa !64
  %t9 = xor i32 %t7, %t8
  %t10 = load i32, ptr %l0, !tbaa !64
  %t12 = lshr i32 %t10, 3
  %t15 = xor i32 %t9, %t12
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fsha256_2esigma1(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l2 = alloca i32
  %l4 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !64
  %t3 = call i32 @std_2fsha256_2erotr(i32 %t1, i32 17)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l0, !tbaa !64
  %t6 = call i32 @std_2fsha256_2erotr(i32 %t4, i32 19)
  store i32 %t6, ptr %l4
  br label %bb2
bb2:
  %t7 = load i32, ptr %l2, !tbaa !64
  %t8 = load i32, ptr %l4, !tbaa !64
  %t9 = xor i32 %t7, %t8
  %t10 = load i32, ptr %l0, !tbaa !64
  %t12 = lshr i32 %t10, 10
  %t15 = xor i32 %t9, %t12
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2fsha256_2estd_2fsha256_3aHasher_2eSum(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/sha256:Hasher"
  %l2 = alloca i64
  %l3 = alloca [1 x i8]
  %l4 = alloca [1 x i8]
  %l5 = alloca [8 x i8]
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca [32 x i8]
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l40 = alloca i64
  %l43 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i1
  %l70 = alloca i64
  %l80 = alloca [32 x i8]
  %l84 = alloca i64
  %l87 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i1
  %l139 = alloca [32 x i8]
  %l140 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"std/sha256:Hasher", ptr %t1
  store %"std/sha256:Hasher" %t3, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/sha256:Hasher", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = mul i64 %t8, 8
  store i64 %t11, ptr %l2, !tbaa !65
  %t13 = insertvalue [1 x i8] undef, i8 -128, 0
  store [1 x i8] %t13, ptr %l3
  %t16 = insertvalue { i64, ptr } undef, i64 1, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %l3, 1
  call void @std_2fsha256_2estd_2fsha256_3aHasher_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t17)
  br label %bb1
bb1:
  %t20 = insertvalue [1 x i8] undef, i8 0, 0
  store [1 x i8] %t20, ptr %l4
  br label %bb2
bb2:
  %t22 = getelementptr %"std/sha256:Hasher", ptr %l1, i32 0, i32 2
  %t23 = load i64, ptr %t22, !tbaa !24
  %t25 = icmp ne i64 %t23, 56
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t30 = insertvalue { i64, ptr } undef, i64 1, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %l4, 1
  call void @std_2fsha256_2estd_2fsha256_3aHasher_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t31)
  br label %bb6
bb6:
  br label %bb7
bb7:
  br label %bb2
bb8:
  store i64 0, ptr %l6, !tbaa !24
  store i64 8, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb14
bb11:
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l43, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb13
bb13:
  %t60 = load i64, ptr %l43, !tbaa !24
  store i64 %t60, ptr %l40, !tbaa !24
  br label %bb14
bb14:
  %t61 = load i64, ptr %l40, !tbaa !24
  store i64 %t61, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = sub i64 %t62, 1
  store i64 %t63, ptr %l52, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = icmp slt i64 %t64, 2147483648
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  %t70 = and i1 %t65, %t67
  store i1 %t70, ptr %l55, !tbaa !21
  br label %bb15
bb15:
  %t71 = load i64, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t90 = load i64, ptr %l2, !tbaa !65
  %t91 = load i64, ptr %l11, !tbaa !24
  %t93 = mul i64 8, %t91
  %t95 = sub i64 56, %t93
  store i64 %t95, ptr %l70, !tbaa !65
  %t98 = load i64, ptr %l70, !tbaa !65
  %t99 = load i64, ptr %l70, !tbaa !65
  %t100 = lshr i64 %t90, %t99
  %t102 = and i64 %t100, 255
  %t104 = trunc i64 %t102 to i8
  %t107 = getelementptr [8 x i8], ptr %l5, i64 0, i64 %t89
  store i8 %t104, ptr %t107, !tbaa !32
  br label %bb19
bb19:
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %l10, !tbaa !24
  br label %bb15
bb20:
  %t114 = insertvalue { i64, ptr } undef, i64 8, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %l5, 1
  call void @std_2fsha256_2estd_2fsha256_3aHasher_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t115)
  br label %bb21
bb21:
  br label %fill.121
fill.121:
  br label %fill.118
fill.118:
  %t122 = phi i64 [ 0, %fill.121 ], [ %t123, %fill.119 ]
  %t124 = icmp slt i64 %t122, 32
  br i1 %t124, label %fill.119, label %fill.120
fill.119:
  %t125 = getelementptr [32 x i8], ptr %l80, i64 0, i64 %t122
  store i8 0, ptr %t125
  %t123 = add i64 %t122, 1
  br label %fill.118
fill.120:
  %t126 = load [32 x i8], ptr %l80
  store [32 x i8] %t126, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  store i64 8, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t127 = load i64, ptr %l14, !tbaa !24
  %t128 = load i64, ptr %l13, !tbaa !24
  %t131 = icmp sgt i64 %t127, %t128
  br i1 %t131, label %bb22, label %bb23
bb22:
  %t133 = load i64, ptr %l15, !tbaa !24
  %t135 = icmp sgt i64 %t133, 0
  br i1 %t135, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb27
bb24:
  %t137 = load i64, ptr %l14, !tbaa !24
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = sub i64 %t137, %t138
  %t142 = load i64, ptr %l15, !tbaa !24
  %t145 = add i64 %t141, %t142
  %t147 = sub i64 %t145, 1
  %t148 = load i64, ptr %l15, !tbaa !24
  %t151 = sdiv i64 %t147, %t148
  store i64 %t151, ptr %l87, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb26
bb26:
  %t153 = load i64, ptr %l87, !tbaa !24
  store i64 %t153, ptr %l84, !tbaa !24
  br label %bb27
bb27:
  %t154 = load i64, ptr %l84, !tbaa !24
  store i64 %t154, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t155 = load i64, ptr %l16, !tbaa !24
  %t156 = sub i64 %t155, 1
  store i64 %t156, ptr %l96, !tbaa !24
  %t157 = load i64, ptr %l16, !tbaa !24
  %t158 = icmp slt i64 %t157, 2147483648
  %t159 = load i64, ptr %l17, !tbaa !24
  %t160 = icmp sge i64 %t159, 0
  %t163 = and i1 %t158, %t160
  store i1 %t163, ptr %l99, !tbaa !21
  br label %bb28
bb28:
  %t164 = load i64, ptr %l17, !tbaa !24
  %t165 = load i64, ptr %l16, !tbaa !24
  %t168 = icmp slt i64 %t164, %t165
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t172 = load i64, ptr %l13, !tbaa !24
  %t173 = load i64, ptr %l17, !tbaa !24
  %t174 = load i64, ptr %l15, !tbaa !24
  %t177 = mul i64 %t173, %t174
  %t180 = add i64 %t172, %t177
  store i64 %t180, ptr %l18, !tbaa !24
  %t182 = load i64, ptr %l18, !tbaa !24
  %t183 = getelementptr %"std/sha256:Hasher", ptr %l1, i32 0, i32 0
  %t185 = getelementptr [8 x i32], ptr %t183, i64 0, i64 %t182
  %t186 = load i32, ptr %t185, !tbaa !84
  store i32 %t186, ptr %l19, !tbaa !64
  %t188 = load i64, ptr %l18, !tbaa !24
  %t190 = mul i64 4, %t188
  %t191 = load i32, ptr %l19, !tbaa !64
  %t193 = lshr i32 %t191, 24
  %t195 = trunc i32 %t193 to i8
  %t198 = getelementptr [32 x i8], ptr %l12, i64 0, i64 %t190
  store i8 %t195, ptr %t198, !tbaa !32
  %t199 = load i64, ptr %l18, !tbaa !24
  %t201 = mul i64 4, %t199
  %t203 = add i64 %t201, 1
  %t204 = load i32, ptr %l19, !tbaa !64
  %t206 = lshr i32 %t204, 16
  %t208 = and i32 %t206, 255
  %t210 = trunc i32 %t208 to i8
  %t213 = getelementptr [32 x i8], ptr %l12, i64 0, i64 %t203
  store i8 %t210, ptr %t213, !tbaa !32
  %t214 = load i64, ptr %l18, !tbaa !24
  %t216 = mul i64 4, %t214
  %t218 = add i64 %t216, 2
  %t219 = load i32, ptr %l19, !tbaa !64
  %t221 = lshr i32 %t219, 8
  %t223 = and i32 %t221, 255
  %t225 = trunc i32 %t223 to i8
  %t228 = getelementptr [32 x i8], ptr %l12, i64 0, i64 %t218
  store i8 %t225, ptr %t228, !tbaa !32
  %t229 = load i64, ptr %l18, !tbaa !24
  %t231 = mul i64 4, %t229
  %t233 = add i64 %t231, 3
  %t234 = load i32, ptr %l19, !tbaa !64
  %t236 = and i32 %t234, 255
  %t238 = trunc i32 %t236 to i8
  %t241 = getelementptr [32 x i8], ptr %l12, i64 0, i64 %t233
  store i8 %t238, ptr %t241, !tbaa !32
  br label %bb32
bb32:
  %t242 = load i64, ptr %l17, !tbaa !24
  %t245 = add i64 %t242, 1
  store i64 %t245, ptr %l17, !tbaa !24
  br label %bb28
bb33:
  %t247 = load [32 x i8], ptr %l12
  store [32 x i8] %t247, ptr %l139
  %t248 = mul i64 32, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t248)
  %t250 = insertvalue { i64, ptr } undef, i64 32, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  store { i64, ptr } %t251, ptr %l140, !tbaa !27
  %t252 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = mul i64 32, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t253, ptr %l139, i64 %t254, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t255 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t255, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fsha256_2estd_2fsha256_3aHasher_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca [64 x i32]
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l27 = alloca [64 x i32]
  %l31 = alloca i64
  %l34 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i1
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l109 = alloca i64
  %l112 = alloca i64
  %l132 = alloca i64
  %l135 = alloca i32
  %l139 = alloca i32
  %l144 = alloca i32
  %l148 = alloca i32
  %l150 = alloca i32
  %l152 = alloca i32
  %l154 = alloca i32
  %l155 = alloca i32
  %l157 = alloca i32
  %l176 = alloca i32
  %l178 = alloca i32
  %l179 = alloca i32
  %l181 = alloca i32
  %l210 = alloca ptr
  %l215 = alloca ptr
  %l220 = alloca ptr
  %l225 = alloca ptr
  %l230 = alloca ptr
  %l235 = alloca ptr
  %l240 = alloca ptr
  %l245 = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 64
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [64 x i32], ptr %l27, i64 0, i64 %t5
  store i32 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l27, i64 256, i1 false)
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l34, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l34, !tbaa !24
  store i64 %t35, ptr %l31, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l31, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = sub i64 %t37, 1
  store i64 %t38, ptr %l43, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t39, 2147483648
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  %t45 = and i1 %t40, %t42
  store i1 %t45, ptr %l46, !tbaa !21
  br label %bb7
bb7:
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t67 = mul i64 4, %t65
  %t70 = add i64 %a2, %t67
  store i64 %t70, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t73, ptr %l61, !tbaa !27
  %t74 = load i64, ptr %l10, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t74
  %t79 = load i8, ptr %t78, !tbaa !32
  %t81 = zext i8 %t79 to i32
  %t82 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t82, ptr %l65, !tbaa !27
  %t83 = load i64, ptr %l10, !tbaa !24
  %t85 = add i64 %t83, 1
  %t87 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i8, ptr %t88, i64 %t85
  %t90 = load i8, ptr %t89, !tbaa !32
  %t92 = zext i8 %t90 to i32
  %t94 = shl i32 %t92, 8
  %t97 = or i32 %t81, %t94
  %t98 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t98, ptr %l72, !tbaa !27
  %t99 = load i64, ptr %l10, !tbaa !24
  %t101 = add i64 %t99, 2
  %t103 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr i8, ptr %t104, i64 %t101
  %t106 = load i8, ptr %t105, !tbaa !32
  %t108 = zext i8 %t106 to i32
  %t110 = shl i32 %t108, 16
  %t113 = or i32 %t97, %t110
  %t114 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t114, ptr %l79, !tbaa !27
  %t115 = load i64, ptr %l10, !tbaa !24
  %t117 = add i64 %t115, 3
  %t119 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i8, ptr %t120, i64 %t117
  %t122 = load i8, ptr %t121, !tbaa !32
  %t124 = zext i8 %t122 to i32
  %t126 = shl i32 %t124, 24
  %t129 = or i32 %t113, %t126
  %t131 = call i32 @llvm.bswap.i32(i32 %t129)
  %t134 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t72
  store i32 %t131, ptr %t134, !tbaa !84
  br label %bb11
bb11:
  %t135 = load i64, ptr %l8, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"std/sha256:Hasher", ptr %t140, i32 0, i32 0
  %t143 = getelementptr [8 x i32], ptr %t142, i64 0, i64 0
  %t144 = load i32, ptr %t143, !tbaa !84
  store i32 %t144, ptr %l11, !tbaa !64
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"std/sha256:Hasher", ptr %t146, i32 0, i32 0
  %t149 = getelementptr [8 x i32], ptr %t148, i64 0, i64 1
  %t150 = load i32, ptr %t149, !tbaa !84
  store i32 %t150, ptr %l12, !tbaa !64
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"std/sha256:Hasher", ptr %t152, i32 0, i32 0
  %t155 = getelementptr [8 x i32], ptr %t154, i64 0, i64 2
  %t156 = load i32, ptr %t155, !tbaa !84
  store i32 %t156, ptr %l13, !tbaa !64
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"std/sha256:Hasher", ptr %t158, i32 0, i32 0
  %t161 = getelementptr [8 x i32], ptr %t160, i64 0, i64 3
  %t162 = load i32, ptr %t161, !tbaa !84
  store i32 %t162, ptr %l14, !tbaa !64
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"std/sha256:Hasher", ptr %t164, i32 0, i32 0
  %t167 = getelementptr [8 x i32], ptr %t166, i64 0, i64 4
  %t168 = load i32, ptr %t167, !tbaa !84
  store i32 %t168, ptr %l15, !tbaa !64
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"std/sha256:Hasher", ptr %t170, i32 0, i32 0
  %t173 = getelementptr [8 x i32], ptr %t172, i64 0, i64 5
  %t174 = load i32, ptr %t173, !tbaa !84
  store i32 %t174, ptr %l16, !tbaa !64
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"std/sha256:Hasher", ptr %t176, i32 0, i32 0
  %t179 = getelementptr [8 x i32], ptr %t178, i64 0, i64 6
  %t180 = load i32, ptr %t179, !tbaa !84
  store i32 %t180, ptr %l17, !tbaa !64
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"std/sha256:Hasher", ptr %t182, i32 0, i32 0
  %t185 = getelementptr [8 x i32], ptr %t184, i64 0, i64 7
  %t186 = load i32, ptr %t185, !tbaa !84
  store i32 %t186, ptr %l18, !tbaa !64
  store i64 0, ptr %l19, !tbaa !24
  store i64 64, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t188 = load i64, ptr %l20, !tbaa !24
  %t189 = load i64, ptr %l19, !tbaa !24
  %t192 = icmp sgt i64 %t188, %t189
  br i1 %t192, label %bb13, label %bb14
bb13:
  %t194 = load i64, ptr %l21, !tbaa !24
  %t196 = icmp sgt i64 %t194, 0
  br i1 %t196, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb18
bb15:
  %t198 = load i64, ptr %l20, !tbaa !24
  %t199 = load i64, ptr %l19, !tbaa !24
  %t202 = sub i64 %t198, %t199
  %t203 = load i64, ptr %l21, !tbaa !24
  %t206 = add i64 %t202, %t203
  %t208 = sub i64 %t206, 1
  %t209 = load i64, ptr %l21, !tbaa !24
  %t212 = sdiv i64 %t208, %t209
  store i64 %t212, ptr %l112, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb17
bb17:
  %t214 = load i64, ptr %l112, !tbaa !24
  store i64 %t214, ptr %l109, !tbaa !24
  br label %bb18
bb18:
  %t215 = load i64, ptr %l109, !tbaa !24
  store i64 %t215, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb19
bb19:
  %t216 = load i64, ptr %l23, !tbaa !24
  %t217 = load i64, ptr %l22, !tbaa !24
  %t220 = icmp slt i64 %t216, %t217
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb20, label %bb21
bb20:
  br label %bb35
bb21:
  br label %bb22
bb22:
  %t224 = load i64, ptr %l19, !tbaa !24
  %t225 = load i64, ptr %l23, !tbaa !24
  %t226 = load i64, ptr %l21, !tbaa !24
  %t229 = mul i64 %t225, %t226
  %t232 = add i64 %t224, %t229
  store i64 %t232, ptr %l24, !tbaa !24
  %t234 = load i64, ptr %l24, !tbaa !24
  %t236 = icmp sge i64 %t234, 16
  br i1 %t236, label %bb23, label %bb24
bb23:
  %t238 = load i64, ptr %l24, !tbaa !24
  store i64 %t238, ptr %l132, !tbaa !24
  %t239 = load i64, ptr %l24, !tbaa !24
  %t241 = sub i64 %t239, 16
  %t243 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t241
  %t244 = load i32, ptr %t243, !tbaa !84
  store i32 %t244, ptr %l135, !tbaa !64
  %t245 = load i64, ptr %l24, !tbaa !24
  %t247 = sub i64 %t245, 15
  %t249 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t247
  %t250 = load i32, ptr %t249, !tbaa !84
  %t252 = call i32 @std_2fsha256_2esigma0(i32 %t250)
  store i32 %t252, ptr %l139
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t253 = load i32, ptr %l135, !tbaa !64
  %t254 = load i32, ptr %l139, !tbaa !64
  %t255 = add i32 %t253, %t254
  %t256 = load i64, ptr %l24, !tbaa !24
  %t258 = sub i64 %t256, 7
  %t260 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t258
  %t261 = load i32, ptr %t260, !tbaa !84
  %t264 = add i32 %t255, %t261
  store i32 %t264, ptr %l144, !tbaa !64
  %t265 = load i64, ptr %l24, !tbaa !24
  %t267 = sub i64 %t265, 2
  %t269 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t267
  %t270 = load i32, ptr %t269, !tbaa !84
  %t272 = call i32 @std_2fsha256_2esigma1(i32 %t270)
  store i32 %t272, ptr %l148
  br label %bb26
bb26:
  %t273 = load i32, ptr %l144, !tbaa !64
  %t274 = load i32, ptr %l148, !tbaa !64
  %t275 = add i32 %t273, %t274
  %t277 = load i64, ptr %l132, !tbaa !24
  %t278 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t277
  store i32 %t275, ptr %t278, !tbaa !84
  br label %bb27
bb27:
  %t279 = load i32, ptr %l18, !tbaa !64
  store i32 %t279, ptr %l150, !tbaa !64
  %t280 = load i32, ptr %l15, !tbaa !64
  %t282 = call i32 @std_2fsha256_2erotr(i32 %t280, i32 6)
  store i32 %t282, ptr %l152
  br label %bb28
bb28:
  %t283 = load i32, ptr %l15, !tbaa !64
  %t285 = call i32 @std_2fsha256_2erotr(i32 %t283, i32 11)
  store i32 %t285, ptr %l154
  br label %bb29
bb29:
  %t286 = load i32, ptr %l152, !tbaa !64
  %t287 = load i32, ptr %l154, !tbaa !64
  %t288 = xor i32 %t286, %t287
  store i32 %t288, ptr %l155, !tbaa !64
  %t289 = load i32, ptr %l15, !tbaa !64
  %t291 = call i32 @std_2fsha256_2erotr(i32 %t289, i32 25)
  store i32 %t291, ptr %l157
  br label %bb30
bb30:
  %t292 = load i32, ptr %l155, !tbaa !64
  %t293 = load i32, ptr %l157, !tbaa !64
  %t294 = xor i32 %t292, %t293
  %t295 = load i32, ptr %l150, !tbaa !64
  %t297 = add i32 %t295, %t294
  %t298 = load i32, ptr %l15, !tbaa !64
  %t299 = load i32, ptr %l16, !tbaa !64
  %t302 = and i32 %t298, %t299
  %t303 = load i32, ptr %l15, !tbaa !64
  %t305 = xor i32 %t303, -1
  %t306 = load i32, ptr %l17, !tbaa !64
  %t309 = and i32 %t305, %t306
  %t312 = xor i32 %t302, %t309
  %t315 = add i32 %t297, %t312
  %t316 = load i64, ptr %l24, !tbaa !24
  %t318 = getelementptr [64 x i32], ptr @G_2estd_2fsha256_2ek, i64 0, i64 %t316
  %t319 = load i32, ptr %t318, !tbaa !84
  %t322 = add i32 %t315, %t319
  %t323 = load i64, ptr %l24, !tbaa !24
  %t325 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t323
  %t326 = load i32, ptr %t325, !tbaa !84
  %t329 = add i32 %t322, %t326
  store i32 %t329, ptr %l25, !tbaa !64
  %t331 = load i32, ptr %l11, !tbaa !64
  %t333 = call i32 @std_2fsha256_2erotr(i32 %t331, i32 2)
  store i32 %t333, ptr %l176
  br label %bb31
bb31:
  %t334 = load i32, ptr %l11, !tbaa !64
  %t336 = call i32 @std_2fsha256_2erotr(i32 %t334, i32 13)
  store i32 %t336, ptr %l178
  br label %bb32
bb32:
  %t337 = load i32, ptr %l176, !tbaa !64
  %t338 = load i32, ptr %l178, !tbaa !64
  %t339 = xor i32 %t337, %t338
  store i32 %t339, ptr %l179, !tbaa !64
  %t340 = load i32, ptr %l11, !tbaa !64
  %t342 = call i32 @std_2fsha256_2erotr(i32 %t340, i32 22)
  store i32 %t342, ptr %l181
  br label %bb33
bb33:
  %t343 = load i32, ptr %l179, !tbaa !64
  %t344 = load i32, ptr %l181, !tbaa !64
  %t345 = xor i32 %t343, %t344
  %t346 = load i32, ptr %l11, !tbaa !64
  %t347 = load i32, ptr %l12, !tbaa !64
  %t350 = and i32 %t346, %t347
  %t351 = load i32, ptr %l11, !tbaa !64
  %t352 = load i32, ptr %l13, !tbaa !64
  %t355 = and i32 %t351, %t352
  %t358 = xor i32 %t350, %t355
  %t359 = load i32, ptr %l12, !tbaa !64
  %t360 = load i32, ptr %l13, !tbaa !64
  %t363 = and i32 %t359, %t360
  %t366 = xor i32 %t358, %t363
  %t369 = add i32 %t345, %t366
  %t371 = load i32, ptr %l17, !tbaa !64
  store i32 %t371, ptr %l18, !tbaa !64
  %t373 = load i32, ptr %l16, !tbaa !64
  store i32 %t373, ptr %l17, !tbaa !64
  %t375 = load i32, ptr %l15, !tbaa !64
  store i32 %t375, ptr %l16, !tbaa !64
  %t377 = load i32, ptr %l14, !tbaa !64
  %t378 = load i32, ptr %l25, !tbaa !64
  %t381 = add i32 %t377, %t378
  store i32 %t381, ptr %l15, !tbaa !64
  %t383 = load i32, ptr %l13, !tbaa !64
  store i32 %t383, ptr %l14, !tbaa !64
  %t385 = load i32, ptr %l12, !tbaa !64
  store i32 %t385, ptr %l13, !tbaa !64
  %t387 = load i32, ptr %l11, !tbaa !64
  store i32 %t387, ptr %l12, !tbaa !64
  %t389 = load i32, ptr %l25, !tbaa !64
  %t393 = add i32 %t389, %t369
  store i32 %t393, ptr %l11, !tbaa !64
  br label %bb34
bb34:
  %t395 = load i64, ptr %l23, !tbaa !24
  %t398 = add i64 %t395, 1
  store i64 %t398, ptr %l23, !tbaa !24
  br label %bb19
bb35:
  %t400 = load ptr, ptr %l0, !tbaa !29
  store ptr %t400, ptr %l210, !tbaa !29
  %t401 = load ptr, ptr %l210, !tbaa !29
  %t402 = getelementptr %"std/sha256:Hasher", ptr %t401, i32 0, i32 0
  %t403 = getelementptr [8 x i32], ptr %t402, i64 0, i64 0
  %t404 = load i32, ptr %t403, !tbaa !84
  %t406 = load i32, ptr %l11, !tbaa !64
  %t409 = add i32 %t404, %t406
  %t411 = load ptr, ptr %l210, !tbaa !29
  %t412 = getelementptr %"std/sha256:Hasher", ptr %t411, i32 0, i32 0
  %t413 = getelementptr [8 x i32], ptr %t412, i64 0, i64 0
  store i32 %t409, ptr %t413, !tbaa !84
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l215, !tbaa !29
  %t415 = load ptr, ptr %l215, !tbaa !29
  %t416 = getelementptr %"std/sha256:Hasher", ptr %t415, i32 0, i32 0
  %t417 = getelementptr [8 x i32], ptr %t416, i64 0, i64 1
  %t418 = load i32, ptr %t417, !tbaa !84
  %t420 = load i32, ptr %l12, !tbaa !64
  %t423 = add i32 %t418, %t420
  %t425 = load ptr, ptr %l215, !tbaa !29
  %t426 = getelementptr %"std/sha256:Hasher", ptr %t425, i32 0, i32 0
  %t427 = getelementptr [8 x i32], ptr %t426, i64 0, i64 1
  store i32 %t423, ptr %t427, !tbaa !84
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l220, !tbaa !29
  %t429 = load ptr, ptr %l220, !tbaa !29
  %t430 = getelementptr %"std/sha256:Hasher", ptr %t429, i32 0, i32 0
  %t431 = getelementptr [8 x i32], ptr %t430, i64 0, i64 2
  %t432 = load i32, ptr %t431, !tbaa !84
  %t434 = load i32, ptr %l13, !tbaa !64
  %t437 = add i32 %t432, %t434
  %t439 = load ptr, ptr %l220, !tbaa !29
  %t440 = getelementptr %"std/sha256:Hasher", ptr %t439, i32 0, i32 0
  %t441 = getelementptr [8 x i32], ptr %t440, i64 0, i64 2
  store i32 %t437, ptr %t441, !tbaa !84
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l225, !tbaa !29
  %t443 = load ptr, ptr %l225, !tbaa !29
  %t444 = getelementptr %"std/sha256:Hasher", ptr %t443, i32 0, i32 0
  %t445 = getelementptr [8 x i32], ptr %t444, i64 0, i64 3
  %t446 = load i32, ptr %t445, !tbaa !84
  %t448 = load i32, ptr %l14, !tbaa !64
  %t451 = add i32 %t446, %t448
  %t453 = load ptr, ptr %l225, !tbaa !29
  %t454 = getelementptr %"std/sha256:Hasher", ptr %t453, i32 0, i32 0
  %t455 = getelementptr [8 x i32], ptr %t454, i64 0, i64 3
  store i32 %t451, ptr %t455, !tbaa !84
  %t456 = load ptr, ptr %l0, !tbaa !29
  store ptr %t456, ptr %l230, !tbaa !29
  %t457 = load ptr, ptr %l230, !tbaa !29
  %t458 = getelementptr %"std/sha256:Hasher", ptr %t457, i32 0, i32 0
  %t459 = getelementptr [8 x i32], ptr %t458, i64 0, i64 4
  %t460 = load i32, ptr %t459, !tbaa !84
  %t462 = load i32, ptr %l15, !tbaa !64
  %t465 = add i32 %t460, %t462
  %t467 = load ptr, ptr %l230, !tbaa !29
  %t468 = getelementptr %"std/sha256:Hasher", ptr %t467, i32 0, i32 0
  %t469 = getelementptr [8 x i32], ptr %t468, i64 0, i64 4
  store i32 %t465, ptr %t469, !tbaa !84
  %t470 = load ptr, ptr %l0, !tbaa !29
  store ptr %t470, ptr %l235, !tbaa !29
  %t471 = load ptr, ptr %l235, !tbaa !29
  %t472 = getelementptr %"std/sha256:Hasher", ptr %t471, i32 0, i32 0
  %t473 = getelementptr [8 x i32], ptr %t472, i64 0, i64 5
  %t474 = load i32, ptr %t473, !tbaa !84
  %t476 = load i32, ptr %l16, !tbaa !64
  %t479 = add i32 %t474, %t476
  %t481 = load ptr, ptr %l235, !tbaa !29
  %t482 = getelementptr %"std/sha256:Hasher", ptr %t481, i32 0, i32 0
  %t483 = getelementptr [8 x i32], ptr %t482, i64 0, i64 5
  store i32 %t479, ptr %t483, !tbaa !84
  %t484 = load ptr, ptr %l0, !tbaa !29
  store ptr %t484, ptr %l240, !tbaa !29
  %t485 = load ptr, ptr %l240, !tbaa !29
  %t486 = getelementptr %"std/sha256:Hasher", ptr %t485, i32 0, i32 0
  %t487 = getelementptr [8 x i32], ptr %t486, i64 0, i64 6
  %t488 = load i32, ptr %t487, !tbaa !84
  %t490 = load i32, ptr %l17, !tbaa !64
  %t493 = add i32 %t488, %t490
  %t495 = load ptr, ptr %l240, !tbaa !29
  %t496 = getelementptr %"std/sha256:Hasher", ptr %t495, i32 0, i32 0
  %t497 = getelementptr [8 x i32], ptr %t496, i64 0, i64 6
  store i32 %t493, ptr %t497, !tbaa !84
  %t498 = load ptr, ptr %l0, !tbaa !29
  store ptr %t498, ptr %l245, !tbaa !29
  %t499 = load ptr, ptr %l245, !tbaa !29
  %t500 = getelementptr %"std/sha256:Hasher", ptr %t499, i32 0, i32 0
  %t501 = getelementptr [8 x i32], ptr %t500, i64 0, i64 7
  %t502 = load i32, ptr %t501, !tbaa !84
  %t504 = load i32, ptr %l18, !tbaa !64
  %t507 = add i32 %t502, %t504
  %t509 = load ptr, ptr %l245, !tbaa !29
  %t510 = getelementptr %"std/sha256:Hasher", ptr %t509, i32 0, i32 0
  %t511 = getelementptr [8 x i32], ptr %t510, i64 0, i64 7
  store i32 %t507, ptr %t511, !tbaa !84
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @llvm.bswap.i32(i32)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { i64, ptr } @std_2fsha256_2eSum(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/sha256:Hasher" @std_2fsha256_3aHasher_2ector(ptr %v0)
declare void @std_2fsha256_2estd_2fsha256_3aHasher_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fsha256_2erotr(i32 %a0, i32 %a1)
@G_2estd_2fsha256_2ek = available_externally constant <{ [256 x i8] }> <{ [256 x i8] c"\98\2F\8A\42\91\44\37\71\CF\FB\C0\B5\A5\DB\B5\E9\5B\C2\56\39\F1\11\F1\59\A4\82\3F\92\D5\5E\1C\AB\98\AA\07\D8\01\5B\83\12\BE\85\31\24\C3\7D\0C\55\74\5D\BE\72\FE\B1\DE\80\A7\06\DC\9B\74\F1\9B\C1\C1\69\9B\E4\86\47\BE\EF\C6\9D\C1\0F\CC\A1\0C\24\6F\2C\E9\2D\AA\84\74\4A\DC\A9\B0\5C\DA\88\F9\76\52\51\3E\98\6D\C6\31\A8\C8\27\03\B0\C7\7F\59\BF\F3\0B\E0\C6\47\91\A7\D5\51\63\CA\06\67\29\29\14\85\0A\B7\27\38\21\1B\2E\FC\6D\2C\4D\13\0D\38\53\54\73\0A\65\BB\0A\6A\76\2E\C9\C2\81\85\2C\72\92\A1\E8\BF\A2\4B\66\1A\A8\70\8B\4B\C2\A3\51\6C\C7\19\E8\92\D1\24\06\99\D6\85\35\0E\F4\70\A0\6A\10\16\C1\A4\19\08\6C\37\1E\4C\77\48\27\B5\BC\B0\34\B3\0C\1C\39\4A\AA\D8\4E\4F\CA\9C\5B\F3\6F\2E\68\EE\82\8F\74\6F\63\A5\78\14\78\C8\84\08\02\C7\8C\FA\FF\BE\90\EB\6C\50\A4\F7\A3\F9\BE\F2\78\71\C6" }>, align 64

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
