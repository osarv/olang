; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/io:Lines" = type { i32, %"std/prelude/input:InputBuffer" }
%"std/prelude/input:InputBuffer" = type { i32, i1, { i64, ptr }, i64, i64 }
%"std/io:Reader" = type { i32, %"std/prelude/input:InputBuffer" }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, { i32, { i64, [1 x i64] } } }
@G_2estd_2fio_2eStderr = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2estd_2fio_2eStdin = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2estd_2fio_2eStdout = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2estd_2fio_2ebinary = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
define dso_local i32 @std_2fio_2eFormatInt(ptr %v0, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %rv = alloca i32
  store i64 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  store i1 %t3, ptr %l2, !tbaa !21
  %t5 = load i1, ptr %l2, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l0, !tbaa !24
  store i64 %t7, ptr %l11, !tbaa !24
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0, !tbaa !24
  %t11 = sub i64 0, %t9
  store i64 %t11, ptr %l11, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l11, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  store i32 0, ptr %l4, !tbaa !23
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t14, ptr %l15, !tbaa !27
  %t15 = load i32, ptr %l4, !tbaa !23
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = srem i64 %t16, 10
  %t20 = sub i64 0, %t18
  %t22 = trunc i64 %t20 to i8
  %t25 = add i8 %t22, 48
  %t28 = sext i32 %t15 to i64
  %t29 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr i8, ptr %t30, i64 %t28
  store i8 %t25, ptr %t31, !tbaa !32
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = sdiv i64 %t32, 10
  store i64 %t35, ptr %l3, !tbaa !24
  %t37 = load i32, ptr %l4, !tbaa !23
  %t40 = add i32 %t37, 1
  store i32 %t40, ptr %l4, !tbaa !23
  br label %bb5
bb5:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb6, label %bb7
bb6:
  br label %bb9
bb7:
  br label %bb8
bb8:
  br label %bb4
bb9:
  %t48 = load i1, ptr %l2, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %l33, !tbaa !27
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = sext i32 %t51 to i64
  %t55 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 %t54
  store i8 45, ptr %t57, !tbaa !32
  %t58 = load i32, ptr %l4, !tbaa !23
  %t61 = add i32 %t58, 1
  store i32 %t61, ptr %l4, !tbaa !23
  br label %bb12
bb11:
  br label %bb12
bb12:
  store i32 0, ptr %l5, !tbaa !23
  %t63 = load i32, ptr %l4, !tbaa !23
  %t65 = sub i32 %t63, 1
  store i32 %t65, ptr %l6, !tbaa !23
  br label %bb13
bb13:
  %t67 = load i32, ptr %l5, !tbaa !23
  %t68 = load i32, ptr %l6, !tbaa !23
  %t71 = icmp slt i32 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t75, ptr %l45, !tbaa !27
  %t76 = load i32, ptr %l5, !tbaa !23
  %t78 = sext i32 %t76 to i64
  %t79 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 %t78
  %t82 = load i8, ptr %t81, !tbaa !32
  %t84 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t84, ptr %l48, !tbaa !27
  %t85 = load i32, ptr %l5, !tbaa !23
  %t86 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t86, ptr %l50, !tbaa !27
  %t87 = load i32, ptr %l6, !tbaa !23
  %t89 = sext i32 %t87 to i64
  %t90 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i8, ptr %t91, i64 %t89
  %t93 = load i8, ptr %t92, !tbaa !32
  %t96 = sext i32 %t85 to i64
  %t97 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i8, ptr %t98, i64 %t96
  store i8 %t93, ptr %t99, !tbaa !32
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t100, ptr %l53, !tbaa !27
  %t101 = load i32, ptr %l6, !tbaa !23
  %t105 = sext i32 %t101 to i64
  %t106 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i8, ptr %t107, i64 %t105
  store i8 %t82, ptr %t108, !tbaa !32
  %t109 = load i32, ptr %l5, !tbaa !23
  %t112 = add i32 %t109, 1
  store i32 %t112, ptr %l5, !tbaa !23
  %t114 = load i32, ptr %l6, !tbaa !23
  %t117 = sub i32 %t114, 1
  store i32 %t117, ptr %l6, !tbaa !23
  br label %bb17
bb17:
  br label %bb13
bb18:
  %t119 = load i32, ptr %l4, !tbaa !23
  store i32 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/io:Lines" @std_2fio_2eLines_2esized(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i32
  %l2 = alloca %"std/io:Lines"
  %l6 = alloca %"std/io:Lines"
  %l7 = alloca i64
  %l11 = alloca %"std/prelude/input:InputBuffer"
  %l13 = alloca %"std/prelude/input:InputBuffer"
  %rv = alloca %"std/io:Lines"
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 4, i64 8)
  store i32 %t1, ptr %t3
  %t5 = insertvalue { ptr, ptr } undef, ptr %t3, 0
  %t6 = icmp ne ptr %t3, null
  %t7 = select i1 %t6, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t8 = insertvalue { ptr, ptr } %t5, ptr %t7, 1
  %t10 = call %"std/io:Lines" @std_2fio_3aLines_2ector(ptr %v0, ptr %v0, { ptr, ptr } %t8)
  store %"std/io:Lines" %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load %"std/io:Lines", ptr %l6
  store %"std/io:Lines" %t11, ptr %l2
  %t12 = call ptr @__olang_scope_hold(ptr %v0)
  %t13 = ptrtoint ptr %t12 to i64
  store i64 %t13, ptr %l7, !tbaa !24
  %t14 = load i1, ptr @olang_2esole_2estd_2fio_3aLines_2e1
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = call ptr @__olang_region_make(ptr %v0)
  %t17 = ptrtoint ptr %t16 to i64
  store i64 %t17, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t18 = load i32, ptr %l0, !tbaa !23
  %t20 = load i64, ptr %l7
  %t21 = inttoptr i64 %t20 to ptr
  %t24 = call %"std/prelude/input:InputBuffer" @std_2fprelude_2finput_3aInputBuffer_2ector(ptr %t21, i32 %t18, i64 %a1, i1 false)
  store %"std/prelude/input:InputBuffer" %t24, ptr %l11
  br label %bb4
bb4:
  %t25 = load i1, ptr @olang_2esole_2estd_2fio_3aLines_2e1
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load i64, ptr %l7
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = getelementptr %"std/prelude/input:InputBuffer", ptr %l11, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = call ptr @__olang_region_or(ptr %t31, ptr null)
  %t33 = call ptr @__olang_region_home(ptr %t32)
  %t34 = icmp ne ptr %t33, null
  %t35 = select i1 %t34, ptr %t33, ptr null
  call void @__olang_region_settle_in(ptr %t28, ptr %t35)
  br label %bb6
bb6:
  %t36 = getelementptr %"std/io:Lines", ptr %l2, i32 0, i32 1
  %t37 = load %"std/prelude/input:InputBuffer", ptr %t36
  store %"std/prelude/input:InputBuffer" %t37, ptr %l13
  %t38 = load %"std/prelude/input:InputBuffer", ptr %l11
  %t39 = getelementptr %"std/io:Lines", ptr %l2, i32 0, i32 1
  store %"std/prelude/input:InputBuffer" %t38, ptr %t39
  %t40 = load i1, ptr @olang_2esole_2estd_2fio_3aLines_2e1
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = getelementptr %"std/prelude/input:InputBuffer", ptr %l13, i32 0, i32 2
  %t43 = load { i64, ptr }, ptr %t42
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = call ptr @__olang_region_or(ptr %t44, ptr null)
  %t46 = call ptr @__olang_region_home(ptr %t45)
  %t47 = icmp ne ptr %t46, null
  %t48 = select i1 %t47, ptr %t46, ptr null
  call void @__olang_region_drop(ptr %t48)
  store %"std/prelude/input:InputBuffer" zeroinitializer, ptr %l13
  br label %bb8
bb8:
  %t49 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t49, label %bb9, label %bb10
bb9:
  %t51 = getelementptr %"std/prelude/input:InputBuffer", ptr %l13, i32 0, i32 2
  %t52 = load { i64, ptr }, ptr %t51
  %t53 = extractvalue { i64, ptr } %t52, 0
  %t54 = extractvalue { i64, ptr } %t52, 1
  call void @__olang_region_release_part(ptr %t54, i64 %t53)
  store { i64, ptr } zeroinitializer, ptr %t51
  br label %bb10
bb10:
  %t55 = load %"std/io:Lines", ptr %l2
  store %"std/io:Lines" %t55, ptr %rv
  br label %ret
ret:
  %rr = load %"std/io:Lines", ptr %rv
  ret %"std/io:Lines" %rr
}

define dso_local { i32, { i64, ptr } } @std_2fio_2eRead(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l5 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %rv = alloca { i32, { i64, ptr } }
  %t11 = alloca { i64, [1 x i64] }, align 8
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i64 @std_2fio_2erawRead(ptr %v0, i32 %a0, { i64, ptr } %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, [1 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [1 x i64] }, ptr %t11, i32 0, i32 0
  store i64 0, ptr %t12
  %t13 = load { i64, [1 x i64] }, ptr %t11
  %t14 = call ptr @__olang_errpay_push()
  %t15 = ptrtoint ptr %t14 to i64
  %t18 = inttoptr i64 %t15 to ptr
  %t19 = call ptr @__olang_scope_alloc_a(ptr %t18, i64 16, i64 8)
  store { i64, [1 x i64] } %t13, ptr %t19
  call void @__olang_errpay_set(ptr %t19)
  %t22 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l12, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  store i64 %t24, ptr %l13, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l14, !tbaa !24
  %t27 = icmp sge i64 0, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i64, ptr %l13, !tbaa !24
  %t30 = icmp sle i64 0, %t29
  br i1 %t30, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e183f6af0815be24_39313b6101d20ca8)
  unreachable
bb7:
  %t32 = load i64, ptr %l13, !tbaa !24
  %t33 = load i64, ptr %l14, !tbaa !24
  %t34 = icmp sle i64 %t32, %t33
  br i1 %t34, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_e183f6af0815be24_39313b6101d20ca8)
  unreachable
bb9:
  %t36 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = load i64, ptr %l13, !tbaa !24
  %t39 = getelementptr i8, ptr %t37, i64 0
  %t40 = sub i64 %t38, 0
  %t41 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t39, 1
  %t44 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t42, 1
  store { i32, { i64, ptr } } %t44, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e183f6af0815be24_39313b6101d20ca8)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local %"std/io:Reader" @std_2fio_2eReader_2esized(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i32
  %l2 = alloca %"std/io:Reader"
  %l6 = alloca %"std/io:Reader"
  %l7 = alloca i64
  %l11 = alloca %"std/prelude/input:InputBuffer"
  %l13 = alloca %"std/prelude/input:InputBuffer"
  %rv = alloca %"std/io:Reader"
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 4, i64 8)
  store i32 %t1, ptr %t3
  %t5 = insertvalue { ptr, ptr } undef, ptr %t3, 0
  %t6 = icmp ne ptr %t3, null
  %t7 = select i1 %t6, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t8 = insertvalue { ptr, ptr } %t5, ptr %t7, 1
  %t10 = call %"std/io:Reader" @std_2fio_3aReader_2ector(ptr %v0, ptr %v0, { ptr, ptr } %t8)
  store %"std/io:Reader" %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load %"std/io:Reader", ptr %l6
  store %"std/io:Reader" %t11, ptr %l2
  %t12 = call ptr @__olang_scope_hold(ptr %v0)
  %t13 = ptrtoint ptr %t12 to i64
  store i64 %t13, ptr %l7, !tbaa !24
  %t14 = load i1, ptr @olang_2esole_2estd_2fio_3aReader_2e1
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = call ptr @__olang_region_make(ptr %v0)
  %t17 = ptrtoint ptr %t16 to i64
  store i64 %t17, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t18 = load i32, ptr %l0, !tbaa !23
  %t20 = load i64, ptr %l7
  %t21 = inttoptr i64 %t20 to ptr
  %t24 = call %"std/prelude/input:InputBuffer" @std_2fprelude_2finput_3aInputBuffer_2ector(ptr %t21, i32 %t18, i64 %a1, i1 false)
  store %"std/prelude/input:InputBuffer" %t24, ptr %l11
  br label %bb4
bb4:
  %t25 = load i1, ptr @olang_2esole_2estd_2fio_3aReader_2e1
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load i64, ptr %l7
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = getelementptr %"std/prelude/input:InputBuffer", ptr %l11, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = call ptr @__olang_region_or(ptr %t31, ptr null)
  %t33 = call ptr @__olang_region_home(ptr %t32)
  %t34 = icmp ne ptr %t33, null
  %t35 = select i1 %t34, ptr %t33, ptr null
  call void @__olang_region_settle_in(ptr %t28, ptr %t35)
  br label %bb6
bb6:
  %t36 = getelementptr %"std/io:Reader", ptr %l2, i32 0, i32 1
  %t37 = load %"std/prelude/input:InputBuffer", ptr %t36
  store %"std/prelude/input:InputBuffer" %t37, ptr %l13
  %t38 = load %"std/prelude/input:InputBuffer", ptr %l11
  %t39 = getelementptr %"std/io:Reader", ptr %l2, i32 0, i32 1
  store %"std/prelude/input:InputBuffer" %t38, ptr %t39
  %t40 = load i1, ptr @olang_2esole_2estd_2fio_3aReader_2e1
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = getelementptr %"std/prelude/input:InputBuffer", ptr %l13, i32 0, i32 2
  %t43 = load { i64, ptr }, ptr %t42
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = call ptr @__olang_region_or(ptr %t44, ptr null)
  %t46 = call ptr @__olang_region_home(ptr %t45)
  %t47 = icmp ne ptr %t46, null
  %t48 = select i1 %t47, ptr %t46, ptr null
  call void @__olang_region_drop(ptr %t48)
  store %"std/prelude/input:InputBuffer" zeroinitializer, ptr %l13
  br label %bb8
bb8:
  %t49 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t49, label %bb9, label %bb10
bb9:
  %t51 = getelementptr %"std/prelude/input:InputBuffer", ptr %l13, i32 0, i32 2
  %t52 = load { i64, ptr }, ptr %t51
  %t53 = extractvalue { i64, ptr } %t52, 0
  %t54 = extractvalue { i64, ptr } %t52, 1
  call void @__olang_region_release_part(ptr %t54, i64 %t53)
  store { i64, ptr } zeroinitializer, ptr %t51
  br label %bb10
bb10:
  %t55 = load %"std/io:Reader", ptr %l2
  store %"std/io:Reader" %t55, ptr %rv
  br label %ret
ret:
  %rr = load %"std/io:Reader", ptr %rv
  ret %"std/io:Reader" %rr
}

define dso_local i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l22 = alloca i64
  %rv = alloca i32
  %t47 = alloca { i64, [1 x i64] }, align 8
  %t63 = alloca { i64, [1 x i64] }, align 8
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i32 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l10, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  store i64 %t10, ptr %l11, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t11, 0
  store i64 %t14, ptr %l14, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = icmp sge i64 %t17, 0
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l11, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = icmp sle i64 %t20, %t21
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_405125a8bfc97357_6687826239f87cdb)
  unreachable
bb7:
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp sle i64 %t24, %t25
  br i1 %t26, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_405125a8bfc97357_6687826239f87cdb)
  unreachable
bb9:
  %t28 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l11, !tbaa !24
  %t31 = load i64, ptr %l14, !tbaa !24
  %t32 = getelementptr i8, ptr %t29, i64 %t30
  %t33 = sub i64 %t31, %t30
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t41 = call i64 @std_2fio_2erawWrite(ptr %v0, i32 %a0, { i64, ptr } %t35)
  store i64 %t41, ptr %l22
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_405125a8bfc97357_6687826239f87cdb)
  unreachable
bb11:
  %t42 = load i64, ptr %l22, !tbaa !24
  store i64 %t42, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t43, 0
  br i1 %t45, label %bb12, label %bb13
bb12:
  store { i64, [1 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [1 x i64] }, ptr %t47, i32 0, i32 0
  store i64 0, ptr %t48
  %t49 = load { i64, [1 x i64] }, ptr %t47
  %t50 = call ptr @__olang_errpay_push()
  %t51 = ptrtoint ptr %t50 to i64
  %t54 = inttoptr i64 %t51 to ptr
  %t55 = call ptr @__olang_scope_alloc_a(ptr %t54, i64 16, i64 8)
  store { i64, [1 x i64] } %t49, ptr %t55
  call void @__olang_errpay_set(ptr %t55)
  store i32 65536, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = icmp eq i64 %t58, 0
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t62 = load i64, ptr %l3, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [1 x i64] }, ptr %t63, i32 0, i32 0
  store i64 1, ptr %t64
  %t66 = insertvalue { i64 } undef, i64 %t62, 0
  %t67 = getelementptr { i64, [1 x i64] }, ptr %t63, i32 0, i32 1
  store { i64 } %t66, ptr %t67
  %t68 = load { i64, [1 x i64] }, ptr %t63
  %t69 = call ptr @__olang_errpay_push()
  %t70 = ptrtoint ptr %t69 to i64
  %t73 = inttoptr i64 %t70 to ptr
  %t74 = call ptr @__olang_scope_alloc_a(ptr %t73, i64 16, i64 8)
  store { i64, [1 x i64] } %t68, ptr %t74
  call void @__olang_errpay_set(ptr %t74)
  store i32 65537, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = add i64 %t77, %t79
  store i64 %t82, ptr %l3, !tbaa !24
  br label %bb18
bb18:
  %t84 = load i64, ptr %l3, !tbaa !24
  %t85 = load i64, ptr %l2, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb19, label %bb20
bb19:
  br label %bb22
bb20:
  br label %bb21
bb21:
  br label %bb4
bb22:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2echeckReadIsEmpty(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i32, { i64, ptr } } @std_2fio_2eRead(ptr %v0, ptr %v0, i32 %a0, { i64, ptr } %a1)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  store i32 %t19, ptr %rv
  br label %ret
bb3:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t26 = icmp eq i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5d46b41c36e8feff_84fddb7c6ef404db)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ecloseFd(i32 %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @close(i32 %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2fio_2edrained(ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/io:Lines"
  %l7 = alloca %"std/io:Lines"
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l17 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l1, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 4, i64 8)
  store i32 %a0, ptr %t3
  %t5 = insertvalue { ptr, ptr } undef, ptr %t3, 0
  %t6 = icmp ne ptr %t3, null
  %t7 = select i1 %t6, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t8 = insertvalue { ptr, ptr } %t5, ptr %t7, 1
  %t10 = call %"std/io:Lines" @std_2fio_3aLines_2ector(ptr %s1, ptr %s1, { ptr, ptr } %t8)
  store %"std/io:Lines" %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load %"std/io:Lines", ptr %l7
  store %"std/io:Lines" %t11, ptr %l2
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %s1, ptr %s2, ptr %l2)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l11
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb4, label %ok.17, !prof !99
ok.17:
  store { i64, ptr } %t14, ptr %l10
  br label %bb3
bb3:
  %t18 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t18, ptr %l8, !tbaa !27
  br label %bb13
bb4:
  %t19 = load i32, ptr %l11, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 2
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load i32, ptr %l11, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb7, label %bb8
bb6:
  %t29 = load i32, ptr %l11, !tbaa !23
  %t30 = ashr i32 %t29, 16
  %t32 = icmp eq i32 %t30, 1
  store i1 %t32, ptr %l17, !tbaa !21
  %t33 = load i32, ptr %l11, !tbaa !23
  %t34 = ashr i32 %t33, 16
  %t36 = icmp eq i32 %t34, 1
  br i1 %t36, label %bb10, label %bb11
bb7:
  call void @__olang_errpay_pop()
  br label %bb8
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb10:
  call void @__olang_errpay_pop()
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  call void @__olang_check_failed(ptr @olang_loc_65126f5b67a1f66c_44d990074c227388)
  unreachable
bb13:
  %t38 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t39, 1
  %t43 = extractvalue { i64, ptr } %t39, 0
  %t45 = extractvalue { i64, ptr } %t38, 1
  %t46 = extractvalue { i64, ptr } %t38, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t42, i64 %t43)
  %t52 = getelementptr i8, ptr %t51, i64 %t43
  call void @olang_textcopy(ptr %t52, ptr %t45, i64 %t46)
  %t53 = getelementptr i8, ptr %t52, i64 %t46
  call void @olang_textcopy(ptr %t53, ptr %t48, i64 %t49)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t51, 1
  store { i64, ptr } %t55, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %bb2
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fio_2efailedFlushes(i32 %a0) #0 {
entry:
  %l1 = alloca %"std/io:Writer"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca %"std/io:Writer"
  %l14 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 4, i64 8)
  store i32 %a0, ptr %t3
  %t5 = insertvalue { ptr, ptr } undef, ptr %t3, 0
  %t6 = icmp ne ptr %t3, null
  %t7 = select i1 %t6, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t8 = insertvalue { ptr, ptr } %t5, ptr %t7, 1
  %t10 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, ptr %s0, { ptr, ptr } %t8, i64 4)
  store %"std/io:Writer" %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load %"std/io:Writer", ptr %l12
  store %"std/io:Writer" %t11, ptr %l1
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t13)
  br label %bb2
bb2:
  call void @std_2fio_2estd_2fio_3aWriter_2eWriteChar(ptr %s0, ptr %l1, i8 33)
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l22, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l22, !tbaa !24
  store i64 %t41, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l19, !tbaa !24
  store i64 %t42, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb11, label %bb12
bb11:
  br label %bb28
bb12:
  br label %bb13
bb13:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l8, !tbaa !24
  %t62 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l1)
  store i32 %t62, ptr %l41
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb15, label %ok.64, !prof !99
ok.64:
  br label %bb14
bb14:
  br label %bb26
bb15:
  %t65 = load i32, ptr %l41, !tbaa !23
  %t66 = icmp eq i32 %t65, 65536
  br i1 %t66, label %bb16, label %bb17
bb16:
  %t68 = load i32, ptr %l41, !tbaa !23
  %t69 = ashr i32 %t68, 16
  %t71 = icmp eq i32 %t69, 1
  br i1 %t71, label %bb18, label %bb19
bb17:
  %t73 = load i32, ptr %l41, !tbaa !23
  %t74 = icmp eq i32 %t73, 65537
  br i1 %t74, label %bb21, label %bb22
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t76 = load i64, ptr %l2, !tbaa !24
  %t79 = add i64 %t76, 1
  store i64 %t79, ptr %l2, !tbaa !24
  br label %bb26
bb21:
  %t81 = load i32, ptr %l41, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  br i1 %t84, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e6fc1695886d91da_b063287e95dbbab6)
  unreachable
bb23:
  call void @__olang_errpay_pop()
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t86 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb10
bb28:
  %t91 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t91, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fio_2eioChurn() #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !24
  store i64 0, ptr %l1, !tbaa !24
  store i64 300, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l11, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  %t49 = call i64 @__olang_fmt_i64(ptr null, i64 %t45)
  %t50 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t52)
  %t54 = call i64 @__olang_fmt_i64(ptr %t53, i64 %t45)
  %t55 = getelementptr i8, ptr %t53, i64 %t49
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = load i64, ptr %l0, !tbaa !24
  %t62 = extractvalue { i64, ptr } %t57, 0
  %t65 = add i64 %t59, %t62
  store i64 %t65, ptr %l0, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = add i64 %t67, 1
  store i64 %t70, ptr %l5, !tbaa !24
  br label %bb7
bb12:
  %t72 = load i64, ptr %l0, !tbaa !24
  store i64 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @std_2fio_2eopenReadOnly(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load i32, ptr @G_2estd_2fio_2ebinary, !tbaa !23
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t8 = call i32 (ptr, i32, ...) @open(ptr %t5, i32 %t3)
  store i32 %t8, ptr %l4
  br label %bb1
bb1:
  %t9 = load i32, ptr %l4, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @std_2fio_2erawRead(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l7 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t9 = extractvalue { i64, ptr } %t2, 1
  %t10 = extractvalue { i64, ptr } %t2, 0
  %t12 = call i64 @read(i32 %a0, ptr %t9, i64 %t5)
  store i64 %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = load i64, ptr %l7, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fio_2erawWrite(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l7 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t9 = extractvalue { i64, ptr } %t2, 1
  %t10 = extractvalue { i64, ptr } %t2, 0
  %t12 = call i64 @write(i32 %a0, ptr %t9, i64 %t5)
  store i64 %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = load i64, ptr %l7, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @std_2fio_2estd_2fio_3aLines_2eBuffered(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Lines", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp eq i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call i1 @std_2fprelude_2finput_2eStdinBuffered()
  store i1 %t8, ptr %l5
  br label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/io:Lines", ptr %t9, i32 0, i32 1
  %t13 = call i1 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBuffered(ptr %v0, ptr %t11)
  store i1 %t13, ptr %l8
  br label %bb4
bb3:
  %t14 = load i1, ptr %l5, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb5
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  store i1 %t15, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t16 = load i1, ptr %l4, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aReader_2eAll(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca i1
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca i1
  %rv = alloca { i32, { i64, ptr } }
  %t18 = alloca { i64, [1 x i64] }, align 8
  %t46 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Reader", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp eq i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinAll(ptr %v1)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l6
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l5
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  br label %bb6
bb4:
  %t14 = load i32, ptr %l6, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  store { i64, [1 x i64] } zeroinitializer, ptr %t18
  %t19 = getelementptr { i64, [1 x i64] }, ptr %t18, i32 0, i32 0
  store i64 0, ptr %t19
  %t20 = load { i64, [1 x i64] }, ptr %t18
  %t21 = call ptr @__olang_errpay_push()
  %t22 = ptrtoint ptr %t21 to i64
  %t25 = inttoptr i64 %t22 to ptr
  %t26 = call ptr @__olang_scope_alloc_a(ptr %t25, i64 16, i64 8)
  store { i64, [1 x i64] } %t20, ptr %t26
  call void @__olang_errpay_set(ptr %t26)
  %t29 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t29, ptr %rv
  br label %ret
bb6:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t30, 1
  store { i32, { i64, ptr } } %t31, ptr %rv
  br label %ret
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/io:Reader", ptr %t32, i32 0, i32 1
  %t36 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAll(ptr %v0, ptr %v1, ptr %t34)
  %t37 = extractvalue { i32, { i64, ptr } } %t36, 1
  %t38 = extractvalue { i32, { i64, ptr } } %t36, 0
  store i32 %t38, ptr %l17
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb9, label %ok.40, !prof !99
ok.40:
  store { i64, ptr } %t37, ptr %l16
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t41, ptr %l13, !tbaa !27
  br label %bb11
bb9:
  %t42 = load i32, ptr %l17, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  store i1 %t45, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  store { i64, [1 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [1 x i64] }, ptr %t46, i32 0, i32 0
  store i64 0, ptr %t47
  %t48 = load { i64, [1 x i64] }, ptr %t46
  %t49 = call ptr @__olang_errpay_push()
  %t50 = ptrtoint ptr %t49 to i64
  %t53 = inttoptr i64 %t50 to ptr
  %t54 = call ptr @__olang_scope_alloc_a(ptr %t53, i64 16, i64 8)
  store { i64, [1 x i64] } %t48, ptr %t54
  call void @__olang_errpay_set(ptr %t54)
  %t57 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t57, ptr %rv
  br label %ret
bb11:
  %t58 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t59 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i32, { i64, [1 x i64] } }
  %l5 = alloca { i32, { i64, [1 x i64] } }
  %l6 = alloca { i32, { i64, [1 x i64] } }
  %l9 = alloca i1
  %l11 = alloca { i32, { i64, [1 x i64] } }
  %l12 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2edrain(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"std/io:Writer", ptr %t3, i32 0, i32 3
  %t6 = load { i32, { i64, [1 x i64] } }, ptr %t5
  store { i32, { i64, [1 x i64] } } %t6, ptr %l1
  %t8 = load { i32, { i64, [1 x i64] } }, ptr %l1
  store { i32, { i64, [1 x i64] } } %t8, ptr %l5
  store { i32, { i64, [1 x i64] } } zeroinitializer, ptr %l6
  %t11 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eerror_7bstd_2fio_3aError_7d(ptr %l5, ptr %l6)
  store i1 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i1, ptr %l9, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i32, { i64, [1 x i64] } }, ptr %l1
  store { i32, { i64, [1 x i64] } } %t15, ptr %l11
  %t16 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l11, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  store i32 %t17, ptr %l12, !tbaa !23
  %t18 = load i32, ptr %l12, !tbaa !23
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  br label %bb9
bb5:
  %t21 = load i32, ptr %l12, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d49434c98a69e919_d3631f4f1bfca5d5)
  unreachable
bb7:
  %t26 = call ptr @__olang_errpay_push()
  %t27 = ptrtoint ptr %t26 to i64
  %t28 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l11, i32 0, i32 1
  %t29 = load { i64, [1 x i64] }, ptr %t28
  %t31 = inttoptr i64 %t27 to ptr
  %t32 = call ptr @__olang_scope_alloc_a(ptr %t31, i64 16, i64 8)
  store { i64, [1 x i64] } %t29, ptr %t32
  call void @__olang_errpay_set(ptr %t32)
  br label %bb8
bb8:
  %t34 = load i32, ptr %l12, !tbaa !23
  %t35 = lshr i32 %t34, 16
  %t36 = and i32 %t34, 65535
  %t37 = icmp eq i32 %t35, 1
  %t38 = select i1 %t37, i32 1, i32 0
  %t39 = icmp eq i32 %t34, 0
  %t40 = shl i32 %t38, 16
  %t41 = or i32 %t40, %t36
  %t42 = select i1 %t39, i32 0, i32 %t41
  store i32 %t42, ptr %rv
  br label %ret
bb9:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca { i32, { i64, [1 x i64] } }
  %l12 = alloca { i32, { i64, [1 x i64] } }
  %l15 = alloca i1
  %l41 = alloca i64
  %l44 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Writer", ptr %t1, i32 0, i32 3
  %t4 = load { i32, { i64, [1 x i64] } }, ptr %t3
  store { i32, { i64, [1 x i64] } } %t4, ptr %l11
  store { i32, { i64, [1 x i64] } } zeroinitializer, ptr %l12
  %t7 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eerror_7bstd_2fio_3aError_7d(ptr %l11, ptr %l12)
  store i1 %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load i1, ptr %l15, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/io:Writer", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/io:Writer", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = sub i64 %t21, %t25
  %t31 = icmp sgt i64 %t15, %t28
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2edrain(ptr %v0, ptr %t33)
  br label %bb7
bb6:
  br label %bb12
bb7:
  %t35 = load i64, ptr %l2, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/io:Writer", ptr %t36, i32 0, i32 1
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = icmp sge i64 %t35, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2esend(ptr %v0, ptr %v1, ptr %t46, { i64, ptr } %t47)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"std/io:Writer", ptr %t50, i32 0, i32 2
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l2, !tbaa !24
  store i64 %t55, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l4, !tbaa !24
  %t61 = icmp sgt i64 %t57, %t58
  br i1 %t61, label %bb13, label %bb14
bb13:
  %t63 = load i64, ptr %l6, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb18
bb15:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = sub i64 %t67, %t68
  %t72 = load i64, ptr %l6, !tbaa !24
  %t75 = add i64 %t71, %t72
  %t77 = sub i64 %t75, 1
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = sdiv i64 %t77, %t78
  store i64 %t81, ptr %l44, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb17
bb17:
  %t83 = load i64, ptr %l44, !tbaa !24
  store i64 %t83, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t84 = load i64, ptr %l41, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t86 = sub i64 %t85, 1
  store i64 %t86, ptr %l53, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t88 = icmp slt i64 %t87, 2147483648
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  %t93 = and i1 %t88, %t90
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb19
bb19:
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t102 = load i64, ptr %l4, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  store i64 %t110, ptr %l9, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"std/io:Writer", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %l67, !tbaa !27
  %t116 = load i64, ptr %l3, !tbaa !24
  %t117 = load i64, ptr %l9, !tbaa !24
  %t120 = add i64 %t116, %t117
  %t121 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t121, ptr %l71, !tbaa !27
  %t122 = load i64, ptr %l9, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 %t122
  %t127 = load i8, ptr %t126, !tbaa !32
  %t130 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i8, ptr %t131, i64 %t120
  store i8 %t127, ptr %t132, !tbaa !32
  br label %bb23
bb23:
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = add i64 %t133, 1
  store i64 %t136, ptr %l8, !tbaa !24
  br label %bb19
bb24:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l3, !tbaa !24
  %t140 = load i64, ptr %l2, !tbaa !24
  %t143 = add i64 %t139, %t140
  %t146 = getelementptr %"std/io:Writer", ptr %t138, i32 0, i32 2
  store i64 %t143, ptr %t146, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fio_2estd_2fio_3aWriter_2eWriteChar(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l10 = alloca { i32, { i64, [1 x i64] } }
  %l11 = alloca { i32, { i64, [1 x i64] } }
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l22 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Writer", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/io:Writer", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp eq i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2edrain(ptr %v0, ptr %t15)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/io:Writer", ptr %t17, i32 0, i32 3
  %t20 = load { i32, { i64, [1 x i64] } }, ptr %t19
  store { i32, { i64, [1 x i64] } } %t20, ptr %l10
  store { i32, { i64, [1 x i64] } } zeroinitializer, ptr %l11
  %t23 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eerror_7bstd_2fio_3aError_7d(ptr %l10, ptr %l11)
  store i1 %t23, ptr %l14
  br label %bb5
bb5:
  %t24 = load i1, ptr %l14, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/io:Writer", ptr %t27, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l17, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"std/io:Writer", ptr %t31, i32 0, i32 2
  %t34 = load i64, ptr %t33, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t34
  store i8 %a1, ptr %t41, !tbaa !32
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l22, !tbaa !29
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = getelementptr %"std/io:Writer", ptr %t43, i32 0, i32 2
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = add i64 %t45, 1
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = getelementptr %"std/io:Writer", ptr %t50, i32 0, i32 2
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fio_2estd_2fio_3aWriter_2edrain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i1
  %l6 = alloca { i32, { i64, [1 x i64] } }
  %l7 = alloca { i32, { i64, [1 x i64] } }
  %l10 = alloca i1
  %l11 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Writer", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/io:Writer", ptr %t8, i32 0, i32 3
  %t11 = load { i32, { i64, [1 x i64] } }, ptr %t10
  store { i32, { i64, [1 x i64] } } %t11, ptr %l6
  store { i32, { i64, [1 x i64] } } zeroinitializer, ptr %l7
  %t14 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eerror_7bstd_2fio_3aError_7d(ptr %l6, ptr %l7)
  store i1 %t14, ptr %l10
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t15 = load i1, ptr %l10, !tbaa !21
  store i1 %t15, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l4, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l11, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"std/io:Writer", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l13, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/io:Writer", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l15, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l16, !tbaa !24
  %t28 = icmp sge i64 0, 0
  br i1 %t28, label %bb7, label %bb8
bb6:
  br label %bb14
bb7:
  %t30 = load i64, ptr %l15, !tbaa !24
  %t31 = icmp sle i64 0, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_2286ff1fbe683020_e6ca3016afdcd184)
  unreachable
bb9:
  %t33 = load i64, ptr %l15, !tbaa !24
  %t34 = load i64, ptr %l16, !tbaa !24
  %t35 = icmp sle i64 %t33, %t34
  br i1 %t35, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_2286ff1fbe683020_e6ca3016afdcd184)
  unreachable
bb11:
  %t37 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l15, !tbaa !24
  %t40 = getelementptr i8, ptr %t38, i64 0
  %t41 = sub i64 %t39, 0
  %t42 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t40, 1
  %t44 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2esend(ptr %v0, ptr %v0, ptr %t44, { i64, ptr } %t43)
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_2286ff1fbe683020_e6ca3016afdcd184)
  unreachable
bb13:
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"std/io:Writer", ptr %t46, i32 0, i32 2
  store i64 0, ptr %t48, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fio_2estd_2fio_3aWriter_2esend(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i32, { i64, [1 x i64] } }
  %l6 = alloca i32
  %l8 = alloca i1
  %l9 = alloca { i32, { i64, [1 x i64] } }
  %l10 = alloca { i32, { i64, [1 x i64] } }
  %l11 = alloca i32
  %l15 = alloca { i32, { i64, [1 x i64] } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Writer", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t8 = call i32 @std_2fio_2eWrite(ptr %v1, i32 %t4, { i64, ptr } %a1)
  store i32 %t8, ptr %l6
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  br label %bb1
bb1:
  br label %bb8
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l8, !tbaa !21
  store { i32, { i64, [1 x i64] } } zeroinitializer, ptr %l2
  %t15 = load i32, ptr %l6, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t24 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l2, i32 0, i32 0
  store i32 %t23, ptr %t24, !tbaa !23
  br label %bb3
bb3:
  %t25 = load { i32, { i64, [1 x i64] } }, ptr %l2
  store { i32, { i64, [1 x i64] } } %t25, ptr %l9
  store { i32, { i64, [1 x i64] } } zeroinitializer, ptr %l10
  %t26 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l9, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  store i32 %t27, ptr %l11, !tbaa !23
  %t28 = load i32, ptr %l11, !tbaa !23
  %t29 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l10, i32 0, i32 0
  store i32 %t28, ptr %t29, !tbaa !23
  %t30 = load i32, ptr %l11, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = call ptr @__olang_errpay_top_get()
  %t37 = load { i64, [1 x i64] }, ptr %t35
  %t38 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l10, i32 0, i32 1
  store { i64, [1 x i64] } %t37, ptr %t38
  br label %bb5
bb5:
  %t39 = load { i32, { i64, [1 x i64] } }, ptr %l10
  store { i32, { i64, [1 x i64] } } %t39, ptr %l2
  %t40 = load { i32, { i64, [1 x i64] } }, ptr %l2
  store { i32, { i64, [1 x i64] } } %t40, ptr %l15
  %t41 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l15, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  br i1 %t45, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i32, { i64, [1 x i64] } }, ptr %l2
  %t51 = getelementptr %"std/io:Writer", ptr %t47, i32 0, i32 3
  store { i32, { i64, [1 x i64] } } %t48, ptr %t51
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fio_2ewords(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i32
  %l3 = alloca %"std/io:Reader"
  %l4 = alloca { i64, ptr }
  %l7 = alloca i32
  %l10 = alloca %"std/io:Reader"
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l20 = alloca i1
  %l28 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @std_2fio_2ereading(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t9 = call %"std/io:Reader" @std_2fio_2eReader_2esized(ptr %s0, i32 %t5, i64 %a1)
  store %"std/io:Reader" %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load %"std/io:Reader", ptr %l10
  store %"std/io:Reader" %t10, ptr %l3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aReader_2eWord(ptr %s0, ptr %s1, ptr %l3)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l14
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  store { i64, ptr } %t13, ptr %l13
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  br label %bb14
bb5:
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 2
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  br i1 %t26, label %bb8, label %bb9
bb7:
  %t28 = load i32, ptr %l14, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  store i1 %t31, ptr %l20, !tbaa !21
  %t32 = load i32, ptr %l14, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb11, label %bb12
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb11:
  call void @__olang_errpay_pop()
  br label %bb12
bb12:
  br label %bb13
bb13:
  call void @__olang_check_failed(ptr @olang_loc_3a9593c1ece42b7a_23ab9347e2e9082e)
  unreachable
bb14:
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = extractvalue { i64, ptr } %t38, 0
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t47 = extractvalue { i64, ptr } %t37, 1
  %t48 = extractvalue { i64, ptr } %t37, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t41, i64 %t42)
  %t54 = getelementptr i8, ptr %t53, i64 %t42
  call void @olang_textcopy(ptr %t54, ptr %t43, i64 %t44)
  %t55 = getelementptr i8, ptr %t54, i64 %t44
  call void @olang_textcopy(ptr %t55, ptr %t47, i64 %t48)
  %t56 = getelementptr i8, ptr %t55, i64 %t48
  call void @olang_textcopy(ptr %t56, ptr %t50, i64 %t51)
  %t57 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t53, 1
  store { i64, ptr } %t58, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb15
bb15:
  br label %bb3
bb16:
  %t61 = load i32, ptr %l2, !tbaa !23
  %t63 = call i32 @close(i32 %t61)
  store i32 %t63, ptr %l28
  br label %bb17
bb17:
  %t64 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/io:Lines" @std_2fio_3aLines_2ector(ptr %v0, ptr %v1, { ptr, ptr } %a0) #0 {
entry:
  %l1 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l8 = alloca %"std/prelude/input:InputBuffer"
  %rv = alloca %"std/io:Lines"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { ptr, ptr } %a0, 0
  %t4 = extractvalue { ptr, ptr } %a0, 1
  %t5 = getelementptr ptr, ptr %t4, i64 3
  %t6 = load ptr, ptr %t5
  %t7 = call i32 %t6(ptr %v0, ptr %t3)
  store i32 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load i32, ptr %l4, !tbaa !23
  store i32 %t8, ptr %l1, !tbaa !23
  %t9 = call ptr @__olang_scope_hold(ptr %v1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l5, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2estd_2fio_3aLines_2e1
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = call ptr @__olang_region_make(ptr %v1)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t15 = load i32, ptr %l1, !tbaa !23
  %t16 = load i64, ptr %l5
  %t17 = inttoptr i64 %t16 to ptr
  %t19 = call %"std/prelude/input:InputBuffer" @std_2fprelude_2finput_3aInputBuffer_2ector(ptr %t17, i32 %t15, i64 4096, i1 true)
  store %"std/prelude/input:InputBuffer" %t19, ptr %l8
  br label %bb4
bb4:
  %t20 = load i1, ptr @olang_2esole_2estd_2fio_3aLines_2e1
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load i64, ptr %l5
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = getelementptr %"std/prelude/input:InputBuffer", ptr %l8, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = call ptr @__olang_region_or(ptr %t26, ptr null)
  %t28 = call ptr @__olang_region_home(ptr %t27)
  %t29 = icmp ne ptr %t28, null
  %t30 = select i1 %t29, ptr %t28, ptr null
  call void @__olang_region_settle_in(ptr %t23, ptr %t30)
  br label %bb6
bb6:
  %t31 = load %"std/prelude/input:InputBuffer", ptr %l8
  %t32 = load i32, ptr %l1, !tbaa !23
  %t33 = insertvalue %"std/io:Lines" undef, i32 %t32, 0
  %t35 = insertvalue %"std/io:Lines" %t33, %"std/prelude/input:InputBuffer" %t31, 1
  store %"std/io:Lines" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"std/io:Lines", ptr %rv
  ret %"std/io:Lines" %rr
}

define dso_local %"std/io:Reader" @std_2fio_3aReader_2ector(ptr %v0, ptr %v1, { ptr, ptr } %a0) #0 {
entry:
  %l1 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l8 = alloca %"std/prelude/input:InputBuffer"
  %rv = alloca %"std/io:Reader"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { ptr, ptr } %a0, 0
  %t4 = extractvalue { ptr, ptr } %a0, 1
  %t5 = getelementptr ptr, ptr %t4, i64 3
  %t6 = load ptr, ptr %t5
  %t7 = call i32 %t6(ptr %v0, ptr %t3)
  store i32 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load i32, ptr %l4, !tbaa !23
  store i32 %t8, ptr %l1, !tbaa !23
  %t9 = call ptr @__olang_scope_hold(ptr %v1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l5, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2estd_2fio_3aReader_2e1
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = call ptr @__olang_region_make(ptr %v1)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t15 = load i32, ptr %l1, !tbaa !23
  %t16 = load i64, ptr %l5
  %t17 = inttoptr i64 %t16 to ptr
  %t19 = call %"std/prelude/input:InputBuffer" @std_2fprelude_2finput_3aInputBuffer_2ector(ptr %t17, i32 %t15, i64 4096, i1 true)
  store %"std/prelude/input:InputBuffer" %t19, ptr %l8
  br label %bb4
bb4:
  %t20 = load i1, ptr @olang_2esole_2estd_2fio_3aReader_2e1
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load i64, ptr %l5
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = getelementptr %"std/prelude/input:InputBuffer", ptr %l8, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = call ptr @__olang_region_or(ptr %t26, ptr null)
  %t28 = call ptr @__olang_region_home(ptr %t27)
  %t29 = icmp ne ptr %t28, null
  %t30 = select i1 %t29, ptr %t28, ptr null
  call void @__olang_region_settle_in(ptr %t23, ptr %t30)
  br label %bb6
bb6:
  %t31 = load %"std/prelude/input:InputBuffer", ptr %l8
  %t32 = load i32, ptr %l1, !tbaa !23
  %t33 = insertvalue %"std/io:Reader" undef, i32 %t32, 0
  %t35 = insertvalue %"std/io:Reader" %t33, %"std/prelude/input:InputBuffer" %t31, 1
  store %"std/io:Reader" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"std/io:Reader", ptr %rv
  ret %"std/io:Reader" %rr
}

define dso_local %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, ptr %v1, { ptr, ptr } %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l12 = alloca i64
  %rv = alloca %"std/io:Writer"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { ptr, ptr } %a0, 0
  %t4 = extractvalue { ptr, ptr } %a0, 1
  %t5 = getelementptr ptr, ptr %t4, i64 3
  %t6 = load ptr, ptr %t5
  %t7 = call i32 %t6(ptr %v0, ptr %t3)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t9 = call ptr @__olang_scope_hold(ptr %v1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2estd_2fio_3aWriter_2e1
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = call ptr @__olang_region_make(ptr %v1)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l8, !tbaa !24
  br label %bb3
bb3:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l12, !tbaa !24
  br label %bb6
bb5:
  store i64 1, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = icmp sge i64 %t21, 0
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load i64, ptr %l12, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = load i64, ptr %l8
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %t27, i64 %t25)
  %t29 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = insertvalue %"std/io:Writer" undef, i32 %t32, 0
  %t35 = insertvalue %"std/io:Writer" %t33, { i64, ptr } %t30, 1
  %t37 = insertvalue %"std/io:Writer" %t35, i64 0, 2
  %t39 = insertvalue %"std/io:Writer" %t37, { i32, { i64, [1 x i64] } } zeroinitializer, 3
  store %"std/io:Writer" %t39, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_6cd41157f4fd8842_c8d3cc71cb27ad56)
  unreachable
ret:
  %rr = load %"std/io:Writer", ptr %rv
  ret %"std/io:Writer" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2etable_2eI32_7cstd_2fio_3aDescriptor = linkonce_odr constant [4 x ptr] [ptr @olang_2etypeid_2eI32, ptr @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0]
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd_2fio_3aLines_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
declare ptr @__olang_errpay_push() cold
declare void @__olang_errpay_set(ptr) cold
declare void @__olang_check_failed(ptr) cold noreturn
@olang_2esole_2estd_2fio_3aReader_2e1 = weak hidden constant i1 false
declare i32 @close(i32)
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_errpay_pop()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"more than four bytes" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d3 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"-------------------------------------------------------------" }>, align 8
declare i32 @open(ptr, i32, ...)
declare i64 @read(i32, ptr, i64)
declare i64 @write(i32, ptr, i64)
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eerror_7bstd_2fio_3aError_7d(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0
  %t2 = getelementptr { i32, { i64, [1 x i64] } }, ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1
  %t5 = getelementptr { i32, { i64, [1 x i64] } }, ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb5
bb2:
  %t11 = load ptr, ptr %l0
  %t12 = getelementptr { i32, { i64, [1 x i64] } }, ptr %t11, i32 0, i32 1
  %t13 = load ptr, ptr %l1
  %t14 = getelementptr { i32, { i64, [1 x i64] } }, ptr %t13, i32 0, i32 1
  %t17 = call i1 @olang_2emir_2eHelperKind_2eEqual_2estd_2fio_3aError_24payload(ptr %t12, ptr %t14)
  store i1 %t17, ptr %l8
  br label %bb3
bb3:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb4, label %bb1
bb4:
  br label %bb5
bb5:
  %t19 = load i1, ptr %l2, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare ptr @__olang_errpay_top_get()
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@olang_2esole_2estd_2fio_3aWriter_2e1 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_2etypeid_2eI32 = linkonce_odr constant i8 0
define linkonce_odr void @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t6 = call i64 @__olang_fmt_i64(ptr %t5, i64 %t4)
  call void @__olang_sb_add(ptr %v0, i64 %t6)
  br label %ret
ret:
  ret void
}

define linkonce_odr void @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t3 = sext i32 %t2 to i64
  %t4 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t5 = call i64 @__olang_fmt_i64(ptr %t4, i64 %t3)
  call void @__olang_sb_add(ptr %v0, i64 %t5)
  br label %ret
ret:
  ret void
}

@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2estd_2fio_3aError_24payload(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 2}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 2}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb6
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 ]
bb3:
  br label %bb6
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i64 }, ptr %t15, i32 0, i32 0
  %t17 = load i64, ptr %t16
  %t20 = icmp eq i64 %t13, %t17
  br i1 %t20, label %bb5, label %bb1
bb5:
  br label %bb3
bb6:
  %t22 = load i1, ptr %l2, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare %"std/prelude/input:InputBuffer" @std_2fprelude_2finput_3aInputBuffer_2ector(ptr %v0, i32 %a0, i64 %a1, i1 %a2)
@olang_loc_e183f6af0815be24_39313b6101d20ca8 = external constant [0 x i8]
@olang_loc_405125a8bfc97357_6687826239f87cdb = external constant [0 x i8]
@olang_loc_5d46b41c36e8feff_84fddb7c6ef404db = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_65126f5b67a1f66c_44d990074c227388 = external constant [0 x i8]
@olang_loc_e6fc1695886d91da_b063287e95dbbab6 = external constant [0 x i8]
declare i1 @std_2fprelude_2finput_2eStdinBuffered()
declare i1 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBuffered(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinAll(ptr %v0)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAll(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_d49434c98a69e919_d3631f4f1bfca5d5 = external constant [0 x i8]
@olang_loc_2286ff1fbe683020_e6ca3016afdcd184 = external constant [0 x i8]
declare i32 @std_2fio_2ereading(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aReader_2eWord(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_3a9593c1ece42b7a_23ab9347e2e9082e = external constant [0 x i8]
@olang_loc_6cd41157f4fd8842_c8d3cc71cb27ad56 = external constant [0 x i8]
declare i32 @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
