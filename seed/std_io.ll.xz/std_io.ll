; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/io:Lines" = type { i32, { i64, ptr }, i64, i64 }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, i32 }
@G_2estd_2fio_2eStderr = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2estd_2fio_2eStdin = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2estd_2fio_2eStdout = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
define dso_local i32 @std_2fio_2eFormatInt(ptr %v0, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %rv = alloca i32
  store i64 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  store i1 %t3, ptr %l2, !tbaa !21
  %t5 = load i1, ptr %l2, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l0, !tbaa !24
  store i64 %t7, ptr %l11, !tbaa !24
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0, !tbaa !24
  %t11 = sub i64 0, %t9
  store i64 %t11, ptr %l11, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l11, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  store i32 0, ptr %l4, !tbaa !23
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t14, ptr %l15, !tbaa !27
  %t15 = load i32, ptr %l4, !tbaa !23
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = srem i64 %t16, 10
  %t20 = sub i64 0, %t18
  %t22 = trunc i64 %t20 to i8
  %t25 = add i8 %t22, 48
  %t28 = sext i32 %t15 to i64
  %t29 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr i8, ptr %t30, i64 %t28
  store i8 %t25, ptr %t31, !tbaa !32
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = sdiv i64 %t32, 10
  store i64 %t34, ptr %l3, !tbaa !24
  %t36 = load i32, ptr %l4, !tbaa !23
  %t38 = add i32 %t36, 1
  store i32 %t38, ptr %l4, !tbaa !23
  br label %bb5
bb5:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb6, label %bb7
bb6:
  br label %bb9
bb7:
  br label %bb8
bb8:
  br label %bb4
bb9:
  %t46 = load i1, ptr %l2, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t48, ptr %l31, !tbaa !27
  %t49 = load i32, ptr %l4, !tbaa !23
  %t52 = sext i32 %t49 to i64
  %t53 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 %t52
  store i8 45, ptr %t55, !tbaa !32
  %t56 = load i32, ptr %l4, !tbaa !23
  %t58 = add i32 %t56, 1
  store i32 %t58, ptr %l4, !tbaa !23
  br label %bb12
bb11:
  br label %bb12
bb12:
  store i32 0, ptr %l5, !tbaa !23
  %t60 = load i32, ptr %l4, !tbaa !23
  %t62 = sub i32 %t60, 1
  store i32 %t62, ptr %l6, !tbaa !23
  br label %bb13
bb13:
  %t64 = load i32, ptr %l5, !tbaa !23
  %t65 = load i32, ptr %l6, !tbaa !23
  %t68 = icmp slt i32 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t72, ptr %l42, !tbaa !27
  %t73 = load i32, ptr %l5, !tbaa !23
  %t75 = sext i32 %t73 to i64
  %t76 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t75
  %t79 = load i8, ptr %t78, !tbaa !32
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t81, ptr %l45, !tbaa !27
  %t82 = load i32, ptr %l5, !tbaa !23
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t83, ptr %l47, !tbaa !27
  %t84 = load i32, ptr %l6, !tbaa !23
  %t86 = sext i32 %t84 to i64
  %t87 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i8, ptr %t88, i64 %t86
  %t90 = load i8, ptr %t89, !tbaa !32
  %t93 = sext i32 %t82 to i64
  %t94 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i8, ptr %t95, i64 %t93
  store i8 %t90, ptr %t96, !tbaa !32
  %t97 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t97, ptr %l50, !tbaa !27
  %t98 = load i32, ptr %l6, !tbaa !23
  %t102 = sext i32 %t98 to i64
  %t103 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr i8, ptr %t104, i64 %t102
  store i8 %t79, ptr %t105, !tbaa !32
  %t106 = load i32, ptr %l5, !tbaa !23
  %t108 = add i32 %t106, 1
  store i32 %t108, ptr %l5, !tbaa !23
  %t110 = load i32, ptr %l6, !tbaa !23
  %t112 = sub i32 %t110, 1
  store i32 %t112, ptr %l6, !tbaa !23
  br label %bb17
bb17:
  br label %bb13
bb18:
  %t114 = load i32, ptr %l4, !tbaa !23
  store i32 %t114, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2estd_2fio_2eStdout, !tbaa !23
  %t6 = call i32 @std_2fio_2eWrite(ptr %v0, i32 %t1, { i64, ptr } %a0)
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  store i32 %t17, ptr %rv
  br label %ret
bb3:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2estd_2fio_2eStderr, !tbaa !23
  %t6 = call i32 @std_2fio_2eWrite(ptr %v0, i32 %t1, { i64, ptr } %a0)
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  store i32 %t17, ptr %rv
  br label %ret
bb3:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ePrintErrln(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2estd_2fio_2eStderr, !tbaa !23
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t4, i64 %t5)
  %t10 = getelementptr i8, ptr %t9, i64 %t5
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = extractvalue { i64, ptr } %t12, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t23 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %t1, { i64, ptr } %t20)
  store i32 %t23, ptr %l6
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb2, label %ok.25, !prof !99
ok.25:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t26 = load i32, ptr %l6, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s0)
  store i32 %t34, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2estd_2fio_2eStdout, !tbaa !23
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t4, i64 %t5)
  %t10 = getelementptr i8, ptr %t9, i64 %t5
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = extractvalue { i64, ptr } %t12, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t23 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %t1, { i64, ptr } %t20)
  store i32 %t23, ptr %l6
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb2, label %ok.25, !prof !99
ok.25:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t26 = load i32, ptr %l6, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s0)
  store i32 %t34, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fio_2eRead(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t9 = extractvalue { i64, ptr } %t2, 1
  %t10 = extractvalue { i64, ptr } %t2, 0
  %t12 = call i64 @read(i32 %a0, ptr %t9, i64 %t5)
  store i64 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i64, ptr %l8, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp slt i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t19 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t19, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l12, !tbaa !27
  %t21 = load i64, ptr %l2, !tbaa !24
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l14, !tbaa !24
  %t24 = icmp sge i64 0, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load i64, ptr %l13, !tbaa !24
  %t27 = icmp sle i64 0, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e183f6af0815be24_39313b6101d20ca8)
  unreachable
bb7:
  %t29 = load i64, ptr %l13, !tbaa !24
  %t30 = load i64, ptr %l14, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_e183f6af0815be24_39313b6101d20ca8)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l13, !tbaa !24
  %t36 = getelementptr i8, ptr %t34, i64 0
  %t37 = sub i64 %t35, 0
  %t38 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  %t41 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t39, 1
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e183f6af0815be24_39313b6101d20ca8)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l25 = alloca i64
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i32 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l10, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  store i64 %t10, ptr %l11, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t11, 0
  store i64 %t14, ptr %l14, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = icmp sge i64 %t17, 0
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l11, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = icmp sle i64 %t20, %t21
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_405125a8bfc97357_6687826239f87cdb)
  unreachable
bb7:
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp sle i64 %t24, %t25
  br i1 %t26, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_405125a8bfc97357_6687826239f87cdb)
  unreachable
bb9:
  %t28 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l11, !tbaa !24
  %t31 = load i64, ptr %l14, !tbaa !24
  %t32 = getelementptr i8, ptr %t29, i64 %t30
  %t33 = sub i64 %t31, %t30
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t45 = extractvalue { i64, ptr } %t38, 1
  %t46 = extractvalue { i64, ptr } %t38, 0
  %t48 = call i64 @write(i32 %a0, ptr %t45, i64 %t41)
  store i64 %t48, ptr %l25
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_405125a8bfc97357_6687826239f87cdb)
  unreachable
bb11:
  %t49 = load i64, ptr %l25, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  br i1 %t52, label %bb12, label %bb13
bb12:
  store i32 65536, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = icmp eq i64 %t55, 0
  br i1 %t57, label %bb15, label %bb16
bb15:
  store i32 65537, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t60, %t61
  store i64 %t64, ptr %l3, !tbaa !24
  br label %bb18
bb18:
  %t66 = load i64, ptr %l3, !tbaa !24
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb19, label %bb20
bb19:
  br label %bb22
bb20:
  br label %bb21
bb21:
  br label %bb4
bb22:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2eafterTheEnd(i32 %a0) #0 {
entry:
  %l1 = alloca %"std/io:Lines"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/io:Lines"
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l19 = alloca i1
  %l23 = alloca i64
  %l26 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"std/io:Lines" @std_2fio_3aLines_2ector(ptr %s0, i32 %a0, i64 2)
  store %"std/io:Lines" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/io:Lines", ptr %l10
  store %"std/io:Lines" %t4, ptr %l1
  %t6 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %s0, ptr %s0, ptr %l1)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l14
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb3, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l13
  br label %bb2
bb2:
  %t11 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t11, ptr %l11, !tbaa !27
  br label %bb10
bb3:
  %t12 = load i32, ptr %l14, !tbaa !23
  %t13 = icmp eq i32 %t12, 65536
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d56021b6e5c3bdfa_44c4511adba970be)
  unreachable
bb5:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = icmp eq i32 %t15, 65537
  br i1 %t16, label %bb6, label %bb7
bb6:
  call void @__olang_bang_failed_plain(ptr @olang_loc_9191d7d375be9bf_456d8efa2f19b6b)
  unreachable
bb7:
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = icmp eq i32 %t18, 131072
  br i1 %t19, label %bb8, label %bb9
bb8:
  call void @__olang_bang_failed_plain(ptr @olang_loc_ecfe7bc4e914c155_2facd670f5d599)
  unreachable
bb9:
  call void @__olang_bang_failed_plain(ptr @olang_loc_236626def65966f_f8ee7e95debf0f53)
  unreachable
bb10:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t24, ptr %l19
  br label %bb11
bb11:
  %t25 = load i1, ptr %l19, !tbaa !21
  br i1 %t25, label %bb12, label %bb13
bb12:
  store i64 0, ptr %l3, !tbaa !24
  store i64 3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8ace81b314be0ed6_98e2c78d06064582)
  unreachable
bb14:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb19
bb16:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l26, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb18
bb18:
  %t52 = load i64, ptr %l26, !tbaa !24
  store i64 %t52, ptr %l23, !tbaa !24
  br label %bb19
bb19:
  %t53 = load i64, ptr %l23, !tbaa !24
  store i64 %t53, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb22:
  br label %bb23
bb23:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l8, !tbaa !24
  %t73 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %s0, ptr %s2, ptr %l1)
  %t74 = extractvalue { i32, { i64, ptr } } %t73, 1
  %t75 = extractvalue { i32, { i64, ptr } } %t73, 0
  store i32 %t75, ptr %l47
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb25, label %ok.77, !prof !99
ok.77:
  store { i64, ptr } %t74, ptr %l46
  br label %bb24
bb24:
  %t78 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t78, ptr %l44, !tbaa !27
  br label %bb29
bb25:
  %t79 = load i32, ptr %l47, !tbaa !23
  %t80 = ashr i32 %t79, 16
  %t82 = icmp eq i32 %t80, 2
  br i1 %t82, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  %t84 = load i32, ptr %l47, !tbaa !23
  %t85 = lshr i32 %t84, 16
  %t86 = and i32 %t84, 65535
  %t87 = icmp eq i32 %t85, 1
  %t88 = select i1 %t87, i32 1, i32 0
  %t89 = icmp eq i32 %t85, 2
  %t90 = select i1 %t89, i32 0, i32 %t88
  %t91 = icmp eq i32 %t84, 0
  %t92 = shl i32 %t90, 16
  %t93 = or i32 %t92, %t86
  %t94 = select i1 %t91, i32 0, i32 %t93
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t94, ptr %rv
  br label %ret
bb28:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_cdec8918cbf67d26_bc226afea482d74a)
  unreachable
bb30:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l7, !tbaa !24
  br label %bb20
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2fio_2ebracketed(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca %"std/io:Lines"
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l13 = alloca %"std/io:Lines"
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l21 = alloca i1
  %l27 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ereading(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t8 = extractvalue { i64, ptr } %t5, 1
  %t9 = mul i64 %t7, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t8, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t13 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t13, ptr %lp3
  %t15 = load ptr, ptr %lp3
  store { i64, ptr } %t12, ptr %t15, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load i32, ptr %l2, !tbaa !23
  %t20 = call %"std/io:Lines" @std_2fio_3aLines_2ector(ptr %s1, i32 %t16, i64 %a1)
  store %"std/io:Lines" %t20, ptr %l13
  br label %bb2
bb2:
  %t21 = load %"std/io:Lines", ptr %l13
  store %"std/io:Lines" %t21, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %s1, ptr %s2, ptr %l4)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l17
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb5, label %ok.27, !prof !99
ok.27:
  store { i64, ptr } %t24, ptr %l16
  br label %bb4
bb4:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t28, ptr %l14, !tbaa !27
  br label %bb10
bb5:
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = ashr i32 %t29, 16
  %t32 = icmp eq i32 %t30, 2
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  %t34 = load i32, ptr %l17, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  store i1 %t37, ptr %l21, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_19a3a555e0bc0672_a80c148e75e56d4e)
  unreachable
bb10:
  %t38 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t39 = load ptr, ptr %lp3
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = extractvalue { i64, ptr } %t40, 0
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t49 = extractvalue { i64, ptr } %t38, 1
  %t50 = extractvalue { i64, ptr } %t38, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t43, i64 %t44)
  %t56 = getelementptr i8, ptr %t55, i64 %t44
  call void @olang_textcopy(ptr %t56, ptr %t45, i64 %t46)
  %t57 = getelementptr i8, ptr %t56, i64 %t46
  call void @olang_textcopy(ptr %t57, ptr %t49, i64 %t50)
  %t58 = getelementptr i8, ptr %t57, i64 %t50
  call void @olang_textcopy(ptr %t58, ptr %t52, i64 %t53)
  %t59 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t55, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = extractvalue { i64, ptr } %t60, 1
  %t64 = mul i64 %t62, 1
  %t65 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t64)
  call void @llvm.memcpy.p0.p0.i64(ptr %t65, ptr %t63, i64 %t64, i1 false)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t69 = load ptr, ptr %lp3
  store { i64, ptr } %t67, ptr %t69, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %bb3
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  %t70 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @close(i32 %t70)
  store i32 %t72, ptr %l27
  br label %bb14
bb14:
  %t73 = load ptr, ptr %lp3
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @std_2fio_2echeckReadIsEmpty(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i32, { i64, ptr } } @std_2fio_2eRead(ptr %v0, ptr %v0, i32 %a0, { i64, ptr } %a1)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  store i32 %t19, ptr %rv
  br label %ret
bb3:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t26 = icmp eq i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5d46b41c36e8feff_84fddb7c6ef404db)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ecloseFd(i32 %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @close(i32 %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2fio_2edrained(ptr %v0, i32 %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca %"std/io:Lines"
  %l4 = alloca { i64, ptr }
  %l8 = alloca %"std/io:Lines"
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l16 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = extractvalue { i64, ptr } %t1, 1
  %t5 = mul i64 %t3, 1
  %t6 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t5)
  call void @llvm.memcpy.p0.p0.i64(ptr %t6, ptr %t4, i64 %t5, i1 false)
  %t7 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  %t9 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t9, ptr %lp1
  %t11 = load ptr, ptr %lp1
  store { i64, ptr } %t8, ptr %t11, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = call %"std/io:Lines" @std_2fio_3aLines_2ector(ptr %s1, i32 %a0, i64 65536)
  store %"std/io:Lines" %t14, ptr %l8
  br label %bb1
bb1:
  %t15 = load %"std/io:Lines", ptr %l8
  store %"std/io:Lines" %t15, ptr %l2
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %s1, ptr %s2, ptr %l2)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l12
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb4, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l11
  br label %bb3
bb3:
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t22, ptr %l9, !tbaa !27
  br label %bb9
bb4:
  %t23 = load i32, ptr %l12, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 2
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  %t28 = load i32, ptr %l12, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  store i1 %t31, ptr %l16, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_65126f5b67a1f66c_44d990074c227388)
  unreachable
bb9:
  %t32 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t33 = load ptr, ptr %lp1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = extractvalue { i64, ptr } %t34, 0
  %t40 = extractvalue { i64, ptr } %t32, 1
  %t41 = extractvalue { i64, ptr } %t32, 0
  %t42 = add i64 %t38, %t41
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t37, i64 %t38)
  %t47 = getelementptr i8, ptr %t46, i64 %t38
  call void @olang_textcopy(ptr %t47, ptr %t40, i64 %t41)
  %t48 = getelementptr i8, ptr %t47, i64 %t41
  call void @olang_textcopy(ptr %t48, ptr %t43, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = load ptr, ptr %lp1
  store { i64, ptr } %t57, ptr %t59, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb2
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  %t60 = load ptr, ptr %lp1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fio_2efailedFlushes(i32 %a0) #0 {
entry:
  %l1 = alloca %"std/io:Writer"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/io:Writer"
  %l12 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i64
  %l39 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 %a0, i64 4)
  store %"std/io:Writer" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/io:Writer", ptr %l10
  store %"std/io:Writer" %t4, ptr %l1
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t6)
  br label %bb2
bb2:
  call void @std_2fio_2estd_2fio_3aWriter_2eWriteChar(ptr %s0, ptr %l1, i8 33)
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb9
bb6:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l20, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t34 = load i64, ptr %l20, !tbaa !24
  store i64 %t34, ptr %l17, !tbaa !24
  br label %bb9
bb9:
  %t35 = load i64, ptr %l17, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb11, label %bb12
bb11:
  br label %bb24
bb12:
  br label %bb13
bb13:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l8, !tbaa !24
  %t55 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l1)
  store i32 %t55, ptr %l39
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb15, label %ok.57, !prof !99
ok.57:
  br label %bb14
bb14:
  br label %bb22
bb15:
  %t58 = load i32, ptr %l39, !tbaa !23
  %t59 = icmp eq i32 %t58, 65536
  br i1 %t59, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load i32, ptr %l39, !tbaa !23
  %t62 = icmp eq i32 %t61, 65537
  br i1 %t62, label %bb19, label %bb20
bb18:
  call void @__olang_ert_req_clear()
  %t64 = load i64, ptr %l2, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l2, !tbaa !24
  br label %bb22
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e6fc1695886d91da_b063287e95dbbab6)
  unreachable
bb21:
  call void @__olang_ert_req_clear()
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l7, !tbaa !24
  br label %bb10
bb24:
  %t72 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fio_2eioChurn() #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !24
  store i64 0, ptr %l1, !tbaa !24
  store i64 300, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l11, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  %t49 = call i64 @__olang_fmt_i64(ptr null, i64 %t45)
  %t50 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t52)
  %t54 = call i64 @__olang_fmt_i64(ptr %t53, i64 %t45)
  %t55 = getelementptr i8, ptr %t53, i64 %t49
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = load i64, ptr %l0, !tbaa !24
  %t62 = extractvalue { i64, ptr } %t57, 0
  %t65 = add i64 %t59, %t62
  store i64 %t65, ptr %l0, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l5, !tbaa !24
  br label %bb7
bb12:
  %t71 = load i64, ptr %l0, !tbaa !24
  store i64 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @std_2fio_2eopenReadOnly(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l3 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = call i32 (ptr, i32, ...) @open(ptr %t4, i32 0)
  store i32 %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load i32, ptr %l3, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ereading(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca [2 x i32]
  %l5 = alloca i32
  %l10 = alloca i32
  %l14 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x i32] undef, i32 0, 0
  %t2 = insertvalue [2 x i32] %t1, i32 0, 1
  store [2 x i32] %t2, ptr %l1
  %t5 = insertvalue { i64, ptr } undef, i64 2, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %l1, 1
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = extractvalue { i64, ptr } %t6, 0
  %t10 = call i32 @pipe(ptr %t8)
  store i32 %t10, ptr %l5
  br label %bb1
bb1:
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = icmp eq i32 %t11, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = getelementptr [2 x i32], ptr %l1, i64 0, i64 1
  %t15 = load i32, ptr %t14, !tbaa !33
  %t20 = call i32 @std_2fio_2eWrite(ptr %v0, i32 %t15, { i64, ptr } %a0)
  store i32 %t20, ptr %l10
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb5, label %ok.22, !prof !99
ok.22:
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_48f9082997753888_a240ae8e5e29a0c)
  unreachable
bb4:
  br label %bb10
bb5:
  %t23 = load i32, ptr %l10, !tbaa !23
  %t24 = icmp eq i32 %t23, 65536
  br i1 %t24, label %bb6, label %bb7
bb6:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6ee02aeeb4b82e91_bbd4c13499124615)
  unreachable
bb7:
  %t26 = load i32, ptr %l10, !tbaa !23
  %t27 = icmp eq i32 %t26, 65537
  br i1 %t27, label %bb8, label %bb9
bb8:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2e343f18828dc6fc_fb3c99ef2ae70d28)
  unreachable
bb9:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6b542447dc4d89ad_116b4d1aefb73901)
  unreachable
bb10:
  %t29 = getelementptr [2 x i32], ptr %l1, i64 0, i64 1
  %t30 = load i32, ptr %t29, !tbaa !33
  %t32 = call i32 @close(i32 %t30)
  store i32 %t32, ptr %l14
  br label %bb11
bb11:
  %t33 = getelementptr [2 x i32], ptr %l1, i64 0, i64 0
  %t34 = load i32, ptr %t33, !tbaa !33
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ereportTo(i32 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"std/io:Writer"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/io:Writer"
  %l15 = alloca i64
  %l18 = alloca i64
  %l38 = alloca i32
  %l40 = alloca i32
  %l51 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 %a0, i64 65536)
  store %"std/io:Writer" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/io:Writer", ptr %l10
  store %"std/io:Writer" %t4, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp eq i64 %t53, 3
  br i1 %t55, label %bb12, label %bb13
bb12:
  store i32 65537, ptr %l38, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  %t58 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l2)
  store i32 %t58, ptr %l40
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb15, label %ok.60, !prof !99
ok.60:
  br label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb20
bb15:
  %t61 = load i32, ptr %l40, !tbaa !23
  %t62 = icmp eq i32 %t61, 65536
  br i1 %t62, label %bb16, label %bb17
bb16:
  call void @__olang_bang_failed_plain(ptr @olang_loc_82463fd07313b343_899050d6bae42837)
  unreachable
bb17:
  %t64 = load i32, ptr %l40, !tbaa !23
  %t65 = icmp eq i32 %t64, 65537
  br i1 %t65, label %bb18, label %bb19
bb18:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5dc1029830d6aac4_75c290e3de4fa170)
  unreachable
bb19:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b6949e6a237530b_4c14899758e8fd2f)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t67 = load i32, ptr %l38, !tbaa !23
  store i32 %t67, ptr %rv
  br label %ret
bb21:
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t72 = call i64 @__olang_fmt_i64(ptr null, i64 %t68)
  %t73 = add i64 %t70, %t72
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t69, i64 %t70)
  %t78 = getelementptr i8, ptr %t77, i64 %t70
  %t79 = call i64 @__olang_fmt_i64(ptr %t78, i64 %t68)
  %t80 = getelementptr i8, ptr %t78, i64 %t72
  call void @olang_textcopy(ptr %t80, ptr %t74, i64 %t75)
  %t81 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t77, 1
  %t85 = extractvalue { i64, ptr } %t82, 0
  %t86 = extractvalue { i64, ptr } %t82, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t90)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb8
bb24:
  %t98 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l2)
  store i32 %t98, ptr %l51
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb26, label %ok.100, !prof !99
ok.100:
  br label %bb25
bb25:
  br label %bb31
bb26:
  %t101 = load i32, ptr %l51, !tbaa !23
  %t102 = icmp eq i32 %t101, 65536
  br i1 %t102, label %bb27, label %bb28
bb27:
  call void @__olang_bang_failed_plain(ptr @olang_loc_82463fd07313b343_899050d6bae42837)
  unreachable
bb28:
  %t104 = load i32, ptr %l51, !tbaa !23
  %t105 = icmp eq i32 %t104, 65537
  br i1 %t105, label %bb29, label %bb30
bb29:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5dc1029830d6aac4_75c290e3de4fa170)
  unreachable
bb30:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b6949e6a237530b_4c14899758e8fd2f)
  unreachable
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l54 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l81 = alloca i64
  %l84 = alloca i64
  %l103 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l128 = alloca i64
  %l138 = alloca i64
  %l141 = alloca i64
  %l160 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l168 = alloca i32
  %l170 = alloca { i64, ptr }
  %l172 = alloca i64
  %l176 = alloca i64
  %l177 = alloca i64
  %l189 = alloca i64
  %l210 = alloca { i64, ptr }
  %l211 = alloca ptr
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Lines", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/io:Lines", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l35, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l35, !tbaa !24
  store i64 %t39, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l32, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/io:Lines", ptr %t59, i32 0, i32 1
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l54, !tbaa !27
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i8, ptr %t66, i64 %t63
  %t68 = load i8, ptr %t67, !tbaa !32
  %t70 = icmp eq i8 %t68, 10
  br i1 %t70, label %bb12, label %bb13
bb12:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"std/io:Lines", ptr %t72, i32 0, i32 2
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = add i64 %t78, 1
  %t83 = getelementptr %"std/io:Lines", ptr %t77, i32 0, i32 2
  store i64 %t80, ptr %t83, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l7, !tbaa !24
  %t90 = call { i64, ptr } @std_2fio_2estd_2fio_3aLines_2eline(ptr %v0, ptr %v1, ptr %t84, i64 %t75, i64 %t86)
  store { i64, ptr } %t90, ptr %l66
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t91 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t92 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t91, 1
  store { i32, { i64, ptr } } %t92, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"std/io:Lines", ptr %t97, i32 0, i32 3
  %t100 = load i64, ptr %t99, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/io:Lines", ptr %t101, i32 0, i32 2
  %t104 = load i64, ptr %t103, !tbaa !24
  %t107 = sub i64 %t100, %t104
  store i64 %t107, ptr %l1, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"std/io:Lines", ptr %t109, i32 0, i32 2
  %t112 = load i64, ptr %t111, !tbaa !24
  %t114 = icmp sgt i64 %t112, 0
  br i1 %t114, label %bb18, label %bb19
bb18:
  store i64 0, ptr %l9, !tbaa !24
  %t116 = load i64, ptr %l1, !tbaa !24
  store i64 %t116, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb20, label %bb21
bb19:
  br label %bb32
bb20:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb25
bb22:
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l9, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l84, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb24
bb24:
  %t144 = load i64, ptr %l84, !tbaa !24
  store i64 %t144, ptr %l81, !tbaa !24
  br label %bb25
bb25:
  %t145 = load i64, ptr %l81, !tbaa !24
  store i64 %t145, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t146 = load i64, ptr %l13, !tbaa !24
  %t147 = load i64, ptr %l12, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t154 = load i64, ptr %l9, !tbaa !24
  %t155 = load i64, ptr %l13, !tbaa !24
  %t156 = load i64, ptr %l11, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l14, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"std/io:Lines", ptr %t164, i32 0, i32 1
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  store { i64, ptr } %t167, ptr %l103, !tbaa !27
  %t168 = load i64, ptr %l14, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"std/io:Lines", ptr %t169, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l106, !tbaa !27
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"std/io:Lines", ptr %t173, i32 0, i32 2
  %t176 = load i64, ptr %t175, !tbaa !24
  %t177 = load i64, ptr %l14, !tbaa !24
  %t180 = add i64 %t176, %t177
  %t182 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i8, ptr %t183, i64 %t180
  %t185 = load i8, ptr %t184, !tbaa !32
  %t188 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i8, ptr %t189, i64 %t168
  store i8 %t185, ptr %t190, !tbaa !32
  br label %bb30
bb30:
  %t191 = load i64, ptr %l13, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l13, !tbaa !24
  br label %bb26
bb31:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"std/io:Lines", ptr %t195, i32 0, i32 2
  store i64 0, ptr %t197, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i64, ptr %l1, !tbaa !24
  %t202 = getelementptr %"std/io:Lines", ptr %t198, i32 0, i32 3
  store i64 %t199, ptr %t202, !tbaa !24
  br label %bb32
bb32:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"std/io:Lines", ptr %t203, i32 0, i32 3
  %t206 = load i64, ptr %t205, !tbaa !24
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"std/io:Lines", ptr %t207, i32 0, i32 1
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t215 = icmp eq i64 %t206, %t212
  br i1 %t215, label %bb33, label %bb34
bb33:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"std/io:Lines", ptr %t217, i32 0, i32 1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  store { i64, ptr } %t220, ptr %l15, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l125, !tbaa !29
  %t223 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t223, 0
  %t227 = mul i64 %t225, 2
  store i64 %t227, ptr %l128, !tbaa !24
  %t228 = load i64, ptr %l128, !tbaa !24
  %t229 = icmp sge i64 %t228, 0
  br i1 %t229, label %bb35, label %bb36
bb34:
  br label %bb49
bb35:
  %t231 = load i64, ptr %l128, !tbaa !24
  %t232 = mul i64 %t231, 1
  %t233 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t232)
  %t234 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  %t238 = extractvalue { i64, ptr } %t235, 0
  %t239 = extractvalue { i64, ptr } %t235, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t245 = load ptr, ptr %l125, !tbaa !29
  %t246 = getelementptr %"std/io:Lines", ptr %t245, i32 0, i32 1
  store { i64, ptr } %t243, ptr %t246, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"std/io:Lines", ptr %t247, i32 0, i32 3
  %t250 = load i64, ptr %t249, !tbaa !24
  store i64 %t250, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t252 = load i64, ptr %l17, !tbaa !24
  %t253 = load i64, ptr %l16, !tbaa !24
  %t256 = icmp sgt i64 %t252, %t253
  br i1 %t256, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_5f2b8b2f6326e81f_f1c47ff7019f64c3)
  unreachable
bb37:
  %t258 = load i64, ptr %l18, !tbaa !24
  %t260 = icmp sgt i64 %t258, 0
  br i1 %t260, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb42
bb39:
  %t262 = load i64, ptr %l17, !tbaa !24
  %t263 = load i64, ptr %l16, !tbaa !24
  %t266 = sub i64 %t262, %t263
  %t267 = load i64, ptr %l18, !tbaa !24
  %t270 = add i64 %t266, %t267
  %t272 = sub i64 %t270, 1
  %t273 = load i64, ptr %l18, !tbaa !24
  %t276 = sdiv i64 %t272, %t273
  store i64 %t276, ptr %l141, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb41
bb41:
  %t278 = load i64, ptr %l141, !tbaa !24
  store i64 %t278, ptr %l138, !tbaa !24
  br label %bb42
bb42:
  %t279 = load i64, ptr %l138, !tbaa !24
  store i64 %t279, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb43
bb43:
  %t280 = load i64, ptr %l20, !tbaa !24
  %t281 = load i64, ptr %l19, !tbaa !24
  %t284 = icmp slt i64 %t280, %t281
  %t286 = xor i1 %t284, true
  br i1 %t286, label %bb44, label %bb45
bb44:
  br label %bb48
bb45:
  br label %bb46
bb46:
  %t288 = load i64, ptr %l16, !tbaa !24
  %t289 = load i64, ptr %l20, !tbaa !24
  %t290 = load i64, ptr %l18, !tbaa !24
  %t293 = mul i64 %t289, %t290
  %t296 = add i64 %t288, %t293
  store i64 %t296, ptr %l21, !tbaa !24
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"std/io:Lines", ptr %t298, i32 0, i32 1
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !27
  store { i64, ptr } %t301, ptr %l160, !tbaa !27
  %t302 = load i64, ptr %l21, !tbaa !24
  %t303 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t303, ptr %l162, !tbaa !27
  %t304 = load i64, ptr %l21, !tbaa !24
  %t306 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr i8, ptr %t307, i64 %t304
  %t309 = load i8, ptr %t308, !tbaa !32
  %t312 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr i8, ptr %t313, i64 %t302
  store i8 %t309, ptr %t314, !tbaa !32
  br label %bb47
bb47:
  %t315 = load i64, ptr %l20, !tbaa !24
  %t317 = add i64 %t315, 1
  store i64 %t317, ptr %l20, !tbaa !24
  br label %bb43
bb48:
  br label %bb49
bb49:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"std/io:Lines", ptr %t319, i32 0, i32 0
  %t322 = load i32, ptr %t321, !tbaa !23
  store i32 %t322, ptr %l168, !tbaa !23
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"std/io:Lines", ptr %t323, i32 0, i32 1
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l170, !tbaa !27
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"std/io:Lines", ptr %t327, i32 0, i32 3
  %t330 = load i64, ptr %t329, !tbaa !24
  store i64 %t330, ptr %l172, !tbaa !24
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"std/io:Lines", ptr %t331, i32 0, i32 1
  %t334 = load { i64, ptr }, ptr %t333, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t334, 0
  store i64 %t337, ptr %l176, !tbaa !24
  %t338 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 0
  store i64 %t339, ptr %l177, !tbaa !24
  %t340 = load i64, ptr %l172, !tbaa !24
  %t341 = icmp sge i64 %t340, 0
  br i1 %t341, label %bb50, label %bb51
bb50:
  %t343 = load i64, ptr %l172, !tbaa !24
  %t344 = load i64, ptr %l176, !tbaa !24
  %t345 = icmp sle i64 %t343, %t344
  br i1 %t345, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_3da5c997e7d4ef62_ab09d2a305b27bce)
  unreachable
bb52:
  %t347 = load i64, ptr %l176, !tbaa !24
  %t348 = load i64, ptr %l177, !tbaa !24
  %t349 = icmp sle i64 %t347, %t348
  br i1 %t349, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_3da5c997e7d4ef62_ab09d2a305b27bce)
  unreachable
bb54:
  %t351 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = load i64, ptr %l172, !tbaa !24
  %t354 = load i64, ptr %l176, !tbaa !24
  %t355 = getelementptr i8, ptr %t352, i64 %t353
  %t356 = sub i64 %t354, %t353
  %t357 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t355, 1
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"std/io:Lines", ptr %t359, i32 0, i32 1
  %t362 = load { i64, ptr }, ptr %t361, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"std/io:Lines", ptr %t365, i32 0, i32 3
  %t368 = load i64, ptr %t367, !tbaa !24
  %t371 = sub i64 %t364, %t368
  %t373 = load i32, ptr %l168, !tbaa !23
  %t375 = extractvalue { i64, ptr } %t358, 1
  %t376 = extractvalue { i64, ptr } %t358, 0
  %t378 = call i64 @read(i32 %t373, ptr %t375, i64 %t371)
  store i64 %t378, ptr %l189
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_3da5c997e7d4ef62_ab09d2a305b27bce)
  unreachable
bb56:
  %t379 = load i64, ptr %l189, !tbaa !24
  store i64 %t379, ptr %l22, !tbaa !24
  %t380 = load i64, ptr %l22, !tbaa !24
  %t382 = icmp slt i64 %t380, 0
  br i1 %t382, label %bb57, label %bb58
bb57:
  %t385 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t385, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  %t386 = load i64, ptr %l22, !tbaa !24
  %t388 = icmp eq i64 %t386, 0
  br i1 %t388, label %bb60, label %bb61
bb60:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"std/io:Lines", ptr %t390, i32 0, i32 2
  %t393 = load i64, ptr %t392, !tbaa !24
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = getelementptr %"std/io:Lines", ptr %t394, i32 0, i32 3
  %t397 = load i64, ptr %t396, !tbaa !24
  %t400 = icmp eq i64 %t393, %t397
  br i1 %t400, label %bb62, label %bb63
bb61:
  br label %bb66
bb62:
  %t403 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 131072, 0
  store { i32, { i64, ptr } } %t403, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"std/io:Lines", ptr %t404, i32 0, i32 2
  %t407 = load i64, ptr %t406, !tbaa !24
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"std/io:Lines", ptr %t410, i32 0, i32 3
  %t413 = load i64, ptr %t412, !tbaa !24
  %t416 = getelementptr %"std/io:Lines", ptr %t409, i32 0, i32 2
  store i64 %t413, ptr %t416, !tbaa !24
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr %"std/io:Lines", ptr %t419, i32 0, i32 3
  %t422 = load i64, ptr %t421, !tbaa !24
  %t426 = call { i64, ptr } @std_2fio_2estd_2fio_3aLines_2eline(ptr %v0, ptr %v1, ptr %t417, i64 %t407, i64 %t422)
  store { i64, ptr } %t426, ptr %l210
  br label %bb65
bb65:
  %t427 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t428 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t427, 1
  store { i32, { i64, ptr } } %t428, ptr %rv
  br label %ret
bb66:
  %t429 = load ptr, ptr %l0, !tbaa !29
  store ptr %t429, ptr %l211, !tbaa !29
  %t430 = load ptr, ptr %l211, !tbaa !29
  %t431 = getelementptr %"std/io:Lines", ptr %t430, i32 0, i32 3
  %t432 = load i64, ptr %t431, !tbaa !24
  %t433 = load i64, ptr %l22, !tbaa !24
  %t436 = add i64 %t432, %t433
  %t438 = load ptr, ptr %l211, !tbaa !29
  %t439 = getelementptr %"std/io:Lines", ptr %t438, i32 0, i32 3
  store i64 %t436, ptr %t439, !tbaa !24
  br label %bb67
bb67:
  br label %bb1
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @std_2fio_2estd_2fio_3aLines_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i1
  %l19 = alloca { i64, ptr }
  %l24 = alloca i64
  %l26 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t1, %t2
  store i64 %t5, ptr %l13, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp sgt i64 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/io:Lines", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l19, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = sub i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp eq i8 %t23, 13
  store i1 %t25, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb4, label %bb5
bb4:
  store i64 1, ptr %l24, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = load i64, ptr %l24, !tbaa !24
  %t30 = sub i64 %t28, %t29
  store i64 %t30, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  store i64 %t32, ptr %l26, !tbaa !24
  %t33 = load i64, ptr %l26, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t43 = extractvalue { i64, ptr } %t40, 0
  %t44 = extractvalue { i64, ptr } %t40, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t49, ptr %lp4
  %t51 = load ptr, ptr %lp4
  store { i64, ptr } %t48, ptr %t51, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  store i64 %t52, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp sgt i64 %t54, %t55
  br i1 %t58, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_56fdf4dcd8eda50e_44906f9ee22a8e92)
  unreachable
bb9:
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb14
bb11:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = sub i64 %t72, 1
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = sdiv i64 %t74, %t75
  store i64 %t78, ptr %l38, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb13
bb13:
  %t80 = load i64, ptr %l38, !tbaa !24
  store i64 %t80, ptr %l35, !tbaa !24
  br label %bb14
bb14:
  %t81 = load i64, ptr %l35, !tbaa !24
  store i64 %t81, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  %t82 = load i64, ptr %l9, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t90 = load i64, ptr %l5, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t92 = load i64, ptr %l7, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l10, !tbaa !24
  %t100 = load ptr, ptr %lp4
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l56, !tbaa !27
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"std/io:Lines", ptr %t103, i32 0, i32 1
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l59, !tbaa !27
  %t107 = load i64, ptr %l1, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t119 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i8, ptr %t120, i64 %t102
  store i8 %t116, ptr %t121, !tbaa !32
  br label %bb19
bb19:
  %t122 = load i64, ptr %l9, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l9, !tbaa !24
  br label %bb15
bb20:
  %t126 = load ptr, ptr %lp4
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2edrain(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"std/io:Writer", ptr %t3, i32 0, i32 3
  %t6 = load i32, ptr %t5, !tbaa !23
  %t8 = icmp eq i32 %t6, 1
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i32 65536, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"std/io:Writer", ptr %t11, i32 0, i32 3
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = icmp eq i32 %t14, 2
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i32 65537, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l59 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Writer", ptr %t1, i32 0, i32 3
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/io:Writer", ptr %t13, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"std/io:Writer", ptr %t19, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  %t25 = sub i64 %t18, %t22
  %t28 = icmp sgt i64 %t12, %t25
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2edrain(ptr %v0, ptr %t30)
  br label %bb6
bb5:
  br label %bb11
bb6:
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"std/io:Writer", ptr %t33, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t41 = icmp sge i64 %t32, %t38
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2esend(ptr %v0, ptr %v1, ptr %t43, { i64, ptr } %t44)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"std/io:Writer", ptr %t47, i32 0, i32 2
  %t50 = load i64, ptr %t49, !tbaa !24
  store i64 %t50, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l2, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = icmp sgt i64 %t54, %t55
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb17
bb14:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l4, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = sub i64 %t72, 1
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = sdiv i64 %t74, %t75
  store i64 %t78, ptr %l40, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb16
bb16:
  %t80 = load i64, ptr %l40, !tbaa !24
  store i64 %t80, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t81 = load i64, ptr %l37, !tbaa !24
  store i64 %t81, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t90 = load i64, ptr %l4, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l9, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"std/io:Writer", ptr %t100, i32 0, i32 1
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l59, !tbaa !27
  %t104 = load i64, ptr %l3, !tbaa !24
  %t105 = load i64, ptr %l9, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t109 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t109, ptr %l63, !tbaa !27
  %t110 = load i64, ptr %l9, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t118 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i8, ptr %t119, i64 %t108
  store i8 %t115, ptr %t120, !tbaa !32
  br label %bb22
bb22:
  %t121 = load i64, ptr %l8, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l8, !tbaa !24
  br label %bb18
bb23:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i64, ptr %l3, !tbaa !24
  %t127 = load i64, ptr %l2, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t133 = getelementptr %"std/io:Writer", ptr %t125, i32 0, i32 2
  store i64 %t130, ptr %t133, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fio_2estd_2fio_3aWriter_2eWriteChar(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l18 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Writer", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/io:Writer", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp eq i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2edrain(ptr %v0, ptr %t15)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/io:Writer", ptr %t17, i32 0, i32 3
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = icmp ne i32 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/io:Writer", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l13, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"std/io:Writer", ptr %t28, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i8, ptr %t37, i64 %t31
  store i8 %a1, ptr %t38, !tbaa !32
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l18, !tbaa !29
  %t40 = load ptr, ptr %l18, !tbaa !29
  %t41 = getelementptr %"std/io:Writer", ptr %t40, i32 0, i32 2
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = add i64 %t42, 1
  %t46 = load ptr, ptr %l18, !tbaa !29
  %t47 = getelementptr %"std/io:Writer", ptr %t46, i32 0, i32 2
  store i64 %t44, ptr %t47, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fio_2estd_2fio_3aWriter_2edrain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i1
  %l8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Writer", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/io:Writer", ptr %t8, i32 0, i32 3
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = icmp eq i32 %t11, 0
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l8, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/io:Writer", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l10, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/io:Writer", ptr %t21, i32 0, i32 2
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l12, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l13, !tbaa !24
  %t27 = icmp sge i64 0, 0
  br i1 %t27, label %bb6, label %bb7
bb5:
  br label %bb13
bb6:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = icmp sle i64 0, %t29
  br i1 %t30, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_2286ff1fbe683020_e6ca3016afdcd184)
  unreachable
bb8:
  %t32 = load i64, ptr %l12, !tbaa !24
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = icmp sle i64 %t32, %t33
  br i1 %t34, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2286ff1fbe683020_e6ca3016afdcd184)
  unreachable
bb10:
  %t36 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = load i64, ptr %l12, !tbaa !24
  %t39 = getelementptr i8, ptr %t37, i64 0
  %t40 = sub i64 %t38, 0
  %t41 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t39, 1
  %t43 = load ptr, ptr %l8, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2esend(ptr %v0, ptr %v0, ptr %t43, { i64, ptr } %t42)
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_2286ff1fbe683020_e6ca3016afdcd184)
  unreachable
bb12:
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"std/io:Writer", ptr %t45, i32 0, i32 2
  store i64 0, ptr %t47, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fio_2estd_2fio_3aWriter_2esend(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Writer", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t8 = call i32 @std_2fio_2eWrite(ptr %v1, i32 %t4, { i64, ptr } %a1)
  store i32 %t8, ptr %l5
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  br label %bb1
bb1:
  br label %bb9
bb2:
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = icmp eq i32 %t11, 65536
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i32, ptr %l5, !tbaa !23
  %t15 = icmp eq i32 %t14, 65537
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_ert_req_clear()
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/io:Writer", ptr %t17, i32 0, i32 3
  store i32 1, ptr %t19, !tbaa !23
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_ad9bafd1943ad1d9_899b8bae4e2234dd)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/io:Writer", ptr %t20, i32 0, i32 3
  store i32 2, ptr %t22, !tbaa !23
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local %"std/io:Lines" @std_2fio_3aLines_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i32
  %l9 = alloca i64
  %rv = alloca %"std/io:Lines"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l2, !tbaa !23
  %t3 = load i64, ptr %l1, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  br label %bb3
bb2:
  store i64 1, ptr %l9, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l9, !tbaa !24
  %t10 = icmp sge i64 %t9, 0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  %t19 = extractvalue { i64, ptr } %t16, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = insertvalue %"std/io:Lines" undef, i32 %t26, 0
  %t29 = insertvalue %"std/io:Lines" %t27, { i64, ptr } %t24, 1
  %t31 = insertvalue %"std/io:Lines" %t29, i64 0, 2
  %t33 = insertvalue %"std/io:Lines" %t31, i64 0, 3
  store %"std/io:Lines" %t33, ptr %rv
  br label %ret
bb5:
  call void @__olang_check_failed(ptr @olang_loc_85198735f567fdd6_a81bd0a72fe385a2)
  unreachable
ret:
  %rr = load %"std/io:Lines", ptr %rv
  ret %"std/io:Lines" %rr
}

define dso_local %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i32
  %l9 = alloca i64
  %rv = alloca %"std/io:Writer"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l2, !tbaa !23
  %t3 = load i64, ptr %l1, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  br label %bb3
bb2:
  store i64 1, ptr %l9, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l9, !tbaa !24
  %t10 = icmp sge i64 %t9, 0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  %t18 = load i32, ptr %l2, !tbaa !23
  %t19 = insertvalue %"std/io:Writer" undef, i32 %t18, 0
  %t21 = insertvalue %"std/io:Writer" %t19, { i64, ptr } %t16, 1
  %t23 = insertvalue %"std/io:Writer" %t21, i64 0, 2
  %t25 = insertvalue %"std/io:Writer" %t23, i32 0, 3
  store %"std/io:Writer" %t25, ptr %rv
  br label %ret
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6cd41157f4fd8842_c8d3cc71cb27ad56)
  unreachable
ret:
  %rr = load %"std/io:Writer", ptr %rv
  ret %"std/io:Writer" %rr
}

@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare i64 @read(i32, ptr, i64)
declare void @__olang_check_failed(ptr) cold noreturn
declare i64 @write(i32, ptr, i64)
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d2 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"only" }>, align 8
declare void @__olang_ert_req_clear()
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
declare i32 @close(i32)
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d8 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"more than four bytes" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d9 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"-------------------------------------------------------------" }>, align 8
declare i32 @open(ptr, i32, ...)
declare i32 @pipe(ptr)
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"line " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_loc_e183f6af0815be24_39313b6101d20ca8 = external constant [0 x i8]
@olang_loc_405125a8bfc97357_6687826239f87cdb = external constant [0 x i8]
@olang_loc_d56021b6e5c3bdfa_44c4511adba970be = external constant [0 x i8]
@olang_loc_9191d7d375be9bf_456d8efa2f19b6b = external constant [0 x i8]
@olang_loc_ecfe7bc4e914c155_2facd670f5d599 = external constant [0 x i8]
@olang_loc_236626def65966f_f8ee7e95debf0f53 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8ace81b314be0ed6_98e2c78d06064582 = external constant [0 x i8]
@olang_loc_cdec8918cbf67d26_bc226afea482d74a = external constant [0 x i8]
@olang_loc_19a3a555e0bc0672_a80c148e75e56d4e = external constant [0 x i8]
@olang_loc_5d46b41c36e8feff_84fddb7c6ef404db = external constant [0 x i8]
@olang_loc_65126f5b67a1f66c_44d990074c227388 = external constant [0 x i8]
@olang_loc_e6fc1695886d91da_b063287e95dbbab6 = external constant [0 x i8]
@olang_loc_48f9082997753888_a240ae8e5e29a0c = external constant [0 x i8]
@olang_loc_6ee02aeeb4b82e91_bbd4c13499124615 = external constant [0 x i8]
@olang_loc_2e343f18828dc6fc_fb3c99ef2ae70d28 = external constant [0 x i8]
@olang_loc_6b542447dc4d89ad_116b4d1aefb73901 = external constant [0 x i8]
@olang_loc_82463fd07313b343_899050d6bae42837 = external constant [0 x i8]
@olang_loc_5dc1029830d6aac4_75c290e3de4fa170 = external constant [0 x i8]
@olang_loc_b6949e6a237530b_4c14899758e8fd2f = external constant [0 x i8]
@olang_loc_5f2b8b2f6326e81f_f1c47ff7019f64c3 = external constant [0 x i8]
@olang_loc_3da5c997e7d4ef62_ab09d2a305b27bce = external constant [0 x i8]
@olang_loc_56fdf4dcd8eda50e_44906f9ee22a8e92 = external constant [0 x i8]
@olang_loc_2286ff1fbe683020_e6ca3016afdcd184 = external constant [0 x i8]
@olang_loc_ad9bafd1943ad1d9_899b8bae4e2234dd = external constant [0 x i8]
@olang_loc_85198735f567fdd6_a81bd0a72fe385a2 = external constant [0 x i8]
@olang_loc_6cd41157f4fd8842_c8d3cc71cb27ad56 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
