; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, i32 }
@G_2estd_2fio_2eStderr = global i32 zeroinitializer
@G_2estd_2fio_2eStdin = global i32 zeroinitializer
@G_2estd_2fio_2eStdout = global i32 zeroinitializer
define dso_local void @olang_2einit_2estd_2fio() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fio_2eStdin_2einit()
  br label %bb1
bb1:
  call void @std_2fio_2eStdout_2einit()
  br label %bb2
bb2:
  call void @std_2fio_2eStderr_2einit()
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2estd_2fio_2eStdout
  store i32 %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l3
  %t4 = load i32, ptr %l1
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = call i32 @std_2fio_2eWrite(ptr %v0, i32 %t4, { i64, ptr } %t5)
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t9 = load i32, ptr %l4
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  store i32 %t17, ptr %l5
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l5
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2estd_2fio_2eStderr
  store i32 %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l3
  %t4 = load i32, ptr %l1
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = call i32 @std_2fio_2eWrite(ptr %v0, i32 %t4, { i64, ptr } %t5)
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t9 = load i32, ptr %l4
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  store i32 %t17, ptr %l5
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l5
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ePrintErrln(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2estd_2fio_2eStderr
  store i32 %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t2, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l2
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d0 }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d0 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %s1
  %t9 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t10 = load i64, ptr %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t8, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t14 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t14, ptr %l4
  %t15 = load { i64, ptr }, ptr %l4
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l5
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l5
  %t24 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %t22, { i64, ptr } %t23)
  store i32 %t24, ptr %l6
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb2, label %ok.26
ok.26:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t27 = load i32, ptr %l6
  %t28 = lshr i32 %t27, 16
  %t29 = and i32 %t27, 65535
  %t30 = icmp eq i32 %t28, 1
  %t31 = select i1 %t30, i32 1, i32 0
  %t32 = icmp eq i32 %t27, 0
  %t33 = shl i32 %t31, 16
  %t34 = or i32 %t33, %t29
  %t35 = select i1 %t32, i32 0, i32 %t34
  store i32 %t35, ptr %l7
  call void @__olang_scope_close(ptr %s0)
  %t36 = load i32, ptr %l7
  store i32 %t36, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2estd_2fio_2eStdout
  store i32 %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t2, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l2
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d1 }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d1 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %s1
  %t9 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t10 = load i64, ptr %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t8, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t14 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t14, ptr %l4
  %t15 = load { i64, ptr }, ptr %l4
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l5
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l5
  %t24 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %t22, { i64, ptr } %t23)
  store i32 %t24, ptr %l6
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb2, label %ok.26
ok.26:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t27 = load i32, ptr %l6
  %t28 = lshr i32 %t27, 16
  %t29 = and i32 %t27, 65535
  %t30 = icmp eq i32 %t28, 1
  %t31 = select i1 %t30, i32 1, i32 0
  %t32 = icmp eq i32 %t27, 0
  %t33 = shl i32 %t31, 16
  %t34 = or i32 %t33, %t29
  %t35 = select i1 %t32, i32 0, i32 %t34
  store i32 %t35, ptr %l7
  call void @__olang_scope_close(ptr %s0)
  %t36 = load i32, ptr %l7
  store i32 %t36, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fio_2eStderr_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 2, ptr @G_2estd_2fio_2eStderr
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fio_2eStdin_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 0, ptr @G_2estd_2fio_2eStdin
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fio_2eStdout_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 1, ptr @G_2estd_2fio_2eStdout
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store i32 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t1, ptr %l6
  %t2 = load { i64, ptr }, ptr %l6
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l7
  %t4 = load i64, ptr %l7
  store i64 %t4, ptr %l2
  %t5 = load i64, ptr %l2
  store i64 %t5, ptr %l8
  %t6 = load i64, ptr %l8
  %t7 = icmp eq i64 %t6, 0
  store i1 %t7, ptr %l9
  %t8 = load i1, ptr %l9
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l3
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t9, ptr %l10
  %t10 = load i64, ptr %l3
  store i64 %t10, ptr %l11
  %t11 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t11, ptr %l12
  %t12 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t12, ptr %l13
  %t13 = load { i64, ptr }, ptr %l13
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l14
  %t15 = load { i64, ptr }, ptr %l10
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l15
  %t17 = load i64, ptr %l11
  %t18 = icmp sge i64 %t17, 0
  store i1 %t18, ptr %l16
  %t19 = load i1, ptr %l16
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l11
  %t21 = load i64, ptr %l14
  %t22 = icmp sle i64 %t20, %t21
  store i1 %t22, ptr %l17
  %t23 = load i1, ptr %l17
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb7:
  %t24 = load i64, ptr %l14
  %t25 = load i64, ptr %l15
  %t26 = icmp sle i64 %t24, %t25
  store i1 %t26, ptr %l18
  %t27 = load i1, ptr %l18
  br i1 %t27, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb9:
  %t28 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  %t30 = load i64, ptr %l11
  %t31 = load i64, ptr %l14
  %t32 = getelementptr i8, ptr %t29, i64 %t30
  %t33 = sub i64 %t31, %t30
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  store { i64, ptr } %t35, ptr %l19
  %t36 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t36, ptr %l4
  %t37 = load i32, ptr %l0
  store i32 %t37, ptr %l20
  %t38 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t38, ptr %l21
  %t39 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t39, ptr %l22
  %t40 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t40, ptr %l23
  %t41 = load { i64, ptr }, ptr %l23
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l24
  %t43 = load i32, ptr %l20
  %t44 = load { i64, ptr }, ptr %l22
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = load i64, ptr %l24
  %t48 = call i64 @write(i32 %t43, ptr %t45, i64 %t47)
  store i64 %t48, ptr %l25
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb11:
  %t49 = load i64, ptr %l25
  store i64 %t49, ptr %l5
  %t50 = load i64, ptr %l5
  store i64 %t50, ptr %l26
  %t51 = load i64, ptr %l26
  %t52 = icmp slt i64 %t51, 0
  store i1 %t52, ptr %l27
  %t53 = load i1, ptr %l27
  br i1 %t53, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 65536, ptr %l28
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t54 = load i32, ptr %l28
  store i32 %t54, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t55 = load i64, ptr %l5
  store i64 %t55, ptr %l29
  %t56 = load i64, ptr %l29
  %t57 = icmp eq i64 %t56, 0
  store i1 %t57, ptr %l30
  %t58 = load i1, ptr %l30
  br i1 %t58, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store i32 65537, ptr %l31
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t59 = load i32, ptr %l31
  store i32 %t59, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load i64, ptr %l3
  store i64 %t60, ptr %l32
  %t61 = load i64, ptr %l5
  store i64 %t61, ptr %l33
  %t62 = load i64, ptr %l32
  %t63 = load i64, ptr %l33
  %t64 = add i64 %t62, %t63
  store i64 %t64, ptr %l34
  %t65 = load i64, ptr %l34
  store i64 %t65, ptr %l3
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t66 = load i64, ptr %l3
  store i64 %t66, ptr %l35
  %t67 = load i64, ptr %l2
  store i64 %t67, ptr %l36
  %t68 = load i64, ptr %l35
  %t69 = load i64, ptr %l36
  %t70 = icmp slt i64 %t68, %t69
  store i1 %t70, ptr %l37
  %t71 = load i1, ptr %l37
  %t72 = xor i1 %t71, true
  store i1 %t72, ptr %l38
  %t73 = load i1, ptr %l38
  br i1 %t73, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb4
bb22:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l1
  %t2 = load ptr, ptr %l1
  call void @std_2fio_2estd_2fio_3aWriter_2edrain(ptr %v0, ptr %t2)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0
  store ptr %t3, ptr %l2
  %t4 = load ptr, ptr %l2
  %t5 = getelementptr %"std/io:Writer", ptr %t4, i32 0, i32 3
  %t6 = load i32, ptr %t5
  store i32 %t6, ptr %l3
  %t7 = load i32, ptr %l3
  %t8 = icmp eq i32 %t7, 1
  store i1 %t8, ptr %l4
  %t9 = load i1, ptr %l4
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l5
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i32, ptr %l5
  store i32 %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0
  store ptr %t11, ptr %l6
  %t12 = load ptr, ptr %l6
  %t13 = getelementptr %"std/io:Writer", ptr %t12, i32 0, i32 3
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l7
  %t15 = load i32, ptr %l7
  %t16 = icmp eq i32 %t15, 2
  store i1 %t16, ptr %l8
  %t17 = load i1, ptr %l8
  br i1 %t17, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 65537, ptr %l9
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l9
  store i32 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i8
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l10
  %t2 = load ptr, ptr %l10
  %t3 = getelementptr %"std/io:Writer", ptr %t2, i32 0, i32 3
  %t4 = load i32, ptr %t3
  store i32 %t4, ptr %l11
  %t5 = load i32, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  store i1 %t6, ptr %l12
  %t7 = load i1, ptr %l12
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t8, ptr %l13
  %t9 = load { i64, ptr }, ptr %l13
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l14
  %t11 = load i64, ptr %l14
  store i64 %t11, ptr %l2
  %t12 = load i64, ptr %l2
  store i64 %t12, ptr %l15
  %t13 = load ptr, ptr %l0
  store ptr %t13, ptr %l16
  %t14 = load ptr, ptr %l16
  %t15 = getelementptr %"std/io:Writer", ptr %t14, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15
  store { i64, ptr } %t16, ptr %l17
  %t17 = load { i64, ptr }, ptr %l17
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l18
  %t19 = load ptr, ptr %l0
  store ptr %t19, ptr %l19
  %t20 = load ptr, ptr %l19
  %t21 = getelementptr %"std/io:Writer", ptr %t20, i32 0, i32 2
  %t22 = load i64, ptr %t21
  store i64 %t22, ptr %l20
  %t23 = load i64, ptr %l18
  %t24 = load i64, ptr %l20
  %t25 = sub i64 %t23, %t24
  store i64 %t25, ptr %l21
  %t26 = load i64, ptr %l15
  %t27 = load i64, ptr %l21
  %t28 = icmp sgt i64 %t26, %t27
  store i1 %t28, ptr %l22
  %t29 = load i1, ptr %l22
  br i1 %t29, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0
  store ptr %t30, ptr %l23
  %t31 = load ptr, ptr %l23
  call void @std_2fio_2estd_2fio_3aWriter_2edrain(ptr %v0, ptr %t31)
  br label %bb6
bb5:
  br label %bb11
bb6:
  %t32 = load i64, ptr %l2
  store i64 %t32, ptr %l24
  %t33 = load ptr, ptr %l0
  store ptr %t33, ptr %l25
  %t34 = load ptr, ptr %l25
  %t35 = getelementptr %"std/io:Writer", ptr %t34, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35
  store { i64, ptr } %t36, ptr %l26
  %t37 = load { i64, ptr }, ptr %l26
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l27
  %t39 = load i64, ptr %l24
  %t40 = load i64, ptr %l27
  %t41 = icmp sge i64 %t39, %t40
  store i1 %t41, ptr %l28
  %t42 = load i1, ptr %l28
  br i1 %t42, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load ptr, ptr %l0
  store ptr %t43, ptr %l29
  %t44 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t44, ptr %l30
  %t45 = load ptr, ptr %l29
  %t46 = load { i64, ptr }, ptr %l30
  call void @std_2fio_2estd_2fio_3aWriter_2esend(ptr %v0, ptr %v1, ptr %t45, { i64, ptr } %t46)
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l0
  store ptr %t47, ptr %l31
  %t48 = load ptr, ptr %l31
  %t49 = getelementptr %"std/io:Writer", ptr %t48, i32 0, i32 2
  %t50 = load i64, ptr %t49
  store i64 %t50, ptr %l32
  %t51 = load i64, ptr %l32
  store i64 %t51, ptr %l3
  store %olang.scope zeroinitializer, ptr %s4
  store i64 0, ptr %l4
  %t52 = load i64, ptr %l2
  store i64 %t52, ptr %l33
  %t53 = load i64, ptr %l33
  store i64 %t53, ptr %l5
  store i64 1, ptr %l6
  %t54 = load i64, ptr %l5
  store i64 %t54, ptr %l34
  %t55 = load i64, ptr %l4
  store i64 %t55, ptr %l35
  %t56 = load i64, ptr %l34
  %t57 = load i64, ptr %l35
  %t58 = icmp sgt i64 %t56, %t57
  store i1 %t58, ptr %l36
  %t59 = load i1, ptr %l36
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t60 = load i64, ptr %l6
  store i64 %t60, ptr %l38
  %t61 = load i64, ptr %l38
  %t62 = icmp sgt i64 %t61, 0
  store i1 %t62, ptr %l39
  %t63 = load i1, ptr %l39
  br i1 %t63, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l37
  br label %bb17
bb14:
  %t64 = load i64, ptr %l5
  store i64 %t64, ptr %l41
  %t65 = load i64, ptr %l4
  store i64 %t65, ptr %l42
  %t66 = load i64, ptr %l41
  %t67 = load i64, ptr %l42
  %t68 = sub i64 %t66, %t67
  store i64 %t68, ptr %l43
  %t69 = load i64, ptr %l6
  store i64 %t69, ptr %l44
  %t70 = load i64, ptr %l43
  %t71 = load i64, ptr %l44
  %t72 = add i64 %t70, %t71
  store i64 %t72, ptr %l45
  %t73 = load i64, ptr %l45
  %t74 = sub i64 %t73, 1
  store i64 %t74, ptr %l46
  %t75 = load i64, ptr %l6
  store i64 %t75, ptr %l47
  %t76 = load i64, ptr %l46
  %t77 = load i64, ptr %l47
  %t78 = sdiv i64 %t76, %t77
  store i64 %t78, ptr %l48
  %t79 = load i64, ptr %l48
  store i64 %t79, ptr %l40
  br label %bb16
bb15:
  store i64 0, ptr %l40
  br label %bb16
bb16:
  %t80 = load i64, ptr %l40
  store i64 %t80, ptr %l37
  br label %bb17
bb17:
  %t81 = load i64, ptr %l37
  store i64 %t81, ptr %l7
  store i64 0, ptr %l8
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t82 = load i64, ptr %l8
  store i64 %t82, ptr %l49
  %t83 = load i64, ptr %l7
  store i64 %t83, ptr %l50
  %t84 = load i64, ptr %l49
  %t85 = load i64, ptr %l50
  %t86 = icmp slt i64 %t84, %t85
  store i1 %t86, ptr %l51
  %t87 = load i1, ptr %l51
  %t88 = xor i1 %t87, true
  store i1 %t88, ptr %l52
  %t89 = load i1, ptr %l52
  br i1 %t89, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t90 = load i64, ptr %l4
  store i64 %t90, ptr %l53
  %t91 = load i64, ptr %l8
  store i64 %t91, ptr %l54
  %t92 = load i64, ptr %l6
  store i64 %t92, ptr %l55
  %t93 = load i64, ptr %l54
  %t94 = load i64, ptr %l55
  %t95 = mul i64 %t93, %t94
  store i64 %t95, ptr %l56
  %t96 = load i64, ptr %l53
  %t97 = load i64, ptr %l56
  %t98 = add i64 %t96, %t97
  store i64 %t98, ptr %l57
  %t99 = load i64, ptr %l57
  store i64 %t99, ptr %l9
  %t100 = load ptr, ptr %l0
  store ptr %t100, ptr %l58
  %t101 = load ptr, ptr %l58
  %t102 = getelementptr %"std/io:Writer", ptr %t101, i32 0, i32 1
  %t103 = load { i64, ptr }, ptr %t102
  store { i64, ptr } %t103, ptr %l59
  %t104 = load i64, ptr %l3
  store i64 %t104, ptr %l60
  %t105 = load i64, ptr %l9
  store i64 %t105, ptr %l61
  %t106 = load i64, ptr %l60
  %t107 = load i64, ptr %l61
  %t108 = add i64 %t106, %t107
  store i64 %t108, ptr %l62
  %t109 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t109, ptr %l63
  %t110 = load i64, ptr %l9
  store i64 %t110, ptr %l64
  %t111 = load i64, ptr %l64
  %t112 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t113 = load ptr, ptr %t112
  %t114 = getelementptr i8, ptr %t113, i64 %t111
  %t115 = load i8, ptr %t114
  store i8 %t115, ptr %l65
  %t116 = load i8, ptr %l65
  %t117 = load i64, ptr %l62
  %t118 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t119 = load ptr, ptr %t118
  %t120 = getelementptr i8, ptr %t119, i64 %t117
  store i8 %t116, ptr %t120
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t121 = load i64, ptr %l8
  store i64 %t121, ptr %l66
  %t122 = load i64, ptr %l66
  %t123 = add i64 %t122, 1
  store i64 %t123, ptr %l67
  %t124 = load i64, ptr %l67
  store i64 %t124, ptr %l8
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb23:
  call void @__olang_scope_close(ptr %s4)
  %t125 = load ptr, ptr %l0
  store ptr %t125, ptr %l68
  %t126 = load i64, ptr %l3
  store i64 %t126, ptr %l69
  %t127 = load i64, ptr %l2
  store i64 %t127, ptr %l70
  %t128 = load i64, ptr %l69
  %t129 = load i64, ptr %l70
  %t130 = add i64 %t128, %t129
  store i64 %t130, ptr %l71
  %t131 = load i64, ptr %l71
  %t132 = load ptr, ptr %l68
  %t133 = getelementptr %"std/io:Writer", ptr %t132, i32 0, i32 2
  store i64 %t131, ptr %t133
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fio_2estd_2fio_3aWriter_2edrain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l1
  %t2 = load ptr, ptr %l1
  %t3 = getelementptr %"std/io:Writer", ptr %t2, i32 0, i32 2
  %t4 = load i64, ptr %t3
  store i64 %t4, ptr %l2
  %t5 = load i64, ptr %l2
  %t6 = icmp sgt i64 %t5, 0
  store i1 %t6, ptr %l3
  %t7 = load i1, ptr %l3
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0
  store ptr %t8, ptr %l5
  %t9 = load ptr, ptr %l5
  %t10 = getelementptr %"std/io:Writer", ptr %t9, i32 0, i32 3
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l6
  %t12 = load i32, ptr %l6
  %t13 = icmp eq i32 %t12, 0
  store i1 %t13, ptr %l7
  %t14 = load i1, ptr %l7
  store i1 %t14, ptr %l4
  br label %bb3
bb2:
  store i1 false, ptr %l4
  br label %bb3
bb3:
  %t15 = load i1, ptr %l4
  br i1 %t15, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l8
  %t17 = load ptr, ptr %l0
  store ptr %t17, ptr %l9
  %t18 = load ptr, ptr %l9
  %t19 = getelementptr %"std/io:Writer", ptr %t18, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l10
  %t21 = load ptr, ptr %l0
  store ptr %t21, ptr %l11
  %t22 = load ptr, ptr %l11
  %t23 = getelementptr %"std/io:Writer", ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l12
  %t25 = load { i64, ptr }, ptr %l10
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l13
  %t27 = icmp sge i64 0, 0
  store i1 %t27, ptr %l14
  %t28 = load i1, ptr %l14
  br i1 %t28, label %bb6, label %bb7
bb5:
  br label %bb13
bb6:
  %t29 = load i64, ptr %l12
  %t30 = icmp sle i64 0, %t29
  store i1 %t30, ptr %l15
  %t31 = load i1, ptr %l15
  br i1 %t31, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb8:
  %t32 = load i64, ptr %l12
  %t33 = load i64, ptr %l13
  %t34 = icmp sle i64 %t32, %t33
  store i1 %t34, ptr %l16
  %t35 = load i1, ptr %l16
  br i1 %t35, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb10:
  %t36 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  %t38 = load i64, ptr %l12
  %t39 = getelementptr i8, ptr %t37, i64 0
  %t40 = sub i64 %t38, 0
  %t41 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t39, 1
  store { i64, ptr } %t42, ptr %l17
  %t43 = load ptr, ptr %l8
  %t44 = load { i64, ptr }, ptr %l17
  call void @std_2fio_2estd_2fio_3aWriter_2esend(ptr %v0, ptr %v0, ptr %t43, { i64, ptr } %t44)
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l0
  store ptr %t45, ptr %l18
  %t46 = load ptr, ptr %l18
  %t47 = getelementptr %"std/io:Writer", ptr %t46, i32 0, i32 2
  store i64 0, ptr %t47
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fio_2estd_2fio_3aWriter_2esend(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l2
  %t2 = load ptr, ptr %l2
  %t3 = getelementptr %"std/io:Writer", ptr %t2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  store i32 %t4, ptr %l3
  %t5 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t5, ptr %l4
  %t6 = load i32, ptr %l3
  %t7 = load { i64, ptr }, ptr %l4
  %t8 = call i32 @std_2fio_2eWrite(ptr %v1, i32 %t6, { i64, ptr } %t7)
  store i32 %t8, ptr %l5
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10
ok.10:
  br label %bb1
bb1:
  br label %bb9
bb2:
  %t11 = load i32, ptr %l5
  %t12 = icmp eq i32 %t11, 65536
  store i1 %t12, ptr %l6
  %t13 = load i1, ptr %l6
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i32, ptr %l5
  %t15 = icmp eq i32 %t14, 65537
  store i1 %t15, ptr %l7
  %t16 = load i1, ptr %l7
  br i1 %t16, label %bb6, label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0
  store ptr %t17, ptr %l8
  %t18 = load ptr, ptr %l8
  %t19 = getelementptr %"std/io:Writer", ptr %t18, i32 0, i32 3
  store i32 1, ptr %t19
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load ptr, ptr %l0
  store ptr %t20, ptr %l9
  %t21 = load ptr, ptr %l9
  %t22 = getelementptr %"std/io:Writer", ptr %t21, i32 0, i32 3
  store i32 2, ptr %t22
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/io:Writer"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/io:Writer"
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l6
  %t2 = load i32, ptr %l6
  store i32 %t2, ptr %l2
  %t3 = load i64, ptr %l1
  store i64 %t3, ptr %l7
  %t4 = load i64, ptr %l7
  %t5 = icmp sgt i64 %t4, 0
  store i1 %t5, ptr %l8
  %t6 = load i1, ptr %l8
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l1
  store i64 %t7, ptr %l10
  %t8 = load i64, ptr %l10
  store i64 %t8, ptr %l9
  br label %bb3
bb2:
  store i64 1, ptr %l9
  br label %bb3
bb3:
  %t9 = load i64, ptr %l9
  %t10 = icmp sge i64 %t9, 0
  store i1 %t10, ptr %l11
  %t11 = load i1, ptr %l11
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l9
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l12
  %t17 = load { i64, ptr }, ptr %l12
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l13
  %t24 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t24, ptr %l3
  store i64 0, ptr %l4
  store i32 0, ptr %l5
  %t25 = load i32, ptr %l2
  %t26 = insertvalue %"std/io:Writer" undef, i32 %t25, 0
  %t27 = load { i64, ptr }, ptr %l3
  %t28 = insertvalue %"std/io:Writer" %t26, { i64, ptr } %t27, 1
  %t29 = load i64, ptr %l4
  %t30 = insertvalue %"std/io:Writer" %t28, i64 %t29, 2
  %t31 = load i32, ptr %l5
  %t32 = insertvalue %"std/io:Writer" %t30, i32 %t31, 3
  store %"std/io:Writer" %t32, ptr %l14
  call void @__olang_scope_close(ptr %s0)
  %t33 = load %"std/io:Writer", ptr %l14
  store %"std/io:Writer" %t33, ptr %rv
  br label %ret
bb5:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
ret:
  %rr = load %"std/io:Writer", ptr %rv
  ret %"std/io:Writer" %rr
}

declare void @__olang_scope_close(ptr)
declare void @__olang_sb_put(ptr, ptr, i64)
@.d0 = private constant [1 x i8] c"\0A"
declare ptr @__olang_scope_alloc(ptr, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_sb_done(ptr)
@.d1 = private constant [1 x i8] c"\0A"
declare void @__olang_check_failed(ptr)
@.c2 = private unnamed_addr constant [44 x i8] c"std/io.olang:42: slice bounds out of range\0A\00"
declare i64 @write(i32, ptr, i64)
@.c3 = private unnamed_addr constant [45 x i8] c"std/io.olang:244: slice bounds out of range\0A\00"
@.c4 = private unnamed_addr constant [44 x i8] c"std/io.olang:249: reached unreachable code\0A\00"
declare ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.c5 = private unnamed_addr constant [45 x i8] c"std/io.olang:206: array length out of range\0A\00"
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
