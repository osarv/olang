; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/measure:Sample" = type { i64, i64, i64, i64, i64 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
define dso_local { i64, ptr } @compiler_2fmeasure_2eLine(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/measure:Sample"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/measure:Sample"
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/measure:Sample"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/measure:Sample"
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l34 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l52 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l70 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l90 = alloca i64
  %l98 = alloca { i64, ptr }
  %l100 = alloca double
  %l102 = alloca double
  %l103 = alloca { i64, ptr }
  %l107 = alloca double
  %l108 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l115 = alloca double
  %l116 = alloca { i64, ptr }
  %l118 = alloca double
  %l119 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = mul i64 %t7, 8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  br label %bb1
bb1:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l34, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/measure:Sample", ptr %t25, i64 %t22
  %t27 = load %"compiler/measure:Sample", ptr %t26
  store %"compiler/measure:Sample" %t27, ptr %l5
  %t29 = getelementptr %"compiler/measure:Sample", ptr %l5, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = sitofp i64 %t30 to double
  %t34 = load i64, ptr %l29, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr double, ptr %t36, i64 %t34
  store double %t32, ptr %t37, !tbaa !36
  %t38 = load i64, ptr %l29, !tbaa !24
  %t39 = add i64 %t38, 1
  store i64 %t39, ptr %l29, !tbaa !24
  br label %bb5
bb5:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t40, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb1
bb6:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t46, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l9, !tbaa !24
  %t52 = load i64, ptr %l9, !tbaa !24
  %t54 = mul i64 %t52, 8
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l46, !tbaa !27
  store i64 0, ptr %l47, !tbaa !24
  br label %bb7
bb7:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l9, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t66 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t66, ptr %l52, !tbaa !27
  %t67 = load i64, ptr %l8, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr %"compiler/measure:Sample", ptr %t70, i64 %t67
  %t72 = load %"compiler/measure:Sample", ptr %t71
  store %"compiler/measure:Sample" %t72, ptr %l10
  %t74 = getelementptr %"compiler/measure:Sample", ptr %l10, i32 0, i32 1
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = sitofp i64 %t75 to double
  %t79 = load i64, ptr %l47, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr double, ptr %t81, i64 %t79
  store double %t77, ptr %t82, !tbaa !36
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = add i64 %t83, 1
  store i64 %t84, ptr %l47, !tbaa !24
  br label %bb11
bb11:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t85, 1
  store i64 %t88, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  %t90 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t90, ptr %l11, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t91, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l14, !tbaa !24
  %t97 = load i64, ptr %l14, !tbaa !24
  %t99 = mul i64 %t97, 8
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l64, !tbaa !27
  store i64 0, ptr %l65, !tbaa !24
  br label %bb13
bb13:
  %t103 = load i64, ptr %l13, !tbaa !24
  %t104 = load i64, ptr %l14, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t111 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t111, ptr %l70, !tbaa !27
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr %"compiler/measure:Sample", ptr %t115, i64 %t112
  %t117 = load %"compiler/measure:Sample", ptr %t116
  store %"compiler/measure:Sample" %t117, ptr %l15
  %t119 = getelementptr %"compiler/measure:Sample", ptr %l15, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = sitofp i64 %t120 to double
  %t124 = load i64, ptr %l65, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr double, ptr %t126, i64 %t124
  store double %t122, ptr %t127, !tbaa !36
  %t128 = load i64, ptr %l65, !tbaa !24
  %t129 = add i64 %t128, 1
  store i64 %t129, ptr %l65, !tbaa !24
  br label %bb17
bb17:
  %t130 = load i64, ptr %l13, !tbaa !24
  %t133 = add i64 %t130, 1
  store i64 %t133, ptr %l13, !tbaa !24
  br label %bb13
bb18:
  %t135 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t135, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t136, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l20, !tbaa !24
  br label %bb19
bb19:
  %t142 = load i64, ptr %l19, !tbaa !24
  %t143 = load i64, ptr %l20, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t150 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t150, ptr %l85, !tbaa !27
  %t151 = load i64, ptr %l19, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr %"compiler/measure:Sample", ptr %t154, i64 %t151
  %t156 = load %"compiler/measure:Sample", ptr %t155
  store %"compiler/measure:Sample" %t156, ptr %l21
  %t158 = load i64, ptr %l17, !tbaa !24
  %t159 = getelementptr %"compiler/measure:Sample", ptr %l21, i32 0, i32 3
  %t160 = load i64, ptr %t159, !tbaa !24
  %t163 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t158, i64 %t160)
  store i64 %t163, ptr %l90
  br label %bb23
bb23:
  %t164 = load i64, ptr %l90, !tbaa !24
  store i64 %t164, ptr %l17, !tbaa !24
  br label %bb24
bb24:
  %t165 = load i64, ptr %l19, !tbaa !24
  %t168 = add i64 %t165, 1
  store i64 %t168, ptr %l19, !tbaa !24
  br label %bb19
bb25:
  %t170 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  store i64 %t172, ptr %l22, !tbaa !24
  %t174 = load i64, ptr %l22, !tbaa !24
  %t176 = icmp sgt i64 %t174, 1
  br i1 %t176, label %bb26, label %bb27
bb26:
  %t178 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t180 = call double @std_2fbench_2eMedian(ptr %s0, { i64, ptr } %t178)
  store double %t180, ptr %l100
  br label %bb28
bb27:
  %t181 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t183 = call double @std_2fbench_2eMedian(ptr %s0, { i64, ptr } %t181)
  store double %t183, ptr %l107
  br label %bb31
bb28:
  %t184 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t186 = call double @std_2fbench_2eSpread(ptr %s0, { i64, ptr } %t184)
  store double %t186, ptr %l102
  br label %bb29
bb29:
  %t187 = load double, ptr %l100, !tbaa !26
  %t188 = load double, ptr %l102, !tbaa !26
  %t189 = call { i64, ptr } @compiler_2fmeasure_2esecsSpread(ptr %s0, double %t187, double %t188)
  store { i64, ptr } %t189, ptr %l103
  br label %bb30
bb30:
  %t190 = load i64, ptr %l22, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t198 = call i64 @__olang_fmt_i64(ptr null, i64 %t190)
  %t199 = add i64 %t196, %t198
  %t200 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t202 = add i64 %t199, %t201
  %t203 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t202)
  call void @olang_textcopy(ptr %t203, ptr %t192, i64 %t193)
  %t204 = getelementptr i8, ptr %t203, i64 %t193
  call void @olang_textcopy(ptr %t204, ptr %t194, i64 %t195)
  %t205 = getelementptr i8, ptr %t204, i64 %t195
  %t206 = call i64 @__olang_fmt_i64(ptr %t205, i64 %t190)
  %t207 = getelementptr i8, ptr %t205, i64 %t198
  call void @olang_textcopy(ptr %t207, ptr %t200, i64 %t201)
  %t208 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t203, 1
  store { i64, ptr } %t209, ptr %l98, !tbaa !27
  br label %bb33
bb31:
  %t211 = load double, ptr %l107, !tbaa !26
  %t212 = call { i64, ptr } @compiler_2fmeasure_2esecs(ptr %s0, double %t211)
  store { i64, ptr } %t212, ptr %l108
  br label %bb32
bb32:
  %t213 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t214, i64 %t215)
  %t220 = getelementptr i8, ptr %t219, i64 %t215
  call void @olang_textcopy(ptr %t220, ptr %t216, i64 %t217)
  %t221 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t219, 1
  store { i64, ptr } %t222, ptr %l98, !tbaa !27
  br label %bb33
bb33:
  %t224 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t224, ptr %l23, !tbaa !27
  %t227 = sitofp i64 %a0 to double
  %t229 = call { i64, ptr } @compiler_2fmeasure_2esecs(ptr %s0, double %t227)
  store { i64, ptr } %t229, ptr %l112
  br label %bb34
bb34:
  %t230 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t230, ptr %l113, !tbaa !27
  %t231 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t233 = call double @std_2fbench_2eMedian(ptr %s0, { i64, ptr } %t231)
  store double %t233, ptr %l115
  br label %bb35
bb35:
  %t234 = load double, ptr %l115, !tbaa !26
  %t235 = call { i64, ptr } @compiler_2fmeasure_2esecs(ptr %s0, double %t234)
  store { i64, ptr } %t235, ptr %l116
  br label %bb36
bb36:
  %t236 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t238 = call double @std_2fbench_2eMedian(ptr %s0, { i64, ptr } %t236)
  store double %t238, ptr %l118
  br label %bb37
bb37:
  %t239 = load double, ptr %l118, !tbaa !26
  %t240 = call { i64, ptr } @compiler_2fmeasure_2esecs(ptr %s0, double %t239)
  store { i64, ptr } %t240, ptr %l119
  br label %bb38
bb38:
  %t241 = load i64, ptr %l17, !tbaa !24
  %t243 = sdiv i64 %t241, 1024
  %t244 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t245 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t246 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t246, 1
  %t248 = extractvalue { i64, ptr } %t246, 0
  %t249 = add i64 %t245, %t248
  %t250 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t251 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t252 = add i64 %t249, %t251
  %t253 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 1
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = add i64 %t252, %t255
  %t257 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = add i64 %t256, %t259
  %t261 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t264 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = add i64 %t263, %t266
  %t268 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t270 = add i64 %t267, %t269
  %t272 = call i64 @__olang_fmt_i64(ptr null, i64 %t243)
  %t273 = add i64 %t270, %t272
  %t274 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t244, i64 %t245)
  %t278 = getelementptr i8, ptr %t277, i64 %t245
  call void @olang_textcopy(ptr %t278, ptr %t247, i64 %t248)
  %t279 = getelementptr i8, ptr %t278, i64 %t248
  call void @olang_textcopy(ptr %t279, ptr %t250, i64 %t251)
  %t280 = getelementptr i8, ptr %t279, i64 %t251
  call void @olang_textcopy(ptr %t280, ptr %t254, i64 %t255)
  %t281 = getelementptr i8, ptr %t280, i64 %t255
  call void @olang_textcopy(ptr %t281, ptr %t258, i64 %t259)
  %t282 = getelementptr i8, ptr %t281, i64 %t259
  call void @olang_textcopy(ptr %t282, ptr %t261, i64 %t262)
  %t283 = getelementptr i8, ptr %t282, i64 %t262
  call void @olang_textcopy(ptr %t283, ptr %t265, i64 %t266)
  %t284 = getelementptr i8, ptr %t283, i64 %t266
  call void @olang_textcopy(ptr %t284, ptr %t268, i64 %t269)
  %t285 = getelementptr i8, ptr %t284, i64 %t269
  %t286 = call i64 @__olang_fmt_i64(ptr %t285, i64 %t243)
  %t287 = getelementptr i8, ptr %t285, i64 %t272
  call void @olang_textcopy(ptr %t287, ptr %t274, i64 %t275)
  %t288 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t277, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t289, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmeasure_2eMeasure(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"compiler/measure:Sample"
  %l14 = alloca { i64, ptr }
  %l16 = alloca i32
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l44 = alloca %"compiler/measure:Sample"
  %l45 = alloca { i64, ptr }
  %l48 = alloca i32
  %l51 = alloca %"compiler/measure:Sample"
  %l52 = alloca i32
  %l54 = alloca i1
  %l57 = alloca { i64, ptr }
  %l60 = alloca i32
  %l62 = alloca i1
  %l65 = alloca i32
  %l67 = alloca i32
  %l76 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l81 = alloca i32
  %l83 = alloca i1
  %l87 = alloca i32
  %l89 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = call i32 (ptr, i32, ...) @open(ptr %t3, i32 1)
  store i32 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i32, ptr %l16, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmeasure_3aSample_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l17
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t11 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a2, i64 1)
  store i64 %t11, ptr %l19
  br label %bb3
bb3:
  %t12 = load i64, ptr %l19, !tbaa !24
  store i64 %t12, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l9, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb9
bb6:
  %t23 = load i64, ptr %l8, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l9, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l26, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l26, !tbaa !24
  store i64 %t39, ptr %l23, !tbaa !24
  br label %bb9
bb9:
  %t40 = load i64, ptr %l23, !tbaa !24
  store i64 %t40, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  %t41 = load i64, ptr %l11, !tbaa !24
  %t42 = load i64, ptr %l10, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  br label %bb35
bb12:
  br label %bb13
bb13:
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l11, !tbaa !24
  %t51 = load i64, ptr %l9, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t59, ptr %l45, !tbaa !27
  %t62 = icmp eq i64 %t57, 0
  br i1 %t62, label %bb14, label %bb15
bb14:
  store i32 -1, ptr %l48, !tbaa !23
  br label %bb16
bb15:
  %t64 = load i32, ptr %l4, !tbaa !23
  store i32 %t64, ptr %l48, !tbaa !23
  br label %bb16
bb16:
  %t67 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t68 = load i32, ptr %l48, !tbaa !23
  %t70 = call { i32, %"compiler/measure:Sample" } @compiler_2fmeasure_2eSample_2eOf(ptr %v0, ptr %v1, { i64, ptr } %t67, i32 %t68, { i64, ptr } %a3)
  %t71 = extractvalue { i32, %"compiler/measure:Sample" } %t70, 1
  %t72 = extractvalue { i32, %"compiler/measure:Sample" } %t70, 0
  store i32 %t72, ptr %l52
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb18, label %ok.74, !prof !99
ok.74:
  store %"compiler/measure:Sample" %t71, ptr %l51
  br label %bb17
bb17:
  %t75 = load %"compiler/measure:Sample", ptr %l51
  store %"compiler/measure:Sample" %t75, ptr %l44
  br label %bb29
bb18:
  %t76 = load i32, ptr %l52, !tbaa !23
  %t77 = ashr i32 %t76, 16
  %t79 = icmp eq i32 %t77, 1
  store i1 %t79, ptr %l54, !tbaa !21
  %t80 = load i32, ptr %l52, !tbaa !23
  %t81 = ashr i32 %t80, 16
  %t83 = icmp eq i32 %t81, 1
  br i1 %t83, label %bb19, label %bb20
bb19:
  call void @__olang_errpay_pop()
  br label %bb20
bb20:
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t85, ptr %l57, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %t87, i64 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !37
  %t90 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t93 = extractvalue { i64, ptr } %t89, 1
  %t94 = extractvalue { i64, ptr } %t89, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t90, i64 %t91)
  %t100 = getelementptr i8, ptr %t99, i64 %t91
  call void @olang_textcopy(ptr %t100, ptr %t93, i64 %t94)
  %t101 = getelementptr i8, ptr %t100, i64 %t94
  call void @olang_textcopy(ptr %t101, ptr %t96, i64 %t97)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t99, 1
  %t105 = call i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t103)
  store i32 %t105, ptr %l60
  %t106 = icmp ne i32 %t105, 0
  br i1 %t106, label %bb23, label %ok.107, !prof !99
ok.107:
  br label %bb22
bb22:
  br label %bb27
bb23:
  %t108 = load i32, ptr %l60, !tbaa !23
  %t109 = ashr i32 %t108, 16
  %t111 = icmp eq i32 %t109, 1
  store i1 %t111, ptr %l62, !tbaa !21
  %t112 = load i32, ptr %l60, !tbaa !23
  %t113 = ashr i32 %t112, 16
  %t115 = icmp eq i32 %t113, 1
  br i1 %t115, label %bb24, label %bb25
bb24:
  call void @__olang_errpay_pop()
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  store i32 1, ptr %l65, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  %t117 = load i32, ptr %l4, !tbaa !23
  %t119 = call i32 @close(i32 %t117)
  store i32 %t119, ptr %l67
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t120 = load i32, ptr %l65, !tbaa !23
  store i32 %t120, ptr %rv
  br label %ret
bb29:
  %t121 = load %"compiler/measure:Sample", ptr %l44
  store %"compiler/measure:Sample" %t121, ptr %l13
  %t122 = load %"compiler/measure:Sample", ptr %l13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmeasure_3aSample_3e_2ePush_3ccompiler_2fmeasure_3aSample_3e(ptr %s0, ptr %l5, %"compiler/measure:Sample" %t122)
  br label %bb30
bb30:
  %t125 = getelementptr %"compiler/measure:Sample", ptr %l13, i32 0, i32 4
  %t126 = load i64, ptr %t125, !tbaa !24
  store i64 %t126, ptr %l6, !tbaa !24
  %t128 = load i64, ptr %l6, !tbaa !24
  %t130 = icmp ne i64 %t128, 0
  br i1 %t130, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = add i64 %t132, 1
  store i64 %t135, ptr %l11, !tbaa !24
  br label %bb10
bb35:
  store i64 %a1, ptr %l76, !tbaa !24
  %t139 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmeasure_3aSample_3e_2eToArr_H5b7e85abe257daf59f7cb8a9c65adc88(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t139, ptr %l78
  br label %bb36
bb36:
  %t140 = load i64, ptr %l76, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t142 = call { i64, ptr } @compiler_2fmeasure_2eLine(ptr %s0, ptr %s0, i64 %t140, { i64, ptr } %t141)
  store { i64, ptr } %t142, ptr %l79
  br label %bb37
bb37:
  %t143 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t145 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t143, i64 %t144)
  %t153 = getelementptr i8, ptr %t152, i64 %t144
  call void @olang_textcopy(ptr %t153, ptr %t146, i64 %t147)
  %t154 = getelementptr i8, ptr %t153, i64 %t147
  call void @olang_textcopy(ptr %t154, ptr %t149, i64 %t150)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t152, 1
  %t158 = call i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t156)
  store i32 %t158, ptr %l81
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb39, label %ok.160, !prof !99
ok.160:
  br label %bb38
bb38:
  br label %bb43
bb39:
  %t161 = load i32, ptr %l81, !tbaa !23
  %t162 = ashr i32 %t161, 16
  %t164 = icmp eq i32 %t162, 1
  store i1 %t164, ptr %l83, !tbaa !21
  %t165 = load i32, ptr %l81, !tbaa !23
  %t166 = ashr i32 %t165, 16
  %t168 = icmp eq i32 %t166, 1
  br i1 %t168, label %bb40, label %bb41
bb40:
  call void @__olang_errpay_pop()
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t170 = load i64, ptr %l6, !tbaa !24
  %t172 = trunc i64 %t170 to i32
  store i32 %t172, ptr %l87, !tbaa !23
  %t173 = load i32, ptr %l4, !tbaa !23
  %t175 = call i32 @close(i32 %t173)
  store i32 %t175, ptr %l89
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t176 = load i32, ptr %l87, !tbaa !23
  store i32 %t176, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"compiler/measure:Sample" } @compiler_2fmeasure_2eSample_2eOf(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca [1 x i32]
  %l21 = alloca [18 x i64]
  %l22 = alloca i64
  %l23 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i1
  %l36 = alloca { i64, ptr }
  %l47 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i1
  %l61 = alloca { i64, ptr }
  %l67 = alloca i64
  %l70 = alloca i1
  %l75 = alloca { i64, ptr }
  %l93 = alloca i64
  %l95 = alloca i1
  %l96 = alloca i32
  %l101 = alloca { i64, ptr }
  %l103 = alloca i32
  %l111 = alloca { i64, ptr }
  %l113 = alloca i32
  %l116 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca i64
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, [2 x i64] }
  %l122 = alloca i64
  %l124 = alloca { i64, [2 x i64] }
  %l128 = alloca [18 x i64]
  %l136 = alloca i32
  %l138 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca i64
  %l142 = alloca { i64, ptr }
  %l143 = alloca { i64, [2 x i64] }
  %l144 = alloca i64
  %l146 = alloca { i64, [2 x i64] }
  %l149 = alloca i64
  %l157 = alloca i64
  %l177 = alloca %"compiler/measure:Sample"
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/measure:Sample" }
  %t224 = alloca { i64, [2 x i64] }, align 8
  %t292 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = sub i64 %t7, 1
  store i64 %t8, ptr %l28, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = icmp slt i64 %t9, 2147483648
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  %t15 = and i1 %t10, %t12
  store i1 %t15, ptr %l31, !tbaa !21
  br label %bb1
bb1:
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l36, !tbaa !27
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %t28, i64 %t25
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !37
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = extractvalue { i64, ptr } %t30, 0
  %t37 = add i64 %t35, 1
  %t40 = add i64 %t32, %t37
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %l5, !tbaa !24
  br label %bb1
bb6:
  %t47 = load i64, ptr %l3, !tbaa !24
  store i64 %t47, ptr %l47, !tbaa !24
  %t48 = load i64, ptr %l47, !tbaa !24
  %t49 = icmp sge i64 %t48, 0
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t51 = load i64, ptr %l47, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l12, !tbaa !24
  %t63 = load i64, ptr %l12, !tbaa !24
  %t64 = sub i64 %t63, 1
  store i64 %t64, ptr %l53, !tbaa !24
  %t65 = load i64, ptr %l12, !tbaa !24
  %t66 = icmp slt i64 %t65, 2147483648
  %t67 = load i64, ptr %l11, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  %t71 = and i1 %t66, %t68
  store i1 %t71, ptr %l56, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d4d32b6bc60e7203_b6478d4bfe2d5d77)
  unreachable
bb9:
  %t72 = load i64, ptr %l11, !tbaa !24
  %t73 = load i64, ptr %l12, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t80 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t80, ptr %l61, !tbaa !27
  %t81 = load i64, ptr %l11, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %t84, i64 %t81
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !37
  store { i64, ptr } %t86, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  store i64 %t92, ptr %l16, !tbaa !24
  %t94 = load i64, ptr %l16, !tbaa !24
  %t95 = sub i64 %t94, 1
  store i64 %t95, ptr %l67, !tbaa !24
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = icmp slt i64 %t96, 2147483648
  %t98 = load i64, ptr %l15, !tbaa !24
  %t99 = icmp sge i64 %t98, 0
  %t102 = and i1 %t97, %t99
  store i1 %t102, ptr %l70, !tbaa !21
  br label %bb13
bb13:
  %t103 = load i64, ptr %l15, !tbaa !24
  %t104 = load i64, ptr %l16, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t111 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t111, ptr %l75, !tbaa !27
  %t112 = load i64, ptr %l15, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i8, ptr %t115, i64 %t112
  %t117 = load i8, ptr %t116, !tbaa !32
  %t119 = load i64, ptr %l9, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 %t119
  store i8 %t117, ptr %t126, !tbaa !32
  %t127 = load i64, ptr %l9, !tbaa !24
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  %t132 = load i64, ptr %l15, !tbaa !24
  %t135 = add i64 %t132, 1
  store i64 %t135, ptr %l15, !tbaa !24
  br label %bb13
bb18:
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = add i64 %t137, 1
  store i64 %t140, ptr %l9, !tbaa !24
  br label %bb19
bb19:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l11, !tbaa !24
  br label %bb9
bb20:
  %t147 = call i64 @std_2ftime_2eNow()
  store i64 %t147, ptr %l93
  br label %bb21
bb21:
  %t148 = load i64, ptr %l93, !tbaa !24
  store i64 %t148, ptr %l18, !tbaa !24
  %t149 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t151 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t149, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t151, ptr %l95
  br label %bb22
bb22:
  %t152 = load i1, ptr %l95, !tbaa !21
  br i1 %t152, label %bb23, label %bb24
bb23:
  %t153 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = load i32, ptr %l1, !tbaa !23
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l101, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t153, 1
  %t161 = extractvalue { i64, ptr } %t153, 0
  %t165 = extractvalue { i64, ptr } %t158, 1
  %t166 = extractvalue { i64, ptr } %t158, 0
  %t167 = call i32 @__olang_spawn(ptr %t160, i64 %t156, i32 -1, i32 %t157, i32 -1, ptr %t165)
  store i32 %t167, ptr %l103
  br label %bb25
bb24:
  %t168 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 1
  %t171 = extractvalue { i64, ptr } %t168, 0
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t170, i64 %t171)
  %t176 = getelementptr i8, ptr %t175, i64 %t171
  call void @olang_textcopy(ptr %t176, ptr %t172, i64 %t173)
  %t177 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  %t180 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = load i32, ptr %l1, !tbaa !23
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l111, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t178, 1
  %t188 = extractvalue { i64, ptr } %t178, 0
  %t190 = extractvalue { i64, ptr } %t180, 1
  %t191 = extractvalue { i64, ptr } %t180, 0
  %t195 = extractvalue { i64, ptr } %t185, 1
  %t196 = extractvalue { i64, ptr } %t185, 0
  %t197 = call i32 @__olang_spawn_as(ptr %t187, ptr %t190, i64 %t183, i32 -1, i32 %t184, i32 -1, ptr %t195)
  store i32 %t197, ptr %l113
  br label %bb26
bb25:
  %t198 = load i32, ptr %l103, !tbaa !23
  store i32 %t198, ptr %l96, !tbaa !23
  br label %bb27
bb26:
  %t199 = load i32, ptr %l113, !tbaa !23
  store i32 %t199, ptr %l96, !tbaa !23
  br label %bb27
bb27:
  %t200 = load i32, ptr %l96, !tbaa !23
  store i32 %t200, ptr %l19, !tbaa !23
  %t201 = load i32, ptr %l19, !tbaa !23
  %t203 = icmp slt i32 %t201, 0
  br i1 %t203, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s11
  %t205 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t205, ptr %l116, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %t207, i64 0
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !37
  store { i64, ptr } %t209, ptr %l118, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 0
  store i64 %t212, ptr %l119, !tbaa !24
  %t213 = load i64, ptr %l119, !tbaa !24
  %t214 = mul i64 %t213, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t214)
  %t216 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  store { i64, ptr } %t217, ptr %l120, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = load i64, ptr %l119, !tbaa !24
  %t223 = mul i64 %t222, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t219, ptr %t221, i64 %t223, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t224
  %t225 = getelementptr { i64, [2 x i64] }, ptr %t224, i32 0, i32 0
  store i64 6, ptr %t225
  %t226 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t227 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t226, 0
  %t228 = getelementptr { i64, [2 x i64] }, ptr %t224, i32 0, i32 1
  store { { i64, ptr } } %t227, ptr %t228
  %t229 = load { i64, [2 x i64] }, ptr %t224
  store { i64, [2 x i64] } %t229, ptr %l121
  %t230 = call ptr @__olang_errpay_push()
  %t231 = ptrtoint ptr %t230 to i64
  store i64 %t231, ptr %l122, !tbaa !24
  %t232 = load i64, ptr %l122
  %t233 = inttoptr i64 %t232 to ptr
  %t235 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t233, ptr %l121)
  store { i64, [2 x i64] } %t235, ptr %l124
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t236 = load { i64, [2 x i64] }, ptr %l124
  %t237 = load i64, ptr %l122
  %t238 = inttoptr i64 %t237 to ptr
  %t239 = call ptr @__olang_scope_alloc_a(ptr %t238, i64 24, i64 8)
  store { i64, [2 x i64] } %t236, ptr %t239
  call void @__olang_errpay_set(ptr %t239)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t242 = insertvalue { i32, %"compiler/measure:Sample" } zeroinitializer, i32 65542, 0
  store { i32, %"compiler/measure:Sample" } %t242, ptr %rv
  br label %ret
bb31:
  %t243 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t243, ptr %l20
  br label %fill.248
fill.248:
  br label %fill.245
fill.245:
  %t249 = phi i64 [ 0, %fill.248 ], [ %t250, %fill.246 ]
  %t251 = icmp slt i64 %t249, 18
  br i1 %t251, label %fill.246, label %fill.247
fill.246:
  %t252 = getelementptr [18 x i64], ptr %l128, i64 0, i64 %t249
  store i64 0, ptr %t252
  %t250 = add i64 %t249, 1
  br label %fill.245
fill.247:
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %l128, i64 144, i1 false)
  %t253 = load i32, ptr %l19, !tbaa !23
  %t255 = insertvalue { i64, ptr } undef, i64 1, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %l20, 1
  %t259 = insertvalue { i64, ptr } undef, i64 18, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %l21, 1
  %t264 = extractvalue { i64, ptr } %t256, 1
  %t265 = extractvalue { i64, ptr } %t256, 0
  %t267 = extractvalue { i64, ptr } %t260, 1
  %t268 = extractvalue { i64, ptr } %t260, 0
  %t269 = call i32 @wait4(i32 %t253, ptr %t264, i32 0, ptr %t267)
  store i32 %t269, ptr %l136
  br label %bb32
bb32:
  %t270 = load i32, ptr %l136, !tbaa !23
  %t271 = icmp slt i32 %t270, 0
  br i1 %t271, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s12
  %t273 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t273, ptr %l138, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %t275, i64 0
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !37
  store { i64, ptr } %t277, ptr %l140, !tbaa !27
  %t279 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 0
  store i64 %t280, ptr %l141, !tbaa !24
  %t281 = load i64, ptr %l141, !tbaa !24
  %t282 = mul i64 %t281, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t282)
  %t284 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  store { i64, ptr } %t285, ptr %l142, !tbaa !27
  %t286 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = load i64, ptr %l141, !tbaa !24
  %t291 = mul i64 %t290, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t287, ptr %t289, i64 %t291, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t292
  %t293 = getelementptr { i64, [2 x i64] }, ptr %t292, i32 0, i32 0
  store i64 6, ptr %t293
  %t294 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t295 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t294, 0
  %t296 = getelementptr { i64, [2 x i64] }, ptr %t292, i32 0, i32 1
  store { { i64, ptr } } %t295, ptr %t296
  %t297 = load { i64, [2 x i64] }, ptr %t292
  store { i64, [2 x i64] } %t297, ptr %l143
  %t298 = call ptr @__olang_errpay_push()
  %t299 = ptrtoint ptr %t298 to i64
  store i64 %t299, ptr %l144, !tbaa !24
  %t300 = load i64, ptr %l144
  %t301 = inttoptr i64 %t300 to ptr
  %t303 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t301, ptr %l143)
  store { i64, [2 x i64] } %t303, ptr %l146
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t304 = load { i64, [2 x i64] }, ptr %l146
  %t305 = load i64, ptr %l144
  %t306 = inttoptr i64 %t305 to ptr
  %t307 = call ptr @__olang_scope_alloc_a(ptr %t306, i64 24, i64 8)
  store { i64, [2 x i64] } %t304, ptr %t307
  call void @__olang_errpay_set(ptr %t307)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t310 = insertvalue { i32, %"compiler/measure:Sample" } zeroinitializer, i32 65542, 0
  store { i32, %"compiler/measure:Sample" } %t310, ptr %rv
  br label %ret
bb36:
  %t311 = call i64 @std_2ftime_2eNow()
  store i64 %t311, ptr %l149
  br label %bb37
bb37:
  %t312 = load i64, ptr %l18, !tbaa !24
  %t313 = load i64, ptr %l149, !tbaa !24
  %t315 = sub i64 %t313, %t312
  store i64 %t315, ptr %l22, !tbaa !24
  %t317 = getelementptr [1 x i32], ptr %l20, i64 0, i64 0
  %t318 = load i32, ptr %t317, !tbaa !33
  %t320 = sext i32 %t318 to i64
  store i64 %t320, ptr %l23, !tbaa !24
  %t322 = load i64, ptr %l23, !tbaa !24
  %t324 = and i64 %t322, 127
  %t326 = icmp eq i64 %t324, 0
  br i1 %t326, label %bb38, label %bb39
bb38:
  %t328 = load i64, ptr %l23, !tbaa !24
  %t330 = ashr i64 %t328, 8
  %t332 = and i64 %t330, 255
  store i64 %t332, ptr %l157, !tbaa !24
  br label %bb40
bb39:
  %t334 = load i64, ptr %l23, !tbaa !24
  %t336 = and i64 %t334, 127
  %t338 = add i64 128, %t336
  store i64 %t338, ptr %l157, !tbaa !24
  br label %bb40
bb40:
  %t340 = load i64, ptr %l157, !tbaa !24
  %t341 = load i64, ptr %l22, !tbaa !24
  %t342 = getelementptr [18 x i64], ptr %l21, i64 0, i64 0
  %t343 = load i64, ptr %t342, !tbaa !34
  %t345 = mul i64 %t343, 1000000000
  %t346 = getelementptr [18 x i64], ptr %l21, i64 0, i64 1
  %t347 = load i64, ptr %t346, !tbaa !34
  %t349 = mul i64 %t347, 1000
  %t352 = add i64 %t345, %t349
  %t353 = getelementptr [18 x i64], ptr %l21, i64 0, i64 2
  %t354 = load i64, ptr %t353, !tbaa !34
  %t356 = mul i64 %t354, 1000000000
  %t357 = getelementptr [18 x i64], ptr %l21, i64 0, i64 3
  %t358 = load i64, ptr %t357, !tbaa !34
  %t360 = mul i64 %t358, 1000
  %t363 = add i64 %t356, %t360
  %t364 = getelementptr [18 x i64], ptr %l21, i64 0, i64 4
  %t365 = load i64, ptr %t364, !tbaa !34
  %t372 = call %"compiler/measure:Sample" @compiler_2fmeasure_3aSample_2ector(ptr %s0, i64 %t341, i64 %t352, i64 %t363, i64 %t365, i64 %t340)
  store %"compiler/measure:Sample" %t372, ptr %l177
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t373 = load %"compiler/measure:Sample", ptr %l177
  %t374 = insertvalue { i32, %"compiler/measure:Sample" } zeroinitializer, %"compiler/measure:Sample" %t373, 1
  store { i32, %"compiler/measure:Sample" } %t374, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/measure:Sample" }, ptr %rv
  ret { i32, %"compiler/measure:Sample" } %rr
}

define dso_local { i64, ptr } @compiler_2fmeasure_2eTotal(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca [18 x i64]
  %l3 = alloca [18 x i64]
  %l7 = alloca i32
  %l8 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 18
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [18 x i64], ptr %l3, i64 0, i64 %t5
  store i64 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l3, i64 144, i1 false)
  %t10 = insertvalue { i64, ptr } undef, i64 18, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %l2, 1
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = extractvalue { i64, ptr } %t11, 0
  %t16 = call i32 @getrusage(i32 -1, ptr %t14)
  store i32 %t16, ptr %l7
  br label %bb1
bb1:
  store i64 %a0, ptr %l8, !tbaa !24
  %t20 = sitofp i64 %a1 to double
  %t22 = call { i64, ptr } @compiler_2fmeasure_2esecs(ptr %s0, double %t20)
  store { i64, ptr } %t22, ptr %l11
  br label %bb2
bb2:
  %t23 = getelementptr [18 x i64], ptr %l2, i64 0, i64 0
  %t24 = load i64, ptr %t23, !tbaa !34
  %t26 = mul i64 %t24, 1000000000
  %t27 = getelementptr [18 x i64], ptr %l2, i64 0, i64 1
  %t28 = load i64, ptr %t27, !tbaa !34
  %t30 = mul i64 %t28, 1000
  %t33 = add i64 %t26, %t30
  %t35 = sitofp i64 %t33 to double
  %t37 = call { i64, ptr } @compiler_2fmeasure_2esecs(ptr %s0, double %t35)
  store { i64, ptr } %t37, ptr %l18
  br label %bb3
bb3:
  %t38 = getelementptr [18 x i64], ptr %l2, i64 0, i64 2
  %t39 = load i64, ptr %t38, !tbaa !34
  %t41 = mul i64 %t39, 1000000000
  %t42 = getelementptr [18 x i64], ptr %l2, i64 0, i64 3
  %t43 = load i64, ptr %t42, !tbaa !34
  %t45 = mul i64 %t43, 1000
  %t48 = add i64 %t41, %t45
  %t50 = sitofp i64 %t48 to double
  %t52 = call { i64, ptr } @compiler_2fmeasure_2esecs(ptr %s0, double %t50)
  store { i64, ptr } %t52, ptr %l25
  br label %bb4
bb4:
  %t53 = getelementptr [18 x i64], ptr %l2, i64 0, i64 4
  %t54 = load i64, ptr %t53, !tbaa !34
  %t56 = sdiv i64 %t54, 1024
  %t57 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = call i64 @__olang_fmt_i64(ptr null, i64 %t59)
  %t61 = add i64 %t58, %t60
  %t62 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = add i64 %t64, %t67
  %t69 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t71 = add i64 %t68, %t70
  %t72 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t87 = call i64 @__olang_fmt_i64(ptr null, i64 %t56)
  %t88 = add i64 %t85, %t87
  %t89 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t57, i64 %t58)
  %t93 = getelementptr i8, ptr %t92, i64 %t58
  %t94 = call i64 @__olang_fmt_i64(ptr %t93, i64 %t59)
  %t95 = getelementptr i8, ptr %t93, i64 %t60
  call void @olang_textcopy(ptr %t95, ptr %t62, i64 %t63)
  %t96 = getelementptr i8, ptr %t95, i64 %t63
  call void @olang_textcopy(ptr %t96, ptr %t66, i64 %t67)
  %t97 = getelementptr i8, ptr %t96, i64 %t67
  call void @olang_textcopy(ptr %t97, ptr %t69, i64 %t70)
  %t98 = getelementptr i8, ptr %t97, i64 %t70
  call void @olang_textcopy(ptr %t98, ptr %t73, i64 %t74)
  %t99 = getelementptr i8, ptr %t98, i64 %t74
  call void @olang_textcopy(ptr %t99, ptr %t76, i64 %t77)
  %t100 = getelementptr i8, ptr %t99, i64 %t77
  call void @olang_textcopy(ptr %t100, ptr %t80, i64 %t81)
  %t101 = getelementptr i8, ptr %t100, i64 %t81
  call void @olang_textcopy(ptr %t101, ptr %t83, i64 %t84)
  %t102 = getelementptr i8, ptr %t101, i64 %t84
  %t103 = call i64 @__olang_fmt_i64(ptr %t102, i64 %t56)
  %t104 = getelementptr i8, ptr %t102, i64 %t87
  call void @olang_textcopy(ptr %t104, ptr %t89, i64 %t90)
  %t105 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t92, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmeasure_2esecsSpread(ptr %v0, double %a0, double %a1) #0 {
entry:
  %l0 = alloca double
  %l1 = alloca double
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store double %a0, ptr %l0
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load double, ptr %l1, !tbaa !26
  %t3 = fcmp oeq double %t1, 0x0000000000000000
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load double, ptr %l0, !tbaa !26
  %t7 = call { i64, ptr } @compiler_2fmeasure_2esecs(ptr %v0, double %t5)
  store { i64, ptr } %t7, ptr %l6
  br label %bb3
bb2:
  %t8 = load double, ptr %l0, !tbaa !26
  %t10 = call { i64, ptr } @compiler_2fmeasure_2esecs(ptr %s0, double %t8)
  store { i64, ptr } %t10, ptr %l8
  br label %bb4
bb3:
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  br label %bb6
bb4:
  %t12 = load double, ptr %l1, !tbaa !26
  %t14 = call { i64, ptr } @compiler_2fmeasure_2esecs(ptr %s0, double %t12)
  store { i64, ptr } %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t21 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = add i64 %t20, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t16, i64 %t17)
  %t26 = getelementptr i8, ptr %t25, i64 %t17
  call void @olang_textcopy(ptr %t26, ptr %t18, i64 %t19)
  %t27 = getelementptr i8, ptr %t26, i64 %t19
  call void @olang_textcopy(ptr %t27, ptr %t22, i64 %t23)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t25, 1
  store { i64, ptr } %t29, ptr %l4, !tbaa !27
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/measure:Sample" @compiler_2fmeasure_3aSample_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/measure:Sample"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/measure:Sample" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/measure:Sample" %t12, i64 %a1, 1
  %t16 = insertvalue %"compiler/measure:Sample" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/measure:Sample" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/measure:Sample" %t18, i64 %a4, 4
  store %"compiler/measure:Sample" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/measure:Sample", ptr %rv
  ret %"compiler/measure:Sample" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d0 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" (median of " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" runs; " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d3 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"built in " }>, align 8
@.d4 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ran in " }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" user, " }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" sys, " }>, align 8
@.d7 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" MB peak)" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d8 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"/dev/null\00" }>, align 8
declare i32 @open(ptr, i32, ...)
declare void @__olang_errpay_pop()
@.d9 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"bench: " }>, align 8
@.d10 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" could not be started\0A" }>, align 8
declare i32 @close(i32)
@.d11 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"bench: " }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_check_failed(ptr) cold noreturn
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @__olang_spawn(ptr, i64, i32, i32, i32, ptr)
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @__olang_spawn_as(ptr, ptr, i64, i32, i32, i32, ptr)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_errpay_push() cold
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 7}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { { i64, ptr } }, ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, ptr } }, ptr %t42, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t43
  br label %bb1
bb4:
  %t44 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l9, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  store i64 %t48, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = mul i64 %t49, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l11, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = mul i64 %t58, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %t57, i64 %t59, i1 false)
  %t60 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t61 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { { i64, ptr } }, ptr %t61, i32 0, i32 0
  store { i64, ptr } %t60, ptr %t62
  br label %bb1
bb5:
  %t63 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { { i64, ptr } }, ptr %t63, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64
  store { i64, ptr } %t65, ptr %l12, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l13, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l14, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l13, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t80 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t81 = getelementptr { { i64, ptr } }, ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81
  br label %bb1
bb6:
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t83 = getelementptr { { i64, ptr } }, ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83
  store { i64, ptr } %t84, ptr %l15, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l17, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t99 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, ptr } }, ptr %t99, i32 0, i32 0
  store { i64, ptr } %t98, ptr %t100
  br label %bb1
bb7:
  %t101 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t102 = getelementptr { { i64, ptr } }, ptr %t101, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102
  store { i64, ptr } %t103, ptr %l18, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l19, !tbaa !24
  %t106 = load i64, ptr %l19, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l20, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l19, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t119 = getelementptr { { i64, ptr } }, ptr %t118, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t119
  br label %bb1
bb8:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { { i64, ptr } }, ptr %t120, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l21, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l22, !tbaa !24
  %t125 = load i64, ptr %l22, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l23, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l22, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t137 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t138 = getelementptr { { i64, ptr } }, ptr %t137, i32 0, i32 0
  store { i64, ptr } %t136, ptr %t138
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_errpay_set(ptr) cold
declare i32 @wait4(i32, ptr, i32, ptr)
declare i32 @getrusage(i32, ptr)
@.d17 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"bench: " }>, align 8
@.d18 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" files in " }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d20 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" user, " }>, align 8
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" sys, " }>, align 8
@.d22 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" MB peak)" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" \C2\B1 " }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare double @std_2fbench_2eMedian(ptr %v0, { i64, ptr } %a0)
declare double @std_2fbench_2eSpread(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fmeasure_2esecs(ptr %v0, double %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmeasure_3aSample_3e_2ector(ptr %v0, i64 %a0)
declare i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmeasure_3aSample_3e_2ePush_3ccompiler_2fmeasure_3aSample_3e(ptr %v0, ptr %a0, %"compiler/measure:Sample" %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmeasure_3aSample_3e_2eToArr_H5b7e85abe257daf59f7cb8a9c65adc88(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_d4d32b6bc60e7203_b6478d4bfe2d5d77 = external constant [0 x i8]
declare i64 @std_2ftime_2eNow()
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
