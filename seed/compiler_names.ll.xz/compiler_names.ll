; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/names:local" = type { i32, %"compiler/source:Span", i32, i1, i1, i1 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/names:Unread" = type { i64, %"compiler/source:Span", i32, i1 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1, ptr }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/names:raisedName" = type { i32, %"compiler/source:Span", i64, i1, i64, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
define dso_local i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb17
bb15:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t22, ptr %l14
  br label %bb16
bb16:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb17
bb17:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb21
bb19:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t27, ptr %l17
  br label %bb20
bb20:
  %t28 = load i1, ptr %l17, !tbaa !21
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb21
bb21:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb25
bb23:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t32, ptr %l20
  br label %bb24
bb24:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb25
bb25:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb29
bb27:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t35, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t37, ptr %l23
  br label %bb28
bb28:
  %t38 = load i1, ptr %l23, !tbaa !21
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb29
bb29:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb33
bb31:
  %t40 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t40, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t42, ptr %l26
  br label %bb32
bb32:
  %t43 = load i1, ptr %l26, !tbaa !21
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb33
bb33:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb37
bb35:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t47, ptr %l29
  br label %bb36
bb36:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb37
bb37:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb41
bb39:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t52, ptr %l32
  br label %bb40
bb40:
  %t53 = load i1, ptr %l32, !tbaa !21
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb41
bb41:
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb45
bb43:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t55, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t57, ptr %l35
  br label %bb44
bb44:
  %t58 = load i1, ptr %l35, !tbaa !21
  store i1 %t58, ptr %l33, !tbaa !21
  br label %bb45
bb45:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb49
bb47:
  %t60 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t62, ptr %l38
  br label %bb48
bb48:
  %t63 = load i1, ptr %l38, !tbaa !21
  store i1 %t63, ptr %l36, !tbaa !21
  br label %bb49
bb49:
  %t64 = load i1, ptr %l36, !tbaa !21
  br i1 %t64, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb53
bb51:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t67, ptr %l41
  br label %bb52
bb52:
  %t68 = load i1, ptr %l41, !tbaa !21
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb53
bb53:
  %t69 = load i1, ptr %l39, !tbaa !21
  br i1 %t69, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb57
bb55:
  %t70 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t72 = call i1 @compiler_2ftypes_2eIsIntName(ptr %v0, { i64, ptr } %t70)
  store i1 %t72, ptr %l44
  br label %bb56
bb56:
  %t73 = load i1, ptr %l44, !tbaa !21
  store i1 %t73, ptr %l42, !tbaa !21
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load i1, ptr %l42, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fnames_2eLoneCatchName(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 5
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Catch", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp ne i64 %t13, 1
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Catch", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr ptr, ptr %t23, i64 0
  %t25 = load ptr, ptr %t24, !tbaa !39
  %t27 = getelementptr %"compiler/ast:Path", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp ne i64 %t30, 1
  store i1 %t32, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l10, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load i32, ptr %l1, !range !{i32 0, i32 9}
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t43 = load i32, ptr %l1, !range !{i32 0, i32 9}
  %t45 = trunc i64 7 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l21, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t51 = load i32, ptr %l1, !range !{i32 0, i32 9}
  %t53 = trunc i64 8 to i32
  %t54 = icmp eq i32 %t51, %t53
  %t56 = xor i1 %t54, true
  store i1 %t56, ptr %l25, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l25, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fnames_2ePayloadName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fnames_2eWrittenMut(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t17, i32 0, i32 2
  %t19 = load i1, ptr %t18
  store i1 %t19, ptr %l1, !tbaa !21
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load i1, ptr %l1, !tbaa !21
  store i1 %t21, ptr %l5, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_93f58d21316a4d1a_c55e0a424e12d50e)
  unreachable
bb14:
  %t23 = load i1, ptr %l5, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eImportSaid(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l18 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 16
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Hd32f6fdf378a1d4c0e47f8552643012d(ptr %v0, ptr %t15, i64 %t16)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l14
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t20, ptr %l4
  %t21 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l4, i32 0, i32 0
  %t22 = load i32, ptr %t21, !tbaa !23
  %t26 = icmp eq i32 %t22, %a1
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l4, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp eq i64 %t29, -1
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t35, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eLocalSpan(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/names:local"
  %l16 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 8
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/names:Resolver", ptr %t16, i32 0, i32 8
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t18, i64 %t19)
  store %"compiler/names:local" %t22, ptr %l14
  br label %bb7
bb6:
  %t23 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t23, ptr %l16
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/names:local", ptr %l14, i32 0, i32 1
  %t25 = load %"compiler/source:Span", ptr %t24
  store %"compiler/source:Span" %t25, ptr %l10
  br label %bb9
bb8:
  %t27 = load %"compiler/source:Span", ptr %l16
  store %"compiler/source:Span" %t27, ptr %l10
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca i32
  %l12 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 5
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = call i64 @compiler_2fnames_2ekey(i64 %a1, i32 %a2)
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = call { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eG_Hb4f204ca9d50eb43e30fe8770cb15d1a(ptr %v0, ptr %t9, i64 %t10)
  %t12 = extractvalue { i32, %"compiler/names:Ref" } %t11, 1
  %t13 = extractvalue { i32, %"compiler/names:Ref" } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store %"compiler/names:Ref" %t12, ptr %l9
  br label %bb2
bb2:
  %t16 = load %"compiler/names:Ref", ptr %l9
  store %"compiler/names:Ref" %t16, ptr %l3
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t18 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t18, ptr %l12
  br label %bb5
bb5:
  %t19 = load %"compiler/names:Ref", ptr %l12
  store %"compiler/names:Ref" %t19, ptr %l3
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load %"compiler/names:Ref", ptr %l3
  store %"compiler/names:Ref" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMissingIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca i64
  %l5 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 6
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = call i64 @compiler_2fnames_2ekey(i64 %a1, i32 %a2)
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t9, i64 %t10)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t16 = load i64, ptr %l9, !tbaa !24
  store i64 %t16, ptr %l3, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca i32
  %l12 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 4
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = call i64 @compiler_2fnames_2ekey(i64 %a1, i32 %a2)
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = call { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eG_Hb4f204ca9d50eb43e30fe8770cb15d1a(ptr %v0, ptr %t9, i64 %t10)
  %t12 = extractvalue { i32, %"compiler/names:Ref" } %t11, 1
  %t13 = extractvalue { i32, %"compiler/names:Ref" } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store %"compiler/names:Ref" %t12, ptr %l9
  br label %bb2
bb2:
  %t16 = load %"compiler/names:Ref", ptr %l9
  store %"compiler/names:Ref" %t16, ptr %l3
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t18 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t18, ptr %l12
  br label %bb5
bb5:
  %t19 = load %"compiler/names:Ref", ptr %l12
  store %"compiler/names:Ref" %t19, ptr %l3
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load %"compiler/names:Ref", ptr %l3
  store %"compiler/names:Ref" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l30 = alloca ptr
  %l34 = alloca { i64, [3 x i64] }
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/diagmsg:Msg"
  %l40 = alloca i64
  %l44 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l56 = alloca { i64, [3 x i64] }
  %l59 = alloca { i64, ptr }
  %l61 = alloca %"compiler/diagmsg:Msg"
  %l62 = alloca i64
  %l64 = alloca i1
  %l67 = alloca ptr
  %l71 = alloca { i64, [3 x i64] }
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"compiler/diagmsg:Msg"
  %l77 = alloca i64
  %l86 = alloca i1
  %l89 = alloca ptr
  %l93 = alloca { i64, [3 x i64] }
  %l96 = alloca { i64, ptr }
  %l98 = alloca %"compiler/diagmsg:Msg"
  %l99 = alloca i64
  %l101 = alloca ptr
  %l102 = alloca i32
  %l105 = alloca i64
  %l107 = alloca ptr
  %l112 = alloca %"compiler/names:Entry"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l14, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 10
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l19
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l19, !tbaa !29
  store ptr %t19, ptr %l6, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t24, ptr %l22
  br label %bb3
bb3:
  %t25 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t25, ptr %l7, !tbaa !27
  %t26 = load i32, ptr %l2, !tbaa !23
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t30 = getelementptr %"compiler/names:Table", ptr %t28, i32 0, i32 2
  %t34 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t30, i32 %t26)
  store i1 %t34, ptr %l27
  br label %bb4
bb4:
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/names:Resolver", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/load:Loader", ptr %t39, i32 0, i32 4
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l30, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l1, !tbaa !24
  %t45 = load %"compiler/source:Span", ptr %l3
  %t49 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t43, i64 %t44, %"compiler/source:Span" %t45)
  store { i64, [3 x i64] } %t49, ptr %l34
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t50, i32 %t51)
  store { i64, ptr } %t54, ptr %l37
  br label %bb8
bb8:
  %t55 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeNameInUse(ptr %s1, ptr %v0, { i64, ptr } %t55)
  store %"compiler/diagmsg:Msg" %t57, ptr %l39
  br label %bb9
bb9:
  %t58 = load ptr, ptr %l30, !tbaa !29
  %t59 = load { i64, [3 x i64] }, ptr %l34
  %t60 = load %"compiler/diagmsg:Msg", ptr %l39
  %t61 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t58, { i64, [3 x i64] } %t59, %"compiler/diagmsg:Msg" %t60)
  store i64 %t61, ptr %l40
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb11:
  %t62 = load ptr, ptr %l6, !tbaa !29
  %t64 = getelementptr %"compiler/load:Module", ptr %t62, i32 0, i32 3
  %t65 = load i1, ptr %t64, !tbaa !21
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb12, label %bb13
bb12:
  %t69 = load i32, ptr %l2, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/names:Resolver", ptr %t71, i32 0, i32 2
  %t77 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t73, i32 %t69)
  store i1 %t77, ptr %l49
  br label %bb14
bb13:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb15
bb14:
  %t78 = load i1, ptr %l49, !tbaa !21
  store i1 %t78, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t79 = load i1, ptr %l44, !tbaa !21
  br i1 %t79, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/names:Resolver", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/load:Loader", ptr %t83, i32 0, i32 4
  %t86 = load ptr, ptr %t85, !tbaa !29
  store ptr %t86, ptr %l52, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i64, ptr %l1, !tbaa !24
  %t89 = load %"compiler/source:Span", ptr %l3
  %t93 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t87, i64 %t88, %"compiler/source:Span" %t89)
  store { i64, [3 x i64] } %t93, ptr %l56
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l2, !tbaa !23
  %t98 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t94, i32 %t95)
  store { i64, ptr } %t98, ptr %l59
  br label %bb19
bb19:
  %t99 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t101 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %s2, ptr %v0, { i64, ptr } %t99)
  store %"compiler/diagmsg:Msg" %t101, ptr %l61
  br label %bb20
bb20:
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t103 = load { i64, [3 x i64] }, ptr %l56
  %t104 = load %"compiler/diagmsg:Msg", ptr %l61
  %t105 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t102, { i64, [3 x i64] } %t103, %"compiler/diagmsg:Msg" %t104)
  store i64 %t105, ptr %l62
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t106 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t108 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t106)
  store i1 %t108, ptr %l64
  br label %bb23
bb23:
  %t109 = load i1, ptr %l64, !tbaa !21
  br i1 %t109, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/names:Resolver", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 4
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l67, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l1, !tbaa !24
  %t119 = load %"compiler/source:Span", ptr %l3
  %t123 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t117, i64 %t118, %"compiler/source:Span" %t119)
  store { i64, [3 x i64] } %t123, ptr %l71
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i32, ptr %l2, !tbaa !23
  %t128 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s3, ptr %t124, i32 %t125)
  store { i64, ptr } %t128, ptr %l74
  br label %bb27
bb27:
  %t129 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t131 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %s3, ptr %v0, { i64, ptr } %t129)
  store %"compiler/diagmsg:Msg" %t131, ptr %l76
  br label %bb28
bb28:
  %t132 = load ptr, ptr %l67, !tbaa !29
  %t133 = load { i64, [3 x i64] }, ptr %l71
  %t134 = load %"compiler/diagmsg:Msg", ptr %l76
  %t135 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t132, { i64, [3 x i64] } %t133, %"compiler/diagmsg:Msg" %t134)
  store i64 %t135, ptr %l77
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l1, !tbaa !24
  %t138 = load i32, ptr %l2, !tbaa !23
  %t139 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t136, i64 %t137, i32 %t138, %"compiler/source:Span" %t139)
  br label %bb31
bb31:
  %t144 = load i32, ptr %l2, !tbaa !23
  %t146 = load ptr, ptr %l5, !tbaa !29
  %t148 = getelementptr %"compiler/names:Table", ptr %t146, i32 0, i32 1
  %t152 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t148, i32 %t144)
  store i1 %t152, ptr %l86
  br label %bb32
bb32:
  %t153 = load i1, ptr %l86, !tbaa !21
  br i1 %t153, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/names:Resolver", ptr %t154, i32 0, i32 0
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/load:Loader", ptr %t157, i32 0, i32 4
  %t160 = load ptr, ptr %t159, !tbaa !29
  store ptr %t160, ptr %l89, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i64, ptr %l1, !tbaa !24
  %t163 = load %"compiler/source:Span", ptr %l3
  %t167 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t161, i64 %t162, %"compiler/source:Span" %t163)
  store { i64, [3 x i64] } %t167, ptr %l93
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l2, !tbaa !23
  %t172 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s4, ptr %t168, i32 %t169)
  store { i64, ptr } %t172, ptr %l96
  br label %bb36
bb36:
  %t173 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t175 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNameIsType(ptr %s4, ptr %v0, { i64, ptr } %t173)
  store %"compiler/diagmsg:Msg" %t175, ptr %l98
  br label %bb37
bb37:
  %t176 = load ptr, ptr %l89, !tbaa !29
  %t177 = load { i64, [3 x i64] }, ptr %l93
  %t178 = load %"compiler/diagmsg:Msg", ptr %l98
  %t179 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t176, { i64, [3 x i64] } %t177, %"compiler/diagmsg:Msg" %t178)
  store i64 %t179, ptr %l99
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb39:
  %t180 = load ptr, ptr %l5, !tbaa !29
  %t182 = getelementptr %"compiler/names:Table", ptr %t180, i32 0, i32 2
  store ptr %t182, ptr %l101, !tbaa !29
  %t183 = load i32, ptr %l2, !tbaa !23
  store i32 %t183, ptr %l102, !tbaa !23
  %t184 = load ptr, ptr %l5, !tbaa !29
  %t186 = getelementptr %"compiler/names:Table", ptr %t184, i32 0, i32 0
  %t188 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t186)
  store i64 %t188, ptr %l105
  br label %bb40
bb40:
  %t189 = load ptr, ptr %l101, !tbaa !29
  %t190 = load i32, ptr %l102, !tbaa !23
  %t191 = load i64, ptr %l105, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t189, i32 %t190, i64 %t191)
  br label %bb41
bb41:
  %t192 = load ptr, ptr %l5, !tbaa !29
  %t194 = getelementptr %"compiler/names:Table", ptr %t192, i32 0, i32 0
  store ptr %t194, ptr %l107, !tbaa !29
  %t195 = load i32, ptr %l2, !tbaa !23
  %t196 = load %"compiler/source:Span", ptr %l3
  %t202 = call %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v1, ptr %v0, i32 %t195, %"compiler/source:Span" %t196, i32 4, i1 false, ptr %a4)
  store %"compiler/names:Entry" %t202, ptr %l112
  br label %bb42
bb42:
  %t203 = load ptr, ptr %l107, !tbaa !29
  %t204 = load %"compiler/names:Entry", ptr %l112
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t203, %"compiler/names:Entry" %t204)
  br label %bb43
bb43:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHead(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/names:Ref"
  %l6 = alloca %"compiler/names:Ref"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/names:Ref" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/names:Ref", ptr %l6
  store %"compiler/names:Ref" %t6, ptr %l3
  %t7 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 9}
  %t10 = trunc i64 5 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  %t15 = load %"compiler/names:Ref", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t13, %"compiler/source:Span" %t14, %"compiler/names:Ref" %t15)
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t19 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
bb5:
  %t22 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22, !range !{i32 0, i32 9}
  %t25 = trunc i64 0 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  %t30 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %t28, %"compiler/source:Span" %t29, i32 %t30)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHop(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca i64
  %l17 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i32
  %l28 = alloca { i64, ptr }
  %l30 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i64
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, [3 x i64] }
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/diagmsg:Msg"
  %l51 = alloca i64
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasTarget(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/names:Resolver", ptr %t12, i32 0, i32 1
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t21 = getelementptr %"compiler/names:Table", ptr %t19, i32 0, i32 3
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t21, i32 %t22)
  %t26 = extractvalue { i32, i64 } %t25, 1
  %t27 = extractvalue { i32, i64 } %t25, 0
  store i32 %t27, ptr %l22
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb7, label %ok.29, !prof !99
ok.29:
  store i64 %t26, ptr %l21
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l13, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb9
bb9:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l28
  br label %bb13
bb13:
  %t42 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t42, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t43)
  store i1 %t45, ptr %l30
  br label %bb14
bb14:
  %t46 = load i1, ptr %l30, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/names:Resolver", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l34, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l35, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/names:Resolver", ptr %t57, i32 0, i32 7
  %t60 = load i64, ptr %t59, !tbaa !24
  store i64 %t60, ptr %l37, !tbaa !24
  %t61 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t67 = trunc i64 %t65 to i32
  %t70 = sub i32 %t62, %t67
  %t71 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t72 = load i32, ptr %t71, !tbaa !23
  %t75 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t70, i32 %t72)
  store %"compiler/source:Span" %t75, ptr %l44
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t76 = load ptr, ptr %l35, !tbaa !29
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = load %"compiler/source:Span", ptr %l44
  %t79 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t76, i64 %t77, %"compiler/source:Span" %t78)
  store { i64, [3 x i64] } %t79, ptr %l45
  br label %bb18
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l3, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s3, ptr %t80, i32 %t81)
  store { i64, ptr } %t84, ptr %l48
  br label %bb19
bb19:
  %t85 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t87 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportIsPrivate(ptr %s3, ptr %v0, { i64, ptr } %t85)
  store %"compiler/diagmsg:Msg" %t87, ptr %l50
  br label %bb20
bb20:
  %t88 = load ptr, ptr %l34, !tbaa !29
  %t89 = load { i64, [3 x i64] }, ptr %l45
  %t90 = load %"compiler/diagmsg:Msg", ptr %l50
  %t91 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t88, { i64, [3 x i64] } %t89, %"compiler/diagmsg:Msg" %t90)
  store i64 %t91, ptr %l51
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb22:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/names:Resolver", ptr %t93, i32 0, i32 5
  store ptr %t95, ptr %l54, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/names:Resolver", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/load:Loader", ptr %t99, i32 0, i32 10
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/names:Resolver", ptr %t102, i32 0, i32 7
  %t105 = load i64, ptr %t104, !tbaa !24
  %t108 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t101, i64 %t105)
  store ptr %t108, ptr %l60
  br label %bb23
bb23:
  %t109 = load ptr, ptr %l60, !tbaa !29
  %t111 = getelementptr %"compiler/load:Module", ptr %t109, i32 0, i32 4
  %t112 = load i64, ptr %t111, !tbaa !24
  %t113 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t114 = load i32, ptr %t113, !tbaa !23
  %t117 = call i64 @compiler_2fnames_2ekey(i64 %t112, i32 %t114)
  store i64 %t117, ptr %l64
  br label %bb24
bb24:
  %t118 = load i64, ptr %l5, !tbaa !24
  %t121 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 5, i64 %t118, i64 -1)
  store %"compiler/names:Ref" %t121, ptr %l67
  br label %bb25
bb25:
  %t122 = load ptr, ptr %l54, !tbaa !29
  %t123 = load i64, ptr %l64, !tbaa !24
  %t124 = load %"compiler/names:Ref", ptr %l67
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t122, i64 %t123, %"compiler/names:Ref" %t124)
  br label %bb26
bb26:
  %t125 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l34 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  %t24 = load i32, ptr %l3, !tbaa !23
  %t28 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHead(ptr %v0, ptr %t22, %"compiler/source:Span" %t23, i32 %t24)
  store i64 %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = load i64, ptr %l19, !tbaa !24
  store i64 %t29, ptr %l7, !tbaa !24
  br label %bb19
bb7:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 28}
  %t37 = icmp eq i64 %t35, 12
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t41, i32 0, i32 0
  %t43 = load %"compiler/source:Span", ptr %t42
  store %"compiler/source:Span" %t43, ptr %l4
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l5, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t53, i32 0, i32 2
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l6, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l4
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  %t65 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHop(ptr %v0, ptr %v1, ptr %t57, %"compiler/source:Span" %t58, ptr %t59, i32 %t60)
  store i64 %t65, ptr %l34
  br label %bb13
bb13:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_fd033da614d46a49_c57bfff01eec9785)
  unreachable
bb19:
  %t67 = load i64, ptr %l7, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %rv = alloca { i64, [3 x i64] }
  %t23 = alloca { i64, [3 x i64] }, align 8
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 4
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t19 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = sext i32 %t20 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t23, i32 0, i32 0
  store i64 3, ptr %t24
  %t26 = insertvalue { i64, i64, i64 } undef, i64 %t14, 0
  %t28 = insertvalue { i64, i64, i64 } %t26, i64 %t18, 1
  %t30 = insertvalue { i64, i64, i64 } %t28, i64 %t22, 2
  %t31 = getelementptr { i64, [3 x i64] }, ptr %t23, i32 0, i32 1
  store { i64, i64, i64 } %t30, ptr %t31
  %t32 = load { i64, [3 x i64] }, ptr %t23
  store { i64, [3 x i64] } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l18 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca %"compiler/names:local"
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 9
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l11
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l10
  br label %bb1
bb1:
  %t12 = load i64, ptr %l10, !tbaa !24
  store i64 %t12, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/names:Resolver", ptr %t14, i32 0, i32 10
  store ptr %t16, ptr %l13, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t21 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s0, i32 %t17, i64 %t13)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %t22, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t23)
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/names:Resolver", ptr %t24, i32 0, i32 9
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l19, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/names:Resolver", ptr %t28, i32 0, i32 8
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l22
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i32, ptr %l19, !tbaa !23
  %t35 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t33, i32 %t34, i64 %t35)
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/names:Resolver", ptr %t36, i32 0, i32 8
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load i32, ptr %l1, !tbaa !23
  %t45 = call %"compiler/names:local" @compiler_2fnames_3alocal_2ector(ptr %s0, i32 %t39, %"compiler/source:Span" %a2, i32 %a3, i1 false, i1 false, i1 false)
  store %"compiler/names:local" %t45, ptr %l28
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = load %"compiler/names:local", ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2ePush_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t46, %"compiler/names:local" %t47)
  br label %bb10
bb10:
  %t48 = load i32, ptr %l1, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/names:Resolver", ptr %t50, i32 0, i32 11
  %t56 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t52, i32 %t48)
  store i1 %t56, ptr %l33
  br label %bb11
bb11:
  %t57 = load i1, ptr %l33, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/names:Resolver", ptr %t60, i32 0, i32 11
  %t63 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t62, i32 %t63)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l19 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l11
  br label %bb4
bb4:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t33, ptr %t31)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t38, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb5
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t43, i64 %t44)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecaseOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i64, ptr %l13, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:Case", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l18
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Case", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l27, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epattern(ptr %v0, ptr %v1, ptr %s1, ptr %t41, ptr %t39, ptr %l3)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t46, 1
  store i64 %t49, ptr %l5, !tbaa !24
  br label %bb5
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Case", ptr %t51, i32 0, i32 2
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/ast:Case", ptr %t60, i32 0, i32 2
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l10, !tbaa !24
  br label %bb15
bb14:
  br label %bb22
bb15:
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t77, ptr %l48, !tbaa !27
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t85 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t85, ptr %t83)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %l9, !tbaa !24
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Case", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb23, label %bb24
bb23:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/ast:Case", ptr %t105, i32 0, i32 3
  %t108 = load ptr, ptr %t107, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t104, ptr %t108)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/ast:Case", ptr %t113, i32 0, i32 4
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t112, { i64, ptr } %t116)
  br label %bb27
bb27:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr %"compiler/ast:Case", ptr %t119, i32 0, i32 5
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb28, label %bb29
bb28:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Case", ptr %t129, i32 0, i32 5
  %t132 = load ptr, ptr %t131, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t128, ptr %t132)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t136, i64 %t137)
  br label %bb32
bb32:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l27 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca ptr
  %l42 = alloca i1
  %l44 = alloca { i64, ptr }
  %l49 = alloca i32
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca %"compiler/names:Ref"
  %l59 = alloca i1
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l87 = alloca i64
  %l104 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb44
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l27, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Catch", ptr %t29, i32 0, i32 5
  %t32 = load i32, ptr %t31, !tbaa !23
  store i32 %t32, ptr %l6, !tbaa !23
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/ast:Catch", ptr %t34, i32 0, i32 6
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l7
  %t39 = load i32, ptr %l6, !tbaa !23
  %t41 = icmp eq i32 %t39, 0
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l5, !tbaa !29
  store ptr %t43, ptr %l37, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Catch", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp eq i64 %t49, 1
  br i1 %t51, label %bb10, label %bb11
bb9:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb18
bb10:
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Catch", ptr %t53, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l44, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 0
  %t60 = load ptr, ptr %t59, !tbaa !39
  %t62 = getelementptr %"compiler/ast:Path", ptr %t60, i32 0, i32 1
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t67 = icmp eq i64 %t65, 1
  store i1 %t67, ptr %l42, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb12
bb12:
  %t69 = load i1, ptr %l42, !tbaa !21
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Catch", ptr %t71, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l52, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 0
  %t78 = load ptr, ptr %t77, !tbaa !39
  %t80 = getelementptr %"compiler/ast:Path", ptr %t78, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l54, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i32, ptr %t83, i64 0
  %t85 = load i32, ptr %t84, !tbaa !33
  %t88 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t70, i32 %t85)
  store %"compiler/names:Ref" %t88, ptr %l56
  br label %bb15
bb14:
  store i32 4, ptr %l49
  br label %bb16
bb15:
  %t90 = getelementptr %"compiler/names:Ref", ptr %l56, i32 0, i32 0
  %t91 = load i32, ptr %t90, !range !{i32 0, i32 9}
  store i32 %t91, ptr %l49
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l37, !tbaa !29
  %t94 = load i32, ptr %l49, !range !{i32 0, i32 9}
  %t95 = call i1 @compiler_2fnames_2eLoneCatchName(ptr %v1, ptr %t93, i32 %t94)
  store i1 %t95, ptr %l59
  br label %bb17
bb17:
  %t96 = load i1, ptr %l59, !tbaa !21
  store i1 %t96, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  %t97 = load i1, ptr %l36, !tbaa !21
  br i1 %t97, label %bb19, label %bb20
bb19:
  %t98 = load ptr, ptr %l5, !tbaa !29
  %t100 = getelementptr %"compiler/ast:Catch", ptr %t98, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l61, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 0
  %t105 = load ptr, ptr %t104, !tbaa !39
  %t107 = getelementptr %"compiler/ast:Path", ptr %t105, i32 0, i32 1
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l63, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i32, ptr %t110, i64 0
  %t112 = load i32, ptr %t111, !tbaa !33
  store i32 %t112, ptr %l6, !tbaa !23
  %t114 = load ptr, ptr %l5, !tbaa !29
  %t116 = getelementptr %"compiler/ast:Catch", ptr %t114, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l66, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr ptr, ptr %t119, i64 0
  %t121 = load ptr, ptr %t120, !tbaa !39
  %t123 = getelementptr %"compiler/ast:Path", ptr %t121, i32 0, i32 0
  %t124 = load %"compiler/source:Span", ptr %t123
  store %"compiler/source:Span" %t124, ptr %l7
  br label %bb28
bb20:
  %t126 = load ptr, ptr %l5, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Catch", ptr %t126, i32 0, i32 1
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  %t135 = load i64, ptr %l9, !tbaa !24
  %t136 = load i64, ptr %l10, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb22, label %bb23
bb22:
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t143 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t143, ptr %l77, !tbaa !27
  %t144 = load i64, ptr %l9, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr ptr, ptr %t147, i64 %t144
  %t149 = load ptr, ptr %t148, !tbaa !39
  %t151 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t151, ptr %t149)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l9, !tbaa !24
  br label %bb21
bb27:
  br label %bb28
bb28:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t161)
  store i64 %t163, ptr %l87
  br label %bb29
bb29:
  %t164 = load i64, ptr %l87, !tbaa !24
  store i64 %t164, ptr %l12, !tbaa !24
  %t165 = load i32, ptr %l6, !tbaa !23
  %t167 = icmp ne i32 %t165, 0
  br i1 %t167, label %bb30, label %bb31
bb30:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l6, !tbaa !23
  %t171 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t169, i32 %t170, %"compiler/source:Span" %t171, i1 false)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load ptr, ptr %l5, !tbaa !29
  %t178 = getelementptr %"compiler/ast:Catch", ptr %t176, i32 0, i32 2
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t175, { i64, ptr } %t179)
  br label %bb34
bb34:
  %t182 = load ptr, ptr %l5, !tbaa !29
  %t184 = getelementptr %"compiler/ast:Catch", ptr %t182, i32 0, i32 3
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l15, !tbaa !24
  br label %bb35
bb35:
  %t191 = load i64, ptr %l14, !tbaa !24
  %t192 = load i64, ptr %l15, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t199 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t199, ptr %l104, !tbaa !27
  %t200 = load i64, ptr %l14, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr ptr, ptr %t203, i64 %t200
  %t205 = load ptr, ptr %t204, !tbaa !39
  %t207 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t207, ptr %t205)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t212 = load i64, ptr %l14, !tbaa !24
  %t215 = add i64 %t212, 1
  store i64 %t215, ptr %l14, !tbaa !24
  br label %bb35
bb41:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t217, i64 %t218)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t221 = load i64, ptr %l3, !tbaa !24
  %t224 = add i64 %t221, 1
  store i64 %t224, ptr %l3, !tbaa !24
  br label %bb4
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l13 = alloca ptr
  %l18 = alloca { i64, [3 x i64] }
  %l19 = alloca %"compiler/diagmsg:Msg"
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i1
  %l33 = alloca %"compiler/names:local"
  %l36 = alloca i1
  %l41 = alloca ptr
  %l46 = alloca { i64, [3 x i64] }
  %l49 = alloca %"compiler/diagmsg:Msg"
  %l52 = alloca { i64, ptr }
  %l54 = alloca %"compiler/diagmsg:Msg"
  %l57 = alloca { i64, ptr }
  %l59 = alloca %"compiler/diagmsg:Msg"
  %l60 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load i1, ptr %l10, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/names:Resolver", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/names:Resolver", ptr %t19, i32 0, i32 7
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load %"compiler/source:Span", ptr %l2
  %t27 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t18, i64 %t22, %"compiler/source:Span" %t23)
  store { i64, [3 x i64] } %t27, ptr %l18
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t28 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %v0)
  store %"compiler/diagmsg:Msg" %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l13, !tbaa !29
  %t30 = load { i64, [3 x i64] }, ptr %l18
  %t31 = load %"compiler/diagmsg:Msg", ptr %l19
  %t32 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t29, { i64, [3 x i64] } %t30, %"compiler/diagmsg:Msg" %t31)
  store i64 %t32, ptr %l20
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/names:Resolver", ptr %t33, i32 0, i32 9
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t35, i32 %t36)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l26
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb10, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l25
  br label %bb9
bb9:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %l21, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l21, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp sge i64 %t46, 0
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/names:Resolver", ptr %t50, i32 0, i32 8
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t52, i64 %t53)
  store %"compiler/names:local" %t56, ptr %l33
  br label %bb15
bb14:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb16
bb15:
  %t57 = getelementptr %"compiler/names:local", ptr %l33, i32 0, i32 2
  %t58 = load i32, ptr %t57, !range !{i32 0, i32 9}
  %t60 = trunc i64 1 to i32
  %t61 = icmp eq i32 %t58, %t60
  store i1 %t61, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t63 = load i1, ptr %l29, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t66 = xor i1 %a3, true
  store i1 %t66, ptr %l36, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb19
bb19:
  %t68 = load i1, ptr %l36, !tbaa !21
  br i1 %t68, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/load:Loader", ptr %t72, i32 0, i32 4
  %t75 = load ptr, ptr %t74, !tbaa !29
  store ptr %t75, ptr %l41, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/names:Resolver", ptr %t77, i32 0, i32 7
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = load %"compiler/source:Span", ptr %l2
  %t85 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t76, i64 %t80, %"compiler/source:Span" %t81)
  store { i64, [3 x i64] } %t85, ptr %l46
  br label %bb22
bb21:
  br label %bb31
bb22:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/names:Resolver", ptr %t86, i32 0, i32 14
  %t89 = load i1, ptr %t88, !tbaa !21
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l1, !tbaa !23
  %t95 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t91, i32 %t92)
  store { i64, ptr } %t95, ptr %l52
  br label %bb25
bb24:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t96, i32 %t97)
  store { i64, ptr } %t100, ptr %l57
  br label %bb27
bb25:
  %t101 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t103 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAlreadyDeclared(ptr %s2, ptr %v0, { i64, ptr } %t101)
  store %"compiler/diagmsg:Msg" %t103, ptr %l54
  br label %bb26
bb26:
  %t104 = load %"compiler/diagmsg:Msg", ptr %l54
  store %"compiler/diagmsg:Msg" %t104, ptr %l49
  br label %bb29
bb27:
  %t105 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t107 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDeclaredTwice(ptr %s2, ptr %v0, { i64, ptr } %t105)
  store %"compiler/diagmsg:Msg" %t107, ptr %l59
  br label %bb28
bb28:
  %t108 = load %"compiler/diagmsg:Msg", ptr %l59
  store %"compiler/diagmsg:Msg" %t108, ptr %l49
  br label %bb29
bb29:
  %t109 = load ptr, ptr %l41, !tbaa !29
  %t110 = load { i64, [3 x i64] }, ptr %l46
  %t111 = load %"compiler/diagmsg:Msg", ptr %l49
  %t112 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t109, { i64, [3 x i64] } %t110, %"compiler/diagmsg:Msg" %t111)
  store i64 %t112, ptr %l60
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l1, !tbaa !23
  %t115 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoShadow(ptr %v0, ptr %t113, i32 %t114, %"compiler/source:Span" %t115)
  br label %bb32
bb32:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/names:Resolver", ptr %t120, i32 0, i32 7
  %t123 = load i64, ptr %t122, !tbaa !24
  %t124 = load i32, ptr %l1, !tbaa !23
  %t125 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t119, i64 %t123, i32 %t124, %"compiler/source:Span" %t125)
  br label %bb33
bb33:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l1, !tbaa !23
  %t132 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t130, i32 %t131, %"compiler/source:Span" %t132, i32 1)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/names:local"
  %l8 = alloca i64
  %l14 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca %"compiler/names:local"
  %l25 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l34 = alloca %"compiler/names:local"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t7, i32 %a1, %"compiler/source:Span" %a2, i1 false)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/names:Resolver", ptr %t13, i32 0, i32 8
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l14
  br label %bb3
bb3:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l14, !tbaa !24
  %t21 = icmp sgt i64 %t19, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/names:Resolver", ptr %t23, i32 0, i32 8
  store ptr %t25, ptr %l18, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/names:Resolver", ptr %t26, i32 0, i32 8
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l21
  br label %bb6
bb5:
  br label %bb11
bb6:
  %t31 = load i64, ptr %l21, !tbaa !24
  %t32 = sub i64 %t31, 1
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t35 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t33, i64 %t32)
  store %"compiler/names:local" %t35, ptr %l23
  br label %bb7
bb7:
  %t36 = load %"compiler/names:local", ptr %l23
  store %"compiler/names:local" %t36, ptr %l5
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t37, i32 0, i32 8
  store ptr %t39, ptr %l25, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 8
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l28
  br label %bb8
bb8:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = sub i64 %t45, 1
  store i64 %t46, ptr %l29, !tbaa !24
  %t47 = getelementptr %"compiler/names:local", ptr %l5, i32 0, i32 0
  %t48 = load i32, ptr %t47, !tbaa !23
  %t49 = getelementptr %"compiler/names:local", ptr %l5, i32 0, i32 1
  %t50 = load %"compiler/source:Span", ptr %t49
  %t51 = getelementptr %"compiler/names:local", ptr %l5, i32 0, i32 2
  %t52 = load i32, ptr %t51, !range !{i32 0, i32 9}
  %t58 = call %"compiler/names:local" @compiler_2fnames_3alocal_2ector(ptr %s1, i32 %t48, %"compiler/source:Span" %t50, i32 %t52, i1 true, i1 %a3, i1 false)
  store %"compiler/names:local" %t58, ptr %l34
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l25, !tbaa !29
  %t60 = load i64, ptr %l29, !tbaa !24
  %t61 = load %"compiler/names:local", ptr %l34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eSetAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t59, i64 %t60, %"compiler/names:local" %t61)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eelemsPattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %l52 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 16
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %bb34
bb10:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t28 = load ptr, ptr %l22, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l22, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 28}
  %t34 = icmp eq i64 %t32, 17
  store i1 %t34, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb34
bb16:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t37 = load ptr, ptr %l26, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb17, label %bb18
bb17:
  %t40 = load ptr, ptr %l26, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 28}
  %t43 = icmp eq i64 %t41, 13
  store i1 %t43, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb19, label %bb20
bb19:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb28
bb21:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t55 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enamesType(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  store i1 %t55, ptr %l34
  br label %bb22
bb22:
  %t56 = load i1, ptr %l34, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb23, label %bb24
bb23:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t59, ptr %t60)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %ret
bb26:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  br label %bb27
bb27:
  br label %bb34
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  br label %bb32
bb32:
  br label %ret
bb33:
  call void @__olang_check_failed(ptr @olang_loc_f2d30a85840d12d4_ee21d33ae1ca6100)
  unreachable
bb34:
  store { i64, ptr } %a2, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  store i64 %t78, ptr %l8, !tbaa !24
  br label %bb35
bb35:
  %t80 = load i64, ptr %l7, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t88 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t88, ptr %l52, !tbaa !27
  %t89 = load i64, ptr %l7, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr ptr, ptr %t92, i64 %t89
  %t94 = load ptr, ptr %t93, !tbaa !39
  %t96 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epattern(ptr %v0, ptr %v2, ptr %v3, ptr %t96, ptr %t94, ptr %a3)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = add i64 %t102, 1
  store i64 %t105, ptr %l7, !tbaa !24
  br label %bb35
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforName(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l27 = alloca i1
  %l31 = alloca %"compiler/names:local"
  %l34 = alloca i1
  %l40 = alloca ptr
  %l44 = alloca i1
  %l47 = alloca ptr
  %l52 = alloca { i64, [3 x i64] }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t5, i32 %t6)
  store { i64, ptr } %t9, ptr %l11
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t11, ptr %l12
  br label %bb4
bb4:
  %t12 = load i1, ptr %l12, !tbaa !21
  store i1 %t12, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/names:Resolver", ptr %t15, i32 0, i32 7
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = load i32, ptr %l2, !tbaa !23
  %t25 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t14, i64 %t18, i32 %a1, i32 %t20)
  store %"compiler/source:Span" %t25, ptr %l18
  br label %bb9
bb9:
  %t26 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t26, ptr %l3
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 9
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t29, i32 %t30)
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l24
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb11, label %ok.37, !prof !99
ok.37:
  store i64 %t34, ptr %l23
  br label %bb10
bb10:
  %t38 = load i64, ptr %l23, !tbaa !24
  store i64 %t38, ptr %l19, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  store i64 -1, ptr %l19, !tbaa !24
  br label %bb13
bb13:
  %t39 = load i64, ptr %l19, !tbaa !24
  store i64 %t39, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = icmp sge i64 %t40, 0
  br i1 %t42, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/names:Resolver", ptr %t44, i32 0, i32 8
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t46, i64 %t47)
  store %"compiler/names:local" %t50, ptr %l31
  br label %bb16
bb15:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb17
bb16:
  %t51 = getelementptr %"compiler/names:local", ptr %l31, i32 0, i32 2
  %t52 = load i32, ptr %t51, !range !{i32 0, i32 9}
  %t54 = trunc i64 1 to i32
  %t55 = icmp eq i32 %t52, %t54
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l27, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb22
bb19:
  %t58 = load i32, ptr %l2, !tbaa !23
  store i32 %t58, ptr %l5, !tbaa !23
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/names:Resolver", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/names:Resolver", ptr %t63, i32 0, i32 7
  %t66 = load i64, ptr %t65, !tbaa !24
  %t69 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t62, i64 %t66)
  store ptr %t69, ptr %l40
  br label %bb20
bb20:
  %t70 = load ptr, ptr %l40, !tbaa !29
  %t72 = getelementptr %"compiler/names:Table", ptr %t70, i32 0, i32 1
  %t73 = load i32, ptr %l5, !tbaa !23
  %t76 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t76, ptr %l44
  br label %bb21
bb21:
  %t77 = load i1, ptr %l44, !tbaa !21
  store i1 %t77, ptr %l34, !tbaa !21
  br label %bb22
bb22:
  %t78 = load i1, ptr %l34, !tbaa !21
  br i1 %t78, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/names:Resolver", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 4
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l47, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/names:Resolver", ptr %t87, i32 0, i32 7
  %t90 = load i64, ptr %t89, !tbaa !24
  %t91 = load %"compiler/source:Span", ptr %l3
  %t95 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t86, i64 %t90, %"compiler/source:Span" %t91)
  store { i64, [3 x i64] } %t95, ptr %l52
  br label %bb25
bb24:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l2, !tbaa !23
  %t98 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %t96, i32 %t97, %"compiler/source:Span" %t98, i1 true)
  br label %bb31
bb25:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l2, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t102, i32 %t103)
  store { i64, ptr } %t106, ptr %l55
  br label %bb26
bb26:
  %t107 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t107, ptr %l56, !tbaa !27
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l2, !tbaa !23
  %t112 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t108, i32 %t109)
  store { i64, ptr } %t112, ptr %l59
  br label %bb27
bb27:
  %t113 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t115 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInNameExists(ptr %s2, ptr %v0, ptr %v0, { i64, ptr } %t113, { i64, ptr } %t114)
  store %"compiler/diagmsg:Msg" %t115, ptr %l60
  br label %bb28
bb28:
  %t116 = load ptr, ptr %l47, !tbaa !29
  %t117 = load { i64, [3 x i64] }, ptr %l52
  %t118 = load %"compiler/diagmsg:Msg", ptr %l60
  %t119 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t116, { i64, [3 x i64] } %t117, %"compiler/diagmsg:Msg" %t118)
  store i64 %t119, ptr %l61
  br label %bb29
bb29:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l2, !tbaa !23
  %t122 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t120, i32 %t121, %"compiler/source:Span" %t122, i32 1)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforNames(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforName(ptr %v0, ptr %t1, i32 %t2, i32 %a2)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforName(ptr %v0, ptr %t7, i32 %t8, i32 %a3)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i64, ptr %l4, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t5, ptr %t6, i1 true)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Func", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epushSig(ptr %v0, ptr %v1, ptr %t9, ptr %t13)
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Func", ptr %t16, i32 0, i32 4
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 4
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t25, { i64, ptr } %t29)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopSig(ptr %v0, ptr %t32)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t34, i64 %t35)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eintroduce(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i1
  %l24 = alloca %"compiler/names:local"
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/names:Ref"
  %l39 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca i32
  %l48 = alloca i64
  %l51 = alloca i64
  %l53 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  %t5 = xor i1 %t3, true
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/names:Resolver", ptr %t12, i32 0, i32 9
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t14, i32 %t15)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l17
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb6, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l16
  br label %bb5
bb5:
  %t23 = load i64, ptr %l16, !tbaa !24
  store i64 %t23, ptr %l12, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t24 = load i64, ptr %l12, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sge i64 %t25, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/names:Resolver", ptr %t29, i32 0, i32 8
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t31, i64 %t32)
  store %"compiler/names:local" %t35, ptr %l24
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t36 = getelementptr %"compiler/names:local", ptr %l24, i32 0, i32 2
  %t37 = load i32, ptr %t36, !range !{i32 0, i32 9}
  %t39 = trunc i64 8 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l20, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l27, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t44, ptr %l28
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/names:Resolver", ptr %t45, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t53 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 8, i64 %t48, i64 %t49)
  store %"compiler/names:Ref" %t53, ptr %l33
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t54 = load ptr, ptr %l27, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l28
  %t56 = load %"compiler/names:Ref", ptr %l33
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t54, %"compiler/source:Span" %t55, %"compiler/names:Ref" %t56)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/names:Resolver", ptr %t58, i32 0, i32 7
  %t61 = load i64, ptr %t60, !tbaa !24
  %t62 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t63 = load i32, ptr %t62, !tbaa !23
  %t64 = load i32, ptr %l2, !tbaa !23
  %t69 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t57, i64 %t61, i32 %t63, i32 %t64)
  store %"compiler/source:Span" %t69, ptr %l39
  br label %bb18
bb18:
  %t70 = load %"compiler/source:Span", ptr %l39
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t71, i32 %t72, %"compiler/source:Span" %t70, i32 8)
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l44, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t79, ptr %l45
  store i32 8, ptr %l46
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/names:Resolver", ptr %t80, i32 0, i32 7
  %t83 = load i64, ptr %t82, !tbaa !24
  store i64 %t83, ptr %l48, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/names:Resolver", ptr %t84, i32 0, i32 8
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l51
  br label %bb20
bb20:
  %t89 = load i64, ptr %l51, !tbaa !24
  %t90 = sub i64 %t89, 1
  %t91 = load i32, ptr %l46, !range !{i32 0, i32 9}
  %t92 = load i64, ptr %l48, !tbaa !24
  %t94 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 %t91, i64 %t92, i64 %t90)
  store %"compiler/names:Ref" %t94, ptr %l53
  br label %bb21
bb21:
  %t95 = load ptr, ptr %l44, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l45
  %t97 = load %"compiler/names:Ref", ptr %l53
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t95, %"compiler/source:Span" %t96, %"compiler/names:Ref" %t97)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eintroduceVar(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i1
  %l17 = alloca %"compiler/names:local"
  %l22 = alloca i1
  %l27 = alloca %"compiler/names:Ref"
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 9
  %t4 = load i32, ptr %l2, !tbaa !23
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l5, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 8
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t20, i64 %t21)
  store %"compiler/names:local" %t24, ptr %l17
  br label %bb7
bb6:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  %t25 = getelementptr %"compiler/names:local", ptr %l17, i32 0, i32 2
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 9}
  %t28 = trunc i64 8 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l13, !tbaa !21
  %t34 = xor i1 %t31, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t37, i32 0, i32 7
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i32, ptr %l2, !tbaa !23
  %t45 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeIn(ptr %v0, ptr %t36, i64 %t40, i32 %t41)
  store %"compiler/names:Ref" %t45, ptr %l27
  br label %bb11
bb10:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb12
bb11:
  %t46 = getelementptr %"compiler/names:Ref", ptr %l27, i32 0, i32 0
  %t47 = load i32, ptr %t46, !range !{i32 0, i32 9}
  %t49 = trunc i64 0 to i32
  %t50 = icmp eq i32 %t47, %t49
  store i1 %t50, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l22, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eintroduce(ptr %v0, ptr %v0, ptr %t53, %"compiler/source:Span" %a1, i32 %t55, ptr null)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ejudge(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/names:local"
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"compiler/names:local"
  %l22 = alloca i1
  %l26 = alloca { i64, ptr }
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l52 = alloca i1
  %l57 = alloca ptr
  %l63 = alloca ptr
  %l69 = alloca %"compiler/names:Unread"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l11, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 8
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l14
  br label %bb3
bb3:
  %t11 = load i64, ptr %l11, !tbaa !24
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l10, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/names:Resolver", ptr %t16, i32 0, i32 8
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t18, i64 %t19)
  store %"compiler/names:local" %t22, ptr %l19
  br label %bb8
bb8:
  %t23 = load %"compiler/names:local", ptr %l19
  store %"compiler/names:local" %t23, ptr %l2
  %t24 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 3
  %t25 = load i1, ptr %t24, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t29 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 5
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 0
  %t35 = load i32, ptr %t34, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t33, i32 %t35)
  store { i64, ptr } %t38, ptr %l26
  br label %bb15
bb15:
  %t39 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t39, ptr %l3, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 18
  store ptr %t42, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  %t44 = load i64, ptr %l5, !tbaa !24
  store i64 %t44, ptr %l29, !tbaa !24
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t45)
  store i64 %t47, ptr %l31
  br label %bb17
bb17:
  %t48 = load i64, ptr %l29, !tbaa !24
  %t49 = load i64, ptr %l31, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb18, label %bb19
bb18:
  br label %bb31
bb19:
  br label %bb20
bb20:
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t54, i64 %t55)
  store %"compiler/source:Span" %t58, ptr %l36
  br label %bb21
bb21:
  %t59 = load %"compiler/source:Span", ptr %l36
  store %"compiler/source:Span" %t59, ptr %l6
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/names:Resolver", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/load:Loader", ptr %t63, i32 0, i32 10
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/names:Resolver", ptr %t66, i32 0, i32 7
  %t69 = load i64, ptr %t68, !tbaa !24
  %t72 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t65, i64 %t69)
  store ptr %t72, ptr %l42
  br label %bb22
bb22:
  %t73 = load ptr, ptr %l42, !tbaa !29
  %t75 = getelementptr %"compiler/load:Module", ptr %t73, i32 0, i32 6
  %t76 = load ptr, ptr %t75, !tbaa !29
  store ptr %t76, ptr %l7, !tbaa !29
  %t78 = load ptr, ptr %l7, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_29838351972cb384_2d79eff554670e58)
  unreachable
bb24:
  br label %bb25
bb25:
  %t82 = load ptr, ptr %l7, !tbaa !29
  %t85 = getelementptr %"compiler/source:Source", ptr %t82, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t87 = load %"compiler/source:Span", ptr %l6
  %t88 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t92 = call i1 @compiler_2fnames_2eMentions(ptr %v0, ptr %v0, { i64, ptr } %t86, %"compiler/source:Span" %t87, { i64, ptr } %t88)
  store i1 %t92, ptr %l52
  br label %bb26
bb26:
  %t93 = load i1, ptr %l52, !tbaa !21
  br i1 %t93, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t94 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t94, 1
  store i64 %t97, ptr %l5, !tbaa !24
  br label %bb16
bb31:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/names:Resolver", ptr %t99, i32 0, i32 19
  store ptr %t101, ptr %l57, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/names:Resolver", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/load:Loader", ptr %t105, i32 0, i32 10
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/names:Resolver", ptr %t108, i32 0, i32 7
  %t111 = load i64, ptr %t110, !tbaa !24
  %t114 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t107, i64 %t111)
  store ptr %t114, ptr %l63
  br label %bb32
bb32:
  %t115 = load ptr, ptr %l63, !tbaa !29
  %t117 = getelementptr %"compiler/load:Module", ptr %t115, i32 0, i32 4
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 1
  %t120 = load %"compiler/source:Span", ptr %t119
  %t121 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 0
  %t122 = load i32, ptr %t121, !tbaa !23
  %t123 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 4
  %t124 = load i1, ptr %t123, !tbaa !21
  %t129 = call %"compiler/names:Unread" @compiler_2fnames_3aUnread_2ector(ptr %s0, i64 %t118, %"compiler/source:Span" %t120, i32 %t122, i1 %t124)
  store %"compiler/names:Unread" %t129, ptr %l69
  br label %bb33
bb33:
  %t130 = load ptr, ptr %l57, !tbaa !29
  %t131 = load %"compiler/names:Unread", ptr %l69
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2ePush_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t130, %"compiler/names:Unread" %t131)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 10
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ematchOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l18 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Match", ptr %t9, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecaseOf(ptr %v0, ptr %v1, ptr %t34, ptr %t32)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = add i64 %t38, 1
  store i64 %t41, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ememberOf(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l23 = alloca %"compiler/names:Entry"
  %l27 = alloca %"compiler/names:Ref"
  %l28 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l39 = alloca %"compiler/names:Ref"
  %l43 = alloca %"compiler/names:Ref"
  %l48 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i32
  %l58 = alloca %"compiler/names:Ref"
  %l60 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l11, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/names:Table", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l17
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l16
  br label %bb2
bb2:
  %t20 = load i64, ptr %l16, !tbaa !24
  store i64 %t20, ptr %l12, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/names:Table", ptr %t26, i32 0, i32 0
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s1, ptr %t28, i64 %t29)
  store %"compiler/names:Entry" %t32, ptr %l23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t33 = getelementptr %"compiler/names:Entry", ptr %l23, i32 0, i32 2
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 9}
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t40 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s1, i32 %t34, i64 %t35, i64 %t36)
  store %"compiler/names:Ref" %t40, ptr %l27
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/names:Ref", ptr %l27
  store %"compiler/names:Ref" %t41, ptr %rv
  br label %ret
bb10:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/names:Table", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t44, i32 %t45)
  %t49 = extractvalue { i32, i64 } %t48, 1
  %t50 = extractvalue { i32, i64 } %t48, 0
  store i32 %t50, ptr %l33
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb12, label %ok.52, !prof !99
ok.52:
  store i64 %t49, ptr %l32
  br label %bb11
bb11:
  %t53 = load i64, ptr %l32, !tbaa !24
  store i64 %t53, ptr %l28, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l28, !tbaa !24
  br label %bb14
bb14:
  %t54 = load i64, ptr %l28, !tbaa !24
  store i64 %t54, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t64 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 4, i64 %t59, i64 %t60)
  store %"compiler/names:Ref" %t64, ptr %l39
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t65 = load %"compiler/names:Ref", ptr %l39
  store %"compiler/names:Ref" %t65, ptr %rv
  br label %ret
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = load i32, ptr %l2, !tbaa !23
  %t72 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esharedType(ptr %v0, ptr %t66, i64 %t67, i32 %t68)
  store %"compiler/names:Ref" %t72, ptr %l43
  br label %bb19
bb19:
  %t73 = load %"compiler/names:Ref", ptr %l43
  store %"compiler/names:Ref" %t73, ptr %l6
  %t74 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t75 = load i32, ptr %t74, !range !{i32 0, i32 9}
  %t77 = trunc i64 0 to i32
  %t78 = icmp eq i32 %t75, %t77
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb20, label %bb21
bb20:
  %t82 = load %"compiler/names:Ref", ptr %l6
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/names:Ref" %t82, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/names:Table", ptr %t84, i32 0, i32 3
  %t87 = load i32, ptr %l2, !tbaa !23
  %t90 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t86, i32 %t87)
  %t91 = extractvalue { i32, i64 } %t90, 1
  %t92 = extractvalue { i32, i64 } %t90, 0
  store i32 %t92, ptr %l53
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb24, label %ok.94, !prof !99
ok.94:
  store i64 %t91, ptr %l52
  br label %bb23
bb23:
  %t95 = load i64, ptr %l52, !tbaa !24
  store i64 %t95, ptr %l48, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  store i64 -1, ptr %l48, !tbaa !24
  br label %bb26
bb26:
  %t96 = load i64, ptr %l48, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t99 = icmp sge i64 %t97, 0
  br i1 %t99, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s4, i32 5, i64 %t101, i64 -1)
  store %"compiler/names:Ref" %t104, ptr %l58
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t105 = load %"compiler/names:Ref", ptr %l58
  store %"compiler/names:Ref" %t105, ptr %rv
  br label %ret
bb30:
  %t107 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t107, ptr %l60
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t108 = load %"compiler/names:Ref", ptr %l60
  store %"compiler/names:Ref" %t108, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enamesType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/names:Ref"
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca %"compiler/names:Ref"
  %l20 = alloca i1
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca %"compiler/names:Ref"
  %l46 = alloca i1
  %l53 = alloca ptr
  %l57 = alloca i1
  %l58 = alloca i1
  %l62 = alloca %"compiler/names:Ref"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t16, i32 %t17)
  store %"compiler/names:Ref" %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = getelementptr %"compiler/names:Ref", ptr %l16, i32 0, i32 0
  %t22 = load i32, ptr %t21, !range !{i32 0, i32 9}
  store i32 %t22, ptr %l3
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 9}
  %t26 = trunc i64 4 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t29 = load i32, ptr %l3, !range !{i32 0, i32 9}
  %t31 = trunc i64 7 to i32
  %t32 = icmp eq i32 %t29, %t31
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t35 = load i32, ptr %l3, !range !{i32 0, i32 9}
  %t37 = trunc i64 8 to i32
  %t38 = icmp eq i32 %t35, %t37
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l23, !tbaa !21
  store i1 %t40, ptr %rv
  br label %ret
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t42 = load ptr, ptr %l26, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 28}
  %t48 = icmp eq i64 %t46, 12
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t52, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t58, i32 0, i32 2
  %t60 = load i32, ptr %t59
  store i32 %t60, ptr %l5, !tbaa !23
  br label %bb18
bb17:
  br label %bb42
bb18:
  %t62 = load ptr, ptr %l4, !tbaa !29
  store ptr %t62, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 28}
  %t69 = icmp eq i64 %t67, 0
  store i1 %t69, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l35, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32 }, ptr %t73, i32 0, i32 1
  %t75 = load i32, ptr %t74
  store i32 %t75, ptr %l6, !tbaa !23
  br label %bb23
bb22:
  br label %bb37
bb23:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l6, !tbaa !23
  %t81 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t77, i32 %t78)
  store %"compiler/names:Ref" %t81, ptr %l42
  br label %bb24
bb24:
  %t82 = load %"compiler/names:Ref", ptr %l42
  store %"compiler/names:Ref" %t82, ptr %l7
  %t83 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t84 = load i32, ptr %t83, !range !{i32 0, i32 9}
  %t86 = trunc i64 5 to i32
  %t87 = icmp eq i32 %t84, %t86
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb27
bb26:
  %t91 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  %t94 = icmp slt i64 %t92, 0
  store i1 %t94, ptr %l46, !tbaa !21
  br label %bb27
bb27:
  %t96 = load i1, ptr %l46, !tbaa !21
  br i1 %t96, label %bb28, label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/names:Resolver", ptr %t98, i32 0, i32 1
  %t101 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t102 = load i64, ptr %t101, !tbaa !24
  %t105 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t100, i64 %t102)
  store ptr %t105, ptr %l53
  br label %bb31
bb31:
  %t106 = load ptr, ptr %l53, !tbaa !29
  %t108 = getelementptr %"compiler/names:Table", ptr %t106, i32 0, i32 2
  %t109 = load i32, ptr %l5, !tbaa !23
  %t112 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t108, i32 %t109)
  store i1 %t112, ptr %l57
  br label %bb32
bb32:
  %t113 = load i1, ptr %l57, !tbaa !21
  br i1 %t113, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb36
bb34:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load i32, ptr %l5, !tbaa !23
  %t121 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esharedType(ptr %v0, ptr %t114, i64 %t116, i32 %t117)
  store %"compiler/names:Ref" %t121, ptr %l62
  br label %bb35
bb35:
  %t122 = getelementptr %"compiler/names:Ref", ptr %l62, i32 0, i32 0
  %t123 = load i32, ptr %t122, !range !{i32 0, i32 9}
  %t125 = trunc i64 0 to i32
  %t126 = icmp eq i32 %t123, %t125
  %t128 = xor i1 %t126, true
  store i1 %t128, ptr %l58, !tbaa !21
  br label %bb36
bb36:
  %t130 = load i1, ptr %l58, !tbaa !21
  store i1 %t130, ptr %rv
  br label %ret
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store i1 false, ptr %rv
  br label %ret
bb41:
  call void @__olang_check_failed(ptr @olang_loc_2c32128468766446_22803ecfd3e7a722)
  unreachable
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i1 false, ptr %rv
  br label %ret
bb46:
  call void @__olang_check_failed(ptr @olang_loc_f2fe3b3cf3edda27_d5ea4c4d6e43c823)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l20 = alloca { i64, [3 x i64] }
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/diagmsg:Msg"
  %l26 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  store i32 %t1, ptr %l4, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t3, i32 0, i32 1
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t12 = getelementptr %"compiler/names:Table", ptr %t10, i32 0, i32 3
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  %t31 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t25, i64 %t26, %"compiler/source:Span" %a3)
  store { i64, [3 x i64] } %t31, ptr %l20
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t32, i32 %t33)
  store { i64, ptr } %t36, ptr %l23
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNameClashesWithImport(ptr %s1, ptr %v0, { i64, ptr } %t37)
  store %"compiler/diagmsg:Msg" %t39, ptr %l25
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l16, !tbaa !29
  %t41 = load { i64, [3 x i64] }, ptr %l20
  %t42 = load %"compiler/diagmsg:Msg", ptr %l25
  %t43 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t40, { i64, [3 x i64] } %t41, %"compiler/diagmsg:Msg" %t42)
  store i64 %t43, ptr %l26
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enotPrivate(ptr %v0, ptr %a0, i64 %a1, %"compiler/names:Ref" %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/names:Ref"
  %l3 = alloca i32
  %l5 = alloca %"compiler/diagmsg:Msg"
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca ptr
  %l31 = alloca %"compiler/diagmsg:Msg"
  %l34 = alloca { i64, ptr }
  %l36 = alloca %"compiler/diagmsg:Msg"
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"compiler/diagmsg:Msg"
  %l44 = alloca ptr
  %l49 = alloca { i64, [3 x i64] }
  %l51 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/names:Ref" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/names:Resolver", ptr %t2, i32 0, i32 7
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = icmp eq i64 %t1, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t10 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t11 = load i32, ptr %t10, !range !{i32 0, i32 9}
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t17 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 9}
  %t20 = trunc i64 5 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t28, ptr %l19
  br label %bb9
bb9:
  %t29 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t30 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t29)
  store i1 %t30, ptr %l20
  br label %bb10
bb10:
  %t31 = load i1, ptr %l20, !tbaa !21
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l16, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb15
bb13:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/names:Resolver", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/load:Loader", ptr %t36, i32 0, i32 10
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t38, i64 %t39)
  store ptr %t42, ptr %l26
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t45 = getelementptr %"compiler/load:Module", ptr %t43, i32 0, i32 33
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb15
bb15:
  %t48 = load i1, ptr %l21, !tbaa !21
  br i1 %t48, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  br label %bb18
bb18:
  %t49 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 9}
  %t52 = trunc i64 4 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t55, i32 %t56)
  store { i64, ptr } %t59, ptr %l34
  br label %bb21
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t60, i32 %t61)
  store { i64, ptr } %t64, ptr %l39
  br label %bb23
bb21:
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t67 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeIsPrivate(ptr %s0, ptr %v0, { i64, ptr } %t65)
  store %"compiler/diagmsg:Msg" %t67, ptr %l36
  br label %bb22
bb22:
  %t68 = load %"compiler/diagmsg:Msg", ptr %l36
  store %"compiler/diagmsg:Msg" %t68, ptr %l31
  br label %bb25
bb23:
  %t69 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t71 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVarIsPrivate(ptr %s0, ptr %v0, { i64, ptr } %t69)
  store %"compiler/diagmsg:Msg" %t71, ptr %l41
  br label %bb24
bb24:
  %t72 = load %"compiler/diagmsg:Msg", ptr %l41
  store %"compiler/diagmsg:Msg" %t72, ptr %l31
  br label %bb25
bb25:
  %t73 = load %"compiler/diagmsg:Msg", ptr %l31
  store %"compiler/diagmsg:Msg" %t73, ptr %l5
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/names:Resolver", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/load:Loader", ptr %t77, i32 0, i32 4
  %t80 = load ptr, ptr %t79, !tbaa !29
  store ptr %t80, ptr %l44, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/names:Resolver", ptr %t82, i32 0, i32 7
  %t85 = load i64, ptr %t84, !tbaa !24
  %t90 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t81, i64 %t85, %"compiler/source:Span" %a4)
  store { i64, [3 x i64] } %t90, ptr %l49
  br label %bb26
bb26:
  %t91 = load %"compiler/diagmsg:Msg", ptr %l5
  %t92 = load ptr, ptr %l44, !tbaa !29
  %t93 = load { i64, [3 x i64] }, ptr %l49
  %t95 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t92, { i64, [3 x i64] } %t93, %"compiler/diagmsg:Msg" %t91)
  store i64 %t95, ptr %l51
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l11 = alloca ptr
  %l17 = alloca { i64, [3 x i64] }
  %l18 = alloca %"compiler/diagmsg:Msg"
  %l19 = alloca i64
  %l27 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Param", ptr %t2, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  %t8 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t5)
  store { i64, ptr } %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/names:Resolver", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/load:Loader", ptr %t15, i32 0, i32 4
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l11, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/names:Resolver", ptr %t20, i32 0, i32 7
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Param", ptr %t24, i32 0, i32 0
  %t27 = load %"compiler/source:Span", ptr %t26
  %t31 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t19, i64 %t23, %"compiler/source:Span" %t27)
  store { i64, [3 x i64] } %t31, ptr %l17
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t32 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %v0)
  store %"compiler/diagmsg:Msg" %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l11, !tbaa !29
  %t34 = load { i64, [3 x i64] }, ptr %l17
  %t35 = load %"compiler/diagmsg:Msg", ptr %l18
  %t36 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t33, { i64, [3 x i64] } %t34, %"compiler/diagmsg:Msg" %t35)
  store i64 %t36, ptr %l19
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/names:Resolver", ptr %t38, i32 0, i32 7
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Param", ptr %t42, i32 0, i32 0
  %t45 = getelementptr %"compiler/source:Span", ptr %t44, i32 0, i32 0
  %t46 = load i32, ptr %t45, !tbaa !23
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Param", ptr %t47, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  %t55 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t37, i64 %t41, i32 %t46, i32 %t50)
  store %"compiler/source:Span" %t55, ptr %l27
  br label %bb9
bb9:
  %t56 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t56, ptr %l3
  br i1 %a2, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/ast:Param", ptr %t60, i32 0, i32 1
  %t63 = load i32, ptr %t62, !tbaa !23
  %t64 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t59, i32 %t63, %"compiler/source:Span" %t64, i1 false)
  br label %bb12
bb11:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 7
  %t72 = load i64, ptr %t71, !tbaa !24
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Param", ptr %t73, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t77 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t68, i64 %t72, i32 %t76, %"compiler/source:Span" %t77)
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Param", ptr %t83, i32 0, i32 1
  %t86 = load i32, ptr %t85, !tbaa !23
  %t87 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t82, i32 %t86, %"compiler/source:Span" %t87, i32 1)
  br label %bb14
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/names:Ref"
  %l7 = alloca i1
  %l13 = alloca { i64, ptr }
  %l21 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/names:Ref"
  %l30 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:Path", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Path", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 0
  %t22 = load i32, ptr %t21, !tbaa !33
  store i32 %t22, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/names:Resolver", ptr %t25, i32 0, i32 7
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Path", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"compiler/source:Span", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load i32, ptr %l2, !tbaa !23
  %t39 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t24, i64 %t28, i32 %t33, i32 %t34)
  store %"compiler/source:Span" %t39, ptr %l21
  br label %bb7
bb7:
  %t40 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t40, ptr %l3
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t41, i32 %t42)
  store %"compiler/names:Ref" %t45, ptr %l24
  br label %bb8
bb8:
  %t46 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t46, ptr %l4
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l3
  %t49 = load %"compiler/names:Ref", ptr %l4
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t47, %"compiler/source:Span" %t48, %"compiler/names:Ref" %t49)
  br label %bb9
bb9:
  %t53 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t54 = load i32, ptr %t53, !range !{i32 0, i32 9}
  %t56 = trunc i64 0 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Path", ptr %t59, i32 0, i32 1
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t66 = icmp sge i64 %t64, 2
  store i1 %t66, ptr %l30, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t68 = load i1, ptr %l30, !tbaa !21
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l3
  %t71 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %t69, %"compiler/source:Span" %t70, i32 %t71)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l56 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l66 = alloca i1
  %l76 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l98 = alloca { i64, ptr }
  %l99 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i1
  %l143 = alloca { i64, ptr }
  %l144 = alloca i1
  %l146 = alloca i1
  %l150 = alloca i1
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t17 = load ptr, ptr %l29, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l29, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 9}
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l30, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l30, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb10
bb10:
  br label %bb91
bb11:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t37 = load ptr, ptr %l38, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l38, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 9}
  %t43 = icmp eq i64 %t41, 2
  store i1 %t43, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l39, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l4, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t53, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %t54
  store { i64, ptr } %t55, ptr %l5, !tbaa !27
  br label %bb16
bb15:
  br label %bb25
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t57, ptr %t58)
  br label %bb17
bb17:
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t62, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb19, label %bb20
bb19:
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t76 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t76, ptr %l56, !tbaa !27
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t77
  %t82 = load ptr, ptr %t81, !tbaa !39
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %t84, ptr %t82, ptr %t86)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %l7, !tbaa !24
  br label %bb18
bb24:
  br label %bb91
bb25:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t96 = load ptr, ptr %l65, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb26, label %bb27
bb26:
  %t99 = load ptr, ptr %l65, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 9}
  %t102 = icmp eq i64 %t100, 3
  store i1 %t102, ptr %l66, !tbaa !21
  br label %bb27
bb27:
  %t103 = load i1, ptr %l66, !tbaa !21
  br i1 %t103, label %bb28, label %bb29
bb28:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32 }, ptr %t106, i32 0, i32 0
  %t108 = load %"compiler/source:Span", ptr %t107
  store %"compiler/source:Span" %t108, ptr %l10
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32 }, ptr %t112, i32 0, i32 1
  %t114 = load i32, ptr %t113
  store i32 %t114, ptr %l11, !tbaa !23
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t116 = load i32, ptr %l11, !tbaa !23
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t122 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t118, i32 %t116)
  store i1 %t122, ptr %l76
  br label %bb31
bb31:
  %t123 = load i1, ptr %l76, !tbaa !21
  %t124 = xor i1 %t123, true
  br i1 %t124, label %bb32, label %bb33
bb32:
  %t126 = load ptr, ptr %l2, !tbaa !29
  %t127 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t126, i32 %t127)
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l11, !tbaa !23
  %t132 = load %"compiler/source:Span", ptr %l10
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %t130, i32 %t131, %"compiler/source:Span" %t132, i1 true)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb91
bb37:
  %t136 = load ptr, ptr %l1, !tbaa !29
  store ptr %t136, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t137 = load ptr, ptr %l83, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb38, label %bb39
bb38:
  %t140 = load ptr, ptr %l83, !tbaa !29
  %t141 = load i64, ptr %t140, !range !{i64 0, i64 9}
  %t143 = icmp eq i64 %t141, 5
  store i1 %t143, ptr %l84, !tbaa !21
  br label %bb39
bb39:
  %t144 = load i1, ptr %l84, !tbaa !21
  br i1 %t144, label %bb40, label %bb41
bb40:
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t147, i32 0, i32 1
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l13, !tbaa !29
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t153, i32 0, i32 2
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l14, !tbaa !23
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t159, i32 0, i32 3
  %t161 = load %"compiler/source:Span", ptr %t160
  store %"compiler/source:Span" %t161, ptr %l15
  br label %bb42
bb41:
  br label %bb55
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  br label %bb43
bb43:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l14, !tbaa !23
  %t172 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t168, i32 %t169)
  store { i64, ptr } %t172, ptr %l98
  br label %bb44
bb44:
  %t173 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t174 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t173, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t174, ptr %l99
  br label %bb45
bb45:
  %t175 = load i1, ptr %l99, !tbaa !21
  %t176 = xor i1 %t175, true
  br i1 %t176, label %bb46, label %bb47
bb46:
  %t178 = load i32, ptr %l14, !tbaa !23
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t184 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t180, i32 %t178)
  store i1 %t184, ptr %l105
  br label %bb48
bb47:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb49
bb48:
  %t185 = load i1, ptr %l105, !tbaa !21
  %t186 = xor i1 %t185, true
  store i1 %t186, ptr %l101, !tbaa !21
  br label %bb49
bb49:
  %t188 = load i1, ptr %l101, !tbaa !21
  br i1 %t188, label %bb50, label %bb51
bb50:
  %t189 = load ptr, ptr %l2, !tbaa !29
  %t190 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t189, i32 %t190)
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i32, ptr %l14, !tbaa !23
  %t195 = load %"compiler/source:Span", ptr %l15
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %t193, i32 %t194, %"compiler/source:Span" %t195, i1 true)
  br label %bb53
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb91
bb55:
  %t199 = load ptr, ptr %l1, !tbaa !29
  store ptr %t199, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t200 = load ptr, ptr %l112, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb56, label %bb57
bb56:
  %t203 = load ptr, ptr %l112, !tbaa !29
  %t204 = load i64, ptr %t203, !range !{i64 0, i64 9}
  %t206 = icmp eq i64 %t204, 6
  store i1 %t206, ptr %l113, !tbaa !21
  br label %bb57
bb57:
  %t207 = load i1, ptr %l113, !tbaa !21
  br i1 %t207, label %bb58, label %bb59
bb58:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t210, i32 0, i32 1
  %t212 = load ptr, ptr %t211
  store ptr %t212, ptr %l17, !tbaa !29
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t216 = getelementptr { i64, [4 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t216, i32 0, i32 2
  %t218 = load { i64, ptr }, ptr %t217
  store { i64, ptr } %t218, ptr %l18, !tbaa !27
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l17, !tbaa !29
  %t222 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t223 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eelemsPattern(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t220, ptr %t221, { i64, ptr } %t222, ptr %t223)
  br label %bb61
bb61:
  br label %bb91
bb62:
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t229 = load ptr, ptr %l124, !tbaa !29
  %t230 = icmp ne ptr %t229, null
  br i1 %t230, label %bb63, label %bb64
bb63:
  %t232 = load ptr, ptr %l124, !tbaa !29
  %t233 = load i64, ptr %t232, !range !{i64 0, i64 9}
  %t235 = icmp eq i64 %t233, 8
  store i1 %t235, ptr %l125, !tbaa !21
  br label %bb64
bb64:
  %t236 = load i1, ptr %l125, !tbaa !21
  br i1 %t236, label %bb65, label %bb66
bb65:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t239, i32 0, i32 2
  %t241 = load ptr, ptr %t240
  store ptr %t241, ptr %l19, !tbaa !29
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l19, !tbaa !29
  %t245 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %t243, ptr %t244, ptr %t245)
  br label %bb68
bb68:
  br label %bb91
bb69:
  %t249 = load ptr, ptr %l1, !tbaa !29
  store ptr %t249, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t250 = load ptr, ptr %l133, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb70, label %bb71
bb70:
  %t253 = load ptr, ptr %l133, !tbaa !29
  %t254 = load i64, ptr %t253, !range !{i64 0, i64 9}
  %t256 = icmp eq i64 %t254, 7
  store i1 %t256, ptr %l134, !tbaa !21
  br label %bb71
bb71:
  %t257 = load i1, ptr %l134, !tbaa !21
  br i1 %t257, label %bb72, label %bb73
bb72:
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i32 }, ptr %t260, i32 0, i32 0
  %t262 = load %"compiler/source:Span", ptr %t261
  store %"compiler/source:Span" %t262, ptr %l20
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [4 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", i32 }, ptr %t266, i32 0, i32 1
  %t268 = load i32, ptr %t267
  store i32 %t268, ptr %l21, !tbaa !23
  br label %bb74
bb73:
  br label %bb86
bb74:
  store %olang.scope zeroinitializer, ptr %s12
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load i32, ptr %l21, !tbaa !23
  %t274 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t270, i32 %t271)
  store { i64, ptr } %t274, ptr %l143
  br label %bb75
bb75:
  %t275 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t276 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s12, { i64, ptr } %t275, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t276, ptr %l144
  br label %bb76
bb76:
  %t277 = load i1, ptr %l144, !tbaa !21
  %t278 = xor i1 %t277, true
  br i1 %t278, label %bb77, label %bb78
bb77:
  %t280 = load i32, ptr %l21, !tbaa !23
  %t282 = load ptr, ptr %l2, !tbaa !29
  %t286 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t282, i32 %t280)
  store i1 %t286, ptr %l150
  br label %bb79
bb78:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb80
bb79:
  %t287 = load i1, ptr %l150, !tbaa !21
  %t288 = xor i1 %t287, true
  store i1 %t288, ptr %l146, !tbaa !21
  br label %bb80
bb80:
  %t290 = load i1, ptr %l146, !tbaa !21
  br i1 %t290, label %bb81, label %bb82
bb81:
  %t291 = load ptr, ptr %l2, !tbaa !29
  %t292 = load i32, ptr %l21, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t291, i32 %t292)
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load i32, ptr %l21, !tbaa !23
  %t297 = load %"compiler/source:Span", ptr %l20
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %t295, i32 %t296, %"compiler/source:Span" %t297, i1 true)
  br label %bb84
bb84:
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s12)
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_e5a1f3e08188ecc4_85420485b9e83138)
  unreachable
bb91:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epayloadEnum(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %lp6 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca i32
  %l30 = alloca %"compiler/ast:TypeDecl"
  %l34 = alloca ptr
  %l39 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i32
  %l45 = alloca i64
  %l47 = alloca ptr
  %l52 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %t40 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t2 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_20, 0
  %t3 = insertvalue { ptr, ptr } %t2, ptr null, 1
  %t6 = extractvalue { ptr, ptr } %t3, 0
  %t7 = extractvalue { ptr, ptr } %t3, 1
  %t8 = call i1 @std_2fprelude_2farray_2eArray_3ccompiler_2fast_3aCaseDecl_26_3e_2eSome_3ccompiler_2fast_3aCaseDecl_26_2c_20_3f_3e(ptr %v1, ptr %s0, { i64, ptr } %t1, ptr %t6, ptr %t7)
  store i1 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i1, ptr %l11, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/names:Resolver", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/load:Loader", ptr %t15, i32 0, i32 3
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l15, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t23 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t19, i32 %a3)
  store { i64, ptr } %t23, ptr %l18
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t25 = call { i64, ptr } @compiler_2fnames_2ePayloadName(ptr %v0, ptr %s0, { i64, ptr } %t24)
  store { i64, ptr } %t25, ptr %l19
  br label %bb6
bb6:
  %t26 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t29 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t27, { i64, ptr } %t26)
  store i32 %t29, ptr %l21
  br label %bb7
bb7:
  %t30 = load i32, ptr %l21, !tbaa !23
  store i32 %t30, ptr %l5, !tbaa !23
  %t31 = load i32, ptr %l5, !tbaa !23
  store i32 %t31, ptr %l22, !tbaa !23
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = icmp sle i64 0, 1152921504606846975
  br i1 %t34, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e812c7da9410078c_45e3614fe5b58650)
  unreachable
bb10:
  %t36 = mul i64 0, 8
  %t37 = insertvalue { i64, ptr } undef, i64 0, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [6 x i64] }, ptr %t40, i32 0, i32 0
  store i64 1, ptr %t41
  %t43 = insertvalue { { i64, ptr }, ptr } undef, { i64, ptr } %t39, 0
  %t44 = insertvalue { { i64, ptr }, ptr } %t43, ptr null, 1
  %t45 = getelementptr { i64, [6 x i64] }, ptr %t40, i32 0, i32 1
  store { { i64, ptr }, ptr } %t44, ptr %t45
  %t46 = load { i64, [6 x i64] }, ptr %t40
  %t48 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t46, ptr %t48
  %t49 = load i32, ptr %l22, !tbaa !23
  %t53 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, i32 %t49, { i64, ptr } %t38, i1 false, ptr %t48, i32 0, i1 false, ptr null, i32 0)
  store %"compiler/ast:TypeDecl" %t53, ptr %l30
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_e812c7da9410078c_45e3614fe5b58650)
  unreachable
bb12:
  %t54 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store ptr %t54, ptr %lp6
  %t55 = load %"compiler/ast:TypeDecl", ptr %l30
  %t56 = load ptr, ptr %lp6
  store %"compiler/ast:TypeDecl" %t55, ptr %t56
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/names:Resolver", ptr %t57, i32 0, i32 1
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t59, i64 %a1)
  store ptr %t63, ptr %l34
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l34, !tbaa !29
  store ptr %t64, ptr %l7, !tbaa !29
  %t65 = load i32, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = getelementptr %"compiler/names:Table", ptr %t67, i32 0, i32 2
  %t73 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t69, i32 %t65)
  store i1 %t73, ptr %l39
  br label %bb14
bb14:
  %t74 = load i1, ptr %l39, !tbaa !21
  br i1 %t74, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  br label %bb17
bb17:
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t77 = getelementptr %"compiler/names:Table", ptr %t75, i32 0, i32 2
  store ptr %t77, ptr %l41, !tbaa !29
  %t78 = load i32, ptr %l5, !tbaa !23
  store i32 %t78, ptr %l42, !tbaa !23
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t81 = getelementptr %"compiler/names:Table", ptr %t79, i32 0, i32 0
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l45
  br label %bb18
bb18:
  %t84 = load ptr, ptr %l41, !tbaa !29
  %t85 = load i32, ptr %l42, !tbaa !23
  %t86 = load i64, ptr %l45, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t84, i32 %t85, i64 %t86)
  br label %bb19
bb19:
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = getelementptr %"compiler/names:Table", ptr %t87, i32 0, i32 0
  store ptr %t89, ptr %l47, !tbaa !29
  %t90 = load i32, ptr %l5, !tbaa !23
  %t92 = load ptr, ptr %lp6
  %t97 = call %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v0, ptr %v0, i32 %t90, %"compiler/source:Span" %a2, i32 4, i1 false, ptr %t92)
  store %"compiler/names:Entry" %t97, ptr %l52
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l47, !tbaa !29
  %t99 = load %"compiler/names:Entry", ptr %l52
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t98, %"compiler/names:Entry" %t99)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopSig(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 23
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/names:Resolver", ptr %t8, i32 0, i32 26
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l8
  br label %bb3
bb3:
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = icmp eq i64 %t13, 0
  store i1 %t14, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l5, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/names:Resolver", ptr %t17, i32 0, i32 26
  %t21 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t19)
  %t22 = extractvalue { i32, i64 } %t21, 1
  %t23 = extractvalue { i32, i64 } %t21, 0
  store i32 %t23, ptr %l14
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb9, label %ok.25, !prof !99
ok.25:
  store i64 %t22, ptr %l13
  br label %bb8
bb8:
  %t26 = load i64, ptr %l13, !tbaa !24
  store i64 %t26, ptr %l10, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  br label %ret
bb11:
  %t27 = load i64, ptr %l10, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/names:Resolver", ptr %t28, i32 0, i32 25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t30, i64 %t27)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l5 = alloca i64
  %l9 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l12 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l26 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 10
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb2
bb2:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, %a1
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/names:Resolver", ptr %t13, i32 0, i32 10
  %t17 = call { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__He0d1b669a6d0fad4ef2d0863356e160c(ptr %v0, ptr %t15)
  %t18 = extractvalue { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } %t17, 1
  %t19 = extractvalue { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } %t17, 0
  store i32 %t19, ptr %l13
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb7, label %ok.21, !prof !99
ok.21:
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t18, ptr %l12
  br label %bb6
bb6:
  %t22 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l12
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t22, ptr %l9
  br label %bb9
bb7:
  br label %bb8
bb8:
  br label %ret
bb9:
  %t23 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l9
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t23, ptr %l2
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/names:Resolver", ptr %t25, i32 0, i32 9
  %t28 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t32 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t27, i32 %t29)
  %t33 = extractvalue { i32, i64 } %t32, 1
  %t34 = extractvalue { i32, i64 } %t32, 0
  store i32 %t34, ptr %l20
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb11, label %ok.36, !prof !99
ok.36:
  store i64 %t33, ptr %l19
  br label %bb10
bb10:
  %t37 = load i64, ptr %l19, !tbaa !24
  store i64 %t37, ptr %l15, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  store i64 -1, ptr %l15, !tbaa !24
  br label %bb13
bb13:
  %t38 = load ptr, ptr %l14, !tbaa !29
  %t39 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ejudge(ptr %v0, ptr %t38, i64 %t39)
  br label %bb14
bb14:
  %t40 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/names:Resolver", ptr %t45, i32 0, i32 9
  %t48 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 0
  %t49 = load i32, ptr %t48, !tbaa !23
  %t52 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H7068c8717e9d582db2941dd2bdd79d55(ptr %v0, ptr %t47, i32 %t49)
  store i1 %t52, ptr %l26
  br label %bb17
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/names:Resolver", ptr %t53, i32 0, i32 9
  %t56 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t58 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t55, i32 %t57, i64 %t59)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb1
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epreludeTaken(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca %"compiler/diagmsg:Msg"
  %l5 = alloca %"compiler/names:Ref"
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca i32
  %l12 = alloca %"compiler/names:Ref"
  %l15 = alloca %"compiler/diagmsg:Msg"
  %l18 = alloca { i64, ptr }
  %l20 = alloca %"compiler/diagmsg:Msg"
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/diagmsg:Msg"
  %l28 = alloca ptr
  %l32 = alloca { i64, [3 x i64] }
  %l34 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 3
  %t4 = load i32, ptr %l2, !tbaa !23
  %t7 = call { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H678d1b43e8b98a171ffdea8f28643d28(ptr %v0, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, %"compiler/names:Ref" } %t7, 1
  %t9 = extractvalue { i32, %"compiler/names:Ref" } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store %"compiler/names:Ref" %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load %"compiler/names:Ref", ptr %l9
  store %"compiler/names:Ref" %t12, ptr %l5
  br label %bb5
bb2:
  br label %bb3
bb3:
  %t14 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t14, ptr %l12
  br label %bb4
bb4:
  %t15 = load %"compiler/names:Ref", ptr %l12
  store %"compiler/names:Ref" %t15, ptr %l5
  br label %bb5
bb5:
  %t16 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t17 = load i32, ptr %t16, !range !{i32 0, i32 9}
  %t19 = trunc i64 3 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l18
  br label %bb8
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t27, i32 %t28)
  store { i64, ptr } %t31, ptr %l23
  br label %bb10
bb8:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePreludeFuncRedeclared(ptr %s0, ptr %v0, { i64, ptr } %t32)
  store %"compiler/diagmsg:Msg" %t34, ptr %l20
  br label %bb9
bb9:
  %t35 = load %"compiler/diagmsg:Msg", ptr %l20
  store %"compiler/diagmsg:Msg" %t35, ptr %l15
  br label %bb12
bb10:
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t38 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePreludeConstRedeclared(ptr %s0, ptr %v0, { i64, ptr } %t36)
  store %"compiler/diagmsg:Msg" %t38, ptr %l25
  br label %bb11
bb11:
  %t39 = load %"compiler/diagmsg:Msg", ptr %l25
  store %"compiler/diagmsg:Msg" %t39, ptr %l15
  br label %bb12
bb12:
  %t40 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t40, ptr %l4
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/names:Resolver", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 4
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l28, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t54 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t48, i64 %a1, %"compiler/source:Span" %a3)
  store { i64, [3 x i64] } %t54, ptr %l32
  br label %bb13
bb13:
  %t55 = load %"compiler/diagmsg:Msg", ptr %l4
  %t56 = load ptr, ptr %l28, !tbaa !29
  %t57 = load { i64, [3 x i64] }, ptr %l32
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t56, { i64, [3 x i64] } %t57, %"compiler/diagmsg:Msg" %t55)
  store i64 %t59, ptr %l34
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epushSig(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i64
  %l22 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 23
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/names:Resolver", ptr %t8, i32 0, i32 26
  store ptr %t10, ptr %l10, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/names:Resolver", ptr %t11, i32 0, i32 25
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l10, !tbaa !29
  %t17 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t16, i64 %t17)
  br label %bb5
bb5:
  %t20 = getelementptr %"compiler/ast:Sig", ptr %a1, i32 0, i32 3
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l22, !tbaa !27
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 %t36
  %t41 = load ptr, ptr %t40, !tbaa !39
  store ptr %t41, ptr %l5, !tbaa !29
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Path", ptr %t43, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t50 = icmp eq i64 %t48, 1
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/names:Resolver", ptr %t52, i32 0, i32 25
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Path", ptr %t55, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l32, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 0
  %t62 = load i32, ptr %t61, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t54, i32 %t62)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t68 = add i64 %t65, 1
  store i64 %t68, ptr %l3, !tbaa !24
  br label %bb6
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eread(ptr %v0, ptr %a0, %"compiler/names:Ref" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/names:Ref"
  %l2 = alloca %"compiler/names:local"
  %l6 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i64
  %l13 = alloca i64
  %l18 = alloca %"compiler/names:local"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l28 = alloca %"compiler/names:local"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/names:Ref" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/names:Ref", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 9}
  %t4 = trunc i64 1 to i32
  %t5 = icmp eq i32 %t2, %t4
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t9 = getelementptr %"compiler/names:Ref", ptr %l1, i32 0, i32 2
  %t10 = load i64, ptr %t9, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb5:
  %t15 = getelementptr %"compiler/names:Ref", ptr %l1, i32 0, i32 2
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l10, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/names:Resolver", ptr %t17, i32 0, i32 8
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = load i64, ptr %l13, !tbaa !24
  %t24 = icmp sge i64 %t22, %t23
  store i1 %t24, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l9, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 8
  %t30 = getelementptr %"compiler/names:Ref", ptr %l1, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t34 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t29, i64 %t31)
  store %"compiler/names:local" %t34, ptr %l18
  br label %bb11
bb11:
  %t35 = load %"compiler/names:local", ptr %l18
  store %"compiler/names:local" %t35, ptr %l2
  %t36 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 5
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/names:Resolver", ptr %t39, i32 0, i32 8
  store ptr %t41, ptr %l21, !tbaa !29
  %t42 = getelementptr %"compiler/names:Ref", ptr %l1, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l22, !tbaa !24
  %t44 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 1
  %t47 = load %"compiler/source:Span", ptr %t46
  %t48 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 2
  %t49 = load i32, ptr %t48, !range !{i32 0, i32 9}
  %t50 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 3
  %t51 = load i1, ptr %t50, !tbaa !21
  %t52 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 4
  %t53 = load i1, ptr %t52, !tbaa !21
  %t59 = call %"compiler/names:local" @compiler_2fnames_3alocal_2ector(ptr %s0, i32 %t45, %"compiler/source:Span" %t47, i32 %t49, i1 %t51, i1 %t53, i1 true)
  store %"compiler/names:local" %t59, ptr %l28
  br label %bb15
bb15:
  %t60 = load ptr, ptr %l21, !tbaa !29
  %t61 = load i64, ptr %l22, !tbaa !24
  %t62 = load %"compiler/names:local", ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eSetAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t60, i64 %t61, %"compiler/names:local" %t62)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l23 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i1
  %l52 = alloca i1
  %l58 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  store ptr %t36, ptr %l6, !tbaa !29
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Path", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 1
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Path", ptr %t48, i32 0, i32 0
  %t51 = load %"compiler/source:Span", ptr %t50
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = getelementptr %"compiler/ast:Path", ptr %t52, i32 0, i32 1
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l34, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i32, ptr %t57, i64 0
  %t59 = load i32, ptr %t58, !tbaa !33
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eintroduceVar(ptr %v0, ptr %t47, %"compiler/source:Span" %t51, i32 %t59)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = add i64 %t63, 1
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb6
bb15:
  br label %bb34
bb16:
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t69 = load ptr, ptr %l39, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb17, label %bb18
bb17:
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 8}
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t76 = load i1, ptr %l40, !tbaa !21
  br i1 %t76, label %bb19, label %bb20
bb19:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t79, i32 0, i32 0
  %t81 = load %"compiler/source:Span", ptr %t80
  store %"compiler/source:Span" %t81, ptr %l7
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t85, i32 0, i32 1
  %t87 = load { i64, ptr }, ptr %t86
  store { i64, ptr } %t87, ptr %l8, !tbaa !27
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t91, i32 0, i32 2
  %t93 = load { i64, ptr }, ptr %t92
  store { i64, ptr } %t93, ptr %l9, !tbaa !27
  br label %bb21
bb20:
  br label %bb28
bb21:
  %t95 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = icmp eq i64 %t97, 1
  br i1 %t99, label %bb22, label %bb23
bb22:
  %t101 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t105 = icmp eq i64 %t103, 0
  store i1 %t105, ptr %l52, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb24
bb24:
  %t107 = load i1, ptr %l52, !tbaa !21
  br i1 %t107, label %bb25, label %bb26
bb25:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l7
  %t110 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t110, ptr %l58, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i32, ptr %t112, i64 0
  %t114 = load i32, ptr %t113, !tbaa !33
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eintroduceVar(ptr %v0, ptr %t108, %"compiler/source:Span" %t109, i32 %t114)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb34
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t118, ptr %t119, i1 true)
  br label %bb32
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_248dea6bbb4b10fb_e7c6566d75989db7)
  unreachable
bb34:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l25 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t6 = load ptr, ptr %l12, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l12, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l13, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t16, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  br label %bb8
bb7:
  br label %bb16
bb8:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %l25, !tbaa !27
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t35
  %t40 = load ptr, ptr %t39, !tbaa !39
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverArg(ptr %v0, ptr %v1, ptr %t42, ptr %t40)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t46, 1
  store i64 %t49, ptr %l5, !tbaa !24
  br label %bb9
bb15:
  br label %bb35
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t52 = load ptr, ptr %l33, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l33, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 8}
  %t58 = icmp eq i64 %t56, 3
  store i1 %t58, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t59 = load i1, ptr %l34, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l8, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l8, !tbaa !29
  %t69 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t66, ptr %t67, i1 %t69)
  br label %bb22
bb22:
  br label %bb35
bb23:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t74 = load ptr, ptr %l43, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t77 = load ptr, ptr %l43, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 8}
  %t80 = icmp eq i64 %t78, 4
  store i1 %t80, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t81 = load i1, ptr %l44, !tbaa !21
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t84, i32 0, i32 1
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l9, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l9, !tbaa !29
  %t90 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t88, ptr %t89, i1 %t90)
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_1bcb50306faa07e3_18a30ea25b6c39c7)
  unreachable
bb35:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/names:Ref" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/names:Ref"
  %l6 = alloca i1
  %l11 = alloca ptr
  %l17 = alloca ptr
  %l21 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/names:Ref" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 9}
  %t4 = trunc i64 0 to i32
  %t5 = icmp eq i32 %t2, %t4
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 23
  %t12 = load i1, ptr %t11, !tbaa !21
  %t14 = xor i1 %t12, true
  store i1 %t14, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l6, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/names:Resolver", ptr %t17, i32 0, i32 4
  store ptr %t19, ptr %l11, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/names:Resolver", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/load:Loader", ptr %t23, i32 0, i32 10
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/names:Resolver", ptr %t26, i32 0, i32 7
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t25, i64 %t29)
  store ptr %t32, ptr %l17
  br label %bb6
bb5:
  br label %bb9
bb6:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t35 = getelementptr %"compiler/load:Module", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  %t41 = call i64 @compiler_2fnames_2ekey(i64 %t36, i32 %t38)
  store i64 %t41, ptr %l21
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l2
  %t43 = load ptr, ptr %l11, !tbaa !29
  %t44 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t43, i64 %t44, %"compiler/names:Ref" %t42)
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esharedType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i64
  %l19 = alloca %"compiler/names:Ref"
  %l20 = alloca i64
  %l22 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i32
  %l31 = alloca %"compiler/names:Ref"
  %l32 = alloca i32
  %l33 = alloca i64
  %l34 = alloca i64
  %l38 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca i32
  %l44 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l9, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/load:Module", ptr %t12, i32 0, i32 33
  %t15 = load i1, ptr %t14, !tbaa !21
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/load:Module", ptr %t19, i32 0, i32 37
  %t23 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He890afa3b14bd52c6ea464bca4cef525(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l16
  br label %bb4
bb4:
  %t24 = load i64, ptr %l16, !tbaa !24
  %t25 = icmp eq i64 %t24, 0
  store i1 %t25, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t29 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s1, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t29, ptr %l19
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t30 = load %"compiler/names:Ref", ptr %l19
  store %"compiler/names:Ref" %t30, ptr %rv
  br label %ret
bb9:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/load:Module", ptr %t31, i32 0, i32 37
  store ptr %t33, ptr %l22, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t34, i32 %t35)
  store { i64, ptr } %t38, ptr %l25
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t41 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t39, { i64, ptr } %t40)
  %t42 = extractvalue { i32, i64 } %t41, 1
  %t43 = extractvalue { i32, i64 } %t41, 0
  store i32 %t43, ptr %l27
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb12, label %ok.45, !prof !99
ok.45:
  store i64 %t42, ptr %l26
  br label %bb11
bb11:
  %t46 = load i64, ptr %l26, !tbaa !24
  store i64 %t46, ptr %l20, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb14
bb14:
  %t47 = load i64, ptr %l20, !tbaa !24
  store i64 %t47, ptr %l4, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp slt i64 %t48, 0
  br i1 %t50, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t53, ptr %l31
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t54 = load %"compiler/names:Ref", ptr %l31
  store %"compiler/names:Ref" %t54, ptr %rv
  br label %ret
bb18:
  store i32 4, ptr %l32
  %t55 = load i64, ptr %l4, !tbaa !24
  store i64 %t55, ptr %l33, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/names:Resolver", ptr %t56, i32 0, i32 1
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t58, i64 %t59)
  store ptr %t62, ptr %l38
  br label %bb19
bb19:
  %t63 = load ptr, ptr %l38, !tbaa !29
  %t65 = getelementptr %"compiler/names:Table", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l2, !tbaa !23
  %t69 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t65, i32 %t66)
  %t70 = extractvalue { i32, i64 } %t69, 1
  %t71 = extractvalue { i32, i64 } %t69, 0
  store i32 %t71, ptr %l43
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb21, label %ok.73, !prof !99
ok.73:
  store i64 %t70, ptr %l42
  br label %bb20
bb20:
  %t74 = load i64, ptr %l42, !tbaa !24
  store i64 %t74, ptr %l34, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l34, !tbaa !24
  br label %bb23
bb23:
  %t75 = load i32, ptr %l32, !range !{i32 0, i32 9}
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = load i64, ptr %l34, !tbaa !24
  %t78 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 %t75, i64 %t76, i64 %t77)
  store %"compiler/names:Ref" %t78, ptr %l44
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t79 = load %"compiler/names:Ref", ptr %l44
  store %"compiler/names:Ref" %t79, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l17 = alloca %"compiler/names:Ref"
  %l23 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l36 = alloca ptr
  %l42 = alloca ptr
  %l46 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l47 = alloca ptr
  %l48 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t22, i32 %t23)
  store %"compiler/names:Ref" %t26, ptr %l17
  br label %bb6
bb6:
  %t27 = load %"compiler/names:Ref", ptr %l17
  store %"compiler/names:Ref" %t27, ptr %l4
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l2
  %t30 = load %"compiler/names:Ref", ptr %l4
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t28, %"compiler/source:Span" %t29, %"compiler/names:Ref" %t30)
  br label %bb7
bb7:
  %t34 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 9}
  %t37 = trunc i64 1 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 27
  %t43 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t44 = load i64, ptr %t43, !tbaa !24
  %t47 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t42, i64 %t44)
  store i1 %t47, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb11
bb10:
  %t48 = load i1, ptr %l27, !tbaa !21
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/names:Resolver", ptr %t50, i32 0, i32 27
  %t53 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t54 = load i64, ptr %t53, !tbaa !24
  %t57 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t52, i64 %t54)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l33
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb15, label %ok.61, !prof !99
ok.61:
  store i64 %t58, ptr %l32
  br label %bb14
bb13:
  br label %bb21
bb14:
  %t62 = load i64, ptr %l32, !tbaa !24
  store i64 %t62, ptr %l28, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb17
bb17:
  %t63 = load i64, ptr %l28, !tbaa !24
  store i64 %t63, ptr %l5, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/names:Resolver", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/load:Loader", ptr %t67, i32 0, i32 5
  store ptr %t69, ptr %l36, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/names:Resolver", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/load:Loader", ptr %t73, i32 0, i32 10
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/names:Resolver", ptr %t76, i32 0, i32 7
  %t79 = load i64, ptr %t78, !tbaa !24
  %t82 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t75, i64 %t79)
  store ptr %t82, ptr %l42
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l42, !tbaa !29
  %t85 = getelementptr %"compiler/load:Module", ptr %t83, i32 0, i32 4
  %t86 = load i64, ptr %t85, !tbaa !24
  %t87 = load i64, ptr %l5, !tbaa !24
  %t90 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t86, i64 %t87)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t90, ptr %l46
  br label %bb19
bb19:
  %t91 = load ptr, ptr %l36, !tbaa !29
  %t92 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l46
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t91, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t92, i1 true)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb35
bb22:
  %t93 = load ptr, ptr %l1, !tbaa !29
  store ptr %t93, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t94 = load ptr, ptr %l47, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t97 = load ptr, ptr %l47, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 28}
  %t100 = icmp eq i64 %t98, 2
  store i1 %t100, ptr %l48, !tbaa !21
  br label %bb24
bb24:
  %t101 = load i1, ptr %l48, !tbaa !21
  br i1 %t101, label %bb25, label %bb26
bb25:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr }, ptr %t104, i32 0, i32 1
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l6, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %t108, ptr %t109)
  br label %bb28
bb28:
  br label %bb35
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t112, ptr %t113)
  br label %bb33
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_c883e3bd313e2585_b0aaf26ba1585cf1)
  unreachable
bb35:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %t7, i32 %a1)
  store { i64, ptr } %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %l21 = alloca %"compiler/names:Ref"
  %l25 = alloca %"compiler/names:Ref"
  %l30 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %l40 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca %"compiler/names:Ref"
  %l53 = alloca { i64, ptr }
  %l54 = alloca i1
  %l56 = alloca %"compiler/names:Ref"
  %l58 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t10 = getelementptr %"compiler/names:Table", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t10, i32 %t11)
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l15
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18, !prof !99
ok.18:
  store i64 %t15, ptr %l14
  br label %bb2
bb2:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l6, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l6, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load i64, ptr %l1, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t30 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s1, i32 4, i64 %t25, i64 %t26)
  store %"compiler/names:Ref" %t30, ptr %l21
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/names:Ref", ptr %l21
  store %"compiler/names:Ref" %t31, ptr %rv
  br label %ret
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i32, ptr %l2, !tbaa !23
  %t38 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esharedType(ptr %v0, ptr %t32, i64 %t33, i32 %t34)
  store %"compiler/names:Ref" %t38, ptr %l25
  br label %bb10
bb10:
  %t39 = load %"compiler/names:Ref", ptr %l25
  store %"compiler/names:Ref" %t39, ptr %l4
  %t40 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t41 = load i32, ptr %t40, !range !{i32 0, i32 9}
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load %"compiler/names:Ref", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/names:Ref" %t48, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/names:Resolver", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l2, !tbaa !23
  %t56 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t52, i32 %t53)
  %t57 = extractvalue { i32, i64 } %t56, 1
  %t58 = extractvalue { i32, i64 } %t56, 0
  store i32 %t58, ptr %l35
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb15, label %ok.60, !prof !99
ok.60:
  store i64 %t57, ptr %l34
  br label %bb14
bb14:
  %t61 = load i64, ptr %l34, !tbaa !24
  store i64 %t61, ptr %l30, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  store i64 -1, ptr %l30, !tbaa !24
  br label %bb17
bb17:
  %t62 = load i64, ptr %l30, !tbaa !24
  store i64 %t62, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = icmp sge i64 %t63, 0
  br i1 %t65, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 4, ptr %l38
  %t67 = load i64, ptr %l5, !tbaa !24
  store i64 %t67, ptr %l39, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/names:Resolver", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t70, i64 %t71)
  store ptr %t74, ptr %l44
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t75 = load ptr, ptr %l44, !tbaa !29
  %t77 = getelementptr %"compiler/names:Table", ptr %t75, i32 0, i32 2
  %t78 = load i32, ptr %l2, !tbaa !23
  %t81 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t77, i32 %t78)
  %t82 = extractvalue { i32, i64 } %t81, 1
  %t83 = extractvalue { i32, i64 } %t81, 0
  store i32 %t83, ptr %l49
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb22, label %ok.85, !prof !99
ok.85:
  store i64 %t82, ptr %l48
  br label %bb21
bb21:
  %t86 = load i64, ptr %l48, !tbaa !24
  store i64 %t86, ptr %l40, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  store i64 -1, ptr %l40, !tbaa !24
  br label %bb24
bb24:
  %t87 = load i32, ptr %l38, !range !{i32 0, i32 9}
  %t88 = load i64, ptr %l39, !tbaa !24
  %t89 = load i64, ptr %l40, !tbaa !24
  %t90 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s3, i32 %t87, i64 %t88, i64 %t89)
  store %"compiler/names:Ref" %t90, ptr %l50
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t91 = load %"compiler/names:Ref", ptr %l50
  store %"compiler/names:Ref" %t91, ptr %rv
  br label %ret
bb26:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  %t96 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t92, i32 %t93)
  store { i64, ptr } %t96, ptr %l53
  br label %bb27
bb27:
  %t97 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t98 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t97)
  store i1 %t98, ptr %l54
  br label %bb28
bb28:
  %t99 = load i1, ptr %l54, !tbaa !21
  br i1 %t99, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s4, i32 7, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t101, ptr %l56
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t102 = load %"compiler/names:Ref", ptr %l56
  store %"compiler/names:Ref" %t102, ptr %rv
  br label %ret
bb32:
  %t104 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t104, ptr %l58
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t105 = load %"compiler/names:Ref", ptr %l58
  store %"compiler/names:Ref" %t105, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeParams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l25 = alloca { i64, ptr }
  %l35 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l45 = alloca i64
  %l48 = alloca i64
  %l50 = alloca %"compiler/names:Ref"
  %l61 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l25, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 7
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeParam", ptr %t34, i32 0, i32 0
  %t37 = getelementptr %"compiler/source:Span", ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr %"compiler/ast:TypeParam", ptr %t39, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t47 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t29, i64 %t33, i32 %t38, i32 %t42)
  store %"compiler/source:Span" %t47, ptr %l35
  br label %bb8
bb8:
  %t48 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t48, ptr %l6
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = getelementptr %"compiler/ast:TypeParam", ptr %t50, i32 0, i32 1
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t49, i32 %t53, %"compiler/source:Span" %t54, i32 8)
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t60, ptr %l42
  store i32 8, ptr %l43
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/names:Resolver", ptr %t61, i32 0, i32 7
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l45, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/names:Resolver", ptr %t65, i32 0, i32 8
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t67)
  store i64 %t69, ptr %l48
  br label %bb10
bb10:
  %t70 = load i64, ptr %l48, !tbaa !24
  %t71 = sub i64 %t70, 1
  %t72 = load i32, ptr %l43, !range !{i32 0, i32 9}
  %t73 = load i64, ptr %l45, !tbaa !24
  %t75 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s3, i32 %t72, i64 %t73, i64 %t71)
  store %"compiler/names:Ref" %t75, ptr %l50
  br label %bb11
bb11:
  %t76 = load ptr, ptr %l41, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l42
  %t78 = load %"compiler/names:Ref", ptr %l50
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t76, %"compiler/source:Span" %t77, %"compiler/names:Ref" %t78)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t79 = load i64, ptr %l3, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l3, !tbaa !24
  br label %bb4
bb14:
  %t84 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t84, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb16, label %bb17
bb16:
  br label %bb28
bb17:
  br label %bb18
bb18:
  %t98 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t98, ptr %l61, !tbaa !27
  %t99 = load i64, ptr %l8, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr ptr, ptr %t102, i64 %t99
  %t104 = load ptr, ptr %t103, !tbaa !39
  store ptr %t104, ptr %l10, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l10, !tbaa !29
  %t109 = getelementptr %"compiler/ast:TypeParam", ptr %t107, i32 0, i32 2
  %t110 = load ptr, ptr %t109, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t106, ptr %t110)
  br label %bb19
bb19:
  %t113 = load ptr, ptr %l10, !tbaa !29
  %t115 = getelementptr %"compiler/ast:TypeParam", ptr %t113, i32 0, i32 3
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  store i64 %t120, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  %t122 = load i64, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l13, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb21, label %bb22
bb21:
  br label %bb26
bb22:
  br label %bb23
bb23:
  %t130 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t130, ptr %l75, !tbaa !27
  %t131 = load i64, ptr %l12, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr ptr, ptr %t134, i64 %t131
  %t136 = load ptr, ptr %t135, !tbaa !39
  %t138 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t138, ptr %t136)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = add i64 %t143, 1
  store i64 %t146, ptr %l12, !tbaa !24
  br label %bb20
bb26:
  br label %bb27
bb27:
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = add i64 %t148, 1
  store i64 %t151, ptr %l8, !tbaa !24
  br label %bb15
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l13 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca { i64, ptr }
  %l27 = alloca i1
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l42 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l54 = alloca ptr
  %l59 = alloca { i64, [3 x i64] }
  %l62 = alloca { i64, ptr }
  %l65 = alloca %"compiler/diagmsg:Msg"
  %l66 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t5, i64 %t9)
  store ptr %t12, ptr %l13
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t15 = getelementptr %"compiler/names:Table", ptr %t13, i32 0, i32 4
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l17
  br label %bb2
bb2:
  %t20 = load i1, ptr %l17, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l20
  br label %bb6
bb6:
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/load:Loader", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = extractvalue { i64, ptr } %t33, 0
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t42 = extractvalue { i64, ptr } %t34, 1
  %t43 = extractvalue { i64, ptr } %t34, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t36, i64 %t37)
  %t49 = getelementptr i8, ptr %t48, i64 %t37
  call void @olang_textcopy(ptr %t49, ptr %t38, i64 %t39)
  %t50 = getelementptr i8, ptr %t49, i64 %t39
  call void @olang_textcopy(ptr %t50, ptr %t42, i64 %t43)
  %t51 = getelementptr i8, ptr %t50, i64 %t43
  call void @olang_textcopy(ptr %t51, ptr %t45, i64 %t46)
  %t52 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t48, 1
  %t56 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t53)
  store i1 %t56, ptr %l27
  br label %bb7
bb7:
  %t57 = load i1, ptr %l27, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/names:Resolver", ptr %t60, i32 0, i32 16
  store ptr %t62, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t64 = load i64, ptr %l6, !tbaa !24
  store i64 %t64, ptr %l31, !tbaa !24
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t65)
  store i64 %t67, ptr %l33
  br label %bb12
bb12:
  %t68 = load i64, ptr %l31, !tbaa !24
  %t69 = load i64, ptr %l33, !tbaa !24
  %t70 = icmp slt i64 %t68, %t69
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb13, label %bb14
bb13:
  br label %bb24
bb14:
  br label %bb15
bb15:
  %t74 = load ptr, ptr %l5, !tbaa !29
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Hd32f6fdf378a1d4c0e47f8552643012d(ptr %v0, ptr %t74, i64 %t75)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t78, ptr %l38
  br label %bb16
bb16:
  %t79 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l38
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t79, ptr %l7
  %t80 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l7, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t82 = load i32, ptr %l2, !tbaa !23
  %t85 = icmp eq i32 %t81, %t82
  br i1 %t85, label %bb17, label %bb18
bb17:
  %t87 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l7, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = icmp eq i64 %t88, -1
  store i1 %t90, ptr %l42, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb19
bb19:
  %t92 = load i1, ptr %l42, !tbaa !21
  br i1 %t92, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = add i64 %t93, 1
  store i64 %t96, ptr %l6, !tbaa !24
  br label %bb11
bb24:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/names:Resolver", ptr %t98, i32 0, i32 16
  store ptr %t100, ptr %l49, !tbaa !29
  %t101 = load i32, ptr %l2, !tbaa !23
  %t103 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s0, i32 %t101, i64 -1)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t103, ptr %l51
  br label %bb25
bb25:
  %t104 = load ptr, ptr %l49, !tbaa !29
  %t105 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l51
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %t104, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t105)
  br label %bb26
bb26:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/names:Resolver", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l54, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/names:Resolver", ptr %t114, i32 0, i32 7
  %t117 = load i64, ptr %t116, !tbaa !24
  %t122 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t113, i64 %t117, %"compiler/source:Span" %a1)
  store { i64, [3 x i64] } %t122, ptr %l59
  br label %bb27
bb27:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l2, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t123, i32 %t124)
  store { i64, ptr } %t127, ptr %l62
  br label %bb28
bb28:
  %t128 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t132 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownImportStd(ptr %s0, ptr %v0, ptr %v0, { i64, ptr } %t128, { i64, ptr } %t129)
  store %"compiler/diagmsg:Msg" %t132, ptr %l65
  br label %bb29
bb29:
  %t133 = load ptr, ptr %l54, !tbaa !29
  %t134 = load { i64, [3 x i64] }, ptr %l59
  %t135 = load %"compiler/diagmsg:Msg", ptr %l65
  %t136 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t133, { i64, [3 x i64] } %t134, %"compiler/diagmsg:Msg" %t135)
  store i64 %t136, ptr %l66
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = getelementptr %"compiler/ast:TopIf", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_c24d94d368b768d0_dc6a7a3b6fd73c94)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TopIf", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitBranch(ptr %v0, ptr %v1, ptr %t14, i64 %t15, ptr %t13)
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TopIf", ptr %t17, i32 0, i32 2
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l14, !tbaa !29
  %t27 = load i64, ptr %l1, !tbaa !24
  store i64 %t27, ptr %l15, !tbaa !24
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TopIf", ptr %t28, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb7, label %bb8
bb6:
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_93653db47984ae2f_98605133537f87a3)
  unreachable
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:TopIf", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load ptr, ptr %l14, !tbaa !29
  %t40 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %t39, i64 %t40, ptr %t38)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/ast:TopIf", ptr %t42, i32 0, i32 3
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l25, !tbaa !29
  %t52 = load i64, ptr %l1, !tbaa !24
  store i64 %t52, ptr %l26, !tbaa !24
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:TopIf", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb14, label %bb15
bb13:
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b66f44eae599aa7e_d468abe9cc136322)
  unreachable
bb15:
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:TopIf", ptr %t60, i32 0, i32 3
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load ptr, ptr %l25, !tbaa !29
  %t65 = load i64, ptr %l26, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitBranch(ptr %v0, ptr %v1, ptr %t64, i64 %t65, ptr %t63)
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fnames_2eidentChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fnames_2eindexOfRaised(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l37 = alloca %"compiler/names:raisedName"
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eLen_H9e36587759e47da85a29e6c0abff1d1c(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i64, ptr %l9, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = call %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %v0, ptr %s2, ptr %t51, i64 %t53)
  store %"compiler/names:raisedName" %t56, ptr %l37
  br label %bb12
bb12:
  %t57 = getelementptr %"compiler/names:raisedName", ptr %l37, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  %t62 = icmp eq i32 %t58, %a1
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t64, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t66, 1
  store i64 %t69, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fnames_2ekey(i64 %a0, i32 %a1) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = shl i64 %a0, 32
  %t6 = sext i32 %a1 to i64
  %t9 = or i64 %t3, %t6
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v0, ptr %v1, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i1 %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/names:Entry"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/names:Entry" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/names:Entry" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/names:Entry" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/names:Entry" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/names:Entry" %t18, ptr %a4, 4
  store %"compiler/names:Entry" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Entry", ptr %rv
  ret %"compiler/names:Entry" %rr
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/names:Ref"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/names:Ref" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/names:Ref" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/names:Ref" %t10, i64 %a2, 2
  store %"compiler/names:Ref" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local %"compiler/names:Unread" @compiler_2fnames_3aUnread_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i32 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/names:Unread"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/names:Unread" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/names:Unread" %t10, %"compiler/source:Span" %a1, 1
  %t14 = insertvalue %"compiler/names:Unread" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/names:Unread" %t14, i1 %a3, 3
  store %"compiler/names:Unread" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Unread", ptr %rv
  ret %"compiler/names:Unread" %rr
}

define dso_local %"compiler/names:local" @compiler_2fnames_3alocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i1 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %rv = alloca %"compiler/names:local"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/names:local" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/names:local" %t14, %"compiler/source:Span" %a1, 1
  %t18 = insertvalue %"compiler/names:local" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/names:local" %t18, i1 %a3, 3
  %t22 = insertvalue %"compiler/names:local" %t20, i1 %a4, 4
  %t24 = insertvalue %"compiler/names:local" %t22, i1 %a5, 5
  store %"compiler/names:local" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:local", ptr %rv
  ret %"compiler/names:local" %rr
}

@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d1 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d7 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d8 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d14 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"$payload" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
define internal i1 @olang_lambda_20(ptr %env, ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:CaseDecl", ptr %a0, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp sgt i64 %t6, 0
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_empty_array = external constant [16 x i64]
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d22 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2eIsIntName(ptr %v0, { i64, ptr } %a0)
@olang_loc_93f58d21316a4d1a_c55e0a424e12d50e = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %a0)
declare %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Hd32f6fdf378a1d4c0e47f8552643012d(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0)
declare %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eG_Hb4f204ca9d50eb43e30fe8770cb15d1a(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNameIsType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/names:Entry" %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %a0, i64 %a1, %"compiler/names:Ref" %a2)
@olang_loc_fd033da614d46a49_c57bfff01eec9785 = external constant [0 x i8]
declare %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %a0, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2ePush_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0, %"compiler/names:local" %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAlreadyDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDeclaredTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoShadow(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eSetAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/names:local" %a2)
@olang_loc_f2d30a85840d12d4_ee21d33ae1ca6100 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInNameExists(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_29838351972cb384_2d79eff554670e58 = external constant [0 x i8]
declare i1 @compiler_2fnames_2eMentions(ptr %v0, ptr %v1, { i64, ptr } %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2ePush_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0, %"compiler/names:Unread" %a1)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_2c32128468766446_22803ecfd3e7a722 = external constant [0 x i8]
@olang_loc_f2fe3b3cf3edda27_d5ea4c4d6e43c823 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNameClashesWithImport(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVarIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e5a1f3e08188ecc4_85420485b9e83138 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3ccompiler_2fast_3aCaseDecl_26_3e_2eSome_3ccompiler_2fast_3aCaseDecl_26_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_e812c7da9410078c_45e3614fe5b58650 = external constant [0 x i8]
declare %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, i32 %a4, i1 %a5, ptr %a6, i32 %a7)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__He0d1b669a6d0fad4ef2d0863356e160c(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H7068c8717e9d582db2941dd2bdd79d55(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H678d1b43e8b98a171ffdea8f28643d28(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePreludeFuncRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePreludeConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_248dea6bbb4b10fb_e7c6566d75989db7 = external constant [0 x i8]
@olang_loc_1bcb50306faa07e3_18a30ea25b6c39c7 = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He890afa3b14bd52c6ea464bca4cef525(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
@olang_loc_c883e3bd313e2585_b0aaf26ba1585cf1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownImportStd(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_c24d94d368b768d0_dc6a7a3b6fd73c94 = external constant [0 x i8]
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitBranch(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_93653db47984ae2f_98605133537f87a3 = external constant [0 x i8]
@olang_loc_b66f44eae599aa7e_d468abe9cc136322 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eLen_H9e36587759e47da85a29e6c0abff1d1c(ptr %v0, ptr %a0)
declare %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %v0, ptr %v1, ptr %a0, i64 %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
