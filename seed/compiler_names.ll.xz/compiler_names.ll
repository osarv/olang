; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/names:Table" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/names:local" = type { i32, %"compiler/source:Span", i32 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/cond:Eval" = type { { i64, ptr }, ptr, ptr, ptr, i1, i1, i1, %"compiler/source:Span", %"compiler/msgs:Msg", i64, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/cond:Scope" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Names" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
define dso_local i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr @.d0 })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 5, ptr @.d1 })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 2, ptr @.d2 })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 3, ptr @.d3 })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb17
bb15:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 3, ptr @.d4 })
  store i1 %t22, ptr %l14
  br label %bb16
bb16:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb17
bb17:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb21
bb19:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 3, ptr @.d5 })
  store i1 %t27, ptr %l17
  br label %bb20
bb20:
  %t28 = load i1, ptr %l17, !tbaa !21
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb21
bb21:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb25
bb23:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 2, ptr @.d6 })
  store i1 %t32, ptr %l20
  br label %bb24
bb24:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb25
bb25:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb29
bb27:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t35, { i64, ptr } { i64 3, ptr @.d7 })
  store i1 %t37, ptr %l23
  br label %bb28
bb28:
  %t38 = load i1, ptr %l23, !tbaa !21
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb29
bb29:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb33
bb31:
  %t40 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t40, { i64, ptr } { i64 3, ptr @.d8 })
  store i1 %t42, ptr %l26
  br label %bb32
bb32:
  %t43 = load i1, ptr %l26, !tbaa !21
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb33
bb33:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb37
bb35:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 3, ptr @.d9 })
  store i1 %t47, ptr %l29
  br label %bb36
bb36:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb37
bb37:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb41
bb39:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 3, ptr @.d10 })
  store i1 %t52, ptr %l32
  br label %bb40
bb40:
  %t53 = load i1, ptr %l32, !tbaa !21
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb41
bb41:
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb45
bb43:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t55, { i64, ptr } { i64 4, ptr @.d11 })
  store i1 %t57, ptr %l35
  br label %bb44
bb44:
  %t58 = load i1, ptr %l35, !tbaa !21
  store i1 %t58, ptr %l33, !tbaa !21
  br label %bb45
bb45:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb49
bb47:
  %t60 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 3, ptr @.d12 })
  store i1 %t62, ptr %l38
  br label %bb48
bb48:
  %t63 = load i1, ptr %l38, !tbaa !21
  store i1 %t63, ptr %l36, !tbaa !21
  br label %bb49
bb49:
  %t64 = load i1, ptr %l36, !tbaa !21
  br i1 %t64, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb53
bb51:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 3, ptr @.d13 })
  store i1 %t67, ptr %l41
  br label %bb52
bb52:
  %t68 = load i1, ptr %l41, !tbaa !21
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i1, ptr %l39, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eDecideTop(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i64
  %l42 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca %"compiler/names:Table"
  %l77 = alloca i64
  %l81 = alloca i64
  %l84 = alloca i64
  %l112 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l125 = alloca i1
  %l132 = alloca %"compiler/source:Span"
  %l150 = alloca i64
  %l154 = alloca i64
  %l157 = alloca i64
  %l179 = alloca ptr
  %l183 = alloca ptr
  %l184 = alloca i64
  %l189 = alloca ptr
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t8 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l32
  br label %bb1
bb1:
  %t9 = load i64, ptr %l32, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/names:Resolver", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i32, ptr %l2, !tbaa !23
  %t16 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %t13, i64 %t14, i32 %t15, i64 %t16)
  br label %bb2
bb2:
  %t21 = load i64, ptr %l4, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/names:Resolver", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 5
  %t30 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l42
  br label %bb3
bb3:
  %t31 = load i64, ptr %l42, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb4, label %bb5
bb4:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb9
bb6:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l49, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb8
bb8:
  %t58 = load i64, ptr %l49, !tbaa !24
  store i64 %t58, ptr %l46, !tbaa !24
  br label %bb9
bb9:
  %t59 = load i64, ptr %l46, !tbaa !24
  store i64 %t59, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t60 = load i64, ptr %l9, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb12:
  br label %bb13
bb13:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l10, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/names:Resolver", ptr %t78, i32 0, i32 1
  store ptr %t80, ptr %l68, !tbaa !29
  %t81 = call %"compiler/names:Table" @compiler_2fnames_3aTable_2ector(ptr %v0)
  store %"compiler/names:Table" %t81, ptr %l69
  br label %bb14
bb14:
  %t82 = load %"compiler/names:Table", ptr %l69
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/names:Table" %t82, ptr %t83
  %t84 = load ptr, ptr %l68, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H66319a5cfce1cb719f827f90e3d522ba(ptr %v0, ptr %v0, ptr %t84, ptr %t83)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l9, !tbaa !24
  br label %bb10
bb17:
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l11, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/names:Resolver", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/load:Loader", ptr %t95, i32 0, i32 5
  %t99 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t97)
  store i64 %t99, ptr %l77
  br label %bb18
bb18:
  %t100 = load i64, ptr %l77, !tbaa !24
  store i64 %t100, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t101 = load i64, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb19, label %bb20
bb19:
  %t107 = load i64, ptr %l13, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb24
bb21:
  %t111 = load i64, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l13, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l13, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l84, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb23
bb23:
  %t127 = load i64, ptr %l84, !tbaa !24
  store i64 %t127, ptr %l81, !tbaa !24
  br label %bb24
bb24:
  %t128 = load i64, ptr %l81, !tbaa !24
  store i64 %t128, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load i64, ptr %l15, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t137 = load i64, ptr %l11, !tbaa !24
  %t138 = load i64, ptr %l15, !tbaa !24
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = mul i64 %t138, %t139
  %t145 = add i64 %t137, %t142
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etableOf(ptr %v0, ptr %t147, i64 %t145)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  %t151 = load i64, ptr %l15, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l15, !tbaa !24
  br label %bb25
bb31:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasesOf(ptr %v0, ptr %t155, i64 %t156)
  br label %bb32
bb32:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/names:Resolver", ptr %t159, i32 0, i32 0
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/load:Loader", ptr %t162, i32 0, i32 5
  %t165 = load i64, ptr %l1, !tbaa !24
  %t168 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t164, i64 %t165)
  store ptr %t168, ptr %l112
  br label %bb33
bb33:
  %t169 = load ptr, ptr %l112, !tbaa !29
  %t172 = getelementptr %"compiler/load:Module", ptr %t169, i32 0, i32 8
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l20, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t179 = load i64, ptr %l19, !tbaa !24
  %t180 = load i64, ptr %l20, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb36:
  br label %bb37
bb37:
  %t187 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t187, ptr %l121, !tbaa !27
  %t188 = load i64, ptr %l19, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr ptr, ptr %t191, i64 %t188
  %t193 = load ptr, ptr %t192, !tbaa !39
  store ptr %t193, ptr %l21, !tbaa !29
  %t195 = load ptr, ptr %l21, !tbaa !29
  store ptr %t195, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t196 = load ptr, ptr %l124, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb38, label %bb39
bb38:
  %t199 = load ptr, ptr %l124, !tbaa !29
  %t200 = load i64, ptr %t199
  %t202 = icmp eq i64 %t200, 7
  store i1 %t202, ptr %l125, !tbaa !21
  br label %bb39
bb39:
  %t203 = load i1, ptr %l125, !tbaa !21
  br i1 %t203, label %bb40, label %bb41
bb40:
  %t204 = load ptr, ptr %l21, !tbaa !29
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", ptr }, ptr %t206, i32 0, i32 1
  %t208 = load ptr, ptr %t207
  store ptr %t208, ptr %l22, !tbaa !29
  br label %bb42
bb41:
  br label %bb49
bb42:
  %t210 = load ptr, ptr %l22, !tbaa !29
  %t212 = getelementptr %"compiler/ast:TopIf", ptr %t210, i32 0, i32 0
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t213)
  store %"compiler/source:Span" %t215, ptr %l132
  br label %bb43
bb43:
  %t216 = getelementptr %"compiler/source:Span", ptr %l132, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  %t218 = load i32, ptr %l2, !tbaa !23
  %t221 = icmp eq i32 %t217, %t218
  br i1 %t221, label %bb44, label %bb45
bb44:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i64, ptr %l1, !tbaa !24
  %t225 = load ptr, ptr %l22, !tbaa !29
  %t226 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollectIf(ptr %v0, ptr %v0, ptr %t223, i64 %t224, ptr %t225, i64 %t226, i64 0)
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load i64, ptr %l1, !tbaa !24
  %t233 = load ptr, ptr %l22, !tbaa !29
  %t234 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodiesIf(ptr %v0, ptr %v0, ptr %t231, i64 %t232, ptr %t233, i64 %t234, i64 0)
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb51:
  %t239 = load i64, ptr %l19, !tbaa !24
  %t241 = add i64 %t239, 1
  store i64 %t241, ptr %l19, !tbaa !24
  br label %bb34
bb52:
  %t243 = load i64, ptr %l4, !tbaa !24
  store i64 %t243, ptr %l23, !tbaa !24
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/names:Resolver", ptr %t245, i32 0, i32 0
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = getelementptr %"compiler/load:Loader", ptr %t248, i32 0, i32 5
  %t252 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t250)
  store i64 %t252, ptr %l150
  br label %bb53
bb53:
  %t253 = load i64, ptr %l150, !tbaa !24
  store i64 %t253, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t254 = load i64, ptr %l24, !tbaa !24
  %t255 = load i64, ptr %l23, !tbaa !24
  %t258 = icmp sgt i64 %t254, %t255
  br i1 %t258, label %bb54, label %bb55
bb54:
  %t260 = load i64, ptr %l25, !tbaa !24
  %t262 = icmp sgt i64 %t260, 0
  br i1 %t262, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l154, !tbaa !24
  br label %bb59
bb56:
  %t264 = load i64, ptr %l24, !tbaa !24
  %t265 = load i64, ptr %l23, !tbaa !24
  %t268 = sub i64 %t264, %t265
  %t269 = load i64, ptr %l25, !tbaa !24
  %t272 = add i64 %t268, %t269
  %t274 = sub i64 %t272, 1
  %t275 = load i64, ptr %l25, !tbaa !24
  %t278 = sdiv i64 %t274, %t275
  store i64 %t278, ptr %l157, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l157, !tbaa !24
  br label %bb58
bb58:
  %t280 = load i64, ptr %l157, !tbaa !24
  store i64 %t280, ptr %l154, !tbaa !24
  br label %bb59
bb59:
  %t281 = load i64, ptr %l154, !tbaa !24
  store i64 %t281, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s14
  %t282 = load i64, ptr %l27, !tbaa !24
  %t283 = load i64, ptr %l26, !tbaa !24
  %t286 = icmp slt i64 %t282, %t283
  %t288 = xor i1 %t286, true
  br i1 %t288, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s14)
  br label %bb71
bb62:
  br label %bb63
bb63:
  %t290 = load i64, ptr %l23, !tbaa !24
  %t291 = load i64, ptr %l27, !tbaa !24
  %t292 = load i64, ptr %l25, !tbaa !24
  %t295 = mul i64 %t291, %t292
  %t298 = add i64 %t290, %t295
  store i64 %t298, ptr %l28, !tbaa !24
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/names:Resolver", ptr %t300, i32 0, i32 0
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t305 = getelementptr %"compiler/load:Loader", ptr %t303, i32 0, i32 5
  %t306 = load i64, ptr %l28, !tbaa !24
  %t309 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t305, i64 %t306)
  store ptr %t309, ptr %l179
  br label %bb64
bb64:
  %t310 = load ptr, ptr %l179, !tbaa !29
  %t312 = getelementptr %"compiler/load:Module", ptr %t310, i32 0, i32 8
  %t313 = load { i64, ptr }, ptr %t312, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t316 = extractvalue { i64, ptr } zeroinitializer, 0
  %t317 = icmp eq i64 %t315, %t316
  %t318 = extractvalue { i64, ptr } %t313, 1
  %t319 = extractvalue { i64, ptr } zeroinitializer, 1
  %t320 = icmp eq ptr %t318, %t319
  %t321 = and i1 %t317, %t320
  %t322 = xor i1 %t321, true
  br i1 %t322, label %bb65, label %bb66
bb65:
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l183, !tbaa !29
  %t325 = load i64, ptr %l28, !tbaa !24
  store i64 %t325, ptr %l184, !tbaa !24
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/names:Resolver", ptr %t326, i32 0, i32 0
  %t329 = load ptr, ptr %t328, !tbaa !29
  %t331 = getelementptr %"compiler/load:Loader", ptr %t329, i32 0, i32 5
  %t332 = load i64, ptr %l28, !tbaa !24
  %t335 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t331, i64 %t332)
  store ptr %t335, ptr %l189
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t336 = load ptr, ptr %l189, !tbaa !29
  %t338 = getelementptr %"compiler/load:Module", ptr %t336, i32 0, i32 8
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  %t340 = load ptr, ptr %l183, !tbaa !29
  %t341 = load i64, ptr %l184, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v0, ptr %t340, i64 %t341, { i64, ptr } %t339)
  br label %bb68
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s14)
  br label %bb70
bb70:
  %t343 = load i64, ptr %l27, !tbaa !24
  %t345 = add i64 %t343, 1
  store i64 %t345, ptr %l27, !tbaa !24
  br label %bb60
bb71:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca i32
  %l12 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 5
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = call i64 @compiler_2fnames_2ekey(i64 %a1, i32 %a2)
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = call { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eG_Hb4f204ca9d50eb43e30fe8770cb15d1a(ptr %v0, ptr %t9, i64 %t10)
  %t12 = extractvalue { i32, %"compiler/names:Ref" } %t11, 1
  %t13 = extractvalue { i32, %"compiler/names:Ref" } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15
ok.15:
  store %"compiler/names:Ref" %t12, ptr %l9
  br label %bb2
bb2:
  %t16 = load %"compiler/names:Ref", ptr %l9
  store %"compiler/names:Ref" %t16, ptr %l3
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t18 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t18, ptr %l12
  br label %bb5
bb5:
  %t19 = load %"compiler/names:Ref", ptr %l12
  store %"compiler/names:Ref" %t19, ptr %l3
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load %"compiler/names:Ref", ptr %l3
  store %"compiler/names:Ref" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l21 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l22 = alloca %"compiler/names:Entry"
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca %"compiler/names:Table"
  %l73 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l102 = alloca ptr
  %l112 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca i32
  %l128 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l133 = alloca i1
  %l135 = alloca ptr
  %l140 = alloca i32
  %l150 = alloca ptr
  %l153 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l154 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l156 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l157 = alloca i32
  %l163 = alloca ptr
  %l167 = alloca %"compiler/names:Entry"
  %l168 = alloca i32
  %l170 = alloca i32
  %l172 = alloca i1
  %l173 = alloca i1
  %l176 = alloca i1
  %l179 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l182 = alloca i1
  %l184 = alloca ptr
  %l185 = alloca i32
  %l189 = alloca %"compiler/names:Ref"
  %l195 = alloca i64
  %l199 = alloca i64
  %l202 = alloca i64
  %l224 = alloca ptr
  %l235 = alloca i64
  %l239 = alloca i64
  %l242 = alloca i64
  %l264 = alloca ptr
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t8 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l39
  br label %bb1
bb1:
  %t9 = load i64, ptr %l39, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb7
bb4:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load i64, ptr %l1, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l46, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l46, !tbaa !24
  store i64 %t36, ptr %l43, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l43, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l6, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/names:Resolver", ptr %t56, i32 0, i32 1
  store ptr %t58, ptr %l65, !tbaa !29
  %t59 = call %"compiler/names:Table" @compiler_2fnames_3aTable_2ector(ptr %v0)
  store %"compiler/names:Table" %t59, ptr %l66
  br label %bb12
bb12:
  %t60 = load %"compiler/names:Table", ptr %l66
  %t61 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/names:Table" %t60, ptr %t61
  %t62 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H66319a5cfce1cb719f827f90e3d522ba(ptr %v0, ptr %v0, ptr %t62, ptr %t61)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l5, !tbaa !24
  br label %bb8
bb15:
  store i64 0, ptr %l7, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/names:Resolver", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 5
  %t75 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t73)
  store i64 %t75, ptr %l73
  br label %bb16
bb16:
  %t76 = load i64, ptr %l73, !tbaa !24
  store i64 %t76, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp sgt i64 %t77, %t78
  br i1 %t81, label %bb17, label %bb18
bb17:
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = icmp sgt i64 %t83, 0
  br i1 %t85, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb22
bb19:
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  store i64 %t101, ptr %l80, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb21
bb21:
  %t103 = load i64, ptr %l80, !tbaa !24
  store i64 %t103, ptr %l77, !tbaa !24
  br label %bb22
bb22:
  %t104 = load i64, ptr %l77, !tbaa !24
  store i64 %t104, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t105 = load i64, ptr %l11, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb82
bb25:
  br label %bb26
bb26:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = mul i64 %t114, %t115
  %t121 = add i64 %t113, %t118
  store i64 %t121, ptr %l12, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/names:Resolver", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/load:Loader", ptr %t126, i32 0, i32 5
  %t129 = load i64, ptr %l12, !tbaa !24
  %t132 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t128, i64 %t129)
  store ptr %t132, ptr %l102
  br label %bb27
bb27:
  %t133 = load ptr, ptr %l102, !tbaa !29
  %t136 = getelementptr %"compiler/load:Module", ptr %t133, i32 0, i32 3
  %t137 = load i1, ptr %t136, !tbaa !21
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb81
bb29:
  br label %bb30
bb30:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etableOf(ptr %v0, ptr %t141, i64 %t142)
  br label %bb31
bb31:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/names:Resolver", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/load:Loader", ptr %t148, i32 0, i32 5
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t150, i64 %t151)
  store ptr %t154, ptr %l112
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l112, !tbaa !29
  %t157 = getelementptr %"compiler/load:Module", ptr %t155, i32 0, i32 9
  store ptr %t157, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t159 = load ptr, ptr %l14, !tbaa !29
  %t160 = load i64, ptr %l15, !tbaa !24
  %t163 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t159, i64 %t160)
  %t164 = extractvalue { i32, { i64, ptr } } %t163, 1
  %t165 = extractvalue { i32, { i64, ptr } } %t163, 0
  store i32 %t165, ptr %l119
  %t166 = icmp ne i32 %t165, 0
  br i1 %t166, label %bb35, label %ok.167
ok.167:
  store { i64, ptr } %t164, ptr %l118
  br label %bb34
bb34:
  %t168 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t168, ptr %l115, !tbaa !27
  br label %bb39
bb35:
  %t169 = load i32, ptr %l119, !tbaa !23
  %t170 = ashr i32 %t169, 16
  %t172 = icmp eq i32 %t170, 1
  br i1 %t172, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb38:
  call void @__olang_scope_close(ptr %s8)
  br label %bb53
bb39:
  %t174 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t174, ptr %l16, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s9
  %t179 = load i64, ptr %l18, !tbaa !24
  %t180 = load i64, ptr %l17, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb42:
  br label %bb43
bb43:
  %t187 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t187, ptr %l128, !tbaa !27
  %t188 = load i64, ptr %l18, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %t191, i64 %t188
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !37
  store { i64, ptr } %t193, ptr %l19, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t195, ptr %l131, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i8, ptr %t197, i64 0
  %t199 = load i8, ptr %t198, !tbaa !32
  %t201 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t199)
  store i1 %t201, ptr %l133
  br label %bb44
bb44:
  %t202 = load i1, ptr %l133, !tbaa !21
  br i1 %t202, label %bb45, label %bb46
bb45:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/names:Resolver", ptr %t203, i32 0, i32 2
  store ptr %t205, ptr %l135, !tbaa !29
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/names:Resolver", ptr %t206, i32 0, i32 0
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = getelementptr %"compiler/load:Loader", ptr %t209, i32 0, i32 3
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t216 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t212, { i64, ptr } %t213)
  store i32 %t216, ptr %l140
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t217 = load i64, ptr %l12, !tbaa !24
  %t218 = load ptr, ptr %l135, !tbaa !29
  %t219 = load i32, ptr %l140, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t218, i32 %t219, i64 %t217)
  br label %bb48
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb50:
  %t221 = load i64, ptr %l18, !tbaa !24
  %t223 = add i64 %t221, 1
  store i64 %t223, ptr %l18, !tbaa !24
  br label %bb40
bb51:
  %t225 = load i64, ptr %l15, !tbaa !24
  %t226 = load i64, ptr %l17, !tbaa !24
  %t229 = add i64 %t225, %t226
  store i64 %t229, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  br label %bb33
bb53:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/names:Resolver", ptr %t231, i32 0, i32 1
  %t234 = load i64, ptr %l12, !tbaa !24
  %t237 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t233, i64 %t234)
  store ptr %t237, ptr %l150
  br label %bb54
bb54:
  %t238 = load ptr, ptr %l150, !tbaa !29
  %t240 = getelementptr %"compiler/names:Table", ptr %t238, i32 0, i32 1
  %t242 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v0, ptr %t240)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t242, ptr %l153
  br label %bb55
bb55:
  %t243 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l153
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t243, ptr %l20
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s13
  %t245 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %l20)
  %t246 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t245, 1
  %t247 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t245, 0
  store i32 %t247, ptr %l157
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb58, label %ok.249
ok.249:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t246, ptr %l156
  br label %bb57
bb57:
  %t250 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l156
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t250, ptr %l154
  br label %bb62
bb58:
  %t251 = load i32, ptr %l157, !tbaa !23
  %t252 = ashr i32 %t251, 16
  %t254 = icmp eq i32 %t252, 1
  br i1 %t254, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb80
bb62:
  %t256 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l154
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t256, ptr %l21
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/names:Resolver", ptr %t257, i32 0, i32 1
  %t260 = load i64, ptr %l12, !tbaa !24
  %t263 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t259, i64 %t260)
  store ptr %t263, ptr %l163
  br label %bb63
bb63:
  %t264 = load ptr, ptr %l163, !tbaa !29
  %t266 = getelementptr %"compiler/names:Table", ptr %t264, i32 0, i32 0
  %t267 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l21, i32 0, i32 1
  %t268 = load i64, ptr %t267, !tbaa !24
  %t271 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t266, i64 %t268)
  store %"compiler/names:Entry" %t271, ptr %l167
  br label %bb64
bb64:
  %t272 = load %"compiler/names:Entry", ptr %l167
  store %"compiler/names:Entry" %t272, ptr %l22
  %t273 = getelementptr %"compiler/names:Entry", ptr %l22, i32 0, i32 2
  %t274 = load i32, ptr %t273
  store i32 %t274, ptr %l168
  store i32 2, ptr %l170
  %t277 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l168, ptr %l170)
  store i1 %t277, ptr %l172
  br label %bb65
bb65:
  %t278 = load i1, ptr %l172, !tbaa !21
  br i1 %t278, label %bb66, label %bb67
bb66:
  %t279 = getelementptr %"compiler/names:Entry", ptr %l22, i32 0, i32 3
  %t280 = load i1, ptr %t279, !tbaa !21
  %t282 = xor i1 %t280, true
  store i1 %t282, ptr %l173, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb68
bb68:
  %t284 = load i1, ptr %l173, !tbaa !21
  br i1 %t284, label %bb69, label %bb70
bb69:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l21, i32 0, i32 0
  %t287 = load i32, ptr %t286, !tbaa !23
  %t290 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t285, i32 %t287)
  store { i64, ptr } %t290, ptr %l179
  br label %bb71
bb70:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb73
bb71:
  %t291 = load { i64, ptr }, ptr %l179, !tbaa !27
  store { i64, ptr } %t291, ptr %l180, !tbaa !27
  %t292 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr i8, ptr %t293, i64 0
  %t295 = load i8, ptr %t294, !tbaa !32
  %t297 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t295)
  store i1 %t297, ptr %l182
  br label %bb72
bb72:
  %t298 = load i1, ptr %l182, !tbaa !21
  store i1 %t298, ptr %l176, !tbaa !21
  br label %bb73
bb73:
  %t299 = load i1, ptr %l176, !tbaa !21
  br i1 %t299, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s14
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/names:Resolver", ptr %t300, i32 0, i32 3
  store ptr %t302, ptr %l184, !tbaa !29
  %t303 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l21, i32 0, i32 0
  %t304 = load i32, ptr %t303, !tbaa !23
  store i32 %t304, ptr %l185, !tbaa !23
  %t305 = load i64, ptr %l12, !tbaa !24
  %t306 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l21, i32 0, i32 1
  %t307 = load i64, ptr %t306, !tbaa !24
  %t311 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s14, i32 2, i64 %t305, i64 %t307)
  store %"compiler/names:Ref" %t311, ptr %l189
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t312 = load ptr, ptr %l184, !tbaa !29
  %t313 = load i32, ptr %l185, !tbaa !23
  %t314 = load %"compiler/names:Ref", ptr %l189
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H456f40e55a35e282608933ec0991ad61(ptr %v0, ptr %t312, i32 %t313, %"compiler/names:Ref" %t314)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s14)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb79:
  br label %bb56
bb80:
  call void @__olang_scope_close(ptr %s5)
  br label %bb81
bb81:
  %t315 = load i64, ptr %l11, !tbaa !24
  %t317 = add i64 %t315, 1
  store i64 %t317, ptr %l11, !tbaa !24
  br label %bb23
bb82:
  store i64 0, ptr %l23, !tbaa !24
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/names:Resolver", ptr %t319, i32 0, i32 0
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = getelementptr %"compiler/load:Loader", ptr %t322, i32 0, i32 5
  %t326 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t324)
  store i64 %t326, ptr %l195
  br label %bb83
bb83:
  %t327 = load i64, ptr %l195, !tbaa !24
  store i64 %t327, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t328 = load i64, ptr %l24, !tbaa !24
  %t329 = load i64, ptr %l23, !tbaa !24
  %t332 = icmp sgt i64 %t328, %t329
  br i1 %t332, label %bb84, label %bb85
bb84:
  %t334 = load i64, ptr %l25, !tbaa !24
  %t336 = icmp sgt i64 %t334, 0
  br i1 %t336, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb89
bb86:
  %t338 = load i64, ptr %l24, !tbaa !24
  %t339 = load i64, ptr %l23, !tbaa !24
  %t342 = sub i64 %t338, %t339
  %t343 = load i64, ptr %l25, !tbaa !24
  %t346 = add i64 %t342, %t343
  %t348 = sub i64 %t346, 1
  %t349 = load i64, ptr %l25, !tbaa !24
  %t352 = sdiv i64 %t348, %t349
  store i64 %t352, ptr %l202, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb88
bb88:
  %t354 = load i64, ptr %l202, !tbaa !24
  store i64 %t354, ptr %l199, !tbaa !24
  br label %bb89
bb89:
  %t355 = load i64, ptr %l199, !tbaa !24
  store i64 %t355, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb90
bb90:
  store %olang.scope zeroinitializer, ptr %s17
  %t356 = load i64, ptr %l27, !tbaa !24
  %t357 = load i64, ptr %l26, !tbaa !24
  %t360 = icmp slt i64 %t356, %t357
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s17)
  br label %bb100
bb92:
  br label %bb93
bb93:
  %t364 = load i64, ptr %l23, !tbaa !24
  %t365 = load i64, ptr %l27, !tbaa !24
  %t366 = load i64, ptr %l25, !tbaa !24
  %t369 = mul i64 %t365, %t366
  %t372 = add i64 %t364, %t369
  store i64 %t372, ptr %l28, !tbaa !24
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/names:Resolver", ptr %t374, i32 0, i32 0
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = getelementptr %"compiler/load:Loader", ptr %t377, i32 0, i32 5
  %t380 = load i64, ptr %l28, !tbaa !24
  %t383 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t379, i64 %t380)
  store ptr %t383, ptr %l224
  br label %bb94
bb94:
  %t384 = load ptr, ptr %l224, !tbaa !29
  %t386 = getelementptr %"compiler/load:Module", ptr %t384, i32 0, i32 3
  %t387 = load i1, ptr %t386, !tbaa !21
  %t389 = xor i1 %t387, true
  br i1 %t389, label %bb95, label %bb96
bb95:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load i64, ptr %l28, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etableOf(ptr %v0, ptr %t391, i64 %t392)
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s17)
  br label %bb99
bb99:
  %t395 = load i64, ptr %l27, !tbaa !24
  %t397 = add i64 %t395, 1
  store i64 %t397, ptr %l27, !tbaa !24
  br label %bb90
bb100:
  store i64 0, ptr %l29, !tbaa !24
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/names:Resolver", ptr %t399, i32 0, i32 0
  %t402 = load ptr, ptr %t401, !tbaa !29
  %t404 = getelementptr %"compiler/load:Loader", ptr %t402, i32 0, i32 5
  %t406 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t404)
  store i64 %t406, ptr %l235
  br label %bb101
bb101:
  %t407 = load i64, ptr %l235, !tbaa !24
  store i64 %t407, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t408 = load i64, ptr %l30, !tbaa !24
  %t409 = load i64, ptr %l29, !tbaa !24
  %t412 = icmp sgt i64 %t408, %t409
  br i1 %t412, label %bb102, label %bb103
bb102:
  %t414 = load i64, ptr %l31, !tbaa !24
  %t416 = icmp sgt i64 %t414, 0
  br i1 %t416, label %bb104, label %bb105
bb103:
  store i64 0, ptr %l239, !tbaa !24
  br label %bb107
bb104:
  %t418 = load i64, ptr %l30, !tbaa !24
  %t419 = load i64, ptr %l29, !tbaa !24
  %t422 = sub i64 %t418, %t419
  %t423 = load i64, ptr %l31, !tbaa !24
  %t426 = add i64 %t422, %t423
  %t428 = sub i64 %t426, 1
  %t429 = load i64, ptr %l31, !tbaa !24
  %t432 = sdiv i64 %t428, %t429
  store i64 %t432, ptr %l242, !tbaa !24
  br label %bb106
bb105:
  store i64 0, ptr %l242, !tbaa !24
  br label %bb106
bb106:
  %t434 = load i64, ptr %l242, !tbaa !24
  store i64 %t434, ptr %l239, !tbaa !24
  br label %bb107
bb107:
  %t435 = load i64, ptr %l239, !tbaa !24
  store i64 %t435, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb108
bb108:
  store %olang.scope zeroinitializer, ptr %s21
  %t436 = load i64, ptr %l33, !tbaa !24
  %t437 = load i64, ptr %l32, !tbaa !24
  %t440 = icmp slt i64 %t436, %t437
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s21)
  br label %bb118
bb110:
  br label %bb111
bb111:
  %t444 = load i64, ptr %l29, !tbaa !24
  %t445 = load i64, ptr %l33, !tbaa !24
  %t446 = load i64, ptr %l31, !tbaa !24
  %t449 = mul i64 %t445, %t446
  %t452 = add i64 %t444, %t449
  store i64 %t452, ptr %l34, !tbaa !24
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/names:Resolver", ptr %t454, i32 0, i32 0
  %t457 = load ptr, ptr %t456, !tbaa !29
  %t459 = getelementptr %"compiler/load:Loader", ptr %t457, i32 0, i32 5
  %t460 = load i64, ptr %l34, !tbaa !24
  %t463 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t459, i64 %t460)
  store ptr %t463, ptr %l264
  br label %bb112
bb112:
  %t464 = load ptr, ptr %l264, !tbaa !29
  store ptr %t464, ptr %l35, !tbaa !29
  %t465 = load ptr, ptr %l35, !tbaa !29
  %t467 = getelementptr %"compiler/load:Module", ptr %t465, i32 0, i32 8
  %t468 = load { i64, ptr }, ptr %t467, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t468, 0
  %t471 = extractvalue { i64, ptr } zeroinitializer, 0
  %t472 = icmp eq i64 %t470, %t471
  %t473 = extractvalue { i64, ptr } %t468, 1
  %t474 = extractvalue { i64, ptr } zeroinitializer, 1
  %t475 = icmp eq ptr %t473, %t474
  %t476 = and i1 %t472, %t475
  %t477 = xor i1 %t476, true
  br i1 %t477, label %bb113, label %bb114
bb113:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load i64, ptr %l34, !tbaa !24
  %t481 = load ptr, ptr %l35, !tbaa !29
  %t483 = getelementptr %"compiler/load:Module", ptr %t481, i32 0, i32 8
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v0, ptr %t479, i64 %t480, { i64, ptr } %t484)
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s21)
  br label %bb117
bb117:
  %t488 = load i64, ptr %l33, !tbaa !24
  %t490 = add i64 %t488, 1
  store i64 %t490, ptr %l33, !tbaa !24
  br label %bb108
bb118:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca i32
  %l12 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 4
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = call i64 @compiler_2fnames_2ekey(i64 %a1, i32 %a2)
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = call { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eG_Hb4f204ca9d50eb43e30fe8770cb15d1a(ptr %v0, ptr %t9, i64 %t10)
  %t12 = extractvalue { i32, %"compiler/names:Ref" } %t11, 1
  %t13 = extractvalue { i32, %"compiler/names:Ref" } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15
ok.15:
  store %"compiler/names:Ref" %t12, ptr %l9
  br label %bb2
bb2:
  %t16 = load %"compiler/names:Ref", ptr %l9
  store %"compiler/names:Ref" %t16, ptr %l3
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t18 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t18, ptr %l12
  br label %bb5
bb5:
  %t19 = load %"compiler/names:Ref", ptr %l12
  store %"compiler/names:Ref" %t19, ptr %l3
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load %"compiler/names:Ref", ptr %l3
  store %"compiler/names:Ref" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l30 = alloca ptr
  %l34 = alloca { i64, [3 x i64] }
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %l44 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l56 = alloca { i64, [3 x i64] }
  %l59 = alloca { i64, ptr }
  %l61 = alloca %"compiler/msgs:Msg"
  %l62 = alloca i64
  %l64 = alloca i1
  %l67 = alloca ptr
  %l71 = alloca { i64, [3 x i64] }
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"compiler/msgs:Msg"
  %l77 = alloca i64
  %l86 = alloca i1
  %l89 = alloca ptr
  %l93 = alloca { i64, [3 x i64] }
  %l96 = alloca { i64, ptr }
  %l98 = alloca %"compiler/msgs:Msg"
  %l99 = alloca i64
  %l101 = alloca ptr
  %l102 = alloca i32
  %l105 = alloca i64
  %l107 = alloca ptr
  %l112 = alloca %"compiler/names:Entry"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l14, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 5
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l19
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l19, !tbaa !29
  store ptr %t19, ptr %l6, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t24, ptr %l22
  br label %bb3
bb3:
  %t25 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t25, ptr %l7, !tbaa !27
  %t26 = load i32, ptr %l2, !tbaa !23
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t30 = getelementptr %"compiler/names:Table", ptr %t28, i32 0, i32 2
  %t34 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t30, i32 %t26)
  store i1 %t34, ptr %l27
  br label %bb4
bb4:
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/names:Resolver", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/load:Loader", ptr %t39, i32 0, i32 4
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l30, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l1, !tbaa !24
  %t45 = load %"compiler/source:Span", ptr %l3
  %t49 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t43, i64 %t44, %"compiler/source:Span" %t45)
  store { i64, [3 x i64] } %t49, ptr %l34
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t50, i32 %t51)
  store { i64, ptr } %t54, ptr %l37
  br label %bb8
bb8:
  %t55 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t63 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNameInUse(ptr %s1, ptr %s1, { i64, ptr } %t61)
  store %"compiler/msgs:Msg" %t63, ptr %l39
  br label %bb9
bb9:
  %t64 = load ptr, ptr %l30, !tbaa !29
  %t65 = load { i64, [3 x i64] }, ptr %l34
  %t66 = load %"compiler/msgs:Msg", ptr %l39
  %t67 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t64, { i64, [3 x i64] } %t65, %"compiler/msgs:Msg" %t66)
  store i64 %t67, ptr %l40
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb11:
  %t68 = load ptr, ptr %l6, !tbaa !29
  %t70 = getelementptr %"compiler/load:Module", ptr %t68, i32 0, i32 3
  %t71 = load i1, ptr %t70, !tbaa !21
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb12, label %bb13
bb12:
  %t75 = load i32, ptr %l2, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/names:Resolver", ptr %t77, i32 0, i32 2
  %t83 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t79, i32 %t75)
  store i1 %t83, ptr %l49
  br label %bb14
bb13:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb15
bb14:
  %t84 = load i1, ptr %l49, !tbaa !21
  store i1 %t84, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t85 = load i1, ptr %l44, !tbaa !21
  br i1 %t85, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/names:Resolver", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/load:Loader", ptr %t89, i32 0, i32 4
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l52, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l1, !tbaa !24
  %t95 = load %"compiler/source:Span", ptr %l3
  %t99 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t93, i64 %t94, %"compiler/source:Span" %t95)
  store { i64, [3 x i64] } %t99, ptr %l56
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l2, !tbaa !23
  %t104 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t100, i32 %t101)
  store { i64, ptr } %t104, ptr %l59
  br label %bb19
bb19:
  %t105 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %s2, ptr %s2, { i64, ptr } %t111)
  store %"compiler/msgs:Msg" %t113, ptr %l61
  br label %bb20
bb20:
  %t114 = load ptr, ptr %l52, !tbaa !29
  %t115 = load { i64, [3 x i64] }, ptr %l56
  %t116 = load %"compiler/msgs:Msg", ptr %l61
  %t117 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t114, { i64, [3 x i64] } %t115, %"compiler/msgs:Msg" %t116)
  store i64 %t117, ptr %l62
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t118 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t120 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t118)
  store i1 %t120, ptr %l64
  br label %bb23
bb23:
  %t121 = load i1, ptr %l64, !tbaa !21
  br i1 %t121, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/names:Resolver", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/load:Loader", ptr %t125, i32 0, i32 4
  %t128 = load ptr, ptr %t127, !tbaa !29
  store ptr %t128, ptr %l67, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  %t131 = load %"compiler/source:Span", ptr %l3
  %t135 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t129, i64 %t130, %"compiler/source:Span" %t131)
  store { i64, [3 x i64] } %t135, ptr %l71
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l2, !tbaa !23
  %t140 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s3, ptr %t136, i32 %t137)
  store { i64, ptr } %t140, ptr %l74
  br label %bb27
bb27:
  %t141 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t149 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %s3, ptr %s3, { i64, ptr } %t147)
  store %"compiler/msgs:Msg" %t149, ptr %l76
  br label %bb28
bb28:
  %t150 = load ptr, ptr %l67, !tbaa !29
  %t151 = load { i64, [3 x i64] }, ptr %l71
  %t152 = load %"compiler/msgs:Msg", ptr %l76
  %t153 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t150, { i64, [3 x i64] } %t151, %"compiler/msgs:Msg" %t152)
  store i64 %t153, ptr %l77
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i64, ptr %l1, !tbaa !24
  %t156 = load i32, ptr %l2, !tbaa !23
  %t157 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t154, i64 %t155, i32 %t156, %"compiler/source:Span" %t157)
  br label %bb31
bb31:
  %t162 = load i32, ptr %l2, !tbaa !23
  %t164 = load ptr, ptr %l5, !tbaa !29
  %t166 = getelementptr %"compiler/names:Table", ptr %t164, i32 0, i32 1
  %t170 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t166, i32 %t162)
  store i1 %t170, ptr %l86
  br label %bb32
bb32:
  %t171 = load i1, ptr %l86, !tbaa !21
  br i1 %t171, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/names:Resolver", ptr %t172, i32 0, i32 0
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/load:Loader", ptr %t175, i32 0, i32 4
  %t178 = load ptr, ptr %t177, !tbaa !29
  store ptr %t178, ptr %l89, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l1, !tbaa !24
  %t181 = load %"compiler/source:Span", ptr %l3
  %t185 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t179, i64 %t180, %"compiler/source:Span" %t181)
  store { i64, [3 x i64] } %t185, ptr %l93
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i32, ptr %l2, !tbaa !23
  %t190 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s4, ptr %t186, i32 %t187)
  store { i64, ptr } %t190, ptr %l96
  br label %bb36
bb36:
  %t191 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = mul i64 %t192, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t194)
  call void @llvm.memcpy.p0.p0.i64(ptr %t195, ptr %t193, i64 %t194, i1 false)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t199 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameIsType(ptr %s4, ptr %s4, { i64, ptr } %t197)
  store %"compiler/msgs:Msg" %t199, ptr %l98
  br label %bb37
bb37:
  %t200 = load ptr, ptr %l89, !tbaa !29
  %t201 = load { i64, [3 x i64] }, ptr %l93
  %t202 = load %"compiler/msgs:Msg", ptr %l98
  %t203 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t200, { i64, [3 x i64] } %t201, %"compiler/msgs:Msg" %t202)
  store i64 %t203, ptr %l99
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb39:
  %t204 = load ptr, ptr %l5, !tbaa !29
  %t206 = getelementptr %"compiler/names:Table", ptr %t204, i32 0, i32 2
  store ptr %t206, ptr %l101, !tbaa !29
  %t207 = load i32, ptr %l2, !tbaa !23
  store i32 %t207, ptr %l102, !tbaa !23
  %t208 = load ptr, ptr %l5, !tbaa !29
  %t210 = getelementptr %"compiler/names:Table", ptr %t208, i32 0, i32 0
  %t212 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t210)
  store i64 %t212, ptr %l105
  br label %bb40
bb40:
  %t213 = load ptr, ptr %l101, !tbaa !29
  %t214 = load i32, ptr %l102, !tbaa !23
  %t215 = load i64, ptr %l105, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t213, i32 %t214, i64 %t215)
  br label %bb41
bb41:
  %t216 = load ptr, ptr %l5, !tbaa !29
  %t218 = getelementptr %"compiler/names:Table", ptr %t216, i32 0, i32 0
  store ptr %t218, ptr %l107, !tbaa !29
  %t219 = load i32, ptr %l2, !tbaa !23
  %t220 = load %"compiler/source:Span", ptr %l3
  %t226 = call %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v1, ptr %v0, i32 %t219, %"compiler/source:Span" %t220, i32 4, i1 false, ptr %a4)
  store %"compiler/names:Entry" %t226, ptr %l112
  br label %bb42
bb42:
  %t227 = load ptr, ptr %l107, !tbaa !29
  %t228 = load %"compiler/names:Entry", ptr %l112
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t227, %"compiler/names:Entry" %t228)
  br label %bb43
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddValue(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4, i1 %a5, i1 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i64
  %l19 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l32 = alloca ptr
  %l36 = alloca { i64, [3 x i64] }
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i64
  %l41 = alloca ptr
  %l45 = alloca %"compiler/names:Entry"
  %l50 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l65 = alloca i1
  %l69 = alloca ptr
  %l73 = alloca { i64, [3 x i64] }
  %l76 = alloca { i64, ptr }
  %l78 = alloca %"compiler/msgs:Msg"
  %l79 = alloca i64
  %l83 = alloca ptr
  %l87 = alloca { i64, [3 x i64] }
  %l90 = alloca { i64, ptr }
  %l92 = alloca %"compiler/msgs:Msg"
  %l93 = alloca i64
  %l99 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i32
  %l107 = alloca i1
  %l109 = alloca i1
  %l113 = alloca %"compiler/names:Entry"
  %l114 = alloca i32
  %l116 = alloca i32
  %l118 = alloca i1
  %l122 = alloca ptr
  %l126 = alloca { i64, [3 x i64] }
  %l129 = alloca { i64, ptr }
  %l131 = alloca %"compiler/msgs:Msg"
  %l132 = alloca i64
  %l143 = alloca i1
  %l144 = alloca i1
  %l149 = alloca i1
  %l150 = alloca i1
  %l152 = alloca i1
  %l155 = alloca ptr
  %l159 = alloca { i64, [3 x i64] }
  %l162 = alloca { i64, ptr }
  %l164 = alloca %"compiler/msgs:Msg"
  %l165 = alloca i64
  %l169 = alloca i1
  %l174 = alloca i1
  %l177 = alloca ptr
  %l181 = alloca { i64, [3 x i64] }
  %l184 = alloca { i64, ptr }
  %l186 = alloca %"compiler/msgs:Msg"
  %l187 = alloca i64
  %l189 = alloca ptr
  %l190 = alloca i32
  %l193 = alloca i64
  %l195 = alloca ptr
  %l196 = alloca i32
  %l197 = alloca %"compiler/source:Span"
  %l199 = alloca i32
  %l203 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l19, !tbaa !29
  store ptr %t8, ptr %l8, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 5
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l24
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l24, !tbaa !29
  store ptr %t19, ptr %l9, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t24, ptr %l27
  br label %bb3
bb3:
  %t25 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 1, ptr @.d16 })
  store i1 %t28, ptr %l29
  br label %bb4
bb4:
  %t29 = load i1, ptr %l29, !tbaa !21
  br i1 %t29, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/load:Loader", ptr %t33, i32 0, i32 4
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l32, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t39 = load %"compiler/source:Span", ptr %l3
  %t43 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t37, i64 %t38, %"compiler/source:Span" %t39)
  store { i64, [3 x i64] } %t43, ptr %l36
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t44 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %s1)
  store %"compiler/msgs:Msg" %t44, ptr %l37
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l32, !tbaa !29
  %t46 = load { i64, [3 x i64] }, ptr %l36
  %t47 = load %"compiler/msgs:Msg", ptr %l37
  %t48 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t45, { i64, [3 x i64] } %t46, %"compiler/msgs:Msg" %t47)
  store i64 %t48, ptr %l38
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  br i1 %a6, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l8, !tbaa !29
  %t53 = getelementptr %"compiler/names:Table", ptr %t51, i32 0, i32 0
  store ptr %t53, ptr %l41, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t55 = load %"compiler/source:Span", ptr %l3
  %t59 = call %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v0, ptr %v0, i32 %t54, %"compiler/source:Span" %t55, i32 3, i1 false, ptr null)
  store %"compiler/names:Entry" %t59, ptr %l45
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t60 = load ptr, ptr %l41, !tbaa !29
  %t61 = load %"compiler/names:Entry", ptr %l45
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t60, %"compiler/names:Entry" %t61)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/names:Resolver", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t72 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v0, ptr %t68, { i64, ptr } %t69)
  store i1 %t72, ptr %l50
  br label %bb16
bb16:
  %t73 = load i1, ptr %l50, !tbaa !21
  br i1 %t73, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load ptr, ptr %l9, !tbaa !29
  %t76 = getelementptr %"compiler/load:Module", ptr %t74, i32 0, i32 2
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s3, { i64, ptr } %t77, { i64, ptr } { i64 4, ptr @.d17 })
  store i1 %t79, ptr %l53
  br label %bb19
bb18:
  br label %bb45
bb19:
  %t80 = load i1, ptr %l53, !tbaa !21
  br i1 %t80, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb22
bb21:
  %t81 = load ptr, ptr %l9, !tbaa !29
  %t83 = getelementptr %"compiler/load:Module", ptr %t81, i32 0, i32 3
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l54, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l54, !tbaa !21
  store i1 %t86, ptr %l11, !tbaa !21
  %t87 = load i1, ptr %l5, !tbaa !21
  br i1 %t87, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb25
bb24:
  %t89 = load i1, ptr %l11, !tbaa !21
  store i1 %t89, ptr %l58, !tbaa !21
  br label %bb25
bb25:
  %t91 = load i1, ptr %l58, !tbaa !21
  br i1 %t91, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb29
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/names:Resolver", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/load:Loader", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t102 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v0, ptr %t98, { i64, ptr } %t99)
  store i1 %t102, ptr %l65
  br label %bb28
bb28:
  %t103 = load i1, ptr %l65, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l60, !tbaa !21
  br label %bb29
bb29:
  %t106 = load i1, ptr %l60, !tbaa !21
  br i1 %t106, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/names:Resolver", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/load:Loader", ptr %t110, i32 0, i32 4
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l69, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i64, ptr %l1, !tbaa !24
  %t116 = load %"compiler/source:Span", ptr %l3
  %t120 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t114, i64 %t115, %"compiler/source:Span" %t116)
  store { i64, [3 x i64] } %t120, ptr %l73
  br label %bb32
bb31:
  %t121 = load i1, ptr %l4, !tbaa !21
  br i1 %t121, label %bb36, label %bb37
bb32:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l2, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s4, ptr %t123, i32 %t124)
  store { i64, ptr } %t127, ptr %l76
  br label %bb33
bb33:
  %t128 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildConstRedeclared(ptr %s4, ptr %s4, { i64, ptr } %t134)
  store %"compiler/msgs:Msg" %t136, ptr %l78
  br label %bb34
bb34:
  %t137 = load ptr, ptr %l69, !tbaa !29
  %t138 = load { i64, [3 x i64] }, ptr %l73
  %t139 = load %"compiler/msgs:Msg", ptr %l78
  %t140 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t137, { i64, [3 x i64] } %t138, %"compiler/msgs:Msg" %t139)
  store i64 %t140, ptr %l79
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/names:Resolver", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/load:Loader", ptr %t144, i32 0, i32 4
  %t147 = load ptr, ptr %t146, !tbaa !29
  store ptr %t147, ptr %l83, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i64, ptr %l1, !tbaa !24
  %t150 = load %"compiler/source:Span", ptr %l3
  %t154 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t148, i64 %t149, %"compiler/source:Span" %t150)
  store { i64, [3 x i64] } %t154, ptr %l87
  br label %bb38
bb37:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l1, !tbaa !24
  %t157 = load i32, ptr %l2, !tbaa !23
  %t158 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebuildDefault(ptr %v0, ptr %v1, ptr %t155, i64 %t156, i32 %t157, %"compiler/source:Span" %t158, ptr %a7)
  br label %bb42
bb38:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i32, ptr %l2, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s6, ptr %t165, i32 %t166)
  store { i64, ptr } %t169, ptr %l90
  br label %bb39
bb39:
  %t170 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t172 = extractvalue { i64, ptr } %t170, 1
  %t173 = mul i64 %t171, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  %t178 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultMut(ptr %s6, ptr %s6, { i64, ptr } %t176)
  store %"compiler/msgs:Msg" %t178, ptr %l92
  br label %bb40
bb40:
  %t179 = load ptr, ptr %l83, !tbaa !29
  %t180 = load { i64, [3 x i64] }, ptr %l87
  %t181 = load %"compiler/msgs:Msg", ptr %l92
  %t182 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s6, ptr %t179, { i64, [3 x i64] } %t180, %"compiler/msgs:Msg" %t181)
  store i64 %t182, ptr %l93
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb45:
  %t183 = load ptr, ptr %l8, !tbaa !29
  %t185 = getelementptr %"compiler/names:Table", ptr %t183, i32 0, i32 1
  %t186 = load i32, ptr %l2, !tbaa !23
  %t189 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t185, i32 %t186)
  %t190 = extractvalue { i32, i64 } %t189, 1
  %t191 = extractvalue { i32, i64 } %t189, 0
  store i32 %t191, ptr %l104
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb47, label %ok.193
ok.193:
  store i64 %t190, ptr %l103
  br label %bb46
bb46:
  %t194 = load i64, ptr %l103, !tbaa !24
  store i64 %t194, ptr %l99, !tbaa !24
  br label %bb49
bb47:
  br label %bb48
bb48:
  store i64 -1, ptr %l99, !tbaa !24
  br label %bb49
bb49:
  %t195 = load i64, ptr %l99, !tbaa !24
  store i64 %t195, ptr %l12, !tbaa !24
  %t196 = load i64, ptr %l12, !tbaa !24
  %t198 = icmp sge i64 %t196, 0
  br i1 %t198, label %bb50, label %bb51
bb50:
  %t200 = load i1, ptr %l5, !tbaa !21
  br i1 %t200, label %bb52, label %bb53
bb51:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb57
bb52:
  %t202 = load ptr, ptr %l8, !tbaa !29
  %t204 = getelementptr %"compiler/names:Table", ptr %t202, i32 0, i32 0
  %t205 = load i64, ptr %l12, !tbaa !24
  %t208 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s0, ptr %t204, i64 %t205)
  store %"compiler/names:Entry" %t208, ptr %l113
  br label %bb54
bb53:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb56
bb54:
  %t209 = getelementptr %"compiler/names:Entry", ptr %l113, i32 0, i32 2
  %t210 = load i32, ptr %t209
  store i32 %t210, ptr %l114
  store i32 3, ptr %l116
  %t213 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l114, ptr %l116)
  store i1 %t213, ptr %l118
  br label %bb55
bb55:
  %t214 = load i1, ptr %l118, !tbaa !21
  store i1 %t214, ptr %l109, !tbaa !21
  br label %bb56
bb56:
  %t215 = load i1, ptr %l109, !tbaa !21
  %t216 = xor i1 %t215, true
  store i1 %t216, ptr %l107, !tbaa !21
  br label %bb57
bb57:
  %t218 = load i1, ptr %l107, !tbaa !21
  br i1 %t218, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s8
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/names:Resolver", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/load:Loader", ptr %t222, i32 0, i32 4
  %t225 = load ptr, ptr %t224, !tbaa !29
  store ptr %t225, ptr %l122, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i64, ptr %l1, !tbaa !24
  %t228 = load %"compiler/source:Span", ptr %l3
  %t232 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t226, i64 %t227, %"compiler/source:Span" %t228)
  store { i64, [3 x i64] } %t232, ptr %l126
  br label %bb60
bb59:
  br label %bb64
bb60:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l2, !tbaa !23
  %t237 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s8, ptr %t233, i32 %t234)
  store { i64, ptr } %t237, ptr %l129
  br label %bb61
bb61:
  %t238 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 0
  %t240 = extractvalue { i64, ptr } %t238, 1
  %t241 = mul i64 %t239, 1
  %t242 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t241)
  call void @llvm.memcpy.p0.p0.i64(ptr %t242, ptr %t240, i64 %t241, i1 false)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  %t246 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameInUse(ptr %s8, ptr %s8, { i64, ptr } %t244)
  store %"compiler/msgs:Msg" %t246, ptr %l131
  br label %bb62
bb62:
  %t247 = load ptr, ptr %l122, !tbaa !29
  %t248 = load { i64, [3 x i64] }, ptr %l126
  %t249 = load %"compiler/msgs:Msg", ptr %l131
  %t250 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t247, { i64, [3 x i64] } %t248, %"compiler/msgs:Msg" %t249)
  store i64 %t250, ptr %l132
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb64:
  %t251 = load i64, ptr %l12, !tbaa !24
  %t253 = icmp slt i64 %t251, 0
  br i1 %t253, label %bb65, label %bb66
bb65:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l1, !tbaa !24
  %t257 = load i32, ptr %l2, !tbaa !23
  %t258 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t255, i64 %t256, i32 %t257, %"compiler/source:Span" %t258)
  br label %bb67
bb66:
  br label %bb97
bb67:
  %t263 = load i32, ptr %l2, !tbaa !23
  %t265 = load ptr, ptr %l8, !tbaa !29
  %t267 = getelementptr %"compiler/names:Table", ptr %t265, i32 0, i32 2
  %t271 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t267, i32 %t263)
  store i1 %t271, ptr %l143
  br label %bb68
bb68:
  %t272 = load i1, ptr %l143, !tbaa !21
  br i1 %t272, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb72
bb70:
  %t273 = load i32, ptr %l2, !tbaa !23
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/names:Resolver", ptr %t275, i32 0, i32 2
  %t281 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t277, i32 %t273)
  store i1 %t281, ptr %l149
  br label %bb71
bb71:
  %t282 = load i1, ptr %l149, !tbaa !21
  store i1 %t282, ptr %l144, !tbaa !21
  br label %bb72
bb72:
  %t283 = load i1, ptr %l144, !tbaa !21
  br i1 %t283, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb76
bb74:
  %t284 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t286 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t284)
  store i1 %t286, ptr %l152
  br label %bb75
bb75:
  %t287 = load i1, ptr %l152, !tbaa !21
  store i1 %t287, ptr %l150, !tbaa !21
  br label %bb76
bb76:
  %t288 = load i1, ptr %l150, !tbaa !21
  br i1 %t288, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s10
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/names:Resolver", ptr %t289, i32 0, i32 0
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = getelementptr %"compiler/load:Loader", ptr %t292, i32 0, i32 4
  %t295 = load ptr, ptr %t294, !tbaa !29
  store ptr %t295, ptr %l155, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load i64, ptr %l1, !tbaa !24
  %t298 = load %"compiler/source:Span", ptr %l3
  %t302 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t296, i64 %t297, %"compiler/source:Span" %t298)
  store { i64, [3 x i64] } %t302, ptr %l159
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l2, !tbaa !23
  %t307 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s10, ptr %t303, i32 %t304)
  store { i64, ptr } %t307, ptr %l162
  br label %bb80
bb80:
  %t308 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  %t310 = extractvalue { i64, ptr } %t308, 1
  %t311 = mul i64 %t309, 1
  %t312 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t311)
  call void @llvm.memcpy.p0.p0.i64(ptr %t312, ptr %t310, i64 %t311, i1 false)
  %t313 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  %t316 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameIsType(ptr %s10, ptr %s10, { i64, ptr } %t314)
  store %"compiler/msgs:Msg" %t316, ptr %l164
  br label %bb81
bb81:
  %t317 = load ptr, ptr %l155, !tbaa !29
  %t318 = load { i64, [3 x i64] }, ptr %l159
  %t319 = load %"compiler/msgs:Msg", ptr %l164
  %t320 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t317, { i64, [3 x i64] } %t318, %"compiler/msgs:Msg" %t319)
  store i64 %t320, ptr %l165
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s10)
  br label %bb83
bb83:
  %t321 = load ptr, ptr %l9, !tbaa !29
  %t323 = getelementptr %"compiler/load:Module", ptr %t321, i32 0, i32 3
  %t324 = load i1, ptr %t323, !tbaa !21
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb84, label %bb85
bb84:
  %t328 = load i32, ptr %l2, !tbaa !23
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/names:Resolver", ptr %t330, i32 0, i32 3
  %t336 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H6d33fbc050830e537410645e3c893b2c(ptr %v0, ptr %t332, i32 %t328)
  store i1 %t336, ptr %l174
  br label %bb86
bb85:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb87
bb86:
  %t337 = load i1, ptr %l174, !tbaa !21
  store i1 %t337, ptr %l169, !tbaa !21
  br label %bb87
bb87:
  %t338 = load i1, ptr %l169, !tbaa !21
  br i1 %t338, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s11
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/names:Resolver", ptr %t339, i32 0, i32 0
  %t342 = load ptr, ptr %t341, !tbaa !29
  %t344 = getelementptr %"compiler/load:Loader", ptr %t342, i32 0, i32 4
  %t345 = load ptr, ptr %t344, !tbaa !29
  store ptr %t345, ptr %l177, !tbaa !29
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i64, ptr %l1, !tbaa !24
  %t348 = load %"compiler/source:Span", ptr %l3
  %t352 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t346, i64 %t347, %"compiler/source:Span" %t348)
  store { i64, [3 x i64] } %t352, ptr %l181
  br label %bb90
bb89:
  br label %bb94
bb90:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load i32, ptr %l2, !tbaa !23
  %t357 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s11, ptr %t353, i32 %t354)
  store { i64, ptr } %t357, ptr %l184
  br label %bb91
bb91:
  %t358 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  %t360 = extractvalue { i64, ptr } %t358, 1
  %t361 = mul i64 %t359, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t361)
  call void @llvm.memcpy.p0.p0.i64(ptr %t362, ptr %t360, i64 %t361, i1 false)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  %t366 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePreludeConstRedeclared(ptr %s11, ptr %s11, { i64, ptr } %t364)
  store %"compiler/msgs:Msg" %t366, ptr %l186
  br label %bb92
bb92:
  %t367 = load ptr, ptr %l177, !tbaa !29
  %t368 = load { i64, [3 x i64] }, ptr %l181
  %t369 = load %"compiler/msgs:Msg", ptr %l186
  %t370 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s11, ptr %t367, { i64, [3 x i64] } %t368, %"compiler/msgs:Msg" %t369)
  store i64 %t370, ptr %l187
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s11)
  br label %bb94
bb94:
  %t371 = load ptr, ptr %l8, !tbaa !29
  %t373 = getelementptr %"compiler/names:Table", ptr %t371, i32 0, i32 1
  store ptr %t373, ptr %l189, !tbaa !29
  %t374 = load i32, ptr %l2, !tbaa !23
  store i32 %t374, ptr %l190, !tbaa !23
  %t375 = load ptr, ptr %l8, !tbaa !29
  %t377 = getelementptr %"compiler/names:Table", ptr %t375, i32 0, i32 0
  %t379 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t377)
  store i64 %t379, ptr %l193
  br label %bb95
bb95:
  %t380 = load ptr, ptr %l189, !tbaa !29
  %t381 = load i32, ptr %l190, !tbaa !23
  %t382 = load i64, ptr %l193, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t380, i32 %t381, i64 %t382)
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t383 = load ptr, ptr %l8, !tbaa !29
  %t385 = getelementptr %"compiler/names:Table", ptr %t383, i32 0, i32 0
  store ptr %t385, ptr %l195, !tbaa !29
  %t386 = load i32, ptr %l2, !tbaa !23
  store i32 %t386, ptr %l196, !tbaa !23
  %t387 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t387, ptr %l197
  %t388 = load i1, ptr %l5, !tbaa !21
  br i1 %t388, label %bb98, label %bb99
bb98:
  store i32 3, ptr %l199
  br label %bb100
bb99:
  store i32 2, ptr %l199
  br label %bb100
bb100:
  %t392 = load i1, ptr %l4, !tbaa !21
  %t393 = load i32, ptr %l196, !tbaa !23
  %t394 = load %"compiler/source:Span", ptr %l197
  %t395 = load i32, ptr %l199
  %t397 = call %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v0, ptr %v0, i32 %t393, %"compiler/source:Span" %t394, i32 %t395, i1 %t392, ptr null)
  store %"compiler/names:Entry" %t397, ptr %l203
  br label %bb101
bb101:
  %t398 = load ptr, ptr %l195, !tbaa !29
  %t399 = load %"compiler/names:Entry", ptr %l203
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t398, %"compiler/names:Entry" %t399)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHead(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/names:Ref"
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i32
  %l9 = alloca i32
  %l11 = alloca i1
  %l16 = alloca i32
  %l18 = alloca i32
  %l20 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/names:Ref" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/names:Ref", ptr %l6
  store %"compiler/names:Ref" %t6, ptr %l3
  %t7 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l7
  store i32 5, ptr %l9
  %t11 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l7, ptr %l9)
  store i1 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i1, ptr %l11, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  %t15 = load %"compiler/names:Ref", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t13, %"compiler/source:Span" %t14, %"compiler/names:Ref" %t15)
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
bb6:
  %t22 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l16
  store i32 0, ptr %l18
  %t26 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l16, ptr %l18)
  store i1 %t26, ptr %l20
  br label %bb7
bb7:
  %t27 = load i1, ptr %l20, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  %t30 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %t28, %"compiler/source:Span" %t29, i32 %t30)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHop(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca i64
  %l17 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i32
  %l28 = alloca { i64, ptr }
  %l30 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i64
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, [3 x i64] }
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/msgs:Msg"
  %l51 = alloca i64
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasTarget(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/names:Resolver", ptr %t12, i32 0, i32 1
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t21 = getelementptr %"compiler/names:Table", ptr %t19, i32 0, i32 3
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t21, i32 %t22)
  %t26 = extractvalue { i32, i64 } %t25, 1
  %t27 = extractvalue { i32, i64 } %t25, 0
  store i32 %t27, ptr %l22
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb7, label %ok.29
ok.29:
  store i64 %t26, ptr %l21
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l13, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb9
bb9:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l28
  br label %bb13
bb13:
  %t42 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t42, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t43)
  store i1 %t45, ptr %l30
  br label %bb14
bb14:
  %t46 = load i1, ptr %l30, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/names:Resolver", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l34, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l35, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/names:Resolver", ptr %t57, i32 0, i32 6
  %t60 = load i64, ptr %t59, !tbaa !24
  store i64 %t60, ptr %l37, !tbaa !24
  %t61 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t67 = trunc i64 %t65 to i32
  %t70 = sub i32 %t62, %t67
  %t71 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t72 = load i32, ptr %t71, !tbaa !23
  %t75 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t70, i32 %t72)
  store %"compiler/source:Span" %t75, ptr %l44
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t76 = load ptr, ptr %l35, !tbaa !29
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = load %"compiler/source:Span", ptr %l44
  %t79 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t76, i64 %t77, %"compiler/source:Span" %t78)
  store { i64, [3 x i64] } %t79, ptr %l45
  br label %bb18
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l3, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s3, ptr %t80, i32 %t81)
  store { i64, ptr } %t84, ptr %l48
  br label %bb19
bb19:
  %t85 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportIsPrivate(ptr %s3, ptr %s3, { i64, ptr } %t91)
  store %"compiler/msgs:Msg" %t93, ptr %l50
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l34, !tbaa !29
  %t95 = load { i64, [3 x i64] }, ptr %l45
  %t96 = load %"compiler/msgs:Msg", ptr %l50
  %t97 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t94, { i64, [3 x i64] } %t95, %"compiler/msgs:Msg" %t96)
  store i64 %t97, ptr %l51
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb22:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/names:Resolver", ptr %t99, i32 0, i32 5
  store ptr %t101, ptr %l54, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/names:Resolver", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/load:Loader", ptr %t105, i32 0, i32 5
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/names:Resolver", ptr %t108, i32 0, i32 6
  %t111 = load i64, ptr %t110, !tbaa !24
  %t114 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t107, i64 %t111)
  store ptr %t114, ptr %l60
  br label %bb23
bb23:
  %t115 = load ptr, ptr %l60, !tbaa !29
  %t117 = getelementptr %"compiler/load:Module", ptr %t115, i32 0, i32 4
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t120 = load i32, ptr %t119, !tbaa !23
  %t123 = call i64 @compiler_2fnames_2ekey(i64 %t118, i32 %t120)
  store i64 %t123, ptr %l64
  br label %bb24
bb24:
  %t124 = load i64, ptr %l5, !tbaa !24
  %t127 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 5, i64 %t124, i64 -1)
  store %"compiler/names:Ref" %t127, ptr %l67
  br label %bb25
bb25:
  %t128 = load ptr, ptr %l54, !tbaa !29
  %t129 = load i64, ptr %l64, !tbaa !24
  %t130 = load %"compiler/names:Ref", ptr %l67
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t128, i64 %t129, %"compiler/names:Ref" %t130)
  br label %bb26
bb26:
  %t131 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasModule(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l39 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i32
  %l56 = alloca i1
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t10 = sub i64 %t8, 1
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb3:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb5
bb5:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l8, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/names:Resolver", ptr %t58, i32 0, i32 1
  %t61 = load i64, ptr %l2, !tbaa !24
  %t64 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store ptr %t64, ptr %l43
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l43, !tbaa !29
  %t67 = getelementptr %"compiler/names:Table", ptr %t65, i32 0, i32 3
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l46, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 %t69
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t67, i32 %t74)
  %t78 = extractvalue { i32, i64 } %t77, 1
  %t79 = extractvalue { i32, i64 } %t77, 0
  store i32 %t79, ptr %l50
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb13, label %ok.81
ok.81:
  store i64 %t78, ptr %l49
  br label %bb12
bb12:
  %t82 = load i64, ptr %l49, !tbaa !24
  store i64 %t82, ptr %l39, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l39, !tbaa !24
  br label %bb15
bb15:
  %t83 = load i64, ptr %l39, !tbaa !24
  store i64 %t83, ptr %l9, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t94, ptr %l58, !tbaa !27
  %t95 = load i64, ptr %l8, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t103 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t93, i32 %t100)
  store { i64, ptr } %t103, ptr %l61
  br label %bb21
bb20:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb23
bb21:
  %t104 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t105 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t104)
  store i1 %t105, ptr %l62
  br label %bb22
bb22:
  %t106 = load i1, ptr %l62, !tbaa !21
  %t107 = xor i1 %t106, true
  store i1 %t107, ptr %l56, !tbaa !21
  br label %bb23
bb23:
  %t109 = load i1, ptr %l56, !tbaa !21
  br i1 %t109, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t111 = load i64, ptr %l9, !tbaa !24
  store i64 %t111, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l7, !tbaa !24
  br label %bb7
bb28:
  %t117 = load i64, ptr %l2, !tbaa !24
  store i64 %t117, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l34 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  %t24 = load i32, ptr %l3, !tbaa !23
  %t28 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHead(ptr %v0, ptr %t22, %"compiler/source:Span" %t23, i32 %t24)
  store i64 %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = load i64, ptr %l19, !tbaa !24
  store i64 %t29, ptr %l7, !tbaa !24
  br label %bb19
bb7:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = load i64, ptr %t34
  %t37 = icmp eq i64 %t35, 15
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t41, i32 0, i32 0
  %t43 = load %"compiler/source:Span", ptr %t42
  store %"compiler/source:Span" %t43, ptr %l4
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l5, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t53, i32 0, i32 2
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l6, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l4
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  %t65 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHop(ptr %v0, ptr %v1, ptr %t57, %"compiler/source:Span" %t58, ptr %t59, i32 %t60)
  store i64 %t65, ptr %l34
  br label %bb13
bb13:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb19:
  %t67 = load i64, ptr %l7, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasesOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/load:Import"
  %l12 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l33 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l44 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l12, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 5
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l17
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t21 = getelementptr %"compiler/load:Module", ptr %t19, i32 0, i32 11
  store ptr %t21, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t23, i64 %t24)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l24
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31
ok.31:
  store { i64, ptr } %t28, ptr %l23
  br label %bb4
bb4:
  %t32 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t32, ptr %l20, !tbaa !27
  br label %bb9
bb5:
  %t33 = load i32, ptr %l24, !tbaa !23
  %t34 = ashr i32 %t33, 16
  %t36 = icmp eq i32 %t34, 1
  br i1 %t36, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb9:
  %t38 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr %"compiler/load:Import", ptr %t55, i64 %t52
  %t57 = load %"compiler/load:Import", ptr %t56
  store %"compiler/load:Import" %t57, ptr %l8
  %t59 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 5
  %t60 = load i64, ptr %t59, !tbaa !24
  %t62 = icmp sge i64 %t60, 0
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/names:Table", ptr %t64, i32 0, i32 3
  store ptr %t66, ptr %l39, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/names:Resolver", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/load:Loader", ptr %t70, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 2
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  %t78 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t73, { i64, ptr } %t75)
  store i32 %t78, ptr %l44
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t79 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 5
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = load ptr, ptr %l39, !tbaa !29
  %t82 = load i32, ptr %l44, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t81, i32 %t82, i64 %t80)
  br label %bb17
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t84 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l7, !tbaa !24
  br label %bb10
bb20:
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = add i64 %t88, %t89
  store i64 %t92, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb3
bb22:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %rv = alloca { i64, [3 x i64] }
  %t23 = alloca { i64, [3 x i64] }, align 8
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t10 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 4
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t19 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = sext i32 %t20 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t23, i32 0, i32 0
  store i64 3, ptr %t24
  %t26 = insertvalue { i64, i64, i64 } undef, i64 %t14, 0
  %t28 = insertvalue { i64, i64, i64 } %t26, i64 %t18, 1
  %t30 = insertvalue { i64, i64, i64 } %t28, i64 %t22, 2
  %t31 = getelementptr { i64, [3 x i64] }, ptr %t23, i32 0, i32 1
  store { i64, i64, i64 } %t30, ptr %t31
  %t32 = load { i64, [3 x i64] }, ptr %t23
  store { i64, [3 x i64] } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l18 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca %"compiler/names:local"
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 8
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l11
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l10
  br label %bb1
bb1:
  %t12 = load i64, ptr %l10, !tbaa !24
  store i64 %t12, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/names:Resolver", ptr %t14, i32 0, i32 9
  store ptr %t16, ptr %l13, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t21 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s0, i32 %t17, i64 %t13)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l16
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H00be49c2f1e120c94602e8686f44be2a(ptr %v0, ptr %t22, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t23)
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/names:Resolver", ptr %t24, i32 0, i32 8
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l19, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/names:Resolver", ptr %t28, i32 0, i32 7
  %t32 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l22
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i32, ptr %l19, !tbaa !23
  %t35 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t33, i32 %t34, i64 %t35)
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/names:Resolver", ptr %t36, i32 0, i32 7
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load i32, ptr %l1, !tbaa !23
  %t45 = call %"compiler/names:local" @compiler_2fnames_3alocal_2ector(ptr %s0, i32 %t39, %"compiler/source:Span" %a2, i32 %a3)
  store %"compiler/names:local" %t45, ptr %l28
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = load %"compiler/names:local", ptr %l28
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2ePush_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t46, %"compiler/names:local" %t47)
  br label %bb10
bb10:
  %t48 = load i32, ptr %l1, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/names:Resolver", ptr %t50, i32 0, i32 10
  %t56 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t52, i32 %t48)
  store i1 %t56, ptr %l33
  br label %bb11
bb11:
  %t57 = load i1, ptr %l33, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/names:Resolver", ptr %t60, i32 0, i32 10
  %t63 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t62, i32 %t63)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i64
  %l18 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = extractvalue { i64, ptr } zeroinitializer, 0
  %t5 = icmp eq i64 %t3, %t4
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } zeroinitializer, 1
  %t8 = icmp eq ptr %t6, %t7
  %t9 = and i1 %t5, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l10
  br label %bb4
bb4:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t29, ptr %l18, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr ptr, ptr %t33, i64 %t30
  %t35 = load ptr, ptr %t34, !tbaa !39
  %t37 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t37, ptr %t35)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l4, !tbaa !24
  br label %bb5
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t45, i64 %t46)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i64
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l105 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l113 = alloca i1
  %s2 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l25, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  store ptr %t23, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t24 = load ptr, ptr %l28, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l28, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 7
  store i1 %t30, ptr %l29, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l29, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l7, !tbaa !29
  br label %bb9
bb8:
  br label %bb18
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/names:Resolver", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l35, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  store i64 %t42, ptr %l36, !tbaa !24
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TopIf", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t46)
  store %"compiler/source:Span" %t48, ptr %l39
  br label %bb10
bb10:
  %t49 = getelementptr %"compiler/source:Span", ptr %l39, i32 0, i32 0
  %t50 = load i32, ptr %t49, !tbaa !23
  %t51 = load ptr, ptr %l35, !tbaa !29
  %t52 = load i64, ptr %l36, !tbaa !24
  %t54 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t51, i64 %t52, i32 %t50)
  store i64 %t54, ptr %l41
  br label %bb11
bb11:
  %t55 = load i64, ptr %l41, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l8, !tbaa !24
  %t57 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t60 = icmp eq i64 %t56, %t57
  br i1 %t60, label %bb12, label %bb13
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t62, i64 %t63)
  br label %bb14
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = load ptr, ptr %l7, !tbaa !29
  %t69 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodiesIf(ptr %v0, ptr %v1, ptr %t66, i64 %t67, ptr %t68, i64 %t69, i64 0)
  br label %bb16
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etopConds(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  br label %bb15
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb69
bb18:
  %t78 = load ptr, ptr %l6, !tbaa !29
  store ptr %t78, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t79 = load ptr, ptr %l53, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t82 = load ptr, ptr %l53, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 0
  store i1 %t85, ptr %l54, !tbaa !21
  br label %bb20
bb20:
  %t86 = load i1, ptr %l54, !tbaa !21
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t87 = load ptr, ptr %l6, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { ptr }, ptr %t89, i32 0, i32 0
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l9, !tbaa !29
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t93, i64 %t94)
  br label %bb24
bb24:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efunc(ptr %v0, ptr %v1, ptr %t97, ptr %t98)
  br label %bb25
bb25:
  br label %bb69
bb26:
  %t101 = load ptr, ptr %l6, !tbaa !29
  store ptr %t101, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb27, label %bb28
bb27:
  %t105 = load ptr, ptr %l63, !tbaa !29
  %t106 = load i64, ptr %t105
  %t108 = icmp eq i64 %t106, 1
  store i1 %t108, ptr %l64, !tbaa !21
  br label %bb28
bb28:
  %t109 = load i1, ptr %l64, !tbaa !21
  br i1 %t109, label %bb29, label %bb30
bb29:
  %t110 = load ptr, ptr %l6, !tbaa !29
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { ptr }, ptr %t112, i32 0, i32 0
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l10, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t116, i64 %t117)
  br label %bb32
bb32:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t120, ptr %t121, i1 false)
  br label %bb33
bb33:
  br label %bb69
bb34:
  %t124 = load ptr, ptr %l6, !tbaa !29
  store ptr %t124, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t125 = load ptr, ptr %l73, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb35, label %bb36
bb35:
  %t128 = load ptr, ptr %l73, !tbaa !29
  %t129 = load i64, ptr %t128
  %t131 = icmp eq i64 %t129, 2
  store i1 %t131, ptr %l74, !tbaa !21
  br label %bb36
bb36:
  %t132 = load i1, ptr %l74, !tbaa !21
  br i1 %t132, label %bb37, label %bb38
bb37:
  %t133 = load ptr, ptr %l6, !tbaa !29
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", ptr }, ptr %t135, i32 0, i32 1
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l11, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t139, i64 %t140)
  br label %bb40
bb40:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeDecl(ptr %v0, ptr %v1, ptr %t143, ptr %t144)
  br label %bb41
bb41:
  br label %bb69
bb42:
  %t147 = load ptr, ptr %l6, !tbaa !29
  store ptr %t147, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t148 = load ptr, ptr %l83, !tbaa !29
  %t149 = icmp ne ptr %t148, null
  br i1 %t149, label %bb43, label %bb44
bb43:
  %t151 = load ptr, ptr %l83, !tbaa !29
  %t152 = load i64, ptr %t151
  %t154 = icmp eq i64 %t152, 3
  store i1 %t154, ptr %l84, !tbaa !21
  br label %bb44
bb44:
  %t155 = load i1, ptr %l84, !tbaa !21
  br i1 %t155, label %bb45, label %bb46
bb45:
  %t156 = load ptr, ptr %l6, !tbaa !29
  %t158 = getelementptr { i64, [4 x i64] }, ptr %t156, i32 0, i32 1
  %t159 = getelementptr { %"compiler/source:Span", ptr }, ptr %t158, i32 0, i32 1
  %t160 = load ptr, ptr %t159
  store ptr %t160, ptr %l12, !tbaa !29
  br label %bb47
bb46:
  br label %bb60
bb47:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t162, i64 %t163)
  br label %bb48
bb48:
  %t166 = load ptr, ptr %l12, !tbaa !29
  %t168 = getelementptr %"compiler/ast:VarDecl", ptr %t166, i32 0, i32 2
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = icmp ne ptr %t169, null
  br i1 %t171, label %bb49, label %bb50
bb49:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l12, !tbaa !29
  %t176 = getelementptr %"compiler/ast:VarDecl", ptr %t174, i32 0, i32 2
  %t177 = load ptr, ptr %t176, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t173, ptr %t177)
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  %t180 = load ptr, ptr %l12, !tbaa !29
  %t182 = getelementptr %"compiler/ast:VarDecl", ptr %t180, i32 0, i32 3
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t185 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t185, 0
  store i64 %t187, ptr %l15, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  %t189 = load i64, ptr %l14, !tbaa !24
  %t190 = load i64, ptr %l15, !tbaa !24
  %t193 = icmp slt i64 %t189, %t190
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s12)
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t197 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t197, ptr %l105, !tbaa !27
  %t198 = load i64, ptr %l14, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr ptr, ptr %t201, i64 %t198
  %t203 = load ptr, ptr %t202, !tbaa !39
  %t205 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t205, ptr %t203)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s12)
  br label %bb58
bb58:
  %t209 = load i64, ptr %l14, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l14, !tbaa !24
  br label %bb53
bb59:
  br label %bb69
bb60:
  %t213 = load ptr, ptr %l6, !tbaa !29
  store ptr %t213, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t214 = load ptr, ptr %l112, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb61, label %bb62
bb61:
  %t217 = load ptr, ptr %l112, !tbaa !29
  %t218 = load i64, ptr %t217
  %t220 = icmp eq i64 %t218, 6
  store i1 %t220, ptr %l113, !tbaa !21
  br label %bb62
bb62:
  %t221 = load i1, ptr %l113, !tbaa !21
  br i1 %t221, label %bb63, label %bb64
bb63:
  %t222 = load ptr, ptr %l6, !tbaa !29
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t224, i32 0, i32 2
  %t226 = load { i64, ptr }, ptr %t225
  store { i64, ptr } %t226, ptr %l17, !tbaa !27
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t228, i64 %t229)
  br label %bb66
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t232, { i64, ptr } %t233)
  br label %bb67
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb70:
  %t236 = load i64, ptr %l4, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l4, !tbaa !24
  br label %bb1
bb71:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodiesIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TopBranch", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t16 = extractvalue { i64, ptr } zeroinitializer, 0
  %t17 = icmp eq i64 %t15, %t16
  %t18 = extractvalue { i64, ptr } %t13, 1
  %t19 = extractvalue { i64, ptr } zeroinitializer, 1
  %t20 = icmp eq ptr %t18, %t19
  %t21 = and i1 %t17, %t20
  %t22 = xor i1 %t21, true
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t24 = load i1, ptr %l8, !tbaa !21
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TopIf", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TopBranch", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %t25, i64 %t26, { i64, ptr } %t33)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp ne ptr %t40, null
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TopIf", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodiesIf(ptr %v0, ptr %v1, ptr %t44, i64 %t45, ptr %t49, i64 %t50, i64 %t53)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TopIf", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp ne ptr %t62, null
  br i1 %t64, label %bb12, label %bb13
bb12:
  %t66 = load i64, ptr %l3, !tbaa !24
  %t67 = load i64, ptr %l4, !tbaa !24
  %t69 = add i64 %t67, 1
  %t72 = icmp eq i64 %t66, %t69
  store i1 %t72, ptr %l31, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t74 = load i1, ptr %l31, !tbaa !21
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = getelementptr %"compiler/ast:TopIf", ptr %t75, i32 0, i32 3
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/ast:TopBranch", ptr %t78, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } zeroinitializer, 0
  %t85 = icmp eq i64 %t83, %t84
  %t86 = extractvalue { i64, ptr } %t81, 1
  %t87 = extractvalue { i64, ptr } zeroinitializer, 1
  %t88 = icmp eq ptr %t86, %t87
  %t89 = and i1 %t85, %t88
  %t90 = xor i1 %t89, true
  store i1 %t90, ptr %l36, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t92 = load i1, ptr %l36, !tbaa !21
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l1, !tbaa !24
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr %"compiler/ast:TopIf", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/ast:TopBranch", ptr %t98, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %t93, i64 %t94, { i64, ptr } %t101)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/names:Resolver", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 4
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Branch", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t14, i64 %t18)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Branch", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t21, { i64, ptr } %t25)
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Branch", ptr %t28, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = icmp sge i64 %t31, 0
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/names:Resolver", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/load:Loader", ptr %t38, i32 0, i32 4
  %t41 = load ptr, ptr %t40, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t41)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebuildDefault(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca %"compiler/source:Span"
  %l28 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca i64
  %l34 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca i64
  %l56 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l62 = alloca i1
  %l64 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l82 = alloca ptr
  %l86 = alloca { i64, [3 x i64] }
  %l89 = alloca { i64, ptr }
  %l92 = alloca %"compiler/msgs:Msg"
  %l93 = alloca i64
  %l96 = alloca { i64, ptr }
  %l102 = alloca i1
  %l106 = alloca ptr
  %l110 = alloca { i64, [3 x i64] }
  %l111 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l123 = alloca %"compiler/msgs:Msg"
  %l124 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d20 }, ptr %l9, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t5, ptr %l10, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l11, !tbaa !24
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l12, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t19, ptr %l5, !tbaa !27
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:VarDecl", ptr %t20, i32 0, i32 2
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp ne ptr %t23, null
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/load:Loader", ptr %t30, i32 0, i32 5
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t32, i64 %t33)
  store ptr %t36, ptr %l20
  br label %bb6
bb5:
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/ast:VarDecl", ptr %t37, i32 0, i32 3
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t44 = icmp eq i64 %t42, 1
  br i1 %t44, label %bb18, label %bb19
bb6:
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t48 = getelementptr %"compiler/load:Module", ptr %t46, i32 0, i32 6
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/source:Source", ptr %t49, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l23, !tbaa !27
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t55 = getelementptr %"compiler/ast:VarDecl", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t56)
  store %"compiler/source:Span" %t58, ptr %l26
  br label %bb7
bb7:
  %t59 = getelementptr %"compiler/source:Span", ptr %l26, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = sext i32 %t60 to i64
  store i64 %t62, ptr %l28, !tbaa !24
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = getelementptr %"compiler/ast:VarDecl", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t66)
  store %"compiler/source:Span" %t68, ptr %l31
  br label %bb8
bb8:
  %t69 = getelementptr %"compiler/source:Span", ptr %l31, i32 0, i32 1
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = sext i32 %t70 to i64
  store i64 %t72, ptr %l33, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l34, !tbaa !24
  %t75 = load i64, ptr %l28, !tbaa !24
  %t76 = icmp sge i64 %t75, 0
  br i1 %t76, label %bb9, label %bb10
bb9:
  %t78 = load i64, ptr %l28, !tbaa !24
  %t79 = load i64, ptr %l33, !tbaa !24
  %t80 = icmp sle i64 %t78, %t79
  br i1 %t80, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb11:
  %t82 = load i64, ptr %l33, !tbaa !24
  %t83 = load i64, ptr %l34, !tbaa !24
  %t84 = icmp sle i64 %t82, %t83
  br i1 %t84, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb13:
  %t86 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = load i64, ptr %l28, !tbaa !24
  %t89 = load i64, ptr %l33, !tbaa !24
  %t90 = getelementptr i8, ptr %t87, i64 %t88
  %t91 = sub i64 %t89, %t88
  %t92 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t90, 1
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = extractvalue { i64, ptr } %t93, 0
  %t97 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t95, i64 %t96)
  %t98 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l39, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l41, !tbaa !24
  %t105 = load i64, ptr %l41, !tbaa !24
  %t106 = icmp eq i64 %t101, %t105
  br i1 %t106, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb15:
  %t108 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l41, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  br label %bb17
bb16:
  %t114 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t114, ptr %l5, !tbaa !27
  br label %bb17
bb17:
  br label %bb25
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t115 = load ptr, ptr %l4, !tbaa !29
  %t117 = getelementptr %"compiler/ast:VarDecl", ptr %t115, i32 0, i32 3
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l48, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr ptr, ptr %t120, i64 0
  %t122 = load ptr, ptr %t121, !tbaa !39
  %t124 = call { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v1, ptr %s5, ptr %t122)
  store { i64, ptr } %t124, ptr %l50
  br label %bb20
bb19:
  br label %bb24
bb20:
  %t125 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t127)
  call void @olang_textcopy(ptr %t128, ptr %t126, i64 %t127)
  %t129 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  store { i64, ptr } %t130, ptr %l51, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  %t133 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l53, !tbaa !24
  %t136 = load i64, ptr %l53, !tbaa !24
  %t137 = icmp eq i64 %t132, %t136
  br i1 %t137, label %bb21, label %bb22
bb21:
  %t139 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = load i64, ptr %l53, !tbaa !24
  %t144 = mul i64 %t143, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t140, ptr %t142, i64 %t144, i1 false)
  br label %bb23
bb22:
  %t145 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t145, ptr %l5, !tbaa !27
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t146 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t146, { i64, ptr } { i64 0, ptr @.d22 })
  store i1 %t148, ptr %l56
  br label %bb26
bb26:
  %t149 = load i1, ptr %l56, !tbaa !21
  br i1 %t149, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb28:
  br label %bb29
bb29:
  %t150 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t152 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t150, { i64, ptr } { i64 4, ptr @.d23 })
  store i1 %t152, ptr %l58
  br label %bb30
bb30:
  %t153 = load i1, ptr %l58, !tbaa !21
  %t154 = xor i1 %t153, true
  br i1 %t154, label %bb31, label %bb32
bb31:
  %t156 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t158 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t156, { i64, ptr } { i64 3, ptr @.d24 })
  store i1 %t158, ptr %l62
  br label %bb33
bb32:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb34
bb33:
  %t159 = load i1, ptr %l62, !tbaa !21
  %t160 = xor i1 %t159, true
  store i1 %t160, ptr %l60, !tbaa !21
  br label %bb34
bb34:
  %t162 = load i1, ptr %l60, !tbaa !21
  br i1 %t162, label %bb35, label %bb36
bb35:
  %t163 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t165 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t163, { i64, ptr } { i64 3, ptr @.d25 })
  store i1 %t165, ptr %l66
  br label %bb37
bb36:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb38
bb37:
  %t166 = load i1, ptr %l66, !tbaa !21
  %t167 = xor i1 %t166, true
  store i1 %t167, ptr %l64, !tbaa !21
  br label %bb38
bb38:
  %t169 = load i1, ptr %l64, !tbaa !21
  br i1 %t169, label %bb39, label %bb40
bb39:
  %t170 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t172 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t170, { i64, ptr } { i64 3, ptr @.d26 })
  store i1 %t172, ptr %l70
  br label %bb41
bb40:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb42
bb41:
  %t173 = load i1, ptr %l70, !tbaa !21
  %t174 = xor i1 %t173, true
  store i1 %t174, ptr %l68, !tbaa !21
  br label %bb42
bb42:
  %t176 = load i1, ptr %l68, !tbaa !21
  br i1 %t176, label %bb43, label %bb44
bb43:
  %t177 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t179 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t177, { i64, ptr } { i64 3, ptr @.d27 })
  store i1 %t179, ptr %l74
  br label %bb45
bb44:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb46
bb45:
  %t180 = load i1, ptr %l74, !tbaa !21
  %t181 = xor i1 %t180, true
  store i1 %t181, ptr %l72, !tbaa !21
  br label %bb46
bb46:
  %t183 = load i1, ptr %l72, !tbaa !21
  br i1 %t183, label %bb47, label %bb48
bb47:
  %t184 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t186 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t184, { i64, ptr } { i64 6, ptr @.d28 })
  store i1 %t186, ptr %l78
  br label %bb49
bb48:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb50
bb49:
  %t187 = load i1, ptr %l78, !tbaa !21
  %t188 = xor i1 %t187, true
  store i1 %t188, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t190 = load i1, ptr %l76, !tbaa !21
  br i1 %t190, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/names:Resolver", ptr %t191, i32 0, i32 0
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/load:Loader", ptr %t194, i32 0, i32 4
  %t197 = load ptr, ptr %t196, !tbaa !29
  store ptr %t197, ptr %l82, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i64, ptr %l1, !tbaa !24
  %t200 = load %"compiler/source:Span", ptr %l3
  %t204 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t198, i64 %t199, %"compiler/source:Span" %t200)
  store { i64, [3 x i64] } %t204, ptr %l86
  br label %bb53
bb52:
  br label %bb57
bb53:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l2, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s8, ptr %t205, i32 %t206)
  store { i64, ptr } %t209, ptr %l89
  br label %bb54
bb54:
  %t210 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  %t217 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t220 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultType(ptr %s8, ptr %s0, ptr %s8, { i64, ptr } %t216, { i64, ptr } %t217)
  store %"compiler/msgs:Msg" %t220, ptr %l92
  br label %bb55
bb55:
  %t221 = load ptr, ptr %l82, !tbaa !29
  %t222 = load { i64, [3 x i64] }, ptr %l86
  %t223 = load %"compiler/msgs:Msg", ptr %l92
  %t224 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t221, { i64, [3 x i64] } %t222, %"compiler/msgs:Msg" %t223)
  store i64 %t224, ptr %l93
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb57:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l2, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t225, i32 %t226)
  store { i64, ptr } %t229, ptr %l96
  br label %bb58
bb58:
  %t230 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t230, ptr %l6, !tbaa !27
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/names:Resolver", ptr %t231, i32 0, i32 0
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = getelementptr %"compiler/load:Loader", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t238 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t243 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFits(ptr %v0, ptr %v0, ptr %s0, ptr %t237, { i64, ptr } %t238, { i64, ptr } %t239)
  store i1 %t243, ptr %l102
  br label %bb59
bb59:
  %t244 = load i1, ptr %l102, !tbaa !21
  %t245 = xor i1 %t244, true
  br i1 %t245, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s9
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/names:Resolver", ptr %t247, i32 0, i32 0
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = getelementptr %"compiler/load:Loader", ptr %t250, i32 0, i32 4
  %t253 = load ptr, ptr %t252, !tbaa !29
  store ptr %t253, ptr %l106, !tbaa !29
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i64, ptr %l1, !tbaa !24
  %t256 = load %"compiler/source:Span", ptr %l3
  %t260 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t254, i64 %t255, %"compiler/source:Span" %t256)
  store { i64, [3 x i64] } %t260, ptr %l110
  br label %bb62
bb61:
  br label %bb67
bb62:
  %t261 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t261, ptr %l111, !tbaa !27
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/names:Resolver", ptr %t262, i32 0, i32 0
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = getelementptr %"compiler/load:Loader", ptr %t265, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t269 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t272 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v0, ptr %s9, ptr %t268, { i64, ptr } %t269)
  store { i64, ptr } %t272, ptr %l116
  br label %bb63
bb63:
  %t273 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 0
  %t275 = extractvalue { i64, ptr } %t273, 1
  %t276 = mul i64 %t274, 1
  %t277 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t276)
  call void @llvm.memcpy.p0.p0.i64(ptr %t277, ptr %t275, i64 %t276, i1 false)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  store { i64, ptr } %t279, ptr %l117, !tbaa !27
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i32, ptr %l2, !tbaa !23
  %t284 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s9, ptr %t280, i32 %t281)
  store { i64, ptr } %t284, ptr %l120
  br label %bb64
bb64:
  %t285 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 0
  %t287 = extractvalue { i64, ptr } %t285, 1
  %t288 = mul i64 %t286, 1
  %t289 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t288)
  call void @llvm.memcpy.p0.p0.i64(ptr %t289, ptr %t287, i64 %t288, i1 false)
  %t290 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t291 = insertvalue { i64, ptr } %t290, ptr %t289, 1
  %t292 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t293 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t294 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t297 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultFit(ptr %v0, ptr %s9, ptr %s9, ptr %s0, ptr %s9, { i64, ptr } %t293, { i64, ptr } %t294, { i64, ptr } %t291, { i64, ptr } %t292)
  store %"compiler/msgs:Msg" %t297, ptr %l123
  br label %bb65
bb65:
  %t298 = load ptr, ptr %l106, !tbaa !29
  %t299 = load { i64, [3 x i64] }, ptr %l110
  %t300 = load %"compiler/msgs:Msg", ptr %l123
  %t301 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t298, { i64, [3 x i64] } %t299, %"compiler/msgs:Msg" %t300)
  store i64 %t301, ptr %l124
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s9)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecaseOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i64, ptr %l13, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:Case", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = extractvalue { i64, ptr } zeroinitializer, 0
  %t12 = icmp eq i64 %t10, %t11
  %t13 = extractvalue { i64, ptr } %t8, 1
  %t14 = extractvalue { i64, ptr } zeroinitializer, 1
  %t15 = icmp eq ptr %t13, %t14
  %t16 = and i1 %t12, %t15
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr @__olang_prog_scope
  %t20 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %t19)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l17
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t21 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l3
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Case", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t39, ptr %l26, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  %t47 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epattern(ptr %v0, ptr %v1, ptr %s1, ptr %t47, ptr %t45, ptr %l3)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l5, !tbaa !24
  br label %bb5
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Case", ptr %t56, i32 0, i32 2
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = extractvalue { i64, ptr } zeroinitializer, 0
  %t63 = icmp eq i64 %t61, %t62
  %t64 = extractvalue { i64, ptr } %t59, 1
  %t65 = extractvalue { i64, ptr } zeroinitializer, 1
  %t66 = icmp eq ptr %t64, %t65
  %t67 = and i1 %t63, %t66
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Case", ptr %t70, i32 0, i32 2
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l10, !tbaa !24
  br label %bb15
bb14:
  br label %bb22
bb15:
  store %olang.scope zeroinitializer, ptr %s7
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s7)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t87 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t87, ptr %l45, !tbaa !27
  %t88 = load i64, ptr %l9, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr ptr, ptr %t91, i64 %t88
  %t93 = load ptr, ptr %t92, !tbaa !39
  %t95 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t95, ptr %t93)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s7)
  br label %bb20
bb20:
  %t99 = load i64, ptr %l9, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l9, !tbaa !24
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/ast:Case", ptr %t103, i32 0, i32 3
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = icmp ne ptr %t106, null
  br i1 %t108, label %bb23, label %bb24
bb23:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/ast:Case", ptr %t111, i32 0, i32 3
  %t114 = load ptr, ptr %t113, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t110, ptr %t114)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr %"compiler/ast:Case", ptr %t118, i32 0, i32 4
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t117, { i64, ptr } %t121)
  br label %bb27
bb27:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr %"compiler/ast:Case", ptr %t124, i32 0, i32 5
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = icmp ne ptr %t127, null
  br i1 %t129, label %bb28, label %bb29
bb28:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Case", ptr %t132, i32 0, i32 5
  %t135 = load ptr, ptr %t134, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t131, ptr %t135)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t138, i64 %t139)
  br label %bb32
bb32:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2echoose(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l21 = alloca i1
  %l27 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  br i1 %a2, label %bb4, label %bb5
bb4:
  br i1 %a3, label %bb6, label %bb7
bb5:
  br i1 %a4, label %bb11, label %bb12
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/names:Resolver", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 4
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Branch", ptr %t21, i32 0, i32 2
  %t24 = load i64, ptr %t23, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t20, i64 %t24)
  br label %bb8
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/load:Loader", ptr %t30, i32 0, i32 4
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/ast:Branch", ptr %t34, i32 0, i32 2
  %t37 = load i64, ptr %t36, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t33, i64 %t37)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb19
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/load:Loader", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Branch", ptr %t47, i32 0, i32 2
  %t50 = load i64, ptr %t49, !tbaa !24
  %t53 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t46, i64 %t50)
  store i1 %t53, ptr %l27
  br label %bb13
bb12:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  %t54 = load i1, ptr %l27, !tbaa !21
  %t55 = xor i1 %t54, true
  store i1 %t55, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l21, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/names:Resolver", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/load:Loader", ptr %t61, i32 0, i32 4
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Branch", ptr %t65, i32 0, i32 2
  %t68 = load i64, ptr %t67, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t64, i64 %t68)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l23 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = extractvalue { i64, ptr } zeroinitializer, 0
  %t5 = icmp eq i64 %t3, %t4
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } zeroinitializer, 1
  %t8 = icmp eq ptr %t6, %t7
  %t9 = and i1 %t5, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l23, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l5, !tbaa !29
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Catch", ptr %t33, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s5
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t50 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t50, ptr %l34, !tbaa !27
  %t51 = load i64, ptr %l7, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  %t58 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t58, ptr %t56)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb13
bb13:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l7, !tbaa !24
  br label %bb8
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Catch", ptr %t67, i32 0, i32 2
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t66, { i64, ptr } %t70)
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Catch", ptr %t73, i32 0, i32 3
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l12, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s8
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l12, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s8)
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t90 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t90, ptr %l52, !tbaa !27
  %t91 = load i64, ptr %l11, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr ptr, ptr %t94, i64 %t91
  %t96 = load ptr, ptr %t95, !tbaa !39
  %t98 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t98, ptr %t96)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s8)
  br label %bb21
bb21:
  %t102 = load i64, ptr %l11, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l11, !tbaa !24
  br label %bb16
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t106 = load i64, ptr %l3, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l3, !tbaa !24
  br label %bb4
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l29 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i64
  %l43 = alloca %"compiler/source:Span"
  %l45 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l71 = alloca i32
  %l77 = alloca ptr
  %l78 = alloca i64
  %l80 = alloca i32
  %l86 = alloca %"compiler/source:Span"
  %l90 = alloca ptr
  %l91 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i64
  %l101 = alloca i32
  %l107 = alloca %"compiler/source:Span"
  %l109 = alloca ptr
  %l110 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i64
  %l119 = alloca i32
  %l124 = alloca %"compiler/source:Span"
  %l125 = alloca ptr
  %l126 = alloca i1
  %l137 = alloca i64
  %l140 = alloca i64
  %l158 = alloca ptr
  %l159 = alloca i64
  %l161 = alloca { i64, ptr }
  %l163 = alloca i32
  %l165 = alloca { i64, ptr }
  %l167 = alloca %"compiler/source:Span"
  %l170 = alloca i1
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l29, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  store ptr %t23, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t24 = load ptr, ptr %l32, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l32, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 7
  store i1 %t30, ptr %l33, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l33, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l7, !tbaa !29
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/names:Resolver", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l39, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  store i64 %t42, ptr %l40, !tbaa !24
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TopIf", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t46)
  store %"compiler/source:Span" %t48, ptr %l43
  br label %bb10
bb10:
  %t49 = getelementptr %"compiler/source:Span", ptr %l43, i32 0, i32 0
  %t50 = load i32, ptr %t49, !tbaa !23
  %t51 = load ptr, ptr %l39, !tbaa !29
  %t52 = load i64, ptr %l40, !tbaa !24
  %t54 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t51, i64 %t52, i32 %t50)
  store i64 %t54, ptr %l45
  br label %bb11
bb11:
  %t55 = load i64, ptr %l45, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l8, !tbaa !24
  %t57 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t60 = icmp eq i64 %t56, %t57
  br i1 %t60, label %bb12, label %bb13
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l1, !tbaa !24
  %t64 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %t62, i64 %t63, ptr %t64)
  br label %bb14
bb13:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  %t70 = load ptr, ptr %l7, !tbaa !29
  %t71 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollectIf(ptr %v0, ptr %v1, ptr %t68, i64 %t69, ptr %t70, i64 %t71, i64 0)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb69
bb17:
  %t76 = load ptr, ptr %l6, !tbaa !29
  store ptr %t76, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t77 = load ptr, ptr %l56, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb18, label %bb19
bb18:
  %t80 = load ptr, ptr %l56, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 0
  store i1 %t83, ptr %l57, !tbaa !21
  br label %bb19
bb19:
  %t84 = load i1, ptr %l57, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t85 = load ptr, ptr %l6, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { ptr }, ptr %t87, i32 0, i32 0
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l9, !tbaa !29
  br label %bb26
bb21:
  %t91 = load ptr, ptr %l6, !tbaa !29
  store ptr %t91, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t92 = load ptr, ptr %l62, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb22, label %bb23
bb22:
  %t95 = load ptr, ptr %l62, !tbaa !29
  %t96 = load i64, ptr %t95
  %t98 = icmp eq i64 %t96, 1
  store i1 %t98, ptr %l63, !tbaa !21
  br label %bb23
bb23:
  %t99 = load i1, ptr %l63, !tbaa !21
  br i1 %t99, label %bb24, label %bb25
bb24:
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { ptr }, ptr %t102, i32 0, i32 0
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l9, !tbaa !29
  br label %bb26
bb25:
  br label %bb32
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t106 = load ptr, ptr %l9, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Func", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = icmp ne ptr %t109, null
  br i1 %t111, label %bb27, label %bb28
bb27:
  %t113 = load ptr, ptr %l9, !tbaa !29
  %t115 = getelementptr %"compiler/ast:Func", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/ast:Param", ptr %t116, i32 0, i32 0
  %t119 = getelementptr %"compiler/source:Span", ptr %t118, i32 0, i32 1
  %t120 = load i32, ptr %t119, !tbaa !23
  store i32 %t120, ptr %l71, !tbaa !23
  br label %bb29
bb28:
  %t122 = load ptr, ptr %l9, !tbaa !29
  %t124 = getelementptr %"compiler/ast:Func", ptr %t122, i32 0, i32 0
  %t125 = getelementptr %"compiler/source:Span", ptr %t124, i32 0, i32 0
  %t126 = load i32, ptr %t125, !tbaa !23
  store i32 %t126, ptr %l71, !tbaa !23
  br label %bb29
bb29:
  %t128 = load i32, ptr %l71, !tbaa !23
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l77, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  store i64 %t130, ptr %l78, !tbaa !24
  %t131 = load ptr, ptr %l9, !tbaa !29
  %t133 = getelementptr %"compiler/ast:Func", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %t133, !tbaa !23
  store i32 %t134, ptr %l80, !tbaa !23
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i64, ptr %l1, !tbaa !24
  %t138 = load ptr, ptr %l9, !tbaa !29
  %t140 = getelementptr %"compiler/ast:Func", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %t140, !tbaa !23
  %t146 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t135, i64 %t136, i32 %t128, i32 %t141)
  store %"compiler/source:Span" %t146, ptr %l86
  br label %bb30
bb30:
  %t147 = load ptr, ptr %l9, !tbaa !29
  %t149 = getelementptr %"compiler/ast:Func", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp ne ptr %t150, null
  %t153 = load ptr, ptr %l77, !tbaa !29
  %t154 = load i64, ptr %l78, !tbaa !24
  %t155 = load i32, ptr %l80, !tbaa !23
  %t156 = load %"compiler/source:Span", ptr %l86
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddValue(ptr %v0, ptr %s6, ptr %t153, i64 %t154, i32 %t155, %"compiler/source:Span" %t156, i1 false, i1 true, i1 %t152, ptr null)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb69
bb32:
  %t158 = load ptr, ptr %l6, !tbaa !29
  store ptr %t158, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t159 = load ptr, ptr %l90, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb33, label %bb34
bb33:
  %t162 = load ptr, ptr %l90, !tbaa !29
  %t163 = load i64, ptr %t162
  %t165 = icmp eq i64 %t163, 2
  store i1 %t165, ptr %l91, !tbaa !21
  br label %bb34
bb34:
  %t166 = load i1, ptr %l91, !tbaa !21
  br i1 %t166, label %bb35, label %bb36
bb35:
  %t167 = load ptr, ptr %l6, !tbaa !29
  %t169 = getelementptr { i64, [4 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", ptr }, ptr %t169, i32 0, i32 0
  %t171 = load %"compiler/source:Span", ptr %t170
  store %"compiler/source:Span" %t171, ptr %l11
  %t173 = load ptr, ptr %l6, !tbaa !29
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l12, !tbaa !29
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l98, !tbaa !29
  %t180 = load i64, ptr %l1, !tbaa !24
  store i64 %t180, ptr %l99, !tbaa !24
  %t181 = load ptr, ptr %l12, !tbaa !29
  %t183 = getelementptr %"compiler/ast:TypeDecl", ptr %t181, i32 0, i32 0
  %t184 = load i32, ptr %t183, !tbaa !23
  store i32 %t184, ptr %l101, !tbaa !23
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i64, ptr %l1, !tbaa !24
  %t187 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t188 = load i32, ptr %t187, !tbaa !23
  %t189 = load ptr, ptr %l12, !tbaa !29
  %t191 = getelementptr %"compiler/ast:TypeDecl", ptr %t189, i32 0, i32 0
  %t192 = load i32, ptr %t191, !tbaa !23
  %t197 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t185, i64 %t186, i32 %t188, i32 %t192)
  store %"compiler/source:Span" %t197, ptr %l107
  br label %bb38
bb38:
  %t198 = load ptr, ptr %l12, !tbaa !29
  %t199 = load ptr, ptr %l98, !tbaa !29
  %t200 = load i64, ptr %l99, !tbaa !24
  %t201 = load i32, ptr %l101, !tbaa !23
  %t202 = load %"compiler/source:Span", ptr %l107
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v1, ptr %t199, i64 %t200, i32 %t201, %"compiler/source:Span" %t202, ptr %t198)
  br label %bb39
bb39:
  br label %bb69
bb40:
  %t204 = load ptr, ptr %l6, !tbaa !29
  store ptr %t204, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t205 = load ptr, ptr %l109, !tbaa !29
  %t206 = icmp ne ptr %t205, null
  br i1 %t206, label %bb41, label %bb42
bb41:
  %t208 = load ptr, ptr %l109, !tbaa !29
  %t209 = load i64, ptr %t208
  %t211 = icmp eq i64 %t209, 5
  store i1 %t211, ptr %l110, !tbaa !21
  br label %bb42
bb42:
  %t212 = load i1, ptr %l110, !tbaa !21
  br i1 %t212, label %bb43, label %bb44
bb43:
  %t213 = load ptr, ptr %l6, !tbaa !29
  %t215 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", i32, { i64, ptr } }, ptr %t215, i32 0, i32 0
  %t217 = load %"compiler/source:Span", ptr %t216
  store %"compiler/source:Span" %t217, ptr %l13
  %t219 = load ptr, ptr %l6, !tbaa !29
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 1
  %t222 = getelementptr { %"compiler/source:Span", i32, { i64, ptr } }, ptr %t221, i32 0, i32 1
  %t223 = load i32, ptr %t222
  store i32 %t223, ptr %l14, !tbaa !23
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l117, !tbaa !29
  %t226 = load i64, ptr %l1, !tbaa !24
  store i64 %t226, ptr %l118, !tbaa !24
  %t227 = load i32, ptr %l14, !tbaa !23
  store i32 %t227, ptr %l119, !tbaa !23
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i64, ptr %l1, !tbaa !24
  %t230 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t231 = load i32, ptr %t230, !tbaa !23
  %t232 = load i32, ptr %l14, !tbaa !23
  %t237 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t228, i64 %t229, i32 %t231, i32 %t232)
  store %"compiler/source:Span" %t237, ptr %l124
  br label %bb46
bb46:
  %t238 = load ptr, ptr %l117, !tbaa !29
  %t239 = load i64, ptr %l118, !tbaa !24
  %t240 = load i32, ptr %l119, !tbaa !23
  %t241 = load %"compiler/source:Span", ptr %l124
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v0, ptr %t238, i64 %t239, i32 %t240, %"compiler/source:Span" %t241, ptr null)
  br label %bb47
bb47:
  br label %bb69
bb48:
  %t242 = load ptr, ptr %l6, !tbaa !29
  store ptr %t242, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t243 = load ptr, ptr %l125, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb49, label %bb50
bb49:
  %t246 = load ptr, ptr %l125, !tbaa !29
  %t247 = load i64, ptr %t246
  %t249 = icmp eq i64 %t247, 3
  store i1 %t249, ptr %l126, !tbaa !21
  br label %bb50
bb50:
  %t250 = load i1, ptr %l126, !tbaa !21
  br i1 %t250, label %bb51, label %bb52
bb51:
  %t251 = load ptr, ptr %l6, !tbaa !29
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l15, !tbaa !29
  br label %bb53
bb52:
  br label %bb68
bb53:
  store i64 0, ptr %l16, !tbaa !24
  %t257 = load ptr, ptr %l15, !tbaa !29
  %t259 = getelementptr %"compiler/ast:VarDecl", ptr %t257, i32 0, i32 0
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t260, 0
  store i64 %t262, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t264 = load i64, ptr %l17, !tbaa !24
  %t265 = load i64, ptr %l16, !tbaa !24
  %t268 = icmp sgt i64 %t264, %t265
  br i1 %t268, label %bb54, label %bb55
bb54:
  %t270 = load i64, ptr %l18, !tbaa !24
  %t272 = icmp sgt i64 %t270, 0
  br i1 %t272, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb59
bb56:
  %t274 = load i64, ptr %l17, !tbaa !24
  %t275 = load i64, ptr %l16, !tbaa !24
  %t278 = sub i64 %t274, %t275
  %t279 = load i64, ptr %l18, !tbaa !24
  %t282 = add i64 %t278, %t279
  %t284 = sub i64 %t282, 1
  %t285 = load i64, ptr %l18, !tbaa !24
  %t288 = sdiv i64 %t284, %t285
  store i64 %t288, ptr %l140, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb58
bb58:
  %t290 = load i64, ptr %l140, !tbaa !24
  store i64 %t290, ptr %l137, !tbaa !24
  br label %bb59
bb59:
  %t291 = load i64, ptr %l137, !tbaa !24
  store i64 %t291, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t292 = load i64, ptr %l20, !tbaa !24
  %t293 = load i64, ptr %l19, !tbaa !24
  %t296 = icmp slt i64 %t292, %t293
  %t298 = xor i1 %t296, true
  br i1 %t298, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb67
bb62:
  br label %bb63
bb63:
  %t300 = load i64, ptr %l16, !tbaa !24
  %t301 = load i64, ptr %l20, !tbaa !24
  %t302 = load i64, ptr %l18, !tbaa !24
  %t305 = mul i64 %t301, %t302
  %t308 = add i64 %t300, %t305
  store i64 %t308, ptr %l21, !tbaa !24
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l158, !tbaa !29
  %t311 = load i64, ptr %l1, !tbaa !24
  store i64 %t311, ptr %l159, !tbaa !24
  %t312 = load ptr, ptr %l15, !tbaa !29
  %t314 = getelementptr %"compiler/ast:VarDecl", ptr %t312, i32 0, i32 0
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  store { i64, ptr } %t315, ptr %l161, !tbaa !27
  %t316 = load i64, ptr %l21, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr i32, ptr %t319, i64 %t316
  %t321 = load i32, ptr %t320, !tbaa !33
  store i32 %t321, ptr %l163, !tbaa !23
  %t322 = load ptr, ptr %l15, !tbaa !29
  %t324 = getelementptr %"compiler/ast:VarDecl", ptr %t322, i32 0, i32 1
  %t325 = load { i64, ptr }, ptr %t324, !tbaa !27
  store { i64, ptr } %t325, ptr %l165, !tbaa !27
  %t326 = load i64, ptr %l21, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr %"compiler/source:Span", ptr %t329, i64 %t326
  %t331 = load %"compiler/source:Span", ptr %t330
  store %"compiler/source:Span" %t331, ptr %l167
  %t332 = load ptr, ptr %l15, !tbaa !29
  %t334 = getelementptr %"compiler/ast:VarDecl", ptr %t332, i32 0, i32 2
  %t335 = load ptr, ptr %t334, !tbaa !29
  %t337 = call i1 @compiler_2fnames_2ewritable(ptr %v1, ptr %t335)
  store i1 %t337, ptr %l170
  br label %bb64
bb64:
  %t338 = load ptr, ptr %l15, !tbaa !29
  %t339 = load ptr, ptr %l158, !tbaa !29
  %t340 = load i64, ptr %l159, !tbaa !24
  %t341 = load i32, ptr %l163, !tbaa !23
  %t342 = load %"compiler/source:Span", ptr %l167
  %t343 = load i1, ptr %l170, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddValue(ptr %v0, ptr %v1, ptr %t339, i64 %t340, i32 %t341, %"compiler/source:Span" %t342, i1 %t343, i1 false, i1 false, ptr %t338)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb66:
  %t345 = load i64, ptr %l20, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l20, !tbaa !24
  br label %bb60
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb70:
  %t349 = load i64, ptr %l4, !tbaa !24
  %t351 = add i64 %t349, 1
  store i64 %t351, ptr %l4, !tbaa !24
  br label %bb1
bb71:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollectIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TopBranch", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t16 = extractvalue { i64, ptr } zeroinitializer, 0
  %t17 = icmp eq i64 %t15, %t16
  %t18 = extractvalue { i64, ptr } %t13, 1
  %t19 = extractvalue { i64, ptr } zeroinitializer, 1
  %t20 = icmp eq ptr %t18, %t19
  %t21 = and i1 %t17, %t20
  %t22 = xor i1 %t21, true
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t24 = load i1, ptr %l8, !tbaa !21
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TopIf", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TopBranch", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v1, ptr %t25, i64 %t26, { i64, ptr } %t33)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp ne ptr %t40, null
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TopIf", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollectIf(ptr %v0, ptr %v1, ptr %t44, i64 %t45, ptr %t49, i64 %t50, i64 %t53)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TopIf", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp ne ptr %t62, null
  br i1 %t64, label %bb12, label %bb13
bb12:
  %t66 = load i64, ptr %l3, !tbaa !24
  %t67 = load i64, ptr %l4, !tbaa !24
  %t69 = add i64 %t67, 1
  %t72 = icmp eq i64 %t66, %t69
  store i1 %t72, ptr %l31, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t74 = load i1, ptr %l31, !tbaa !21
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = getelementptr %"compiler/ast:TopIf", ptr %t75, i32 0, i32 3
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/ast:TopBranch", ptr %t78, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } zeroinitializer, 0
  %t85 = icmp eq i64 %t83, %t84
  %t86 = extractvalue { i64, ptr } %t81, 1
  %t87 = extractvalue { i64, ptr } zeroinitializer, 1
  %t88 = icmp eq ptr %t86, %t87
  %t89 = and i1 %t85, %t88
  %t90 = xor i1 %t89, true
  store i1 %t90, ptr %l36, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t92 = load i1, ptr %l36, !tbaa !21
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l1, !tbaa !24
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr %"compiler/ast:TopIf", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/ast:TopBranch", ptr %t98, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v1, ptr %t93, i64 %t94, { i64, ptr } %t101)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i1 } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edecideLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l21 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l43 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i32
  %l73 = alloca { i64, ptr }
  %l96 = alloca %"compiler/cond:Eval"
  %l100 = alloca { i32, i1 }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i32, i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 6
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l21
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l21, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/names:Resolver", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v0, ptr %t18, ptr %t19)
  br label %bb2
bb2:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 23
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/cond:Scope", ptr %t25, i32 0, i32 2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eCle_Hfe7f0d5b2686087af262d47548aa26e4(ptr %v0, ptr %t27)
  br label %bb3
bb3:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/names:Resolver", ptr %t29, i32 0, i32 10
  store ptr %t31, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v0, ptr %t33, i64 %t34)
  %t38 = extractvalue { i32, { i64, ptr } } %t37, 1
  %t39 = extractvalue { i32, { i64, ptr } } %t37, 0
  store i32 %t39, ptr %l34
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb6, label %ok.41
ok.41:
  store { i64, ptr } %t38, ptr %l33
  br label %bb5
bb5:
  %t42 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t42, ptr %l30, !tbaa !27
  br label %bb10
bb6:
  %t43 = load i32, ptr %l34, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  br i1 %t46, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  %t48 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t61, ptr %l43, !tbaa !27
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i32, ptr %t65, i64 %t62
  %t67 = load i32, ptr %t66, !tbaa !33
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/load:Module", ptr %t69, i32 0, i32 23
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/cond:Scope", ptr %t72, i32 0, i32 2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t74, i32 %t67)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  %t82 = load i64, ptr %l4, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = add i64 %t82, %t83
  store i64 %t86, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb4
bb19:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/load:Module", ptr %t88, i32 0, i32 23
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/cond:Scope", ptr %t91, i32 0, i32 3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eCle_Hfe7f0d5b2686087af262d47548aa26e4(ptr %v0, ptr %t93)
  br label %bb20
bb20:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/names:Resolver", ptr %t95, i32 0, i32 11
  store ptr %t97, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t99 = load ptr, ptr %l9, !tbaa !29
  %t100 = load i64, ptr %l10, !tbaa !24
  %t103 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v0, ptr %t99, i64 %t100)
  %t104 = extractvalue { i32, { i64, ptr } } %t103, 1
  %t105 = extractvalue { i32, { i64, ptr } } %t103, 0
  store i32 %t105, ptr %l64
  %t106 = icmp ne i32 %t105, 0
  br i1 %t106, label %bb23, label %ok.107
ok.107:
  store { i64, ptr } %t104, ptr %l63
  br label %bb22
bb22:
  %t108 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t108, ptr %l60, !tbaa !27
  br label %bb27
bb23:
  %t109 = load i32, ptr %l64, !tbaa !23
  %t110 = ashr i32 %t109, 16
  %t112 = icmp eq i32 %t110, 1
  br i1 %t112, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb27:
  %t114 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t114, ptr %l11, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t119 = load i64, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l12, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t127 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t127, ptr %l73, !tbaa !27
  %t128 = load i64, ptr %l13, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i32, ptr %t131, i64 %t128
  %t133 = load i32, ptr %t132, !tbaa !33
  %t135 = load ptr, ptr %l2, !tbaa !29
  %t137 = getelementptr %"compiler/load:Module", ptr %t135, i32 0, i32 23
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/cond:Scope", ptr %t138, i32 0, i32 3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t140, i32 %t133)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l13, !tbaa !24
  br label %bb28
bb34:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t149 = load i64, ptr %l12, !tbaa !24
  %t152 = add i64 %t148, %t149
  store i64 %t152, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  br label %bb21
bb36:
  %t154 = load ptr, ptr %l2, !tbaa !29
  %t156 = getelementptr %"compiler/load:Module", ptr %t154, i32 0, i32 6
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/source:Source", ptr %t157, i32 0, i32 1
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/names:Resolver", ptr %t161, i32 0, i32 0
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/load:Loader", ptr %t164, i32 0, i32 3
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t170 = getelementptr %"compiler/load:Module", ptr %t168, i32 0, i32 23
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/names:Resolver", ptr %t172, i32 0, i32 0
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/load:Loader", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t183 = call %"compiler/cond:Eval" @compiler_2fcond_3aEval_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t160, ptr %t167, ptr %t171, ptr %t178)
  store %"compiler/cond:Eval" %t183, ptr %l96
  br label %bb37
bb37:
  %t184 = load %"compiler/cond:Eval", ptr %l96
  %t185 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 128, i64 8)
  store %"compiler/cond:Eval" %t184, ptr %t185
  %t191 = call { i32, i1 } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eLocal(ptr %v0, ptr %v1, ptr %t185, ptr %a1)
  store { i32, i1 } %t191, ptr %l100
  br label %bb38
bb38:
  %t192 = load { i32, i1 }, ptr %l100
  store { i32, i1 } %t192, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l13 = alloca ptr
  %l18 = alloca { i64, [3 x i64] }
  %l19 = alloca %"compiler/msgs:Msg"
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i1
  %l33 = alloca %"compiler/names:local"
  %l34 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i1
  %l39 = alloca i1
  %l44 = alloca ptr
  %l49 = alloca { i64, [3 x i64] }
  %l52 = alloca %"compiler/msgs:Msg"
  %l55 = alloca { i64, ptr }
  %l57 = alloca %"compiler/msgs:Msg"
  %l60 = alloca { i64, ptr }
  %l62 = alloca %"compiler/msgs:Msg"
  %l63 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 1, ptr @.d31 })
  store i1 %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load i1, ptr %l10, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/names:Resolver", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/names:Resolver", ptr %t19, i32 0, i32 6
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load %"compiler/source:Span", ptr %l2
  %t27 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t18, i64 %t22, %"compiler/source:Span" %t23)
  store { i64, [3 x i64] } %t27, ptr %l18
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %s1)
  store %"compiler/msgs:Msg" %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l13, !tbaa !29
  %t30 = load { i64, [3 x i64] }, ptr %l18
  %t31 = load %"compiler/msgs:Msg", ptr %l19
  %t32 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t29, { i64, [3 x i64] } %t30, %"compiler/msgs:Msg" %t31)
  store i64 %t32, ptr %l20
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/names:Resolver", ptr %t33, i32 0, i32 8
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t35, i32 %t36)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l26
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb10, label %ok.43
ok.43:
  store i64 %t40, ptr %l25
  br label %bb9
bb9:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %l21, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l21, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp sge i64 %t46, 0
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/names:Resolver", ptr %t50, i32 0, i32 7
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = call %"compiler/names:local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t52, i64 %t53)
  store %"compiler/names:local" %t56, ptr %l33
  br label %bb15
bb14:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb17
bb15:
  %t57 = getelementptr %"compiler/names:local", ptr %l33, i32 0, i32 2
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l34
  store i32 1, ptr %l36
  %t61 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l34, ptr %l36)
  store i1 %t61, ptr %l38
  br label %bb16
bb16:
  %t62 = load i1, ptr %l38, !tbaa !21
  store i1 %t62, ptr %l29, !tbaa !21
  br label %bb17
bb17:
  %t63 = load i1, ptr %l29, !tbaa !21
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t66 = xor i1 %a3, true
  store i1 %t66, ptr %l39, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l39, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/load:Loader", ptr %t72, i32 0, i32 4
  %t75 = load ptr, ptr %t74, !tbaa !29
  store ptr %t75, ptr %l44, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/names:Resolver", ptr %t77, i32 0, i32 6
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = load %"compiler/source:Span", ptr %l2
  %t85 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t76, i64 %t80, %"compiler/source:Span" %t81)
  store { i64, [3 x i64] } %t85, ptr %l49
  br label %bb23
bb22:
  br label %bb32
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/names:Resolver", ptr %t86, i32 0, i32 13
  %t89 = load i1, ptr %t88, !tbaa !21
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l1, !tbaa !23
  %t95 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t91, i32 %t92)
  store { i64, ptr } %t95, ptr %l55
  br label %bb26
bb25:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t96, i32 %t97)
  store { i64, ptr } %t100, ptr %l60
  br label %bb28
bb26:
  %t101 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t109 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAlreadyDeclared(ptr %s2, ptr %s2, { i64, ptr } %t107)
  store %"compiler/msgs:Msg" %t109, ptr %l57
  br label %bb27
bb27:
  %t110 = load %"compiler/msgs:Msg", ptr %l57
  store %"compiler/msgs:Msg" %t110, ptr %l52
  br label %bb30
bb28:
  %t111 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t119 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredTwice(ptr %s2, ptr %s2, { i64, ptr } %t117)
  store %"compiler/msgs:Msg" %t119, ptr %l62
  br label %bb29
bb29:
  %t120 = load %"compiler/msgs:Msg", ptr %l62
  store %"compiler/msgs:Msg" %t120, ptr %l52
  br label %bb30
bb30:
  %t121 = load ptr, ptr %l44, !tbaa !29
  %t122 = load { i64, [3 x i64] }, ptr %l49
  %t123 = load %"compiler/msgs:Msg", ptr %l52
  %t124 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t121, { i64, [3 x i64] } %t122, %"compiler/msgs:Msg" %t123)
  store i64 %t124, ptr %l63
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i32, ptr %l1, !tbaa !23
  %t127 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoShadow(ptr %v0, ptr %t125, i32 %t126, %"compiler/source:Span" %t127)
  br label %bb33
bb33:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/names:Resolver", ptr %t132, i32 0, i32 6
  %t135 = load i64, ptr %t134, !tbaa !24
  %t136 = load i32, ptr %l1, !tbaa !23
  %t137 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t131, i64 %t135, i32 %t136, %"compiler/source:Span" %t137)
  br label %bb34
bb34:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l1, !tbaa !23
  %t144 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t142, i32 %t143, %"compiler/source:Span" %t144, i32 1)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edropAll(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Branch", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/names:Resolver", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:If", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Branch", ptr %t21, i32 0, i32 2
  %t24 = load i64, ptr %t23, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCutOff(ptr %v0, ptr %t17, i64 %t24)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:If", ptr %t27, i32 0, i32 2
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/ast:If", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  store ptr %t39, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l19, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 5
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t47 = load i1, ptr %l20, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edropAll(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  br label %bb13
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l66 = alloca i1
  %l67 = alloca i64
  %l68 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %l144 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca i1
  %l204 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l212 = alloca i1
  %l232 = alloca { i64, ptr }
  %l239 = alloca ptr
  %l240 = alloca i1
  %l256 = alloca { i64, ptr }
  %l263 = alloca ptr
  %l264 = alloca i1
  %l277 = alloca ptr
  %l278 = alloca i1
  %l294 = alloca { i64, ptr }
  %l301 = alloca ptr
  %l302 = alloca i1
  %l317 = alloca ptr
  %l318 = alloca i1
  %l336 = alloca { i64, ptr }
  %l343 = alloca ptr
  %l344 = alloca i1
  %l349 = alloca ptr
  %l350 = alloca i1
  %l355 = alloca ptr
  %l356 = alloca i1
  %l368 = alloca { i64, ptr }
  %l375 = alloca ptr
  %l376 = alloca i1
  %l393 = alloca i64
  %l408 = alloca ptr
  %l409 = alloca i1
  %l420 = alloca ptr
  %l421 = alloca i1
  %l430 = alloca i64
  %l445 = alloca ptr
  %l446 = alloca i1
  %s7 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s36 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t6 = load ptr, ptr %l71, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l71, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l72, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l72, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32 }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32 }, ptr %t22, i32 0, i32 1
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l2
  %t28 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ename(ptr %v0, ptr %t26, %"compiler/source:Span" %t27, i32 %t28)
  br label %bb9
bb9:
  br label %bb230
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t33 = load ptr, ptr %l82, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l82, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l83, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l83, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb23
bb14:
  %t47 = load ptr, ptr %l1, !tbaa !29
  store ptr %t47, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t48 = load ptr, ptr %l88, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l88, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 3
  store i1 %t54, ptr %l89, !tbaa !21
  br label %bb16
bb16:
  %t55 = load i1, ptr %l89, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb23
bb18:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t63 = load ptr, ptr %l94, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t66 = load ptr, ptr %l94, !tbaa !29
  %t67 = load i64, ptr %t66
  %t69 = icmp eq i64 %t67, 4
  store i1 %t69, ptr %l95, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l95, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t77, ptr %t78)
  br label %bb24
bb24:
  br label %bb230
bb25:
  %t81 = load ptr, ptr %l1, !tbaa !29
  store ptr %t81, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t82 = load ptr, ptr %l102, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t85 = load ptr, ptr %l102, !tbaa !29
  %t86 = load i64, ptr %t85
  %t88 = icmp eq i64 %t86, 5
  store i1 %t88, ptr %l103, !tbaa !21
  br label %bb27
bb27:
  %t89 = load i1, ptr %l103, !tbaa !21
  br i1 %t89, label %bb28, label %bb29
bb28:
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l5, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t98, i32 0, i32 3
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l6, !tbaa !29
  br label %bb38
bb29:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t103 = load ptr, ptr %l110, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l110, !tbaa !29
  %t107 = load i64, ptr %t106
  %t109 = icmp eq i64 %t107, 6
  store i1 %t109, ptr %l111, !tbaa !21
  br label %bb31
bb31:
  %t110 = load i1, ptr %l111, !tbaa !21
  br i1 %t110, label %bb32, label %bb33
bb32:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t113, i32 0, i32 1
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l5, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l6, !tbaa !29
  br label %bb38
bb33:
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t124 = load ptr, ptr %l118, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb34, label %bb35
bb34:
  %t127 = load ptr, ptr %l118, !tbaa !29
  %t128 = load i64, ptr %t127
  %t130 = icmp eq i64 %t128, 10
  store i1 %t130, ptr %l119, !tbaa !21
  br label %bb35
bb35:
  %t131 = load i1, ptr %l119, !tbaa !21
  br i1 %t131, label %bb36, label %bb37
bb36:
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t134, i32 0, i32 1
  %t136 = load ptr, ptr %t135
  store ptr %t136, ptr %l5, !tbaa !29
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t144, ptr %t145)
  br label %bb39
bb39:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t148, ptr %t149)
  br label %bb40
bb40:
  br label %bb230
bb41:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t153 = load ptr, ptr %l130, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb42, label %bb43
bb42:
  %t156 = load ptr, ptr %l130, !tbaa !29
  %t157 = load i64, ptr %t156
  %t159 = icmp eq i64 %t157, 7
  store i1 %t159, ptr %l131, !tbaa !21
  br label %bb43
bb43:
  %t160 = load i1, ptr %l131, !tbaa !21
  br i1 %t160, label %bb44, label %bb45
bb44:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", ptr }, ptr %t163, i32 0, i32 1
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l7, !tbaa !29
  br label %bb46
bb45:
  br label %bb54
bb46:
  %t167 = load ptr, ptr %l7, !tbaa !29
  %t169 = getelementptr %"compiler/ast:Chain", ptr %t167, i32 0, i32 1
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  store i64 %t174, ptr %l10, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t176 = load i64, ptr %l9, !tbaa !24
  %t177 = load i64, ptr %l10, !tbaa !24
  %t180 = icmp slt i64 %t176, %t177
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t184 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t184, ptr %l144, !tbaa !27
  %t185 = load i64, ptr %l9, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr ptr, ptr %t188, i64 %t185
  %t190 = load ptr, ptr %t189, !tbaa !39
  %t192 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t192, ptr %t190)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb52:
  %t196 = load i64, ptr %l9, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l9, !tbaa !24
  br label %bb47
bb53:
  br label %bb230
bb54:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l151, !tbaa !29
  store i1 false, ptr %l152, !tbaa !21
  %t201 = load ptr, ptr %l151, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb55, label %bb56
bb55:
  %t204 = load ptr, ptr %l151, !tbaa !29
  %t205 = load i64, ptr %t204
  %t207 = icmp eq i64 %t205, 8
  store i1 %t207, ptr %l152, !tbaa !21
  br label %bb56
bb56:
  %t208 = load i1, ptr %l152, !tbaa !21
  br i1 %t208, label %bb57, label %bb58
bb57:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t211, i32 0, i32 1
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l12, !tbaa !29
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr { i64, [5 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t217, i32 0, i32 2
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l13, !tbaa !29
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t223, i32 0, i32 3
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l14, !tbaa !29
  br label %bb59
bb58:
  br label %bb63
bb59:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t227, ptr %t228)
  br label %bb60
bb60:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t231, ptr %t232)
  br label %bb61
bb61:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t235, ptr %t236)
  br label %bb62
bb62:
  br label %bb230
bb63:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l167, !tbaa !29
  store i1 false, ptr %l168, !tbaa !21
  %t240 = load ptr, ptr %l167, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb64, label %bb65
bb64:
  %t243 = load ptr, ptr %l167, !tbaa !29
  %t244 = load i64, ptr %t243
  %t246 = icmp eq i64 %t244, 9
  store i1 %t246, ptr %l168, !tbaa !21
  br label %bb65
bb65:
  %t247 = load i1, ptr %l168, !tbaa !21
  br i1 %t247, label %bb66, label %bb67
bb66:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t250, i32 0, i32 1
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l15, !tbaa !29
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [5 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t256, i32 0, i32 2
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l16, !tbaa !29
  br label %bb72
bb67:
  %t260 = load ptr, ptr %l1, !tbaa !29
  store ptr %t260, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t261 = load ptr, ptr %l175, !tbaa !29
  %t262 = icmp ne ptr %t261, null
  br i1 %t262, label %bb68, label %bb69
bb68:
  %t264 = load ptr, ptr %l175, !tbaa !29
  %t265 = load i64, ptr %t264
  %t267 = icmp eq i64 %t265, 11
  store i1 %t267, ptr %l176, !tbaa !21
  br label %bb69
bb69:
  %t268 = load i1, ptr %l176, !tbaa !21
  br i1 %t268, label %bb70, label %bb71
bb70:
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr { i64, [5 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t271, i32 0, i32 1
  %t273 = load ptr, ptr %t272
  store ptr %t273, ptr %l15, !tbaa !29
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr { i64, [5 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t277, i32 0, i32 2
  %t279 = load ptr, ptr %t278
  store ptr %t279, ptr %l16, !tbaa !29
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t281, ptr %t282)
  br label %bb73
bb73:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t285, ptr %t286)
  br label %bb74
bb74:
  br label %bb230
bb75:
  %t289 = load ptr, ptr %l1, !tbaa !29
  store ptr %t289, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t290 = load ptr, ptr %l187, !tbaa !29
  %t291 = icmp ne ptr %t290, null
  br i1 %t291, label %bb76, label %bb77
bb76:
  %t293 = load ptr, ptr %l187, !tbaa !29
  %t294 = load i64, ptr %t293
  %t296 = icmp eq i64 %t294, 12
  store i1 %t296, ptr %l188, !tbaa !21
  br label %bb77
bb77:
  %t297 = load i1, ptr %l188, !tbaa !21
  br i1 %t297, label %bb78, label %bb79
bb78:
  %t298 = load ptr, ptr %l1, !tbaa !29
  %t300 = getelementptr { i64, [5 x i64] }, ptr %t298, i32 0, i32 1
  %t301 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t300, i32 0, i32 1
  %t302 = load ptr, ptr %t301
  store ptr %t302, ptr %l17, !tbaa !29
  %t304 = load ptr, ptr %l1, !tbaa !29
  %t306 = getelementptr { i64, [5 x i64] }, ptr %t304, i32 0, i32 1
  %t307 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t306, i32 0, i32 2
  %t308 = load { i64, ptr }, ptr %t307
  store { i64, ptr } %t308, ptr %l18, !tbaa !27
  br label %bb80
bb79:
  br label %bb89
bb80:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t310, ptr %t311)
  br label %bb81
bb81:
  %t314 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t314, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t316 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t316, 0
  store i64 %t318, ptr %l21, !tbaa !24
  br label %bb82
bb82:
  store %olang.scope zeroinitializer, ptr %s13
  %t320 = load i64, ptr %l20, !tbaa !24
  %t321 = load i64, ptr %l21, !tbaa !24
  %t324 = icmp slt i64 %t320, %t321
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s13)
  br label %bb88
bb84:
  br label %bb85
bb85:
  %t328 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t328, ptr %l204, !tbaa !27
  %t329 = load i64, ptr %l20, !tbaa !24
  %t331 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr ptr, ptr %t332, i64 %t329
  %t334 = load ptr, ptr %t333, !tbaa !39
  %t336 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t336, ptr %t334)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s13)
  br label %bb87
bb87:
  %t340 = load i64, ptr %l20, !tbaa !24
  %t342 = add i64 %t340, 1
  store i64 %t342, ptr %l20, !tbaa !24
  br label %bb82
bb88:
  br label %bb230
bb89:
  %t344 = load ptr, ptr %l1, !tbaa !29
  store ptr %t344, ptr %l211, !tbaa !29
  store i1 false, ptr %l212, !tbaa !21
  %t345 = load ptr, ptr %l211, !tbaa !29
  %t346 = icmp ne ptr %t345, null
  br i1 %t346, label %bb90, label %bb91
bb90:
  %t348 = load ptr, ptr %l211, !tbaa !29
  %t349 = load i64, ptr %t348
  %t351 = icmp eq i64 %t349, 13
  store i1 %t351, ptr %l212, !tbaa !21
  br label %bb91
bb91:
  %t352 = load i1, ptr %l212, !tbaa !21
  br i1 %t352, label %bb92, label %bb93
bb92:
  %t353 = load ptr, ptr %l1, !tbaa !29
  %t355 = getelementptr { i64, [5 x i64] }, ptr %t353, i32 0, i32 1
  %t356 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t355, i32 0, i32 0
  %t357 = load %"compiler/source:Span", ptr %t356
  store %"compiler/source:Span" %t357, ptr %l23
  %t359 = load ptr, ptr %l1, !tbaa !29
  %t361 = getelementptr { i64, [5 x i64] }, ptr %t359, i32 0, i32 1
  %t362 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t361, i32 0, i32 1
  %t363 = load ptr, ptr %t362
  store ptr %t363, ptr %l24, !tbaa !29
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t367, i32 0, i32 2
  %t369 = load i32, ptr %t368
  store i32 %t369, ptr %l25, !tbaa !23
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [5 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t373, i32 0, i32 3
  %t375 = load { i64, ptr }, ptr %t374
  store { i64, ptr } %t375, ptr %l26, !tbaa !27
  br label %bb94
bb93:
  br label %bb103
bb94:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t377, ptr %t378)
  br label %bb95
bb95:
  %t381 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t381, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t383 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t385 = extractvalue { i64, ptr } %t383, 0
  store i64 %t385, ptr %l29, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s17
  %t387 = load i64, ptr %l28, !tbaa !24
  %t388 = load i64, ptr %l29, !tbaa !24
  %t391 = icmp slt i64 %t387, %t388
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s17)
  br label %bb102
bb98:
  br label %bb99
bb99:
  %t395 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t395, ptr %l232, !tbaa !27
  %t396 = load i64, ptr %l28, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr ptr, ptr %t399, i64 %t396
  %t401 = load ptr, ptr %t400, !tbaa !39
  %t403 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t403, ptr %t401)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s17)
  br label %bb101
bb101:
  %t407 = load i64, ptr %l28, !tbaa !24
  %t409 = add i64 %t407, 1
  store i64 %t409, ptr %l28, !tbaa !24
  br label %bb96
bb102:
  br label %bb230
bb103:
  %t411 = load ptr, ptr %l1, !tbaa !29
  store ptr %t411, ptr %l239, !tbaa !29
  store i1 false, ptr %l240, !tbaa !21
  %t412 = load ptr, ptr %l239, !tbaa !29
  %t413 = icmp ne ptr %t412, null
  br i1 %t413, label %bb104, label %bb105
bb104:
  %t415 = load ptr, ptr %l239, !tbaa !29
  %t416 = load i64, ptr %t415
  %t418 = icmp eq i64 %t416, 14
  store i1 %t418, ptr %l240, !tbaa !21
  br label %bb105
bb105:
  %t419 = load i1, ptr %l240, !tbaa !21
  br i1 %t419, label %bb106, label %bb107
bb106:
  %t420 = load ptr, ptr %l1, !tbaa !29
  %t422 = getelementptr { i64, [5 x i64] }, ptr %t420, i32 0, i32 1
  %t423 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t422, i32 0, i32 1
  %t424 = load ptr, ptr %t423
  store ptr %t424, ptr %l31, !tbaa !29
  %t426 = load ptr, ptr %l1, !tbaa !29
  %t428 = getelementptr { i64, [5 x i64] }, ptr %t426, i32 0, i32 1
  %t429 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t428, i32 0, i32 2
  %t430 = load { i64, ptr }, ptr %t429
  store { i64, ptr } %t430, ptr %l32, !tbaa !27
  br label %bb108
bb107:
  br label %bb117
bb108:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t432, ptr %t433)
  br label %bb109
bb109:
  %t436 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t436, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t438 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t438, 0
  store i64 %t440, ptr %l35, !tbaa !24
  br label %bb110
bb110:
  store %olang.scope zeroinitializer, ptr %s21
  %t442 = load i64, ptr %l34, !tbaa !24
  %t443 = load i64, ptr %l35, !tbaa !24
  %t446 = icmp slt i64 %t442, %t443
  %t448 = xor i1 %t446, true
  br i1 %t448, label %bb111, label %bb112
bb111:
  call void @__olang_scope_close(ptr %s21)
  br label %bb116
bb112:
  br label %bb113
bb113:
  %t450 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t450, ptr %l256, !tbaa !27
  %t451 = load i64, ptr %l34, !tbaa !24
  %t453 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !27
  %t455 = getelementptr ptr, ptr %t454, i64 %t451
  %t456 = load ptr, ptr %t455, !tbaa !39
  %t458 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t458, ptr %t456)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s21)
  br label %bb115
bb115:
  %t462 = load i64, ptr %l34, !tbaa !24
  %t464 = add i64 %t462, 1
  store i64 %t464, ptr %l34, !tbaa !24
  br label %bb110
bb116:
  br label %bb230
bb117:
  %t466 = load ptr, ptr %l1, !tbaa !29
  store ptr %t466, ptr %l263, !tbaa !29
  store i1 false, ptr %l264, !tbaa !21
  %t467 = load ptr, ptr %l263, !tbaa !29
  %t468 = icmp ne ptr %t467, null
  br i1 %t468, label %bb118, label %bb119
bb118:
  %t470 = load ptr, ptr %l263, !tbaa !29
  %t471 = load i64, ptr %t470
  %t473 = icmp eq i64 %t471, 15
  store i1 %t473, ptr %l264, !tbaa !21
  br label %bb119
bb119:
  %t474 = load i1, ptr %l264, !tbaa !21
  br i1 %t474, label %bb120, label %bb121
bb120:
  %t475 = load ptr, ptr %l1, !tbaa !29
  %t477 = getelementptr { i64, [5 x i64] }, ptr %t475, i32 0, i32 1
  %t478 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t477, i32 0, i32 0
  %t479 = load %"compiler/source:Span", ptr %t478
  store %"compiler/source:Span" %t479, ptr %l37
  %t481 = load ptr, ptr %l1, !tbaa !29
  %t483 = getelementptr { i64, [5 x i64] }, ptr %t481, i32 0, i32 1
  %t484 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t483, i32 0, i32 1
  %t485 = load ptr, ptr %t484
  store ptr %t485, ptr %l38, !tbaa !29
  %t487 = load ptr, ptr %l1, !tbaa !29
  %t489 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 1
  %t490 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t489, i32 0, i32 2
  %t491 = load i32, ptr %t490
  store i32 %t491, ptr %l39, !tbaa !23
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load %"compiler/source:Span", ptr %l37
  %t495 = load ptr, ptr %l38, !tbaa !29
  %t496 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emember(ptr %v0, ptr %v1, ptr %t493, %"compiler/source:Span" %t494, ptr %t495, i32 %t496)
  br label %bb123
bb123:
  br label %bb230
bb124:
  %t501 = load ptr, ptr %l1, !tbaa !29
  store ptr %t501, ptr %l277, !tbaa !29
  store i1 false, ptr %l278, !tbaa !21
  %t502 = load ptr, ptr %l277, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb125, label %bb126
bb125:
  %t505 = load ptr, ptr %l277, !tbaa !29
  %t506 = load i64, ptr %t505
  %t508 = icmp eq i64 %t506, 16
  store i1 %t508, ptr %l278, !tbaa !21
  br label %bb126
bb126:
  %t509 = load i1, ptr %l278, !tbaa !21
  br i1 %t509, label %bb127, label %bb128
bb127:
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [5 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t512, i32 0, i32 1
  %t514 = load ptr, ptr %t513
  store ptr %t514, ptr %l40, !tbaa !29
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr { i64, [5 x i64] }, ptr %t516, i32 0, i32 1
  %t519 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t518, i32 0, i32 2
  %t520 = load { i64, ptr }, ptr %t519
  store { i64, ptr } %t520, ptr %l41, !tbaa !27
  br label %bb129
bb128:
  br label %bb138
bb129:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t522, ptr %t523)
  br label %bb130
bb130:
  %t526 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t526, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t528 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t530 = extractvalue { i64, ptr } %t528, 0
  store i64 %t530, ptr %l44, !tbaa !24
  br label %bb131
bb131:
  store %olang.scope zeroinitializer, ptr %s26
  %t532 = load i64, ptr %l43, !tbaa !24
  %t533 = load i64, ptr %l44, !tbaa !24
  %t536 = icmp slt i64 %t532, %t533
  %t538 = xor i1 %t536, true
  br i1 %t538, label %bb132, label %bb133
bb132:
  call void @__olang_scope_close(ptr %s26)
  br label %bb137
bb133:
  br label %bb134
bb134:
  %t540 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t540, ptr %l294, !tbaa !27
  %t541 = load i64, ptr %l43, !tbaa !24
  %t543 = getelementptr { i64, ptr }, ptr %l294, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = getelementptr ptr, ptr %t544, i64 %t541
  %t546 = load ptr, ptr %t545, !tbaa !39
  %t548 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t548, ptr %t546)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s26)
  br label %bb136
bb136:
  %t552 = load i64, ptr %l43, !tbaa !24
  %t554 = add i64 %t552, 1
  store i64 %t554, ptr %l43, !tbaa !24
  br label %bb131
bb137:
  br label %bb230
bb138:
  %t556 = load ptr, ptr %l1, !tbaa !29
  store ptr %t556, ptr %l301, !tbaa !29
  store i1 false, ptr %l302, !tbaa !21
  %t557 = load ptr, ptr %l301, !tbaa !29
  %t558 = icmp ne ptr %t557, null
  br i1 %t558, label %bb139, label %bb140
bb139:
  %t560 = load ptr, ptr %l301, !tbaa !29
  %t561 = load i64, ptr %t560
  %t563 = icmp eq i64 %t561, 17
  store i1 %t563, ptr %l302, !tbaa !21
  br label %bb140
bb140:
  %t564 = load i1, ptr %l302, !tbaa !21
  br i1 %t564, label %bb141, label %bb142
bb141:
  %t565 = load ptr, ptr %l1, !tbaa !29
  %t567 = getelementptr { i64, [5 x i64] }, ptr %t565, i32 0, i32 1
  %t568 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t567, i32 0, i32 1
  %t569 = load ptr, ptr %t568
  store ptr %t569, ptr %l46, !tbaa !29
  %t571 = load ptr, ptr %l1, !tbaa !29
  %t573 = getelementptr { i64, [5 x i64] }, ptr %t571, i32 0, i32 1
  %t574 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t573, i32 0, i32 2
  %t575 = load ptr, ptr %t574
  store ptr %t575, ptr %l47, !tbaa !29
  %t577 = load ptr, ptr %l1, !tbaa !29
  %t579 = getelementptr { i64, [5 x i64] }, ptr %t577, i32 0, i32 1
  %t580 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t579, i32 0, i32 3
  %t581 = load ptr, ptr %t580
  store ptr %t581, ptr %l48, !tbaa !29
  br label %bb143
bb142:
  br label %bb147
bb143:
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = load ptr, ptr %l46, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t583, ptr %t584)
  br label %bb144
bb144:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t587, ptr %t588)
  br label %bb145
bb145:
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t592 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t591, ptr %t592)
  br label %bb146
bb146:
  br label %bb230
bb147:
  %t595 = load ptr, ptr %l1, !tbaa !29
  store ptr %t595, ptr %l317, !tbaa !29
  store i1 false, ptr %l318, !tbaa !21
  %t596 = load ptr, ptr %l317, !tbaa !29
  %t597 = icmp ne ptr %t596, null
  br i1 %t597, label %bb148, label %bb149
bb148:
  %t599 = load ptr, ptr %l317, !tbaa !29
  %t600 = load i64, ptr %t599
  %t602 = icmp eq i64 %t600, 18
  store i1 %t602, ptr %l318, !tbaa !21
  br label %bb149
bb149:
  %t603 = load i1, ptr %l318, !tbaa !21
  br i1 %t603, label %bb150, label %bb151
bb150:
  %t604 = load ptr, ptr %l1, !tbaa !29
  %t606 = getelementptr { i64, [5 x i64] }, ptr %t604, i32 0, i32 1
  %t607 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t606, i32 0, i32 1
  %t608 = load ptr, ptr %t607
  store ptr %t608, ptr %l49, !tbaa !29
  %t610 = load ptr, ptr %l1, !tbaa !29
  %t612 = getelementptr { i64, [5 x i64] }, ptr %t610, i32 0, i32 1
  %t613 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t612, i32 0, i32 2
  %t614 = load { i64, ptr }, ptr %t613
  store { i64, ptr } %t614, ptr %l50, !tbaa !27
  br label %bb152
bb151:
  br label %bb164
bb152:
  %t616 = load ptr, ptr %l49, !tbaa !29
  %t618 = icmp ne ptr %t616, null
  br i1 %t618, label %bb153, label %bb154
bb153:
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t621 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t620, ptr %t621)
  br label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb156
bb156:
  %t624 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t624, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t626 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t628 = extractvalue { i64, ptr } %t626, 0
  store i64 %t628, ptr %l53, !tbaa !24
  br label %bb157
bb157:
  store %olang.scope zeroinitializer, ptr %s32
  %t630 = load i64, ptr %l52, !tbaa !24
  %t631 = load i64, ptr %l53, !tbaa !24
  %t634 = icmp slt i64 %t630, %t631
  %t636 = xor i1 %t634, true
  br i1 %t636, label %bb158, label %bb159
bb158:
  call void @__olang_scope_close(ptr %s32)
  br label %bb163
bb159:
  br label %bb160
bb160:
  %t638 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t638, ptr %l336, !tbaa !27
  %t639 = load i64, ptr %l52, !tbaa !24
  %t641 = getelementptr { i64, ptr }, ptr %l336, i32 0, i32 1
  %t642 = load ptr, ptr %t641, !tbaa !27
  %t643 = getelementptr ptr, ptr %t642, i64 %t639
  %t644 = load ptr, ptr %t643, !tbaa !39
  %t646 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t646, ptr %t644)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s32)
  br label %bb162
bb162:
  %t650 = load i64, ptr %l52, !tbaa !24
  %t652 = add i64 %t650, 1
  store i64 %t652, ptr %l52, !tbaa !24
  br label %bb157
bb163:
  br label %bb230
bb164:
  %t654 = load ptr, ptr %l1, !tbaa !29
  store ptr %t654, ptr %l343, !tbaa !29
  store i1 false, ptr %l344, !tbaa !21
  %t655 = load ptr, ptr %l343, !tbaa !29
  %t656 = icmp ne ptr %t655, null
  br i1 %t656, label %bb165, label %bb166
bb165:
  %t658 = load ptr, ptr %l343, !tbaa !29
  %t659 = load i64, ptr %t658
  %t661 = icmp eq i64 %t659, 19
  store i1 %t661, ptr %l344, !tbaa !21
  br label %bb166
bb166:
  %t662 = load i1, ptr %l344, !tbaa !21
  br i1 %t662, label %bb167, label %bb168
bb167:
  %t663 = load ptr, ptr %l1, !tbaa !29
  %t665 = getelementptr { i64, [5 x i64] }, ptr %t663, i32 0, i32 1
  %t666 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t665, i32 0, i32 1
  %t667 = load { i64, ptr }, ptr %t666
  store { i64, ptr } %t667, ptr %l55, !tbaa !27
  br label %bb177
bb168:
  %t669 = load ptr, ptr %l1, !tbaa !29
  store ptr %t669, ptr %l349, !tbaa !29
  store i1 false, ptr %l350, !tbaa !21
  %t670 = load ptr, ptr %l349, !tbaa !29
  %t671 = icmp ne ptr %t670, null
  br i1 %t671, label %bb169, label %bb170
bb169:
  %t673 = load ptr, ptr %l349, !tbaa !29
  %t674 = load i64, ptr %t673
  %t676 = icmp eq i64 %t674, 21
  store i1 %t676, ptr %l350, !tbaa !21
  br label %bb170
bb170:
  %t677 = load i1, ptr %l350, !tbaa !21
  br i1 %t677, label %bb171, label %bb172
bb171:
  %t678 = load ptr, ptr %l1, !tbaa !29
  %t680 = getelementptr { i64, [5 x i64] }, ptr %t678, i32 0, i32 1
  %t681 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t680, i32 0, i32 1
  %t682 = load { i64, ptr }, ptr %t681
  store { i64, ptr } %t682, ptr %l55, !tbaa !27
  br label %bb177
bb172:
  %t684 = load ptr, ptr %l1, !tbaa !29
  store ptr %t684, ptr %l355, !tbaa !29
  store i1 false, ptr %l356, !tbaa !21
  %t685 = load ptr, ptr %l355, !tbaa !29
  %t686 = icmp ne ptr %t685, null
  br i1 %t686, label %bb173, label %bb174
bb173:
  %t688 = load ptr, ptr %l355, !tbaa !29
  %t689 = load i64, ptr %t688
  %t691 = icmp eq i64 %t689, 25
  store i1 %t691, ptr %l356, !tbaa !21
  br label %bb174
bb174:
  %t692 = load i1, ptr %l356, !tbaa !21
  br i1 %t692, label %bb175, label %bb176
bb175:
  %t693 = load ptr, ptr %l1, !tbaa !29
  %t695 = getelementptr { i64, [5 x i64] }, ptr %t693, i32 0, i32 1
  %t696 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t695, i32 0, i32 1
  %t697 = load { i64, ptr }, ptr %t696
  store { i64, ptr } %t697, ptr %l55, !tbaa !27
  br label %bb177
bb176:
  br label %bb185
bb177:
  %t699 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t699, ptr %l56, !tbaa !27
  store i64 0, ptr %l57, !tbaa !24
  %t701 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t703 = extractvalue { i64, ptr } %t701, 0
  store i64 %t703, ptr %l58, !tbaa !24
  br label %bb178
bb178:
  store %olang.scope zeroinitializer, ptr %s36
  %t705 = load i64, ptr %l57, !tbaa !24
  %t706 = load i64, ptr %l58, !tbaa !24
  %t709 = icmp slt i64 %t705, %t706
  %t711 = xor i1 %t709, true
  br i1 %t711, label %bb179, label %bb180
bb179:
  call void @__olang_scope_close(ptr %s36)
  br label %bb184
bb180:
  br label %bb181
bb181:
  %t713 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t713, ptr %l368, !tbaa !27
  %t714 = load i64, ptr %l57, !tbaa !24
  %t716 = getelementptr { i64, ptr }, ptr %l368, i32 0, i32 1
  %t717 = load ptr, ptr %t716, !tbaa !27
  %t718 = getelementptr ptr, ptr %t717, i64 %t714
  %t719 = load ptr, ptr %t718, !tbaa !39
  %t721 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t721, ptr %t719)
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s36)
  br label %bb183
bb183:
  %t725 = load i64, ptr %l57, !tbaa !24
  %t727 = add i64 %t725, 1
  store i64 %t727, ptr %l57, !tbaa !24
  br label %bb178
bb184:
  br label %bb230
bb185:
  %t729 = load ptr, ptr %l1, !tbaa !29
  store ptr %t729, ptr %l375, !tbaa !29
  store i1 false, ptr %l376, !tbaa !21
  %t730 = load ptr, ptr %l375, !tbaa !29
  %t731 = icmp ne ptr %t730, null
  br i1 %t731, label %bb186, label %bb187
bb186:
  %t733 = load ptr, ptr %l375, !tbaa !29
  %t734 = load i64, ptr %t733
  %t736 = icmp eq i64 %t734, 20
  store i1 %t736, ptr %l376, !tbaa !21
  br label %bb187
bb187:
  %t737 = load i1, ptr %l376, !tbaa !21
  br i1 %t737, label %bb188, label %bb189
bb188:
  %t738 = load ptr, ptr %l1, !tbaa !29
  %t740 = getelementptr { i64, [5 x i64] }, ptr %t738, i32 0, i32 1
  %t741 = getelementptr { %"compiler/source:Span", ptr }, ptr %t740, i32 0, i32 0
  %t742 = load %"compiler/source:Span", ptr %t741
  store %"compiler/source:Span" %t742, ptr %l60
  %t744 = load ptr, ptr %l1, !tbaa !29
  %t746 = getelementptr { i64, [5 x i64] }, ptr %t744, i32 0, i32 1
  %t747 = getelementptr { %"compiler/source:Span", ptr }, ptr %t746, i32 0, i32 1
  %t748 = load ptr, ptr %t747
  store ptr %t748, ptr %l61, !tbaa !29
  br label %bb190
bb189:
  br label %bb201
bb190:
  %t750 = load ptr, ptr %l61, !tbaa !29
  %t752 = getelementptr %"compiler/ast:Compr", ptr %t750, i32 0, i32 0
  %t753 = load ptr, ptr %t752, !tbaa !29
  %t755 = icmp ne ptr %t753, null
  br i1 %t755, label %bb191, label %bb192
bb191:
  %t757 = load ptr, ptr %l0, !tbaa !29
  %t758 = load ptr, ptr %l61, !tbaa !29
  %t760 = getelementptr %"compiler/ast:Compr", ptr %t758, i32 0, i32 0
  %t761 = load ptr, ptr %t760, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t757, ptr %t761)
  br label %bb193
bb192:
  br label %bb194
bb193:
  br label %bb194
bb194:
  %t764 = load ptr, ptr %l0, !tbaa !29
  %t765 = load ptr, ptr %l61, !tbaa !29
  %t767 = getelementptr %"compiler/ast:Compr", ptr %t765, i32 0, i32 4
  %t768 = load ptr, ptr %t767, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t764, ptr %t768)
  br label %bb195
bb195:
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t773 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t771)
  store i64 %t773, ptr %l393
  br label %bb196
bb196:
  %t774 = load i64, ptr %l393, !tbaa !24
  store i64 %t774, ptr %l62, !tbaa !24
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t776 = getelementptr %"compiler/source:Span", ptr %l60, i32 0, i32 0
  %t777 = load i32, ptr %t776, !tbaa !23
  %t778 = load ptr, ptr %l61, !tbaa !29
  %t780 = getelementptr %"compiler/ast:Compr", ptr %t778, i32 0, i32 2
  %t781 = load i32, ptr %t780, !tbaa !23
  %t782 = load ptr, ptr %l61, !tbaa !29
  %t784 = getelementptr %"compiler/ast:Compr", ptr %t782, i32 0, i32 3
  %t785 = load i32, ptr %t784, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforNames(ptr %v0, ptr %t775, i32 %t777, i32 %t781, i32 %t785)
  br label %bb197
bb197:
  %t790 = load ptr, ptr %l0, !tbaa !29
  %t791 = load ptr, ptr %l61, !tbaa !29
  %t793 = getelementptr %"compiler/ast:Compr", ptr %t791, i32 0, i32 1
  %t794 = load ptr, ptr %t793, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t790, ptr %t794)
  br label %bb198
bb198:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t798 = load ptr, ptr %l61, !tbaa !29
  %t800 = getelementptr %"compiler/ast:Compr", ptr %t798, i32 0, i32 5
  %t801 = load ptr, ptr %t800, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t797, ptr %t801)
  br label %bb199
bb199:
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t805 = load i64, ptr %l62, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t804, i64 %t805)
  br label %bb200
bb200:
  br label %bb230
bb201:
  %t808 = load ptr, ptr %l1, !tbaa !29
  store ptr %t808, ptr %l408, !tbaa !29
  store i1 false, ptr %l409, !tbaa !21
  %t809 = load ptr, ptr %l408, !tbaa !29
  %t810 = icmp ne ptr %t809, null
  br i1 %t810, label %bb202, label %bb203
bb202:
  %t812 = load ptr, ptr %l408, !tbaa !29
  %t813 = load i64, ptr %t812
  %t815 = icmp eq i64 %t813, 22
  store i1 %t815, ptr %l409, !tbaa !21
  br label %bb203
bb203:
  %t816 = load i1, ptr %l409, !tbaa !21
  br i1 %t816, label %bb204, label %bb205
bb204:
  %t817 = load ptr, ptr %l1, !tbaa !29
  %t819 = getelementptr { i64, [5 x i64] }, ptr %t817, i32 0, i32 1
  %t820 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t819, i32 0, i32 1
  %t821 = load ptr, ptr %t820
  store ptr %t821, ptr %l63, !tbaa !29
  %t823 = load ptr, ptr %l1, !tbaa !29
  %t825 = getelementptr { i64, [5 x i64] }, ptr %t823, i32 0, i32 1
  %t826 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t825, i32 0, i32 2
  %t827 = load { i64, ptr }, ptr %t826
  store { i64, ptr } %t827, ptr %l64, !tbaa !27
  br label %bb206
bb205:
  br label %bb209
bb206:
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t830 = load ptr, ptr %l63, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t829, ptr %t830)
  br label %bb207
bb207:
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t834 = load { i64, ptr }, ptr %l64, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t833, { i64, ptr } %t834)
  br label %bb208
bb208:
  br label %bb230
bb209:
  %t837 = load ptr, ptr %l1, !tbaa !29
  store ptr %t837, ptr %l420, !tbaa !29
  store i1 false, ptr %l421, !tbaa !21
  %t838 = load ptr, ptr %l420, !tbaa !29
  %t839 = icmp ne ptr %t838, null
  br i1 %t839, label %bb210, label %bb211
bb210:
  %t841 = load ptr, ptr %l420, !tbaa !29
  %t842 = load i64, ptr %t841
  %t844 = icmp eq i64 %t842, 23
  store i1 %t844, ptr %l421, !tbaa !21
  br label %bb211
bb211:
  %t845 = load i1, ptr %l421, !tbaa !21
  br i1 %t845, label %bb212, label %bb213
bb212:
  %t846 = load ptr, ptr %l1, !tbaa !29
  %t848 = getelementptr { i64, [5 x i64] }, ptr %t846, i32 0, i32 1
  %t849 = getelementptr { %"compiler/source:Span", ptr }, ptr %t848, i32 0, i32 1
  %t850 = load ptr, ptr %t849
  store ptr %t850, ptr %l65, !tbaa !29
  br label %bb214
bb213:
  br label %bb222
bb214:
  %t852 = load ptr, ptr %l0, !tbaa !29
  %t854 = getelementptr %"compiler/names:Resolver", ptr %t852, i32 0, i32 12
  %t855 = load i1, ptr %t854, !tbaa !21
  store i1 %t855, ptr %l66, !tbaa !21
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t859 = getelementptr %"compiler/names:Resolver", ptr %t857, i32 0, i32 12
  store i1 false, ptr %t859, !tbaa !21
  %t860 = load ptr, ptr %l0, !tbaa !29
  %t862 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t860)
  store i64 %t862, ptr %l430
  br label %bb215
bb215:
  %t863 = load i64, ptr %l430, !tbaa !24
  store i64 %t863, ptr %l67, !tbaa !24
  %t864 = load ptr, ptr %l0, !tbaa !29
  %t866 = getelementptr %"compiler/names:Resolver", ptr %t864, i32 0, i32 13
  store i1 true, ptr %t866, !tbaa !21
  %t867 = load ptr, ptr %l0, !tbaa !29
  %t868 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t867, ptr %t868, i1 true)
  br label %bb216
bb216:
  %t871 = load ptr, ptr %l0, !tbaa !29
  %t873 = getelementptr %"compiler/names:Resolver", ptr %t871, i32 0, i32 13
  store i1 false, ptr %t873, !tbaa !21
  %t874 = load ptr, ptr %l65, !tbaa !29
  %t876 = getelementptr %"compiler/ast:Func", ptr %t874, i32 0, i32 4
  %t877 = load { i64, ptr }, ptr %t876, !tbaa !27
  %t879 = extractvalue { i64, ptr } %t877, 0
  %t880 = extractvalue { i64, ptr } zeroinitializer, 0
  %t881 = icmp eq i64 %t879, %t880
  %t882 = extractvalue { i64, ptr } %t877, 1
  %t883 = extractvalue { i64, ptr } zeroinitializer, 1
  %t884 = icmp eq ptr %t882, %t883
  %t885 = and i1 %t881, %t884
  %t886 = xor i1 %t885, true
  br i1 %t886, label %bb217, label %bb218
bb217:
  %t888 = load ptr, ptr %l0, !tbaa !29
  %t889 = load ptr, ptr %l65, !tbaa !29
  %t891 = getelementptr %"compiler/ast:Func", ptr %t889, i32 0, i32 4
  %t892 = load { i64, ptr }, ptr %t891, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t888, { i64, ptr } %t892)
  br label %bb219
bb218:
  br label %bb220
bb219:
  br label %bb220
bb220:
  %t895 = load ptr, ptr %l0, !tbaa !29
  %t896 = load i64, ptr %l67, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t895, i64 %t896)
  br label %bb221
bb221:
  %t899 = load ptr, ptr %l0, !tbaa !29
  %t900 = load i1, ptr %l66, !tbaa !21
  %t903 = getelementptr %"compiler/names:Resolver", ptr %t899, i32 0, i32 12
  store i1 %t900, ptr %t903, !tbaa !21
  br label %bb230
bb222:
  %t904 = load ptr, ptr %l1, !tbaa !29
  store ptr %t904, ptr %l445, !tbaa !29
  store i1 false, ptr %l446, !tbaa !21
  %t905 = load ptr, ptr %l445, !tbaa !29
  %t906 = icmp ne ptr %t905, null
  br i1 %t906, label %bb223, label %bb224
bb223:
  %t908 = load ptr, ptr %l445, !tbaa !29
  %t909 = load i64, ptr %t908
  %t911 = icmp eq i64 %t909, 24
  store i1 %t911, ptr %l446, !tbaa !21
  br label %bb224
bb224:
  %t912 = load i1, ptr %l446, !tbaa !21
  br i1 %t912, label %bb225, label %bb226
bb225:
  %t913 = load ptr, ptr %l1, !tbaa !29
  %t915 = getelementptr { i64, [5 x i64] }, ptr %t913, i32 0, i32 1
  %t916 = getelementptr { %"compiler/source:Span", ptr }, ptr %t915, i32 0, i32 1
  %t917 = load ptr, ptr %t916
  store ptr %t917, ptr %l68, !tbaa !29
  br label %bb227
bb226:
  br label %bb229
bb227:
  %t919 = load ptr, ptr %l0, !tbaa !29
  %t920 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ematchOf(ptr %v0, ptr %v1, ptr %t919, ptr %t920)
  br label %bb228
bb228:
  br label %bb230
bb229:
  br label %bb230
bb230:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforName(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l22 = alloca i1
  %l26 = alloca %"compiler/names:local"
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i1
  %l38 = alloca ptr
  %l42 = alloca i1
  %l45 = alloca ptr
  %l50 = alloca { i64, [3 x i64] }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca %"compiler/msgs:Msg"
  %l59 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 6
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = load i32, ptr %l2, !tbaa !23
  %t16 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t5, i64 %t9, i32 %a1, i32 %t11)
  store %"compiler/source:Span" %t16, ptr %l13
  br label %bb4
bb4:
  %t17 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t17, ptr %l3
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 8
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t20, i32 %t21)
  %t25 = extractvalue { i32, i64 } %t24, 1
  %t26 = extractvalue { i32, i64 } %t24, 0
  store i32 %t26, ptr %l19
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb6, label %ok.28
ok.28:
  store i64 %t25, ptr %l18
  br label %bb5
bb5:
  %t29 = load i64, ptr %l18, !tbaa !24
  store i64 %t29, ptr %l14, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 -1, ptr %l14, !tbaa !24
  br label %bb8
bb8:
  %t30 = load i64, ptr %l14, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sge i64 %t31, 0
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/names:Resolver", ptr %t35, i32 0, i32 7
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = call %"compiler/names:local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t37, i64 %t38)
  store %"compiler/names:local" %t41, ptr %l26
  br label %bb11
bb10:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb13
bb11:
  %t42 = getelementptr %"compiler/names:local", ptr %l26, i32 0, i32 2
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l27
  store i32 1, ptr %l29
  %t46 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l27, ptr %l29)
  store i1 %t46, ptr %l31
  br label %bb12
bb12:
  %t47 = load i1, ptr %l31, !tbaa !21
  store i1 %t47, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t48 = load i1, ptr %l22, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb18
bb15:
  %t49 = load i32, ptr %l2, !tbaa !23
  store i32 %t49, ptr %l5, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/names:Resolver", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/names:Resolver", ptr %t54, i32 0, i32 6
  %t57 = load i64, ptr %t56, !tbaa !24
  %t60 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t53, i64 %t57)
  store ptr %t60, ptr %l38
  br label %bb16
bb16:
  %t61 = load ptr, ptr %l38, !tbaa !29
  %t63 = getelementptr %"compiler/names:Table", ptr %t61, i32 0, i32 1
  %t64 = load i32, ptr %l5, !tbaa !23
  %t67 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t63, i32 %t64)
  store i1 %t67, ptr %l42
  br label %bb17
bb17:
  %t68 = load i1, ptr %l42, !tbaa !21
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb18
bb18:
  %t69 = load i1, ptr %l32, !tbaa !21
  br i1 %t69, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/names:Resolver", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/load:Loader", ptr %t73, i32 0, i32 4
  %t76 = load ptr, ptr %t75, !tbaa !29
  store ptr %t76, ptr %l45, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/names:Resolver", ptr %t78, i32 0, i32 6
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load %"compiler/source:Span", ptr %l3
  %t86 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t77, i64 %t81, %"compiler/source:Span" %t82)
  store { i64, [3 x i64] } %t86, ptr %l50
  br label %bb21
bb20:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l2, !tbaa !23
  %t89 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t87, i32 %t88, %"compiler/source:Span" %t89, i1 false)
  br label %bb27
bb21:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l2, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t93, i32 %t94)
  store { i64, ptr } %t97, ptr %l53
  br label %bb22
bb22:
  %t98 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l54, !tbaa !27
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l2, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t105, i32 %t106)
  store { i64, ptr } %t109, ptr %l57
  br label %bb23
bb23:
  %t110 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t112 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInNameExists(ptr %s2, ptr %v0, ptr %s2, { i64, ptr } %t110, { i64, ptr } %t111)
  store %"compiler/msgs:Msg" %t112, ptr %l58
  br label %bb24
bb24:
  %t113 = load ptr, ptr %l45, !tbaa !29
  %t114 = load { i64, [3 x i64] }, ptr %l50
  %t115 = load %"compiler/msgs:Msg", ptr %l58
  %t116 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t113, { i64, [3 x i64] } %t114, %"compiler/msgs:Msg" %t115)
  store i64 %t116, ptr %l59
  br label %bb25
bb25:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l2, !tbaa !23
  %t119 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t117, i32 %t118, %"compiler/source:Span" %t119, i32 1)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforNames(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforName(ptr %v0, ptr %t1, i32 %t2, i32 %a2)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforName(ptr %v0, ptr %t7, i32 %t8, i32 %a3)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i64, ptr %l4, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t5, ptr %t6, i1 true)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Func", ptr %t9, i32 0, i32 4
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } zeroinitializer, 0
  %t16 = icmp eq i64 %t14, %t15
  %t17 = extractvalue { i64, ptr } %t12, 1
  %t18 = extractvalue { i64, ptr } zeroinitializer, 1
  %t19 = icmp eq ptr %t17, %t18
  %t20 = and i1 %t16, %t19
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Func", ptr %t24, i32 0, i32 4
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t23, { i64, ptr } %t27)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t30, i64 %t31)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i32, i1 }
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l23 = alloca { i32, i1 }
  %l26 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i1
  %l32 = alloca ptr
  %l38 = alloca ptr
  %l40 = alloca i64
  %l43 = alloca %"compiler/source:Span"
  %l46 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l47 = alloca i32
  %l49 = alloca i32
  %l51 = alloca i1
  %l52 = alloca i32
  %l54 = alloca i32
  %l56 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l92 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:If", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %t8, ptr %t12)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/names:Resolver", ptr %t15, i32 0, i32 12
  store i1 true, ptr %t17, !tbaa !21
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:If", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t18, ptr %t22)
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/names:Resolver", ptr %t25, i32 0, i32 12
  store i1 false, ptr %t27, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:If", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t35 = call { i32, i1 } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edecideLocal(ptr %v0, ptr %v1, ptr %t28, ptr %t32)
  store { i32, i1 } %t35, ptr %l23
  br label %bb6
bb6:
  %t36 = load { i32, i1 }, ptr %l23
  store { i32, i1 } %t36, ptr %l2
  %t37 = getelementptr { i32, i1 }, ptr %l2, i32 0, i32 0
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l3
  %t40 = getelementptr { i32, i1 }, ptr %l2, i32 0, i32 1
  %t41 = load i1, ptr %t40, !tbaa !21
  store i1 %t41, ptr %l4, !tbaa !21
  %t43 = load i32, ptr %l3
  store i32 %t43, ptr %l26
  store i32 4, ptr %l28
  %t46 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aOutcome(ptr %l26, ptr %l28)
  store i1 %t46, ptr %l30
  br label %bb7
bb7:
  %t47 = load i1, ptr %l30, !tbaa !21
  br i1 %t47, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/names:Resolver", ptr %t48, i32 0, i32 16
  store ptr %t50, ptr %l32, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/names:Resolver", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/load:Loader", ptr %t54, i32 0, i32 5
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/names:Resolver", ptr %t57, i32 0, i32 6
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t56, i64 %t60)
  store ptr %t63, ptr %l38
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t64 = load ptr, ptr %l38, !tbaa !29
  %t66 = getelementptr %"compiler/load:Module", ptr %t64, i32 0, i32 4
  %t67 = load i64, ptr %t66, !tbaa !24
  store i64 %t67, ptr %l40, !tbaa !24
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr %"compiler/ast:If", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t71)
  store %"compiler/source:Span" %t73, ptr %l43
  br label %bb11
bb11:
  %t74 = getelementptr %"compiler/source:Span", ptr %l43, i32 0, i32 0
  %t75 = load i32, ptr %t74, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t78 = load i64, ptr %l40, !tbaa !24
  %t80 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t78, i64 %t77)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t80, ptr %l46
  br label %bb12
bb12:
  %t81 = load ptr, ptr %l32, !tbaa !29
  %t82 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l46
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t81, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t82, i1 true)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t83 = load i32, ptr %l3
  store i32 %t83, ptr %l47
  store i32 0, ptr %l49
  %t86 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aOutcome(ptr %l47, ptr %l49)
  store i1 %t86, ptr %l51
  br label %bb15
bb15:
  %t87 = load i1, ptr %l51, !tbaa !21
  store i1 %t87, ptr %l5, !tbaa !21
  %t88 = load i32, ptr %l3
  store i32 %t88, ptr %l52
  store i32 1, ptr %l54
  %t91 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aOutcome(ptr %l52, ptr %l54)
  store i1 %t91, ptr %l56
  br label %bb16
bb16:
  %t92 = load i1, ptr %l56, !tbaa !21
  %t93 = xor i1 %t92, true
  store i1 %t93, ptr %l6, !tbaa !21
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/ast:If", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i1, ptr %l5, !tbaa !21
  %t101 = load i1, ptr %l4, !tbaa !21
  %t102 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2echoose(ptr %v0, ptr %v1, ptr %t95, ptr %t99, i1 %t100, i1 %t101, i1 %t102)
  br label %bb17
bb17:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/ast:If", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %t108, ptr %t112)
  br label %bb18
bb18:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/ast:If", ptr %t115, i32 0, i32 2
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = icmp eq ptr %t118, null
  br i1 %t120, label %bb19, label %bb20
bb19:
  br label %ret
bb20:
  br label %bb21
bb21:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/ast:If", ptr %t122, i32 0, i32 2
  %t125 = load ptr, ptr %t124, !tbaa !29
  store ptr %t125, ptr %l7, !tbaa !29
  %t127 = load ptr, ptr %l7, !tbaa !29
  store ptr %t127, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t128 = load ptr, ptr %l72, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb22, label %bb23
bb22:
  %t131 = load ptr, ptr %l72, !tbaa !29
  %t132 = load i64, ptr %t131
  %t134 = icmp eq i64 %t132, 5
  store i1 %t134, ptr %l73, !tbaa !21
  br label %bb23
bb23:
  %t135 = load i1, ptr %l73, !tbaa !21
  br i1 %t135, label %bb24, label %bb25
bb24:
  %t136 = load ptr, ptr %l7, !tbaa !29
  %t138 = getelementptr { i64, [5 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr }, ptr %t138, i32 0, i32 1
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l8, !tbaa !29
  br label %bb26
bb25:
  br label %bb40
bb26:
  %t142 = load ptr, ptr %l8, !tbaa !29
  %t144 = getelementptr %"compiler/ast:If", ptr %t142, i32 0, i32 0
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = icmp eq ptr %t145, null
  br i1 %t147, label %bb27, label %bb28
bb27:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l8, !tbaa !29
  %t152 = getelementptr %"compiler/ast:If", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t154 = load i1, ptr %l5, !tbaa !21
  %t155 = load i1, ptr %l4, !tbaa !21
  %t157 = xor i1 %t155, true
  %t158 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2echoose(ptr %v0, ptr %v1, ptr %t149, ptr %t153, i1 %t154, i1 %t157, i1 %t158)
  br label %bb29
bb28:
  %t164 = load i1, ptr %l5, !tbaa !21
  br i1 %t164, label %bb31, label %bb32
bb29:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l8, !tbaa !29
  %t169 = getelementptr %"compiler/ast:If", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %t166, ptr %t170)
  br label %bb30
bb30:
  br label %bb39
bb31:
  %t173 = load i1, ptr %l4, !tbaa !21
  store i1 %t173, ptr %l92, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb33
bb33:
  %t175 = load i1, ptr %l92, !tbaa !21
  br i1 %t175, label %bb34, label %bb35
bb34:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edropAll(ptr %v0, ptr %v1, ptr %t176, ptr %t177)
  br label %bb36
bb35:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eifStmt(ptr %v0, ptr %v1, ptr %t180, ptr %t181)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb46
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load ptr, ptr %l1, !tbaa !29
  %t187 = getelementptr %"compiler/ast:If", ptr %t185, i32 0, i32 2
  %t188 = load ptr, ptr %t187, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t184, ptr %t188)
  br label %bb44
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @.c32)
  unreachable
bb46:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eimportedType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/load:Import"
  %l8 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l30 = alloca { i64, ptr }
  %l35 = alloca i1
  %l40 = alloca ptr
  %l44 = alloca i1
  %l45 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l51 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 6
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l14
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l14, !tbaa !29
  %t16 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 11
  store ptr %t16, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t18, i64 %t19)
  %t23 = extractvalue { i32, { i64, ptr } } %t22, 1
  %t24 = extractvalue { i32, { i64, ptr } } %t22, 0
  store i32 %t24, ptr %l21
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb4, label %ok.26
ok.26:
  store { i64, ptr } %t23, ptr %l20
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  br label %bb8
bb4:
  %t28 = load i32, ptr %l21, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  br i1 %t31, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c33)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb8:
  %t33 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb11:
  br label %bb12
bb12:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l30, !tbaa !27
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr %"compiler/load:Import", ptr %t50, i64 %t47
  %t52 = load %"compiler/load:Import", ptr %t51
  store %"compiler/load:Import" %t52, ptr %l7
  %t54 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 5
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load i32, ptr %l1, !tbaa !23
  store i32 %t59, ptr %l8, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/names:Resolver", ptr %t61, i32 0, i32 1
  %t64 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 5
  %t65 = load i64, ptr %t64, !tbaa !24
  %t68 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t63, i64 %t65)
  store ptr %t68, ptr %l40
  br label %bb15
bb14:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb17
bb15:
  %t69 = load ptr, ptr %l40, !tbaa !29
  %t71 = getelementptr %"compiler/names:Table", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l8, !tbaa !23
  %t75 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t71, i32 %t72)
  store i1 %t75, ptr %l44
  br label %bb16
bb16:
  %t76 = load i1, ptr %l44, !tbaa !21
  store i1 %t76, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t77 = load i1, ptr %l35, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l1, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l48
  br label %bb20
bb19:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb22
bb20:
  %t83 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t83, ptr %l49, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i8, ptr %t85, i64 0
  %t87 = load i8, ptr %t86, !tbaa !32
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t87)
  store i1 %t89, ptr %l51
  br label %bb21
bb21:
  %t90 = load i1, ptr %l51, !tbaa !21
  store i1 %t90, ptr %l45, !tbaa !21
  br label %bb22
bb22:
  %t91 = load i1, ptr %l45, !tbaa !21
  br i1 %t91, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb9
bb27:
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = add i64 %t97, %t98
  store i64 %t101, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  br label %bb2
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eintroduce(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l18 = alloca i1
  %l22 = alloca %"compiler/names:local"
  %l23 = alloca i32
  %l25 = alloca i32
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l34 = alloca %"compiler/names:Ref"
  %l40 = alloca %"compiler/source:Span"
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca i32
  %l49 = alloca i64
  %l52 = alloca i64
  %l54 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 8
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l15
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb6, label %ok.19
ok.19:
  store i64 %t16, ptr %l14
  br label %bb5
bb5:
  %t20 = load i64, ptr %l14, !tbaa !24
  store i64 %t20, ptr %l10, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  %t21 = load i64, ptr %l10, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb9, label %bb10
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/names:Resolver", ptr %t26, i32 0, i32 7
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = call %"compiler/names:local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/names:local" %t32, ptr %l22
  br label %bb11
bb10:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb13
bb11:
  %t33 = getelementptr %"compiler/names:local", ptr %l22, i32 0, i32 2
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l23
  store i32 8, ptr %l25
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l23, ptr %l25)
  store i1 %t37, ptr %l27
  br label %bb12
bb12:
  %t38 = load i1, ptr %l27, !tbaa !21
  store i1 %t38, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l28, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t41, ptr %l29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/names:Resolver", ptr %t42, i32 0, i32 6
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t50 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 8, i64 %t45, i64 %t46)
  store %"compiler/names:Ref" %t50, ptr %l34
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l29
  %t53 = load %"compiler/names:Ref", ptr %l34
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t51, %"compiler/source:Span" %t52, %"compiler/names:Ref" %t53)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/names:Resolver", ptr %t55, i32 0, i32 6
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t61 = load i32, ptr %l2, !tbaa !23
  %t66 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t54, i64 %t58, i32 %t60, i32 %t61)
  store %"compiler/source:Span" %t66, ptr %l40
  br label %bb19
bb19:
  %t67 = load %"compiler/source:Span", ptr %l40
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t68, i32 %t69, %"compiler/source:Span" %t67, i32 8)
  br label %bb20
bb20:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l45, !tbaa !29
  %t76 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t76, ptr %l46
  store i32 8, ptr %l47
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/names:Resolver", ptr %t77, i32 0, i32 6
  %t80 = load i64, ptr %t79, !tbaa !24
  store i64 %t80, ptr %l49, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/names:Resolver", ptr %t81, i32 0, i32 7
  %t85 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t83)
  store i64 %t85, ptr %l52
  br label %bb21
bb21:
  %t86 = load i64, ptr %l52, !tbaa !24
  %t87 = sub i64 %t86, 1
  %t88 = load i32, ptr %l47
  %t89 = load i64, ptr %l49, !tbaa !24
  %t91 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 %t88, i64 %t89, i64 %t87)
  store %"compiler/names:Ref" %t91, ptr %l54
  br label %bb22
bb22:
  %t92 = load ptr, ptr %l45, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l46
  %t94 = load %"compiler/names:Ref", ptr %l54
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t92, %"compiler/source:Span" %t93, %"compiler/names:Ref" %t94)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/names:Ref"
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l21 = alloca %"compiler/names:local"
  %l26 = alloca %"compiler/names:Ref"
  %l31 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i32
  %l43 = alloca %"compiler/names:Entry"
  %l48 = alloca %"compiler/names:Ref"
  %l49 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l61 = alloca %"compiler/names:Ref"
  %l62 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i32
  %l72 = alloca %"compiler/names:Ref"
  %l75 = alloca { i64, ptr }
  %l80 = alloca i1
  %l82 = alloca %"compiler/names:Ref"
  %l83 = alloca %"compiler/names:Ref"
  %l87 = alloca %"compiler/names:Ref"
  %l88 = alloca i32
  %l90 = alloca %"compiler/names:Ref"
  %l91 = alloca i32
  %l93 = alloca i32
  %l95 = alloca i1
  %l98 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i32
  %l106 = alloca i32
  %l107 = alloca i64
  %l108 = alloca i64
  %l112 = alloca ptr
  %l116 = alloca i64
  %l117 = alloca i32
  %l118 = alloca %"compiler/names:Ref"
  %l120 = alloca i1
  %l122 = alloca %"compiler/names:Ref"
  %l124 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 8
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l15
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l14
  br label %bb1
bb1:
  %t12 = load i64, ptr %l14, !tbaa !24
  store i64 %t12, ptr %l10, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l10, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 7
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call %"compiler/names:local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t20, i64 %t21)
  store %"compiler/names:local" %t24, ptr %l21
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t25 = getelementptr %"compiler/names:local", ptr %l21, i32 0, i32 2
  %t26 = load i32, ptr %t25
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 6
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t35 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s1, i32 %t26, i64 %t30, i64 %t31)
  store %"compiler/names:Ref" %t35, ptr %l26
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t36 = load %"compiler/names:Ref", ptr %l26
  store %"compiler/names:Ref" %t36, ptr %rv
  br label %ret
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 6
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t39, i64 %t43)
  store ptr %t46, ptr %l31
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l31, !tbaa !29
  store ptr %t47, ptr %l3, !tbaa !29
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t50 = getelementptr %"compiler/names:Table", ptr %t48, i32 0, i32 1
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t50, i32 %t51)
  %t55 = extractvalue { i32, i64 } %t54, 1
  %t56 = extractvalue { i32, i64 } %t54, 0
  store i32 %t56, ptr %l37
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb12, label %ok.58
ok.58:
  store i64 %t55, ptr %l36
  br label %bb11
bb11:
  %t59 = load i64, ptr %l36, !tbaa !24
  store i64 %t59, ptr %l32, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l32, !tbaa !24
  br label %bb14
bb14:
  %t60 = load i64, ptr %l32, !tbaa !24
  store i64 %t60, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = icmp sge i64 %t61, 0
  br i1 %t63, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr %"compiler/names:Table", ptr %t65, i32 0, i32 0
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s2, ptr %t67, i64 %t68)
  store %"compiler/names:Entry" %t71, ptr %l43
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t72 = getelementptr %"compiler/names:Entry", ptr %l43, i32 0, i32 2
  %t73 = load i32, ptr %t72
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/names:Resolver", ptr %t74, i32 0, i32 6
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = load i64, ptr %l4, !tbaa !24
  %t82 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 %t73, i64 %t77, i64 %t78)
  store %"compiler/names:Ref" %t82, ptr %l48
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t83 = load %"compiler/names:Ref", ptr %l48
  store %"compiler/names:Ref" %t83, ptr %rv
  br label %ret
bb19:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/names:Table", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l1, !tbaa !23
  %t90 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t86, i32 %t87)
  %t91 = extractvalue { i32, i64 } %t90, 1
  %t92 = extractvalue { i32, i64 } %t90, 0
  store i32 %t92, ptr %l54
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb21, label %ok.94
ok.94:
  store i64 %t91, ptr %l53
  br label %bb20
bb20:
  %t95 = load i64, ptr %l53, !tbaa !24
  store i64 %t95, ptr %l49, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb23
bb23:
  %t96 = load i64, ptr %l49, !tbaa !24
  store i64 %t96, ptr %l5, !tbaa !24
  %t97 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp sge i64 %t97, 0
  br i1 %t99, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/names:Resolver", ptr %t101, i32 0, i32 6
  %t104 = load i64, ptr %t103, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t109 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s3, i32 4, i64 %t104, i64 %t105)
  store %"compiler/names:Ref" %t109, ptr %l61
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t110 = load %"compiler/names:Ref", ptr %l61
  store %"compiler/names:Ref" %t110, ptr %rv
  br label %ret
bb27:
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/names:Table", ptr %t111, i32 0, i32 3
  %t114 = load i32, ptr %l1, !tbaa !23
  %t117 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t113, i32 %t114)
  %t118 = extractvalue { i32, i64 } %t117, 1
  %t119 = extractvalue { i32, i64 } %t117, 0
  store i32 %t119, ptr %l67
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb29, label %ok.121
ok.121:
  store i64 %t118, ptr %l66
  br label %bb28
bb28:
  %t122 = load i64, ptr %l66, !tbaa !24
  store i64 %t122, ptr %l62, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %l62, !tbaa !24
  br label %bb31
bb31:
  %t123 = load i64, ptr %l62, !tbaa !24
  store i64 %t123, ptr %l6, !tbaa !24
  %t124 = load i64, ptr %l6, !tbaa !24
  %t126 = icmp sge i64 %t124, 0
  br i1 %t126, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s4
  %t128 = load i64, ptr %l6, !tbaa !24
  %t131 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s4, i32 5, i64 %t128, i64 -1)
  store %"compiler/names:Ref" %t131, ptr %l72
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t132 = load %"compiler/names:Ref", ptr %l72
  store %"compiler/names:Ref" %t132, ptr %rv
  br label %ret
bb35:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l1, !tbaa !23
  %t137 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t133, i32 %t134)
  store { i64, ptr } %t137, ptr %l75
  br label %bb36
bb36:
  %t138 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/names:Resolver", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/load:Loader", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t149 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v0, ptr %t145, { i64, ptr } %t146)
  store i1 %t149, ptr %l80
  br label %bb37
bb37:
  %t150 = load i1, ptr %l80, !tbaa !21
  br i1 %t150, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t152 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s5, i32 6, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t152, ptr %l82
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t153 = load %"compiler/names:Ref", ptr %l82
  store %"compiler/names:Ref" %t153, ptr %rv
  br label %ret
bb41:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/names:Resolver", ptr %t154, i32 0, i32 3
  %t157 = load i32, ptr %l1, !tbaa !23
  %t160 = call { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H678d1b43e8b98a171ffdea8f28643d28(ptr %v0, ptr %t156, i32 %t157)
  %t161 = extractvalue { i32, %"compiler/names:Ref" } %t160, 1
  %t162 = extractvalue { i32, %"compiler/names:Ref" } %t160, 0
  store i32 %t162, ptr %l88
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb43, label %ok.164
ok.164:
  store %"compiler/names:Ref" %t161, ptr %l87
  br label %bb42
bb42:
  %t165 = load %"compiler/names:Ref", ptr %l87
  store %"compiler/names:Ref" %t165, ptr %l83
  br label %bb46
bb43:
  br label %bb44
bb44:
  %t167 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t167, ptr %l90
  br label %bb45
bb45:
  %t168 = load %"compiler/names:Ref", ptr %l90
  store %"compiler/names:Ref" %t168, ptr %l83
  br label %bb46
bb46:
  %t169 = load %"compiler/names:Ref", ptr %l83
  store %"compiler/names:Ref" %t169, ptr %l8
  %t170 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t171 = load i32, ptr %t170
  store i32 %t171, ptr %l91
  store i32 0, ptr %l93
  %t174 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l91, ptr %l93)
  store i1 %t174, ptr %l95
  br label %bb47
bb47:
  %t175 = load i1, ptr %l95, !tbaa !21
  %t176 = xor i1 %t175, true
  br i1 %t176, label %bb48, label %bb49
bb48:
  %t178 = load %"compiler/names:Ref", ptr %l8
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/names:Ref" %t178, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/names:Resolver", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l1, !tbaa !23
  %t186 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t182, i32 %t183)
  %t187 = extractvalue { i32, i64 } %t186, 1
  %t188 = extractvalue { i32, i64 } %t186, 0
  store i32 %t188, ptr %l103
  %t189 = icmp ne i32 %t188, 0
  br i1 %t189, label %bb52, label %ok.190
ok.190:
  store i64 %t187, ptr %l102
  br label %bb51
bb51:
  %t191 = load i64, ptr %l102, !tbaa !24
  store i64 %t191, ptr %l98, !tbaa !24
  br label %bb54
bb52:
  br label %bb53
bb53:
  store i64 -1, ptr %l98, !tbaa !24
  br label %bb54
bb54:
  %t192 = load i64, ptr %l98, !tbaa !24
  store i64 %t192, ptr %l9, !tbaa !24
  %t193 = load i64, ptr %l9, !tbaa !24
  %t195 = icmp sge i64 %t193, 0
  br i1 %t195, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s7
  store i32 4, ptr %l106
  %t197 = load i64, ptr %l9, !tbaa !24
  store i64 %t197, ptr %l107, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/names:Resolver", ptr %t198, i32 0, i32 1
  %t201 = load i64, ptr %l9, !tbaa !24
  %t204 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t200, i64 %t201)
  store ptr %t204, ptr %l112
  br label %bb57
bb56:
  br label %bb63
bb57:
  %t205 = load ptr, ptr %l112, !tbaa !29
  %t207 = getelementptr %"compiler/names:Table", ptr %t205, i32 0, i32 2
  %t208 = load i32, ptr %l1, !tbaa !23
  %t211 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t207, i32 %t208)
  %t212 = extractvalue { i32, i64 } %t211, 1
  %t213 = extractvalue { i32, i64 } %t211, 0
  store i32 %t213, ptr %l117
  %t214 = icmp ne i32 %t213, 0
  br i1 %t214, label %bb59, label %ok.215
ok.215:
  store i64 %t212, ptr %l116
  br label %bb58
bb58:
  %t216 = load i64, ptr %l116, !tbaa !24
  store i64 %t216, ptr %l108, !tbaa !24
  br label %bb61
bb59:
  br label %bb60
bb60:
  store i64 -1, ptr %l108, !tbaa !24
  br label %bb61
bb61:
  %t217 = load i32, ptr %l106
  %t218 = load i64, ptr %l107, !tbaa !24
  %t219 = load i64, ptr %l108, !tbaa !24
  %t220 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s7, i32 %t217, i64 %t218, i64 %t219)
  store %"compiler/names:Ref" %t220, ptr %l118
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t221 = load %"compiler/names:Ref", ptr %l118
  store %"compiler/names:Ref" %t221, ptr %rv
  br label %ret
bb63:
  %t222 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t224 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t222)
  store i1 %t224, ptr %l120
  br label %bb64
bb64:
  %t225 = load i1, ptr %l120, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s8
  %t227 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s8, i32 7, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t227, ptr %l122
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t228 = load %"compiler/names:Ref", ptr %l122
  store %"compiler/names:Ref" %t228, ptr %rv
  br label %ret
bb68:
  %t230 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t230, ptr %l124
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t231 = load %"compiler/names:Ref", ptr %l124
  store %"compiler/names:Ref" %t231, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_Hf9d8b9e9334551fc04613fb711673451(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ematchOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Match", ptr %t8, i32 0, i32 3
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecaseOf(ptr %v0, ptr %v1, ptr %t33, ptr %t31)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/ast:Match", ptr %t41, i32 0, i32 4
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp ne ptr %t44, null
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Match", ptr %t49, i32 0, i32 4
  %t52 = load ptr, ptr %t51, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecaseOf(ptr %v0, ptr %v1, ptr %t48, ptr %t52)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emember(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/names:Ref"
  %l8 = alloca i64
  %l14 = alloca %"compiler/names:Ref"
  %l15 = alloca i32
  %l17 = alloca i32
  %l19 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca %"compiler/names:Ref"
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l41 = alloca ptr
  %l45 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasTarget(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i32, ptr %l3, !tbaa !23
  %t17 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ememberOf(ptr %v0, ptr %t11, i64 %t12, i32 %t13)
  store %"compiler/names:Ref" %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb15
bb4:
  %t18 = load %"compiler/names:Ref", ptr %l14
  store %"compiler/names:Ref" %t18, ptr %l5
  %t19 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l15
  store i32 0, ptr %l17
  %t23 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l15, ptr %l17)
  store i1 %t23, ptr %l19
  br label %bb5
bb5:
  %t24 = load i1, ptr %l19, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l21, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l22, !tbaa !24
  %t29 = load %"compiler/names:Ref", ptr %l5
  store %"compiler/names:Ref" %t29, ptr %l23
  %t30 = load i32, ptr %l3, !tbaa !23
  store i32 %t30, ptr %l24, !tbaa !23
  %t31 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t32 = load i32, ptr %t31, !tbaa !23
  store i32 %t32, ptr %l25, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t33, i32 %t34)
  store { i64, ptr } %t37, ptr %l28
  br label %bb8
bb7:
  br label %bb14
bb8:
  %t38 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t41 = trunc i64 %t39 to i32
  %t42 = load i32, ptr %l25, !tbaa !23
  %t44 = sub i32 %t42, %t41
  %t45 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t46 = load i32, ptr %t45, !tbaa !23
  %t49 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t44, i32 %t46)
  store %"compiler/source:Span" %t49, ptr %l33
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l21, !tbaa !29
  %t51 = load i64, ptr %l22, !tbaa !24
  %t52 = load %"compiler/names:Ref", ptr %l23
  %t53 = load i32, ptr %l24, !tbaa !23
  %t54 = load %"compiler/source:Span", ptr %l33
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enotPrivate(ptr %v0, ptr %t50, i64 %t51, %"compiler/names:Ref" %t52, i32 %t53, %"compiler/source:Span" %t54)
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/names:Resolver", ptr %t55, i32 0, i32 5
  store ptr %t57, ptr %l35, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/names:Resolver", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/load:Loader", ptr %t61, i32 0, i32 5
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/names:Resolver", ptr %t64, i32 0, i32 6
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t63, i64 %t67)
  store ptr %t70, ptr %l41
  br label %bb11
bb11:
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t73 = getelementptr %"compiler/load:Module", ptr %t71, i32 0, i32 4
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t79 = call i64 @compiler_2fnames_2ekey(i64 %t74, i32 %t76)
  store i64 %t79, ptr %l45
  br label %bb12
bb12:
  %t80 = load %"compiler/names:Ref", ptr %l5
  %t81 = load ptr, ptr %l35, !tbaa !29
  %t82 = load i64, ptr %l45, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t81, i64 %t82, %"compiler/names:Ref" %t80)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %ret
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t84, ptr %t85)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ememberOf(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l22 = alloca %"compiler/names:Entry"
  %l26 = alloca %"compiler/names:Ref"
  %l27 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l38 = alloca %"compiler/names:Ref"
  %l39 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l49 = alloca %"compiler/names:Ref"
  %l51 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/names:Table", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l16
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19
ok.19:
  store i64 %t16, ptr %l15
  br label %bb2
bb2:
  %t20 = load i64, ptr %l15, !tbaa !24
  store i64 %t20, ptr %l11, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l11, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/names:Table", ptr %t26, i32 0, i32 0
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s1, ptr %t28, i64 %t29)
  store %"compiler/names:Entry" %t32, ptr %l22
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t33 = getelementptr %"compiler/names:Entry", ptr %l22, i32 0, i32 2
  %t34 = load i32, ptr %t33
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t40 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s1, i32 %t34, i64 %t35, i64 %t36)
  store %"compiler/names:Ref" %t40, ptr %l26
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/names:Ref", ptr %l26
  store %"compiler/names:Ref" %t41, ptr %rv
  br label %ret
bb10:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/names:Table", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t44, i32 %t45)
  %t49 = extractvalue { i32, i64 } %t48, 1
  %t50 = extractvalue { i32, i64 } %t48, 0
  store i32 %t50, ptr %l32
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb12, label %ok.52
ok.52:
  store i64 %t49, ptr %l31
  br label %bb11
bb11:
  %t53 = load i64, ptr %l31, !tbaa !24
  store i64 %t53, ptr %l27, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t54 = load i64, ptr %l27, !tbaa !24
  store i64 %t54, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t64 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 4, i64 %t59, i64 %t60)
  store %"compiler/names:Ref" %t64, ptr %l38
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t65 = load %"compiler/names:Ref", ptr %l38
  store %"compiler/names:Ref" %t65, ptr %rv
  br label %ret
bb18:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/names:Table", ptr %t66, i32 0, i32 3
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t68, i32 %t69)
  %t73 = extractvalue { i32, i64 } %t72, 1
  %t74 = extractvalue { i32, i64 } %t72, 0
  store i32 %t74, ptr %l44
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb20, label %ok.76
ok.76:
  store i64 %t73, ptr %l43
  br label %bb19
bb19:
  %t77 = load i64, ptr %l43, !tbaa !24
  store i64 %t77, ptr %l39, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  store i64 -1, ptr %l39, !tbaa !24
  br label %bb22
bb22:
  %t78 = load i64, ptr %l39, !tbaa !24
  store i64 %t78, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = icmp sge i64 %t79, 0
  br i1 %t81, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s3, i32 5, i64 %t83, i64 -1)
  store %"compiler/names:Ref" %t86, ptr %l49
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t87 = load %"compiler/names:Ref", ptr %l49
  store %"compiler/names:Ref" %t87, ptr %rv
  br label %ret
bb26:
  %t89 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t89, ptr %l51
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t90 = load %"compiler/names:Ref", ptr %l51
  store %"compiler/names:Ref" %t90, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ename(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/names:Ref"
  %l6 = alloca %"compiler/names:Ref"
  %l10 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/names:Ref" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/names:Ref", ptr %l6
  store %"compiler/names:Ref" %t6, ptr %l3
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load %"compiler/names:Ref", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t7, %"compiler/source:Span" %t8, %"compiler/names:Ref" %t9)
  br label %bb2
bb2:
  %t13 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l10
  store i32 0, ptr %l12
  %t17 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l10, ptr %l12)
  store i1 %t17, ptr %l14
  br label %bb3
bb3:
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/names:Resolver", ptr %t19, i32 0, i32 12
  %t22 = load i1, ptr %t21, !tbaa !21
  store i1 %t22, ptr %l15, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  %t27 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownInCond(ptr %v0, ptr %t25, %"compiler/source:Span" %t26, i32 %t27)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/token:Token"
  %l21 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l52 = alloca i64
  %l55 = alloca i64
  %l73 = alloca { i64, ptr }
  %l76 = alloca i32
  %l78 = alloca i32
  %l80 = alloca i1
  %l81 = alloca i1
  %l86 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i1
  %l91 = alloca i1
  %l94 = alloca { i64, ptr }
  %l96 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l105 = alloca i1
  %l108 = alloca %"compiler/source:Span"
  %l113 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t10 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l21
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l21, !tbaa !29
  store ptr %t11, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = getelementptr %"compiler/load:Module", ptr %t12, i32 0, i32 7
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/scan:Tokens", ptr %t15, i32 0, i32 0
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp slt i64 %t24, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sdiv i64 %t36, 2
  store i64 %t38, ptr %l8, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l35, !tbaa !27
  %t41 = load i64, ptr %l8, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr %"compiler/token:Token", ptr %t44, i64 %t41
  %t46 = getelementptr %"compiler/token:Token", ptr %t45, i32 0, i32 2
  %t47 = load i32, ptr %t46, !tbaa !23
  %t48 = load i32, ptr %l2, !tbaa !23
  %t51 = icmp slt i32 %t47, %t48
  br i1 %t51, label %bb6, label %bb7
bb6:
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l6, !tbaa !24
  br label %bb8
bb7:
  %t57 = load i64, ptr %l8, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb2
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t63 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t59, i32 %a3)
  store { i64, ptr } %t63, ptr %l45
  br label %bb11
bb11:
  %t64 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  %t65 = load i64, ptr %l6, !tbaa !24
  store i64 %t65, ptr %l10, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb12, label %bb13
bb12:
  %t77 = load i64, ptr %l12, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb17
bb14:
  %t81 = load i64, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = sub i64 %t81, %t82
  %t86 = load i64, ptr %l12, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = sub i64 %t89, 1
  %t92 = load i64, ptr %l12, !tbaa !24
  %t95 = sdiv i64 %t91, %t92
  store i64 %t95, ptr %l55, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb16
bb16:
  %t97 = load i64, ptr %l55, !tbaa !24
  store i64 %t97, ptr %l52, !tbaa !24
  br label %bb17
bb17:
  %t98 = load i64, ptr %l52, !tbaa !24
  store i64 %t98, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load i64, ptr %l14, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb20:
  br label %bb21
bb21:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l14, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = mul i64 %t108, %t109
  %t115 = add i64 %t107, %t112
  store i64 %t115, ptr %l15, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t117, ptr %l73, !tbaa !27
  %t118 = load i64, ptr %l15, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr %"compiler/token:Token", ptr %t121, i64 %t118
  %t123 = load %"compiler/token:Token", ptr %t122
  store %"compiler/token:Token" %t123, ptr %l16
  %t125 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 0
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l76
  store i32 0, ptr %l78
  %t129 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l76, ptr %l78)
  store i1 %t129, ptr %l80
  br label %bb22
bb22:
  %t130 = load i1, ptr %l80, !tbaa !21
  br i1 %t130, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb25
bb24:
  %t131 = load i64, ptr %l15, !tbaa !24
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = sub i64 %t131, %t132
  %t137 = icmp sgt i64 %t135, 256
  store i1 %t137, ptr %l81, !tbaa !21
  br label %bb25
bb25:
  %t139 = load i1, ptr %l81, !tbaa !21
  br i1 %t139, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb27:
  br label %bb28
bb28:
  %t140 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 0
  %t141 = load i32, ptr %t140
  store i32 %t141, ptr %l86
  store i32 1, ptr %l88
  %t144 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l86, ptr %l88)
  store i1 %t144, ptr %l90
  br label %bb29
bb29:
  %t145 = load i1, ptr %l90, !tbaa !21
  br i1 %t145, label %bb30, label %bb31
bb30:
  %t146 = load ptr, ptr %l4, !tbaa !29
  %t148 = getelementptr %"compiler/load:Module", ptr %t146, i32 0, i32 6
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/source:Source", ptr %t149, i32 0, i32 1
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  store { i64, ptr } %t152, ptr %l94, !tbaa !27
  %t153 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 2
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = sext i32 %t154 to i64
  store i64 %t156, ptr %l96, !tbaa !24
  %t157 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 3
  %t158 = load i32, ptr %t157, !tbaa !23
  %t160 = sext i32 %t158 to i64
  store i64 %t160, ptr %l98, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 0
  store i64 %t162, ptr %l99, !tbaa !24
  %t163 = load i64, ptr %l96, !tbaa !24
  %t164 = icmp sge i64 %t163, 0
  br i1 %t164, label %bb32, label %bb33
bb31:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb39
bb32:
  %t166 = load i64, ptr %l96, !tbaa !24
  %t167 = load i64, ptr %l98, !tbaa !24
  %t168 = icmp sle i64 %t166, %t167
  br i1 %t168, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @.c34)
  unreachable
bb34:
  %t170 = load i64, ptr %l98, !tbaa !24
  %t171 = load i64, ptr %l99, !tbaa !24
  %t172 = icmp sle i64 %t170, %t171
  br i1 %t172, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @.c34)
  unreachable
bb36:
  %t174 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = load i64, ptr %l96, !tbaa !24
  %t177 = load i64, ptr %l98, !tbaa !24
  %t178 = getelementptr i8, ptr %t175, i64 %t176
  %t179 = sub i64 %t177, %t176
  %t180 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t178, 1
  %t182 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t185 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t181, { i64, ptr } %t182)
  store i1 %t185, ptr %l105
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @.c34)
  unreachable
bb38:
  %t186 = load i1, ptr %l105, !tbaa !21
  store i1 %t186, ptr %l91, !tbaa !21
  br label %bb39
bb39:
  %t187 = load i1, ptr %l91, !tbaa !21
  br i1 %t187, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t188 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 2
  %t189 = load i32, ptr %t188, !tbaa !23
  %t190 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 3
  %t191 = load i32, ptr %t190, !tbaa !23
  %t194 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s7, i32 %t189, i32 %t191)
  store %"compiler/source:Span" %t194, ptr %l108
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t195 = load %"compiler/source:Span", ptr %l108
  store %"compiler/source:Span" %t195, ptr %rv
  br label %ret
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb44:
  %t196 = load i64, ptr %l14, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l14, !tbaa !24
  br label %bb18
bb45:
  %t200 = load i32, ptr %l2, !tbaa !23
  %t201 = load i32, ptr %l2, !tbaa !23
  %t204 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t200, i32 %t201)
  store %"compiler/source:Span" %t204, ptr %l113
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t205 = load %"compiler/source:Span", ptr %l113
  store %"compiler/source:Span" %t205, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l20 = alloca { i64, [3 x i64] }
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  store i32 %t1, ptr %l4, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t3, i32 0, i32 1
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t12 = getelementptr %"compiler/names:Table", ptr %t10, i32 0, i32 3
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  %t31 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t25, i64 %t26, %"compiler/source:Span" %a3)
  store { i64, [3 x i64] } %t31, ptr %l20
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t32, i32 %t33)
  store { i64, ptr } %t36, ptr %l23
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = mul i64 %t38, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameClashesWithImport(ptr %s1, ptr %s1, { i64, ptr } %t43)
  store %"compiler/msgs:Msg" %t45, ptr %l25
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l16, !tbaa !29
  %t47 = load { i64, [3 x i64] }, ptr %l20
  %t48 = load %"compiler/msgs:Msg", ptr %l25
  %t49 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t46, { i64, [3 x i64] } %t47, %"compiler/msgs:Msg" %t48)
  store i64 %t49, ptr %l26
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoShadow(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"compiler/names:Entry"
  %l11 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l31 = alloca %"compiler/names:Entry"
  %l34 = alloca ptr
  %l39 = alloca { i64, [3 x i64] }
  %l40 = alloca i32
  %l42 = alloca i32
  %l44 = alloca i1
  %l45 = alloca %"compiler/msgs:Msg"
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/msgs:Msg"
  %l53 = alloca { i64, ptr }
  %l55 = alloca %"compiler/msgs:Msg"
  %l56 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l68 = alloca { i64, ptr }
  %l70 = alloca %"compiler/msgs:Msg"
  %l75 = alloca i1
  %l78 = alloca ptr
  %l83 = alloca { i64, [3 x i64] }
  %l86 = alloca { i64, ptr }
  %l88 = alloca %"compiler/msgs:Msg"
  %l89 = alloca i64
  %l94 = alloca i1
  %l97 = alloca ptr
  %l102 = alloca { i64, [3 x i64] }
  %l105 = alloca { i64, ptr }
  %l107 = alloca %"compiler/msgs:Msg"
  %l108 = alloca i64
  %l113 = alloca i1
  %l114 = alloca i1
  %l119 = alloca i1
  %l120 = alloca i1
  %l122 = alloca i1
  %l125 = alloca ptr
  %l130 = alloca { i64, [3 x i64] }
  %l133 = alloca { i64, ptr }
  %l135 = alloca %"compiler/msgs:Msg"
  %l136 = alloca i64
  %l137 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i32
  %l145 = alloca i1
  %l149 = alloca %"compiler/names:local"
  %l150 = alloca i32
  %l152 = alloca i32
  %l154 = alloca i1
  %l157 = alloca ptr
  %l162 = alloca { i64, [3 x i64] }
  %l165 = alloca { i64, ptr }
  %l167 = alloca %"compiler/msgs:Msg"
  %l168 = alloca i64
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/names:Resolver", ptr %t4, i32 0, i32 6
  %t7 = load i64, ptr %t6, !tbaa !24
  %t10 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t3, i64 %t7)
  store ptr %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l16, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l19
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/names:Table", ptr %t18, i32 0, i32 1
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t20, i32 %t21)
  %t25 = extractvalue { i32, i64 } %t24, 1
  %t26 = extractvalue { i32, i64 } %t24, 0
  store i32 %t26, ptr %l25
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb4, label %ok.28
ok.28:
  store i64 %t25, ptr %l24
  br label %bb3
bb3:
  %t29 = load i64, ptr %l24, !tbaa !24
  store i64 %t29, ptr %l20, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l20, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sge i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/names:Table", ptr %t35, i32 0, i32 0
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store %"compiler/names:Entry" %t41, ptr %l31
  br label %bb9
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/names:Resolver", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/load:Loader", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v0, ptr %t48, { i64, ptr } %t49)
  store i1 %t52, ptr %l75
  br label %bb24
bb9:
  %t53 = load %"compiler/names:Entry", ptr %l31
  store %"compiler/names:Entry" %t53, ptr %l6
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/names:Resolver", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/load:Loader", ptr %t57, i32 0, i32 4
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l34, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/names:Resolver", ptr %t62, i32 0, i32 6
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = load %"compiler/source:Span", ptr %l2
  %t70 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t61, i64 %t65, %"compiler/source:Span" %t66)
  store { i64, [3 x i64] } %t70, ptr %l39
  br label %bb10
bb10:
  %t71 = getelementptr %"compiler/names:Entry", ptr %l6, i32 0, i32 2
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l40
  store i32 3, ptr %l42
  %t75 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l40, ptr %l42)
  store i1 %t75, ptr %l44
  br label %bb11
bb11:
  %t76 = load i1, ptr %l44, !tbaa !21
  br i1 %t76, label %bb12, label %bb13
bb12:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l1, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t77, i32 %t78)
  store { i64, ptr } %t81, ptr %l48
  br label %bb14
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t82, i32 %t83)
  store { i64, ptr } %t86, ptr %l53
  br label %bb16
bb14:
  %t87 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t95 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsFunction(ptr %s1, ptr %s1, { i64, ptr } %t93)
  store %"compiler/msgs:Msg" %t95, ptr %l50
  br label %bb15
bb15:
  %t96 = load %"compiler/msgs:Msg", ptr %l50
  store %"compiler/msgs:Msg" %t96, ptr %l45
  br label %bb18
bb16:
  %t97 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  %t99 = extractvalue { i64, ptr } %t97, 1
  %t100 = mul i64 %t98, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t101, ptr %t99, i64 %t100, i1 false)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t105 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsGlobal(ptr %s1, ptr %s1, { i64, ptr } %t103)
  store %"compiler/msgs:Msg" %t105, ptr %l55
  br label %bb17
bb17:
  %t106 = load %"compiler/msgs:Msg", ptr %l55
  store %"compiler/msgs:Msg" %t106, ptr %l45
  br label %bb18
bb18:
  %t107 = load ptr, ptr %l34, !tbaa !29
  %t108 = load { i64, [3 x i64] }, ptr %l39
  %t109 = load %"compiler/msgs:Msg", ptr %l45
  %t110 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t107, { i64, [3 x i64] } %t108, %"compiler/msgs:Msg" %t109)
  store i64 %t110, ptr %l56
  br label %bb19
bb19:
  %t111 = load i64, ptr %l56, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/names:Resolver", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 4
  %t118 = load ptr, ptr %t117, !tbaa !29
  store ptr %t118, ptr %l59, !tbaa !29
  store i64 %t111, ptr %l60, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/names:Resolver", ptr %t121, i32 0, i32 6
  %t124 = load i64, ptr %t123, !tbaa !24
  %t125 = getelementptr %"compiler/names:Entry", ptr %l6, i32 0, i32 1
  %t126 = load %"compiler/source:Span", ptr %t125
  %t130 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t120, i64 %t124, %"compiler/source:Span" %t126)
  store { i64, [3 x i64] } %t130, ptr %l65
  br label %bb20
bb20:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t131, i32 %t132)
  store { i64, ptr } %t135, ptr %l68
  br label %bb21
bb21:
  %t136 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t138 = extractvalue { i64, ptr } %t136, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t144 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s1, ptr %s1, { i64, ptr } %t142)
  store %"compiler/msgs:Msg" %t144, ptr %l70
  br label %bb22
bb22:
  %t145 = load ptr, ptr %l59, !tbaa !29
  %t146 = load i64, ptr %l60, !tbaa !24
  %t147 = load { i64, [3 x i64] }, ptr %l65
  %t148 = load %"compiler/msgs:Msg", ptr %l70
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s1, ptr %t145, i64 %t146, { i64, [3 x i64] } %t147, %"compiler/msgs:Msg" %t148)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s1)
  br label %bb72
bb24:
  %t149 = load i1, ptr %l75, !tbaa !21
  br i1 %t149, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/names:Resolver", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/load:Loader", ptr %t153, i32 0, i32 4
  %t156 = load ptr, ptr %t155, !tbaa !29
  store ptr %t156, ptr %l78, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/names:Resolver", ptr %t158, i32 0, i32 6
  %t161 = load i64, ptr %t160, !tbaa !24
  %t162 = load %"compiler/source:Span", ptr %l2
  %t166 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t157, i64 %t161, %"compiler/source:Span" %t162)
  store { i64, [3 x i64] } %t166, ptr %l83
  br label %bb27
bb26:
  %t167 = load i32, ptr %l1, !tbaa !23
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/names:Resolver", ptr %t169, i32 0, i32 3
  %t175 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H6d33fbc050830e537410645e3c893b2c(ptr %v0, ptr %t171, i32 %t167)
  store i1 %t175, ptr %l94
  br label %bb31
bb27:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l1, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s3, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l86
  br label %bb28
bb28:
  %t181 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsBuildConst(ptr %s3, ptr %s3, { i64, ptr } %t187)
  store %"compiler/msgs:Msg" %t189, ptr %l88
  br label %bb29
bb29:
  %t190 = load ptr, ptr %l78, !tbaa !29
  %t191 = load { i64, [3 x i64] }, ptr %l83
  %t192 = load %"compiler/msgs:Msg", ptr %l88
  %t193 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t190, { i64, [3 x i64] } %t191, %"compiler/msgs:Msg" %t192)
  store i64 %t193, ptr %l89
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb31:
  %t194 = load i1, ptr %l94, !tbaa !21
  br i1 %t194, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/names:Resolver", ptr %t195, i32 0, i32 0
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/load:Loader", ptr %t198, i32 0, i32 4
  %t201 = load ptr, ptr %t200, !tbaa !29
  store ptr %t201, ptr %l97, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/names:Resolver", ptr %t203, i32 0, i32 6
  %t206 = load i64, ptr %t205, !tbaa !24
  %t207 = load %"compiler/source:Span", ptr %l2
  %t211 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t202, i64 %t206, %"compiler/source:Span" %t207)
  store { i64, [3 x i64] } %t211, ptr %l102
  br label %bb34
bb33:
  %t212 = load i32, ptr %l1, !tbaa !23
  %t214 = load ptr, ptr %l3, !tbaa !29
  %t216 = getelementptr %"compiler/names:Table", ptr %t214, i32 0, i32 2
  %t220 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t216, i32 %t212)
  store i1 %t220, ptr %l113
  br label %bb38
bb34:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l1, !tbaa !23
  %t225 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s5, ptr %t221, i32 %t222)
  store { i64, ptr } %t225, ptr %l105
  br label %bb35
bb35:
  %t226 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 0
  %t228 = extractvalue { i64, ptr } %t226, 1
  %t229 = mul i64 %t227, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t229)
  call void @llvm.memcpy.p0.p0.i64(ptr %t230, ptr %t228, i64 %t229, i1 false)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  %t234 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePreludeConstRedeclared(ptr %s5, ptr %s5, { i64, ptr } %t232)
  store %"compiler/msgs:Msg" %t234, ptr %l107
  br label %bb36
bb36:
  %t235 = load ptr, ptr %l97, !tbaa !29
  %t236 = load { i64, [3 x i64] }, ptr %l102
  %t237 = load %"compiler/msgs:Msg", ptr %l107
  %t238 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t235, { i64, [3 x i64] } %t236, %"compiler/msgs:Msg" %t237)
  store i64 %t238, ptr %l108
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb70
bb38:
  %t239 = load i1, ptr %l113, !tbaa !21
  br i1 %t239, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb42
bb40:
  %t240 = load i32, ptr %l1, !tbaa !23
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/names:Resolver", ptr %t242, i32 0, i32 2
  %t248 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t244, i32 %t240)
  store i1 %t248, ptr %l119
  br label %bb41
bb41:
  %t249 = load i1, ptr %l119, !tbaa !21
  store i1 %t249, ptr %l114, !tbaa !21
  br label %bb42
bb42:
  %t250 = load i1, ptr %l114, !tbaa !21
  br i1 %t250, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb46
bb44:
  %t251 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t253 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t251)
  store i1 %t253, ptr %l122
  br label %bb45
bb45:
  %t254 = load i1, ptr %l122, !tbaa !21
  store i1 %t254, ptr %l120, !tbaa !21
  br label %bb46
bb46:
  %t255 = load i1, ptr %l120, !tbaa !21
  br i1 %t255, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/names:Resolver", ptr %t256, i32 0, i32 0
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/load:Loader", ptr %t259, i32 0, i32 4
  %t262 = load ptr, ptr %t261, !tbaa !29
  store ptr %t262, ptr %l125, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/names:Resolver", ptr %t264, i32 0, i32 6
  %t267 = load i64, ptr %t266, !tbaa !24
  %t268 = load %"compiler/source:Span", ptr %l2
  %t272 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t263, i64 %t267, %"compiler/source:Span" %t268)
  store { i64, [3 x i64] } %t272, ptr %l130
  br label %bb49
bb48:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/names:Resolver", ptr %t273, i32 0, i32 8
  %t276 = load i32, ptr %l1, !tbaa !23
  %t279 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t275, i32 %t276)
  %t280 = extractvalue { i32, i64 } %t279, 1
  %t281 = extractvalue { i32, i64 } %t279, 0
  store i32 %t281, ptr %l142
  %t282 = icmp ne i32 %t281, 0
  br i1 %t282, label %bb54, label %ok.283
ok.283:
  store i64 %t280, ptr %l141
  br label %bb53
bb49:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i32, ptr %l1, !tbaa !23
  %t288 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s7, ptr %t284, i32 %t285)
  store { i64, ptr } %t288, ptr %l133
  br label %bb50
bb50:
  %t289 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 0
  %t291 = extractvalue { i64, ptr } %t289, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t297 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsType(ptr %s7, ptr %s7, { i64, ptr } %t295)
  store %"compiler/msgs:Msg" %t297, ptr %l135
  br label %bb51
bb51:
  %t298 = load ptr, ptr %l125, !tbaa !29
  %t299 = load { i64, [3 x i64] }, ptr %l130
  %t300 = load %"compiler/msgs:Msg", ptr %l135
  %t301 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t298, { i64, [3 x i64] } %t299, %"compiler/msgs:Msg" %t300)
  store i64 %t301, ptr %l136
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb69
bb53:
  %t302 = load i64, ptr %l141, !tbaa !24
  store i64 %t302, ptr %l137, !tbaa !24
  br label %bb56
bb54:
  br label %bb55
bb55:
  store i64 -1, ptr %l137, !tbaa !24
  br label %bb56
bb56:
  %t303 = load i64, ptr %l137, !tbaa !24
  store i64 %t303, ptr %l11, !tbaa !24
  %t304 = load i64, ptr %l11, !tbaa !24
  %t306 = icmp sge i64 %t304, 0
  br i1 %t306, label %bb57, label %bb58
bb57:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/names:Resolver", ptr %t308, i32 0, i32 7
  %t311 = load i64, ptr %l11, !tbaa !24
  %t314 = call %"compiler/names:local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t310, i64 %t311)
  store %"compiler/names:local" %t314, ptr %l149
  br label %bb59
bb58:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb61
bb59:
  %t315 = getelementptr %"compiler/names:local", ptr %l149, i32 0, i32 2
  %t316 = load i32, ptr %t315
  store i32 %t316, ptr %l150
  store i32 8, ptr %l152
  %t319 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l150, ptr %l152)
  store i1 %t319, ptr %l154
  br label %bb60
bb60:
  %t320 = load i1, ptr %l154, !tbaa !21
  store i1 %t320, ptr %l145, !tbaa !21
  br label %bb61
bb61:
  %t321 = load i1, ptr %l145, !tbaa !21
  br i1 %t321, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s9
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/names:Resolver", ptr %t322, i32 0, i32 0
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t327 = getelementptr %"compiler/load:Loader", ptr %t325, i32 0, i32 4
  %t328 = load ptr, ptr %t327, !tbaa !29
  store ptr %t328, ptr %l157, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/names:Resolver", ptr %t330, i32 0, i32 6
  %t333 = load i64, ptr %t332, !tbaa !24
  %t334 = load %"compiler/source:Span", ptr %l2
  %t338 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t329, i64 %t333, %"compiler/source:Span" %t334)
  store { i64, [3 x i64] } %t338, ptr %l162
  br label %bb64
bb63:
  br label %bb68
bb64:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i32, ptr %l1, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s9, ptr %t339, i32 %t340)
  store { i64, ptr } %t343, ptr %l165
  br label %bb65
bb65:
  %t344 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  %t346 = extractvalue { i64, ptr } %t344, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  %t352 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsType(ptr %s9, ptr %s9, { i64, ptr } %t350)
  store %"compiler/msgs:Msg" %t352, ptr %l167
  br label %bb66
bb66:
  %t353 = load ptr, ptr %l157, !tbaa !29
  %t354 = load { i64, [3 x i64] }, ptr %l162
  %t355 = load %"compiler/msgs:Msg", ptr %l167
  %t356 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t353, { i64, [3 x i64] } %t354, %"compiler/msgs:Msg" %t355)
  store i64 %t356, ptr %l168
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s9)
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enotPrivate(ptr %v0, ptr %a0, i64 %a1, %"compiler/names:Ref" %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/names:Ref"
  %l3 = alloca i32
  %l5 = alloca %"compiler/msgs:Msg"
  %l10 = alloca i1
  %l11 = alloca i32
  %l13 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i1
  %l32 = alloca %"compiler/msgs:Msg"
  %l35 = alloca { i64, ptr }
  %l37 = alloca %"compiler/msgs:Msg"
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"compiler/msgs:Msg"
  %l45 = alloca ptr
  %l50 = alloca { i64, [3 x i64] }
  %l52 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/names:Ref" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/names:Resolver", ptr %t2, i32 0, i32 6
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = icmp eq i64 %a1, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb2:
  %t10 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l11
  store i32 0, ptr %l13
  %t14 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l11, ptr %l13)
  store i1 %t14, ptr %l15
  br label %bb3
bb3:
  %t15 = load i1, ptr %l15, !tbaa !21
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb6:
  %t17 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l17
  store i32 5, ptr %l19
  %t21 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l17, ptr %l19)
  store i1 %t21, ptr %l21
  br label %bb7
bb7:
  %t22 = load i1, ptr %l21, !tbaa !21
  store i1 %t22, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t23 = load i1, ptr %l16, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb13
bb10:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t28, ptr %l25
  br label %bb11
bb11:
  %t29 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t30 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t29)
  store i1 %t30, ptr %l26
  br label %bb12
bb12:
  %t31 = load i1, ptr %l26, !tbaa !21
  store i1 %t31, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  br label %bb16
bb16:
  %t33 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l27
  store i32 4, ptr %l29
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l27, ptr %l29)
  store i1 %t37, ptr %l31
  br label %bb17
bb17:
  %t38 = load i1, ptr %l31, !tbaa !21
  br i1 %t38, label %bb18, label %bb19
bb18:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t39, i32 %t40)
  store { i64, ptr } %t43, ptr %l35
  br label %bb20
bb19:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t44, i32 %t45)
  store { i64, ptr } %t48, ptr %l40
  br label %bb22
bb20:
  %t49 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t57 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeIsPrivate(ptr %s0, ptr %s0, { i64, ptr } %t55)
  store %"compiler/msgs:Msg" %t57, ptr %l37
  br label %bb21
bb21:
  %t58 = load %"compiler/msgs:Msg", ptr %l37
  store %"compiler/msgs:Msg" %t58, ptr %l32
  br label %bb24
bb22:
  %t59 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t67 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarIsPrivate(ptr %s0, ptr %s0, { i64, ptr } %t65)
  store %"compiler/msgs:Msg" %t67, ptr %l42
  br label %bb23
bb23:
  %t68 = load %"compiler/msgs:Msg", ptr %l42
  store %"compiler/msgs:Msg" %t68, ptr %l32
  br label %bb24
bb24:
  %t69 = load %"compiler/msgs:Msg", ptr %l32
  store %"compiler/msgs:Msg" %t69, ptr %l5
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/names:Resolver", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/load:Loader", ptr %t73, i32 0, i32 4
  %t76 = load ptr, ptr %t75, !tbaa !29
  store ptr %t76, ptr %l45, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/names:Resolver", ptr %t78, i32 0, i32 6
  %t81 = load i64, ptr %t80, !tbaa !24
  %t86 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t77, i64 %t81, %"compiler/source:Span" %a4)
  store { i64, [3 x i64] } %t86, ptr %l50
  br label %bb25
bb25:
  %t87 = load %"compiler/msgs:Msg", ptr %l5
  %t88 = load ptr, ptr %l45, !tbaa !29
  %t89 = load { i64, [3 x i64] }, ptr %l50
  %t91 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s0, ptr %t88, { i64, [3 x i64] } %t89, %"compiler/msgs:Msg" %t87)
  store i64 %t91, ptr %l52
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l11 = alloca ptr
  %l17 = alloca { i64, [3 x i64] }
  %l18 = alloca %"compiler/msgs:Msg"
  %l19 = alloca i64
  %l27 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Param", ptr %t2, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  %t8 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t1, i32 %t5)
  store { i64, ptr } %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 1, ptr @.d35 })
  store i1 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/names:Resolver", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/load:Loader", ptr %t15, i32 0, i32 4
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l11, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/names:Resolver", ptr %t20, i32 0, i32 6
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Param", ptr %t24, i32 0, i32 0
  %t27 = load %"compiler/source:Span", ptr %t26
  %t31 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t19, i64 %t23, %"compiler/source:Span" %t27)
  store { i64, [3 x i64] } %t31, ptr %l17
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t32 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %s1)
  store %"compiler/msgs:Msg" %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l11, !tbaa !29
  %t34 = load { i64, [3 x i64] }, ptr %l17
  %t35 = load %"compiler/msgs:Msg", ptr %l18
  %t36 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t33, { i64, [3 x i64] } %t34, %"compiler/msgs:Msg" %t35)
  store i64 %t36, ptr %l19
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/names:Resolver", ptr %t38, i32 0, i32 6
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Param", ptr %t42, i32 0, i32 0
  %t45 = getelementptr %"compiler/source:Span", ptr %t44, i32 0, i32 0
  %t46 = load i32, ptr %t45, !tbaa !23
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Param", ptr %t47, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  %t55 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t37, i64 %t41, i32 %t46, i32 %t50)
  store %"compiler/source:Span" %t55, ptr %l27
  br label %bb9
bb9:
  %t56 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t56, ptr %l3
  br i1 %a2, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/ast:Param", ptr %t60, i32 0, i32 1
  %t63 = load i32, ptr %t62, !tbaa !23
  %t64 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t59, i32 %t63, %"compiler/source:Span" %t64, i1 false)
  br label %bb12
bb11:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 6
  %t72 = load i64, ptr %t71, !tbaa !24
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Param", ptr %t73, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t77 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t68, i64 %t72, i32 %t76, %"compiler/source:Span" %t77)
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Param", ptr %t83, i32 0, i32 1
  %t86 = load i32, ptr %t85, !tbaa !23
  %t87 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t82, i32 %t86, %"compiler/source:Span" %t87, i32 1)
  br label %bb14
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/names:Ref"
  %l7 = alloca i1
  %l13 = alloca { i64, ptr }
  %l21 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/names:Ref"
  %l28 = alloca i32
  %l30 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:Path", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Path", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 0
  %t22 = load i32, ptr %t21, !tbaa !33
  store i32 %t22, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/names:Resolver", ptr %t25, i32 0, i32 6
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Path", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"compiler/source:Span", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load i32, ptr %l2, !tbaa !23
  %t39 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t24, i64 %t28, i32 %t33, i32 %t34)
  store %"compiler/source:Span" %t39, ptr %l21
  br label %bb7
bb7:
  %t40 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t40, ptr %l3
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t41, i32 %t42)
  store %"compiler/names:Ref" %t45, ptr %l24
  br label %bb8
bb8:
  %t46 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t46, ptr %l4
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l3
  %t49 = load %"compiler/names:Ref", ptr %l4
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t47, %"compiler/source:Span" %t48, %"compiler/names:Ref" %t49)
  br label %bb9
bb9:
  %t53 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l28
  store i32 0, ptr %l30
  %t57 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l28, ptr %l30)
  store i1 %t57, ptr %l32
  br label %bb10
bb10:
  %t58 = load i1, ptr %l32, !tbaa !21
  br i1 %t58, label %bb11, label %bb12
bb11:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Path", ptr %t59, i32 0, i32 1
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t66 = icmp sge i64 %t64, 2
  store i1 %t66, ptr %l33, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb13
bb13:
  %t68 = load i1, ptr %l33, !tbaa !21
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l3
  %t71 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %t69, %"compiler/source:Span" %t70, i32 %t71)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l44 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca i1
  %l63 = alloca i1
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t17 = load ptr, ptr %l19, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l19, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l20, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb10
bb10:
  br label %bb38
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t36 = load ptr, ptr %l27, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l27, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l28, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t52, i32 0, i32 2
  %t54 = load { i64, ptr }, ptr %t53
  store { i64, ptr } %t54, ptr %l5, !tbaa !27
  br label %bb16
bb15:
  br label %bb25
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t56, ptr %t57)
  br label %bb17
bb17:
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t60, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t74, ptr %l44, !tbaa !27
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %t82, ptr %t80, ptr %t84)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l7, !tbaa !24
  br label %bb18
bb24:
  br label %bb38
bb25:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t93 = load ptr, ptr %l52, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb26, label %bb27
bb26:
  %t96 = load ptr, ptr %l52, !tbaa !29
  %t97 = load i64, ptr %t96
  %t99 = icmp eq i64 %t97, 3
  store i1 %t99, ptr %l53, !tbaa !21
  br label %bb27
bb27:
  %t100 = load i1, ptr %l53, !tbaa !21
  br i1 %t100, label %bb28, label %bb29
bb28:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32 }, ptr %t103, i32 0, i32 0
  %t105 = load %"compiler/source:Span", ptr %t104
  store %"compiler/source:Span" %t105, ptr %l10
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32 }, ptr %t109, i32 0, i32 1
  %t111 = load i32, ptr %t110
  store i32 %t111, ptr %l11, !tbaa !23
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t113 = load i32, ptr %l11, !tbaa !23
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t119 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t115, i32 %t113)
  store i1 %t119, ptr %l63
  br label %bb31
bb31:
  %t120 = load i1, ptr %l63, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t124 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v2, ptr %t123, i32 %t124)
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l11, !tbaa !23
  %t129 = load %"compiler/source:Span", ptr %l10
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t127, i32 %t128, %"compiler/source:Span" %t129, i1 false)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l5 = alloca i64
  %l9 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l12 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l13 = alloca i32
  %l19 = alloca i1
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_Hf9d8b9e9334551fc04613fb711673451(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb2
bb2:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, %a1
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/names:Resolver", ptr %t13, i32 0, i32 9
  %t17 = call { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H1b67a9adff6f6c708503322bb7ca7b5e(ptr %v0, ptr %t15)
  %t18 = extractvalue { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } %t17, 1
  %t19 = extractvalue { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } %t17, 0
  store i32 %t19, ptr %l13
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb7, label %ok.21
ok.21:
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t18, ptr %l12
  br label %bb6
bb6:
  %t22 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l12
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t22, ptr %l9
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb9:
  %t23 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l9
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t23, ptr %l2
  %t24 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 1
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/names:Resolver", ptr %t29, i32 0, i32 8
  %t32 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t36 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H7068c8717e9d582db2941dd2bdd79d55(ptr %v0, ptr %t31, i32 %t33)
  store i1 %t36, ptr %l19
  br label %bb12
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t37, i32 0, i32 8
  %t40 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t39, i32 %t41, i64 %t43)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb15
bb15:
  br label %bb1
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l38 = alloca i64
  %l41 = alloca i64
  %l59 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l75 = alloca i1
  %l79 = alloca { i64, ptr }
  %l81 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i32
  %l89 = alloca i1
  %l93 = alloca %"compiler/names:local"
  %l94 = alloca i32
  %l96 = alloca i32
  %l98 = alloca i1
  %l101 = alloca i1
  %l106 = alloca %"compiler/names:Ref"
  %l107 = alloca i32
  %l109 = alloca i32
  %l111 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t6 = load ptr, ptr %l23, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l23, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l24, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l3
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t28, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  br label %bb8
bb7:
  br label %bb58
bb8:
  store i64 0, ptr %l6, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb14
bb11:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l41, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb13
bb13:
  %t62 = load i64, ptr %l41, !tbaa !24
  store i64 %t62, ptr %l38, !tbaa !24
  br label %bb14
bb14:
  %t63 = load i64, ptr %l38, !tbaa !24
  store i64 %t63, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load i64, ptr %l10, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb17:
  br label %bb18
bb18:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t73 = load i64, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l8, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t82, ptr %l59, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr ptr, ptr %t86, i64 %t80
  %t88 = load ptr, ptr %t87, !tbaa !39
  store ptr %t88, ptr %l12, !tbaa !29
  %t90 = load ptr, ptr %l12, !tbaa !29
  store ptr %t90, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t91 = load ptr, ptr %l62, !tbaa !29
  %t92 = icmp ne ptr %t91, null
  br i1 %t92, label %bb19, label %bb20
bb19:
  %t94 = load ptr, ptr %l62, !tbaa !29
  %t95 = load i64, ptr %t94
  %t97 = icmp eq i64 %t95, 0
  store i1 %t97, ptr %l63, !tbaa !21
  br label %bb20
bb20:
  %t98 = load i1, ptr %l63, !tbaa !21
  br i1 %t98, label %bb21, label %bb22
bb21:
  %t99 = load ptr, ptr %l12, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t101, i32 0, i32 0
  %t103 = load %"compiler/source:Span", ptr %t102
  store %"compiler/source:Span" %t103, ptr %l13
  %t105 = load ptr, ptr %l12, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t107, i32 0, i32 1
  %t109 = load { i64, ptr }, ptr %t108
  store { i64, ptr } %t109, ptr %l14, !tbaa !27
  %t111 = load ptr, ptr %l12, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t113, i32 0, i32 2
  %t115 = load { i64, ptr }, ptr %t114
  store { i64, ptr } %t115, ptr %l15, !tbaa !27
  br label %bb23
bb22:
  br label %bb49
bb23:
  %t117 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = icmp eq i64 %t119, 1
  br i1 %t121, label %bb24, label %bb25
bb24:
  %t123 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t127 = icmp eq i64 %t125, 0
  store i1 %t127, ptr %l75, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb26
bb26:
  %t129 = load i1, ptr %l75, !tbaa !21
  br i1 %t129, label %bb27, label %bb28
bb27:
  %t130 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t130, ptr %l79, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i32, ptr %t132, i64 0
  %t134 = load i32, ptr %t133, !tbaa !33
  store i32 %t134, ptr %l16, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/names:Resolver", ptr %t136, i32 0, i32 8
  %t139 = load i32, ptr %l16, !tbaa !23
  %t142 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t138, i32 %t139)
  %t143 = extractvalue { i32, i64 } %t142, 1
  %t144 = extractvalue { i32, i64 } %t142, 0
  store i32 %t144, ptr %l86
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb30, label %ok.146
ok.146:
  store i64 %t143, ptr %l85
  br label %bb29
bb28:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t147, ptr %t148, i1 true)
  br label %bb47
bb29:
  %t151 = load i64, ptr %l85, !tbaa !24
  store i64 %t151, ptr %l81, !tbaa !24
  br label %bb32
bb30:
  br label %bb31
bb31:
  store i64 -1, ptr %l81, !tbaa !24
  br label %bb32
bb32:
  %t152 = load i64, ptr %l81, !tbaa !24
  store i64 %t152, ptr %l17, !tbaa !24
  %t153 = load i64, ptr %l17, !tbaa !24
  %t155 = icmp sge i64 %t153, 0
  br i1 %t155, label %bb33, label %bb34
bb33:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/names:Resolver", ptr %t157, i32 0, i32 7
  %t160 = load i64, ptr %l17, !tbaa !24
  %t163 = call %"compiler/names:local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t159, i64 %t160)
  store %"compiler/names:local" %t163, ptr %l93
  br label %bb35
bb34:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb37
bb35:
  %t164 = getelementptr %"compiler/names:local", ptr %l93, i32 0, i32 2
  %t165 = load i32, ptr %t164
  store i32 %t165, ptr %l94
  store i32 8, ptr %l96
  %t168 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l94, ptr %l96)
  store i1 %t168, ptr %l98
  br label %bb36
bb36:
  %t169 = load i1, ptr %l98, !tbaa !21
  store i1 %t169, ptr %l89, !tbaa !21
  br label %bb37
bb37:
  %t170 = load i1, ptr %l89, !tbaa !21
  %t173 = xor i1 %t170, true
  br i1 %t173, label %bb38, label %bb39
bb38:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/names:Resolver", ptr %t176, i32 0, i32 6
  %t179 = load i64, ptr %t178, !tbaa !24
  %t180 = load i32, ptr %l16, !tbaa !23
  %t184 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeIn(ptr %v0, ptr %t175, i64 %t179, i32 %t180)
  store %"compiler/names:Ref" %t184, ptr %l106
  br label %bb40
bb39:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb42
bb40:
  %t185 = getelementptr %"compiler/names:Ref", ptr %l106, i32 0, i32 0
  %t186 = load i32, ptr %t185
  store i32 %t186, ptr %l107
  store i32 0, ptr %l109
  %t189 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l107, ptr %l109)
  store i1 %t189, ptr %l111
  br label %bb41
bb41:
  %t190 = load i1, ptr %l111, !tbaa !21
  store i1 %t190, ptr %l101, !tbaa !21
  br label %bb42
bb42:
  %t191 = load i1, ptr %l101, !tbaa !21
  br i1 %t191, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l13
  %t194 = load i32, ptr %l16, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eintroduce(ptr %v0, ptr %s7, ptr %t192, %"compiler/source:Span" %t193, i32 %t194, ptr null)
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb55
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t198, ptr %t199, i1 true)
  br label %bb53
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @.c36)
  unreachable
bb55:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb56:
  %t202 = load i64, ptr %l10, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l10, !tbaa !24
  br label %bb15
bb57:
  br label %bb73
bb58:
  %t206 = load ptr, ptr %l1, !tbaa !29
  store ptr %t206, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t207 = load ptr, ptr %l121, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb59, label %bb60
bb59:
  %t210 = load ptr, ptr %l121, !tbaa !29
  %t211 = load i64, ptr %t210
  %t213 = icmp eq i64 %t211, 3
  store i1 %t213, ptr %l122, !tbaa !21
  br label %bb60
bb60:
  %t214 = load i1, ptr %l122, !tbaa !21
  br i1 %t214, label %bb61, label %bb62
bb61:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr { i64, [5 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t217, i32 0, i32 1
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l19, !tbaa !29
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l19, !tbaa !29
  %t223 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t221, ptr %t222, i1 %t223)
  br label %bb64
bb64:
  br label %bb73
bb65:
  %t227 = load ptr, ptr %l1, !tbaa !29
  store ptr %t227, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t228 = load ptr, ptr %l130, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb66, label %bb67
bb66:
  %t231 = load ptr, ptr %l130, !tbaa !29
  %t232 = load i64, ptr %t231
  %t234 = icmp eq i64 %t232, 4
  store i1 %t234, ptr %l131, !tbaa !21
  br label %bb67
bb67:
  %t235 = load i1, ptr %l131, !tbaa !21
  br i1 %t235, label %bb68, label %bb69
bb68:
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t238, i32 0, i32 1
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l20, !tbaa !29
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l20, !tbaa !29
  %t244 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t242, ptr %t243, i1 %t244)
  br label %bb71
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/names:Ref" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/names:Ref"
  %l3 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i1
  %l10 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/names:Ref" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t2 = load i32, ptr %t1
  store i32 %t2, ptr %l3
  store i32 0, ptr %l5
  %t5 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l3, ptr %l5)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 4
  store ptr %t11, ptr %l10, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/names:Resolver", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/load:Loader", ptr %t15, i32 0, i32 5
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 6
  %t21 = load i64, ptr %t20, !tbaa !24
  %t24 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t17, i64 %t21)
  store ptr %t24, ptr %l16
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t25 = load ptr, ptr %l16, !tbaa !29
  %t27 = getelementptr %"compiler/load:Module", ptr %t25, i32 0, i32 4
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t30 = load i32, ptr %t29, !tbaa !23
  %t33 = call i64 @compiler_2fnames_2ekey(i64 %t28, i32 %t30)
  store i64 %t33, ptr %l20
  br label %bb5
bb5:
  %t34 = load %"compiler/names:Ref", ptr %l2
  %t35 = load ptr, ptr %l10, !tbaa !29
  %t36 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t35, i64 %t36, %"compiler/names:Ref" %t34)
  br label %bb6
bb6:
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l32 = alloca i1
  %l53 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l116 = alloca i1
  %l133 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Func", ptr %t7, i32 0, i32 5
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeParams(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t10)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Func", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp ne ptr %t16, null
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Param", ptr %t23, i32 0, i32 2
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp ne ptr %t26, null
  store i1 %t28, ptr %l32, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb4
bb4:
  %t30 = load i1, ptr %l32, !tbaa !21
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Func", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Param", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t31, ptr %t38, i1 false)
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Func", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Param", ptr %t45, i32 0, i32 2
  %t48 = load ptr, ptr %t47, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t41, ptr %t48)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Sig", ptr %t51, i32 0, i32 0
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t68, ptr %l53, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  store ptr %t74, ptr %l7, !tbaa !29
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Param", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = icmp ne ptr %t79, null
  br i1 %t81, label %bb14, label %bb15
bb14:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l7, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Param", ptr %t84, i32 0, i32 2
  %t87 = load ptr, ptr %t86, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t83, ptr %t87)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l5, !tbaa !24
  br label %bb10
bb19:
  %t94 = load ptr, ptr %l3, !tbaa !29
  %t96 = getelementptr %"compiler/ast:Sig", ptr %t94, i32 0, i32 1
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l10, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s7
  %t103 = load i64, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s7)
  br label %bb26
bb22:
  br label %bb23
bb23:
  %t111 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t111, ptr %l72, !tbaa !27
  %t112 = load i64, ptr %l9, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t119 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t119, ptr %t117)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s7)
  br label %bb25
bb25:
  %t123 = load i64, ptr %l9, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l9, !tbaa !24
  br label %bb20
bb26:
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t129 = getelementptr %"compiler/ast:Sig", ptr %t127, i32 0, i32 3
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  store i64 %t134, ptr %l14, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s10
  %t136 = load i64, ptr %l13, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s10)
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t144 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t144, ptr %l87, !tbaa !27
  %t145 = load i64, ptr %l13, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr ptr, ptr %t148, i64 %t145
  %t150 = load ptr, ptr %t149, !tbaa !39
  %t152 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t152, ptr %t150)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s10)
  br label %bb32
bb32:
  %t156 = load i64, ptr %l13, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l13, !tbaa !24
  br label %bb27
bb33:
  %t160 = load ptr, ptr %l3, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Sig", ptr %t160, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l18, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s13
  %t169 = load i64, ptr %l17, !tbaa !24
  %t170 = load i64, ptr %l18, !tbaa !24
  %t173 = icmp slt i64 %t169, %t170
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s13)
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t177 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t177, ptr %l102, !tbaa !27
  %t178 = load i64, ptr %l17, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr ptr, ptr %t181, i64 %t178
  %t183 = load ptr, ptr %t182, !tbaa !39
  store ptr %t183, ptr %l19, !tbaa !29
  %t185 = load ptr, ptr %l19, !tbaa !29
  %t187 = getelementptr %"compiler/ast:Param", ptr %t185, i32 0, i32 3
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = icmp ne ptr %t188, null
  br i1 %t190, label %bb38, label %bb39
bb38:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load ptr, ptr %l19, !tbaa !29
  %t195 = getelementptr %"compiler/ast:Param", ptr %t193, i32 0, i32 3
  %t196 = load ptr, ptr %t195, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t192, ptr %t196)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s13)
  br label %bb42
bb42:
  %t199 = load i64, ptr %l17, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l17, !tbaa !24
  br label %bb34
bb43:
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr %"compiler/ast:Func", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = icmp ne ptr %t206, null
  br i1 %t208, label %bb44, label %bb45
bb44:
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr %"compiler/ast:Func", ptr %t210, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = getelementptr %"compiler/ast:Param", ptr %t213, i32 0, i32 1
  %t216 = load i32, ptr %t215, !tbaa !23
  %t218 = icmp ne i32 %t216, 0
  store i1 %t218, ptr %l116, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb46
bb46:
  %t220 = load i1, ptr %l116, !tbaa !21
  br i1 %t220, label %bb47, label %bb48
bb47:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr %"compiler/ast:Func", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t226 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %t221, ptr %t225, i1 %t226)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  %t230 = load ptr, ptr %l3, !tbaa !29
  %t232 = getelementptr %"compiler/ast:Sig", ptr %t230, i32 0, i32 0
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t235, 0
  store i64 %t237, ptr %l22, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s18
  %t239 = load i64, ptr %l21, !tbaa !24
  %t240 = load i64, ptr %l22, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s18)
  br label %bb57
bb53:
  br label %bb54
bb54:
  %t247 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t247, ptr %l133, !tbaa !27
  %t248 = load i64, ptr %l21, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr ptr, ptr %t251, i64 %t248
  %t253 = load ptr, ptr %t252, !tbaa !39
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %t255, ptr %t253, i1 %t257)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s18)
  br label %bb56
bb56:
  %t261 = load i64, ptr %l21, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l21, !tbaa !24
  br label %bb51
bb57:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l15 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 6
  store i64 %a1, ptr %t5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 7
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eClear_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t8)
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/names:Resolver", ptr %t10, i32 0, i32 8
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hb7e448baed1c9668005f7dc6325e5707(ptr %v0, ptr %t12)
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/names:Resolver", ptr %t14, i32 0, i32 9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H3edd758492d36e0e1280bad2972803df(ptr %v0, ptr %t16)
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 10
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eCle_Hfe7f0d5b2686087af262d47548aa26e4(ptr %v0, ptr %t20)
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/names:Resolver", ptr %t22, i32 0, i32 11
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eCle_Hfe7f0d5b2686087af262d47548aa26e4(ptr %v0, ptr %t24)
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/names:Resolver", ptr %t26, i32 0, i32 12
  store i1 false, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l15, !tbaa !29
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 14
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = add i64 %t32, 1
  %t36 = load ptr, ptr %l15, !tbaa !29
  %t37 = getelementptr %"compiler/names:Resolver", ptr %t36, i32 0, i32 14
  store i64 %t34, ptr %t37, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l82 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l101 = alloca i1
  %l110 = alloca i1
  %l113 = alloca { i64, ptr }
  %l114 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l187 = alloca i64
  %l205 = alloca ptr
  %l206 = alloca i1
  %l217 = alloca i64
  %l232 = alloca ptr
  %l233 = alloca i1
  %l244 = alloca ptr
  %l245 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca i1
  %l265 = alloca { i64, ptr }
  %l272 = alloca ptr
  %l273 = alloca i1
  %l286 = alloca ptr
  %l287 = alloca i1
  %l296 = alloca ptr
  %l297 = alloca i1
  %l306 = alloca ptr
  %l307 = alloca i1
  %l321 = alloca { i64, ptr }
  %l330 = alloca ptr
  %l331 = alloca i1
  %l342 = alloca ptr
  %l343 = alloca i1
  %l349 = alloca i64
  %l354 = alloca ptr
  %l355 = alloca i1
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s38 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t6 = load ptr, ptr %l52, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l52, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l53, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l53, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb224
bb10:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t25 = load ptr, ptr %l60, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l60, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l61, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l61, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", ptr }, ptr %t35, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2evarDecl(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb16
bb16:
  br label %bb224
bb17:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t44 = load ptr, ptr %l68, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb18, label %bb19
bb18:
  %t47 = load ptr, ptr %l68, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 2
  store i1 %t50, ptr %l69, !tbaa !21
  br label %bb19
bb19:
  %t51 = load i1, ptr %l69, !tbaa !21
  br i1 %t51, label %bb20, label %bb21
bb20:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb61
bb22:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Multi", ptr %t58, i32 0, i32 2
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  store i64 %t65, ptr %l7, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t75, ptr %l82, !tbaa !27
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t76
  %t81 = load ptr, ptr %t80, !tbaa !39
  %t83 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t83, ptr %t81)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l6, !tbaa !24
  br label %bb23
bb29:
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Multi", ptr %t91, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l11, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t100 = load i64, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb32:
  br label %bb33
bb33:
  %t108 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t108, ptr %l97, !tbaa !27
  %t109 = load i64, ptr %l10, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr ptr, ptr %t112, i64 %t109
  %t114 = load ptr, ptr %t113, !tbaa !39
  store ptr %t114, ptr %l12, !tbaa !29
  %t116 = load ptr, ptr %l12, !tbaa !29
  store ptr %t116, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t117 = load ptr, ptr %l100, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb34, label %bb35
bb34:
  %t120 = load ptr, ptr %l100, !tbaa !29
  %t121 = load i64, ptr %t120
  %t123 = icmp eq i64 %t121, 0
  store i1 %t123, ptr %l101, !tbaa !21
  br label %bb35
bb35:
  %t124 = load i1, ptr %l101, !tbaa !21
  br i1 %t124, label %bb36, label %bb37
bb36:
  %t125 = load ptr, ptr %l12, !tbaa !29
  %t127 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i32 }, ptr %t127, i32 0, i32 0
  %t129 = load %"compiler/source:Span", ptr %t128
  store %"compiler/source:Span" %t129, ptr %l13
  %t131 = load ptr, ptr %l12, !tbaa !29
  %t133 = getelementptr { i64, [5 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", i32 }, ptr %t133, i32 0, i32 1
  %t135 = load i32, ptr %t134
  store i32 %t135, ptr %l14, !tbaa !23
  br label %bb38
bb37:
  br label %bb52
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Multi", ptr %t137, i32 0, i32 1
  %t140 = load i1, ptr %t139, !tbaa !21
  br i1 %t140, label %bb39, label %bb40
bb39:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l14, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t142, i32 %t143)
  store { i64, ptr } %t146, ptr %l113
  br label %bb41
bb40:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb43
bb41:
  %t147 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s10, { i64, ptr } %t147, { i64, ptr } { i64 1, ptr @.d37 })
  store i1 %t148, ptr %l114
  br label %bb42
bb42:
  %t149 = load i1, ptr %l114, !tbaa !21
  %t150 = xor i1 %t149, true
  store i1 %t150, ptr %l110, !tbaa !21
  br label %bb43
bb43:
  %t152 = load i1, ptr %l110, !tbaa !21
  br i1 %t152, label %bb44, label %bb45
bb44:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l14, !tbaa !23
  %t155 = load %"compiler/source:Span", ptr %l13
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t153, i32 %t154, %"compiler/source:Span" %t155, i1 false)
  br label %bb46
bb45:
  %t159 = load ptr, ptr %l4, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Multi", ptr %t159, i32 0, i32 1
  %t162 = load i1, ptr %t161, !tbaa !21
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb47, label %bb48
bb46:
  br label %bb51
bb47:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t166, ptr %t167)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t170, ptr %t171)
  br label %bb56
bb56:
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @.c38)
  unreachable
bb58:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb59:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l10, !tbaa !24
  br label %bb30
bb60:
  br label %bb224
bb61:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t179 = load ptr, ptr %l128, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb62, label %bb63
bb62:
  %t182 = load ptr, ptr %l128, !tbaa !29
  %t183 = load i64, ptr %t182
  %t185 = icmp eq i64 %t183, 3
  store i1 %t185, ptr %l129, !tbaa !21
  br label %bb63
bb63:
  %t186 = load i1, ptr %l129, !tbaa !21
  br i1 %t186, label %bb64, label %bb65
bb64:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr { i64, [5 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t189, i32 0, i32 2
  %t191 = load ptr, ptr %t190
  store ptr %t191, ptr %l15, !tbaa !29
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr { i64, [5 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t195, i32 0, i32 3
  %t197 = load ptr, ptr %t196
  store ptr %t197, ptr %l16, !tbaa !29
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t199, ptr %t200)
  br label %bb67
bb67:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t203, ptr %t204)
  br label %bb68
bb68:
  br label %bb224
bb69:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t208 = load ptr, ptr %l140, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb70, label %bb71
bb70:
  %t211 = load ptr, ptr %l140, !tbaa !29
  %t212 = load i64, ptr %t211
  %t214 = icmp eq i64 %t212, 4
  store i1 %t214, ptr %l141, !tbaa !21
  br label %bb71
bb71:
  %t215 = load i1, ptr %l141, !tbaa !21
  br i1 %t215, label %bb72, label %bb73
bb72:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t218, i32 0, i32 1
  %t220 = load ptr, ptr %t219
  store ptr %t220, ptr %l17, !tbaa !29
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t224, i32 0, i32 2
  %t226 = load { i64, ptr }, ptr %t225
  store { i64, ptr } %t226, ptr %l18, !tbaa !27
  br label %bb74
bb73:
  br label %bb77
bb74:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t228, ptr %t229)
  br label %bb75
bb75:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t232, { i64, ptr } %t233)
  br label %bb76
bb76:
  br label %bb224
bb77:
  %t236 = load ptr, ptr %l1, !tbaa !29
  store ptr %t236, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t237 = load ptr, ptr %l152, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb78, label %bb79
bb78:
  %t240 = load ptr, ptr %l152, !tbaa !29
  %t241 = load i64, ptr %t240
  %t243 = icmp eq i64 %t241, 5
  store i1 %t243, ptr %l153, !tbaa !21
  br label %bb79
bb79:
  %t244 = load i1, ptr %l153, !tbaa !21
  br i1 %t244, label %bb80, label %bb81
bb80:
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [5 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", ptr }, ptr %t247, i32 0, i32 1
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l19, !tbaa !29
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eifStmt(ptr %v0, ptr %v1, ptr %t251, ptr %t252)
  br label %bb83
bb83:
  br label %bb224
bb84:
  %t255 = load ptr, ptr %l1, !tbaa !29
  store ptr %t255, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t256 = load ptr, ptr %l160, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb85, label %bb86
bb85:
  %t259 = load ptr, ptr %l160, !tbaa !29
  %t260 = load i64, ptr %t259
  %t262 = icmp eq i64 %t260, 6
  store i1 %t262, ptr %l161, !tbaa !21
  br label %bb86
bb86:
  %t263 = load i1, ptr %l161, !tbaa !21
  br i1 %t263, label %bb87, label %bb88
bb87:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [5 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t266, i32 0, i32 1
  %t268 = load { i64, ptr }, ptr %t267
  store { i64, ptr } %t268, ptr %l20, !tbaa !27
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t270, { i64, ptr } %t271)
  br label %bb90
bb90:
  br label %bb224
bb91:
  %t274 = load ptr, ptr %l1, !tbaa !29
  store ptr %t274, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t275 = load ptr, ptr %l168, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb92, label %bb93
bb92:
  %t278 = load ptr, ptr %l168, !tbaa !29
  %t279 = load i64, ptr %t278
  %t281 = icmp eq i64 %t279, 7
  store i1 %t281, ptr %l169, !tbaa !21
  br label %bb93
bb93:
  %t282 = load i1, ptr %l169, !tbaa !21
  br i1 %t282, label %bb94, label %bb95
bb94:
  %t283 = load ptr, ptr %l1, !tbaa !29
  %t285 = getelementptr { i64, [5 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t285, i32 0, i32 1
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l21, !tbaa !29
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 1
  %t292 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t291, i32 0, i32 2
  %t293 = load { i64, ptr }, ptr %t292
  store { i64, ptr } %t293, ptr %l22, !tbaa !27
  br label %bb96
bb95:
  br label %bb99
bb96:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t295, ptr %t296)
  br label %bb97
bb97:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t299, { i64, ptr } %t300)
  br label %bb98
bb98:
  br label %bb224
bb99:
  %t303 = load ptr, ptr %l1, !tbaa !29
  store ptr %t303, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t304 = load ptr, ptr %l180, !tbaa !29
  %t305 = icmp ne ptr %t304, null
  br i1 %t305, label %bb100, label %bb101
bb100:
  %t307 = load ptr, ptr %l180, !tbaa !29
  %t308 = load i64, ptr %t307
  %t310 = icmp eq i64 %t308, 8
  store i1 %t310, ptr %l181, !tbaa !21
  br label %bb101
bb101:
  %t311 = load i1, ptr %l181, !tbaa !21
  br i1 %t311, label %bb102, label %bb103
bb102:
  %t312 = load ptr, ptr %l1, !tbaa !29
  %t314 = getelementptr { i64, [5 x i64] }, ptr %t312, i32 0, i32 1
  %t315 = getelementptr { %"compiler/source:Span", ptr }, ptr %t314, i32 0, i32 1
  %t316 = load ptr, ptr %t315
  store ptr %t316, ptr %l23, !tbaa !29
  br label %bb104
bb103:
  br label %bb114
bb104:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t318)
  store i64 %t320, ptr %l187
  br label %bb105
bb105:
  %t321 = load i64, ptr %l187, !tbaa !24
  store i64 %t321, ptr %l24, !tbaa !24
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load ptr, ptr %l23, !tbaa !29
  %t325 = getelementptr %"compiler/ast:For3", ptr %t323, i32 0, i32 0
  %t326 = load ptr, ptr %t325, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t322, ptr %t326)
  br label %bb106
bb106:
  %t329 = load ptr, ptr %l23, !tbaa !29
  %t331 = getelementptr %"compiler/ast:For3", ptr %t329, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !29
  %t334 = icmp ne ptr %t332, null
  br i1 %t334, label %bb107, label %bb108
bb107:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load ptr, ptr %l23, !tbaa !29
  %t339 = getelementptr %"compiler/ast:For3", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t336, ptr %t340)
  br label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb110
bb110:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l23, !tbaa !29
  %t346 = getelementptr %"compiler/ast:For3", ptr %t344, i32 0, i32 2
  %t347 = load ptr, ptr %t346, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t343, ptr %t347)
  br label %bb111
bb111:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load ptr, ptr %l23, !tbaa !29
  %t353 = getelementptr %"compiler/ast:For3", ptr %t351, i32 0, i32 3
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t350, { i64, ptr } %t354)
  br label %bb112
bb112:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i64, ptr %l24, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t357, i64 %t358)
  br label %bb113
bb113:
  br label %bb224
bb114:
  %t361 = load ptr, ptr %l1, !tbaa !29
  store ptr %t361, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t362 = load ptr, ptr %l205, !tbaa !29
  %t363 = icmp ne ptr %t362, null
  br i1 %t363, label %bb115, label %bb116
bb115:
  %t365 = load ptr, ptr %l205, !tbaa !29
  %t366 = load i64, ptr %t365
  %t368 = icmp eq i64 %t366, 9
  store i1 %t368, ptr %l206, !tbaa !21
  br label %bb116
bb116:
  %t369 = load i1, ptr %l206, !tbaa !21
  br i1 %t369, label %bb117, label %bb118
bb117:
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t372 = getelementptr { i64, [5 x i64] }, ptr %t370, i32 0, i32 1
  %t373 = getelementptr { %"compiler/source:Span", ptr }, ptr %t372, i32 0, i32 0
  %t374 = load %"compiler/source:Span", ptr %t373
  store %"compiler/source:Span" %t374, ptr %l25
  %t376 = load ptr, ptr %l1, !tbaa !29
  %t378 = getelementptr { i64, [5 x i64] }, ptr %t376, i32 0, i32 1
  %t379 = getelementptr { %"compiler/source:Span", ptr }, ptr %t378, i32 0, i32 1
  %t380 = load ptr, ptr %t379
  store ptr %t380, ptr %l26, !tbaa !29
  br label %bb119
bb118:
  br label %bb126
bb119:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load ptr, ptr %l26, !tbaa !29
  %t385 = getelementptr %"compiler/ast:ForIn", ptr %t383, i32 0, i32 2
  %t386 = load ptr, ptr %t385, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t382, ptr %t386)
  br label %bb120
bb120:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t389)
  store i64 %t391, ptr %l217
  br label %bb121
bb121:
  %t392 = load i64, ptr %l217, !tbaa !24
  store i64 %t392, ptr %l27, !tbaa !24
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 0
  %t395 = load i32, ptr %t394, !tbaa !23
  %t396 = load ptr, ptr %l26, !tbaa !29
  %t398 = getelementptr %"compiler/ast:ForIn", ptr %t396, i32 0, i32 0
  %t399 = load i32, ptr %t398, !tbaa !23
  %t400 = load ptr, ptr %l26, !tbaa !29
  %t402 = getelementptr %"compiler/ast:ForIn", ptr %t400, i32 0, i32 1
  %t403 = load i32, ptr %t402, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforNames(ptr %v0, ptr %t393, i32 %t395, i32 %t399, i32 %t403)
  br label %bb122
bb122:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load ptr, ptr %l26, !tbaa !29
  %t411 = getelementptr %"compiler/ast:ForIn", ptr %t409, i32 0, i32 4
  %t412 = load { i64, ptr }, ptr %t411, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t408, { i64, ptr } %t412)
  br label %bb123
bb123:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load i64, ptr %l27, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t415, i64 %t416)
  br label %bb124
bb124:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load ptr, ptr %l26, !tbaa !29
  %t422 = getelementptr %"compiler/ast:ForIn", ptr %t420, i32 0, i32 5
  %t423 = load { i64, ptr }, ptr %t422, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t419, { i64, ptr } %t423)
  br label %bb125
bb125:
  br label %bb224
bb126:
  %t426 = load ptr, ptr %l1, !tbaa !29
  store ptr %t426, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t427 = load ptr, ptr %l232, !tbaa !29
  %t428 = icmp ne ptr %t427, null
  br i1 %t428, label %bb127, label %bb128
bb127:
  %t430 = load ptr, ptr %l232, !tbaa !29
  %t431 = load i64, ptr %t430
  %t433 = icmp eq i64 %t431, 10
  store i1 %t433, ptr %l233, !tbaa !21
  br label %bb128
bb128:
  %t434 = load i1, ptr %l233, !tbaa !21
  br i1 %t434, label %bb129, label %bb130
bb129:
  %t435 = load ptr, ptr %l1, !tbaa !29
  %t437 = getelementptr { i64, [5 x i64] }, ptr %t435, i32 0, i32 1
  %t438 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t437, i32 0, i32 1
  %t439 = load { i64, ptr }, ptr %t438
  store { i64, ptr } %t439, ptr %l28, !tbaa !27
  %t441 = load ptr, ptr %l1, !tbaa !29
  %t443 = getelementptr { i64, [5 x i64] }, ptr %t441, i32 0, i32 1
  %t444 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t443, i32 0, i32 2
  %t445 = load ptr, ptr %t444
  store ptr %t445, ptr %l29, !tbaa !29
  br label %bb131
bb130:
  br label %bb134
bb131:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t447, { i64, ptr } %t448)
  br label %bb132
bb132:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t451, ptr %t452)
  br label %bb133
bb133:
  br label %bb224
bb134:
  %t455 = load ptr, ptr %l1, !tbaa !29
  store ptr %t455, ptr %l244, !tbaa !29
  store i1 false, ptr %l245, !tbaa !21
  %t456 = load ptr, ptr %l244, !tbaa !29
  %t457 = icmp ne ptr %t456, null
  br i1 %t457, label %bb135, label %bb136
bb135:
  %t459 = load ptr, ptr %l244, !tbaa !29
  %t460 = load i64, ptr %t459
  %t462 = icmp eq i64 %t460, 11
  store i1 %t462, ptr %l245, !tbaa !21
  br label %bb136
bb136:
  %t463 = load i1, ptr %l245, !tbaa !21
  br i1 %t463, label %bb137, label %bb138
bb137:
  %t464 = load ptr, ptr %l1, !tbaa !29
  %t466 = getelementptr { i64, [5 x i64] }, ptr %t464, i32 0, i32 1
  %t467 = getelementptr { %"compiler/source:Span", ptr }, ptr %t466, i32 0, i32 1
  %t468 = load ptr, ptr %t467
  store ptr %t468, ptr %l30, !tbaa !29
  br label %bb139
bb138:
  br label %bb141
bb139:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ematchOf(ptr %v0, ptr %v1, ptr %t470, ptr %t471)
  br label %bb140
bb140:
  br label %bb224
bb141:
  %t474 = load ptr, ptr %l1, !tbaa !29
  store ptr %t474, ptr %l252, !tbaa !29
  store i1 false, ptr %l253, !tbaa !21
  %t475 = load ptr, ptr %l252, !tbaa !29
  %t476 = icmp ne ptr %t475, null
  br i1 %t476, label %bb142, label %bb143
bb142:
  %t478 = load ptr, ptr %l252, !tbaa !29
  %t479 = load i64, ptr %t478
  %t481 = icmp eq i64 %t479, 12
  store i1 %t481, ptr %l253, !tbaa !21
  br label %bb143
bb143:
  %t482 = load i1, ptr %l253, !tbaa !21
  br i1 %t482, label %bb144, label %bb145
bb144:
  %t483 = load ptr, ptr %l1, !tbaa !29
  %t485 = getelementptr { i64, [5 x i64] }, ptr %t483, i32 0, i32 1
  %t486 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t485, i32 0, i32 1
  %t487 = load { i64, ptr }, ptr %t486
  store { i64, ptr } %t487, ptr %l31, !tbaa !27
  br label %bb146
bb145:
  br label %bb154
bb146:
  %t489 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t489, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 0
  store i64 %t493, ptr %l34, !tbaa !24
  br label %bb147
bb147:
  store %olang.scope zeroinitializer, ptr %s28
  %t495 = load i64, ptr %l33, !tbaa !24
  %t496 = load i64, ptr %l34, !tbaa !24
  %t499 = icmp slt i64 %t495, %t496
  %t501 = xor i1 %t499, true
  br i1 %t501, label %bb148, label %bb149
bb148:
  call void @__olang_scope_close(ptr %s28)
  br label %bb153
bb149:
  br label %bb150
bb150:
  %t503 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t503, ptr %l265, !tbaa !27
  %t504 = load i64, ptr %l33, !tbaa !24
  %t506 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr ptr, ptr %t507, i64 %t504
  %t509 = load ptr, ptr %t508, !tbaa !39
  %t511 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t511, ptr %t509)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s28)
  br label %bb152
bb152:
  %t515 = load i64, ptr %l33, !tbaa !24
  %t517 = add i64 %t515, 1
  store i64 %t517, ptr %l33, !tbaa !24
  br label %bb147
bb153:
  br label %bb224
bb154:
  %t519 = load ptr, ptr %l1, !tbaa !29
  store ptr %t519, ptr %l272, !tbaa !29
  store i1 false, ptr %l273, !tbaa !21
  %t520 = load ptr, ptr %l272, !tbaa !29
  %t521 = icmp ne ptr %t520, null
  br i1 %t521, label %bb155, label %bb156
bb155:
  %t523 = load ptr, ptr %l272, !tbaa !29
  %t524 = load i64, ptr %t523
  %t526 = icmp eq i64 %t524, 14
  store i1 %t526, ptr %l273, !tbaa !21
  br label %bb156
bb156:
  %t527 = load i1, ptr %l273, !tbaa !21
  br i1 %t527, label %bb157, label %bb158
bb157:
  %t528 = load ptr, ptr %l1, !tbaa !29
  %t530 = getelementptr { i64, [5 x i64] }, ptr %t528, i32 0, i32 1
  %t531 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t530, i32 0, i32 1
  %t532 = load ptr, ptr %t531
  store ptr %t532, ptr %l36, !tbaa !29
  %t534 = load ptr, ptr %l1, !tbaa !29
  %t536 = getelementptr { i64, [5 x i64] }, ptr %t534, i32 0, i32 1
  %t537 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t536, i32 0, i32 2
  %t538 = load ptr, ptr %t537
  store ptr %t538, ptr %l37, !tbaa !29
  br label %bb159
bb158:
  br label %bb165
bb159:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t541 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t540, ptr %t541)
  br label %bb160
bb160:
  %t544 = load ptr, ptr %l37, !tbaa !29
  %t546 = icmp ne ptr %t544, null
  br i1 %t546, label %bb161, label %bb162
bb161:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t549 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t548, ptr %t549)
  br label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb164
bb164:
  br label %bb224
bb165:
  %t552 = load ptr, ptr %l1, !tbaa !29
  store ptr %t552, ptr %l286, !tbaa !29
  store i1 false, ptr %l287, !tbaa !21
  %t553 = load ptr, ptr %l286, !tbaa !29
  %t554 = icmp ne ptr %t553, null
  br i1 %t554, label %bb166, label %bb167
bb166:
  %t556 = load ptr, ptr %l286, !tbaa !29
  %t557 = load i64, ptr %t556
  %t559 = icmp eq i64 %t557, 13
  store i1 %t559, ptr %l287, !tbaa !21
  br label %bb167
bb167:
  %t560 = load i1, ptr %l287, !tbaa !21
  br i1 %t560, label %bb168, label %bb169
bb168:
  %t561 = load ptr, ptr %l1, !tbaa !29
  %t563 = getelementptr { i64, [5 x i64] }, ptr %t561, i32 0, i32 1
  %t564 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t563, i32 0, i32 2
  %t565 = load ptr, ptr %t564
  store ptr %t565, ptr %l38, !tbaa !29
  br label %bb170
bb169:
  br label %bb175
bb170:
  %t567 = load ptr, ptr %l38, !tbaa !29
  %t569 = icmp ne ptr %t567, null
  br i1 %t569, label %bb171, label %bb172
bb171:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t571, ptr %t572)
  br label %bb173
bb172:
  br label %bb174
bb173:
  br label %bb174
bb174:
  br label %bb224
bb175:
  %t575 = load ptr, ptr %l1, !tbaa !29
  store ptr %t575, ptr %l296, !tbaa !29
  store i1 false, ptr %l297, !tbaa !21
  %t576 = load ptr, ptr %l296, !tbaa !29
  %t577 = icmp ne ptr %t576, null
  br i1 %t577, label %bb176, label %bb177
bb176:
  %t579 = load ptr, ptr %l296, !tbaa !29
  %t580 = load i64, ptr %t579
  %t582 = icmp eq i64 %t580, 15
  store i1 %t582, ptr %l297, !tbaa !21
  br label %bb177
bb177:
  %t583 = load i1, ptr %l297, !tbaa !21
  br i1 %t583, label %bb178, label %bb179
bb178:
  %t584 = load ptr, ptr %l1, !tbaa !29
  %t586 = getelementptr { i64, [5 x i64] }, ptr %t584, i32 0, i32 1
  %t587 = getelementptr { %"compiler/source:Span", ptr }, ptr %t586, i32 0, i32 1
  %t588 = load ptr, ptr %t587
  store ptr %t588, ptr %l39, !tbaa !29
  br label %bb180
bb179:
  br label %bb185
bb180:
  %t590 = load ptr, ptr %l39, !tbaa !29
  %t592 = icmp ne ptr %t590, null
  br i1 %t592, label %bb181, label %bb182
bb181:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t594, ptr %t595)
  br label %bb183
bb182:
  br label %bb184
bb183:
  br label %bb184
bb184:
  br label %bb224
bb185:
  %t598 = load ptr, ptr %l1, !tbaa !29
  store ptr %t598, ptr %l306, !tbaa !29
  store i1 false, ptr %l307, !tbaa !21
  %t599 = load ptr, ptr %l306, !tbaa !29
  %t600 = icmp ne ptr %t599, null
  br i1 %t600, label %bb186, label %bb187
bb186:
  %t602 = load ptr, ptr %l306, !tbaa !29
  %t603 = load i64, ptr %t602
  %t605 = icmp eq i64 %t603, 16
  store i1 %t605, ptr %l307, !tbaa !21
  br label %bb187
bb187:
  %t606 = load i1, ptr %l307, !tbaa !21
  br i1 %t606, label %bb188, label %bb189
bb188:
  %t607 = load ptr, ptr %l1, !tbaa !29
  %t609 = getelementptr { i64, [5 x i64] }, ptr %t607, i32 0, i32 1
  %t610 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t609, i32 0, i32 1
  %t611 = load { i64, ptr }, ptr %t610
  store { i64, ptr } %t611, ptr %l40, !tbaa !27
  %t613 = load ptr, ptr %l1, !tbaa !29
  %t615 = getelementptr { i64, [5 x i64] }, ptr %t613, i32 0, i32 1
  %t616 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t615, i32 0, i32 2
  %t617 = load ptr, ptr %t616
  store ptr %t617, ptr %l41, !tbaa !29
  br label %bb190
bb189:
  br label %bb199
bb190:
  %t619 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t619, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t621 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t623 = extractvalue { i64, ptr } %t621, 0
  store i64 %t623, ptr %l44, !tbaa !24
  br label %bb191
bb191:
  store %olang.scope zeroinitializer, ptr %s38
  %t625 = load i64, ptr %l43, !tbaa !24
  %t626 = load i64, ptr %l44, !tbaa !24
  %t629 = icmp slt i64 %t625, %t626
  %t631 = xor i1 %t629, true
  br i1 %t631, label %bb192, label %bb193
bb192:
  call void @__olang_scope_close(ptr %s38)
  br label %bb197
bb193:
  br label %bb194
bb194:
  %t633 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t633, ptr %l321, !tbaa !27
  %t634 = load i64, ptr %l43, !tbaa !24
  %t636 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t637 = load ptr, ptr %t636, !tbaa !27
  %t638 = getelementptr ptr, ptr %t637, i64 %t634
  %t639 = load ptr, ptr %t638, !tbaa !39
  %t641 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t641, ptr %t639)
  br label %bb195
bb195:
  call void @__olang_scope_close(ptr %s38)
  br label %bb196
bb196:
  %t645 = load i64, ptr %l43, !tbaa !24
  %t647 = add i64 %t645, 1
  store i64 %t647, ptr %l43, !tbaa !24
  br label %bb191
bb197:
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t650 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t649, ptr %t650)
  br label %bb198
bb198:
  br label %bb224
bb199:
  %t653 = load ptr, ptr %l1, !tbaa !29
  store ptr %t653, ptr %l330, !tbaa !29
  store i1 false, ptr %l331, !tbaa !21
  %t654 = load ptr, ptr %l330, !tbaa !29
  %t655 = icmp ne ptr %t654, null
  br i1 %t655, label %bb200, label %bb201
bb200:
  %t657 = load ptr, ptr %l330, !tbaa !29
  %t658 = load i64, ptr %t657
  %t660 = icmp eq i64 %t658, 17
  store i1 %t660, ptr %l331, !tbaa !21
  br label %bb201
bb201:
  %t661 = load i1, ptr %l331, !tbaa !21
  br i1 %t661, label %bb202, label %bb203
bb202:
  %t662 = load ptr, ptr %l1, !tbaa !29
  %t664 = getelementptr { i64, [5 x i64] }, ptr %t662, i32 0, i32 1
  %t665 = getelementptr { %"compiler/source:Span", ptr }, ptr %t664, i32 0, i32 1
  %t666 = load ptr, ptr %t665
  store ptr %t666, ptr %l46, !tbaa !29
  br label %bb204
bb203:
  br label %bb207
bb204:
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t669 = load ptr, ptr %l46, !tbaa !29
  %t671 = getelementptr %"compiler/ast:JoinS", ptr %t669, i32 0, i32 1
  %t672 = load { i64, ptr }, ptr %t671, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t668, { i64, ptr } %t672)
  br label %bb205
bb205:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t676 = load ptr, ptr %l46, !tbaa !29
  %t678 = getelementptr %"compiler/ast:JoinS", ptr %t676, i32 0, i32 2
  %t679 = load { i64, ptr }, ptr %t678, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t675, { i64, ptr } %t679)
  br label %bb206
bb206:
  br label %bb224
bb207:
  %t682 = load ptr, ptr %l1, !tbaa !29
  store ptr %t682, ptr %l342, !tbaa !29
  store i1 false, ptr %l343, !tbaa !21
  %t683 = load ptr, ptr %l342, !tbaa !29
  %t684 = icmp ne ptr %t683, null
  br i1 %t684, label %bb208, label %bb209
bb208:
  %t686 = load ptr, ptr %l342, !tbaa !29
  %t687 = load i64, ptr %t686
  %t689 = icmp eq i64 %t687, 18
  store i1 %t689, ptr %l343, !tbaa !21
  br label %bb209
bb209:
  %t690 = load i1, ptr %l343, !tbaa !21
  br i1 %t690, label %bb210, label %bb211
bb210:
  %t691 = load ptr, ptr %l1, !tbaa !29
  %t693 = getelementptr { i64, [5 x i64] }, ptr %t691, i32 0, i32 1
  %t694 = getelementptr { %"compiler/source:Span", ptr }, ptr %t693, i32 0, i32 1
  %t695 = load ptr, ptr %t694
  store ptr %t695, ptr %l47, !tbaa !29
  br label %bb212
bb211:
  br label %bb216
bb212:
  %t697 = load ptr, ptr %l0, !tbaa !29
  %t699 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t697)
  store i64 %t699, ptr %l349
  br label %bb213
bb213:
  %t700 = load i64, ptr %l349, !tbaa !24
  store i64 %t700, ptr %l48, !tbaa !24
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t702 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t701, ptr %t702)
  br label %bb214
bb214:
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load i64, ptr %l48, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t705, i64 %t706)
  br label %bb215
bb215:
  br label %bb224
bb216:
  %t709 = load ptr, ptr %l1, !tbaa !29
  store ptr %t709, ptr %l354, !tbaa !29
  store i1 false, ptr %l355, !tbaa !21
  %t710 = load ptr, ptr %l354, !tbaa !29
  %t711 = icmp ne ptr %t710, null
  br i1 %t711, label %bb217, label %bb218
bb217:
  %t713 = load ptr, ptr %l354, !tbaa !29
  %t714 = load i64, ptr %t713
  %t716 = icmp eq i64 %t714, 19
  store i1 %t716, ptr %l355, !tbaa !21
  br label %bb218
bb218:
  %t717 = load i1, ptr %l355, !tbaa !21
  br i1 %t717, label %bb219, label %bb220
bb219:
  %t718 = load ptr, ptr %l1, !tbaa !29
  %t720 = getelementptr { i64, [5 x i64] }, ptr %t718, i32 0, i32 1
  %t721 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t720, i32 0, i32 1
  %t722 = load { i64, ptr }, ptr %t721
  store { i64, ptr } %t722, ptr %l49, !tbaa !27
  br label %bb221
bb220:
  br label %bb223
bb221:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t724, { i64, ptr } %t725)
  br label %bb222
bb222:
  br label %bb224
bb223:
  br label %bb224
bb224:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esuggests(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/names:Entry"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l21 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l31 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l41 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l70 = alloca i1
  %l73 = alloca i1
  %l78 = alloca i64
  %l79 = alloca [14 x { i64, ptr }]
  %l92 = alloca i64
  %l102 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l118 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l139 = alloca ptr
  %l142 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca i32
  %l155 = alloca { i64, ptr }
  %l160 = alloca i64
  %l171 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l172 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l174 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l175 = alloca i32
  %l178 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l182 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sge i64 %t3, 2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l26, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = sub i64 %t10, 1
  %t14 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t17)
  store i1 %t19, ptr %l31
  br label %bb3
bb2:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb4
bb3:
  %t20 = load i1, ptr %l31, !tbaa !21
  store i1 %t20, ptr %l25, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l25, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l2, !tbaa !24
  br label %bb7
bb6:
  br label %bb37
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load i64, ptr %l2, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t30, ptr %l37, !tbaa !27
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t31, 1
  %t35 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t33
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t38)
  store i1 %t40, ptr %l41
  br label %bb10
bb9:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb11
bb10:
  %t41 = load i1, ptr %l41, !tbaa !21
  store i1 %t41, ptr %l36, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l36, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  br label %bb7
bb16:
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = load i64, ptr %l2, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t57 = icmp slt i64 %t55, 8
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t59, ptr %l51, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l52, !tbaa !24
  %t62 = icmp sge i64 0, 0
  br i1 %t62, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb33
bb19:
  %t64 = icmp sle i64 0, 1
  br i1 %t64, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb21:
  %t66 = load i64, ptr %l52, !tbaa !24
  %t67 = icmp sle i64 1, %t66
  br i1 %t67, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb23:
  %t69 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 0
  %t72 = sub i64 1, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  %t76 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v1, ptr %s1, { i64, ptr } %t74)
  store { i64, ptr } %t76, ptr %l57
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb25:
  %t77 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t77, ptr %l58, !tbaa !27
  %t78 = load i64, ptr %l2, !tbaa !24
  store i64 %t78, ptr %l59, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t79, 0
  store i64 %t82, ptr %l62, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l63, !tbaa !24
  %t85 = load i64, ptr %l59, !tbaa !24
  %t86 = icmp sge i64 %t85, 0
  br i1 %t86, label %bb26, label %bb27
bb26:
  %t88 = load i64, ptr %l59, !tbaa !24
  %t89 = load i64, ptr %l62, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb28:
  %t92 = load i64, ptr %l62, !tbaa !24
  %t93 = load i64, ptr %l63, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb30:
  %t96 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l59, !tbaa !24
  %t99 = load i64, ptr %l62, !tbaa !24
  %t100 = getelementptr i8, ptr %t97, i64 %t98
  %t101 = sub i64 %t99, %t98
  %t102 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  %t104 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = extractvalue { i64, ptr } %t103, 1
  %t109 = extractvalue { i64, ptr } %t103, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t105, i64 %t106)
  %t112 = getelementptr i8, ptr %t111, i64 %t106
  call void @olang_textcopy(ptr %t112, ptr %t108, i64 %t109)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } %t114, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t123 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %s1, { i64, ptr } %t121)
  store i1 %t123, ptr %l70
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb32:
  %t124 = load i1, ptr %l70, !tbaa !21
  store i1 %t124, ptr %l50, !tbaa !21
  br label %bb33
bb33:
  %t125 = load i1, ptr %l50, !tbaa !21
  br i1 %t125, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s1)
  br label %bb37
bb37:
  %t127 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t127, { i64, ptr } { i64 4, ptr @.d40 })
  store i1 %t129, ptr %l73
  br label %bb38
bb38:
  %t130 = load i1, ptr %l73, !tbaa !21
  br i1 %t130, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t132 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t136 = icmp sle i64 %t134, 4
  br i1 %t136, label %bb42, label %bb43
bb42:
  store i64 2, ptr %l78, !tbaa !24
  br label %bb44
bb43:
  store i64 3, ptr %l78, !tbaa !24
  br label %bb44
bb44:
  %t138 = load i64, ptr %l78, !tbaa !24
  store i64 %t138, ptr %l3, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s6
  %t139 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 0
  store { i64, ptr } { i64 2, ptr @.d41 }, ptr %t139, !tbaa !37
  %t140 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr @.d42 }, ptr %t140, !tbaa !37
  %t141 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 2
  store { i64, ptr } { i64 3, ptr @.d43 }, ptr %t141, !tbaa !37
  %t142 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 3
  store { i64, ptr } { i64 3, ptr @.d44 }, ptr %t142, !tbaa !37
  %t143 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr @.d45 }, ptr %t143, !tbaa !37
  %t144 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr @.d46 }, ptr %t144, !tbaa !37
  %t145 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr @.d47 }, ptr %t145, !tbaa !37
  %t146 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 7
  store { i64, ptr } { i64 3, ptr @.d48 }, ptr %t146, !tbaa !37
  %t147 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr @.d49 }, ptr %t147, !tbaa !37
  %t148 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 9
  store { i64, ptr } { i64 4, ptr @.d50 }, ptr %t148, !tbaa !37
  %t149 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr @.d51 }, ptr %t149, !tbaa !37
  %t150 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr @.d52 }, ptr %t150, !tbaa !37
  %t151 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 12
  store { i64, ptr } { i64 4, ptr @.d53 }, ptr %t151, !tbaa !37
  %t152 = getelementptr [14 x { i64, ptr }], ptr %l79, i64 0, i64 13
  store { i64, ptr } { i64 5, ptr @.d54 }, ptr %t152, !tbaa !37
  %t153 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 224, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %l79, i64 224, i1 false)
  store ptr %t153, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t155 = load ptr, ptr %l4
  store i64 14, ptr %l6, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s7
  %t158 = load i64, ptr %l5, !tbaa !24
  %t159 = load i64, ptr %l6, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb54
bb47:
  br label %bb48
bb48:
  %t166 = load ptr, ptr %l4
  %t167 = load i64, ptr %l5, !tbaa !24
  %t170 = getelementptr [14 x { i64, ptr }], ptr %t166, i64 0, i64 %t167
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !37
  %t173 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t175 = load ptr, ptr @__olang_prog_scope
  %t178 = call i64 @compiler_2fnames_2edistance(ptr %v1, ptr %t175, { i64, ptr } %t173, { i64, ptr } %t171)
  store i64 %t178, ptr %l92
  br label %bb49
bb49:
  %t179 = load i64, ptr %l3, !tbaa !24
  %t180 = load i64, ptr %l92, !tbaa !24
  %t182 = icmp slt i64 %t180, %t179
  br i1 %t182, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb53:
  %t185 = load i64, ptr %l5, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l5, !tbaa !24
  br label %bb45
bb54:
  call void @__olang_scope_close(ptr %s6)
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/names:Resolver", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/names:Resolver", ptr %t192, i32 0, i32 6
  %t195 = load i64, ptr %t194, !tbaa !24
  %t198 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t191, i64 %t195)
  store ptr %t198, ptr %l102
  br label %bb55
bb55:
  %t199 = load ptr, ptr %l102, !tbaa !29
  %t201 = getelementptr %"compiler/names:Table", ptr %t199, i32 0, i32 0
  store ptr %t201, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  %t203 = load ptr, ptr %l8, !tbaa !29
  %t204 = load i64, ptr %l9, !tbaa !24
  %t207 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t203, i64 %t204)
  %t208 = extractvalue { i32, { i64, ptr } } %t207, 1
  %t209 = extractvalue { i32, { i64, ptr } } %t207, 0
  store i32 %t209, ptr %l109
  %t210 = icmp ne i32 %t209, 0
  br i1 %t210, label %bb58, label %ok.211
ok.211:
  store { i64, ptr } %t208, ptr %l108
  br label %bb57
bb57:
  %t212 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t212, ptr %l105, !tbaa !27
  br label %bb62
bb58:
  %t213 = load i32, ptr %l109, !tbaa !23
  %t214 = ashr i32 %t213, 16
  %t216 = icmp eq i32 %t214, 1
  br i1 %t216, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb75
bb62:
  %t218 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t218, ptr %l10, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t219, 0
  store i64 %t221, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t223 = load i64, ptr %l12, !tbaa !24
  %t224 = load i64, ptr %l11, !tbaa !24
  %t227 = icmp slt i64 %t223, %t224
  %t229 = xor i1 %t227, true
  br i1 %t229, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s12)
  br label %bb73
bb65:
  br label %bb66
bb66:
  %t231 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t231, ptr %l118, !tbaa !27
  %t232 = load i64, ptr %l12, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr %"compiler/names:Entry", ptr %t235, i64 %t232
  %t237 = load %"compiler/names:Entry", ptr %t236
  store %"compiler/names:Entry" %t237, ptr %l13
  %t239 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t239, ptr %l121, !tbaa !27
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/names:Entry", ptr %l13, i32 0, i32 0
  %t242 = load i32, ptr %t241, !tbaa !23
  %t245 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t240, i32 %t242)
  store { i64, ptr } %t245, ptr %l124
  br label %bb67
bb67:
  %t246 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t248 = call i64 @compiler_2fnames_2edistance(ptr %v1, ptr %v0, { i64, ptr } %t246, { i64, ptr } %t247)
  store i64 %t248, ptr %l125
  br label %bb68
bb68:
  %t249 = load i64, ptr %l3, !tbaa !24
  %t250 = load i64, ptr %l125, !tbaa !24
  %t252 = icmp slt i64 %t250, %t249
  br i1 %t252, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s12)
  br label %bb72
bb72:
  %t255 = load i64, ptr %l12, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l12, !tbaa !24
  br label %bb63
bb73:
  %t259 = load i64, ptr %l9, !tbaa !24
  %t260 = load i64, ptr %l11, !tbaa !24
  %t263 = add i64 %t259, %t260
  store i64 %t263, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb74:
  br label %bb56
bb75:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/names:Resolver", ptr %t265, i32 0, i32 0
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t270 = getelementptr %"compiler/load:Loader", ptr %t268, i32 0, i32 5
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/names:Resolver", ptr %t271, i32 0, i32 6
  %t274 = load i64, ptr %t273, !tbaa !24
  %t277 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t270, i64 %t274)
  store ptr %t277, ptr %l139
  br label %bb76
bb76:
  %t278 = load ptr, ptr %l139, !tbaa !29
  %t280 = getelementptr %"compiler/load:Module", ptr %t278, i32 0, i32 9
  store ptr %t280, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s16
  %t282 = load ptr, ptr %l14, !tbaa !29
  %t283 = load i64, ptr %l15, !tbaa !24
  %t286 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t282, i64 %t283)
  %t287 = extractvalue { i32, { i64, ptr } } %t286, 1
  %t288 = extractvalue { i32, { i64, ptr } } %t286, 0
  store i32 %t288, ptr %l146
  %t289 = icmp ne i32 %t288, 0
  br i1 %t289, label %bb79, label %ok.290
ok.290:
  store { i64, ptr } %t287, ptr %l145
  br label %bb78
bb78:
  %t291 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t291, ptr %l142, !tbaa !27
  br label %bb83
bb79:
  %t292 = load i32, ptr %l146, !tbaa !23
  %t293 = ashr i32 %t292, 16
  %t295 = icmp eq i32 %t293, 1
  br i1 %t295, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @.c56)
  unreachable
bb82:
  call void @__olang_scope_close(ptr %s16)
  br label %bb95
bb83:
  %t297 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t297, ptr %l16, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t298, 0
  store i64 %t300, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s17
  %t302 = load i64, ptr %l18, !tbaa !24
  %t303 = load i64, ptr %l17, !tbaa !24
  %t306 = icmp slt i64 %t302, %t303
  %t308 = xor i1 %t306, true
  br i1 %t308, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s17)
  br label %bb93
bb86:
  br label %bb87
bb87:
  %t310 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t310, ptr %l155, !tbaa !27
  %t311 = load i64, ptr %l18, !tbaa !24
  %t313 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr { i64, ptr }, ptr %t314, i64 %t311
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !37
  %t318 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t322 = call i64 @compiler_2fnames_2edistance(ptr %v1, ptr %v0, { i64, ptr } %t318, { i64, ptr } %t316)
  store i64 %t322, ptr %l160
  br label %bb88
bb88:
  %t323 = load i64, ptr %l3, !tbaa !24
  %t324 = load i64, ptr %l160, !tbaa !24
  %t326 = icmp slt i64 %t324, %t323
  br i1 %t326, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s17)
  br label %bb92
bb92:
  %t329 = load i64, ptr %l18, !tbaa !24
  %t331 = add i64 %t329, 1
  store i64 %t331, ptr %l18, !tbaa !24
  br label %bb84
bb93:
  %t333 = load i64, ptr %l15, !tbaa !24
  %t334 = load i64, ptr %l17, !tbaa !24
  %t337 = add i64 %t333, %t334
  store i64 %t337, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb94
bb94:
  br label %bb77
bb95:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/names:Resolver", ptr %t339, i32 0, i32 2
  %t343 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v0, ptr %t341)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t343, ptr %l171
  br label %bb96
bb96:
  %t344 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l171
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t344, ptr %l20
  br label %bb97
bb97:
  store %olang.scope zeroinitializer, ptr %s21
  %t346 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %l20)
  %t347 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t346, 1
  %t348 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t346, 0
  store i32 %t348, ptr %l175
  %t349 = icmp ne i32 %t348, 0
  br i1 %t349, label %bb99, label %ok.350
ok.350:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t347, ptr %l174
  br label %bb98
bb98:
  %t351 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l174
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t351, ptr %l172
  br label %bb103
bb99:
  %t352 = load i32, ptr %l175, !tbaa !23
  %t353 = ashr i32 %t352, 16
  %t355 = icmp eq i32 %t353, 1
  br i1 %t355, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @.c57)
  unreachable
bb102:
  call void @__olang_scope_close(ptr %s21)
  br label %bb110
bb103:
  %t357 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l172
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t357, ptr %l21
  %t358 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t358, ptr %l178, !tbaa !27
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l21, i32 0, i32 0
  %t361 = load i32, ptr %t360, !tbaa !23
  %t364 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t359, i32 %t361)
  store { i64, ptr } %t364, ptr %l181
  br label %bb104
bb104:
  %t365 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t366 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t367 = call i64 @compiler_2fnames_2edistance(ptr %v1, ptr %v0, { i64, ptr } %t365, { i64, ptr } %t366)
  store i64 %t367, ptr %l182
  br label %bb105
bb105:
  %t368 = load i64, ptr %l3, !tbaa !24
  %t369 = load i64, ptr %l182, !tbaa !24
  %t371 = icmp slt i64 %t369, %t368
  br i1 %t371, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s21)
  br label %bb109
bb109:
  br label %bb97
bb110:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etableOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasesOf(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/names:Resolver", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/load:Loader", ptr %t8, i32 0, i32 5
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t10, i64 %t11)
  store ptr %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l9, !tbaa !29
  store ptr %t15, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 8
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } zeroinitializer, 0
  %t23 = icmp eq i64 %t21, %t22
  %t24 = extractvalue { i64, ptr } %t19, 1
  %t25 = extractvalue { i64, ptr } zeroinitializer, 1
  %t26 = icmp eq ptr %t24, %t25
  %t27 = and i1 %t23, %t26
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb3, label %bb4
bb3:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 8
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v0, ptr %t30, i64 %t31, { i64, ptr } %t35)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t7, i32 %a1)
  store { i64, ptr } %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etopConds(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 12
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopIf", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t4, ptr %t8)
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/names:Resolver", ptr %t11, i32 0, i32 12
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp ne ptr %t17, null
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:TopIf", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etopConds(ptr %v0, ptr %v1, ptr %t21, ptr %t25)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca i1
  %l86 = alloca i64
  %l98 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l129 = alloca i64
  %l138 = alloca { i64, ptr }
  %l165 = alloca i64
  %l167 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l169 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l173 = alloca i32
  %l182 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l186 = alloca i32
  %l187 = alloca %"compiler/source:Span"
  %l199 = alloca ptr
  %l200 = alloca i1
  %l212 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l236 = alloca ptr
  %l237 = alloca i1
  %l249 = alloca { i64, ptr }
  %l253 = alloca i64
  %l260 = alloca ptr
  %l261 = alloca i1
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s36 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t7 = extractvalue { i64, ptr } zeroinitializer, 0
  %t8 = icmp eq i64 %t6, %t7
  %t9 = extractvalue { i64, ptr } %t4, 1
  %t10 = extractvalue { i64, ptr } zeroinitializer, 1
  %t11 = icmp eq ptr %t9, %t10
  %t12 = and i1 %t8, %t11
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:TypeDecl", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb14
bb3:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp slt i64 %t24, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l57, !tbaa !27
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 %t33
  %t38 = load ptr, ptr %t37, !tbaa !39
  store ptr %t38, ptr %l5, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TypeParam", ptr %t40, i32 0, i32 2
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp ne ptr %t43, null
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TypeParam", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t47, ptr %t51)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:TypeParam", ptr %t55, i32 0, i32 1
  %t58 = load i32, ptr %t57, !tbaa !23
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TypeParam", ptr %t59, i32 0, i32 0
  %t62 = load %"compiler/source:Span", ptr %t61
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t54, i32 %t58, %"compiler/source:Span" %t62, i32 8)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t67 = load i64, ptr %l3, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l3, !tbaa !24
  br label %bb3
bb13:
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/ast:TypeDecl", ptr %t71, i32 0, i32 3
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = icmp eq ptr %t74, null
  br i1 %t76, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/ast:TypeDecl", ptr %t78, i32 0, i32 3
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l6, !tbaa !29
  %t83 = load ptr, ptr %l6, !tbaa !29
  store ptr %t83, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t84 = load ptr, ptr %l79, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb18, label %bb19
bb18:
  %t87 = load ptr, ptr %l79, !tbaa !29
  %t88 = load i64, ptr %t87
  %t90 = icmp eq i64 %t88, 0
  store i1 %t90, ptr %l80, !tbaa !21
  br label %bb19
bb19:
  %t91 = load i1, ptr %l80, !tbaa !21
  br i1 %t91, label %bb20, label %bb21
bb20:
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = getelementptr { i64, [2 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { ptr }, ptr %t94, i32 0, i32 0
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb87
bb22:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t98)
  store i64 %t100, ptr %l86
  br label %bb23
bb23:
  %t101 = load i64, ptr %l86, !tbaa !24
  store i64 %t101, ptr %l8, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t105 = getelementptr %"compiler/ast:StructBody", ptr %t103, i32 0, i32 5
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeParams(ptr %v0, ptr %v1, ptr %t102, { i64, ptr } %t106)
  br label %bb24
bb24:
  %t109 = load ptr, ptr %l7, !tbaa !29
  %t111 = getelementptr %"compiler/ast:StructBody", ptr %t109, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  store { i64, ptr } %t112, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 0
  store i64 %t116, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s9)
  br label %bb34
bb27:
  br label %bb28
bb28:
  %t126 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t126, ptr %l98, !tbaa !27
  %t127 = load i64, ptr %l10, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t127
  %t132 = load ptr, ptr %t131, !tbaa !39
  store ptr %t132, ptr %l12, !tbaa !29
  %t134 = load ptr, ptr %l12, !tbaa !29
  %t136 = getelementptr %"compiler/ast:Param", ptr %t134, i32 0, i32 2
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = icmp ne ptr %t137, null
  br i1 %t139, label %bb29, label %bb30
bb29:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l12, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Param", ptr %t142, i32 0, i32 2
  %t145 = load ptr, ptr %t144, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t141, ptr %t145)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb33:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l10, !tbaa !24
  br label %bb25
bb34:
  %t152 = load ptr, ptr %l7, !tbaa !29
  %t154 = getelementptr %"compiler/ast:StructBody", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = icmp ne ptr %t155, null
  br i1 %t157, label %bb35, label %bb36
bb35:
  %t159 = load ptr, ptr %l7, !tbaa !29
  %t161 = getelementptr %"compiler/ast:StructBody", ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/ast:Sig", ptr %t162, i32 0, i32 3
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l15, !tbaa !24
  br label %bb37
bb36:
  br label %bb44
bb37:
  store %olang.scope zeroinitializer, ptr %s14
  %t171 = load i64, ptr %l14, !tbaa !24
  %t172 = load i64, ptr %l15, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s14)
  br label %bb43
bb39:
  br label %bb40
bb40:
  %t179 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t179, ptr %l121, !tbaa !27
  %t180 = load i64, ptr %l14, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr ptr, ptr %t183, i64 %t180
  %t185 = load ptr, ptr %t184, !tbaa !39
  %t187 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t187, ptr %t185)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s14)
  br label %bb42
bb42:
  %t191 = load i64, ptr %l14, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l14, !tbaa !24
  br label %bb37
bb43:
  br label %bb44
bb44:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t195)
  store i64 %t197, ptr %l129
  br label %bb45
bb45:
  %t198 = load i64, ptr %l129, !tbaa !24
  store i64 %t198, ptr %l17, !tbaa !24
  %t199 = load ptr, ptr %l7, !tbaa !29
  %t201 = getelementptr %"compiler/ast:StructBody", ptr %t199, i32 0, i32 0
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  store { i64, ptr } %t202, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t204 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 0
  store i64 %t206, ptr %l20, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s17
  %t208 = load i64, ptr %l19, !tbaa !24
  %t209 = load i64, ptr %l20, !tbaa !24
  %t212 = icmp slt i64 %t208, %t209
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s17)
  br label %bb56
bb48:
  br label %bb49
bb49:
  %t216 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t216, ptr %l138, !tbaa !27
  %t217 = load i64, ptr %l19, !tbaa !24
  %t219 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr ptr, ptr %t220, i64 %t217
  %t222 = load ptr, ptr %t221, !tbaa !39
  store ptr %t222, ptr %l21, !tbaa !29
  %t224 = load ptr, ptr %l21, !tbaa !29
  %t226 = getelementptr %"compiler/ast:Param", ptr %t224, i32 0, i32 3
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = icmp ne ptr %t227, null
  br i1 %t229, label %bb50, label %bb51
bb50:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l21, !tbaa !29
  %t234 = getelementptr %"compiler/ast:Param", ptr %t232, i32 0, i32 3
  %t235 = load ptr, ptr %t234, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t231, ptr %t235)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %t238, ptr %t239, i1 true)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s17)
  br label %bb55
bb55:
  %t242 = load i64, ptr %l19, !tbaa !24
  %t244 = add i64 %t242, 1
  store i64 %t244, ptr %l19, !tbaa !24
  br label %bb46
bb56:
  %t246 = load ptr, ptr %l7, !tbaa !29
  %t248 = getelementptr %"compiler/ast:StructBody", ptr %t246, i32 0, i32 2
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = extractvalue { i64, ptr } zeroinitializer, 0
  %t253 = icmp eq i64 %t251, %t252
  %t254 = extractvalue { i64, ptr } %t249, 1
  %t255 = extractvalue { i64, ptr } zeroinitializer, 1
  %t256 = icmp eq ptr %t254, %t255
  %t257 = and i1 %t253, %t256
  %t258 = xor i1 %t257, true
  br i1 %t258, label %bb57, label %bb58
bb57:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l7, !tbaa !29
  %t263 = getelementptr %"compiler/ast:StructBody", ptr %t261, i32 0, i32 2
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t260, { i64, ptr } %t264)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i64, ptr %l17, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t267, i64 %t268)
  br label %bb61
bb61:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t271, i64 %t272)
  br label %bb62
bb62:
  %t275 = load ptr, ptr %l7, !tbaa !29
  %t277 = getelementptr %"compiler/ast:StructBody", ptr %t275, i32 0, i32 4
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = extractvalue { i64, ptr } zeroinitializer, 0
  %t282 = icmp eq i64 %t280, %t281
  %t283 = extractvalue { i64, ptr } %t278, 1
  %t284 = extractvalue { i64, ptr } zeroinitializer, 1
  %t285 = icmp eq ptr %t283, %t284
  %t286 = and i1 %t282, %t285
  %t287 = xor i1 %t286, true
  br i1 %t287, label %bb63, label %bb64
bb63:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t289)
  store i64 %t291, ptr %l165
  br label %bb65
bb64:
  br label %bb86
bb65:
  %t292 = load i64, ptr %l165, !tbaa !24
  store i64 %t292, ptr %l22, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s22
  %t293 = load ptr, ptr %l7, !tbaa !29
  %t295 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fnames_2efieldNames(ptr %v1, ptr %s22, ptr %t293)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t295, ptr %l167
  br label %bb66
bb66:
  %t296 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l167
  %t297 = call ptr @__olang_scope_alloc_a(ptr %s22, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t296, ptr %t297
  store ptr %t297, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s23
  %t299 = load ptr, ptr %l23, !tbaa !29
  %t300 = load i64, ptr %l24, !tbaa !24
  %t303 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %s22, ptr %t299, i64 %t300)
  %t304 = extractvalue { i32, { i64, ptr } } %t303, 1
  %t305 = extractvalue { i32, { i64, ptr } } %t303, 0
  store i32 %t305, ptr %l173
  %t306 = icmp ne i32 %t305, 0
  br i1 %t306, label %bb69, label %ok.307
ok.307:
  store { i64, ptr } %t304, ptr %l172
  br label %bb68
bb68:
  %t308 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t308, ptr %l169, !tbaa !27
  br label %bb73
bb69:
  %t309 = load i32, ptr %l173, !tbaa !23
  %t310 = ashr i32 %t309, 16
  %t312 = icmp eq i32 %t310, 1
  br i1 %t312, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @.c58)
  unreachable
bb72:
  call void @__olang_scope_close(ptr %s23)
  br label %bb83
bb73:
  %t314 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t314, ptr %l25, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t315, 0
  store i64 %t317, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s24
  %t319 = load i64, ptr %l27, !tbaa !24
  %t320 = load i64, ptr %l26, !tbaa !24
  %t323 = icmp slt i64 %t319, %t320
  %t325 = xor i1 %t323, true
  br i1 %t325, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s24)
  br label %bb81
bb76:
  br label %bb77
bb77:
  %t327 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t327, ptr %l182, !tbaa !27
  %t328 = load i64, ptr %l27, !tbaa !24
  %t330 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr i32, ptr %t331, i64 %t328
  %t333 = load i32, ptr %t332, !tbaa !33
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l185, !tbaa !29
  store i32 %t333, ptr %l186, !tbaa !23
  %t337 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s24, i32 0, i32 0)
  store %"compiler/source:Span" %t337, ptr %l187
  br label %bb78
bb78:
  %t338 = load ptr, ptr %l185, !tbaa !29
  %t339 = load i32, ptr %l186, !tbaa !23
  %t340 = load %"compiler/source:Span", ptr %l187
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t338, i32 %t339, %"compiler/source:Span" %t340, i32 1)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s24)
  br label %bb80
bb80:
  %t342 = load i64, ptr %l27, !tbaa !24
  %t344 = add i64 %t342, 1
  store i64 %t344, ptr %l27, !tbaa !24
  br label %bb74
bb81:
  %t346 = load i64, ptr %l24, !tbaa !24
  %t347 = load i64, ptr %l26, !tbaa !24
  %t350 = add i64 %t346, %t347
  store i64 %t350, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb82
bb82:
  br label %bb67
bb83:
  call void @__olang_scope_close(ptr %s22)
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l7, !tbaa !29
  %t355 = getelementptr %"compiler/ast:StructBody", ptr %t353, i32 0, i32 4
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t352, { i64, ptr } %t356)
  br label %bb84
bb84:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i64, ptr %l22, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t359, i64 %t360)
  br label %bb85
bb85:
  br label %bb86
bb86:
  br label %bb136
bb87:
  %t363 = load ptr, ptr %l6, !tbaa !29
  store ptr %t363, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t364 = load ptr, ptr %l199, !tbaa !29
  %t365 = icmp ne ptr %t364, null
  br i1 %t365, label %bb88, label %bb89
bb88:
  %t367 = load ptr, ptr %l199, !tbaa !29
  %t368 = load i64, ptr %t367
  %t370 = icmp eq i64 %t368, 1
  store i1 %t370, ptr %l200, !tbaa !21
  br label %bb89
bb89:
  %t371 = load i1, ptr %l200, !tbaa !21
  br i1 %t371, label %bb90, label %bb91
bb90:
  %t372 = load ptr, ptr %l6, !tbaa !29
  %t374 = getelementptr { i64, [2 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { { i64, ptr } }, ptr %t374, i32 0, i32 0
  %t376 = load { i64, ptr }, ptr %t375
  store { i64, ptr } %t376, ptr %l29, !tbaa !27
  br label %bb92
bb91:
  br label %bb109
bb92:
  %t378 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t378, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t380 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t380, 0
  store i64 %t382, ptr %l32, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s28
  %t384 = load i64, ptr %l31, !tbaa !24
  %t385 = load i64, ptr %l32, !tbaa !24
  %t388 = icmp slt i64 %t384, %t385
  %t390 = xor i1 %t388, true
  br i1 %t390, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s28)
  br label %bb108
bb95:
  br label %bb96
bb96:
  %t392 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t392, ptr %l212, !tbaa !27
  %t393 = load i64, ptr %l31, !tbaa !24
  %t395 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !27
  %t397 = getelementptr ptr, ptr %t396, i64 %t393
  %t398 = load ptr, ptr %t397, !tbaa !39
  %t402 = getelementptr %"compiler/ast:CaseDecl", ptr %t398, i32 0, i32 2
  %t403 = load { i64, ptr }, ptr %t402, !tbaa !27
  store { i64, ptr } %t403, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t405 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t405, 0
  store i64 %t407, ptr %l36, !tbaa !24
  br label %bb97
bb97:
  store %olang.scope zeroinitializer, ptr %s30
  %t409 = load i64, ptr %l35, !tbaa !24
  %t410 = load i64, ptr %l36, !tbaa !24
  %t413 = icmp slt i64 %t409, %t410
  %t415 = xor i1 %t413, true
  br i1 %t415, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s30)
  br label %bb106
bb99:
  br label %bb100
bb100:
  %t417 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t417, ptr %l223, !tbaa !27
  %t418 = load i64, ptr %l35, !tbaa !24
  %t420 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr ptr, ptr %t421, i64 %t418
  %t423 = load ptr, ptr %t422, !tbaa !39
  store ptr %t423, ptr %l37, !tbaa !29
  %t425 = load ptr, ptr %l37, !tbaa !29
  %t427 = getelementptr %"compiler/ast:Param", ptr %t425, i32 0, i32 2
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t430 = icmp ne ptr %t428, null
  br i1 %t430, label %bb101, label %bb102
bb101:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load ptr, ptr %l37, !tbaa !29
  %t435 = getelementptr %"compiler/ast:Param", ptr %t433, i32 0, i32 2
  %t436 = load ptr, ptr %t435, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t432, ptr %t436)
  br label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s30)
  br label %bb105
bb105:
  %t439 = load i64, ptr %l35, !tbaa !24
  %t441 = add i64 %t439, 1
  store i64 %t441, ptr %l35, !tbaa !24
  br label %bb97
bb106:
  call void @__olang_scope_close(ptr %s28)
  br label %bb107
bb107:
  %t443 = load i64, ptr %l31, !tbaa !24
  %t445 = add i64 %t443, 1
  store i64 %t445, ptr %l31, !tbaa !24
  br label %bb93
bb108:
  br label %bb136
bb109:
  %t447 = load ptr, ptr %l6, !tbaa !29
  store ptr %t447, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t448 = load ptr, ptr %l236, !tbaa !29
  %t449 = icmp ne ptr %t448, null
  br i1 %t449, label %bb110, label %bb111
bb110:
  %t451 = load ptr, ptr %l236, !tbaa !29
  %t452 = load i64, ptr %t451
  %t454 = icmp eq i64 %t452, 2
  store i1 %t454, ptr %l237, !tbaa !21
  br label %bb111
bb111:
  %t455 = load i1, ptr %l237, !tbaa !21
  br i1 %t455, label %bb112, label %bb113
bb112:
  %t456 = load ptr, ptr %l6, !tbaa !29
  %t458 = getelementptr { i64, [2 x i64] }, ptr %t456, i32 0, i32 1
  %t459 = getelementptr { { i64, ptr } }, ptr %t458, i32 0, i32 0
  %t460 = load { i64, ptr }, ptr %t459
  store { i64, ptr } %t460, ptr %l38, !tbaa !27
  br label %bb114
bb113:
  br label %bb124
bb114:
  %t462 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t462, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t464 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t464, 0
  store i64 %t466, ptr %l41, !tbaa !24
  br label %bb115
bb115:
  store %olang.scope zeroinitializer, ptr %s36
  %t468 = load i64, ptr %l40, !tbaa !24
  %t469 = load i64, ptr %l41, !tbaa !24
  %t472 = icmp slt i64 %t468, %t469
  %t474 = xor i1 %t472, true
  br i1 %t474, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s36)
  br label %bb123
bb117:
  br label %bb118
bb118:
  %t476 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t476, ptr %l249, !tbaa !27
  %t477 = load i64, ptr %l40, !tbaa !24
  %t479 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t480 = load ptr, ptr %t479, !tbaa !27
  %t481 = getelementptr ptr, ptr %t480, i64 %t477
  %t482 = load ptr, ptr %t481, !tbaa !39
  store ptr %t482, ptr %l42, !tbaa !29
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t486 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t484)
  store i64 %t486, ptr %l253
  br label %bb119
bb119:
  %t487 = load i64, ptr %l253, !tbaa !24
  store i64 %t487, ptr %l43, !tbaa !24
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t488, ptr %t489, i1 false)
  br label %bb120
bb120:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load i64, ptr %l43, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t492, i64 %t493)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s36)
  br label %bb122
bb122:
  %t496 = load i64, ptr %l40, !tbaa !24
  %t498 = add i64 %t496, 1
  store i64 %t498, ptr %l40, !tbaa !24
  br label %bb115
bb123:
  br label %bb136
bb124:
  %t500 = load ptr, ptr %l6, !tbaa !29
  store ptr %t500, ptr %l260, !tbaa !29
  store i1 false, ptr %l261, !tbaa !21
  %t501 = load ptr, ptr %l260, !tbaa !29
  %t502 = icmp ne ptr %t501, null
  br i1 %t502, label %bb125, label %bb126
bb125:
  %t504 = load ptr, ptr %l260, !tbaa !29
  %t505 = load i64, ptr %t504
  %t507 = icmp eq i64 %t505, 3
  store i1 %t507, ptr %l261, !tbaa !21
  br label %bb126
bb126:
  %t508 = load i1, ptr %l261, !tbaa !21
  br i1 %t508, label %bb127, label %bb128
bb127:
  %t509 = load ptr, ptr %l6, !tbaa !29
  %t511 = getelementptr { i64, [2 x i64] }, ptr %t509, i32 0, i32 1
  %t512 = getelementptr { ptr, ptr }, ptr %t511, i32 0, i32 0
  %t513 = load ptr, ptr %t512
  store ptr %t513, ptr %l44, !tbaa !29
  %t515 = load ptr, ptr %l6, !tbaa !29
  %t517 = getelementptr { i64, [2 x i64] }, ptr %t515, i32 0, i32 1
  %t518 = getelementptr { ptr, ptr }, ptr %t517, i32 0, i32 1
  %t519 = load ptr, ptr %t518
  store ptr %t519, ptr %l45, !tbaa !29
  br label %bb129
bb128:
  br label %bb135
bb129:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t521, ptr %t522)
  br label %bb130
bb130:
  %t525 = load ptr, ptr %l45, !tbaa !29
  %t527 = icmp ne ptr %t525, null
  br i1 %t527, label %bb131, label %bb132
bb131:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efunc(ptr %v0, ptr %v1, ptr %t529, ptr %t530)
  br label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb134
bb134:
  br label %bb136
bb135:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb136:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i32
  %l20 = alloca %"compiler/names:Ref"
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i64
  %l31 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i32
  %l41 = alloca %"compiler/names:Ref"
  %l44 = alloca { i64, ptr }
  %l45 = alloca i1
  %l47 = alloca %"compiler/names:Ref"
  %l49 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/names:Table", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t10, i32 %t11)
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l14
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18
ok.18:
  store i64 %t15, ptr %l13
  br label %bb2
bb2:
  %t19 = load i64, ptr %l13, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load i64, ptr %l1, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t30 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s1, i32 4, i64 %t25, i64 %t26)
  store %"compiler/names:Ref" %t30, ptr %l20
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/names:Ref", ptr %l20
  store %"compiler/names:Ref" %t31, ptr %rv
  br label %ret
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/names:Resolver", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t34, i32 %t35)
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l26
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb11, label %ok.42
ok.42:
  store i64 %t39, ptr %l25
  br label %bb10
bb10:
  %t43 = load i64, ptr %l25, !tbaa !24
  store i64 %t43, ptr %l21, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb13
bb13:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 4, ptr %l29
  %t49 = load i64, ptr %l4, !tbaa !24
  store i64 %t49, ptr %l30, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/names:Resolver", ptr %t50, i32 0, i32 1
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t52, i64 %t53)
  store ptr %t56, ptr %l35
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t59 = getelementptr %"compiler/names:Table", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t59, i32 %t60)
  %t64 = extractvalue { i32, i64 } %t63, 1
  %t65 = extractvalue { i32, i64 } %t63, 0
  store i32 %t65, ptr %l40
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb18, label %ok.67
ok.67:
  store i64 %t64, ptr %l39
  br label %bb17
bb17:
  %t68 = load i64, ptr %l39, !tbaa !24
  store i64 %t68, ptr %l31, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  store i64 -1, ptr %l31, !tbaa !24
  br label %bb20
bb20:
  %t69 = load i32, ptr %l29
  %t70 = load i64, ptr %l30, !tbaa !24
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 %t69, i64 %t70, i64 %t71)
  store %"compiler/names:Ref" %t72, ptr %l41
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t73 = load %"compiler/names:Ref", ptr %l41
  store %"compiler/names:Ref" %t73, ptr %rv
  br label %ret
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t74, i32 %t75)
  store { i64, ptr } %t78, ptr %l44
  br label %bb23
bb23:
  %t79 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t80 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t79)
  store i1 %t80, ptr %l45
  br label %bb24
bb24:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s3, i32 7, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t83, ptr %l47
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t84 = load %"compiler/names:Ref", ptr %l47
  store %"compiler/names:Ref" %t84, ptr %rv
  br label %ret
bb28:
  %t86 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t86, ptr %l49
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load %"compiler/names:Ref", ptr %l49
  store %"compiler/names:Ref" %t87, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeParams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Span"
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l40 = alloca i64
  %l43 = alloca i64
  %l45 = alloca %"compiler/names:Ref"
  %l55 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = extractvalue { i64, ptr } zeroinitializer, 0
  %t5 = icmp eq i64 %t3, %t4
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } zeroinitializer, 1
  %t8 = icmp eq ptr %t6, %t7
  %t9 = and i1 %t5, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l20, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l5, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/names:Resolver", ptr %t34, i32 0, i32 6
  %t37 = load i64, ptr %t36, !tbaa !24
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr %"compiler/ast:TypeParam", ptr %t38, i32 0, i32 0
  %t41 = getelementptr %"compiler/source:Span", ptr %t40, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TypeParam", ptr %t43, i32 0, i32 1
  %t46 = load i32, ptr %t45, !tbaa !23
  %t51 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t33, i64 %t37, i32 %t42, i32 %t46)
  store %"compiler/source:Span" %t51, ptr %l30
  br label %bb8
bb8:
  %t52 = load %"compiler/source:Span", ptr %l30
  store %"compiler/source:Span" %t52, ptr %l6
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t56 = getelementptr %"compiler/ast:TypeParam", ptr %t54, i32 0, i32 1
  %t57 = load i32, ptr %t56, !tbaa !23
  %t58 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t53, i32 %t57, %"compiler/source:Span" %t58, i32 8)
  br label %bb9
bb9:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l36, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t64, ptr %l37
  store i32 8, ptr %l38
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/names:Resolver", ptr %t65, i32 0, i32 6
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l40, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 7
  %t73 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l43
  br label %bb10
bb10:
  %t74 = load i64, ptr %l43, !tbaa !24
  %t75 = sub i64 %t74, 1
  %t76 = load i32, ptr %l38
  %t77 = load i64, ptr %l40, !tbaa !24
  %t79 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s3, i32 %t76, i64 %t77, i64 %t75)
  store %"compiler/names:Ref" %t79, ptr %l45
  br label %bb11
bb11:
  %t80 = load ptr, ptr %l36, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l37
  %t82 = load %"compiler/names:Ref", ptr %l45
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t80, %"compiler/source:Span" %t81, %"compiler/names:Ref" %t82)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t83 = load i64, ptr %l3, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l3, !tbaa !24
  br label %bb4
bb14:
  %t87 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t87, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t101 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t101, ptr %l55, !tbaa !27
  %t102 = load i64, ptr %l8, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr ptr, ptr %t105, i64 %t102
  %t107 = load ptr, ptr %t106, !tbaa !39
  store ptr %t107, ptr %l10, !tbaa !29
  %t109 = load ptr, ptr %l10, !tbaa !29
  %t111 = getelementptr %"compiler/ast:TypeParam", ptr %t109, i32 0, i32 2
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp ne ptr %t112, null
  br i1 %t114, label %bb19, label %bb20
bb19:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l10, !tbaa !29
  %t119 = getelementptr %"compiler/ast:TypeParam", ptr %t117, i32 0, i32 2
  %t120 = load ptr, ptr %t119, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t116, ptr %t120)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb23
bb23:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l8, !tbaa !24
  br label %bb15
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypePath(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/names:Ref"
  %l12 = alloca { i64, ptr }
  %l14 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l22 = alloca i1
  %l26 = alloca %"compiler/names:local"
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l38 = alloca %"compiler/names:Ref"
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l45 = alloca %"compiler/names:Ref"
  %l46 = alloca { i64, ptr }
  %l48 = alloca i64
  %l53 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i32
  %l60 = alloca i1
  %l63 = alloca %"compiler/names:Ref"
  %l64 = alloca i32
  %l66 = alloca i32
  %l68 = alloca i1
  %l69 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l79 = alloca i64
  %l82 = alloca { i64, ptr }
  %l90 = alloca %"compiler/names:Ref"
  %l91 = alloca ptr
  %l92 = alloca i64
  %l93 = alloca %"compiler/names:Ref"
  %l94 = alloca i32
  %l95 = alloca i32
  %l98 = alloca { i64, ptr }
  %l103 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l12, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i32, ptr %t9, i64 0
  %t11 = load i32, ptr %t10, !tbaa !33
  store i32 %t11, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/names:Resolver", ptr %t13, i32 0, i32 8
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t15, i32 %t16)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l19
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb4, label %ok.23
ok.23:
  store i64 %t20, ptr %l18
  br label %bb3
bb2:
  br label %bb19
bb3:
  %t24 = load i64, ptr %l18, !tbaa !24
  store i64 %t24, ptr %l14, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l14, !tbaa !24
  store i64 %t25, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 7
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = call %"compiler/names:local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t32, i64 %t33)
  store %"compiler/names:local" %t36, ptr %l26
  br label %bb9
bb8:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb9:
  %t37 = getelementptr %"compiler/names:local", ptr %l26, i32 0, i32 2
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l27
  store i32 8, ptr %l29
  %t41 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l27, ptr %l29)
  store i1 %t41, ptr %l31
  br label %bb10
bb10:
  %t42 = load i1, ptr %l31, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l32, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t45, ptr %l33
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/names:Resolver", ptr %t46, i32 0, i32 6
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t54 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 8, i64 %t49, i64 %t50)
  store %"compiler/names:Ref" %t54, ptr %l38
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l33
  %t57 = load %"compiler/names:Ref", ptr %l38
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t55, %"compiler/source:Span" %t56, %"compiler/names:Ref" %t57)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l39, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t59, ptr %l40
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/names:Resolver", ptr %t61, i32 0, i32 6
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = load i32, ptr %l3, !tbaa !23
  %t69 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeIn(ptr %v0, ptr %t60, i64 %t64, i32 %t65)
  store %"compiler/names:Ref" %t69, ptr %l45
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l39, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l40
  %t72 = load %"compiler/names:Ref", ptr %l45
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t70, %"compiler/source:Span" %t71, %"compiler/names:Ref" %t72)
  br label %bb18
bb18:
  br label %ret
bb19:
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t73, ptr %l46, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 0
  %t77 = load i32, ptr %t76, !tbaa !33
  store i32 %t77, ptr %l5, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/names:Resolver", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/names:Resolver", ptr %t82, i32 0, i32 6
  %t85 = load i64, ptr %t84, !tbaa !24
  %t88 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t81, i64 %t85)
  store ptr %t88, ptr %l53
  br label %bb20
bb20:
  %t89 = load ptr, ptr %l53, !tbaa !29
  %t91 = getelementptr %"compiler/names:Table", ptr %t89, i32 0, i32 3
  %t92 = load i32, ptr %l5, !tbaa !23
  %t95 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t91, i32 %t92)
  %t96 = extractvalue { i32, i64 } %t95, 1
  %t97 = extractvalue { i32, i64 } %t95, 0
  store i32 %t97, ptr %l58
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb22, label %ok.99
ok.99:
  store i64 %t96, ptr %l57
  br label %bb21
bb21:
  %t100 = load i64, ptr %l57, !tbaa !24
  store i64 %t100, ptr %l48, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  store i64 -1, ptr %l48, !tbaa !24
  br label %bb24
bb24:
  %t101 = load i64, ptr %l48, !tbaa !24
  %t102 = icmp slt i64 %t101, 0
  br i1 %t102, label %bb25, label %bb26
bb25:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l5, !tbaa !23
  %t108 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t104, i32 %t105)
  store %"compiler/names:Ref" %t108, ptr %l63
  br label %bb27
bb26:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb29
bb27:
  %t109 = getelementptr %"compiler/names:Ref", ptr %l63, i32 0, i32 0
  %t110 = load i32, ptr %t109
  store i32 %t110, ptr %l64
  store i32 0, ptr %l66
  %t113 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %l64, ptr %l66)
  store i1 %t113, ptr %l68
  br label %bb28
bb28:
  %t114 = load i1, ptr %l68, !tbaa !21
  store i1 %t114, ptr %l60, !tbaa !21
  br label %bb29
bb29:
  %t115 = load i1, ptr %l60, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l69, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/names:Resolver", ptr %t118, i32 0, i32 6
  %t121 = load i64, ptr %t120, !tbaa !24
  %t122 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t123 = load i32, ptr %t122, !tbaa !23
  %t124 = load i32, ptr %l5, !tbaa !23
  %t129 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t117, i64 %t121, i32 %t123, i32 %t124)
  store %"compiler/source:Span" %t129, ptr %l75
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t130 = load i32, ptr %l5, !tbaa !23
  %t131 = load ptr, ptr %l69, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l75
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %t131, %"compiler/source:Span" %t132, i32 %t130)
  br label %bb33
bb33:
  br label %ret
bb34:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t138 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasModule(ptr %v0, ptr %v1, ptr %t134, { i64, ptr } %t135)
  store i64 %t138, ptr %l79
  br label %bb35
bb35:
  %t139 = load i64, ptr %l79, !tbaa !24
  store i64 %t139, ptr %l6, !tbaa !24
  %t140 = load i64, ptr %l6, !tbaa !24
  %t142 = icmp sge i64 %t140, 0
  br i1 %t142, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t144 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t144, ptr %l82, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t149 = sub i64 %t147, 1
  %t151 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i32, ptr %t152, i64 %t149
  %t154 = load i32, ptr %t153, !tbaa !33
  store i32 %t154, ptr %l7, !tbaa !23
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i64, ptr %l6, !tbaa !24
  %t158 = load i32, ptr %l7, !tbaa !23
  %t162 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ememberOf(ptr %v0, ptr %t156, i64 %t157, i32 %t158)
  store %"compiler/names:Ref" %t162, ptr %l90
  br label %bb38
bb37:
  br label %bb43
bb38:
  %t163 = load %"compiler/names:Ref", ptr %l90
  store %"compiler/names:Ref" %t163, ptr %l8
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l91, !tbaa !29
  %t165 = load i64, ptr %l6, !tbaa !24
  store i64 %t165, ptr %l92, !tbaa !24
  %t166 = load %"compiler/names:Ref", ptr %l8
  store %"compiler/names:Ref" %t166, ptr %l93
  %t167 = load i32, ptr %l7, !tbaa !23
  store i32 %t167, ptr %l94, !tbaa !23
  %t168 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t169 = load i32, ptr %t168, !tbaa !23
  store i32 %t169, ptr %l95, !tbaa !23
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l7, !tbaa !23
  %t174 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t170, i32 %t171)
  store { i64, ptr } %t174, ptr %l98
  br label %bb39
bb39:
  %t175 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t178 = trunc i64 %t176 to i32
  %t179 = load i32, ptr %l95, !tbaa !23
  %t181 = sub i32 %t179, %t178
  %t182 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t183 = load i32, ptr %t182, !tbaa !23
  %t186 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t181, i32 %t183)
  store %"compiler/source:Span" %t186, ptr %l103
  br label %bb40
bb40:
  %t187 = load ptr, ptr %l91, !tbaa !29
  %t188 = load i64, ptr %l92, !tbaa !24
  %t189 = load %"compiler/names:Ref", ptr %l93
  %t190 = load i32, ptr %l94, !tbaa !23
  %t191 = load %"compiler/source:Span", ptr %l103
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enotPrivate(ptr %v0, ptr %t187, i64 %t188, %"compiler/names:Ref" %t189, i32 %t190, %"compiler/source:Span" %t191)
  br label %bb41
bb41:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l1
  %t194 = load %"compiler/names:Ref", ptr %l8
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t192, %"compiler/source:Span" %t193, %"compiler/names:Ref" %t194)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i1
  %l63 = alloca i64
  %l66 = alloca i64
  %l85 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca i1
  %l104 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l146 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca i1
  %l164 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l189 = alloca i1
  %l202 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l214 = alloca i1
  %l227 = alloca i1
  %l230 = alloca { i64, ptr }
  %l231 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca ptr
  %l236 = alloca i64
  %l238 = alloca %"compiler/source:Span"
  %l241 = alloca %"compiler/source:Span"
  %l244 = alloca %"compiler/names:Ref"
  %l245 = alloca ptr
  %l246 = alloca i1
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s32 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t6 = load ptr, ptr %l45, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l45, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l46, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l46, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t28, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  br label %bb8
bb7:
  br label %bb23
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l2
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypePath(ptr %v0, ptr %v1, ptr %t32, %"compiler/source:Span" %t33, { i64, ptr } %t34)
  br label %bb9
bb9:
  store i64 0, ptr %l5, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb15
bb12:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l66, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb14
bb14:
  %t68 = load i64, ptr %l66, !tbaa !24
  store i64 %t68, ptr %l63, !tbaa !24
  br label %bb15
bb15:
  %t69 = load i64, ptr %l63, !tbaa !24
  store i64 %t69, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t89, ptr %l85, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr ptr, ptr %t93, i64 %t86
  %t95 = load ptr, ptr %t94, !tbaa !39
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t88, ptr %t95)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t98 = load i64, ptr %l9, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l9, !tbaa !24
  br label %bb16
bb22:
  br label %bb125
bb23:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t103 = load ptr, ptr %l90, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb24, label %bb25
bb24:
  %t106 = load ptr, ptr %l90, !tbaa !29
  %t107 = load i64, ptr %t106
  %t109 = icmp eq i64 %t107, 1
  store i1 %t109, ptr %l91, !tbaa !21
  br label %bb25
bb25:
  %t110 = load i1, ptr %l91, !tbaa !21
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", ptr }, ptr %t113, i32 0, i32 1
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l11, !tbaa !29
  br label %bb28
bb27:
  br label %bb53
bb28:
  %t117 = load ptr, ptr %l11, !tbaa !29
  %t119 = getelementptr %"compiler/ast:Sig", ptr %t117, i32 0, i32 0
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  store i64 %t124, ptr %l14, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  %t126 = load i64, ptr %l13, !tbaa !24
  %t127 = load i64, ptr %l14, !tbaa !24
  %t130 = icmp slt i64 %t126, %t127
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t134 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t134, ptr %l104, !tbaa !27
  %t135 = load i64, ptr %l13, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr ptr, ptr %t138, i64 %t135
  %t140 = load ptr, ptr %t139, !tbaa !39
  store ptr %t140, ptr %l15, !tbaa !29
  %t142 = load ptr, ptr %l15, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Param", ptr %t142, i32 0, i32 2
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = icmp ne ptr %t145, null
  br i1 %t147, label %bb33, label %bb34
bb33:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l15, !tbaa !29
  %t152 = getelementptr %"compiler/ast:Param", ptr %t150, i32 0, i32 2
  %t153 = load ptr, ptr %t152, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t149, ptr %t153)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb37
bb37:
  %t156 = load i64, ptr %l13, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l13, !tbaa !24
  br label %bb29
bb38:
  %t160 = load ptr, ptr %l11, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Sig", ptr %t160, i32 0, i32 1
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l18, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s12
  %t169 = load i64, ptr %l17, !tbaa !24
  %t170 = load i64, ptr %l18, !tbaa !24
  %t173 = icmp slt i64 %t169, %t170
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s12)
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t177 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t177, ptr %l123, !tbaa !27
  %t178 = load i64, ptr %l17, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr ptr, ptr %t181, i64 %t178
  %t183 = load ptr, ptr %t182, !tbaa !39
  %t185 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t185, ptr %t183)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s12)
  br label %bb44
bb44:
  %t189 = load i64, ptr %l17, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l17, !tbaa !24
  br label %bb39
bb45:
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t195 = getelementptr %"compiler/ast:Sig", ptr %t193, i32 0, i32 3
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  store { i64, ptr } %t196, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t198 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t198, 0
  store i64 %t200, ptr %l22, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s15
  %t202 = load i64, ptr %l21, !tbaa !24
  %t203 = load i64, ptr %l22, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s15)
  br label %bb52
bb48:
  br label %bb49
bb49:
  %t210 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t210, ptr %l138, !tbaa !27
  %t211 = load i64, ptr %l21, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr ptr, ptr %t214, i64 %t211
  %t216 = load ptr, ptr %t215, !tbaa !39
  %t218 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t218, ptr %t216)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s15)
  br label %bb51
bb51:
  %t222 = load i64, ptr %l21, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l21, !tbaa !24
  br label %bb46
bb52:
  br label %bb125
bb53:
  %t226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t226, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t227 = load ptr, ptr %l145, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb54, label %bb55
bb54:
  %t230 = load ptr, ptr %l145, !tbaa !29
  %t231 = load i64, ptr %t230
  %t233 = icmp eq i64 %t231, 2
  store i1 %t233, ptr %l146, !tbaa !21
  br label %bb55
bb55:
  %t234 = load i1, ptr %l146, !tbaa !21
  br i1 %t234, label %bb56, label %bb57
bb56:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr { i64, [5 x i64] }, ptr %t235, i32 0, i32 1
  %t238 = getelementptr { %"compiler/source:Span", ptr }, ptr %t237, i32 0, i32 1
  %t239 = load ptr, ptr %t238
  store ptr %t239, ptr %l24, !tbaa !29
  br label %bb58
bb57:
  br label %bb98
bb58:
  %t241 = load ptr, ptr %l24, !tbaa !29
  store ptr %t241, ptr %l151, !tbaa !29
  store i1 false, ptr %l152, !tbaa !21
  %t242 = load ptr, ptr %l151, !tbaa !29
  %t243 = icmp ne ptr %t242, null
  br i1 %t243, label %bb59, label %bb60
bb59:
  %t245 = load ptr, ptr %l151, !tbaa !29
  %t246 = load i64, ptr %t245
  %t248 = icmp eq i64 %t246, 1
  store i1 %t248, ptr %l152, !tbaa !21
  br label %bb60
bb60:
  %t249 = load i1, ptr %l152, !tbaa !21
  br i1 %t249, label %bb61, label %bb62
bb61:
  %t250 = load ptr, ptr %l24, !tbaa !29
  %t252 = getelementptr { i64, [2 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { { i64, ptr } }, ptr %t252, i32 0, i32 0
  %t254 = load { i64, ptr }, ptr %t253
  store { i64, ptr } %t254, ptr %l25, !tbaa !27
  br label %bb63
bb62:
  br label %bb80
bb63:
  %t256 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t256, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t258 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 0
  store i64 %t260, ptr %l28, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s20
  %t262 = load i64, ptr %l27, !tbaa !24
  %t263 = load i64, ptr %l28, !tbaa !24
  %t266 = icmp slt i64 %t262, %t263
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s20)
  br label %bb79
bb66:
  br label %bb67
bb67:
  %t270 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t270, ptr %l164, !tbaa !27
  %t271 = load i64, ptr %l27, !tbaa !24
  %t273 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = getelementptr ptr, ptr %t274, i64 %t271
  %t276 = load ptr, ptr %t275, !tbaa !39
  %t280 = getelementptr %"compiler/ast:CaseDecl", ptr %t276, i32 0, i32 2
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !27
  store { i64, ptr } %t281, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t283 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t283, 0
  store i64 %t285, ptr %l32, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s22
  %t287 = load i64, ptr %l31, !tbaa !24
  %t288 = load i64, ptr %l32, !tbaa !24
  %t291 = icmp slt i64 %t287, %t288
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s22)
  br label %bb77
bb70:
  br label %bb71
bb71:
  %t295 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t295, ptr %l175, !tbaa !27
  %t296 = load i64, ptr %l31, !tbaa !24
  %t298 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr ptr, ptr %t299, i64 %t296
  %t301 = load ptr, ptr %t300, !tbaa !39
  store ptr %t301, ptr %l33, !tbaa !29
  %t303 = load ptr, ptr %l33, !tbaa !29
  %t305 = getelementptr %"compiler/ast:Param", ptr %t303, i32 0, i32 2
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = icmp ne ptr %t306, null
  br i1 %t308, label %bb72, label %bb73
bb72:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load ptr, ptr %l33, !tbaa !29
  %t313 = getelementptr %"compiler/ast:Param", ptr %t311, i32 0, i32 2
  %t314 = load ptr, ptr %t313, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t310, ptr %t314)
  br label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s22)
  br label %bb76
bb76:
  %t317 = load i64, ptr %l31, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l31, !tbaa !24
  br label %bb68
bb77:
  call void @__olang_scope_close(ptr %s20)
  br label %bb78
bb78:
  %t321 = load i64, ptr %l27, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l27, !tbaa !24
  br label %bb64
bb79:
  br label %bb97
bb80:
  %t325 = load ptr, ptr %l24, !tbaa !29
  store ptr %t325, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t326 = load ptr, ptr %l188, !tbaa !29
  %t327 = icmp ne ptr %t326, null
  br i1 %t327, label %bb81, label %bb82
bb81:
  %t329 = load ptr, ptr %l188, !tbaa !29
  %t330 = load i64, ptr %t329
  %t332 = icmp eq i64 %t330, 0
  store i1 %t332, ptr %l189, !tbaa !21
  br label %bb82
bb82:
  %t333 = load i1, ptr %l189, !tbaa !21
  br i1 %t333, label %bb83, label %bb84
bb83:
  %t334 = load ptr, ptr %l24, !tbaa !29
  %t336 = getelementptr { i64, [2 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { ptr }, ptr %t336, i32 0, i32 0
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l34, !tbaa !29
  br label %bb85
bb84:
  br label %bb96
bb85:
  %t340 = load ptr, ptr %l34, !tbaa !29
  %t342 = getelementptr %"compiler/ast:StructBody", ptr %t340, i32 0, i32 0
  %t343 = load { i64, ptr }, ptr %t342, !tbaa !27
  store { i64, ptr } %t343, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t345 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t345, 0
  store i64 %t347, ptr %l37, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s28
  %t349 = load i64, ptr %l36, !tbaa !24
  %t350 = load i64, ptr %l37, !tbaa !24
  %t353 = icmp slt i64 %t349, %t350
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s28)
  br label %bb95
bb88:
  br label %bb89
bb89:
  %t357 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t357, ptr %l202, !tbaa !27
  %t358 = load i64, ptr %l36, !tbaa !24
  %t360 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr ptr, ptr %t361, i64 %t358
  %t363 = load ptr, ptr %t362, !tbaa !39
  store ptr %t363, ptr %l38, !tbaa !29
  %t365 = load ptr, ptr %l38, !tbaa !29
  %t367 = getelementptr %"compiler/ast:Param", ptr %t365, i32 0, i32 2
  %t368 = load ptr, ptr %t367, !tbaa !29
  %t370 = icmp ne ptr %t368, null
  br i1 %t370, label %bb90, label %bb91
bb90:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load ptr, ptr %l38, !tbaa !29
  %t375 = getelementptr %"compiler/ast:Param", ptr %t373, i32 0, i32 2
  %t376 = load ptr, ptr %t375, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t372, ptr %t376)
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s28)
  br label %bb94
bb94:
  %t379 = load i64, ptr %l36, !tbaa !24
  %t381 = add i64 %t379, 1
  store i64 %t381, ptr %l36, !tbaa !24
  br label %bb86
bb95:
  br label %bb97
bb96:
  br label %bb97
bb97:
  br label %bb125
bb98:
  %t383 = load ptr, ptr %l1, !tbaa !29
  store ptr %t383, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t384 = load ptr, ptr %l213, !tbaa !29
  %t385 = icmp ne ptr %t384, null
  br i1 %t385, label %bb99, label %bb100
bb99:
  %t387 = load ptr, ptr %l213, !tbaa !29
  %t388 = load i64, ptr %t387
  %t390 = icmp eq i64 %t388, 3
  store i1 %t390, ptr %l214, !tbaa !21
  br label %bb100
bb100:
  %t391 = load i1, ptr %l214, !tbaa !21
  br i1 %t391, label %bb101, label %bb102
bb101:
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t394 = getelementptr { i64, [5 x i64] }, ptr %t392, i32 0, i32 1
  %t395 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t394, i32 0, i32 0
  %t396 = load %"compiler/source:Span", ptr %t395
  store %"compiler/source:Span" %t396, ptr %l39
  %t398 = load ptr, ptr %l1, !tbaa !29
  %t400 = getelementptr { i64, [5 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t400, i32 0, i32 1
  %t402 = load ptr, ptr %t401
  store ptr %t402, ptr %l40, !tbaa !29
  %t404 = load ptr, ptr %l1, !tbaa !29
  %t406 = getelementptr { i64, [5 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t406, i32 0, i32 2
  %t408 = load i32, ptr %t407
  store i32 %t408, ptr %l41, !tbaa !23
  br label %bb103
bb102:
  br label %bb117
bb103:
  store %olang.scope zeroinitializer, ptr %s32
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t410, ptr %t411)
  br label %bb104
bb104:
  %t414 = load i32, ptr %l41, !tbaa !23
  %t416 = icmp ne i32 %t414, 0
  br i1 %t416, label %bb105, label %bb106
bb105:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load i32, ptr %l41, !tbaa !23
  %t422 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t418, i32 %t419)
  store { i64, ptr } %t422, ptr %l230
  br label %bb107
bb106:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb109
bb107:
  %t423 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t424 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s32, { i64, ptr } %t423, { i64, ptr } { i64 6, ptr @.d60 })
  store i1 %t424, ptr %l231
  br label %bb108
bb108:
  %t425 = load i1, ptr %l231, !tbaa !21
  %t426 = xor i1 %t425, true
  store i1 %t426, ptr %l227, !tbaa !21
  br label %bb109
bb109:
  %t428 = load i1, ptr %l227, !tbaa !21
  br i1 %t428, label %bb110, label %bb111
bb110:
  %t429 = load ptr, ptr %l0, !tbaa !29
  store ptr %t429, ptr %l233, !tbaa !29
  %t430 = load ptr, ptr %l0, !tbaa !29
  store ptr %t430, ptr %l234, !tbaa !29
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/names:Resolver", ptr %t431, i32 0, i32 6
  %t434 = load i64, ptr %t433, !tbaa !24
  store i64 %t434, ptr %l236, !tbaa !24
  %t435 = load ptr, ptr %l40, !tbaa !29
  %t437 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t435)
  store %"compiler/source:Span" %t437, ptr %l238
  br label %bb112
bb111:
  br label %bb116
bb112:
  %t438 = getelementptr %"compiler/source:Span", ptr %l238, i32 0, i32 1
  %t439 = load i32, ptr %t438, !tbaa !23
  %t440 = load i32, ptr %l41, !tbaa !23
  %t441 = load ptr, ptr %l234, !tbaa !29
  %t442 = load i64, ptr %l236, !tbaa !24
  %t445 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t441, i64 %t442, i32 %t439, i32 %t440)
  store %"compiler/source:Span" %t445, ptr %l241
  br label %bb113
bb113:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load i32, ptr %l41, !tbaa !23
  %t450 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t446, i32 %t447)
  store %"compiler/names:Ref" %t450, ptr %l244
  br label %bb114
bb114:
  %t451 = load ptr, ptr %l233, !tbaa !29
  %t452 = load %"compiler/source:Span", ptr %l241
  %t453 = load %"compiler/names:Ref", ptr %l244
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t451, %"compiler/source:Span" %t452, %"compiler/names:Ref" %t453)
  br label %bb115
bb115:
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s32)
  br label %bb125
bb117:
  %t454 = load ptr, ptr %l1, !tbaa !29
  store ptr %t454, ptr %l245, !tbaa !29
  store i1 false, ptr %l246, !tbaa !21
  %t455 = load ptr, ptr %l245, !tbaa !29
  %t456 = icmp ne ptr %t455, null
  br i1 %t456, label %bb118, label %bb119
bb118:
  %t458 = load ptr, ptr %l245, !tbaa !29
  %t459 = load i64, ptr %t458
  %t461 = icmp eq i64 %t459, 4
  store i1 %t461, ptr %l246, !tbaa !21
  br label %bb119
bb119:
  %t462 = load i1, ptr %l246, !tbaa !21
  br i1 %t462, label %bb120, label %bb121
bb120:
  %t463 = load ptr, ptr %l1, !tbaa !29
  %t465 = getelementptr { i64, [5 x i64] }, ptr %t463, i32 0, i32 1
  %t466 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t465, i32 0, i32 1
  %t467 = load ptr, ptr %t466
  store ptr %t467, ptr %l42, !tbaa !29
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t469, ptr %t470)
  br label %bb123
bb123:
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @.c61)
  unreachable
bb125:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l16 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca { i64, ptr }
  %l30 = alloca i1
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l47 = alloca { i64, ptr }
  %l53 = alloca i1
  %l62 = alloca ptr
  %l64 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l67 = alloca ptr
  %l72 = alloca { i64, [3 x i64] }
  %l75 = alloca { i64, ptr }
  %l78 = alloca %"compiler/msgs:Msg"
  %l79 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 6
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t5, i64 %t9)
  store ptr %t12, ptr %l16
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l16, !tbaa !29
  %t15 = getelementptr %"compiler/names:Table", ptr %t13, i32 0, i32 4
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l20
  br label %bb2
bb2:
  %t20 = load i1, ptr %l20, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l23
  br label %bb6
bb6:
  %t26 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/load:Loader", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = extractvalue { i64, ptr } %t33, 0
  %t38 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 1
  %t39 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 0
  %t40 = add i64 %t37, %t39
  %t42 = extractvalue { i64, ptr } %t34, 1
  %t43 = extractvalue { i64, ptr } %t34, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 6, ptr @.d63 }, 1
  %t46 = extractvalue { i64, ptr } { i64 6, ptr @.d63 }, 0
  %t47 = add i64 %t44, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t36, i64 %t37)
  %t49 = getelementptr i8, ptr %t48, i64 %t37
  call void @olang_textcopy(ptr %t49, ptr %t38, i64 %t39)
  %t50 = getelementptr i8, ptr %t49, i64 %t39
  call void @olang_textcopy(ptr %t50, ptr %t42, i64 %t43)
  %t51 = getelementptr i8, ptr %t50, i64 %t43
  call void @olang_textcopy(ptr %t51, ptr %t45, i64 %t46)
  %t52 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t48, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t62 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t60)
  store i1 %t62, ptr %l30
  br label %bb7
bb7:
  %t63 = load i1, ptr %l30, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/names:Resolver", ptr %t66, i32 0, i32 15
  store ptr %t68, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_Hc76fbb3533b710cefef21f62cdce924c(ptr %v0, ptr %t70, i64 %t71)
  %t75 = extractvalue { i32, { i64, ptr } } %t74, 1
  %t76 = extractvalue { i32, { i64, ptr } } %t74, 0
  store i32 %t76, ptr %l38
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb13, label %ok.78
ok.78:
  store { i64, ptr } %t75, ptr %l37
  br label %bb12
bb12:
  %t79 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t79, ptr %l34, !tbaa !27
  br label %bb17
bb13:
  %t80 = load i32, ptr %l38, !tbaa !23
  %t81 = ashr i32 %t80, 16
  %t83 = icmp eq i32 %t81, 1
  br i1 %t83, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @.c64)
  unreachable
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb17:
  %t85 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t85, ptr %l7, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb20:
  br label %bb21
bb21:
  %t98 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t98, ptr %l47, !tbaa !27
  %t99 = load i64, ptr %l9, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %t102, i64 %t99
  %t104 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %t103
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t104, ptr %l10
  %t106 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l10, i32 0, i32 0
  %t107 = load i32, ptr %t106, !tbaa !23
  %t108 = load i32, ptr %l2, !tbaa !23
  %t111 = icmp eq i32 %t107, %t108
  br i1 %t111, label %bb22, label %bb23
bb22:
  %t113 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l10, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t116 = icmp eq i64 %t114, -1
  store i1 %t116, ptr %l53, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb24
bb24:
  %t118 = load i1, ptr %l53, !tbaa !21
  br i1 %t118, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  %t119 = load i64, ptr %l9, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l9, !tbaa !24
  br label %bb18
bb29:
  %t123 = load i64, ptr %l6, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = add i64 %t123, %t124
  store i64 %t127, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  br label %bb11
bb31:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/names:Resolver", ptr %t129, i32 0, i32 15
  store ptr %t131, ptr %l62, !tbaa !29
  %t132 = load i32, ptr %l2, !tbaa !23
  %t134 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s0, i32 %t132, i64 -1)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t134, ptr %l64
  br label %bb32
bb32:
  %t135 = load ptr, ptr %l62, !tbaa !29
  %t136 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H00be49c2f1e120c94602e8686f44be2a(ptr %v0, ptr %t135, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t136)
  br label %bb33
bb33:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/names:Resolver", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/load:Loader", ptr %t140, i32 0, i32 4
  %t143 = load ptr, ptr %t142, !tbaa !29
  store ptr %t143, ptr %l67, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/names:Resolver", ptr %t145, i32 0, i32 6
  %t148 = load i64, ptr %t147, !tbaa !24
  %t153 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t144, i64 %t148, %"compiler/source:Span" %a1)
  store { i64, [3 x i64] } %t153, ptr %l72
  br label %bb34
bb34:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i32, ptr %l2, !tbaa !23
  %t158 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t154, i32 %t155)
  store { i64, ptr } %t158, ptr %l75
  br label %bb35
bb35:
  %t159 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  %t161 = extractvalue { i64, ptr } %t159, 1
  %t162 = mul i64 %t160, 1
  %t163 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t162)
  call void @llvm.memcpy.p0.p0.i64(ptr %t163, ptr %t161, i64 %t162, i1 false)
  %t164 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  %t166 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t169 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownImportStd(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t165, { i64, ptr } %t166)
  store %"compiler/msgs:Msg" %t169, ptr %l78
  br label %bb36
bb36:
  %t170 = load ptr, ptr %l67, !tbaa !29
  %t171 = load { i64, [3 x i64] }, ptr %l72
  %t172 = load %"compiler/msgs:Msg", ptr %l78
  %t173 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s0, ptr %t170, { i64, [3 x i64] } %t171, %"compiler/msgs:Msg" %t172)
  store i64 %t173, ptr %l79
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownInCond(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l16 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i32
  %l46 = alloca { i64, ptr }
  %l52 = alloca i1
  %l63 = alloca ptr
  %l67 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l70 = alloca ptr
  %l75 = alloca { i64, [3 x i64] }
  %l78 = alloca { i64, ptr }
  %l81 = alloca %"compiler/msgs:Msg"
  %l82 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 6
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t5, i64 %t9)
  store ptr %t12, ptr %l16
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l16, !tbaa !29
  %t15 = getelementptr %"compiler/names:Table", ptr %t13, i32 0, i32 4
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l20
  br label %bb2
bb2:
  %t20 = load i1, ptr %l20, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l23
  br label %bb6
bb6:
  %t26 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esuggests(ptr %v0, ptr %v0, ptr %t27, { i64, ptr } %t28)
  store i1 %t31, ptr %l26
  br label %bb7
bb7:
  %t32 = load i1, ptr %l26, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb11
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eimportedType(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l30
  br label %bb10
bb10:
  %t38 = load i1, ptr %l30, !tbaa !21
  store i1 %t38, ptr %l27, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l27, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 15
  store ptr %t42, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_Hc76fbb3533b710cefef21f62cdce924c(ptr %v0, ptr %t44, i64 %t45)
  %t49 = extractvalue { i32, { i64, ptr } } %t48, 1
  %t50 = extractvalue { i32, { i64, ptr } } %t48, 0
  store i32 %t50, ptr %l37
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb17, label %ok.52
ok.52:
  store { i64, ptr } %t49, ptr %l36
  br label %bb16
bb16:
  %t53 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t53, ptr %l33, !tbaa !27
  br label %bb21
bb17:
  %t54 = load i32, ptr %l37, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  br i1 %t57, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @.c65)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb21:
  %t59 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t59, ptr %l7, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb24:
  br label %bb25
bb25:
  %t72 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t72, ptr %l46, !tbaa !27
  %t73 = load i64, ptr %l9, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %t76, i64 %t73
  %t78 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %t77
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t78, ptr %l10
  %t80 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l10, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t82 = load i32, ptr %l2, !tbaa !23
  %t85 = icmp eq i32 %t81, %t82
  br i1 %t85, label %bb26, label %bb27
bb26:
  %t87 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l10, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/names:Resolver", ptr %t89, i32 0, i32 14
  %t92 = load i64, ptr %t91, !tbaa !24
  %t95 = icmp eq i64 %t88, %t92
  store i1 %t95, ptr %l52, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb28
bb28:
  %t97 = load i1, ptr %l52, !tbaa !21
  br i1 %t97, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  %t98 = load i64, ptr %l9, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l9, !tbaa !24
  br label %bb22
bb33:
  %t102 = load i64, ptr %l6, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = add i64 %t102, %t103
  store i64 %t106, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb34:
  br label %bb15
bb35:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/names:Resolver", ptr %t108, i32 0, i32 15
  store ptr %t110, ptr %l63, !tbaa !29
  %t111 = load i32, ptr %l2, !tbaa !23
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/names:Resolver", ptr %t112, i32 0, i32 14
  %t115 = load i64, ptr %t114, !tbaa !24
  %t118 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s0, i32 %t111, i64 %t115)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t118, ptr %l67
  br label %bb36
bb36:
  %t119 = load ptr, ptr %l63, !tbaa !29
  %t120 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l67
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H00be49c2f1e120c94602e8686f44be2a(ptr %v0, ptr %t119, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t120)
  br label %bb37
bb37:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/names:Resolver", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/load:Loader", ptr %t124, i32 0, i32 4
  %t127 = load ptr, ptr %t126, !tbaa !29
  store ptr %t127, ptr %l70, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/names:Resolver", ptr %t129, i32 0, i32 6
  %t132 = load i64, ptr %t131, !tbaa !24
  %t137 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t128, i64 %t132, %"compiler/source:Span" %a1)
  store { i64, [3 x i64] } %t137, ptr %l75
  br label %bb38
bb38:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l2, !tbaa !23
  %t142 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t138, i32 %t139)
  store { i64, ptr } %t142, ptr %l78
  br label %bb39
bb39:
  %t143 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  %t145 = extractvalue { i64, ptr } %t143, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  %t150 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t153 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownBuildName(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t149, { i64, ptr } %t150)
  store %"compiler/msgs:Msg" %t153, ptr %l81
  br label %bb40
bb40:
  %t154 = load ptr, ptr %l70, !tbaa !29
  %t155 = load { i64, [3 x i64] }, ptr %l75
  %t156 = load %"compiler/msgs:Msg", ptr %l81
  %t157 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s0, ptr %t154, { i64, [3 x i64] } %t155, %"compiler/msgs:Msg" %t156)
  store i64 %t157, ptr %l82
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2evarDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l31 = alloca { i64, ptr }
  %l40 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l59 = alloca i64
  %l62 = alloca i64
  %l82 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l96 = alloca i1
  %l112 = alloca { i64, ptr }
  %l119 = alloca i1
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp ne ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:VarDecl", ptr %t9, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t8, ptr %t12)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:VarDecl", ptr %t15, i32 0, i32 3
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp slt i64 %t24, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l31, !tbaa !27
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 %t33
  %t38 = load ptr, ptr %t37, !tbaa !39
  %t40 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t40, ptr %t38)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l3, !tbaa !24
  br label %bb5
bb11:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/ast:VarDecl", ptr %t48, i32 0, i32 5
  %t51 = load i1, ptr %t50, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/ast:VarDecl", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  store i1 %t58, ptr %l40, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t60 = load i1, ptr %l40, !tbaa !21
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:VarDecl", ptr %t61, i32 0, i32 3
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t68 = icmp eq i64 %t66, 0
  store i1 %t68, ptr %l44, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t70 = load i1, ptr %l44, !tbaa !21
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/ast:VarDecl", ptr %t71, i32 0, i32 4
  %t74 = load i1, ptr %t73, !tbaa !21
  %t76 = xor i1 %t74, true
  store i1 %t76, ptr %l49, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t78 = load i1, ptr %l49, !tbaa !21
  br i1 %t78, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l6, !tbaa !24
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/ast:VarDecl", ptr %t79, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb24, label %bb25
bb24:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb29
bb26:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l62, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb28
bb28:
  %t112 = load i64, ptr %l62, !tbaa !24
  store i64 %t112, ptr %l59, !tbaa !24
  br label %bb29
bb29:
  %t113 = load i64, ptr %l59, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb32:
  br label %bb33
bb33:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr %"compiler/ast:VarDecl", ptr %t133, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l82, !tbaa !27
  %t137 = load i64, ptr %l11, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i32, ptr %t140, i64 %t137
  %t142 = load i32, ptr %t141, !tbaa !33
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr %"compiler/ast:VarDecl", ptr %t143, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l86, !tbaa !27
  %t147 = load i64, ptr %l11, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr %"compiler/source:Span", ptr %t150, i64 %t147
  %t152 = load %"compiler/source:Span", ptr %t151
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/ast:VarDecl", ptr %t153, i32 0, i32 5
  %t156 = load i1, ptr %t155, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t132, i32 %t142, %"compiler/source:Span" %t152, i1 %t156)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t161 = load i64, ptr %l10, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l10, !tbaa !24
  br label %bb30
bb36:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/ast:VarDecl", ptr %t165, i32 0, i32 5
  %t168 = load i1, ptr %t167, !tbaa !21
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb37, label %bb38
bb37:
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr %"compiler/ast:VarDecl", ptr %t172, i32 0, i32 3
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr %"compiler/ast:VarDecl", ptr %t178, i32 0, i32 0
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t186 = icmp eq i64 %t177, %t183
  store i1 %t186, ptr %l96, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb39
bb39:
  %t188 = load i1, ptr %l96, !tbaa !21
  br i1 %t188, label %bb40, label %bb41
bb40:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr %"compiler/ast:VarDecl", ptr %t189, i32 0, i32 0
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  store { i64, ptr } %t192, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  store i64 %t196, ptr %l14, !tbaa !24
  br label %bb42
bb41:
  br label %bb53
bb42:
  store %olang.scope zeroinitializer, ptr %s11
  %t198 = load i64, ptr %l13, !tbaa !24
  %t199 = load i64, ptr %l14, !tbaa !24
  %t202 = icmp slt i64 %t198, %t199
  %t204 = xor i1 %t202, true
  br i1 %t204, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s11)
  br label %bb52
bb44:
  br label %bb45
bb45:
  %t206 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t206, ptr %l112, !tbaa !27
  %t207 = load i64, ptr %l13, !tbaa !24
  %t209 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr i32, ptr %t210, i64 %t207
  %t212 = load i32, ptr %t211, !tbaa !33
  store i32 %t212, ptr %l15, !tbaa !23
  %t214 = load i32, ptr %l15, !tbaa !23
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/names:Resolver", ptr %t216, i32 0, i32 11
  %t222 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t218, i32 %t214)
  store i1 %t222, ptr %l119
  br label %bb46
bb46:
  %t223 = load i1, ptr %l119, !tbaa !21
  %t224 = xor i1 %t223, true
  br i1 %t224, label %bb47, label %bb48
bb47:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/names:Resolver", ptr %t226, i32 0, i32 11
  %t229 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t228, i32 %t229)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s11)
  br label %bb51
bb51:
  %t232 = load i64, ptr %l13, !tbaa !24
  %t234 = add i64 %t232, 1
  store i64 %t234, ptr %l13, !tbaa !24
  br label %bb42
bb52:
  br label %bb53
bb53:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = getelementptr %"compiler/ast:TopIf", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitBranch(ptr %v0, ptr %v1, ptr %t1, i64 %t2, ptr %t6)
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TopIf", ptr %t10, i32 0, i32 2
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp ne ptr %t13, null
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:TopIf", ptr %t19, i32 0, i32 2
  %t22 = load ptr, ptr %t21, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %t17, i64 %t18, ptr %t22)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"compiler/ast:TopIf", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp ne ptr %t29, null
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l1, !tbaa !24
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:TopIf", ptr %t35, i32 0, i32 3
  %t38 = load ptr, ptr %t37, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitBranch(ptr %v0, ptr %v1, ptr %t33, i64 %t34, ptr %t38)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitBranch(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i32
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l27 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l97 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l106 = alloca i1
  %l120 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l126 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l137 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l140 = alloca i32
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TopBranch", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t7 = extractvalue { i64, ptr } zeroinitializer, 0
  %t8 = icmp eq i64 %t6, %t7
  %t9 = extractvalue { i64, ptr } %t4, 1
  %t10 = extractvalue { i64, ptr } zeroinitializer, 1
  %t11 = icmp eq ptr %t9, %t10
  %t12 = and i1 %t8, %t11
  br i1 %t12, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/names:Resolver", ptr %t14, i32 0, i32 1
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l27
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l27, !tbaa !29
  store ptr %t21, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/ast:TopBranch", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb75
bb7:
  br label %bb8
bb8:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t39, ptr %l36, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l7, !tbaa !29
  %t47 = load ptr, ptr %l7, !tbaa !29
  store ptr %t47, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t48 = load ptr, ptr %l39, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb9, label %bb10
bb9:
  %t51 = load ptr, ptr %l39, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 7
  store i1 %t54, ptr %l40, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l40, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t56 = load ptr, ptr %l7, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l8, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l1, !tbaa !24
  %t64 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %t62, i64 %t63, ptr %t64)
  br label %bb14
bb14:
  br label %bb73
bb15:
  %t68 = load ptr, ptr %l7, !tbaa !29
  store ptr %t68, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t69 = load ptr, ptr %l48, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = load ptr, ptr %l48, !tbaa !29
  %t73 = load i64, ptr %t72
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l49, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l49, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { ptr }, ptr %t79, i32 0, i32 0
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l9, !tbaa !29
  br label %bb24
bb19:
  %t83 = load ptr, ptr %l7, !tbaa !29
  store ptr %t83, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t84 = load ptr, ptr %l54, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t87 = load ptr, ptr %l54, !tbaa !29
  %t88 = load i64, ptr %t87
  %t90 = icmp eq i64 %t88, 1
  store i1 %t90, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t91 = load i1, ptr %l55, !tbaa !21
  br i1 %t91, label %bb22, label %bb23
bb22:
  %t92 = load ptr, ptr %l7, !tbaa !29
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { ptr }, ptr %t94, i32 0, i32 0
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l9, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/names:Table", ptr %t98, i32 0, i32 4
  %t101 = load ptr, ptr %l9, !tbaa !29
  %t103 = getelementptr %"compiler/ast:Func", ptr %t101, i32 0, i32 2
  %t104 = load i32, ptr %t103, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t100, i32 %t104, i1 true)
  br label %bb25
bb25:
  br label %bb73
bb26:
  %t107 = load ptr, ptr %l7, !tbaa !29
  store ptr %t107, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t108 = load ptr, ptr %l64, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb27, label %bb28
bb27:
  %t111 = load ptr, ptr %l64, !tbaa !29
  %t112 = load i64, ptr %t111
  %t114 = icmp eq i64 %t112, 2
  store i1 %t114, ptr %l65, !tbaa !21
  br label %bb28
bb28:
  %t115 = load i1, ptr %l65, !tbaa !21
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t116 = load ptr, ptr %l7, !tbaa !29
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", ptr }, ptr %t118, i32 0, i32 1
  %t120 = load ptr, ptr %t119
  store ptr %t120, ptr %l10, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t124 = getelementptr %"compiler/names:Table", ptr %t122, i32 0, i32 4
  %t125 = load ptr, ptr %l10, !tbaa !29
  %t127 = getelementptr %"compiler/ast:TypeDecl", ptr %t125, i32 0, i32 0
  %t128 = load i32, ptr %t127, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t124, i32 %t128, i1 true)
  br label %bb32
bb32:
  br label %bb73
bb33:
  %t131 = load ptr, ptr %l7, !tbaa !29
  store ptr %t131, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t132 = load ptr, ptr %l74, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb34, label %bb35
bb34:
  %t135 = load ptr, ptr %l74, !tbaa !29
  %t136 = load i64, ptr %t135
  %t138 = icmp eq i64 %t136, 5
  store i1 %t138, ptr %l75, !tbaa !21
  br label %bb35
bb35:
  %t139 = load i1, ptr %l75, !tbaa !21
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t140 = load ptr, ptr %l7, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, { i64, ptr } }, ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l11, !tbaa !23
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t146 = load ptr, ptr %l3, !tbaa !29
  %t148 = getelementptr %"compiler/names:Table", ptr %t146, i32 0, i32 4
  %t149 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t148, i32 %t149, i1 true)
  br label %bb39
bb39:
  br label %bb73
bb40:
  %t152 = load ptr, ptr %l7, !tbaa !29
  store ptr %t152, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t153 = load ptr, ptr %l83, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb41, label %bb42
bb41:
  %t156 = load ptr, ptr %l83, !tbaa !29
  %t157 = load i64, ptr %t156
  %t159 = icmp eq i64 %t157, 3
  store i1 %t159, ptr %l84, !tbaa !21
  br label %bb42
bb42:
  %t160 = load i1, ptr %l84, !tbaa !21
  br i1 %t160, label %bb43, label %bb44
bb43:
  %t161 = load ptr, ptr %l7, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", ptr }, ptr %t163, i32 0, i32 1
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l12, !tbaa !29
  br label %bb45
bb44:
  br label %bb53
bb45:
  %t167 = load ptr, ptr %l12, !tbaa !29
  %t169 = getelementptr %"compiler/ast:VarDecl", ptr %t167, i32 0, i32 0
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  store i64 %t174, ptr %l15, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s10
  %t176 = load i64, ptr %l14, !tbaa !24
  %t177 = load i64, ptr %l15, !tbaa !24
  %t180 = icmp slt i64 %t176, %t177
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb52
bb48:
  br label %bb49
bb49:
  %t184 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t184, ptr %l97, !tbaa !27
  %t185 = load i64, ptr %l14, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i32, ptr %t188, i64 %t185
  %t190 = load i32, ptr %t189, !tbaa !33
  %t192 = load ptr, ptr %l3, !tbaa !29
  %t194 = getelementptr %"compiler/names:Table", ptr %t192, i32 0, i32 4
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t194, i32 %t190, i1 true)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb51
bb51:
  %t198 = load i64, ptr %l14, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l14, !tbaa !24
  br label %bb46
bb52:
  br label %bb73
bb53:
  %t202 = load ptr, ptr %l7, !tbaa !29
  store ptr %t202, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t203 = load ptr, ptr %l105, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb54, label %bb55
bb54:
  %t206 = load ptr, ptr %l105, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 4
  store i1 %t209, ptr %l106, !tbaa !21
  br label %bb55
bb55:
  %t210 = load i1, ptr %l106, !tbaa !21
  br i1 %t210, label %bb56, label %bb57
bb56:
  %t211 = load ptr, ptr %l7, !tbaa !29
  %t213 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t213, i32 0, i32 1
  %t215 = load i32, ptr %t214
  store i32 %t215, ptr %l17, !tbaa !23
  %t217 = load ptr, ptr %l7, !tbaa !29
  %t219 = getelementptr { i64, [4 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t219, i32 0, i32 2
  %t221 = load %"compiler/source:Span", ptr %t220
  store %"compiler/source:Span" %t221, ptr %l18
  br label %bb58
bb57:
  br label %bb72
bb58:
  %t223 = load i32, ptr %l17, !tbaa !23
  store i32 %t223, ptr %l19, !tbaa !23
  %t225 = load i32, ptr %l19, !tbaa !23
  %t227 = icmp eq i32 %t225, 0
  br i1 %t227, label %bb59, label %bb60
bb59:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/names:Resolver", ptr %t229, i32 0, i32 0
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t234 = getelementptr %"compiler/load:Loader", ptr %t232, i32 0, i32 5
  %t235 = load i64, ptr %l1, !tbaa !24
  %t238 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t234, i64 %t235)
  store ptr %t238, ptr %l120
  br label %bb61
bb60:
  br label %bb70
bb61:
  %t239 = load ptr, ptr %l120, !tbaa !29
  %t241 = getelementptr %"compiler/load:Module", ptr %t239, i32 0, i32 6
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/source:Source", ptr %t242, i32 0, i32 1
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  store { i64, ptr } %t245, ptr %l123, !tbaa !27
  %t246 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t247 = load i32, ptr %t246, !tbaa !23
  %t249 = add i32 %t247, 1
  %t251 = sext i32 %t249 to i64
  store i64 %t251, ptr %l126, !tbaa !24
  %t252 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 1
  %t253 = load i32, ptr %t252, !tbaa !23
  %t255 = sub i32 %t253, 1
  %t257 = sext i32 %t255 to i64
  store i64 %t257, ptr %l129, !tbaa !24
  %t258 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 0
  store i64 %t259, ptr %l130, !tbaa !24
  %t260 = load i64, ptr %l126, !tbaa !24
  %t261 = icmp sge i64 %t260, 0
  br i1 %t261, label %bb62, label %bb63
bb62:
  %t263 = load i64, ptr %l126, !tbaa !24
  %t264 = load i64, ptr %l129, !tbaa !24
  %t265 = icmp sle i64 %t263, %t264
  br i1 %t265, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb64:
  %t267 = load i64, ptr %l129, !tbaa !24
  %t268 = load i64, ptr %l130, !tbaa !24
  %t269 = icmp sle i64 %t267, %t268
  br i1 %t269, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb66:
  %t271 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = load i64, ptr %l126, !tbaa !24
  %t274 = load i64, ptr %l129, !tbaa !24
  %t275 = getelementptr i8, ptr %t272, i64 %t273
  %t276 = sub i64 %t274, %t273
  %t277 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t275, 1
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/names:Resolver", ptr %t280, i32 0, i32 0
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t285 = getelementptr %"compiler/load:Loader", ptr %t283, i32 0, i32 3
  %t286 = load ptr, ptr %t285, !tbaa !29
  store ptr %t286, ptr %l137, !tbaa !29
  %t289 = call { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %v0, { i64, ptr } %t278)
  store { i64, ptr } %t289, ptr %l139
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb68:
  %t290 = load ptr, ptr %l137, !tbaa !29
  %t291 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t292 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t290, { i64, ptr } %t291)
  store i32 %t292, ptr %l140
  br label %bb69
bb69:
  %t293 = load i32, ptr %l140, !tbaa !23
  store i32 %t293, ptr %l19, !tbaa !23
  br label %bb70
bb70:
  %t294 = load ptr, ptr %l3, !tbaa !29
  %t296 = getelementptr %"compiler/names:Table", ptr %t294, i32 0, i32 4
  %t297 = load i32, ptr %l19, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t296, i32 %t297, i1 true)
  br label %bb71
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s3)
  br label %bb74
bb74:
  %t300 = load i64, ptr %l5, !tbaa !24
  %t302 = add i64 %t300, 1
  store i64 %t302, ptr %l5, !tbaa !24
  br label %bb5
bb75:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fnames_2edistance(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca i1
  %l41 = alloca i64
  %l47 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i64
  %l116 = alloca i64
  %l119 = alloca i64
  %l139 = alloca i64
  %l140 = alloca { i64, ptr }
  %l144 = alloca i8
  %l145 = alloca { i64, ptr }
  %l149 = alloca i8
  %l151 = alloca i64
  %l160 = alloca i64
  %l164 = alloca i1
  %l168 = alloca i64
  %l173 = alloca i64
  %l184 = alloca i64
  %l187 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 40
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp sgt i64 %t9, 40
  store i1 %t11, ptr %l34, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l34, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i64 99, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = add i64 %t17, 1
  store i64 %t19, ptr %l41, !tbaa !24
  %t20 = load i64, ptr %l41, !tbaa !24
  %t21 = icmp sge i64 %t20, 0
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l41, !tbaa !24
  %t24 = icmp sle i64 %t23, 1152921504606846975
  br i1 %t24, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c67)
  unreachable
bb9:
  %t26 = load i64, ptr %l41, !tbaa !24
  %t27 = mul i64 %t26, 8
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l2, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l47, !tbaa !24
  %t37 = load i64, ptr %l47, !tbaa !24
  %t38 = icmp sge i64 %t37, 0
  br i1 %t38, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c67)
  unreachable
bb11:
  %t40 = load i64, ptr %l47, !tbaa !24
  %t41 = icmp sle i64 %t40, 1152921504606846975
  br i1 %t41, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb13:
  %t43 = load i64, ptr %l47, !tbaa !24
  %t44 = mul i64 %t43, 8
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb15:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  br i1 %t63, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb20
bb17:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l4, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sub i64 %t73, 1
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = sdiv i64 %t75, %t76
  store i64 %t79, ptr %l60, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb19
bb19:
  %t81 = load i64, ptr %l60, !tbaa !24
  store i64 %t81, ptr %l57, !tbaa !24
  br label %bb20
bb20:
  %t82 = load i64, ptr %l57, !tbaa !24
  store i64 %t82, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t91 = load i64, ptr %l4, !tbaa !24
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = mul i64 %t92, %t93
  %t99 = add i64 %t91, %t96
  store i64 %t99, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i64, ptr %t106, i64 %t101
  store i64 %t102, ptr %t107, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t108 = load i64, ptr %l8, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l8, !tbaa !24
  br label %bb21
bb26:
  store i64 1, ptr %l10, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t118 = load i64, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb27, label %bb28
bb27:
  %t124 = load i64, ptr %l12, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb32
bb29:
  %t128 = load i64, ptr %l11, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l12, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l91, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb31
bb31:
  %t144 = load i64, ptr %l91, !tbaa !24
  store i64 %t144, ptr %l88, !tbaa !24
  br label %bb32
bb32:
  %t145 = load i64, ptr %l88, !tbaa !24
  store i64 %t145, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t146 = load i64, ptr %l14, !tbaa !24
  %t147 = load i64, ptr %l13, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb76
bb35:
  br label %bb36
bb36:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t155 = load i64, ptr %l14, !tbaa !24
  %t156 = load i64, ptr %l12, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l15, !tbaa !24
  %t164 = load i64, ptr %l15, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i64, ptr %t167, i64 0
  store i64 %t164, ptr %t168, !tbaa !34
  store i64 1, ptr %l16, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t175 = load i64, ptr %l17, !tbaa !24
  %t176 = load i64, ptr %l16, !tbaa !24
  %t179 = icmp sgt i64 %t175, %t176
  br i1 %t179, label %bb37, label %bb38
bb37:
  %t181 = load i64, ptr %l18, !tbaa !24
  %t183 = icmp sgt i64 %t181, 0
  br i1 %t183, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb42
bb39:
  %t185 = load i64, ptr %l17, !tbaa !24
  %t186 = load i64, ptr %l16, !tbaa !24
  %t189 = sub i64 %t185, %t186
  %t190 = load i64, ptr %l18, !tbaa !24
  %t193 = add i64 %t189, %t190
  %t195 = sub i64 %t193, 1
  %t196 = load i64, ptr %l18, !tbaa !24
  %t199 = sdiv i64 %t195, %t196
  store i64 %t199, ptr %l119, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb41
bb41:
  %t201 = load i64, ptr %l119, !tbaa !24
  store i64 %t201, ptr %l116, !tbaa !24
  br label %bb42
bb42:
  %t202 = load i64, ptr %l116, !tbaa !24
  store i64 %t202, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t203 = load i64, ptr %l20, !tbaa !24
  %t204 = load i64, ptr %l19, !tbaa !24
  %t207 = icmp slt i64 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s8)
  br label %bb62
bb45:
  br label %bb46
bb46:
  %t211 = load i64, ptr %l16, !tbaa !24
  %t212 = load i64, ptr %l20, !tbaa !24
  %t213 = load i64, ptr %l18, !tbaa !24
  %t216 = mul i64 %t212, %t213
  %t219 = add i64 %t211, %t216
  store i64 %t219, ptr %l21, !tbaa !24
  %t221 = load i64, ptr %l21, !tbaa !24
  %t223 = sub i64 %t221, 1
  %t225 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i64, ptr %t226, i64 %t223
  %t228 = load i64, ptr %t227, !tbaa !34
  store i64 %t228, ptr %l139, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t229, ptr %l140, !tbaa !27
  %t230 = load i64, ptr %l15, !tbaa !24
  %t232 = sub i64 %t230, 1
  %t234 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i8, ptr %t235, i64 %t232
  %t237 = load i8, ptr %t236, !tbaa !32
  %t239 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t237)
  store i8 %t239, ptr %l144
  br label %bb47
bb47:
  %t240 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t240, ptr %l145, !tbaa !27
  %t241 = load i64, ptr %l21, !tbaa !24
  %t243 = sub i64 %t241, 1
  %t245 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr i8, ptr %t246, i64 %t243
  %t248 = load i8, ptr %t247, !tbaa !32
  %t250 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t248)
  store i8 %t250, ptr %l149
  br label %bb48
bb48:
  %t251 = load i8, ptr %l144, !tbaa !22
  %t252 = load i8, ptr %l149, !tbaa !22
  %t253 = icmp eq i8 %t251, %t252
  br i1 %t253, label %bb49, label %bb50
bb49:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb51
bb50:
  store i64 1, ptr %l151, !tbaa !24
  br label %bb51
bb51:
  %t255 = load i64, ptr %l139, !tbaa !24
  %t256 = load i64, ptr %l151, !tbaa !24
  %t257 = add i64 %t255, %t256
  store i64 %t257, ptr %l22, !tbaa !24
  %t259 = load i64, ptr %l21, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr i64, ptr %t262, i64 %t259
  %t264 = load i64, ptr %t263, !tbaa !34
  %t266 = add i64 %t264, 1
  store i64 %t266, ptr %l23, !tbaa !24
  %t268 = load i64, ptr %l21, !tbaa !24
  %t270 = sub i64 %t268, 1
  %t272 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i64, ptr %t273, i64 %t270
  %t275 = load i64, ptr %t274, !tbaa !34
  %t277 = add i64 %t275, 1
  store i64 %t277, ptr %l24, !tbaa !24
  %t279 = load i64, ptr %l21, !tbaa !24
  store i64 %t279, ptr %l160, !tbaa !24
  %t280 = load i64, ptr %l22, !tbaa !24
  %t281 = load i64, ptr %l23, !tbaa !24
  %t284 = icmp slt i64 %t280, %t281
  br i1 %t284, label %bb52, label %bb53
bb52:
  %t286 = load i64, ptr %l22, !tbaa !24
  %t287 = load i64, ptr %l24, !tbaa !24
  %t290 = icmp slt i64 %t286, %t287
  store i1 %t290, ptr %l164, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb54
bb54:
  %t292 = load i1, ptr %l164, !tbaa !21
  br i1 %t292, label %bb55, label %bb56
bb55:
  %t293 = load i64, ptr %l22, !tbaa !24
  store i64 %t293, ptr %l168, !tbaa !24
  br label %bb60
bb56:
  %t295 = load i64, ptr %l23, !tbaa !24
  %t296 = load i64, ptr %l24, !tbaa !24
  %t299 = icmp slt i64 %t295, %t296
  br i1 %t299, label %bb57, label %bb58
bb57:
  %t301 = load i64, ptr %l23, !tbaa !24
  store i64 %t301, ptr %l173, !tbaa !24
  br label %bb59
bb58:
  %t303 = load i64, ptr %l24, !tbaa !24
  store i64 %t303, ptr %l173, !tbaa !24
  br label %bb59
bb59:
  %t305 = load i64, ptr %l173, !tbaa !24
  store i64 %t305, ptr %l168, !tbaa !24
  br label %bb60
bb60:
  %t306 = load i64, ptr %l168, !tbaa !24
  %t307 = load i64, ptr %l160, !tbaa !24
  %t308 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr i64, ptr %t309, i64 %t307
  store i64 %t306, ptr %t310, !tbaa !34
  call void @__olang_scope_close(ptr %s8)
  br label %bb61
bb61:
  %t311 = load i64, ptr %l20, !tbaa !24
  %t313 = add i64 %t311, 1
  store i64 %t313, ptr %l20, !tbaa !24
  br label %bb43
bb62:
  store i64 0, ptr %l25, !tbaa !24
  %t315 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t321 = load i64, ptr %l26, !tbaa !24
  %t322 = load i64, ptr %l25, !tbaa !24
  %t325 = icmp sgt i64 %t321, %t322
  br i1 %t325, label %bb63, label %bb64
bb63:
  %t327 = load i64, ptr %l27, !tbaa !24
  %t329 = icmp sgt i64 %t327, 0
  br i1 %t329, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l184, !tbaa !24
  br label %bb68
bb65:
  %t331 = load i64, ptr %l26, !tbaa !24
  %t332 = load i64, ptr %l25, !tbaa !24
  %t335 = sub i64 %t331, %t332
  %t336 = load i64, ptr %l27, !tbaa !24
  %t339 = add i64 %t335, %t336
  %t341 = sub i64 %t339, 1
  %t342 = load i64, ptr %l27, !tbaa !24
  %t345 = sdiv i64 %t341, %t342
  store i64 %t345, ptr %l187, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l187, !tbaa !24
  br label %bb67
bb67:
  %t347 = load i64, ptr %l187, !tbaa !24
  store i64 %t347, ptr %l184, !tbaa !24
  br label %bb68
bb68:
  %t348 = load i64, ptr %l184, !tbaa !24
  store i64 %t348, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s11
  %t349 = load i64, ptr %l29, !tbaa !24
  %t350 = load i64, ptr %l28, !tbaa !24
  %t353 = icmp slt i64 %t349, %t350
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb71:
  br label %bb72
bb72:
  %t357 = load i64, ptr %l25, !tbaa !24
  %t358 = load i64, ptr %l29, !tbaa !24
  %t359 = load i64, ptr %l27, !tbaa !24
  %t362 = mul i64 %t358, %t359
  %t365 = add i64 %t357, %t362
  store i64 %t365, ptr %l30, !tbaa !24
  %t367 = load i64, ptr %l30, !tbaa !24
  %t368 = load i64, ptr %l30, !tbaa !24
  %t370 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr i64, ptr %t371, i64 %t368
  %t373 = load i64, ptr %t372, !tbaa !34
  %t376 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr i64, ptr %t377, i64 %t367
  store i64 %t373, ptr %t378, !tbaa !34
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb73:
  %t379 = load i64, ptr %l29, !tbaa !24
  %t381 = add i64 %t379, 1
  store i64 %t381, ptr %l29, !tbaa !24
  br label %bb69
bb74:
  call void @__olang_scope_close(ptr %s6)
  br label %bb75
bb75:
  %t383 = load i64, ptr %l14, !tbaa !24
  %t385 = add i64 %t383, 1
  store i64 %t385, ptr %l14, !tbaa !24
  br label %bb33
bb76:
  %t387 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t387, 0
  %t391 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !27
  %t393 = getelementptr i64, ptr %t392, i64 %t389
  %t394 = load i64, ptr %t393, !tbaa !34
  call void @__olang_scope_close(ptr %s0)
  store i64 %t394, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fnames_2efieldNames(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i1
  %l61 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l15
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/ast:StructBody", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l24, !tbaa !27
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  %t31 = load ptr, ptr %lp1
  %t34 = getelementptr %"compiler/ast:Param", ptr %t29, i32 0, i32 1
  %t35 = load i32, ptr %t34, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v1, ptr %t31, i32 %t35)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/ast:StructBody", ptr %t42, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } zeroinitializer, 0
  %t49 = icmp eq i64 %t47, %t48
  %t50 = extractvalue { i64, ptr } %t45, 1
  %t51 = extractvalue { i64, ptr } zeroinitializer, 1
  %t52 = icmp eq ptr %t50, %t51
  %t53 = and i1 %t49, %t52
  br i1 %t53, label %bb9, label %bb10
bb9:
  %t55 = load ptr, ptr %lp1
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t55
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/ast:StructBody", ptr %t58, i32 0, i32 2
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  store i64 %t65, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s6
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb14:
  br label %bb15
bb15:
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t75, ptr %l44, !tbaa !27
  %t76 = load i64, ptr %l7, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t76
  %t81 = load ptr, ptr %t80, !tbaa !39
  store ptr %t81, ptr %l9, !tbaa !29
  %t83 = load ptr, ptr %l9, !tbaa !29
  store ptr %t83, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb16, label %bb17
bb16:
  %t87 = load ptr, ptr %l47, !tbaa !29
  %t88 = load i64, ptr %t87
  %t90 = icmp eq i64 %t88, 1
  store i1 %t90, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t91 = load i1, ptr %l48, !tbaa !21
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t92 = load ptr, ptr %l9, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", ptr }, ptr %t94, i32 0, i32 1
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l10, !tbaa !29
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t98 = load ptr, ptr %l10, !tbaa !29
  %t100 = getelementptr %"compiler/ast:VarDecl", ptr %t98, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s9
  %t107 = load i64, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l13, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s9)
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t115 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t115, ptr %l61, !tbaa !27
  %t116 = load i64, ptr %l12, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i32, ptr %t119, i64 %t116
  %t121 = load i32, ptr %t120, !tbaa !33
  %t123 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v1, ptr %t123, i32 %t121)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s9)
  br label %bb26
bb26:
  %t127 = load i64, ptr %l12, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l12, !tbaa !24
  br label %bb21
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l7, !tbaa !24
  br label %bb12
bb31:
  %t135 = load ptr, ptr %lp1
  %t136 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t135
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2fnames_2ekey(i64 %a0, i32 %a1) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = shl i64 %a0, 32
  %t6 = sext i32 %a1 to i64
  %t9 = or i64 %t3, %t6
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i64 } @compiler_2fnames_2elineCol(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 %a1, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l14, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store { i64, ptr } %a0, ptr %l35, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i8, ptr %t53, i64 %t47
  %t55 = load i8, ptr %t54, !tbaa !32
  %t57 = icmp eq i8 %t55, 10
  br i1 %t57, label %bb11, label %bb12
bb11:
  %t59 = load i64, ptr %l2, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  br label %bb13
bb12:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l3, !tbaa !24
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t67 = load i64, ptr %l8, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l8, !tbaa !24
  br label %bb7
bb15:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load i64, ptr %l3, !tbaa !24
  %t74 = insertvalue { i64, i64 } undef, i64 %t71, 0
  %t76 = insertvalue { i64, i64 } %t74, i64 %t72, 1
  store { i64, i64 } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca i32
  %l14 = alloca i32
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i32
  %l30 = alloca i32
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca i32
  %l38 = alloca i32
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l47 = alloca i1
  %l54 = alloca i32
  %l56 = alloca i32
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca i1
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t16 = load i32, ptr %l1
  store i32 %t16, ptr %l12
  store i32 2, ptr %l14
  %t19 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l12, ptr %l14)
  store i1 %t19, ptr %l16
  br label %bb6
bb6:
  %t20 = load i1, ptr %l16, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 3, ptr @.d69 }, ptr %l18, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  br label %bb21
bb8:
  %t23 = load i32, ptr %l1
  store i32 %t23, ptr %l20
  store i32 3, ptr %l22
  %t26 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l20, ptr %l22)
  store i1 %t26, ptr %l24
  br label %bb9
bb9:
  %t27 = load i1, ptr %l24, !tbaa !21
  br i1 %t27, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 3, ptr @.d70 }, ptr %l26, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t28, ptr %l25, !tbaa !27
  br label %bb20
bb11:
  %t30 = load i32, ptr %l1
  store i32 %t30, ptr %l28
  store i32 6, ptr %l30
  %t33 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l28, ptr %l30)
  store i1 %t33, ptr %l32
  br label %bb12
bb12:
  %t34 = load i1, ptr %l32, !tbaa !21
  br i1 %t34, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 4, ptr @.d71 }, ptr %l34, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t35, ptr %l33, !tbaa !27
  br label %bb19
bb14:
  %t37 = load i32, ptr %l1
  store i32 %t37, ptr %l36
  store i32 5, ptr %l38
  %t40 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l36, ptr %l38)
  store i1 %t40, ptr %l40
  br label %bb15
bb15:
  %t41 = load i1, ptr %l40, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 6, ptr @.d72 }, ptr %l42, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t42, ptr %l41, !tbaa !27
  br label %bb18
bb17:
  store { i64, ptr } { i64 0, ptr @.d73 }, ptr %l44, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t44, ptr %l41, !tbaa !27
  br label %bb18
bb18:
  %t46 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t46, ptr %l33, !tbaa !27
  br label %bb19
bb19:
  %t47 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t47, ptr %l25, !tbaa !27
  br label %bb20
bb20:
  %t48 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t48, ptr %l17, !tbaa !27
  br label %bb21
bb21:
  %t49 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t49, ptr %l5, !tbaa !27
  br label %bb45
bb22:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t51 = load ptr, ptr %l46, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb23, label %bb24
bb23:
  %t54 = load ptr, ptr %l46, !tbaa !29
  %t55 = load i64, ptr %t54
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t58 = load i1, ptr %l47, !tbaa !21
  br i1 %t58, label %bb25, label %bb26
bb25:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l2
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t71 = load i32, ptr %l2
  store i32 %t71, ptr %l54
  store i32 50, ptr %l56
  %t74 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l54, ptr %l56)
  store i1 %t74, ptr %l58
  br label %bb28
bb28:
  %t75 = load i1, ptr %l58, !tbaa !21
  br i1 %t75, label %bb29, label %bb30
bb29:
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = call { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v0, ptr %v1, ptr %t76)
  store { i64, ptr } %t78, ptr %l61
  br label %bb31
bb30:
  store { i64, ptr } { i64 0, ptr @.d74 }, ptr %l62, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t79, ptr %l59, !tbaa !27
  br label %bb32
bb31:
  %t81 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t81, ptr %l59, !tbaa !27
  br label %bb32
bb32:
  %t82 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t82, ptr %l5, !tbaa !27
  br label %bb45
bb33:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t84 = load ptr, ptr %l64, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb34, label %bb35
bb34:
  %t87 = load ptr, ptr %l64, !tbaa !29
  %t88 = load i64, ptr %t87
  %t90 = icmp eq i64 %t88, 2
  store i1 %t90, ptr %l65, !tbaa !21
  br label %bb35
bb35:
  %t91 = load i1, ptr %l65, !tbaa !21
  br i1 %t91, label %bb36, label %bb37
bb36:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", ptr }, ptr %t94, i32 0, i32 1
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l4, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t98 = load ptr, ptr %l4, !tbaa !29
  %t100 = call { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v0, ptr %v1, ptr %t98)
  store { i64, ptr } %t100, ptr %l71
  br label %bb39
bb39:
  %t101 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t101, ptr %l5, !tbaa !27
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr @.d75 }, ptr %l72, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t102, ptr %l5, !tbaa !27
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @.c76)
  unreachable
bb45:
  %t104 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l74, !tbaa !24
  %t106 = load i64, ptr %l74, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l75, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l74, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t117, ptr %l5, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t118, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fnames_2etestRules(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/cond:Consts"
  %l10 = alloca %"compiler/diag:Diagnostics"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"compiler/load:Loader"
  %l16 = alloca %"compiler/names:Resolver"
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/diag:Said"
  %l24 = alloca { i64, i64 }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l37 = alloca i64
  %l40 = alloca i64
  %l59 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l69 = alloca i32
  %l74 = alloca %"compiler/cond:Consts"
  %l76 = alloca %"compiler/diag:Diagnostics"
  %l84 = alloca { i64, ptr }
  %l90 = alloca i32
  %l93 = alloca ptr
  %l100 = alloca %"compiler/fetch:Fetcher"
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Names"
  %l105 = alloca %"compiler/load:Loader"
  %l108 = alloca { i64, ptr }
  %l112 = alloca i64
  %l114 = alloca %"compiler/names:Resolver"
  %l116 = alloca %"std/prelude/text:StringBuilder"
  %l118 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l120 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i32
  %l133 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l139 = alloca { i64, i64 }
  %l154 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l156 = alloca i64
  %l157 = alloca { i64, ptr }
  %l159 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t120 = alloca %"compiler/diag:Diagnostics", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr @.d77 }, { i64, ptr } { i64 0, ptr @.d78 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l29
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l28
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t6, ptr %l27, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l29, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb5:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb6:
  %t12 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l4, !tbaa !24
  store i64 2, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb12
bb9:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l40, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb11
bb11:
  %t43 = load i64, ptr %l40, !tbaa !24
  store i64 %t43, ptr %l37, !tbaa !24
  br label %bb12
bb12:
  %t44 = load i64, ptr %l37, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l8, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t64, ptr %l59, !tbaa !27
  %t65 = load i64, ptr %l8, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %t68, i64 %t65
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !37
  %t72 = extractvalue { i64, ptr } %t63, 1
  %t73 = extractvalue { i64, ptr } %t63, 0
  %t74 = extractvalue { i64, ptr } { i64 1, ptr @.d80 }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr @.d80 }, 0
  %t76 = add i64 %t73, %t75
  %t78 = extractvalue { i64, ptr } %t70, 1
  %t79 = extractvalue { i64, ptr } %t70, 0
  %t80 = add i64 %t76, %t79
  %t81 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t72, i64 %t73)
  %t82 = getelementptr i8, ptr %t81, i64 %t73
  call void @olang_textcopy(ptr %t82, ptr %t74, i64 %t75)
  %t83 = getelementptr i8, ptr %t82, i64 %t75
  call void @olang_textcopy(ptr %t83, ptr %t78, i64 %t79)
  %t84 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t81, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t93, ptr %l64, !tbaa !27
  %t94 = load i64, ptr %l8, !tbaa !24
  %t96 = add i64 %t94, 1
  %t98 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %t99, i64 %t96
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !37
  %t105 = call i32 @std_2fos_2eWriteFile(ptr %s3, ptr %v0, { i64, ptr } %t92, { i64, ptr } %t101)
  store i32 %t105, ptr %l69
  %t106 = icmp ne i32 %t105, 0
  br i1 %t106, label %bb18, label %ok.107
ok.107:
  br label %bb17
bb17:
  br label %bb22
bb18:
  %t108 = load i32, ptr %l69, !tbaa !23
  %t109 = ashr i32 %t108, 16
  %t111 = icmp eq i32 %t109, 1
  br i1 %t111, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @.c81)
  unreachable
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l7, !tbaa !24
  br label %bb13
bb24:
  %t117 = call %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %s0)
  store %"compiler/cond:Consts" %t117, ptr %l74
  br label %bb25
bb25:
  %t118 = load %"compiler/cond:Consts", ptr %l74
  store %"compiler/cond:Consts" %t118, ptr %l9
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l9, { i64, ptr } { i64 5, ptr @.d82 }, { i64, ptr } { i64 6, ptr @.d83 }, { i64, ptr } { i64 6, ptr @.d84 }, i64 128, i64 0, i1 false, i1 false, i1 false)
  br label %bb26
bb26:
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t120, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l76, ptr %t120, i64 200, i1 false)
  br label %bb27
bb27:
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %l76, i64 200, i1 false)
  store { i64, ptr } %a1, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  store i64 %t125, ptr %l13, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t127 = load i64, ptr %l12, !tbaa !24
  %t128 = load i64, ptr %l13, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t135 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t135, ptr %l84, !tbaa !27
  %t136 = load i64, ptr %l12, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %t139, i64 %t136
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !37
  %t147 = call i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %s0, ptr %v1, ptr %s0, ptr %l9, { i64, ptr } %t141, ptr %l10)
  store i32 %t147, ptr %l90
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb33, label %ok.149
ok.149:
  br label %bb32
bb32:
  br label %bb35
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb36
bb36:
  %t150 = load i64, ptr %l12, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l12, !tbaa !24
  br label %bb28
bb37:
  store ptr %l9, ptr %l93, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = extractvalue { i64, ptr } %t154, 0
  %t158 = extractvalue { i64, ptr } { i64 11, ptr @.d85 }, 1
  %t159 = extractvalue { i64, ptr } { i64 11, ptr @.d85 }, 0
  %t160 = add i64 %t157, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t156, i64 %t157)
  %t162 = getelementptr i8, ptr %t161, i64 %t157
  call void @olang_textcopy(ptr %t162, ptr %t158, i64 %t159)
  %t163 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t161, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = extractvalue { i64, ptr } %t164, 1
  %t168 = mul i64 %t166, 1
  %t169 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t168)
  call void @llvm.memcpy.p0.p0.i64(ptr %t169, ptr %t167, i64 %t168, i1 false)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  %t172 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 1
  %t175 = extractvalue { i64, ptr } %t172, 0
  %t176 = extractvalue { i64, ptr } { i64 6, ptr @.d86 }, 1
  %t177 = extractvalue { i64, ptr } { i64 6, ptr @.d86 }, 0
  %t178 = add i64 %t175, %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t174, i64 %t175)
  %t180 = getelementptr i8, ptr %t179, i64 %t175
  call void @olang_textcopy(ptr %t180, ptr %t176, i64 %t177)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t179, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = extractvalue { i64, ptr } %t182, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  %t192 = call %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t171, { i64, ptr } %t189, { i64, ptr } { i64 16, ptr @.d87 }, i1 false, i1 true)
  store %"compiler/fetch:Fetcher" %t192, ptr %l100
  br label %bb38
bb38:
  %t193 = load %"compiler/fetch:Fetcher", ptr %l100
  %t194 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 88, i64 8)
  store %"compiler/fetch:Fetcher" %t193, ptr %t194
  store ptr %t194, ptr %l101, !tbaa !29
  %t195 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %s0)
  store %"compiler/source:Names" %t195, ptr %l102
  br label %bb39
bb39:
  %t196 = load %"compiler/source:Names", ptr %l102
  %t197 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 16, i64 8)
  store %"compiler/source:Names" %t196, ptr %t197
  %t198 = load ptr, ptr %l93, !tbaa !29
  %t199 = load ptr, ptr %l101, !tbaa !29
  %t202 = call %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 3, ptr @.d88 }, ptr %t198, ptr %t199, ptr %t197, ptr %l10)
  store %"compiler/load:Loader" %t202, ptr %l105
  br label %bb40
bb40:
  %t203 = load %"compiler/load:Loader", ptr %l105
  store %"compiler/load:Loader" %t203, ptr %l15
  %t204 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t205, ptr %l108, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %t207, i64 0
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !37
  %t211 = extractvalue { i64, ptr } %t204, 1
  %t212 = extractvalue { i64, ptr } %t204, 0
  %t213 = extractvalue { i64, ptr } { i64 1, ptr @.d89 }, 1
  %t214 = extractvalue { i64, ptr } { i64 1, ptr @.d89 }, 0
  %t215 = add i64 %t212, %t214
  %t217 = extractvalue { i64, ptr } %t209, 1
  %t218 = extractvalue { i64, ptr } %t209, 0
  %t219 = add i64 %t215, %t218
  %t220 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t219)
  call void @olang_textcopy(ptr %t220, ptr %t211, i64 %t212)
  %t221 = getelementptr i8, ptr %t220, i64 %t212
  call void @olang_textcopy(ptr %t221, ptr %t213, i64 %t214)
  %t222 = getelementptr i8, ptr %t221, i64 %t214
  call void @olang_textcopy(ptr %t222, ptr %t217, i64 %t218)
  %t223 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t220, 1
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = extractvalue { i64, ptr } %t224, 1
  %t228 = mul i64 %t226, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t229, ptr %t227, i64 %t228, i1 false)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  %t234 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } %t231)
  store i64 %t234, ptr %l112
  br label %bb41
bb41:
  %t236 = call %"compiler/names:Resolver" @compiler_2fnames_3aResolver_2ector(ptr %s0, ptr %s0, ptr %l15)
  store %"compiler/names:Resolver" %t236, ptr %l114
  br label %bb42
bb42:
  %t237 = load %"compiler/names:Resolver", ptr %l114
  store %"compiler/names:Resolver" %t237, ptr %l16
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %s0, ptr %l16)
  br label %bb43
bb43:
  %t239 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t239, ptr %l116
  br label %bb44
bb44:
  %t240 = load %"std/prelude/text:StringBuilder", ptr %l116
  store %"std/prelude/text:StringBuilder" %t240, ptr %l17
  store %olang.scope zeroinitializer, ptr %s14
  %t242 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %s0, ptr %s14, ptr %l10)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t242, ptr %l118
  br label %bb45
bb45:
  %t243 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l118
  %t244 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t243, ptr %t244
  store ptr %t244, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s15
  %t246 = load ptr, ptr %l18, !tbaa !29
  %t247 = load i64, ptr %l19, !tbaa !24
  %t250 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eRunFrom_3ccompiler_2fdiag_3aSaid_3e(ptr %s14, ptr %t246, i64 %t247)
  %t251 = extractvalue { i32, { i64, ptr } } %t250, 1
  %t252 = extractvalue { i32, { i64, ptr } } %t250, 0
  store i32 %t252, ptr %l124
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb48, label %ok.254
ok.254:
  store { i64, ptr } %t251, ptr %l123
  br label %bb47
bb47:
  %t255 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t255, ptr %l120, !tbaa !27
  br label %bb52
bb48:
  %t256 = load i32, ptr %l124, !tbaa !23
  %t257 = ashr i32 %t256, 16
  %t259 = icmp eq i32 %t257, 1
  br i1 %t259, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @.c90)
  unreachable
bb51:
  call void @__olang_scope_close(ptr %s15)
  br label %bb62
bb52:
  %t261 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t261, ptr %l20, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 0
  store i64 %t264, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s16
  %t266 = load i64, ptr %l22, !tbaa !24
  %t267 = load i64, ptr %l21, !tbaa !24
  %t270 = icmp slt i64 %t266, %t267
  %t272 = xor i1 %t270, true
  br i1 %t272, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s16)
  br label %bb60
bb55:
  br label %bb56
bb56:
  %t274 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t274, ptr %l133, !tbaa !27
  %t275 = load i64, ptr %l22, !tbaa !24
  %t277 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr %"compiler/diag:Said", ptr %t278, i64 %t275
  %t280 = load %"compiler/diag:Said", ptr %t279
  store %"compiler/diag:Said" %t280, ptr %l23
  %t282 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t282, ptr %l136, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr { i64, ptr }, ptr %t284, i64 1
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !37
  %t287 = getelementptr %"compiler/diag:Said", ptr %l23, i32 0, i32 2
  %t288 = load i64, ptr %t287, !tbaa !24
  %t291 = call { i64, i64 } @compiler_2fnames_2elineCol(ptr %v0, { i64, ptr } %t286, i64 %t288)
  store { i64, i64 } %t291, ptr %l139
  br label %bb57
bb57:
  %t292 = load { i64, i64 }, ptr %l139
  store { i64, i64 } %t292, ptr %l24
  %t293 = getelementptr { i64, i64 }, ptr %l24, i32 0, i32 0
  %t294 = load i64, ptr %t293, !tbaa !24
  %t296 = getelementptr { i64, i64 }, ptr %l24, i32 0, i32 1
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = getelementptr %"compiler/diag:Said", ptr %l23, i32 0, i32 0
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t300, 1
  %t305 = extractvalue { i64, ptr } %t300, 0
  %t306 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 1
  %t307 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 0
  %t308 = add i64 %t305, %t307
  %t310 = call i64 @__olang_fmt_i64(ptr null, i64 %t294)
  %t311 = add i64 %t308, %t310
  %t312 = extractvalue { i64, ptr } { i64 1, ptr @.d92 }, 1
  %t313 = extractvalue { i64, ptr } { i64 1, ptr @.d92 }, 0
  %t314 = add i64 %t311, %t313
  %t316 = call i64 @__olang_fmt_i64(ptr null, i64 %t297)
  %t317 = add i64 %t314, %t316
  %t318 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 1
  %t319 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 0
  %t320 = add i64 %t317, %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t320)
  call void @olang_textcopy(ptr %t321, ptr %t304, i64 %t305)
  %t322 = getelementptr i8, ptr %t321, i64 %t305
  call void @olang_textcopy(ptr %t322, ptr %t306, i64 %t307)
  %t323 = getelementptr i8, ptr %t322, i64 %t307
  %t324 = call i64 @__olang_fmt_i64(ptr %t323, i64 %t294)
  %t325 = getelementptr i8, ptr %t323, i64 %t310
  call void @olang_textcopy(ptr %t325, ptr %t312, i64 %t313)
  %t326 = getelementptr i8, ptr %t325, i64 %t313
  %t327 = call i64 @__olang_fmt_i64(ptr %t326, i64 %t297)
  %t328 = getelementptr i8, ptr %t326, i64 %t316
  call void @olang_textcopy(ptr %t328, ptr %t318, i64 %t319)
  %t329 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t321, 1
  %t332 = extractvalue { i64, ptr } %t330, 0
  %t333 = extractvalue { i64, ptr } %t330, 1
  %t334 = mul i64 %t332, 1
  %t335 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t334)
  call void @llvm.memcpy.p0.p0.i64(ptr %t335, ptr %t333, i64 %t334, i1 false)
  %t336 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t335, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l17, { i64, ptr } %t337)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s16)
  br label %bb59
bb59:
  %t340 = load i64, ptr %l22, !tbaa !24
  %t342 = add i64 %t340, 1
  store i64 %t342, ptr %l22, !tbaa !24
  br label %bb53
bb60:
  %t344 = load i64, ptr %l19, !tbaa !24
  %t345 = load i64, ptr %l21, !tbaa !24
  %t348 = add i64 %t344, %t345
  store i64 %t348, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb61
bb61:
  br label %bb46
bb62:
  call void @__olang_scope_close(ptr %s14)
  %t351 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l17)
  store { i64, ptr } %t351, ptr %l154
  br label %bb63
bb63:
  %t352 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t352, ptr %l155, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t353, 0
  store i64 %t354, ptr %l156, !tbaa !24
  %t355 = load i64, ptr %l156, !tbaa !24
  %t356 = mul i64 %t355, 1
  %t357 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t356)
  %t358 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  store { i64, ptr } %t359, ptr %l157, !tbaa !27
  %t360 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = load i64, ptr %l156, !tbaa !24
  %t365 = mul i64 %t364, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t361, ptr %t363, i64 %t365, i1 false)
  %t366 = load { i64, ptr }, ptr %l157, !tbaa !27
  store { i64, ptr } %t366, ptr %l155, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t369 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t367)
  store i32 %t369, ptr %l159
  %t370 = icmp ne i32 %t369, 0
  br i1 %t370, label %bb65, label %ok.371
ok.371:
  br label %bb64
bb64:
  br label %bb69
bb65:
  %t372 = load i32, ptr %l159, !tbaa !23
  %t373 = ashr i32 %t372, 16
  %t375 = icmp eq i32 %t373, 1
  br i1 %t375, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t377 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t377, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fnames_2ewritable(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t17, i32 0, i32 2
  %t19 = load i1, ptr %t18
  store i1 %t19, ptr %l1, !tbaa !21
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load i1, ptr %l1, !tbaa !21
  store i1 %t21, ptr %l5, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @.c95)
  unreachable
bb14:
  %t23 = load i1, ptr %l5, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v0, ptr %v1, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i1 %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/names:Entry"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/names:Entry" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/names:Entry" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/names:Entry" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/names:Entry" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/names:Entry" %t18, ptr %a4, 4
  store %"compiler/names:Entry" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Entry", ptr %rv
  ret %"compiler/names:Entry" %rr
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/names:Ref"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/names:Ref" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/names:Ref" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/names:Ref" %t10, i64 %a2, 2
  store %"compiler/names:Ref" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local %"compiler/names:Resolver" @compiler_2fnames_3aResolver_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/names:Resolver"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l19
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l2
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t6)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l20
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e(ptr %t9)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l21
  br label %bb3
bb3:
  %t11 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l4
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e(ptr %t12)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l22
  br label %bb4
bb4:
  %t14 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l5
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e(ptr %t15)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l23
  br label %bb5
bb5:
  %t17 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l6
  store i64 -1, ptr %l7, !tbaa !24
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e(ptr %t18)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l24
  br label %bb6
bb6:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l8
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t21)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l25
  br label %bb7
bb7:
  %t23 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l9
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e(ptr %t24)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l26
  br label %bb8
bb8:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l10
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %t27)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l27
  br label %bb9
bb9:
  %t29 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l11
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l28
  br label %bb10
bb10:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l12
  store i1 false, ptr %l13, !tbaa !21
  store i1 false, ptr %l14, !tbaa !21
  store i64 0, ptr %l15, !tbaa !24
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e(ptr %t33)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l29
  br label %bb11
bb11:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l16
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t36)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l30
  br label %bb12
bb12:
  %t38 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t40 = insertvalue %"compiler/names:Resolver" undef, ptr %t39, 0
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t42 = insertvalue %"compiler/names:Resolver" %t40, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, 1
  %t43 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t44 = insertvalue %"compiler/names:Resolver" %t42, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, 2
  %t45 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t46 = insertvalue %"compiler/names:Resolver" %t44, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, 3
  %t47 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t48 = insertvalue %"compiler/names:Resolver" %t46, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, 4
  %t49 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t50 = insertvalue %"compiler/names:Resolver" %t48, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, 5
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = insertvalue %"compiler/names:Resolver" %t50, i64 %t51, 6
  %t53 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t54 = insertvalue %"compiler/names:Resolver" %t52, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, 7
  %t55 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t56 = insertvalue %"compiler/names:Resolver" %t54, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, 8
  %t57 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t58 = insertvalue %"compiler/names:Resolver" %t56, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, 9
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t60 = insertvalue %"compiler/names:Resolver" %t58, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, 10
  %t61 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t62 = insertvalue %"compiler/names:Resolver" %t60, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, 11
  %t63 = load i1, ptr %l13, !tbaa !21
  %t64 = insertvalue %"compiler/names:Resolver" %t62, i1 %t63, 12
  %t65 = load i1, ptr %l14, !tbaa !21
  %t66 = insertvalue %"compiler/names:Resolver" %t64, i1 %t65, 13
  %t67 = load i64, ptr %l15, !tbaa !24
  %t68 = insertvalue %"compiler/names:Resolver" %t66, i64 %t67, 14
  %t69 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t70 = insertvalue %"compiler/names:Resolver" %t68, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, 15
  %t72 = insertvalue %"compiler/names:Resolver" %t70, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, 16
  store %"compiler/names:Resolver" %t72, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Resolver", ptr %rv
  ret %"compiler/names:Resolver" %rr
}

define dso_local %"compiler/names:Table" @compiler_2fnames_3aTable_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/names:Table"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l5
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l1
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t7)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l2
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t10)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l8
  br label %bb4
bb4:
  %t12 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l3
  %t13 = load ptr, ptr @__olang_prog_scope
  %t14 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %t13)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l9
  br label %bb5
bb5:
  %t15 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t17 = insertvalue %"compiler/names:Table" undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, 0
  %t18 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t19 = insertvalue %"compiler/names:Table" %t17, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, 1
  %t20 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t21 = insertvalue %"compiler/names:Table" %t19, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, 2
  %t22 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t23 = insertvalue %"compiler/names:Table" %t21, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, 3
  %t25 = insertvalue %"compiler/names:Table" %t23, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 4
  store %"compiler/names:Table" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Table", ptr %rv
  ret %"compiler/names:Table" %rr
}

define dso_local %"compiler/names:local" @compiler_2fnames_3alocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/names:local"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/names:local" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/names:local" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/names:local" %t10, i32 %a2, 2
  store %"compiler/names:local" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:local", ptr %rv
  ret %"compiler/names:local" %rr
}

@.d0 = private constant [4 x i8] c"Bool"
@.d1 = private constant [5 x i8] c"Array"
@.d2 = private constant [2 x i8] c"I8"
@.d3 = private constant [3 x i8] c"I16"
@.d4 = private constant [3 x i8] c"I32"
@.d5 = private constant [3 x i8] c"I64"
@.d6 = private constant [2 x i8] c"U8"
@.d7 = private constant [3 x i8] c"U16"
@.d8 = private constant [3 x i8] c"U32"
@.d9 = private constant [3 x i8] c"U64"
@.d10 = private constant [3 x i8] c"F16"
@.d11 = private constant [4 x i8] c"BF16"
@.d12 = private constant [3 x i8] c"F32"
@.d13 = private constant [3 x i8] c"F64"
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr)
@.c14 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:108: unreachable reached\0A\00"
@.c15 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:111: unreachable reached\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fnames_3aWhat(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d16 = private constant [1 x i8] c"_"
@.d17 = private constant [4 x i8] c"std/"
@.c18 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1127: unreachable reached\0A\00"
@.c19 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:206: unreachable reached\0A\00"
@.d20 = private constant [0 x i8] c""
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.c21 = private unnamed_addr constant [53 x i8] c"compiler/names.olang:343: slice bounds out of range\0A\00"
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d22 = private constant [0 x i8] c""
@.d23 = private constant [4 x i8] c"Bool"
@.d24 = private constant [3 x i8] c"I32"
@.d25 = private constant [3 x i8] c"I64"
@.d26 = private constant [3 x i8] c"U64"
@.d27 = private constant [3 x i8] c"F64"
@.d28 = private constant [6 x i8] c"String"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c29 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:903: unreachable reached\0A\00"
@.c30 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:905: unreachable reached\0A\00"
@.d31 = private constant [1 x i8] c"_"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aOutcome(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c32 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:853: unreachable reached\0A\00"
@.c33 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1103: unreachable reached\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c34 = private unnamed_addr constant [53 x i8] c"compiler/names.olang:191: slice bounds out of range\0A\00"
@.d35 = private constant [1 x i8] c"_"
@.c36 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:601: unreachable reached\0A\00"
@.d37 = private constant [1 x i8] c"_"
@.c38 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:726: unreachable reached\0A\00"
@.c39 = private unnamed_addr constant [54 x i8] c"compiler/names.olang:1063: slice bounds out of range\0A\00"
@.d40 = private constant [4 x i8] c"Byte"
@.d41 = private constant [2 x i8] c"I8"
@.d42 = private constant [3 x i8] c"I16"
@.d43 = private constant [3 x i8] c"I32"
@.d44 = private constant [3 x i8] c"I64"
@.d45 = private constant [2 x i8] c"U8"
@.d46 = private constant [3 x i8] c"U16"
@.d47 = private constant [3 x i8] c"U32"
@.d48 = private constant [3 x i8] c"U64"
@.d49 = private constant [3 x i8] c"F16"
@.d50 = private constant [4 x i8] c"BF16"
@.d51 = private constant [3 x i8] c"F32"
@.d52 = private constant [3 x i8] c"F64"
@.d53 = private constant [4 x i8] c"Bool"
@.d54 = private constant [5 x i8] c"Array"
@.c55 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1070: unreachable reached\0A\00"
@.c56 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1073: unreachable reached\0A\00"
@.c57 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1076: unreachable reached\0A\00"
@.c58 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:667: unreachable reached\0A\00"
@.c59 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:646: unreachable reached\0A\00"
@.d60 = private constant [6 x i8] c"return"
@.c61 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1184: unreachable reached\0A\00"
@.d62 = private constant [1 x i8] c"/"
@.d63 = private constant [6 x i8] c".olang"
@.c64 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1163: unreachable reached\0A\00"
@.c65 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1051: unreachable reached\0A\00"
@.c66 = private unnamed_addr constant [53 x i8] c"compiler/names.olang:265: slice bounds out of range\0A\00"
@.c67 = private unnamed_addr constant [54 x i8] c"compiler/names.olang:1085: array length out of range\0A\00"
@.c68 = private unnamed_addr constant [54 x i8] c"compiler/names.olang:1086: array length out of range\0A\00"
@.d69 = private constant [3 x i8] c"I64"
@.d70 = private constant [3 x i8] c"F64"
@.d71 = private constant [4 x i8] c"Bool"
@.d72 = private constant [6 x i8] c"String"
@.d73 = private constant [0 x i8] c""
@.d74 = private constant [0 x i8] c""
@.d75 = private constant [0 x i8] c""
@.c76 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:360: unreachable reached\0A\00"
@.d77 = private constant [0 x i8] c""
@.d78 = private constant [0 x i8] c""
@.c79 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1288: unreachable reached\0A\00"
@.d80 = private constant [1 x i8] c"/"
@.c81 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1291: unreachable reached\0A\00"
@.d82 = private constant [5 x i8] c"linux"
@.d83 = private constant [6 x i8] c"x86_64"
@.d84 = private constant [6 x i8] c"x86-64"
@.d85 = private constant [11 x i8] c"/olang.lock"
@.d86 = private constant [6 x i8] c"/cache"
@.d87 = private constant [16 x i8] c"file:///nowhere/"
@.d88 = private constant [3 x i8] c"std"
@.d89 = private constant [1 x i8] c"/"
@.c90 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1303: unreachable reached\0A\00"
@.d91 = private constant [1 x i8] c" "
declare i64 @__olang_fmt_i64(ptr, i64)
@.d92 = private constant [1 x i8] c":"
@.d93 = private constant [1 x i8] c"\0A"
@.c94 = private unnamed_addr constant [48 x i8] c"compiler/names.olang:1289: unreachable reached\0A\00"
@.c95 = private unnamed_addr constant [47 x i8] c"compiler/names.olang:278: unreachable reached\0A\00"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H66319a5cfce1cb719f827f90e3d522ba(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eG_Hb4f204ca9d50eb43e30fe8770cb15d1a(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H456f40e55a35e282608933ec0991ad61(ptr %v0, ptr %a0, i32 %a1, %"compiler/names:Ref" %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameIsType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/names:Entry" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %v0)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultMut(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H6d33fbc050830e537410645e3c893b2c(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePreludeConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %a0, i64 %a1, %"compiler/names:Ref" %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H00be49c2f1e120c94602e8686f44be2a(ptr %v0, ptr %a0, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2ePush_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0, %"compiler/names:local" %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2fload_2ePending = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultFit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eCle_Hfe7f0d5b2686087af262d47548aa26e4(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/cond:Eval" @compiler_2fcond_3aEval_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3)
declare { i32, i1 } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/names:local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAlreadyDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCutOff(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInNameExists(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H678d1b43e8b98a171ffdea8f28643d28(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_Hf9d8b9e9334551fc04613fb711673451(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameClashesWithImport(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsFunction(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsGlobal(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsBuildConst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H1b67a9adff6f6c708503322bb7ca7b5e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H7068c8717e9d582db2941dd2bdd79d55(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2eClear_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hb7e448baed1c9668005f7dc6325e5707(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H3edd758492d36e0e1280bad2972803df(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_Hc76fbb3533b710cefef21f62cdce924c(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownImportStd(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownBuildName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %v0, { i64, ptr } %a0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eRunFrom_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fnames_3alocal_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
