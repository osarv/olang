; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/names:local" = type { i32, %"compiler/source:Span", i32, i1, i1, i1 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" = type { i64, %"compiler/source:Span" }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Outlives" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/cond:Decision" = type { i32, i1 }
%"compiler/cond:Eval" = type { { i64, ptr }, ptr, ptr, ptr, i1, i1, i1, %"compiler/source:Span", %"compiler/msgs:Msg", i64, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/cond:Scope" = type { i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:raisedName" = type { i32, %"compiler/source:Span", i64, i1, i64 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/names:raised" = type { i32, %"compiler/source:Span", i1 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/names:Unread" = type { i64, %"compiler/source:Span", i32, i1 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
define dso_local i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb17
bb15:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t22, ptr %l14
  br label %bb16
bb16:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb17
bb17:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb21
bb19:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t27, ptr %l17
  br label %bb20
bb20:
  %t28 = load i1, ptr %l17, !tbaa !21
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb21
bb21:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb25
bb23:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t32, ptr %l20
  br label %bb24
bb24:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb25
bb25:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb29
bb27:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t35, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t37, ptr %l23
  br label %bb28
bb28:
  %t38 = load i1, ptr %l23, !tbaa !21
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb29
bb29:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb33
bb31:
  %t40 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t40, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t42, ptr %l26
  br label %bb32
bb32:
  %t43 = load i1, ptr %l26, !tbaa !21
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb33
bb33:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb37
bb35:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t47, ptr %l29
  br label %bb36
bb36:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb37
bb37:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb41
bb39:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t52, ptr %l32
  br label %bb40
bb40:
  %t53 = load i1, ptr %l32, !tbaa !21
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb41
bb41:
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb45
bb43:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t55, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t57, ptr %l35
  br label %bb44
bb44:
  %t58 = load i1, ptr %l35, !tbaa !21
  store i1 %t58, ptr %l33, !tbaa !21
  br label %bb45
bb45:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb49
bb47:
  %t60 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t62, ptr %l38
  br label %bb48
bb48:
  %t63 = load i1, ptr %l38, !tbaa !21
  store i1 %t63, ptr %l36, !tbaa !21
  br label %bb49
bb49:
  %t64 = load i1, ptr %l36, !tbaa !21
  br i1 %t64, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb53
bb51:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t67, ptr %l41
  br label %bb52
bb52:
  %t68 = load i1, ptr %l41, !tbaa !21
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb53
bb53:
  %t69 = load i1, ptr %l39, !tbaa !21
  br i1 %t69, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb57
bb55:
  %t70 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t72 = call i1 @compiler_2ftypes_2eIsIntName(ptr %v0, { i64, ptr } %t70)
  store i1 %t72, ptr %l44
  br label %bb56
bb56:
  %t73 = load i1, ptr %l44, !tbaa !21
  store i1 %t73, ptr %l42, !tbaa !21
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load i1, ptr %l42, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fnames_2eLoneCatchName(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 5
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Catch", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp ne i64 %t13, 1
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Catch", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr ptr, ptr %t23, i64 0
  %t25 = load ptr, ptr %t24, !tbaa !39
  %t27 = getelementptr %"compiler/ast:Path", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp ne i64 %t30, 1
  store i1 %t32, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l10, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load i32, ptr %l1, !range !{i32 0, i32 9}
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t43 = load i32, ptr %l1, !range !{i32 0, i32 9}
  %t45 = trunc i64 7 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l21, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t51 = load i32, ptr %l1, !range !{i32 0, i32 9}
  %t53 = trunc i64 8 to i32
  %t54 = icmp eq i32 %t51, %t53
  %t56 = xor i1 %t54, true
  store i1 %t56, ptr %l25, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l25, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fnames_2eMentions(ptr %v0, ptr %v1, { i64, ptr } %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l19 = alloca i64
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l51 = alloca i1
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l60 = alloca i1
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l75 = alloca i1
  %l78 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t22 = icmp sle i64 %t16, %t19
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = sext i32 %t25 to i64
  store i64 %t27, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = add i64 %t36, %t39
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp sle i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb8, label %bb9
bb8:
  br label %bb39
bb9:
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 %t51
  %t56 = load i8, ptr %t55, !tbaa !32
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t57, ptr %l35, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 0
  %t61 = load i8, ptr %t60, !tbaa !32
  %t64 = icmp ne i8 %t56, %t61
  br i1 %t64, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb20
bb12:
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t66, ptr %l39, !tbaa !27
  %t67 = load i64, ptr %l5, !tbaa !24
  store i64 %t67, ptr %l40, !tbaa !24
  %t68 = load i64, ptr %l5, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t74 = add i64 %t68, %t71
  store i64 %t74, ptr %l44, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l45, !tbaa !24
  %t77 = load i64, ptr %l40, !tbaa !24
  %t78 = icmp sge i64 %t77, 0
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t80 = load i64, ptr %l40, !tbaa !24
  %t81 = load i64, ptr %l44, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  br i1 %t82, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_fb93c458ab7e801d_1c40062d0c03aab1)
  unreachable
bb15:
  %t84 = load i64, ptr %l44, !tbaa !24
  %t85 = load i64, ptr %l45, !tbaa !24
  %t86 = icmp sle i64 %t84, %t85
  br i1 %t86, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_fb93c458ab7e801d_1c40062d0c03aab1)
  unreachable
bb17:
  %t88 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l40, !tbaa !24
  %t91 = load i64, ptr %l44, !tbaa !24
  %t92 = getelementptr i8, ptr %t89, i64 %t90
  %t93 = sub i64 %t91, %t90
  %t94 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t95, { i64, ptr } %t96)
  store i1 %t99, ptr %l51
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_fb93c458ab7e801d_1c40062d0c03aab1)
  unreachable
bb19:
  %t100 = load i1, ptr %l51, !tbaa !21
  %t101 = xor i1 %t100, true
  store i1 %t101, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t103 = load i1, ptr %l38, !tbaa !21
  br i1 %t103, label %bb21, label %bb22
bb21:
  br label %bb38
bb22:
  br label %bb23
bb23:
  %t104 = load i64, ptr %l5, !tbaa !24
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb24, label %bb25
bb24:
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t108, ptr %l56, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t109, 1
  %t113 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t118 = call i1 @compiler_2fnames_2eidentChar(i8 %t116)
  store i1 %t118, ptr %l60
  br label %bb26
bb25:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb27
bb26:
  %t119 = load i1, ptr %l60, !tbaa !21
  store i1 %t119, ptr %l55, !tbaa !21
  br label %bb27
bb27:
  %t120 = load i1, ptr %l55, !tbaa !21
  store i1 %t120, ptr %l6, !tbaa !21
  %t121 = load i64, ptr %l5, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t127 = add i64 %t121, %t124
  %t128 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t133 = icmp slt i64 %t127, %t130
  br i1 %t133, label %bb28, label %bb29
bb28:
  %t135 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t135, ptr %l69, !tbaa !27
  %t136 = load i64, ptr %l5, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t142 = add i64 %t136, %t139
  %t144 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i8, ptr %t145, i64 %t142
  %t147 = load i8, ptr %t146, !tbaa !32
  %t149 = call i1 @compiler_2fnames_2eidentChar(i8 %t147)
  store i1 %t149, ptr %l75
  br label %bb30
bb29:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb31
bb30:
  %t150 = load i1, ptr %l75, !tbaa !21
  store i1 %t150, ptr %l68, !tbaa !21
  br label %bb31
bb31:
  %t151 = load i1, ptr %l68, !tbaa !21
  store i1 %t151, ptr %l7, !tbaa !21
  %t152 = load i1, ptr %l6, !tbaa !21
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb32, label %bb33
bb32:
  %t156 = load i1, ptr %l7, !tbaa !21
  %t158 = xor i1 %t156, true
  store i1 %t158, ptr %l78, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb34
bb34:
  %t160 = load i1, ptr %l78, !tbaa !21
  br i1 %t160, label %bb35, label %bb36
bb35:
  store i1 true, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t162 = load i64, ptr %l5, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l5, !tbaa !24
  br label %bb7
bb39:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eDecideTop(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l38 = alloca i64
  %l48 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca %"compiler/names:Table"
  %l83 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l118 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l131 = alloca i1
  %l141 = alloca %"compiler/source:Span"
  %l163 = alloca i64
  %l167 = alloca i64
  %l170 = alloca i64
  %l188 = alloca ptr
  %l189 = alloca i64
  %l194 = alloca ptr
  %l203 = alloca i64
  %l207 = alloca i64
  %l210 = alloca i64
  %l232 = alloca ptr
  %l237 = alloca ptr
  %l238 = alloca i64
  %l243 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l38
  br label %bb1
bb1:
  %t9 = load i64, ptr %l38, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/names:Resolver", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i32, ptr %l2, !tbaa !23
  %t16 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %t13, i64 %t14, i32 %t15, i64 %t16)
  br label %bb2
bb2:
  %t21 = load i64, ptr %l4, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/names:Resolver", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 5
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l48
  br label %bb3
bb3:
  %t31 = load i64, ptr %l48, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb4, label %bb5
bb4:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb9
bb6:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l55, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb8
bb8:
  %t58 = load i64, ptr %l55, !tbaa !24
  store i64 %t58, ptr %l52, !tbaa !24
  br label %bb9
bb9:
  %t59 = load i64, ptr %l52, !tbaa !24
  store i64 %t59, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  %t60 = load i64, ptr %l9, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  br label %bb13
bb13:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l10, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/names:Resolver", ptr %t78, i32 0, i32 1
  store ptr %t80, ptr %l74, !tbaa !29
  %t81 = call %"compiler/names:Table" @compiler_2fnames_3aTable_2ector(ptr %v0)
  store %"compiler/names:Table" %t81, ptr %l75
  br label %bb14
bb14:
  %t82 = load %"compiler/names:Table", ptr %l75
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/names:Table" %t82, ptr %t83
  %t84 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H945cb5faf347f41d89f6885b75263baa(ptr %v0, ptr %v0, ptr %t84, ptr %t83)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l9, !tbaa !24
  br label %bb10
bb17:
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l11, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/names:Resolver", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/load:Loader", ptr %t95, i32 0, i32 5
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t97)
  store i64 %t99, ptr %l83
  br label %bb18
bb18:
  %t100 = load i64, ptr %l83, !tbaa !24
  store i64 %t100, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t101 = load i64, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb19, label %bb20
bb19:
  %t107 = load i64, ptr %l13, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb24
bb21:
  %t111 = load i64, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l13, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l13, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l90, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb23
bb23:
  %t127 = load i64, ptr %l90, !tbaa !24
  store i64 %t127, ptr %l87, !tbaa !24
  br label %bb24
bb24:
  %t128 = load i64, ptr %l87, !tbaa !24
  store i64 %t128, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb25
bb25:
  %t129 = load i64, ptr %l15, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t137 = load i64, ptr %l11, !tbaa !24
  %t138 = load i64, ptr %l15, !tbaa !24
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = mul i64 %t138, %t139
  %t145 = add i64 %t137, %t142
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etableOf(ptr %v0, ptr %t147, i64 %t145)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t151 = load i64, ptr %l15, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l15, !tbaa !24
  br label %bb25
bb31:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasesOf(ptr %v0, ptr %t155, i64 %t156)
  br label %bb32
bb32:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/names:Resolver", ptr %t159, i32 0, i32 0
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/load:Loader", ptr %t162, i32 0, i32 5
  %t165 = load i64, ptr %l1, !tbaa !24
  %t168 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t164, i64 %t165)
  store ptr %t168, ptr %l118
  br label %bb33
bb33:
  %t169 = load ptr, ptr %l118, !tbaa !29
  %t172 = getelementptr %"compiler/load:Module", ptr %t169, i32 0, i32 8
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l20, !tbaa !24
  br label %bb34
bb34:
  %t179 = load i64, ptr %l19, !tbaa !24
  %t180 = load i64, ptr %l20, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb35, label %bb36
bb35:
  br label %bb60
bb36:
  br label %bb37
bb37:
  %t187 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t187, ptr %l127, !tbaa !27
  %t188 = load i64, ptr %l19, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr ptr, ptr %t191, i64 %t188
  %t193 = load ptr, ptr %t192, !tbaa !39
  store ptr %t193, ptr %l21, !tbaa !29
  %t195 = load ptr, ptr %l21, !tbaa !29
  store ptr %t195, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t196 = load ptr, ptr %l130, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb38, label %bb39
bb38:
  %t199 = load ptr, ptr %l130, !tbaa !29
  %t200 = load i64, ptr %t199, !range !{i64 0, i64 11}
  %t202 = icmp eq i64 %t200, 7
  store i1 %t202, ptr %l131, !tbaa !21
  br label %bb39
bb39:
  %t203 = load i1, ptr %l131, !tbaa !21
  br i1 %t203, label %bb40, label %bb41
bb40:
  %t204 = load ptr, ptr %l21, !tbaa !29
  %t206 = getelementptr { i64, [6 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", ptr }, ptr %t206, i32 0, i32 1
  %t208 = load ptr, ptr %t207
  store ptr %t208, ptr %l22, !tbaa !29
  br label %bb42
bb41:
  br label %bb53
bb42:
  %t210 = load ptr, ptr %l22, !tbaa !29
  %t212 = getelementptr %"compiler/ast:TopIf", ptr %t210, i32 0, i32 0
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  br i1 %t215, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_e4f618869538c748_3c1fb892daabce2c)
  unreachable
bb44:
  br label %bb45
bb45:
  %t217 = load ptr, ptr %l22, !tbaa !29
  %t219 = getelementptr %"compiler/ast:TopIf", ptr %t217, i32 0, i32 0
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t220)
  store %"compiler/source:Span" %t222, ptr %l141
  br label %bb46
bb46:
  %t223 = getelementptr %"compiler/source:Span", ptr %l141, i32 0, i32 0
  %t224 = load i32, ptr %t223, !tbaa !23
  %t225 = load i32, ptr %l2, !tbaa !23
  %t228 = icmp eq i32 %t224, %t225
  br i1 %t228, label %bb47, label %bb48
bb47:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l1, !tbaa !24
  %t232 = load ptr, ptr %l22, !tbaa !29
  %t233 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollectIf(ptr %v0, ptr %v0, ptr %t230, i64 %t231, ptr %t232, i64 %t233, i64 0)
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i64, ptr %l1, !tbaa !24
  %t240 = load ptr, ptr %l22, !tbaa !29
  %t241 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedIf(ptr %v0, ptr %v0, ptr %t238, i64 %t239, ptr %t240, i64 %t241, i64 0)
  br label %bb50
bb50:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load i64, ptr %l1, !tbaa !24
  %t248 = load ptr, ptr %l22, !tbaa !29
  %t249 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodiesIf(ptr %v0, ptr %v0, ptr %t246, i64 %t247, ptr %t248, i64 %t249, i64 0)
  br label %bb51
bb51:
  br label %bb52
bb52:
  br label %bb58
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_8527bf2a1f74a17e_1cb11e6247ae4c42)
  unreachable
bb58:
  br label %bb59
bb59:
  %t254 = load i64, ptr %l19, !tbaa !24
  %t256 = add i64 %t254, 1
  store i64 %t256, ptr %l19, !tbaa !24
  br label %bb34
bb60:
  %t258 = load i64, ptr %l4, !tbaa !24
  store i64 %t258, ptr %l23, !tbaa !24
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/names:Resolver", ptr %t260, i32 0, i32 0
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t265 = getelementptr %"compiler/load:Loader", ptr %t263, i32 0, i32 5
  %t267 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t265)
  store i64 %t267, ptr %l163
  br label %bb61
bb61:
  %t268 = load i64, ptr %l163, !tbaa !24
  store i64 %t268, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t269 = load i64, ptr %l24, !tbaa !24
  %t270 = load i64, ptr %l23, !tbaa !24
  %t273 = icmp sgt i64 %t269, %t270
  br i1 %t273, label %bb62, label %bb63
bb62:
  %t275 = load i64, ptr %l25, !tbaa !24
  %t277 = icmp sgt i64 %t275, 0
  br i1 %t277, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l167, !tbaa !24
  br label %bb67
bb64:
  %t279 = load i64, ptr %l24, !tbaa !24
  %t280 = load i64, ptr %l23, !tbaa !24
  %t283 = sub i64 %t279, %t280
  %t284 = load i64, ptr %l25, !tbaa !24
  %t287 = add i64 %t283, %t284
  %t289 = sub i64 %t287, 1
  %t290 = load i64, ptr %l25, !tbaa !24
  %t293 = sdiv i64 %t289, %t290
  store i64 %t293, ptr %l170, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l170, !tbaa !24
  br label %bb66
bb66:
  %t295 = load i64, ptr %l170, !tbaa !24
  store i64 %t295, ptr %l167, !tbaa !24
  br label %bb67
bb67:
  %t296 = load i64, ptr %l167, !tbaa !24
  store i64 %t296, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb68
bb68:
  %t297 = load i64, ptr %l27, !tbaa !24
  %t298 = load i64, ptr %l26, !tbaa !24
  %t301 = icmp slt i64 %t297, %t298
  %t303 = xor i1 %t301, true
  br i1 %t303, label %bb69, label %bb70
bb69:
  br label %bb75
bb70:
  br label %bb71
bb71:
  %t305 = load i64, ptr %l23, !tbaa !24
  %t306 = load i64, ptr %l27, !tbaa !24
  %t307 = load i64, ptr %l25, !tbaa !24
  %t310 = mul i64 %t306, %t307
  %t313 = add i64 %t305, %t310
  store i64 %t313, ptr %l28, !tbaa !24
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l188, !tbaa !29
  %t316 = load i64, ptr %l28, !tbaa !24
  store i64 %t316, ptr %l189, !tbaa !24
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/names:Resolver", ptr %t317, i32 0, i32 0
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = getelementptr %"compiler/load:Loader", ptr %t320, i32 0, i32 5
  %t323 = load i64, ptr %l28, !tbaa !24
  %t326 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t322, i64 %t323)
  store ptr %t326, ptr %l194
  br label %bb72
bb72:
  %t327 = load ptr, ptr %l194, !tbaa !29
  %t329 = getelementptr %"compiler/load:Module", ptr %t327, i32 0, i32 8
  %t330 = load { i64, ptr }, ptr %t329, !tbaa !27
  %t331 = load ptr, ptr %l188, !tbaa !29
  %t332 = load i64, ptr %l189, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedErrors(ptr %v0, ptr %v0, ptr %t331, i64 %t332, { i64, ptr } %t330)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t334 = load i64, ptr %l27, !tbaa !24
  %t336 = add i64 %t334, 1
  store i64 %t336, ptr %l27, !tbaa !24
  br label %bb68
bb75:
  %t338 = load i64, ptr %l4, !tbaa !24
  store i64 %t338, ptr %l29, !tbaa !24
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/names:Resolver", ptr %t340, i32 0, i32 0
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t345 = getelementptr %"compiler/load:Loader", ptr %t343, i32 0, i32 5
  %t347 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t345)
  store i64 %t347, ptr %l203
  br label %bb76
bb76:
  %t348 = load i64, ptr %l203, !tbaa !24
  store i64 %t348, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t349 = load i64, ptr %l30, !tbaa !24
  %t350 = load i64, ptr %l29, !tbaa !24
  %t353 = icmp sgt i64 %t349, %t350
  br i1 %t353, label %bb77, label %bb78
bb77:
  %t355 = load i64, ptr %l31, !tbaa !24
  %t357 = icmp sgt i64 %t355, 0
  br i1 %t357, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb82
bb79:
  %t359 = load i64, ptr %l30, !tbaa !24
  %t360 = load i64, ptr %l29, !tbaa !24
  %t363 = sub i64 %t359, %t360
  %t364 = load i64, ptr %l31, !tbaa !24
  %t367 = add i64 %t363, %t364
  %t369 = sub i64 %t367, 1
  %t370 = load i64, ptr %l31, !tbaa !24
  %t373 = sdiv i64 %t369, %t370
  store i64 %t373, ptr %l210, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l210, !tbaa !24
  br label %bb81
bb81:
  %t375 = load i64, ptr %l210, !tbaa !24
  store i64 %t375, ptr %l207, !tbaa !24
  br label %bb82
bb82:
  %t376 = load i64, ptr %l207, !tbaa !24
  store i64 %t376, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb83
bb83:
  %t377 = load i64, ptr %l33, !tbaa !24
  %t378 = load i64, ptr %l32, !tbaa !24
  %t381 = icmp slt i64 %t377, %t378
  %t383 = xor i1 %t381, true
  br i1 %t383, label %bb84, label %bb85
bb84:
  br label %bb94
bb85:
  br label %bb86
bb86:
  %t385 = load i64, ptr %l29, !tbaa !24
  %t386 = load i64, ptr %l33, !tbaa !24
  %t387 = load i64, ptr %l31, !tbaa !24
  %t390 = mul i64 %t386, %t387
  %t393 = add i64 %t385, %t390
  store i64 %t393, ptr %l34, !tbaa !24
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/names:Resolver", ptr %t395, i32 0, i32 0
  %t398 = load ptr, ptr %t397, !tbaa !29
  %t400 = getelementptr %"compiler/load:Loader", ptr %t398, i32 0, i32 5
  %t401 = load i64, ptr %l34, !tbaa !24
  %t404 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t400, i64 %t401)
  store ptr %t404, ptr %l232
  br label %bb87
bb87:
  %t405 = load ptr, ptr %l232, !tbaa !29
  %t407 = getelementptr %"compiler/load:Module", ptr %t405, i32 0, i32 8
  %t408 = load { i64, ptr }, ptr %t407, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t412 = icmp sgt i64 %t410, 0
  br i1 %t412, label %bb88, label %bb89
bb88:
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l237, !tbaa !29
  %t415 = load i64, ptr %l34, !tbaa !24
  store i64 %t415, ptr %l238, !tbaa !24
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/names:Resolver", ptr %t416, i32 0, i32 0
  %t419 = load ptr, ptr %t418, !tbaa !29
  %t421 = getelementptr %"compiler/load:Loader", ptr %t419, i32 0, i32 5
  %t422 = load i64, ptr %l34, !tbaa !24
  %t425 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t421, i64 %t422)
  store ptr %t425, ptr %l243
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t426 = load ptr, ptr %l243, !tbaa !29
  %t428 = getelementptr %"compiler/load:Module", ptr %t426, i32 0, i32 8
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  %t430 = load ptr, ptr %l237, !tbaa !29
  %t431 = load i64, ptr %l238, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v0, ptr %t430, i64 %t431, { i64, ptr } %t429)
  br label %bb91
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t433 = load i64, ptr %l33, !tbaa !24
  %t435 = add i64 %t433, 1
  store i64 %t435, ptr %l33, !tbaa !24
  br label %bb83
bb94:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eImportSaid(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l18 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 15
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Hd32f6fdf378a1d4c0e47f8552643012d(ptr %v0, ptr %t15, i64 %t16)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l14
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t20, ptr %l4
  %t21 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l4, i32 0, i32 0
  %t22 = load i32, ptr %t21, !tbaa !23
  %t26 = icmp eq i32 %t22, %a1
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l4, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp eq i64 %t29, -1
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eLocalSpan(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/names:local"
  %l16 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 7
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/names:Resolver", ptr %t16, i32 0, i32 7
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t18, i64 %t19)
  store %"compiler/names:local" %t22, ptr %l14
  br label %bb7
bb6:
  %t23 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t23, ptr %l16
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/names:local", ptr %l14, i32 0, i32 1
  %t25 = load %"compiler/source:Span", ptr %t24
  store %"compiler/source:Span" %t25, ptr %l10
  br label %bb9
bb8:
  %t27 = load %"compiler/source:Span", ptr %l16
  store %"compiler/source:Span" %t27, ptr %l10
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca i32
  %l12 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 5
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = call i64 @compiler_2fnames_2ekey(i64 %a1, i32 %a2)
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = call { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eG_Hb4f204ca9d50eb43e30fe8770cb15d1a(ptr %v0, ptr %t9, i64 %t10)
  %t12 = extractvalue { i32, %"compiler/names:Ref" } %t11, 1
  %t13 = extractvalue { i32, %"compiler/names:Ref" } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store %"compiler/names:Ref" %t12, ptr %l9
  br label %bb2
bb2:
  %t16 = load %"compiler/names:Ref", ptr %l9
  store %"compiler/names:Ref" %t16, ptr %l3
  br label %bb6
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t18 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t18, ptr %l12
  br label %bb5
bb5:
  %t19 = load %"compiler/names:Ref", ptr %l12
  store %"compiler/names:Ref" %t19, ptr %l3
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load %"compiler/names:Ref", ptr %l3
  store %"compiler/names:Ref" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l18 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l19 = alloca %"compiler/names:Entry"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l48 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca %"compiler/names:Table"
  %l82 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i64
  %l111 = alloca ptr
  %l121 = alloca ptr
  %l124 = alloca i64
  %l126 = alloca i64
  %l131 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l134 = alloca i1
  %l136 = alloca ptr
  %l141 = alloca i32
  %l148 = alloca ptr
  %l151 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l152 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l154 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l155 = alloca i32
  %l157 = alloca i1
  %l161 = alloca ptr
  %l165 = alloca %"compiler/names:Entry"
  %l168 = alloca i1
  %l171 = alloca i1
  %l174 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l177 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i32
  %l184 = alloca %"compiler/names:Ref"
  %l190 = alloca i64
  %l194 = alloca i64
  %l197 = alloca i64
  %l219 = alloca ptr
  %l230 = alloca i64
  %l234 = alloca i64
  %l237 = alloca i64
  %l255 = alloca ptr
  %l256 = alloca i64
  %l261 = alloca ptr
  %l269 = alloca i64
  %l273 = alloca i64
  %l276 = alloca i64
  %l298 = alloca ptr
  %l312 = alloca i64
  %l316 = alloca i64
  %l319 = alloca i64
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l48
  br label %bb1
bb1:
  %t9 = load i64, ptr %l48, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb7
bb4:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load i64, ptr %l1, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l55, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l55, !tbaa !24
  store i64 %t36, ptr %l52, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l52, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l6, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/names:Resolver", ptr %t56, i32 0, i32 1
  store ptr %t58, ptr %l74, !tbaa !29
  %t59 = call %"compiler/names:Table" @compiler_2fnames_3aTable_2ector(ptr %v0)
  store %"compiler/names:Table" %t59, ptr %l75
  br label %bb12
bb12:
  %t60 = load %"compiler/names:Table", ptr %l75
  %t61 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/names:Table" %t60, ptr %t61
  %t62 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H945cb5faf347f41d89f6885b75263baa(ptr %v0, ptr %v0, ptr %t62, ptr %t61)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l5, !tbaa !24
  br label %bb8
bb15:
  store i64 0, ptr %l7, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/names:Resolver", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 5
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t73)
  store i64 %t75, ptr %l82
  br label %bb16
bb16:
  %t76 = load i64, ptr %l82, !tbaa !24
  store i64 %t76, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp sgt i64 %t77, %t78
  br i1 %t81, label %bb17, label %bb18
bb17:
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = icmp sgt i64 %t83, 0
  br i1 %t85, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb22
bb19:
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  store i64 %t101, ptr %l89, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb21
bb21:
  %t103 = load i64, ptr %l89, !tbaa !24
  store i64 %t103, ptr %l86, !tbaa !24
  br label %bb22
bb22:
  %t104 = load i64, ptr %l86, !tbaa !24
  store i64 %t104, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  %t105 = load i64, ptr %l11, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb24, label %bb25
bb24:
  br label %bb72
bb25:
  br label %bb26
bb26:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = mul i64 %t114, %t115
  %t121 = add i64 %t113, %t118
  store i64 %t121, ptr %l12, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/names:Resolver", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/load:Loader", ptr %t126, i32 0, i32 5
  %t129 = load i64, ptr %l12, !tbaa !24
  %t132 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t128, i64 %t129)
  store ptr %t132, ptr %l111
  br label %bb27
bb27:
  %t133 = load ptr, ptr %l111, !tbaa !29
  %t136 = getelementptr %"compiler/load:Module", ptr %t133, i32 0, i32 3
  %t137 = load i1, ptr %t136, !tbaa !21
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb28, label %bb29
bb28:
  br label %bb71
bb29:
  br label %bb30
bb30:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etableOf(ptr %v0, ptr %t141, i64 %t142)
  br label %bb31
bb31:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/names:Resolver", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/load:Loader", ptr %t148, i32 0, i32 5
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t150, i64 %t151)
  store ptr %t154, ptr %l121
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l121, !tbaa !29
  %t157 = getelementptr %"compiler/load:Module", ptr %t155, i32 0, i32 9
  store ptr %t157, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb33
bb33:
  %t159 = load i64, ptr %l15, !tbaa !24
  store i64 %t159, ptr %l124, !tbaa !24
  %t160 = load ptr, ptr %l14, !tbaa !29
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t160)
  store i64 %t162, ptr %l126
  br label %bb34
bb34:
  %t163 = load i64, ptr %l124, !tbaa !24
  %t164 = load i64, ptr %l126, !tbaa !24
  %t165 = icmp slt i64 %t163, %t164
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb35, label %bb36
bb35:
  br label %bb46
bb36:
  br label %bb37
bb37:
  %t169 = load ptr, ptr %l14, !tbaa !29
  %t170 = load i64, ptr %l15, !tbaa !24
  %t173 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t169, i64 %t170)
  store { i64, ptr } %t173, ptr %l131
  br label %bb38
bb38:
  %t174 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t174, ptr %l16, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t175, ptr %l132, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 0
  %t179 = load i8, ptr %t178, !tbaa !32
  %t181 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t179)
  store i1 %t181, ptr %l134
  br label %bb39
bb39:
  %t182 = load i1, ptr %l134, !tbaa !21
  br i1 %t182, label %bb40, label %bb41
bb40:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/names:Resolver", ptr %t183, i32 0, i32 2
  store ptr %t185, ptr %l136, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/names:Resolver", ptr %t186, i32 0, i32 0
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/load:Loader", ptr %t189, i32 0, i32 3
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t193 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t196 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t192, { i64, ptr } %t193)
  store i32 %t196, ptr %l141
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t197 = load i64, ptr %l12, !tbaa !24
  %t198 = load ptr, ptr %l136, !tbaa !29
  %t199 = load i32, ptr %l141, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t198, i32 %t199, i64 %t197)
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t201 = load i64, ptr %l15, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l15, !tbaa !24
  br label %bb33
bb46:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/names:Resolver", ptr %t205, i32 0, i32 1
  %t208 = load i64, ptr %l12, !tbaa !24
  %t211 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t207, i64 %t208)
  store ptr %t211, ptr %l148
  br label %bb47
bb47:
  %t212 = load ptr, ptr %l148, !tbaa !29
  %t214 = getelementptr %"compiler/names:Table", ptr %t212, i32 0, i32 1
  %t216 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v0, ptr %t214)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t216, ptr %l151
  br label %bb48
bb48:
  %t217 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l151
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t217, ptr %l17
  br label %bb49
bb49:
  %t219 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %l17)
  %t220 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t219, 1
  %t221 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t219, 0
  store i32 %t221, ptr %l155
  %t222 = icmp ne i32 %t221, 0
  br i1 %t222, label %bb51, label %ok.223, !prof !99
ok.223:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t220, ptr %l154
  br label %bb50
bb50:
  %t224 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l154
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t224, ptr %l152
  br label %bb53
bb51:
  %t225 = load i32, ptr %l155, !tbaa !23
  %t226 = ashr i32 %t225, 16
  %t228 = icmp eq i32 %t226, 1
  store i1 %t228, ptr %l157, !tbaa !21
  br label %bb52
bb52:
  call void @__olang_ert_req_clear()
  br label %bb70
bb53:
  %t229 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l152
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t229, ptr %l18
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/names:Resolver", ptr %t230, i32 0, i32 1
  %t233 = load i64, ptr %l12, !tbaa !24
  %t236 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t232, i64 %t233)
  store ptr %t236, ptr %l161
  br label %bb54
bb54:
  %t237 = load ptr, ptr %l161, !tbaa !29
  %t239 = getelementptr %"compiler/names:Table", ptr %t237, i32 0, i32 0
  %t240 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l18, i32 0, i32 1
  %t241 = load i64, ptr %t240, !tbaa !24
  %t244 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t239, i64 %t241)
  store %"compiler/names:Entry" %t244, ptr %l165
  br label %bb55
bb55:
  %t245 = load %"compiler/names:Entry", ptr %l165
  store %"compiler/names:Entry" %t245, ptr %l19
  %t246 = getelementptr %"compiler/names:Entry", ptr %l19, i32 0, i32 2
  %t247 = load i32, ptr %t246, !range !{i32 0, i32 9}
  %t249 = trunc i64 2 to i32
  %t250 = icmp eq i32 %t247, %t249
  br i1 %t250, label %bb56, label %bb57
bb56:
  %t252 = getelementptr %"compiler/names:Entry", ptr %l19, i32 0, i32 3
  %t253 = load i1, ptr %t252, !tbaa !21
  %t255 = xor i1 %t253, true
  store i1 %t255, ptr %l168, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb58
bb58:
  %t257 = load i1, ptr %l168, !tbaa !21
  br i1 %t257, label %bb59, label %bb60
bb59:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l18, i32 0, i32 0
  %t260 = load i32, ptr %t259, !tbaa !23
  %t263 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t258, i32 %t260)
  store { i64, ptr } %t263, ptr %l174
  br label %bb61
bb60:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb63
bb61:
  %t264 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t264, ptr %l175, !tbaa !27
  %t265 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr i8, ptr %t266, i64 0
  %t268 = load i8, ptr %t267, !tbaa !32
  %t270 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t268)
  store i1 %t270, ptr %l177
  br label %bb62
bb62:
  %t271 = load i1, ptr %l177, !tbaa !21
  store i1 %t271, ptr %l171, !tbaa !21
  br label %bb63
bb63:
  %t272 = load i1, ptr %l171, !tbaa !21
  br i1 %t272, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s13
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/names:Resolver", ptr %t273, i32 0, i32 3
  store ptr %t275, ptr %l179, !tbaa !29
  %t276 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l18, i32 0, i32 0
  %t277 = load i32, ptr %t276, !tbaa !23
  store i32 %t277, ptr %l180, !tbaa !23
  %t278 = load i64, ptr %l12, !tbaa !24
  %t279 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l18, i32 0, i32 1
  %t280 = load i64, ptr %t279, !tbaa !24
  %t284 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s13, i32 2, i64 %t278, i64 %t280)
  store %"compiler/names:Ref" %t284, ptr %l184
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t285 = load ptr, ptr %l179, !tbaa !29
  %t286 = load i32, ptr %l180, !tbaa !23
  %t287 = load %"compiler/names:Ref", ptr %l184
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H456f40e55a35e282608933ec0991ad61(ptr %v0, ptr %t285, i32 %t286, %"compiler/names:Ref" %t287)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb49
bb70:
  br label %bb71
bb71:
  %t288 = load i64, ptr %l11, !tbaa !24
  %t290 = add i64 %t288, 1
  store i64 %t290, ptr %l11, !tbaa !24
  br label %bb23
bb72:
  store i64 0, ptr %l20, !tbaa !24
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/names:Resolver", ptr %t292, i32 0, i32 0
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/load:Loader", ptr %t295, i32 0, i32 5
  %t299 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t297)
  store i64 %t299, ptr %l190
  br label %bb73
bb73:
  %t300 = load i64, ptr %l190, !tbaa !24
  store i64 %t300, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t301 = load i64, ptr %l21, !tbaa !24
  %t302 = load i64, ptr %l20, !tbaa !24
  %t305 = icmp sgt i64 %t301, %t302
  br i1 %t305, label %bb74, label %bb75
bb74:
  %t307 = load i64, ptr %l22, !tbaa !24
  %t309 = icmp sgt i64 %t307, 0
  br i1 %t309, label %bb76, label %bb77
bb75:
  store i64 0, ptr %l194, !tbaa !24
  br label %bb79
bb76:
  %t311 = load i64, ptr %l21, !tbaa !24
  %t312 = load i64, ptr %l20, !tbaa !24
  %t315 = sub i64 %t311, %t312
  %t316 = load i64, ptr %l22, !tbaa !24
  %t319 = add i64 %t315, %t316
  %t321 = sub i64 %t319, 1
  %t322 = load i64, ptr %l22, !tbaa !24
  %t325 = sdiv i64 %t321, %t322
  store i64 %t325, ptr %l197, !tbaa !24
  br label %bb78
bb77:
  store i64 0, ptr %l197, !tbaa !24
  br label %bb78
bb78:
  %t327 = load i64, ptr %l197, !tbaa !24
  store i64 %t327, ptr %l194, !tbaa !24
  br label %bb79
bb79:
  %t328 = load i64, ptr %l194, !tbaa !24
  store i64 %t328, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb80
bb80:
  %t329 = load i64, ptr %l24, !tbaa !24
  %t330 = load i64, ptr %l23, !tbaa !24
  %t333 = icmp slt i64 %t329, %t330
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb81, label %bb82
bb81:
  br label %bb90
bb82:
  br label %bb83
bb83:
  %t337 = load i64, ptr %l20, !tbaa !24
  %t338 = load i64, ptr %l24, !tbaa !24
  %t339 = load i64, ptr %l22, !tbaa !24
  %t342 = mul i64 %t338, %t339
  %t345 = add i64 %t337, %t342
  store i64 %t345, ptr %l25, !tbaa !24
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/names:Resolver", ptr %t347, i32 0, i32 0
  %t350 = load ptr, ptr %t349, !tbaa !29
  %t352 = getelementptr %"compiler/load:Loader", ptr %t350, i32 0, i32 5
  %t353 = load i64, ptr %l25, !tbaa !24
  %t356 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t352, i64 %t353)
  store ptr %t356, ptr %l219
  br label %bb84
bb84:
  %t357 = load ptr, ptr %l219, !tbaa !29
  %t359 = getelementptr %"compiler/load:Module", ptr %t357, i32 0, i32 3
  %t360 = load i1, ptr %t359, !tbaa !21
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb85, label %bb86
bb85:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load i64, ptr %l25, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etableOf(ptr %v0, ptr %t364, i64 %t365)
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t368 = load i64, ptr %l24, !tbaa !24
  %t370 = add i64 %t368, 1
  store i64 %t370, ptr %l24, !tbaa !24
  br label %bb80
bb90:
  store i64 0, ptr %l26, !tbaa !24
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/names:Resolver", ptr %t372, i32 0, i32 0
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t377 = getelementptr %"compiler/load:Loader", ptr %t375, i32 0, i32 5
  %t379 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t377)
  store i64 %t379, ptr %l230
  br label %bb91
bb91:
  %t380 = load i64, ptr %l230, !tbaa !24
  store i64 %t380, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t381 = load i64, ptr %l27, !tbaa !24
  %t382 = load i64, ptr %l26, !tbaa !24
  %t385 = icmp sgt i64 %t381, %t382
  br i1 %t385, label %bb92, label %bb93
bb92:
  %t387 = load i64, ptr %l28, !tbaa !24
  %t389 = icmp sgt i64 %t387, 0
  br i1 %t389, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l234, !tbaa !24
  br label %bb97
bb94:
  %t391 = load i64, ptr %l27, !tbaa !24
  %t392 = load i64, ptr %l26, !tbaa !24
  %t395 = sub i64 %t391, %t392
  %t396 = load i64, ptr %l28, !tbaa !24
  %t399 = add i64 %t395, %t396
  %t401 = sub i64 %t399, 1
  %t402 = load i64, ptr %l28, !tbaa !24
  %t405 = sdiv i64 %t401, %t402
  store i64 %t405, ptr %l237, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l237, !tbaa !24
  br label %bb96
bb96:
  %t407 = load i64, ptr %l237, !tbaa !24
  store i64 %t407, ptr %l234, !tbaa !24
  br label %bb97
bb97:
  %t408 = load i64, ptr %l234, !tbaa !24
  store i64 %t408, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb98
bb98:
  %t409 = load i64, ptr %l30, !tbaa !24
  %t410 = load i64, ptr %l29, !tbaa !24
  %t413 = icmp slt i64 %t409, %t410
  %t415 = xor i1 %t413, true
  br i1 %t415, label %bb99, label %bb100
bb99:
  br label %bb105
bb100:
  br label %bb101
bb101:
  %t417 = load i64, ptr %l26, !tbaa !24
  %t418 = load i64, ptr %l30, !tbaa !24
  %t419 = load i64, ptr %l28, !tbaa !24
  %t422 = mul i64 %t418, %t419
  %t425 = add i64 %t417, %t422
  store i64 %t425, ptr %l31, !tbaa !24
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l255, !tbaa !29
  %t428 = load i64, ptr %l31, !tbaa !24
  store i64 %t428, ptr %l256, !tbaa !24
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/names:Resolver", ptr %t429, i32 0, i32 0
  %t432 = load ptr, ptr %t431, !tbaa !29
  %t434 = getelementptr %"compiler/load:Loader", ptr %t432, i32 0, i32 5
  %t435 = load i64, ptr %l31, !tbaa !24
  %t438 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t434, i64 %t435)
  store ptr %t438, ptr %l261
  br label %bb102
bb102:
  %t439 = load ptr, ptr %l261, !tbaa !29
  %t441 = getelementptr %"compiler/load:Module", ptr %t439, i32 0, i32 8
  %t442 = load { i64, ptr }, ptr %t441, !tbaa !27
  %t443 = load ptr, ptr %l255, !tbaa !29
  %t444 = load i64, ptr %l256, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedErrors(ptr %v0, ptr %v0, ptr %t443, i64 %t444, { i64, ptr } %t442)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t446 = load i64, ptr %l30, !tbaa !24
  %t448 = add i64 %t446, 1
  store i64 %t448, ptr %l30, !tbaa !24
  br label %bb98
bb105:
  store i64 0, ptr %l32, !tbaa !24
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/names:Resolver", ptr %t450, i32 0, i32 0
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t455 = getelementptr %"compiler/load:Loader", ptr %t453, i32 0, i32 5
  %t457 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t455)
  store i64 %t457, ptr %l269
  br label %bb106
bb106:
  %t458 = load i64, ptr %l269, !tbaa !24
  store i64 %t458, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t459 = load i64, ptr %l33, !tbaa !24
  %t460 = load i64, ptr %l32, !tbaa !24
  %t463 = icmp sgt i64 %t459, %t460
  br i1 %t463, label %bb107, label %bb108
bb107:
  %t465 = load i64, ptr %l34, !tbaa !24
  %t467 = icmp sgt i64 %t465, 0
  br i1 %t467, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l273, !tbaa !24
  br label %bb112
bb109:
  %t469 = load i64, ptr %l33, !tbaa !24
  %t470 = load i64, ptr %l32, !tbaa !24
  %t473 = sub i64 %t469, %t470
  %t474 = load i64, ptr %l34, !tbaa !24
  %t477 = add i64 %t473, %t474
  %t479 = sub i64 %t477, 1
  %t480 = load i64, ptr %l34, !tbaa !24
  %t483 = sdiv i64 %t479, %t480
  store i64 %t483, ptr %l276, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l276, !tbaa !24
  br label %bb111
bb111:
  %t485 = load i64, ptr %l276, !tbaa !24
  store i64 %t485, ptr %l273, !tbaa !24
  br label %bb112
bb112:
  %t486 = load i64, ptr %l273, !tbaa !24
  store i64 %t486, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb113
bb113:
  %t487 = load i64, ptr %l36, !tbaa !24
  %t488 = load i64, ptr %l35, !tbaa !24
  %t491 = icmp slt i64 %t487, %t488
  %t493 = xor i1 %t491, true
  br i1 %t493, label %bb114, label %bb115
bb114:
  br label %bb123
bb115:
  br label %bb116
bb116:
  %t495 = load i64, ptr %l32, !tbaa !24
  %t496 = load i64, ptr %l36, !tbaa !24
  %t497 = load i64, ptr %l34, !tbaa !24
  %t500 = mul i64 %t496, %t497
  %t503 = add i64 %t495, %t500
  store i64 %t503, ptr %l37, !tbaa !24
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t507 = getelementptr %"compiler/names:Resolver", ptr %t505, i32 0, i32 0
  %t508 = load ptr, ptr %t507, !tbaa !29
  %t510 = getelementptr %"compiler/load:Loader", ptr %t508, i32 0, i32 5
  %t511 = load i64, ptr %l37, !tbaa !24
  %t514 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t510, i64 %t511)
  store ptr %t514, ptr %l298
  br label %bb117
bb117:
  %t515 = load ptr, ptr %l298, !tbaa !29
  store ptr %t515, ptr %l38, !tbaa !29
  %t516 = load ptr, ptr %l38, !tbaa !29
  %t518 = getelementptr %"compiler/load:Module", ptr %t516, i32 0, i32 8
  %t519 = load { i64, ptr }, ptr %t518, !tbaa !27
  %t521 = extractvalue { i64, ptr } %t519, 0
  %t523 = icmp sgt i64 %t521, 0
  br i1 %t523, label %bb118, label %bb119
bb118:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load i64, ptr %l37, !tbaa !24
  %t527 = load ptr, ptr %l38, !tbaa !29
  %t529 = getelementptr %"compiler/load:Module", ptr %t527, i32 0, i32 8
  %t530 = load { i64, ptr }, ptr %t529, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v0, ptr %t525, i64 %t526, { i64, ptr } %t530)
  br label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb121
bb121:
  br label %bb122
bb122:
  %t534 = load i64, ptr %l36, !tbaa !24
  %t536 = add i64 %t534, 1
  store i64 %t536, ptr %l36, !tbaa !24
  br label %bb113
bb123:
  store i64 0, ptr %l39, !tbaa !24
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t540 = getelementptr %"compiler/names:Resolver", ptr %t538, i32 0, i32 0
  %t541 = load ptr, ptr %t540, !tbaa !29
  %t543 = getelementptr %"compiler/load:Loader", ptr %t541, i32 0, i32 5
  %t545 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t543)
  store i64 %t545, ptr %l312
  br label %bb124
bb124:
  %t546 = load i64, ptr %l312, !tbaa !24
  store i64 %t546, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t547 = load i64, ptr %l40, !tbaa !24
  %t548 = load i64, ptr %l39, !tbaa !24
  %t551 = icmp sgt i64 %t547, %t548
  br i1 %t551, label %bb125, label %bb126
bb125:
  %t553 = load i64, ptr %l41, !tbaa !24
  %t555 = icmp sgt i64 %t553, 0
  br i1 %t555, label %bb127, label %bb128
bb126:
  store i64 0, ptr %l316, !tbaa !24
  br label %bb130
bb127:
  %t557 = load i64, ptr %l40, !tbaa !24
  %t558 = load i64, ptr %l39, !tbaa !24
  %t561 = sub i64 %t557, %t558
  %t562 = load i64, ptr %l41, !tbaa !24
  %t565 = add i64 %t561, %t562
  %t567 = sub i64 %t565, 1
  %t568 = load i64, ptr %l41, !tbaa !24
  %t571 = sdiv i64 %t567, %t568
  store i64 %t571, ptr %l319, !tbaa !24
  br label %bb129
bb128:
  store i64 0, ptr %l319, !tbaa !24
  br label %bb129
bb129:
  %t573 = load i64, ptr %l319, !tbaa !24
  store i64 %t573, ptr %l316, !tbaa !24
  br label %bb130
bb130:
  %t574 = load i64, ptr %l316, !tbaa !24
  store i64 %t574, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb131
bb131:
  %t575 = load i64, ptr %l43, !tbaa !24
  %t576 = load i64, ptr %l42, !tbaa !24
  %t579 = icmp slt i64 %t575, %t576
  %t581 = xor i1 %t579, true
  br i1 %t581, label %bb132, label %bb133
bb132:
  br label %bb137
bb133:
  br label %bb134
bb134:
  %t583 = load i64, ptr %l39, !tbaa !24
  %t584 = load i64, ptr %l43, !tbaa !24
  %t585 = load i64, ptr %l41, !tbaa !24
  %t588 = mul i64 %t584, %t585
  %t591 = add i64 %t583, %t588
  %t593 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunusedImports(ptr %v0, ptr %t593, i64 %t591)
  br label %bb135
bb135:
  br label %bb136
bb136:
  %t597 = load i64, ptr %l43, !tbaa !24
  %t599 = add i64 %t597, 1
  store i64 %t599, ptr %l43, !tbaa !24
  br label %bb131
bb137:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca i32
  %l12 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 4
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = call i64 @compiler_2fnames_2ekey(i64 %a1, i32 %a2)
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = call { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eG_Hb4f204ca9d50eb43e30fe8770cb15d1a(ptr %v0, ptr %t9, i64 %t10)
  %t12 = extractvalue { i32, %"compiler/names:Ref" } %t11, 1
  %t13 = extractvalue { i32, %"compiler/names:Ref" } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store %"compiler/names:Ref" %t12, ptr %l9
  br label %bb2
bb2:
  %t16 = load %"compiler/names:Ref", ptr %l9
  store %"compiler/names:Ref" %t16, ptr %l3
  br label %bb6
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t18 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t18, ptr %l12
  br label %bb5
bb5:
  %t19 = load %"compiler/names:Ref", ptr %l12
  store %"compiler/names:Ref" %t19, ptr %l3
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load %"compiler/names:Ref", ptr %l3
  store %"compiler/names:Ref" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l30 = alloca ptr
  %l34 = alloca { i64, [3 x i64] }
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %l44 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l56 = alloca { i64, [3 x i64] }
  %l59 = alloca { i64, ptr }
  %l61 = alloca %"compiler/msgs:Msg"
  %l62 = alloca i64
  %l64 = alloca i1
  %l67 = alloca ptr
  %l71 = alloca { i64, [3 x i64] }
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"compiler/msgs:Msg"
  %l77 = alloca i64
  %l86 = alloca i1
  %l89 = alloca ptr
  %l93 = alloca { i64, [3 x i64] }
  %l96 = alloca { i64, ptr }
  %l98 = alloca %"compiler/msgs:Msg"
  %l99 = alloca i64
  %l101 = alloca ptr
  %l102 = alloca i32
  %l105 = alloca i64
  %l107 = alloca ptr
  %l112 = alloca %"compiler/names:Entry"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l14, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 5
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l19
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l19, !tbaa !29
  store ptr %t19, ptr %l6, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t24, ptr %l22
  br label %bb3
bb3:
  %t25 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t25, ptr %l7, !tbaa !27
  %t26 = load i32, ptr %l2, !tbaa !23
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t30 = getelementptr %"compiler/names:Table", ptr %t28, i32 0, i32 2
  %t34 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t30, i32 %t26)
  store i1 %t34, ptr %l27
  br label %bb4
bb4:
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/names:Resolver", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/load:Loader", ptr %t39, i32 0, i32 4
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l30, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l1, !tbaa !24
  %t45 = load %"compiler/source:Span", ptr %l3
  %t49 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t43, i64 %t44, %"compiler/source:Span" %t45)
  store { i64, [3 x i64] } %t49, ptr %l34
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t50, i32 %t51)
  store { i64, ptr } %t54, ptr %l37
  br label %bb8
bb8:
  %t55 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t63 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNameInUse(ptr %s1, ptr %s1, { i64, ptr } %t61)
  store %"compiler/msgs:Msg" %t63, ptr %l39
  br label %bb9
bb9:
  %t64 = load ptr, ptr %l30, !tbaa !29
  %t65 = load { i64, [3 x i64] }, ptr %l34
  %t66 = load %"compiler/msgs:Msg", ptr %l39
  %t67 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t64, { i64, [3 x i64] } %t65, %"compiler/msgs:Msg" %t66)
  store i64 %t67, ptr %l40
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb11:
  %t68 = load ptr, ptr %l6, !tbaa !29
  %t70 = getelementptr %"compiler/load:Module", ptr %t68, i32 0, i32 3
  %t71 = load i1, ptr %t70, !tbaa !21
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb12, label %bb13
bb12:
  %t75 = load i32, ptr %l2, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/names:Resolver", ptr %t77, i32 0, i32 2
  %t83 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t79, i32 %t75)
  store i1 %t83, ptr %l49
  br label %bb14
bb13:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb15
bb14:
  %t84 = load i1, ptr %l49, !tbaa !21
  store i1 %t84, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t85 = load i1, ptr %l44, !tbaa !21
  br i1 %t85, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/names:Resolver", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/load:Loader", ptr %t89, i32 0, i32 4
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l52, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l1, !tbaa !24
  %t95 = load %"compiler/source:Span", ptr %l3
  %t99 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t93, i64 %t94, %"compiler/source:Span" %t95)
  store { i64, [3 x i64] } %t99, ptr %l56
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l2, !tbaa !23
  %t104 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t100, i32 %t101)
  store { i64, ptr } %t104, ptr %l59
  br label %bb19
bb19:
  %t105 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %s2, ptr %s2, { i64, ptr } %t111)
  store %"compiler/msgs:Msg" %t113, ptr %l61
  br label %bb20
bb20:
  %t114 = load ptr, ptr %l52, !tbaa !29
  %t115 = load { i64, [3 x i64] }, ptr %l56
  %t116 = load %"compiler/msgs:Msg", ptr %l61
  %t117 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t114, { i64, [3 x i64] } %t115, %"compiler/msgs:Msg" %t116)
  store i64 %t117, ptr %l62
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t118 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t120 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t118)
  store i1 %t120, ptr %l64
  br label %bb23
bb23:
  %t121 = load i1, ptr %l64, !tbaa !21
  br i1 %t121, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/names:Resolver", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/load:Loader", ptr %t125, i32 0, i32 4
  %t128 = load ptr, ptr %t127, !tbaa !29
  store ptr %t128, ptr %l67, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  %t131 = load %"compiler/source:Span", ptr %l3
  %t135 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t129, i64 %t130, %"compiler/source:Span" %t131)
  store { i64, [3 x i64] } %t135, ptr %l71
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l2, !tbaa !23
  %t140 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s3, ptr %t136, i32 %t137)
  store { i64, ptr } %t140, ptr %l74
  br label %bb27
bb27:
  %t141 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t149 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %s3, ptr %s3, { i64, ptr } %t147)
  store %"compiler/msgs:Msg" %t149, ptr %l76
  br label %bb28
bb28:
  %t150 = load ptr, ptr %l67, !tbaa !29
  %t151 = load { i64, [3 x i64] }, ptr %l71
  %t152 = load %"compiler/msgs:Msg", ptr %l76
  %t153 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t150, { i64, [3 x i64] } %t151, %"compiler/msgs:Msg" %t152)
  store i64 %t153, ptr %l77
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i64, ptr %l1, !tbaa !24
  %t156 = load i32, ptr %l2, !tbaa !23
  %t157 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t154, i64 %t155, i32 %t156, %"compiler/source:Span" %t157)
  br label %bb31
bb31:
  %t162 = load i32, ptr %l2, !tbaa !23
  %t164 = load ptr, ptr %l5, !tbaa !29
  %t166 = getelementptr %"compiler/names:Table", ptr %t164, i32 0, i32 1
  %t170 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t166, i32 %t162)
  store i1 %t170, ptr %l86
  br label %bb32
bb32:
  %t171 = load i1, ptr %l86, !tbaa !21
  br i1 %t171, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/names:Resolver", ptr %t172, i32 0, i32 0
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/load:Loader", ptr %t175, i32 0, i32 4
  %t178 = load ptr, ptr %t177, !tbaa !29
  store ptr %t178, ptr %l89, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l1, !tbaa !24
  %t181 = load %"compiler/source:Span", ptr %l3
  %t185 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t179, i64 %t180, %"compiler/source:Span" %t181)
  store { i64, [3 x i64] } %t185, ptr %l93
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i32, ptr %l2, !tbaa !23
  %t190 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s4, ptr %t186, i32 %t187)
  store { i64, ptr } %t190, ptr %l96
  br label %bb36
bb36:
  %t191 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = mul i64 %t192, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t194)
  call void @llvm.memcpy.p0.p0.i64(ptr %t195, ptr %t193, i64 %t194, i1 false)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t199 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameIsType(ptr %s4, ptr %s4, { i64, ptr } %t197)
  store %"compiler/msgs:Msg" %t199, ptr %l98
  br label %bb37
bb37:
  %t200 = load ptr, ptr %l89, !tbaa !29
  %t201 = load { i64, [3 x i64] }, ptr %l93
  %t202 = load %"compiler/msgs:Msg", ptr %l98
  %t203 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t200, { i64, [3 x i64] } %t201, %"compiler/msgs:Msg" %t202)
  store i64 %t203, ptr %l99
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb39:
  %t204 = load ptr, ptr %l5, !tbaa !29
  %t206 = getelementptr %"compiler/names:Table", ptr %t204, i32 0, i32 2
  store ptr %t206, ptr %l101, !tbaa !29
  %t207 = load i32, ptr %l2, !tbaa !23
  store i32 %t207, ptr %l102, !tbaa !23
  %t208 = load ptr, ptr %l5, !tbaa !29
  %t210 = getelementptr %"compiler/names:Table", ptr %t208, i32 0, i32 0
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t210)
  store i64 %t212, ptr %l105
  br label %bb40
bb40:
  %t213 = load ptr, ptr %l101, !tbaa !29
  %t214 = load i32, ptr %l102, !tbaa !23
  %t215 = load i64, ptr %l105, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t213, i32 %t214, i64 %t215)
  br label %bb41
bb41:
  %t216 = load ptr, ptr %l5, !tbaa !29
  %t218 = getelementptr %"compiler/names:Table", ptr %t216, i32 0, i32 0
  store ptr %t218, ptr %l107, !tbaa !29
  %t219 = load i32, ptr %l2, !tbaa !23
  %t220 = load %"compiler/source:Span", ptr %l3
  %t226 = call %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v1, ptr %v0, i32 %t219, %"compiler/source:Span" %t220, i32 4, i1 false, ptr %a4)
  store %"compiler/names:Entry" %t226, ptr %l112
  br label %bb42
bb42:
  %t227 = load ptr, ptr %l107, !tbaa !29
  %t228 = load %"compiler/names:Entry", ptr %l112
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t227, %"compiler/names:Entry" %t228)
  br label %bb43
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddValue(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4, i1 %a5, i1 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i64
  %l19 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l32 = alloca ptr
  %l36 = alloca { i64, [3 x i64] }
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i64
  %l41 = alloca ptr
  %l45 = alloca %"compiler/names:Entry"
  %l50 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l65 = alloca i1
  %l69 = alloca ptr
  %l73 = alloca { i64, [3 x i64] }
  %l76 = alloca { i64, ptr }
  %l78 = alloca %"compiler/msgs:Msg"
  %l79 = alloca i64
  %l83 = alloca ptr
  %l87 = alloca { i64, [3 x i64] }
  %l90 = alloca { i64, ptr }
  %l92 = alloca %"compiler/msgs:Msg"
  %l93 = alloca i64
  %l99 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i32
  %l109 = alloca ptr
  %l113 = alloca { i64, [3 x i64] }
  %l116 = alloca { i64, ptr }
  %l118 = alloca %"compiler/msgs:Msg"
  %l119 = alloca i64
  %l130 = alloca i1
  %l131 = alloca i1
  %l136 = alloca i1
  %l137 = alloca i1
  %l139 = alloca i1
  %l142 = alloca ptr
  %l146 = alloca { i64, [3 x i64] }
  %l149 = alloca { i64, ptr }
  %l151 = alloca %"compiler/msgs:Msg"
  %l152 = alloca i64
  %l156 = alloca i1
  %l161 = alloca i1
  %l164 = alloca ptr
  %l168 = alloca { i64, [3 x i64] }
  %l171 = alloca { i64, ptr }
  %l173 = alloca %"compiler/msgs:Msg"
  %l174 = alloca i64
  %l176 = alloca ptr
  %l177 = alloca i32
  %l180 = alloca i64
  %l182 = alloca ptr
  %l183 = alloca i32
  %l184 = alloca %"compiler/source:Span"
  %l186 = alloca i32
  %l190 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l19, !tbaa !29
  store ptr %t8, ptr %l8, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 5
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l24
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l24, !tbaa !29
  store ptr %t19, ptr %l9, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t24, ptr %l27
  br label %bb3
bb3:
  %t25 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t28, ptr %l29
  br label %bb4
bb4:
  %t29 = load i1, ptr %l29, !tbaa !21
  br i1 %t29, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/load:Loader", ptr %t33, i32 0, i32 4
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l32, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t39 = load %"compiler/source:Span", ptr %l3
  %t43 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t37, i64 %t38, %"compiler/source:Span" %t39)
  store { i64, [3 x i64] } %t43, ptr %l36
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t44 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %s1)
  store %"compiler/msgs:Msg" %t44, ptr %l37
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l32, !tbaa !29
  %t46 = load { i64, [3 x i64] }, ptr %l36
  %t47 = load %"compiler/msgs:Msg", ptr %l37
  %t48 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t45, { i64, [3 x i64] } %t46, %"compiler/msgs:Msg" %t47)
  store i64 %t48, ptr %l38
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  br i1 %a6, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l8, !tbaa !29
  %t53 = getelementptr %"compiler/names:Table", ptr %t51, i32 0, i32 0
  store ptr %t53, ptr %l41, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t55 = load %"compiler/source:Span", ptr %l3
  %t59 = call %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v0, ptr %v0, i32 %t54, %"compiler/source:Span" %t55, i32 3, i1 false, ptr null)
  store %"compiler/names:Entry" %t59, ptr %l45
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t60 = load ptr, ptr %l41, !tbaa !29
  %t61 = load %"compiler/names:Entry", ptr %l45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t60, %"compiler/names:Entry" %t61)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/names:Resolver", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t72 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v0, ptr %t68, { i64, ptr } %t69)
  store i1 %t72, ptr %l50
  br label %bb16
bb16:
  %t73 = load i1, ptr %l50, !tbaa !21
  br i1 %t73, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load ptr, ptr %l9, !tbaa !29
  %t76 = getelementptr %"compiler/load:Module", ptr %t74, i32 0, i32 2
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s3, { i64, ptr } %t77, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t79, ptr %l53
  br label %bb19
bb18:
  br label %bb45
bb19:
  %t80 = load i1, ptr %l53, !tbaa !21
  br i1 %t80, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb22
bb21:
  %t81 = load ptr, ptr %l9, !tbaa !29
  %t83 = getelementptr %"compiler/load:Module", ptr %t81, i32 0, i32 3
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l54, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l54, !tbaa !21
  store i1 %t86, ptr %l11, !tbaa !21
  %t87 = load i1, ptr %l5, !tbaa !21
  br i1 %t87, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb25
bb24:
  %t89 = load i1, ptr %l11, !tbaa !21
  store i1 %t89, ptr %l58, !tbaa !21
  br label %bb25
bb25:
  %t91 = load i1, ptr %l58, !tbaa !21
  br i1 %t91, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb29
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/names:Resolver", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/load:Loader", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t102 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v0, ptr %t98, { i64, ptr } %t99)
  store i1 %t102, ptr %l65
  br label %bb28
bb28:
  %t103 = load i1, ptr %l65, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l60, !tbaa !21
  br label %bb29
bb29:
  %t106 = load i1, ptr %l60, !tbaa !21
  br i1 %t106, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/names:Resolver", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/load:Loader", ptr %t110, i32 0, i32 4
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l69, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i64, ptr %l1, !tbaa !24
  %t116 = load %"compiler/source:Span", ptr %l3
  %t120 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t114, i64 %t115, %"compiler/source:Span" %t116)
  store { i64, [3 x i64] } %t120, ptr %l73
  br label %bb32
bb31:
  %t121 = load i1, ptr %l4, !tbaa !21
  br i1 %t121, label %bb36, label %bb37
bb32:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l2, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s4, ptr %t123, i32 %t124)
  store { i64, ptr } %t127, ptr %l76
  br label %bb33
bb33:
  %t128 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildConstRedeclared(ptr %s4, ptr %s4, { i64, ptr } %t134)
  store %"compiler/msgs:Msg" %t136, ptr %l78
  br label %bb34
bb34:
  %t137 = load ptr, ptr %l69, !tbaa !29
  %t138 = load { i64, [3 x i64] }, ptr %l73
  %t139 = load %"compiler/msgs:Msg", ptr %l78
  %t140 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t137, { i64, [3 x i64] } %t138, %"compiler/msgs:Msg" %t139)
  store i64 %t140, ptr %l79
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/names:Resolver", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/load:Loader", ptr %t144, i32 0, i32 4
  %t147 = load ptr, ptr %t146, !tbaa !29
  store ptr %t147, ptr %l83, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i64, ptr %l1, !tbaa !24
  %t150 = load %"compiler/source:Span", ptr %l3
  %t154 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t148, i64 %t149, %"compiler/source:Span" %t150)
  store { i64, [3 x i64] } %t154, ptr %l87
  br label %bb38
bb37:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l1, !tbaa !24
  %t157 = load i32, ptr %l2, !tbaa !23
  %t158 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebuildDefault(ptr %v0, ptr %v1, ptr %t155, i64 %t156, i32 %t157, %"compiler/source:Span" %t158, ptr %a7)
  br label %bb42
bb38:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i32, ptr %l2, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s6, ptr %t165, i32 %t166)
  store { i64, ptr } %t169, ptr %l90
  br label %bb39
bb39:
  %t170 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t172 = extractvalue { i64, ptr } %t170, 1
  %t173 = mul i64 %t171, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  %t178 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultMut(ptr %s6, ptr %s6, { i64, ptr } %t176)
  store %"compiler/msgs:Msg" %t178, ptr %l92
  br label %bb40
bb40:
  %t179 = load ptr, ptr %l83, !tbaa !29
  %t180 = load { i64, [3 x i64] }, ptr %l87
  %t181 = load %"compiler/msgs:Msg", ptr %l92
  %t182 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s6, ptr %t179, { i64, [3 x i64] } %t180, %"compiler/msgs:Msg" %t181)
  store i64 %t182, ptr %l93
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb45:
  %t183 = load ptr, ptr %l8, !tbaa !29
  %t185 = getelementptr %"compiler/names:Table", ptr %t183, i32 0, i32 1
  %t186 = load i32, ptr %l2, !tbaa !23
  %t189 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t185, i32 %t186)
  %t190 = extractvalue { i32, i64 } %t189, 1
  %t191 = extractvalue { i32, i64 } %t189, 0
  store i32 %t191, ptr %l104
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb47, label %ok.193, !prof !99
ok.193:
  store i64 %t190, ptr %l103
  br label %bb46
bb46:
  %t194 = load i64, ptr %l103, !tbaa !24
  store i64 %t194, ptr %l99, !tbaa !24
  br label %bb49
bb47:
  br label %bb48
bb48:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l99, !tbaa !24
  br label %bb49
bb49:
  %t195 = load i64, ptr %l99, !tbaa !24
  store i64 %t195, ptr %l12, !tbaa !24
  %t196 = load i64, ptr %l12, !tbaa !24
  %t198 = icmp sge i64 %t196, 0
  br i1 %t198, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s8
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/names:Resolver", ptr %t200, i32 0, i32 0
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/load:Loader", ptr %t203, i32 0, i32 4
  %t206 = load ptr, ptr %t205, !tbaa !29
  store ptr %t206, ptr %l109, !tbaa !29
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i64, ptr %l1, !tbaa !24
  %t209 = load %"compiler/source:Span", ptr %l3
  %t213 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t207, i64 %t208, %"compiler/source:Span" %t209)
  store { i64, [3 x i64] } %t213, ptr %l113
  br label %bb52
bb51:
  br label %bb56
bb52:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i32, ptr %l2, !tbaa !23
  %t218 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s8, ptr %t214, i32 %t215)
  store { i64, ptr } %t218, ptr %l116
  br label %bb53
bb53:
  %t219 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 0
  %t221 = extractvalue { i64, ptr } %t219, 1
  %t222 = mul i64 %t220, 1
  %t223 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t222)
  call void @llvm.memcpy.p0.p0.i64(ptr %t223, ptr %t221, i64 %t222, i1 false)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t223, 1
  %t227 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameInUse(ptr %s8, ptr %s8, { i64, ptr } %t225)
  store %"compiler/msgs:Msg" %t227, ptr %l118
  br label %bb54
bb54:
  %t228 = load ptr, ptr %l109, !tbaa !29
  %t229 = load { i64, [3 x i64] }, ptr %l113
  %t230 = load %"compiler/msgs:Msg", ptr %l118
  %t231 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t228, { i64, [3 x i64] } %t229, %"compiler/msgs:Msg" %t230)
  store i64 %t231, ptr %l119
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  %t232 = load i64, ptr %l12, !tbaa !24
  %t234 = icmp slt i64 %t232, 0
  br i1 %t234, label %bb57, label %bb58
bb57:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i64, ptr %l1, !tbaa !24
  %t238 = load i32, ptr %l2, !tbaa !23
  %t239 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t236, i64 %t237, i32 %t238, %"compiler/source:Span" %t239)
  br label %bb59
bb58:
  br label %bb89
bb59:
  %t244 = load i32, ptr %l2, !tbaa !23
  %t246 = load ptr, ptr %l8, !tbaa !29
  %t248 = getelementptr %"compiler/names:Table", ptr %t246, i32 0, i32 2
  %t252 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t248, i32 %t244)
  store i1 %t252, ptr %l130
  br label %bb60
bb60:
  %t253 = load i1, ptr %l130, !tbaa !21
  br i1 %t253, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb64
bb62:
  %t254 = load i32, ptr %l2, !tbaa !23
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/names:Resolver", ptr %t256, i32 0, i32 2
  %t262 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t258, i32 %t254)
  store i1 %t262, ptr %l136
  br label %bb63
bb63:
  %t263 = load i1, ptr %l136, !tbaa !21
  store i1 %t263, ptr %l131, !tbaa !21
  br label %bb64
bb64:
  %t264 = load i1, ptr %l131, !tbaa !21
  br i1 %t264, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb68
bb66:
  %t265 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t267 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t265)
  store i1 %t267, ptr %l139
  br label %bb67
bb67:
  %t268 = load i1, ptr %l139, !tbaa !21
  store i1 %t268, ptr %l137, !tbaa !21
  br label %bb68
bb68:
  %t269 = load i1, ptr %l137, !tbaa !21
  br i1 %t269, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s10
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/names:Resolver", ptr %t270, i32 0, i32 0
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t275 = getelementptr %"compiler/load:Loader", ptr %t273, i32 0, i32 4
  %t276 = load ptr, ptr %t275, !tbaa !29
  store ptr %t276, ptr %l142, !tbaa !29
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load i64, ptr %l1, !tbaa !24
  %t279 = load %"compiler/source:Span", ptr %l3
  %t283 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t277, i64 %t278, %"compiler/source:Span" %t279)
  store { i64, [3 x i64] } %t283, ptr %l146
  br label %bb71
bb70:
  br label %bb75
bb71:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i32, ptr %l2, !tbaa !23
  %t288 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s10, ptr %t284, i32 %t285)
  store { i64, ptr } %t288, ptr %l149
  br label %bb72
bb72:
  %t289 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 0
  %t291 = extractvalue { i64, ptr } %t289, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t297 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameIsType(ptr %s10, ptr %s10, { i64, ptr } %t295)
  store %"compiler/msgs:Msg" %t297, ptr %l151
  br label %bb73
bb73:
  %t298 = load ptr, ptr %l142, !tbaa !29
  %t299 = load { i64, [3 x i64] }, ptr %l146
  %t300 = load %"compiler/msgs:Msg", ptr %l151
  %t301 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t298, { i64, [3 x i64] } %t299, %"compiler/msgs:Msg" %t300)
  store i64 %t301, ptr %l152
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s10)
  br label %bb75
bb75:
  %t302 = load ptr, ptr %l9, !tbaa !29
  %t304 = getelementptr %"compiler/load:Module", ptr %t302, i32 0, i32 3
  %t305 = load i1, ptr %t304, !tbaa !21
  %t307 = xor i1 %t305, true
  br i1 %t307, label %bb76, label %bb77
bb76:
  %t309 = load i32, ptr %l2, !tbaa !23
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/names:Resolver", ptr %t311, i32 0, i32 3
  %t317 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H6d33fbc050830e537410645e3c893b2c(ptr %v0, ptr %t313, i32 %t309)
  store i1 %t317, ptr %l161
  br label %bb78
bb77:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb79
bb78:
  %t318 = load i1, ptr %l161, !tbaa !21
  store i1 %t318, ptr %l156, !tbaa !21
  br label %bb79
bb79:
  %t319 = load i1, ptr %l156, !tbaa !21
  br i1 %t319, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s11
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/names:Resolver", ptr %t320, i32 0, i32 0
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t325 = getelementptr %"compiler/load:Loader", ptr %t323, i32 0, i32 4
  %t326 = load ptr, ptr %t325, !tbaa !29
  store ptr %t326, ptr %l164, !tbaa !29
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i64, ptr %l1, !tbaa !24
  %t329 = load %"compiler/source:Span", ptr %l3
  %t333 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t327, i64 %t328, %"compiler/source:Span" %t329)
  store { i64, [3 x i64] } %t333, ptr %l168
  br label %bb82
bb81:
  br label %bb86
bb82:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i32, ptr %l2, !tbaa !23
  %t338 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s11, ptr %t334, i32 %t335)
  store { i64, ptr } %t338, ptr %l171
  br label %bb83
bb83:
  %t339 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  %t341 = extractvalue { i64, ptr } %t339, 1
  %t342 = mul i64 %t340, 1
  %t343 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t342)
  call void @llvm.memcpy.p0.p0.i64(ptr %t343, ptr %t341, i64 %t342, i1 false)
  %t344 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  %t347 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePreludeConstRedeclared(ptr %s11, ptr %s11, { i64, ptr } %t345)
  store %"compiler/msgs:Msg" %t347, ptr %l173
  br label %bb84
bb84:
  %t348 = load ptr, ptr %l164, !tbaa !29
  %t349 = load { i64, [3 x i64] }, ptr %l168
  %t350 = load %"compiler/msgs:Msg", ptr %l173
  %t351 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s11, ptr %t348, { i64, [3 x i64] } %t349, %"compiler/msgs:Msg" %t350)
  store i64 %t351, ptr %l174
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s11)
  br label %bb86
bb86:
  %t352 = load ptr, ptr %l8, !tbaa !29
  %t354 = getelementptr %"compiler/names:Table", ptr %t352, i32 0, i32 1
  store ptr %t354, ptr %l176, !tbaa !29
  %t355 = load i32, ptr %l2, !tbaa !23
  store i32 %t355, ptr %l177, !tbaa !23
  %t356 = load ptr, ptr %l8, !tbaa !29
  %t358 = getelementptr %"compiler/names:Table", ptr %t356, i32 0, i32 0
  %t360 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t358)
  store i64 %t360, ptr %l180
  br label %bb87
bb87:
  %t361 = load ptr, ptr %l176, !tbaa !29
  %t362 = load i32, ptr %l177, !tbaa !23
  %t363 = load i64, ptr %l180, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t361, i32 %t362, i64 %t363)
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t364 = load ptr, ptr %l8, !tbaa !29
  %t366 = getelementptr %"compiler/names:Table", ptr %t364, i32 0, i32 0
  store ptr %t366, ptr %l182, !tbaa !29
  %t367 = load i32, ptr %l2, !tbaa !23
  store i32 %t367, ptr %l183, !tbaa !23
  %t368 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t368, ptr %l184
  %t369 = load i1, ptr %l5, !tbaa !21
  br i1 %t369, label %bb90, label %bb91
bb90:
  store i32 3, ptr %l186
  br label %bb92
bb91:
  store i32 2, ptr %l186
  br label %bb92
bb92:
  %t373 = load i1, ptr %l4, !tbaa !21
  %t374 = load i32, ptr %l183, !tbaa !23
  %t375 = load %"compiler/source:Span", ptr %l184
  %t376 = load i32, ptr %l186, !range !{i32 0, i32 9}
  %t378 = call %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v0, ptr %v0, i32 %t374, %"compiler/source:Span" %t375, i32 %t376, i1 %t373, ptr null)
  store %"compiler/names:Entry" %t378, ptr %l190
  br label %bb93
bb93:
  %t379 = load ptr, ptr %l182, !tbaa !29
  %t380 = load %"compiler/names:Entry", ptr %l190
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t379, %"compiler/names:Entry" %t380)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHead(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/names:Ref"
  %l6 = alloca %"compiler/names:Ref"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/names:Ref" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/names:Ref", ptr %l6
  store %"compiler/names:Ref" %t6, ptr %l3
  %t7 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 9}
  %t10 = trunc i64 5 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  %t15 = load %"compiler/names:Ref", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t13, %"compiler/source:Span" %t14, %"compiler/names:Ref" %t15)
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t19 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
bb5:
  %t22 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22, !range !{i32 0, i32 9}
  %t25 = trunc i64 0 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  %t30 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %t28, %"compiler/source:Span" %t29, i32 %t30)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHop(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca i64
  %l17 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i32
  %l28 = alloca { i64, ptr }
  %l30 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i64
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, [3 x i64] }
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/msgs:Msg"
  %l51 = alloca i64
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasTarget(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/names:Resolver", ptr %t12, i32 0, i32 1
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t21 = getelementptr %"compiler/names:Table", ptr %t19, i32 0, i32 3
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t21, i32 %t22)
  %t26 = extractvalue { i32, i64 } %t25, 1
  %t27 = extractvalue { i32, i64 } %t25, 0
  store i32 %t27, ptr %l22
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb7, label %ok.29, !prof !99
ok.29:
  store i64 %t26, ptr %l21
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l13, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb9
bb9:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l28
  br label %bb13
bb13:
  %t42 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t42, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t43)
  store i1 %t45, ptr %l30
  br label %bb14
bb14:
  %t46 = load i1, ptr %l30, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/names:Resolver", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l34, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l35, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/names:Resolver", ptr %t57, i32 0, i32 6
  %t60 = load i64, ptr %t59, !tbaa !24
  store i64 %t60, ptr %l37, !tbaa !24
  %t61 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t67 = trunc i64 %t65 to i32
  %t70 = sub i32 %t62, %t67
  %t71 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t72 = load i32, ptr %t71, !tbaa !23
  %t75 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t70, i32 %t72)
  store %"compiler/source:Span" %t75, ptr %l44
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t76 = load ptr, ptr %l35, !tbaa !29
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = load %"compiler/source:Span", ptr %l44
  %t79 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t76, i64 %t77, %"compiler/source:Span" %t78)
  store { i64, [3 x i64] } %t79, ptr %l45
  br label %bb18
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l3, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s3, ptr %t80, i32 %t81)
  store { i64, ptr } %t84, ptr %l48
  br label %bb19
bb19:
  %t85 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportIsPrivate(ptr %s3, ptr %s3, { i64, ptr } %t91)
  store %"compiler/msgs:Msg" %t93, ptr %l50
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l34, !tbaa !29
  %t95 = load { i64, [3 x i64] }, ptr %l45
  %t96 = load %"compiler/msgs:Msg", ptr %l50
  %t97 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t94, { i64, [3 x i64] } %t95, %"compiler/msgs:Msg" %t96)
  store i64 %t97, ptr %l51
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb22:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/names:Resolver", ptr %t99, i32 0, i32 5
  store ptr %t101, ptr %l54, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/names:Resolver", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/load:Loader", ptr %t105, i32 0, i32 5
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/names:Resolver", ptr %t108, i32 0, i32 6
  %t111 = load i64, ptr %t110, !tbaa !24
  %t114 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t107, i64 %t111)
  store ptr %t114, ptr %l60
  br label %bb23
bb23:
  %t115 = load ptr, ptr %l60, !tbaa !29
  %t117 = getelementptr %"compiler/load:Module", ptr %t115, i32 0, i32 4
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t120 = load i32, ptr %t119, !tbaa !23
  %t123 = call i64 @compiler_2fnames_2ekey(i64 %t118, i32 %t120)
  store i64 %t123, ptr %l64
  br label %bb24
bb24:
  %t124 = load i64, ptr %l5, !tbaa !24
  %t127 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 5, i64 %t124, i64 -1)
  store %"compiler/names:Ref" %t127, ptr %l67
  br label %bb25
bb25:
  %t128 = load ptr, ptr %l54, !tbaa !29
  %t129 = load i64, ptr %l64, !tbaa !24
  %t130 = load %"compiler/names:Ref", ptr %l67
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t128, i64 %t129, %"compiler/names:Ref" %t130)
  br label %bb26
bb26:
  %t131 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasModule(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l39 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i32
  %l57 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l63 = alloca i64
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t10 = sub i64 %t8, 1
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb3:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb5
bb5:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l8, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/names:Resolver", ptr %t58, i32 0, i32 1
  %t61 = load i64, ptr %l2, !tbaa !24
  %t64 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store ptr %t64, ptr %l43
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l43, !tbaa !29
  %t67 = getelementptr %"compiler/names:Table", ptr %t65, i32 0, i32 3
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l46, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 %t69
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t67, i32 %t74)
  %t78 = extractvalue { i32, i64 } %t77, 1
  %t79 = extractvalue { i32, i64 } %t77, 0
  store i32 %t79, ptr %l50
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb13, label %ok.81, !prof !99
ok.81:
  store i64 %t78, ptr %l49
  br label %bb12
bb12:
  %t82 = load i64, ptr %l49, !tbaa !24
  store i64 %t82, ptr %l39, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l39, !tbaa !24
  br label %bb15
bb15:
  %t83 = load i64, ptr %l39, !tbaa !24
  store i64 %t83, ptr %l9, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb16, label %bb17
bb16:
  store i64 -1, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp eq i64 %t89, 0
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/names:Resolver", ptr %t93, i32 0, i32 19
  store ptr %t95, ptr %l57, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/names:Resolver", ptr %t96, i32 0, i32 6
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t100, ptr %l60, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i32, ptr %t102, i64 0
  %t104 = load i32, ptr %t103, !tbaa !33
  %t108 = call i64 @compiler_2fnames_2ekey(i64 %t99, i32 %t104)
  store i64 %t108, ptr %l63
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t109 = load ptr, ptr %l57, !tbaa !29
  %t110 = load i64, ptr %l63, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t109, i64 %t110, i1 true)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = icmp sgt i64 %t111, 0
  br i1 %t113, label %bb24, label %bb25
bb24:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t116, ptr %l68, !tbaa !27
  %t117 = load i64, ptr %l8, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i32, ptr %t120, i64 %t117
  %t122 = load i32, ptr %t121, !tbaa !33
  %t125 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t115, i32 %t122)
  store { i64, ptr } %t125, ptr %l71
  br label %bb26
bb25:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb28
bb26:
  %t126 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t127 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t126)
  store i1 %t127, ptr %l72
  br label %bb27
bb27:
  %t128 = load i1, ptr %l72, !tbaa !21
  %t129 = xor i1 %t128, true
  store i1 %t129, ptr %l66, !tbaa !21
  br label %bb28
bb28:
  %t131 = load i1, ptr %l66, !tbaa !21
  br i1 %t131, label %bb29, label %bb30
bb29:
  store i64 -1, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t133 = load i64, ptr %l9, !tbaa !24
  store i64 %t133, ptr %l2, !tbaa !24
  br label %bb32
bb32:
  %t135 = load i64, ptr %l7, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l7, !tbaa !24
  br label %bb7
bb33:
  %t139 = load i64, ptr %l2, !tbaa !24
  store i64 %t139, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l34 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  %t24 = load i32, ptr %l3, !tbaa !23
  %t28 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHead(ptr %v0, ptr %t22, %"compiler/source:Span" %t23, i32 %t24)
  store i64 %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = load i64, ptr %l19, !tbaa !24
  store i64 %t29, ptr %l7, !tbaa !24
  br label %bb19
bb7:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 29}
  %t37 = icmp eq i64 %t35, 15
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t41, i32 0, i32 0
  %t43 = load %"compiler/source:Span", ptr %t42
  store %"compiler/source:Span" %t43, ptr %l4
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l5, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t53, i32 0, i32 2
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l6, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l4
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  %t65 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasHop(ptr %v0, ptr %v1, ptr %t57, %"compiler/source:Span" %t58, ptr %t59, i32 %t60)
  store i64 %t65, ptr %l34
  br label %bb13
bb13:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_fd033da614d46a49_c57bfff01eec9785)
  unreachable
bb19:
  %t67 = load i64, ptr %l7, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasesOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/load:Import"
  %l9 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca i64
  %l24 = alloca %"compiler/load:Import"
  %l28 = alloca ptr
  %l33 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 5
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l14
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t21 = getelementptr %"compiler/load:Module", ptr %t19, i32 0, i32 11
  store ptr %t21, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t23 = load i64, ptr %l4, !tbaa !24
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l19
  br label %bb4
bb4:
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t33, i64 %t34)
  store %"compiler/load:Import" %t37, ptr %l24
  br label %bb8
bb8:
  %t38 = load %"compiler/load:Import", ptr %l24
  store %"compiler/load:Import" %t38, ptr %l5
  %t39 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 5
  %t40 = load i64, ptr %t39, !tbaa !24
  %t42 = icmp sge i64 %t40, 0
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/names:Table", ptr %t44, i32 0, i32 3
  store ptr %t46, ptr %l28, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/names:Resolver", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t58 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t53, { i64, ptr } %t55)
  store i32 %t58, ptr %l33
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t59 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 5
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = load ptr, ptr %l28, !tbaa !29
  %t62 = load i32, ptr %l33, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t61, i32 %t62, i64 %t60)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb3
bb15:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %rv = alloca { i64, [3 x i64] }
  %t23 = alloca { i64, [3 x i64] }, align 8
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 4
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t19 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = sext i32 %t20 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t23, i32 0, i32 0
  store i64 3, ptr %t24
  %t26 = insertvalue { i64, i64, i64 } undef, i64 %t14, 0
  %t28 = insertvalue { i64, i64, i64 } %t26, i64 %t18, 1
  %t30 = insertvalue { i64, i64, i64 } %t28, i64 %t22, 2
  %t31 = getelementptr { i64, [3 x i64] }, ptr %t23, i32 0, i32 1
  store { i64, i64, i64 } %t30, ptr %t31
  %t32 = load { i64, [3 x i64] }, ptr %t23
  store { i64, [3 x i64] } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l18 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca %"compiler/names:local"
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 8
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l11
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l10
  br label %bb1
bb1:
  %t12 = load i64, ptr %l10, !tbaa !24
  store i64 %t12, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/names:Resolver", ptr %t14, i32 0, i32 9
  store ptr %t16, ptr %l13, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t21 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s0, i32 %t17, i64 %t13)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %t22, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t23)
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/names:Resolver", ptr %t24, i32 0, i32 8
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l19, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/names:Resolver", ptr %t28, i32 0, i32 7
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l22
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i32, ptr %l19, !tbaa !23
  %t35 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t33, i32 %t34, i64 %t35)
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/names:Resolver", ptr %t36, i32 0, i32 7
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load i32, ptr %l1, !tbaa !23
  %t45 = call %"compiler/names:local" @compiler_2fnames_3alocal_2ector(ptr %s0, i32 %t39, %"compiler/source:Span" %a2, i32 %a3, i1 false, i1 false, i1 false)
  store %"compiler/names:local" %t45, ptr %l28
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = load %"compiler/names:local", ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2ePush_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t46, %"compiler/names:local" %t47)
  br label %bb10
bb10:
  %t48 = load i32, ptr %l1, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/names:Resolver", ptr %t50, i32 0, i32 10
  %t56 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t52, i32 %t48)
  store i1 %t56, ptr %l33
  br label %bb11
bb11:
  %t57 = load i1, ptr %l33, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/names:Resolver", ptr %t60, i32 0, i32 10
  %t63 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t62, i32 %t63)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l19 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l11
  br label %bb4
bb4:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t33, ptr %t31)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l4, !tbaa !24
  br label %bb5
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t42, i64 %t43)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i64
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l122 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l131 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  %l171 = alloca ptr
  %l172 = alloca i1
  %l186 = alloca { i64, ptr }
  %l194 = alloca ptr
  %l195 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb118
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l35, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  store ptr %t23, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t24 = load ptr, ptr %l38, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l38, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 11}
  %t30 = icmp eq i64 %t28, 7
  store i1 %t30, ptr %l39, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l39, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr { i64, [6 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l7, !tbaa !29
  br label %bb9
bb8:
  br label %bb22
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/names:Resolver", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l45, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  store i64 %t42, ptr %l46, !tbaa !24
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TopIf", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3c4b516dc7f3c61f_40ef246315a2e453)
  unreachable
bb11:
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l7, !tbaa !29
  %t52 = getelementptr %"compiler/ast:TopIf", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l52
  br label %bb13
bb13:
  %t56 = getelementptr %"compiler/source:Span", ptr %l52, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t58 = load ptr, ptr %l45, !tbaa !29
  %t59 = load i64, ptr %l46, !tbaa !24
  %t61 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t58, i64 %t59, i32 %t57)
  store i64 %t61, ptr %l54
  br label %bb14
bb14:
  %t62 = load i64, ptr %l54, !tbaa !24
  store i64 %t62, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t67 = icmp eq i64 %t63, %t64
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 21
  %t72 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t71, i64 %t72, i1 true)
  br label %bb17
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t78 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodiesIf(ptr %v0, ptr %v1, ptr %t75, i64 %t76, ptr %t77, i64 %t78, i64 0)
  br label %bb20
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t83, i64 %t84)
  br label %bb18
bb18:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etopConds(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  br label %bb19
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb116
bb22:
  %t91 = load ptr, ptr %l6, !tbaa !29
  store ptr %t91, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t92 = load ptr, ptr %l69, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = load ptr, ptr %l69, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 11}
  %t98 = icmp eq i64 %t96, 0
  store i1 %t98, ptr %l70, !tbaa !21
  br label %bb24
bb24:
  %t99 = load i1, ptr %l70, !tbaa !21
  br i1 %t99, label %bb25, label %bb26
bb25:
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t102 = getelementptr { i64, [6 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { ptr }, ptr %t102, i32 0, i32 0
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l9, !tbaa !29
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t106, i64 %t107)
  br label %bb28
bb28:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efunc(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  br label %bb29
bb29:
  br label %bb116
bb30:
  %t114 = load ptr, ptr %l6, !tbaa !29
  store ptr %t114, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t115 = load ptr, ptr %l79, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb31, label %bb32
bb31:
  %t118 = load ptr, ptr %l79, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 11}
  %t121 = icmp eq i64 %t119, 1
  store i1 %t121, ptr %l80, !tbaa !21
  br label %bb32
bb32:
  %t122 = load i1, ptr %l80, !tbaa !21
  br i1 %t122, label %bb33, label %bb34
bb33:
  %t123 = load ptr, ptr %l6, !tbaa !29
  %t125 = getelementptr { i64, [6 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { ptr }, ptr %t125, i32 0, i32 0
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l10, !tbaa !29
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t129, i64 %t130)
  br label %bb36
bb36:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t133, ptr %t134, i1 false)
  br label %bb37
bb37:
  br label %bb116
bb38:
  %t137 = load ptr, ptr %l6, !tbaa !29
  store ptr %t137, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t138 = load ptr, ptr %l89, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb39, label %bb40
bb39:
  %t141 = load ptr, ptr %l89, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 11}
  %t144 = icmp eq i64 %t142, 2
  store i1 %t144, ptr %l90, !tbaa !21
  br label %bb40
bb40:
  %t145 = load i1, ptr %l90, !tbaa !21
  br i1 %t145, label %bb41, label %bb42
bb41:
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t148 = getelementptr { i64, [6 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", ptr }, ptr %t148, i32 0, i32 1
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t152, i64 %t153)
  br label %bb44
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeDecl(ptr %v0, ptr %v1, ptr %t156, ptr %t157)
  br label %bb45
bb45:
  br label %bb116
bb46:
  %t160 = load ptr, ptr %l6, !tbaa !29
  store ptr %t160, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t161 = load ptr, ptr %l99, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l99, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 11}
  %t167 = icmp eq i64 %t165, 3
  store i1 %t167, ptr %l100, !tbaa !21
  br label %bb48
bb48:
  %t168 = load i1, ptr %l100, !tbaa !21
  br i1 %t168, label %bb49, label %bb50
bb49:
  %t169 = load ptr, ptr %l6, !tbaa !29
  %t171 = getelementptr { i64, [6 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", ptr }, ptr %t171, i32 0, i32 1
  %t173 = load ptr, ptr %t172
  store ptr %t173, ptr %l12, !tbaa !29
  br label %bb51
bb50:
  br label %bb64
bb51:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t175, i64 %t176)
  br label %bb52
bb52:
  %t179 = load ptr, ptr %l12, !tbaa !29
  %t181 = getelementptr %"compiler/ast:VarDecl", ptr %t179, i32 0, i32 2
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = icmp eq ptr %t182, null
  %t186 = xor i1 %t184, true
  br i1 %t186, label %bb53, label %bb54
bb53:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l12, !tbaa !29
  %t191 = getelementptr %"compiler/ast:VarDecl", ptr %t189, i32 0, i32 2
  %t192 = load ptr, ptr %t191, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t188, ptr %t192)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  %t195 = load ptr, ptr %l12, !tbaa !29
  %t197 = getelementptr %"compiler/ast:VarDecl", ptr %t195, i32 0, i32 3
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  store { i64, ptr } %t198, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  store i64 %t202, ptr %l15, !tbaa !24
  br label %bb57
bb57:
  %t204 = load i64, ptr %l14, !tbaa !24
  %t205 = load i64, ptr %l15, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb58, label %bb59
bb58:
  br label %bb63
bb59:
  br label %bb60
bb60:
  %t212 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t212, ptr %l122, !tbaa !27
  %t213 = load i64, ptr %l14, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr ptr, ptr %t216, i64 %t213
  %t218 = load ptr, ptr %t217, !tbaa !39
  %t220 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t220, ptr %t218)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t225 = load i64, ptr %l14, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l14, !tbaa !24
  br label %bb57
bb63:
  br label %bb116
bb64:
  %t229 = load ptr, ptr %l6, !tbaa !29
  store ptr %t229, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t230 = load ptr, ptr %l130, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb65, label %bb66
bb65:
  %t233 = load ptr, ptr %l130, !tbaa !29
  %t234 = load i64, ptr %t233, !range !{i64 0, i64 11}
  %t236 = icmp eq i64 %t234, 8
  store i1 %t236, ptr %l131, !tbaa !21
  br label %bb66
bb66:
  %t237 = load i1, ptr %l131, !tbaa !21
  br i1 %t237, label %bb67, label %bb68
bb67:
  %t238 = load ptr, ptr %l6, !tbaa !29
  %t240 = getelementptr { i64, [6 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t240, i32 0, i32 1
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l17, !tbaa !29
  %t244 = load ptr, ptr %l6, !tbaa !29
  %t246 = getelementptr { i64, [6 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t246, i32 0, i32 2
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l18, !tbaa !29
  br label %bb69
bb68:
  br label %bb73
bb69:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t250, i64 %t251)
  br label %bb70
bb70:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t254, ptr %t255)
  br label %bb71
bb71:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t259, ptr %t260)
  br label %bb72
bb72:
  br label %bb116
bb73:
  %t264 = load ptr, ptr %l6, !tbaa !29
  store ptr %t264, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t265 = load ptr, ptr %l146, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb74, label %bb75
bb74:
  %t268 = load ptr, ptr %l146, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 11}
  %t271 = icmp eq i64 %t269, 9
  store i1 %t271, ptr %l147, !tbaa !21
  br label %bb75
bb75:
  %t272 = load i1, ptr %l147, !tbaa !21
  br i1 %t272, label %bb76, label %bb77
bb76:
  %t273 = load ptr, ptr %l6, !tbaa !29
  %t275 = getelementptr { i64, [6 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t275, i32 0, i32 1
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l19, !tbaa !29
  %t279 = load ptr, ptr %l6, !tbaa !29
  %t281 = getelementptr { i64, [6 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t281, i32 0, i32 2
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l20, !tbaa !29
  br label %bb78
bb77:
  br label %bb82
bb78:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t285, i64 %t286)
  br label %bb79
bb79:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t289, ptr %t290)
  br label %bb80
bb80:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t294, ptr %t295)
  br label %bb81
bb81:
  br label %bb116
bb82:
  %t298 = load ptr, ptr %l6, !tbaa !29
  store ptr %t298, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t299 = load ptr, ptr %l161, !tbaa !29
  %t300 = icmp ne ptr %t299, null
  br i1 %t300, label %bb83, label %bb84
bb83:
  %t302 = load ptr, ptr %l161, !tbaa !29
  %t303 = load i64, ptr %t302, !range !{i64 0, i64 11}
  %t305 = icmp eq i64 %t303, 6
  store i1 %t305, ptr %l162, !tbaa !21
  br label %bb84
bb84:
  %t306 = load i1, ptr %l162, !tbaa !21
  br i1 %t306, label %bb85, label %bb86
bb85:
  %t307 = load ptr, ptr %l6, !tbaa !29
  %t309 = getelementptr { i64, [6 x i64] }, ptr %t307, i32 0, i32 1
  %t310 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t309, i32 0, i32 2
  %t311 = load { i64, ptr }, ptr %t310
  store { i64, ptr } %t311, ptr %l21, !tbaa !27
  br label %bb87
bb86:
  br label %bb90
bb87:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t313, i64 %t314)
  br label %bb88
bb88:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t317, { i64, ptr } %t318)
  br label %bb89
bb89:
  br label %bb116
bb90:
  %t321 = load ptr, ptr %l6, !tbaa !29
  store ptr %t321, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t322 = load ptr, ptr %l171, !tbaa !29
  %t323 = icmp ne ptr %t322, null
  br i1 %t323, label %bb91, label %bb92
bb91:
  %t325 = load ptr, ptr %l171, !tbaa !29
  %t326 = load i64, ptr %t325, !range !{i64 0, i64 11}
  %t328 = icmp eq i64 %t326, 5
  store i1 %t328, ptr %l172, !tbaa !21
  br label %bb92
bb92:
  %t329 = load i1, ptr %l172, !tbaa !21
  br i1 %t329, label %bb93, label %bb94
bb93:
  %t330 = load ptr, ptr %l6, !tbaa !29
  %t332 = getelementptr { i64, [6 x i64] }, ptr %t330, i32 0, i32 1
  %t333 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t332, i32 0, i32 3
  %t334 = load { i64, ptr }, ptr %t333
  store { i64, ptr } %t334, ptr %l22, !tbaa !27
  br label %bb95
bb94:
  br label %bb104
bb95:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t336, i64 %t337)
  br label %bb96
bb96:
  %t340 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t340, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t342 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t342, 0
  store i64 %t344, ptr %l25, !tbaa !24
  br label %bb97
bb97:
  %t346 = load i64, ptr %l24, !tbaa !24
  %t347 = load i64, ptr %l25, !tbaa !24
  %t350 = icmp slt i64 %t346, %t347
  %t352 = xor i1 %t350, true
  br i1 %t352, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t354 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t354, ptr %l186, !tbaa !27
  %t355 = load i64, ptr %l24, !tbaa !24
  %t357 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = getelementptr ptr, ptr %t358, i64 %t355
  %t360 = load ptr, ptr %t359, !tbaa !39
  %t362 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t362, ptr %t360)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t367 = load i64, ptr %l24, !tbaa !24
  %t369 = add i64 %t367, 1
  store i64 %t369, ptr %l24, !tbaa !24
  br label %bb97
bb103:
  br label %bb116
bb104:
  %t371 = load ptr, ptr %l6, !tbaa !29
  store ptr %t371, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t372 = load ptr, ptr %l194, !tbaa !29
  %t373 = icmp ne ptr %t372, null
  br i1 %t373, label %bb105, label %bb106
bb105:
  %t375 = load ptr, ptr %l194, !tbaa !29
  %t376 = load i64, ptr %t375, !range !{i64 0, i64 11}
  %t378 = icmp eq i64 %t376, 10
  store i1 %t378, ptr %l195, !tbaa !21
  br label %bb106
bb106:
  %t379 = load i1, ptr %l195, !tbaa !21
  br i1 %t379, label %bb107, label %bb108
bb107:
  %t380 = load ptr, ptr %l6, !tbaa !29
  %t382 = getelementptr { i64, [6 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t382, i32 0, i32 2
  %t384 = load { i64, ptr }, ptr %t383
  store { i64, ptr } %t384, ptr %l27, !tbaa !27
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load i64, ptr %l1, !tbaa !24
  %t388 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %t386, i64 %t387, { i64, ptr } %t388)
  br label %bb110
bb110:
  br label %bb116
bb111:
  br i1 true, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_check_failed(ptr @olang_loc_d2d926149e7406c7_ee094aa2e5a4afab)
  unreachable
bb116:
  br label %bb117
bb117:
  %t392 = load i64, ptr %l4, !tbaa !24
  %t394 = add i64 %t392, 1
  store i64 %t394, ptr %l4, !tbaa !24
  br label %bb1
bb118:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodiesIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l18 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i64
  %l38 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l42 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca i64
  %l79 = alloca i1
  %l84 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp ne i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 20
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:TopIf", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb3, label %bb4
bb2:
  br label %bb8
bb3:
  call void @__olang_check_failed(ptr @olang_loc_68114e74278341f8_5424865478da1a14)
  unreachable
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopIf", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t24 = getelementptr %"compiler/ast:TopBranch", ptr %t21, i32 0, i32 0
  %t25 = load %"compiler/source:Span", ptr %t24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t28 = call %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %s1, i64 %t26, %"compiler/source:Span" %t25)
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t28, ptr %l18
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l9, !tbaa !29
  %t30 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H2dfd829fbe4fa38977b46d00afbe1a06(ptr %v0, ptr %t29, %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t30)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"compiler/ast:TopIf", ptr %t31, i32 0, i32 3
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t41, 1
  %t46 = icmp ne i64 %t40, %t43
  store i1 %t46, ptr %l23, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/names:Resolver", ptr %t49, i32 0, i32 20
  store ptr %t51, ptr %l29, !tbaa !29
  %t52 = load i64, ptr %l1, !tbaa !24
  store i64 %t52, ptr %l30, !tbaa !24
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:TopIf", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb14, label %bb15
bb13:
  br label %bb19
bb14:
  call void @__olang_check_failed(ptr @olang_loc_3167f851ad930e17_101a5d4c5c826523)
  unreachable
bb15:
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:TopIf", ptr %t60, i32 0, i32 3
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t66 = getelementptr %"compiler/ast:TopBranch", ptr %t63, i32 0, i32 0
  %t67 = load %"compiler/source:Span", ptr %t66
  %t68 = load i64, ptr %l30, !tbaa !24
  %t70 = call %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %s2, i64 %t68, %"compiler/source:Span" %t67)
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t70, ptr %l38
  br label %bb17
bb17:
  %t71 = load ptr, ptr %l29, !tbaa !29
  %t72 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H2dfd829fbe4fa38977b46d00afbe1a06(ptr %v0, ptr %t71, %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t72)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = icmp eq i64 %t73, %t74
  br i1 %t77, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr %"compiler/ast:TopIf", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb22, label %bb23
bb21:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb25
bb22:
  call void @__olang_check_failed(ptr @olang_loc_10b7a8cdf1f86826_4c22b802d51640a2)
  unreachable
bb23:
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/ast:TopIf", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t92 = getelementptr %"compiler/ast:TopBranch", ptr %t89, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = icmp sgt i64 %t95, 0
  store i1 %t97, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t99 = load i1, ptr %l42, !tbaa !21
  br i1 %t99, label %bb26, label %bb27
bb26:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l52, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  store i64 %t101, ptr %l53, !tbaa !24
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr %"compiler/ast:TopIf", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = icmp eq ptr %t105, null
  br i1 %t107, label %bb28, label %bb29
bb27:
  br label %bb32
bb28:
  call void @__olang_check_failed(ptr @olang_loc_10b7a8cdf1f86826_4c22b802d51640a2)
  unreachable
bb29:
  br label %bb30
bb30:
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t111 = getelementptr %"compiler/ast:TopIf", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t115 = getelementptr %"compiler/ast:TopBranch", ptr %t112, i32 0, i32 1
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t117 = load ptr, ptr %l52, !tbaa !29
  %t118 = load i64, ptr %l53, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %t117, i64 %t118, { i64, ptr } %t116)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/ast:TopIf", ptr %t120, i32 0, i32 2
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb33, label %bb34
bb33:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l65, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  store i64 %t130, ptr %l66, !tbaa !24
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr %"compiler/ast:TopIf", ptr %t131, i32 0, i32 2
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = icmp eq ptr %t134, null
  br i1 %t136, label %bb35, label %bb36
bb34:
  br label %bb39
bb35:
  call void @__olang_check_failed(ptr @olang_loc_4f6a732ad110320d_928733cb84224b09)
  unreachable
bb36:
  br label %bb37
bb37:
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t140 = getelementptr %"compiler/ast:TopIf", ptr %t138, i32 0, i32 2
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t142 = load i64, ptr %l3, !tbaa !24
  %t143 = load i64, ptr %l4, !tbaa !24
  %t145 = add i64 %t143, 1
  %t146 = load ptr, ptr %l65, !tbaa !29
  %t147 = load i64, ptr %l66, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodiesIf(ptr %v0, ptr %v1, ptr %t146, i64 %t147, ptr %t141, i64 %t142, i64 %t145)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t151 = load ptr, ptr %l2, !tbaa !29
  %t153 = getelementptr %"compiler/ast:TopIf", ptr %t151, i32 0, i32 3
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb40, label %bb41
bb40:
  %t160 = load i64, ptr %l3, !tbaa !24
  %t161 = load i64, ptr %l4, !tbaa !24
  %t163 = add i64 %t161, 1
  %t166 = icmp eq i64 %t160, %t163
  store i1 %t166, ptr %l79, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb42
bb42:
  %t168 = load i1, ptr %l79, !tbaa !21
  br i1 %t168, label %bb43, label %bb44
bb43:
  %t169 = load ptr, ptr %l2, !tbaa !29
  %t171 = getelementptr %"compiler/ast:TopIf", ptr %t169, i32 0, i32 3
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = icmp eq ptr %t172, null
  br i1 %t174, label %bb45, label %bb46
bb44:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb48
bb45:
  call void @__olang_check_failed(ptr @olang_loc_3f10f26d81c7593c_51efd4b9807fb190)
  unreachable
bb46:
  br label %bb47
bb47:
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t178 = getelementptr %"compiler/ast:TopIf", ptr %t176, i32 0, i32 3
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t182 = getelementptr %"compiler/ast:TopBranch", ptr %t179, i32 0, i32 1
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t187 = icmp sgt i64 %t185, 0
  store i1 %t187, ptr %l84, !tbaa !21
  br label %bb48
bb48:
  %t189 = load i1, ptr %l84, !tbaa !21
  br i1 %t189, label %bb49, label %bb50
bb49:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l94, !tbaa !29
  %t191 = load i64, ptr %l1, !tbaa !24
  store i64 %t191, ptr %l95, !tbaa !24
  %t192 = load ptr, ptr %l2, !tbaa !29
  %t194 = getelementptr %"compiler/ast:TopIf", ptr %t192, i32 0, i32 3
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = icmp eq ptr %t195, null
  br i1 %t197, label %bb51, label %bb52
bb50:
  br label %bb55
bb51:
  call void @__olang_check_failed(ptr @olang_loc_3f10f26d81c7593c_51efd4b9807fb190)
  unreachable
bb52:
  br label %bb53
bb53:
  %t199 = load ptr, ptr %l2, !tbaa !29
  %t201 = getelementptr %"compiler/ast:TopIf", ptr %t199, i32 0, i32 3
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t205 = getelementptr %"compiler/ast:TopBranch", ptr %t202, i32 0, i32 1
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  %t207 = load ptr, ptr %l94, !tbaa !29
  %t208 = load i64, ptr %l95, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %t207, i64 %t208, { i64, ptr } %t206)
  br label %bb54
bb54:
  br label %bb55
bb55:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/names:Resolver", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 4
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Branch", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t14, i64 %t18)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Branch", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t21, { i64, ptr } %t25)
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Branch", ptr %t28, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = icmp sge i64 %t31, 0
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/names:Resolver", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/load:Loader", ptr %t38, i32 0, i32 4
  %t41 = load ptr, ptr %t40, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t41)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebuildDefault(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca i64
  %l43 = alloca %"compiler/source:Span"
  %l45 = alloca i64
  %l46 = alloca i64
  %l51 = alloca { i64, ptr }
  %l53 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i1
  %l82 = alloca i1
  %l84 = alloca i1
  %l86 = alloca i1
  %l88 = alloca i1
  %l90 = alloca i1
  %l94 = alloca ptr
  %l98 = alloca { i64, [3 x i64] }
  %l101 = alloca { i64, ptr }
  %l104 = alloca %"compiler/msgs:Msg"
  %l105 = alloca i64
  %l108 = alloca { i64, ptr }
  %l114 = alloca i1
  %l118 = alloca ptr
  %l122 = alloca { i64, [3 x i64] }
  %l123 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l135 = alloca %"compiler/msgs:Msg"
  %l136 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t5, ptr %l11, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l12, !tbaa !24
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l13, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t19, ptr %l5, !tbaa !27
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:VarDecl", ptr %t20, i32 0, i32 2
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/names:Resolver", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/load:Loader", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l22
  br label %bb6
bb5:
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t41 = getelementptr %"compiler/ast:VarDecl", ptr %t39, i32 0, i32 3
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = icmp eq i64 %t44, 1
  br i1 %t46, label %bb27, label %bb28
bb6:
  %t48 = load ptr, ptr %l22, !tbaa !29
  %t50 = getelementptr %"compiler/load:Module", ptr %t48, i32 0, i32 6
  %t51 = load ptr, ptr %t50, !tbaa !29
  store ptr %t51, ptr %l6, !tbaa !29
  %t53 = load ptr, ptr %l6, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1073219c408bafd2_e24f73113d5a6ea6)
  unreachable
bb8:
  br label %bb9
bb9:
  %t57 = load ptr, ptr %l6, !tbaa !29
  %t60 = getelementptr %"compiler/source:Source", ptr %t57, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l29, !tbaa !27
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:VarDecl", ptr %t62, i32 0, i32 2
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_1073219c408bafd2_e24f73113d5a6ea6)
  unreachable
bb11:
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = getelementptr %"compiler/ast:VarDecl", ptr %t69, i32 0, i32 2
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t72)
  store %"compiler/source:Span" %t74, ptr %l35
  br label %bb13
bb13:
  %t75 = getelementptr %"compiler/source:Span", ptr %l35, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  store i64 %t78, ptr %l37, !tbaa !24
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/ast:VarDecl", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_1073219c408bafd2_e24f73113d5a6ea6)
  unreachable
bb15:
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/ast:VarDecl", ptr %t86, i32 0, i32 2
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t89)
  store %"compiler/source:Span" %t91, ptr %l43
  br label %bb17
bb17:
  %t92 = getelementptr %"compiler/source:Span", ptr %l43, i32 0, i32 1
  %t93 = load i32, ptr %t92, !tbaa !23
  %t95 = sext i32 %t93 to i64
  store i64 %t95, ptr %l45, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l46, !tbaa !24
  %t98 = load i64, ptr %l37, !tbaa !24
  %t99 = icmp sge i64 %t98, 0
  br i1 %t99, label %bb18, label %bb19
bb18:
  %t101 = load i64, ptr %l37, !tbaa !24
  %t102 = load i64, ptr %l45, !tbaa !24
  %t103 = icmp sle i64 %t101, %t102
  br i1 %t103, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f4b8a71cbdc10f47_ba6792d0a606e23b)
  unreachable
bb20:
  %t105 = load i64, ptr %l45, !tbaa !24
  %t106 = load i64, ptr %l46, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  br i1 %t107, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f4b8a71cbdc10f47_ba6792d0a606e23b)
  unreachable
bb22:
  %t109 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l37, !tbaa !24
  %t112 = load i64, ptr %l45, !tbaa !24
  %t113 = getelementptr i8, ptr %t110, i64 %t111
  %t114 = sub i64 %t112, %t111
  %t115 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t113, 1
  %t118 = extractvalue { i64, ptr } %t116, 1
  %t119 = extractvalue { i64, ptr } %t116, 0
  %t120 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t118, i64 %t119)
  %t121 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l51, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l53, !tbaa !24
  %t128 = load i64, ptr %l53, !tbaa !24
  %t129 = icmp eq i64 %t124, %t128
  br i1 %t129, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_f4b8a71cbdc10f47_ba6792d0a606e23b)
  unreachable
bb24:
  %t131 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l53, !tbaa !24
  %t136 = mul i64 %t135, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t132, ptr %t134, i64 %t136, i1 false)
  br label %bb26
bb25:
  %t137 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t137, ptr %l5, !tbaa !27
  br label %bb26
bb26:
  br label %bb34
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t138 = load ptr, ptr %l4, !tbaa !29
  %t140 = getelementptr %"compiler/ast:VarDecl", ptr %t138, i32 0, i32 3
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l60, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr ptr, ptr %t143, i64 0
  %t145 = load ptr, ptr %t144, !tbaa !39
  %t147 = call { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v1, ptr %s5, ptr %t145)
  store { i64, ptr } %t147, ptr %l62
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t148 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t149, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l63, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t156 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  store i64 %t157, ptr %l65, !tbaa !24
  %t159 = load i64, ptr %l65, !tbaa !24
  %t160 = icmp eq i64 %t155, %t159
  br i1 %t160, label %bb30, label %bb31
bb30:
  %t162 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = load i64, ptr %l65, !tbaa !24
  %t167 = mul i64 %t166, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t163, ptr %t165, i64 %t167, i1 false)
  br label %bb32
bb31:
  %t168 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t168, ptr %l5, !tbaa !27
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t169 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t171 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t169, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t171, ptr %l68
  br label %bb35
bb35:
  %t172 = load i1, ptr %l68, !tbaa !21
  br i1 %t172, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  br label %bb38
bb38:
  %t173 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t175 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t173, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t175, ptr %l70
  br label %bb39
bb39:
  %t176 = load i1, ptr %l70, !tbaa !21
  %t177 = xor i1 %t176, true
  br i1 %t177, label %bb40, label %bb41
bb40:
  %t179 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t181 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t179, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t181, ptr %l74
  br label %bb42
bb41:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb43
bb42:
  %t182 = load i1, ptr %l74, !tbaa !21
  %t183 = xor i1 %t182, true
  store i1 %t183, ptr %l72, !tbaa !21
  br label %bb43
bb43:
  %t185 = load i1, ptr %l72, !tbaa !21
  br i1 %t185, label %bb44, label %bb45
bb44:
  %t186 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t186, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t188, ptr %l78
  br label %bb46
bb45:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb47
bb46:
  %t189 = load i1, ptr %l78, !tbaa !21
  %t190 = xor i1 %t189, true
  store i1 %t190, ptr %l76, !tbaa !21
  br label %bb47
bb47:
  %t192 = load i1, ptr %l76, !tbaa !21
  br i1 %t192, label %bb48, label %bb49
bb48:
  %t193 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t195 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t193, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t195, ptr %l82
  br label %bb50
bb49:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb51
bb50:
  %t196 = load i1, ptr %l82, !tbaa !21
  %t197 = xor i1 %t196, true
  store i1 %t197, ptr %l80, !tbaa !21
  br label %bb51
bb51:
  %t199 = load i1, ptr %l80, !tbaa !21
  br i1 %t199, label %bb52, label %bb53
bb52:
  %t200 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t202 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t200, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t202, ptr %l86
  br label %bb54
bb53:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb55
bb54:
  %t203 = load i1, ptr %l86, !tbaa !21
  %t204 = xor i1 %t203, true
  store i1 %t204, ptr %l84, !tbaa !21
  br label %bb55
bb55:
  %t206 = load i1, ptr %l84, !tbaa !21
  br i1 %t206, label %bb56, label %bb57
bb56:
  %t207 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t209 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t207, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t209, ptr %l90
  br label %bb58
bb57:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb59
bb58:
  %t210 = load i1, ptr %l90, !tbaa !21
  %t211 = xor i1 %t210, true
  store i1 %t211, ptr %l88, !tbaa !21
  br label %bb59
bb59:
  %t213 = load i1, ptr %l88, !tbaa !21
  br i1 %t213, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s8
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/names:Resolver", ptr %t214, i32 0, i32 0
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = getelementptr %"compiler/load:Loader", ptr %t217, i32 0, i32 4
  %t220 = load ptr, ptr %t219, !tbaa !29
  store ptr %t220, ptr %l94, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i64, ptr %l1, !tbaa !24
  %t223 = load %"compiler/source:Span", ptr %l3
  %t227 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t221, i64 %t222, %"compiler/source:Span" %t223)
  store { i64, [3 x i64] } %t227, ptr %l98
  br label %bb62
bb61:
  br label %bb66
bb62:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i32, ptr %l2, !tbaa !23
  %t232 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s8, ptr %t228, i32 %t229)
  store { i64, ptr } %t232, ptr %l101
  br label %bb63
bb63:
  %t233 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 0
  %t235 = extractvalue { i64, ptr } %t233, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  %t240 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t243 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultType(ptr %s8, ptr %s0, ptr %s8, { i64, ptr } %t239, { i64, ptr } %t240)
  store %"compiler/msgs:Msg" %t243, ptr %l104
  br label %bb64
bb64:
  %t244 = load ptr, ptr %l94, !tbaa !29
  %t245 = load { i64, [3 x i64] }, ptr %l98
  %t246 = load %"compiler/msgs:Msg", ptr %l104
  %t247 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t244, { i64, [3 x i64] } %t245, %"compiler/msgs:Msg" %t246)
  store i64 %t247, ptr %l105
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb66:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l2, !tbaa !23
  %t252 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t248, i32 %t249)
  store { i64, ptr } %t252, ptr %l108
  br label %bb67
bb67:
  %t253 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t253, ptr %l7, !tbaa !27
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/names:Resolver", ptr %t254, i32 0, i32 0
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t259 = getelementptr %"compiler/load:Loader", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t261 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t266 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFits(ptr %v0, ptr %v0, ptr %s0, ptr %t260, { i64, ptr } %t261, { i64, ptr } %t262)
  store i1 %t266, ptr %l114
  br label %bb68
bb68:
  %t267 = load i1, ptr %l114, !tbaa !21
  %t268 = xor i1 %t267, true
  br i1 %t268, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s9
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/names:Resolver", ptr %t270, i32 0, i32 0
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t275 = getelementptr %"compiler/load:Loader", ptr %t273, i32 0, i32 4
  %t276 = load ptr, ptr %t275, !tbaa !29
  store ptr %t276, ptr %l118, !tbaa !29
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load i64, ptr %l1, !tbaa !24
  %t279 = load %"compiler/source:Span", ptr %l3
  %t283 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t277, i64 %t278, %"compiler/source:Span" %t279)
  store { i64, [3 x i64] } %t283, ptr %l122
  br label %bb71
bb70:
  br label %bb76
bb71:
  %t284 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t284, ptr %l123, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/names:Resolver", ptr %t285, i32 0, i32 0
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t290 = getelementptr %"compiler/load:Loader", ptr %t288, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t295 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v0, ptr %s9, ptr %t291, { i64, ptr } %t292)
  store { i64, ptr } %t295, ptr %l128
  br label %bb72
bb72:
  %t296 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 0
  %t298 = extractvalue { i64, ptr } %t296, 1
  %t299 = mul i64 %t297, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t299)
  call void @llvm.memcpy.p0.p0.i64(ptr %t300, ptr %t298, i64 %t299, i1 false)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l129, !tbaa !27
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l2, !tbaa !23
  %t307 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s9, ptr %t303, i32 %t304)
  store { i64, ptr } %t307, ptr %l132
  br label %bb73
bb73:
  %t308 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  %t310 = extractvalue { i64, ptr } %t308, 1
  %t311 = mul i64 %t309, 1
  %t312 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t311)
  call void @llvm.memcpy.p0.p0.i64(ptr %t312, ptr %t310, i64 %t311, i1 false)
  %t313 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  %t315 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t320 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultFit(ptr %v0, ptr %s9, ptr %s9, ptr %s0, ptr %s9, { i64, ptr } %t316, { i64, ptr } %t317, { i64, ptr } %t314, { i64, ptr } %t315)
  store %"compiler/msgs:Msg" %t320, ptr %l135
  br label %bb74
bb74:
  %t321 = load ptr, ptr %l118, !tbaa !29
  %t322 = load { i64, [3 x i64] }, ptr %l122
  %t323 = load %"compiler/msgs:Msg", ptr %l135
  %t324 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t321, { i64, [3 x i64] } %t322, %"compiler/msgs:Msg" %t323)
  store i64 %t324, ptr %l136
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s9)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecaseOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i64, ptr %l13, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:Case", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l18
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t15 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Case", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l27, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epattern(ptr %v0, ptr %v1, ptr %s1, ptr %t41, ptr %t39, ptr %l3)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l5, !tbaa !24
  br label %bb5
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Case", ptr %t50, i32 0, i32 2
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Case", ptr %t59, i32 0, i32 2
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l10, !tbaa !24
  br label %bb15
bb14:
  br label %bb22
bb15:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t76 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = load i64, ptr %l9, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t77
  %t82 = load ptr, ptr %t81, !tbaa !39
  %t84 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t84, ptr %t82)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Case", ptr %t93, i32 0, i32 3
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = icmp eq ptr %t96, null
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb23, label %bb24
bb23:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/ast:Case", ptr %t103, i32 0, i32 3
  %t106 = load ptr, ptr %t105, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t102, ptr %t106)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Case", ptr %t110, i32 0, i32 4
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t109, { i64, ptr } %t113)
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/ast:Case", ptr %t116, i32 0, i32 5
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb28, label %bb29
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Case", ptr %t126, i32 0, i32 5
  %t129 = load ptr, ptr %t128, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t125, ptr %t129)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t132, i64 %t133)
  br label %bb32
bb32:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2echoose(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l9 = alloca i1
  %l29 = alloca i1
  %l35 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load i1, ptr %l2, !tbaa !21
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load i1, ptr %l3, !tbaa !21
  %t12 = xor i1 %t10, true
  store i1 %t12, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/names:Resolver", ptr %t15, i32 0, i32 17
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 0
  %t21 = load %"compiler/source:Span", ptr %t20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t17, %"compiler/source:Span" %t21)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t24 = load i1, ptr %l2, !tbaa !21
  br i1 %t24, label %bb11, label %bb12
bb11:
  %t26 = load i1, ptr %l3, !tbaa !21
  br i1 %t26, label %bb13, label %bb14
bb12:
  br i1 %a4, label %bb18, label %bb19
bb13:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/load:Loader", ptr %t33, i32 0, i32 4
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Branch", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t36, i64 %t40)
  br label %bb15
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/names:Resolver", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/load:Loader", ptr %t46, i32 0, i32 4
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Branch", ptr %t50, i32 0, i32 2
  %t53 = load i64, ptr %t52, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t49, i64 %t53)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb26
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/names:Resolver", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/load:Loader", ptr %t59, i32 0, i32 4
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Branch", ptr %t63, i32 0, i32 2
  %t66 = load i64, ptr %t65, !tbaa !24
  %t69 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t62, i64 %t66)
  store i1 %t69, ptr %l35
  br label %bb20
bb19:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb21
bb20:
  %t70 = load i1, ptr %l35, !tbaa !21
  %t71 = xor i1 %t70, true
  store i1 %t71, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l29, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/names:Resolver", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/load:Loader", ptr %t77, i32 0, i32 4
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Branch", ptr %t81, i32 0, i32 2
  %t84 = load i64, ptr %t83, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t80, i64 %t84)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l27 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca ptr
  %l42 = alloca i1
  %l44 = alloca { i64, ptr }
  %l49 = alloca i32
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca %"compiler/names:Ref"
  %l59 = alloca i1
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l86 = alloca i64
  %l103 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb44
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l27, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Catch", ptr %t29, i32 0, i32 5
  %t32 = load i32, ptr %t31, !tbaa !23
  store i32 %t32, ptr %l6, !tbaa !23
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/ast:Catch", ptr %t34, i32 0, i32 6
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l7
  %t39 = load i32, ptr %l6, !tbaa !23
  %t41 = icmp eq i32 %t39, 0
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l5, !tbaa !29
  store ptr %t43, ptr %l37, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Catch", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp eq i64 %t49, 1
  br i1 %t51, label %bb10, label %bb11
bb9:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb18
bb10:
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Catch", ptr %t53, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l44, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 0
  %t60 = load ptr, ptr %t59, !tbaa !39
  %t62 = getelementptr %"compiler/ast:Path", ptr %t60, i32 0, i32 1
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t67 = icmp eq i64 %t65, 1
  store i1 %t67, ptr %l42, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb12
bb12:
  %t69 = load i1, ptr %l42, !tbaa !21
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Catch", ptr %t71, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l52, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 0
  %t78 = load ptr, ptr %t77, !tbaa !39
  %t80 = getelementptr %"compiler/ast:Path", ptr %t78, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l54, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i32, ptr %t83, i64 0
  %t85 = load i32, ptr %t84, !tbaa !33
  %t88 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t70, i32 %t85)
  store %"compiler/names:Ref" %t88, ptr %l56
  br label %bb15
bb14:
  store i32 4, ptr %l49
  br label %bb16
bb15:
  %t90 = getelementptr %"compiler/names:Ref", ptr %l56, i32 0, i32 0
  %t91 = load i32, ptr %t90, !range !{i32 0, i32 9}
  store i32 %t91, ptr %l49
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l37, !tbaa !29
  %t94 = load i32, ptr %l49, !range !{i32 0, i32 9}
  %t95 = call i1 @compiler_2fnames_2eLoneCatchName(ptr %v1, ptr %t93, i32 %t94)
  store i1 %t95, ptr %l59
  br label %bb17
bb17:
  %t96 = load i1, ptr %l59, !tbaa !21
  store i1 %t96, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  %t97 = load i1, ptr %l36, !tbaa !21
  br i1 %t97, label %bb19, label %bb20
bb19:
  %t98 = load ptr, ptr %l5, !tbaa !29
  %t100 = getelementptr %"compiler/ast:Catch", ptr %t98, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l61, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 0
  %t105 = load ptr, ptr %t104, !tbaa !39
  %t107 = getelementptr %"compiler/ast:Path", ptr %t105, i32 0, i32 1
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l63, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i32, ptr %t110, i64 0
  %t112 = load i32, ptr %t111, !tbaa !33
  store i32 %t112, ptr %l6, !tbaa !23
  %t114 = load ptr, ptr %l5, !tbaa !29
  %t116 = getelementptr %"compiler/ast:Catch", ptr %t114, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l66, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr ptr, ptr %t119, i64 0
  %t121 = load ptr, ptr %t120, !tbaa !39
  %t123 = getelementptr %"compiler/ast:Path", ptr %t121, i32 0, i32 0
  %t124 = load %"compiler/source:Span", ptr %t123
  store %"compiler/source:Span" %t124, ptr %l7
  br label %bb28
bb20:
  %t126 = load ptr, ptr %l5, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Catch", ptr %t126, i32 0, i32 1
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  %t135 = load i64, ptr %l9, !tbaa !24
  %t136 = load i64, ptr %l10, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb22, label %bb23
bb22:
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t143 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t143, ptr %l77, !tbaa !27
  %t144 = load i64, ptr %l9, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr ptr, ptr %t147, i64 %t144
  %t149 = load ptr, ptr %t148, !tbaa !39
  %t151 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t151, ptr %t149)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l9, !tbaa !24
  br label %bb21
bb27:
  br label %bb28
bb28:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t160)
  store i64 %t162, ptr %l86
  br label %bb29
bb29:
  %t163 = load i64, ptr %l86, !tbaa !24
  store i64 %t163, ptr %l12, !tbaa !24
  %t164 = load i32, ptr %l6, !tbaa !23
  %t166 = icmp ne i32 %t164, 0
  br i1 %t166, label %bb30, label %bb31
bb30:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l6, !tbaa !23
  %t170 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t168, i32 %t169, %"compiler/source:Span" %t170, i1 false)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l5, !tbaa !29
  %t177 = getelementptr %"compiler/ast:Catch", ptr %t175, i32 0, i32 2
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t174, { i64, ptr } %t178)
  br label %bb34
bb34:
  %t181 = load ptr, ptr %l5, !tbaa !29
  %t183 = getelementptr %"compiler/ast:Catch", ptr %t181, i32 0, i32 3
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  store { i64, ptr } %t184, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  store i64 %t188, ptr %l15, !tbaa !24
  br label %bb35
bb35:
  %t190 = load i64, ptr %l14, !tbaa !24
  %t191 = load i64, ptr %l15, !tbaa !24
  %t194 = icmp slt i64 %t190, %t191
  %t196 = xor i1 %t194, true
  br i1 %t196, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t198 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t198, ptr %l103, !tbaa !27
  %t199 = load i64, ptr %l14, !tbaa !24
  %t201 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr ptr, ptr %t202, i64 %t199
  %t204 = load ptr, ptr %t203, !tbaa !39
  %t206 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t206, ptr %t204)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t211 = load i64, ptr %l14, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l14, !tbaa !24
  br label %bb35
bb41:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t215, i64 %t216)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t219 = load i64, ptr %l3, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l3, !tbaa !24
  br label %bb4
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i64
  %l47 = alloca %"compiler/source:Span"
  %l49 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l76 = alloca i32
  %l86 = alloca ptr
  %l87 = alloca i64
  %l89 = alloca i32
  %l95 = alloca %"compiler/source:Span"
  %l100 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i64
  %l111 = alloca i32
  %l117 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i64
  %l130 = alloca i32
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca ptr
  %l137 = alloca i1
  %l148 = alloca i64
  %l151 = alloca i64
  %l169 = alloca ptr
  %l170 = alloca i64
  %l172 = alloca { i64, ptr }
  %l174 = alloca i32
  %l176 = alloca { i64, ptr }
  %l178 = alloca %"compiler/source:Span"
  %l181 = alloca i1
  %l186 = alloca ptr
  %l187 = alloca i1
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb88
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l30, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  store ptr %t23, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t24 = load ptr, ptr %l33, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l33, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 11}
  %t30 = icmp eq i64 %t28, 7
  store i1 %t30, ptr %l34, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l34, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr { i64, [6 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l7, !tbaa !29
  br label %bb9
bb8:
  br label %bb20
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/names:Resolver", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l40, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  store i64 %t42, ptr %l41, !tbaa !24
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TopIf", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_2f2d72e397ff9e11_581917560c7c3b1d)
  unreachable
bb11:
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l7, !tbaa !29
  %t52 = getelementptr %"compiler/ast:TopIf", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l47
  br label %bb13
bb13:
  %t56 = getelementptr %"compiler/source:Span", ptr %l47, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t58 = load ptr, ptr %l40, !tbaa !29
  %t59 = load i64, ptr %l41, !tbaa !24
  %t61 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t58, i64 %t59, i32 %t57)
  store i64 %t61, ptr %l49
  br label %bb14
bb14:
  %t62 = load i64, ptr %l49, !tbaa !24
  store i64 %t62, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t67 = icmp eq i64 %t63, %t64
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l1, !tbaa !24
  %t71 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %t69, i64 %t70, ptr %t71)
  br label %bb17
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t78 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollectIf(ptr %v0, ptr %v1, ptr %t75, i64 %t76, ptr %t77, i64 %t78, i64 0)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb86
bb20:
  %t83 = load ptr, ptr %l6, !tbaa !29
  store ptr %t83, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t84 = load ptr, ptr %l60, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb21, label %bb22
bb21:
  %t87 = load ptr, ptr %l60, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 11}
  %t90 = icmp eq i64 %t88, 0
  store i1 %t90, ptr %l61, !tbaa !21
  br label %bb22
bb22:
  %t91 = load i1, ptr %l61, !tbaa !21
  br i1 %t91, label %bb23, label %bb24
bb23:
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = getelementptr { i64, [6 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { ptr }, ptr %t94, i32 0, i32 0
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l9, !tbaa !29
  br label %bb29
bb24:
  %t98 = load ptr, ptr %l6, !tbaa !29
  store ptr %t98, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t99 = load ptr, ptr %l66, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb25, label %bb26
bb25:
  %t102 = load ptr, ptr %l66, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 11}
  %t105 = icmp eq i64 %t103, 1
  store i1 %t105, ptr %l67, !tbaa !21
  br label %bb26
bb26:
  %t106 = load i1, ptr %l67, !tbaa !21
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t109 = getelementptr { i64, [6 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { ptr }, ptr %t109, i32 0, i32 0
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l9, !tbaa !29
  br label %bb29
bb28:
  br label %bb38
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t113 = load ptr, ptr %l9, !tbaa !29
  %t115 = getelementptr %"compiler/ast:Func", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = icmp eq ptr %t116, null
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb30, label %bb31
bb30:
  %t122 = load ptr, ptr %l9, !tbaa !29
  %t124 = getelementptr %"compiler/ast:Func", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = icmp eq ptr %t125, null
  br i1 %t127, label %bb32, label %bb33
bb31:
  %t129 = load ptr, ptr %l9, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Func", ptr %t129, i32 0, i32 0
  %t132 = getelementptr %"compiler/source:Span", ptr %t131, i32 0, i32 0
  %t133 = load i32, ptr %t132, !tbaa !23
  store i32 %t133, ptr %l76, !tbaa !23
  br label %bb35
bb32:
  call void @__olang_check_failed(ptr @olang_loc_217d72d4076f850a_92db47fb0f8e8bb6)
  unreachable
bb33:
  br label %bb34
bb34:
  %t135 = load ptr, ptr %l9, !tbaa !29
  %t137 = getelementptr %"compiler/ast:Func", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t141 = getelementptr %"compiler/ast:Param", ptr %t138, i32 0, i32 0
  %t142 = getelementptr %"compiler/source:Span", ptr %t141, i32 0, i32 1
  %t143 = load i32, ptr %t142, !tbaa !23
  store i32 %t143, ptr %l76, !tbaa !23
  br label %bb35
bb35:
  %t145 = load i32, ptr %l76, !tbaa !23
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l86, !tbaa !29
  %t147 = load i64, ptr %l1, !tbaa !24
  store i64 %t147, ptr %l87, !tbaa !24
  %t148 = load ptr, ptr %l9, !tbaa !29
  %t150 = getelementptr %"compiler/ast:Func", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %t150, !tbaa !23
  store i32 %t151, ptr %l89, !tbaa !23
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  %t155 = load ptr, ptr %l9, !tbaa !29
  %t157 = getelementptr %"compiler/ast:Func", ptr %t155, i32 0, i32 2
  %t158 = load i32, ptr %t157, !tbaa !23
  %t163 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t152, i64 %t153, i32 %t145, i32 %t158)
  store %"compiler/source:Span" %t163, ptr %l95
  br label %bb36
bb36:
  %t164 = load ptr, ptr %l9, !tbaa !29
  %t166 = getelementptr %"compiler/ast:Func", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = icmp eq ptr %t167, null
  %t171 = xor i1 %t169, true
  %t172 = load ptr, ptr %l86, !tbaa !29
  %t173 = load i64, ptr %l87, !tbaa !24
  %t174 = load i32, ptr %l89, !tbaa !23
  %t175 = load %"compiler/source:Span", ptr %l95
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddValue(ptr %v0, ptr %s6, ptr %t172, i64 %t173, i32 %t174, %"compiler/source:Span" %t175, i1 false, i1 true, i1 %t171, ptr null)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb86
bb38:
  %t177 = load ptr, ptr %l6, !tbaa !29
  store ptr %t177, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t178 = load ptr, ptr %l100, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb39, label %bb40
bb39:
  %t181 = load ptr, ptr %l100, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 11}
  %t184 = icmp eq i64 %t182, 2
  store i1 %t184, ptr %l101, !tbaa !21
  br label %bb40
bb40:
  %t185 = load i1, ptr %l101, !tbaa !21
  br i1 %t185, label %bb41, label %bb42
bb41:
  %t186 = load ptr, ptr %l6, !tbaa !29
  %t188 = getelementptr { i64, [6 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", ptr }, ptr %t188, i32 0, i32 0
  %t190 = load %"compiler/source:Span", ptr %t189
  store %"compiler/source:Span" %t190, ptr %l11
  %t192 = load ptr, ptr %l6, !tbaa !29
  %t194 = getelementptr { i64, [6 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l12, !tbaa !29
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l108, !tbaa !29
  %t199 = load i64, ptr %l1, !tbaa !24
  store i64 %t199, ptr %l109, !tbaa !24
  %t200 = load ptr, ptr %l12, !tbaa !29
  %t202 = getelementptr %"compiler/ast:TypeDecl", ptr %t200, i32 0, i32 0
  %t203 = load i32, ptr %t202, !tbaa !23
  store i32 %t203, ptr %l111, !tbaa !23
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i64, ptr %l1, !tbaa !24
  %t206 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t207 = load i32, ptr %t206, !tbaa !23
  %t208 = load ptr, ptr %l12, !tbaa !29
  %t210 = getelementptr %"compiler/ast:TypeDecl", ptr %t208, i32 0, i32 0
  %t211 = load i32, ptr %t210, !tbaa !23
  %t216 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t204, i64 %t205, i32 %t207, i32 %t211)
  store %"compiler/source:Span" %t216, ptr %l117
  br label %bb44
bb44:
  %t217 = load ptr, ptr %l12, !tbaa !29
  %t219 = load ptr, ptr %l108, !tbaa !29
  %t220 = load i64, ptr %l109, !tbaa !24
  %t221 = load i32, ptr %l111, !tbaa !23
  %t222 = load %"compiler/source:Span", ptr %l117
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v1, ptr %t219, i64 %t220, i32 %t221, %"compiler/source:Span" %t222, ptr %t217)
  br label %bb45
bb45:
  br label %bb86
bb46:
  %t224 = load ptr, ptr %l6, !tbaa !29
  store ptr %t224, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t225 = load ptr, ptr %l120, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb47, label %bb48
bb47:
  %t228 = load ptr, ptr %l120, !tbaa !29
  %t229 = load i64, ptr %t228, !range !{i64 0, i64 11}
  %t231 = icmp eq i64 %t229, 5
  store i1 %t231, ptr %l121, !tbaa !21
  br label %bb48
bb48:
  %t232 = load i1, ptr %l121, !tbaa !21
  br i1 %t232, label %bb49, label %bb50
bb49:
  %t233 = load ptr, ptr %l6, !tbaa !29
  %t235 = getelementptr { i64, [6 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t235, i32 0, i32 0
  %t237 = load %"compiler/source:Span", ptr %t236
  store %"compiler/source:Span" %t237, ptr %l13
  %t239 = load ptr, ptr %l6, !tbaa !29
  %t241 = getelementptr { i64, [6 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t241, i32 0, i32 1
  %t243 = load i32, ptr %t242
  store i32 %t243, ptr %l14, !tbaa !23
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l128, !tbaa !29
  %t246 = load i64, ptr %l1, !tbaa !24
  store i64 %t246, ptr %l129, !tbaa !24
  %t247 = load i32, ptr %l14, !tbaa !23
  store i32 %t247, ptr %l130, !tbaa !23
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i64, ptr %l1, !tbaa !24
  %t250 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t251 = load i32, ptr %t250, !tbaa !23
  %t252 = load i32, ptr %l14, !tbaa !23
  %t257 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t248, i64 %t249, i32 %t251, i32 %t252)
  store %"compiler/source:Span" %t257, ptr %l135
  br label %bb52
bb52:
  %t258 = load ptr, ptr %l128, !tbaa !29
  %t259 = load i64, ptr %l129, !tbaa !24
  %t260 = load i32, ptr %l130, !tbaa !23
  %t261 = load %"compiler/source:Span", ptr %l135
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v0, ptr %t258, i64 %t259, i32 %t260, %"compiler/source:Span" %t261, ptr null)
  br label %bb53
bb53:
  br label %bb86
bb54:
  %t262 = load ptr, ptr %l6, !tbaa !29
  store ptr %t262, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t263 = load ptr, ptr %l136, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb55, label %bb56
bb55:
  %t266 = load ptr, ptr %l136, !tbaa !29
  %t267 = load i64, ptr %t266, !range !{i64 0, i64 11}
  %t269 = icmp eq i64 %t267, 3
  store i1 %t269, ptr %l137, !tbaa !21
  br label %bb56
bb56:
  %t270 = load i1, ptr %l137, !tbaa !21
  br i1 %t270, label %bb57, label %bb58
bb57:
  %t271 = load ptr, ptr %l6, !tbaa !29
  %t273 = getelementptr { i64, [6 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", ptr }, ptr %t273, i32 0, i32 1
  %t275 = load ptr, ptr %t274
  store ptr %t275, ptr %l15, !tbaa !29
  br label %bb59
bb58:
  br label %bb74
bb59:
  store i64 0, ptr %l16, !tbaa !24
  %t277 = load ptr, ptr %l15, !tbaa !29
  %t279 = getelementptr %"compiler/ast:VarDecl", ptr %t277, i32 0, i32 0
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t280, 0
  store i64 %t282, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t284 = load i64, ptr %l17, !tbaa !24
  %t285 = load i64, ptr %l16, !tbaa !24
  %t288 = icmp sgt i64 %t284, %t285
  br i1 %t288, label %bb60, label %bb61
bb60:
  %t290 = load i64, ptr %l18, !tbaa !24
  %t292 = icmp sgt i64 %t290, 0
  br i1 %t292, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb65
bb62:
  %t294 = load i64, ptr %l17, !tbaa !24
  %t295 = load i64, ptr %l16, !tbaa !24
  %t298 = sub i64 %t294, %t295
  %t299 = load i64, ptr %l18, !tbaa !24
  %t302 = add i64 %t298, %t299
  %t304 = sub i64 %t302, 1
  %t305 = load i64, ptr %l18, !tbaa !24
  %t308 = sdiv i64 %t304, %t305
  store i64 %t308, ptr %l151, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb64
bb64:
  %t310 = load i64, ptr %l151, !tbaa !24
  store i64 %t310, ptr %l148, !tbaa !24
  br label %bb65
bb65:
  %t311 = load i64, ptr %l148, !tbaa !24
  store i64 %t311, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb66
bb66:
  %t312 = load i64, ptr %l20, !tbaa !24
  %t313 = load i64, ptr %l19, !tbaa !24
  %t316 = icmp slt i64 %t312, %t313
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb67, label %bb68
bb67:
  br label %bb73
bb68:
  br label %bb69
bb69:
  %t320 = load i64, ptr %l16, !tbaa !24
  %t321 = load i64, ptr %l20, !tbaa !24
  %t322 = load i64, ptr %l18, !tbaa !24
  %t325 = mul i64 %t321, %t322
  %t328 = add i64 %t320, %t325
  store i64 %t328, ptr %l21, !tbaa !24
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l169, !tbaa !29
  %t331 = load i64, ptr %l1, !tbaa !24
  store i64 %t331, ptr %l170, !tbaa !24
  %t332 = load ptr, ptr %l15, !tbaa !29
  %t334 = getelementptr %"compiler/ast:VarDecl", ptr %t332, i32 0, i32 0
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l172, !tbaa !27
  %t336 = load i64, ptr %l21, !tbaa !24
  %t338 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr i32, ptr %t339, i64 %t336
  %t341 = load i32, ptr %t340, !tbaa !33
  store i32 %t341, ptr %l174, !tbaa !23
  %t342 = load ptr, ptr %l15, !tbaa !29
  %t344 = getelementptr %"compiler/ast:VarDecl", ptr %t342, i32 0, i32 1
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !27
  store { i64, ptr } %t345, ptr %l176, !tbaa !27
  %t346 = load i64, ptr %l21, !tbaa !24
  %t348 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr %"compiler/source:Span", ptr %t349, i64 %t346
  %t351 = load %"compiler/source:Span", ptr %t350
  store %"compiler/source:Span" %t351, ptr %l178
  %t352 = load ptr, ptr %l15, !tbaa !29
  %t354 = getelementptr %"compiler/ast:VarDecl", ptr %t352, i32 0, i32 2
  %t355 = load ptr, ptr %t354, !tbaa !29
  %t357 = call i1 @compiler_2fnames_2ewritable(ptr %v1, ptr %t355)
  store i1 %t357, ptr %l181
  br label %bb70
bb70:
  %t358 = load ptr, ptr %l15, !tbaa !29
  %t360 = load ptr, ptr %l169, !tbaa !29
  %t361 = load i64, ptr %l170, !tbaa !24
  %t362 = load i32, ptr %l174, !tbaa !23
  %t363 = load %"compiler/source:Span", ptr %l178
  %t364 = load i1, ptr %l181, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddValue(ptr %v0, ptr %v1, ptr %t360, i64 %t361, i32 %t362, %"compiler/source:Span" %t363, i1 %t364, i1 false, i1 false, ptr %t358)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t366 = load i64, ptr %l20, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l20, !tbaa !24
  br label %bb66
bb73:
  br label %bb86
bb74:
  %t370 = load ptr, ptr %l6, !tbaa !29
  store ptr %t370, ptr %l186, !tbaa !29
  store i1 false, ptr %l187, !tbaa !21
  %t371 = load ptr, ptr %l186, !tbaa !29
  %t372 = icmp ne ptr %t371, null
  br i1 %t372, label %bb75, label %bb76
bb75:
  %t374 = load ptr, ptr %l186, !tbaa !29
  %t375 = load i64, ptr %t374, !range !{i64 0, i64 11}
  %t377 = icmp eq i64 %t375, 10
  store i1 %t377, ptr %l187, !tbaa !21
  br label %bb76
bb76:
  %t378 = load i1, ptr %l187, !tbaa !21
  br i1 %t378, label %bb77, label %bb78
bb77:
  %t379 = load ptr, ptr %l6, !tbaa !29
  %t381 = getelementptr { i64, [6 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t381, i32 0, i32 2
  %t383 = load { i64, ptr }, ptr %t382
  store { i64, ptr } %t383, ptr %l22, !tbaa !27
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load i64, ptr %l1, !tbaa !24
  %t387 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v1, ptr %t385, i64 %t386, { i64, ptr } %t387)
  br label %bb80
bb80:
  br label %bb86
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_711e2a7edda36e32_9275b80f871f367e)
  unreachable
bb86:
  br label %bb87
bb87:
  %t391 = load i64, ptr %l4, !tbaa !24
  %t393 = add i64 %t391, 1
  store i64 %t393, ptr %l4, !tbaa !24
  br label %bb1
bb88:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollectIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l45 = alloca i1
  %l50 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb3:
  call void @__olang_check_failed(ptr @olang_loc_60cefae456c43b96_68bed78927cbacfa)
  unreachable
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopBranch", ptr %t17, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp sgt i64 %t23, 0
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %l19, !tbaa !24
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TopIf", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_60cefae456c43b96_68bed78927cbacfa)
  unreachable
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t45 = load ptr, ptr %l18, !tbaa !29
  %t46 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v1, ptr %t45, i64 %t46, { i64, ptr } %t44)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TopIf", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  store i64 %t58, ptr %l32, !tbaa !24
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TopIf", ptr %t59, i32 0, i32 2
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb16, label %bb17
bb15:
  br label %bb20
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e46cc2517056eb7d_41b560901e6ccb81)
  unreachable
bb17:
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/ast:TopIf", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  %t74 = load ptr, ptr %l31, !tbaa !29
  %t75 = load i64, ptr %l32, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollectIf(ptr %v0, ptr %v1, ptr %t74, i64 %t75, ptr %t69, i64 %t70, i64 %t73)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr %"compiler/ast:TopIf", ptr %t79, i32 0, i32 3
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t89 = load i64, ptr %l4, !tbaa !24
  %t91 = add i64 %t89, 1
  %t94 = icmp eq i64 %t88, %t91
  store i1 %t94, ptr %l45, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t96 = load i1, ptr %l45, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:TopIf", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb29
bb26:
  call void @__olang_check_failed(ptr @olang_loc_8bede4e7118dcaa8_b7291399ad78424c)
  unreachable
bb27:
  br label %bb28
bb28:
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t106 = getelementptr %"compiler/ast:TopIf", ptr %t104, i32 0, i32 3
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t110 = getelementptr %"compiler/ast:TopBranch", ptr %t107, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t115 = icmp sgt i64 %t113, 0
  store i1 %t115, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t117 = load i1, ptr %l50, !tbaa !21
  br i1 %t117, label %bb30, label %bb31
bb30:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l60, !tbaa !29
  %t119 = load i64, ptr %l1, !tbaa !24
  store i64 %t119, ptr %l61, !tbaa !24
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/ast:TopIf", ptr %t120, i32 0, i32 3
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  br i1 %t125, label %bb32, label %bb33
bb31:
  br label %bb36
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8bede4e7118dcaa8_b7291399ad78424c)
  unreachable
bb33:
  br label %bb34
bb34:
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t129 = getelementptr %"compiler/ast:TopIf", ptr %t127, i32 0, i32 3
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t133 = getelementptr %"compiler/ast:TopBranch", ptr %t130, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t135 = load ptr, ptr %l60, !tbaa !29
  %t136 = load i64, ptr %l61, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v1, ptr %t135, i64 %t136, { i64, ptr } %t134)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2econtract(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l48 = alloca i64
  %l51 = alloca i64
  %l70 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 5
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l17
  br label %bb4
bb4:
  %t11 = load i64, ptr %l17, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l18, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Sig", ptr %t13, i32 0, i32 5
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_c16bd254021e145_58d15072e112dec1)
  unreachable
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Sig", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t26 = getelementptr %"compiler/ast:ContractBlock", ptr %t23, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t28 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %t27)
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Sig", ptr %t30, i32 0, i32 5
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_b8b027e61d959c9e_58d57e65eac3eb3a)
  unreachable
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Sig", ptr %t37, i32 0, i32 5
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t43 = getelementptr %"compiler/ast:ContractBlock", ptr %t40, i32 0, i32 2
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l5, !tbaa !24
  br label %bb12
bb12:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  br label %bb33
bb14:
  br label %bb15
bb15:
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t58, ptr %l39, !tbaa !27
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr ptr, ptr %t62, i64 %t59
  %t64 = load ptr, ptr %t63, !tbaa !39
  store ptr %t64, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Outlives", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  store i64 %t71, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb21
bb18:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l51, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb20
bb20:
  %t99 = load i64, ptr %l51, !tbaa !24
  store i64 %t99, ptr %l48, !tbaa !24
  br label %bb21
bb21:
  %t100 = load i64, ptr %l48, !tbaa !24
  store i64 %t100, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  %t101 = load i64, ptr %l11, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  br label %bb25
bb25:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t110 = load i64, ptr %l11, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l12, !tbaa !24
  %t119 = load ptr, ptr %l6, !tbaa !29
  %t121 = getelementptr %"compiler/ast:Outlives", ptr %t119, i32 0, i32 1
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l70, !tbaa !27
  %t123 = load i64, ptr %l12, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i32, ptr %t126, i64 %t123
  %t128 = load i32, ptr %t127, !tbaa !33
  %t130 = icmp ne i32 %t128, 0
  br i1 %t130, label %bb26, label %bb27
bb26:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l6, !tbaa !29
  %t135 = getelementptr %"compiler/ast:Outlives", ptr %t133, i32 0, i32 2
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l76, !tbaa !27
  %t137 = load i64, ptr %l12, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr %"compiler/source:Span", ptr %t140, i64 %t137
  %t142 = load %"compiler/source:Span", ptr %t141
  %t143 = load ptr, ptr %l6, !tbaa !29
  %t145 = getelementptr %"compiler/ast:Outlives", ptr %t143, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l80, !tbaa !27
  %t147 = load i64, ptr %l12, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i32, ptr %t150, i64 %t147
  %t152 = load i32, ptr %t151, !tbaa !33
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ename(ptr %v0, ptr %t132, %"compiler/source:Span" %t142, i32 %t152)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t156 = load i64, ptr %l11, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l11, !tbaa !24
  br label %bb22
bb31:
  br label %bb32
bb32:
  %t160 = load i64, ptr %l4, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l4, !tbaa !24
  br label %bb12
bb33:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t164, i64 %t165)
  br label %bb34
bb34:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/cond:Decision" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edecideLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l15 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i32
  %l55 = alloca i64
  %l57 = alloca i64
  %l62 = alloca i32
  %l79 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l91 = alloca %"compiler/cond:Eval"
  %l95 = alloca %"compiler/cond:Decision"
  %rv = alloca %"compiler/cond:Decision"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 6
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l15
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l15, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/names:Resolver", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v0, ptr %t18, ptr %t19)
  br label %bb2
bb2:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 23
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_24d74d734bb1c47c_a76eb538bdec4e08)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 23
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t35 = getelementptr %"compiler/cond:Scope", ptr %t32, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eClear_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t35)
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t37, i32 0, i32 10
  store ptr %t39, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l4, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l30
  br label %bb8
bb8:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = load i64, ptr %l30, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t51, i64 %t52)
  store i32 %t55, ptr %l35
  br label %bb12
bb12:
  %t56 = load i32, ptr %l35, !tbaa !23
  store i32 %t56, ptr %l5, !tbaa !23
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/load:Module", ptr %t57, i32 0, i32 23
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9d7678395160f3eb_aad45a645d2f7c27)
  unreachable
bb14:
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/load:Module", ptr %t64, i32 0, i32 23
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t70 = getelementptr %"compiler/cond:Scope", ptr %t67, i32 0, i32 2
  %t71 = load i32, ptr %l5, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t70, i32 %t71)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l4, !tbaa !24
  br label %bb7
bb18:
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 23
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = icmp eq ptr %t81, null
  br i1 %t83, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_606655a3d6c9146a_8558b81c90083f76)
  unreachable
bb20:
  br label %bb21
bb21:
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr %"compiler/load:Module", ptr %t85, i32 0, i32 23
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t91 = getelementptr %"compiler/cond:Scope", ptr %t88, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eClear_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t91)
  br label %bb22
bb22:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/names:Resolver", ptr %t93, i32 0, i32 11
  store ptr %t95, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb23
bb23:
  %t97 = load i64, ptr %l7, !tbaa !24
  store i64 %t97, ptr %l55, !tbaa !24
  %t98 = load ptr, ptr %l6, !tbaa !29
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t98)
  store i64 %t100, ptr %l57
  br label %bb24
bb24:
  %t101 = load i64, ptr %l55, !tbaa !24
  %t102 = load i64, ptr %l57, !tbaa !24
  %t103 = icmp slt i64 %t101, %t102
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb25, label %bb26
bb25:
  br label %bb34
bb26:
  br label %bb27
bb27:
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t108 = load i64, ptr %l7, !tbaa !24
  %t111 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t107, i64 %t108)
  store i32 %t111, ptr %l62
  br label %bb28
bb28:
  %t112 = load i32, ptr %l62, !tbaa !23
  store i32 %t112, ptr %l8, !tbaa !23
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t115 = getelementptr %"compiler/load:Module", ptr %t113, i32 0, i32 23
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = icmp eq ptr %t116, null
  br i1 %t118, label %bb29, label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_ca6a9ef64ba15071_9b37ed8e39b0c3dd)
  unreachable
bb30:
  br label %bb31
bb31:
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/load:Module", ptr %t120, i32 0, i32 23
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t126 = getelementptr %"compiler/cond:Scope", ptr %t123, i32 0, i32 3
  %t127 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t126, i32 %t127)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t130 = load i64, ptr %l7, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l7, !tbaa !24
  br label %bb23
bb34:
  %t134 = load ptr, ptr %l2, !tbaa !29
  %t136 = getelementptr %"compiler/load:Module", ptr %t134, i32 0, i32 6
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = icmp eq ptr %t137, null
  br i1 %t139, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_cbc626cb57e27c38_a58d4f769ca64c8c)
  unreachable
bb36:
  br label %bb37
bb37:
  %t141 = load ptr, ptr %l2, !tbaa !29
  %t143 = getelementptr %"compiler/load:Module", ptr %t141, i32 0, i32 6
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t147 = getelementptr %"compiler/source:Source", ptr %t144, i32 0, i32 1
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l79, !tbaa !27
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/names:Resolver", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/load:Loader", ptr %t152, i32 0, i32 3
  %t155 = load ptr, ptr %t154, !tbaa !29
  store ptr %t155, ptr %l82, !tbaa !29
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t158 = getelementptr %"compiler/load:Module", ptr %t156, i32 0, i32 23
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = icmp eq ptr %t159, null
  br i1 %t161, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_cbc626cb57e27c38_a58d4f769ca64c8c)
  unreachable
bb39:
  br label %bb40
bb40:
  %t163 = load ptr, ptr %l2, !tbaa !29
  %t165 = getelementptr %"compiler/load:Module", ptr %t163, i32 0, i32 23
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/names:Resolver", ptr %t167, i32 0, i32 0
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/load:Loader", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t175 = load ptr, ptr %l82, !tbaa !29
  %t178 = call %"compiler/cond:Eval" @compiler_2fcond_3aEval_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t174, ptr %t175, ptr %t166, ptr %t173)
  store %"compiler/cond:Eval" %t178, ptr %l91
  br label %bb41
bb41:
  %t179 = load %"compiler/cond:Eval", ptr %l91
  %t180 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 128, i64 8)
  store %"compiler/cond:Eval" %t179, ptr %t180
  %t186 = call %"compiler/cond:Decision" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eLocal(ptr %v0, ptr %v1, ptr %t180, ptr %a1)
  store %"compiler/cond:Decision" %t186, ptr %l95
  br label %bb42
bb42:
  %t187 = load %"compiler/cond:Decision", ptr %l95
  store %"compiler/cond:Decision" %t187, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Decision", ptr %rv
  ret %"compiler/cond:Decision" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l13 = alloca ptr
  %l18 = alloca { i64, [3 x i64] }
  %l19 = alloca %"compiler/msgs:Msg"
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i1
  %l33 = alloca %"compiler/names:local"
  %l36 = alloca i1
  %l41 = alloca ptr
  %l46 = alloca { i64, [3 x i64] }
  %l49 = alloca %"compiler/msgs:Msg"
  %l52 = alloca { i64, ptr }
  %l54 = alloca %"compiler/msgs:Msg"
  %l57 = alloca { i64, ptr }
  %l59 = alloca %"compiler/msgs:Msg"
  %l60 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load i1, ptr %l10, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/names:Resolver", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/names:Resolver", ptr %t19, i32 0, i32 6
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load %"compiler/source:Span", ptr %l2
  %t27 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t18, i64 %t22, %"compiler/source:Span" %t23)
  store { i64, [3 x i64] } %t27, ptr %l18
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %s1)
  store %"compiler/msgs:Msg" %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l13, !tbaa !29
  %t30 = load { i64, [3 x i64] }, ptr %l18
  %t31 = load %"compiler/msgs:Msg", ptr %l19
  %t32 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t29, { i64, [3 x i64] } %t30, %"compiler/msgs:Msg" %t31)
  store i64 %t32, ptr %l20
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/names:Resolver", ptr %t33, i32 0, i32 8
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t35, i32 %t36)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l26
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb10, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l25
  br label %bb9
bb9:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %l21, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l21, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp sge i64 %t46, 0
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/names:Resolver", ptr %t50, i32 0, i32 7
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t52, i64 %t53)
  store %"compiler/names:local" %t56, ptr %l33
  br label %bb15
bb14:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb16
bb15:
  %t57 = getelementptr %"compiler/names:local", ptr %l33, i32 0, i32 2
  %t58 = load i32, ptr %t57, !range !{i32 0, i32 9}
  %t60 = trunc i64 1 to i32
  %t61 = icmp eq i32 %t58, %t60
  store i1 %t61, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t63 = load i1, ptr %l29, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t66 = xor i1 %a3, true
  store i1 %t66, ptr %l36, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb19
bb19:
  %t68 = load i1, ptr %l36, !tbaa !21
  br i1 %t68, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/load:Loader", ptr %t72, i32 0, i32 4
  %t75 = load ptr, ptr %t74, !tbaa !29
  store ptr %t75, ptr %l41, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/names:Resolver", ptr %t77, i32 0, i32 6
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = load %"compiler/source:Span", ptr %l2
  %t85 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t76, i64 %t80, %"compiler/source:Span" %t81)
  store { i64, [3 x i64] } %t85, ptr %l46
  br label %bb22
bb21:
  br label %bb31
bb22:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/names:Resolver", ptr %t86, i32 0, i32 13
  %t89 = load i1, ptr %t88, !tbaa !21
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l1, !tbaa !23
  %t95 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t91, i32 %t92)
  store { i64, ptr } %t95, ptr %l52
  br label %bb25
bb24:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t96, i32 %t97)
  store { i64, ptr } %t100, ptr %l57
  br label %bb27
bb25:
  %t101 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t109 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAlreadyDeclared(ptr %s2, ptr %s2, { i64, ptr } %t107)
  store %"compiler/msgs:Msg" %t109, ptr %l54
  br label %bb26
bb26:
  %t110 = load %"compiler/msgs:Msg", ptr %l54
  store %"compiler/msgs:Msg" %t110, ptr %l49
  br label %bb29
bb27:
  %t111 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t119 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredTwice(ptr %s2, ptr %s2, { i64, ptr } %t117)
  store %"compiler/msgs:Msg" %t119, ptr %l59
  br label %bb28
bb28:
  %t120 = load %"compiler/msgs:Msg", ptr %l59
  store %"compiler/msgs:Msg" %t120, ptr %l49
  br label %bb29
bb29:
  %t121 = load ptr, ptr %l41, !tbaa !29
  %t122 = load { i64, [3 x i64] }, ptr %l46
  %t123 = load %"compiler/msgs:Msg", ptr %l49
  %t124 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t121, { i64, [3 x i64] } %t122, %"compiler/msgs:Msg" %t123)
  store i64 %t124, ptr %l60
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i32, ptr %l1, !tbaa !23
  %t127 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoShadow(ptr %v0, ptr %t125, i32 %t126, %"compiler/source:Span" %t127)
  br label %bb32
bb32:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/names:Resolver", ptr %t132, i32 0, i32 6
  %t135 = load i64, ptr %t134, !tbaa !24
  %t136 = load i32, ptr %l1, !tbaa !23
  %t137 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t131, i64 %t135, i32 %t136, %"compiler/source:Span" %t137)
  br label %bb33
bb33:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l1, !tbaa !23
  %t144 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t142, i32 %t143, %"compiler/source:Span" %t144, i32 1)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRaised(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/names:raisedName"
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca %"compiler/names:raisedName"
  %l50 = alloca ptr
  %l52 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l61 = alloca i32
  %l64 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l79 = alloca { i64, ptr }
  %t124 = alloca i64
  %t141 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %t3
  store ptr %t3, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/names:Resolver", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/load:Loader", ptr %t8, i32 0, i32 5
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t10, i64 %t11)
  store ptr %t14, ptr %l17
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l17, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 8
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp slt i64 %t24, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t32, ptr %l26, !tbaa !27
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 %t33
  %t38 = load ptr, ptr %t37, !tbaa !39
  %t40 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t40, ptr %t38)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l5, !tbaa !24
  br label %bb3
bb9:
  store ptr %a2, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l9, !tbaa !24
  store i64 %t50, ptr %l34, !tbaa !24
  %t51 = load ptr, ptr %l8, !tbaa !29
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eLen_H9e36587759e47da85a29e6c0abff1d1c(ptr %v1, ptr %t51)
  store i64 %t53, ptr %l36
  br label %bb11
bb11:
  %t54 = load i64, ptr %l34, !tbaa !24
  %t55 = load i64, ptr %l36, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  br label %bb30
bb13:
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l8, !tbaa !29
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = call %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %v1, ptr %t60, i64 %t61)
  store %"compiler/names:raisedName" %t64, ptr %l41
  br label %bb15
bb15:
  %t65 = load %"compiler/names:raisedName", ptr %l41
  store %"compiler/names:raisedName" %t65, ptr %l10
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t70 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 1
  %t71 = load %"compiler/source:Span", ptr %t70
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v0, ptr %t66, i64 %t67, i32 %t69, %"compiler/source:Span" %t71, ptr null)
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/names:Resolver", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/load:Loader", ptr %t79, i32 0, i32 5
  %t82 = load i64, ptr %l1, !tbaa !24
  %t85 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t81, i64 %t82)
  store ptr %t85, ptr %l50
  br label %bb17
bb17:
  %t86 = load ptr, ptr %l50, !tbaa !29
  %t88 = getelementptr %"compiler/load:Module", ptr %t86, i32 0, i32 9
  store ptr %t88, ptr %l52, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 0
  %t91 = load i32, ptr %t90, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t89, i32 %t91)
  store { i64, ptr } %t94, ptr %l55
  br label %bb18
bb18:
  %t95 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t96, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t108, { i64, ptr } %t107)
  br label %bb19
bb19:
  %t110 = load ptr, ptr %l3, !tbaa !29
  store ptr %t110, ptr %l58, !tbaa !29
  %t111 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 1
  %t112 = load %"compiler/source:Span", ptr %t111
  store %"compiler/source:Span" %t112, ptr %l59
  %t113 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 0
  %t114 = load i32, ptr %t113, !tbaa !23
  store i32 %t114, ptr %l60, !tbaa !23
  %t115 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 0
  %t116 = load i32, ptr %t115, !tbaa !23
  store i32 %t116, ptr %l61, !tbaa !23
  %t117 = icmp sge i64 1, 0
  br i1 %t117, label %bb20, label %bb21
bb20:
  %t119 = icmp sle i64 1, 2305843009213693951
  br i1 %t119, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a58fd8af443a076b_ecb4599a293195d7)
  unreachable
bb22:
  %t121 = mul i64 1, 4
  %t122 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t121)
  %t123 = load i32, ptr %l61, !tbaa !23
  store i64 0, ptr %t124
  br label %fill.125
fill.125:
  %t128 = load i64, ptr %t124
  %t129 = icmp slt i64 %t128, 1
  br i1 %t129, label %fillb.126, label %filld.127
fillb.126:
  %t130 = getelementptr i32, ptr %t122, i64 %t128
  store i32 %t123, ptr %t130
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %t124
  br label %fill.125
filld.127:
  %t132 = insertvalue { i64, ptr } undef, i64 1, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t122, 1
  store { i64, ptr } %t133, ptr %l64, !tbaa !27
  %t134 = icmp sge i64 0, 0
  br i1 %t134, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a58fd8af443a076b_ecb4599a293195d7)
  unreachable
bb24:
  %t136 = icmp sle i64 0, 1152921504606846975
  br i1 %t136, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_a58fd8af443a076b_ecb4599a293195d7)
  unreachable
bb26:
  %t138 = mul i64 0, 8
  %t139 = insertvalue { i64, ptr } undef, i64 0, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [6 x i64] }, ptr %t141, i32 0, i32 0
  store i64 5, ptr %t142
  %t143 = load %"compiler/source:Span", ptr %l59
  %t144 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t143, 0
  %t145 = load i32, ptr %l60, !tbaa !23
  %t146 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } } %t144, i32 %t145, 1
  %t147 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t148 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } } %t146, { i64, ptr } %t147, 2
  %t150 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } } %t148, { i64, ptr } %t140, 3
  %t151 = getelementptr { i64, [6 x i64] }, ptr %t141, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } } %t150, ptr %t151
  %t152 = load { i64, [6 x i64] }, ptr %t141
  %t154 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t152, ptr %t154
  %t155 = load ptr, ptr %l58, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t155, ptr %t154)
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_a58fd8af443a076b_ecb4599a293195d7)
  unreachable
bb28:
  br label %bb29
bb29:
  %t157 = load i64, ptr %l9, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l9, !tbaa !24
  br label %bb10
bb30:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/names:Resolver", ptr %t161, i32 0, i32 0
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/load:Loader", ptr %t164, i32 0, i32 5
  %t167 = load i64, ptr %l1, !tbaa !24
  %t170 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t166, i64 %t167)
  store ptr %t170, ptr %l76
  br label %bb31
bb31:
  %t171 = load ptr, ptr %l76, !tbaa !29
  store ptr %t171, ptr %l77, !tbaa !29
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eToArray_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t172)
  store { i64, ptr } %t174, ptr %l79
  br label %bb32
bb32:
  %t175 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t176 = load ptr, ptr %l77, !tbaa !29
  %t177 = getelementptr %"compiler/load:Module", ptr %t176, i32 0, i32 8
  store { i64, ptr } %t175, ptr %t177, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/names:local"
  %l8 = alloca i64
  %l14 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca %"compiler/names:local"
  %l25 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l34 = alloca %"compiler/names:local"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 7
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t7, i32 %a1, %"compiler/source:Span" %a2, i1 false)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/names:Resolver", ptr %t13, i32 0, i32 7
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l14
  br label %bb3
bb3:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l14, !tbaa !24
  %t21 = icmp sgt i64 %t19, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/names:Resolver", ptr %t23, i32 0, i32 7
  store ptr %t25, ptr %l18, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/names:Resolver", ptr %t26, i32 0, i32 7
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l21
  br label %bb6
bb5:
  br label %bb11
bb6:
  %t31 = load i64, ptr %l21, !tbaa !24
  %t32 = sub i64 %t31, 1
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t35 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t33, i64 %t32)
  store %"compiler/names:local" %t35, ptr %l23
  br label %bb7
bb7:
  %t36 = load %"compiler/names:local", ptr %l23
  store %"compiler/names:local" %t36, ptr %l5
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t37, i32 0, i32 7
  store ptr %t39, ptr %l25, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 7
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l28
  br label %bb8
bb8:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = sub i64 %t45, 1
  store i64 %t46, ptr %l29, !tbaa !24
  %t47 = getelementptr %"compiler/names:local", ptr %l5, i32 0, i32 0
  %t48 = load i32, ptr %t47, !tbaa !23
  %t49 = getelementptr %"compiler/names:local", ptr %l5, i32 0, i32 1
  %t50 = load %"compiler/source:Span", ptr %t49
  %t51 = getelementptr %"compiler/names:local", ptr %l5, i32 0, i32 2
  %t52 = load i32, ptr %t51, !range !{i32 0, i32 9}
  %t58 = call %"compiler/names:local" @compiler_2fnames_3alocal_2ector(ptr %s1, i32 %t48, %"compiler/source:Span" %t50, i32 %t52, i1 true, i1 %a3, i1 false)
  store %"compiler/names:local" %t58, ptr %l34
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l25, !tbaa !29
  %t60 = load i64, ptr %l29, !tbaa !24
  %t61 = load %"compiler/names:local", ptr %l34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eSetAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t59, i64 %t60, %"compiler/names:local" %t61)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edropAll(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l23 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l45 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 17
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:If", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_aef4624c79a8a28b_a45312851bdbb01f)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:If", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Branch", ptr %t14, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  %t19 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t19, %"compiler/source:Span" %t18)
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/ast:If", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = icmp eq ptr %t24, null
  br i1 %t26, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_87cbb522e5e56b9c_2473c9b69de9380)
  unreachable
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:If", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Branch", ptr %t31, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/names:Resolver", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/load:Loader", ptr %t42, i32 0, i32 4
  %t45 = load ptr, ptr %t44, !tbaa !29
  store ptr %t45, ptr %l23, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/ast:If", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb10, label %bb11
bb9:
  br label %bb14
bb10:
  call void @__olang_check_failed(ptr @olang_loc_87cbb522e5e56b9c_2473c9b69de9380)
  unreachable
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/ast:If", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t59 = getelementptr %"compiler/ast:Branch", ptr %t56, i32 0, i32 2
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCutOff(ptr %v0, ptr %t61, i64 %t60)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/ast:If", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/ast:If", ptr %t70, i32 0, i32 2
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l2, !tbaa !29
  %t75 = load ptr, ptr %l2, !tbaa !29
  store ptr %t75, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t76 = load ptr, ptr %l36, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t79 = load ptr, ptr %l36, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 22}
  %t82 = icmp eq i64 %t80, 5
  store i1 %t82, ptr %l37, !tbaa !21
  br label %bb19
bb19:
  %t83 = load i1, ptr %l37, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", ptr }, ptr %t86, i32 0, i32 1
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edropAll(ptr %v0, ptr %v1, ptr %t90, ptr %t91)
  br label %bb23
bb23:
  br label %bb34
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/names:Resolver", ptr %t94, i32 0, i32 17
  store ptr %t96, ptr %l45, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/ast:If", ptr %t97, i32 0, i32 2
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_12490b43c47bea91_b34a6c7dd92a3b95)
  unreachable
bb29:
  br label %bb30
bb30:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/ast:If", ptr %t104, i32 0, i32 2
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t107)
  store %"compiler/source:Span" %t109, ptr %l51
  br label %bb31
bb31:
  %t110 = load ptr, ptr %l45, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l51
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t110, %"compiler/source:Span" %t111)
  br label %bb32
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_f9018996705a58e9_83925e810340c2fd)
  unreachable
bb34:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l66 = alloca i1
  %l67 = alloca i64
  %l68 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i1
  %l161 = alloca { i64, ptr }
  %l169 = alloca ptr
  %l170 = alloca i1
  %l188 = alloca ptr
  %l189 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca i1
  %l228 = alloca { i64, ptr }
  %l236 = alloca ptr
  %l237 = alloca i1
  %l246 = alloca ptr
  %l249 = alloca %"compiler/names:Ref"
  %l260 = alloca { i64, ptr }
  %l268 = alloca ptr
  %l269 = alloca i1
  %l286 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l295 = alloca i1
  %l308 = alloca ptr
  %l309 = alloca i1
  %l326 = alloca { i64, ptr }
  %l334 = alloca ptr
  %l335 = alloca i1
  %l351 = alloca ptr
  %l352 = alloca i1
  %l372 = alloca { i64, ptr }
  %l380 = alloca ptr
  %l381 = alloca i1
  %l386 = alloca ptr
  %l387 = alloca i1
  %l392 = alloca ptr
  %l393 = alloca i1
  %l405 = alloca { i64, ptr }
  %l413 = alloca ptr
  %l414 = alloca i1
  %l433 = alloca i64
  %l449 = alloca ptr
  %l450 = alloca i1
  %l462 = alloca ptr
  %l463 = alloca i1
  %l472 = alloca i64
  %l492 = alloca ptr
  %l493 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t6 = load ptr, ptr %l71, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l71, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 29}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l72, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l72, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32 }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32 }, ptr %t22, i32 0, i32 1
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l2
  %t28 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ename(ptr %v0, ptr %t26, %"compiler/source:Span" %t27, i32 %t28)
  br label %bb9
bb9:
  br label %bb249
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t33 = load ptr, ptr %l82, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l82, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 29}
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l83, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l83, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb27
bb14:
  %t47 = load ptr, ptr %l1, !tbaa !29
  store ptr %t47, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t48 = load ptr, ptr %l88, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l88, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 29}
  %t54 = icmp eq i64 %t52, 27
  store i1 %t54, ptr %l89, !tbaa !21
  br label %bb16
bb16:
  %t55 = load i1, ptr %l89, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb27
bb18:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t63 = load ptr, ptr %l94, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t66 = load ptr, ptr %l94, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 29}
  %t69 = icmp eq i64 %t67, 3
  store i1 %t69, ptr %l95, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l95, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l4, !tbaa !29
  br label %bb27
bb22:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t78 = load ptr, ptr %l100, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb23, label %bb24
bb23:
  %t81 = load ptr, ptr %l100, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 29}
  %t84 = icmp eq i64 %t82, 4
  store i1 %t84, ptr %l101, !tbaa !21
  br label %bb24
bb24:
  %t85 = load i1, ptr %l101, !tbaa !21
  br i1 %t85, label %bb25, label %bb26
bb25:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l4, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  br label %bb28
bb28:
  br label %bb249
bb29:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t98 = load ptr, ptr %l109, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb30, label %bb31
bb30:
  %t101 = load ptr, ptr %l109, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 29}
  %t104 = icmp eq i64 %t102, 28
  store i1 %t104, ptr %l110, !tbaa !21
  br label %bb31
bb31:
  %t105 = load i1, ptr %l110, !tbaa !21
  br i1 %t105, label %bb32, label %bb33
bb32:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", ptr }, ptr %t108, i32 0, i32 1
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l5, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t112, ptr %t113)
  br label %bb35
bb35:
  br label %bb249
bb36:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t117 = load ptr, ptr %l117, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb37, label %bb38
bb37:
  %t120 = load ptr, ptr %l117, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 29}
  %t123 = icmp eq i64 %t121, 5
  store i1 %t123, ptr %l118, !tbaa !21
  br label %bb38
bb38:
  %t124 = load i1, ptr %l118, !tbaa !21
  br i1 %t124, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t127, i32 0, i32 2
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l6, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr { i64, [5 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t133, i32 0, i32 3
  %t135 = load ptr, ptr %t134
  store ptr %t135, ptr %l7, !tbaa !29
  br label %bb49
bb40:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t138 = load ptr, ptr %l125, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb41, label %bb42
bb41:
  %t141 = load ptr, ptr %l125, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 29}
  %t144 = icmp eq i64 %t142, 6
  store i1 %t144, ptr %l126, !tbaa !21
  br label %bb42
bb42:
  %t145 = load i1, ptr %l126, !tbaa !21
  br i1 %t145, label %bb43, label %bb44
bb43:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t148, i32 0, i32 1
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l6, !tbaa !29
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t154, i32 0, i32 2
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l7, !tbaa !29
  br label %bb49
bb44:
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t159 = load ptr, ptr %l133, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb45, label %bb46
bb45:
  %t162 = load ptr, ptr %l133, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 29}
  %t165 = icmp eq i64 %t163, 10
  store i1 %t165, ptr %l134, !tbaa !21
  br label %bb46
bb46:
  %t166 = load i1, ptr %l134, !tbaa !21
  br i1 %t166, label %bb47, label %bb48
bb47:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t169, i32 0, i32 1
  %t171 = load ptr, ptr %t170
  store ptr %t171, ptr %l6, !tbaa !29
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t175, i32 0, i32 2
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l7, !tbaa !29
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  br label %bb50
bb50:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t184, ptr %t185)
  br label %bb51
bb51:
  br label %bb249
bb52:
  %t189 = load ptr, ptr %l1, !tbaa !29
  store ptr %t189, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t190 = load ptr, ptr %l147, !tbaa !29
  %t191 = icmp ne ptr %t190, null
  br i1 %t191, label %bb53, label %bb54
bb53:
  %t193 = load ptr, ptr %l147, !tbaa !29
  %t194 = load i64, ptr %t193, !range !{i64 0, i64 29}
  %t196 = icmp eq i64 %t194, 7
  store i1 %t196, ptr %l148, !tbaa !21
  br label %bb54
bb54:
  %t197 = load i1, ptr %l148, !tbaa !21
  br i1 %t197, label %bb55, label %bb56
bb55:
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { %"compiler/source:Span", ptr }, ptr %t200, i32 0, i32 1
  %t202 = load ptr, ptr %t201
  store ptr %t202, ptr %l8, !tbaa !29
  br label %bb57
bb56:
  br label %bb65
bb57:
  %t204 = load ptr, ptr %l8, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Chain", ptr %t204, i32 0, i32 1
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  store { i64, ptr } %t207, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  store i64 %t211, ptr %l11, !tbaa !24
  br label %bb58
bb58:
  %t213 = load i64, ptr %l10, !tbaa !24
  %t214 = load i64, ptr %l11, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb59, label %bb60
bb59:
  br label %bb64
bb60:
  br label %bb61
bb61:
  %t221 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t221, ptr %l161, !tbaa !27
  %t222 = load i64, ptr %l10, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 %t222
  %t227 = load ptr, ptr %t226, !tbaa !39
  %t229 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t229, ptr %t227)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t234 = load i64, ptr %l10, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l10, !tbaa !24
  br label %bb58
bb64:
  br label %bb249
bb65:
  %t238 = load ptr, ptr %l1, !tbaa !29
  store ptr %t238, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t239 = load ptr, ptr %l169, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb66, label %bb67
bb66:
  %t242 = load ptr, ptr %l169, !tbaa !29
  %t243 = load i64, ptr %t242, !range !{i64 0, i64 29}
  %t245 = icmp eq i64 %t243, 8
  store i1 %t245, ptr %l170, !tbaa !21
  br label %bb67
bb67:
  %t246 = load i1, ptr %l170, !tbaa !21
  br i1 %t246, label %bb68, label %bb69
bb68:
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t249 = getelementptr { i64, [5 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t249, i32 0, i32 1
  %t251 = load ptr, ptr %t250
  store ptr %t251, ptr %l13, !tbaa !29
  %t253 = load ptr, ptr %l1, !tbaa !29
  %t255 = getelementptr { i64, [5 x i64] }, ptr %t253, i32 0, i32 1
  %t256 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t255, i32 0, i32 2
  %t257 = load ptr, ptr %t256
  store ptr %t257, ptr %l14, !tbaa !29
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr { i64, [5 x i64] }, ptr %t259, i32 0, i32 1
  %t262 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t261, i32 0, i32 3
  %t263 = load ptr, ptr %t262
  store ptr %t263, ptr %l15, !tbaa !29
  br label %bb70
bb69:
  br label %bb74
bb70:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t265, ptr %t266)
  br label %bb71
bb71:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t270, ptr %t271)
  br label %bb72
bb72:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t275, ptr %t276)
  br label %bb73
bb73:
  br label %bb249
bb74:
  %t280 = load ptr, ptr %l1, !tbaa !29
  store ptr %t280, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t281 = load ptr, ptr %l188, !tbaa !29
  %t282 = icmp ne ptr %t281, null
  br i1 %t282, label %bb75, label %bb76
bb75:
  %t284 = load ptr, ptr %l188, !tbaa !29
  %t285 = load i64, ptr %t284, !range !{i64 0, i64 29}
  %t287 = icmp eq i64 %t285, 9
  store i1 %t287, ptr %l189, !tbaa !21
  br label %bb76
bb76:
  %t288 = load i1, ptr %l189, !tbaa !21
  br i1 %t288, label %bb77, label %bb78
bb77:
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 1
  %t292 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t291, i32 0, i32 1
  %t293 = load ptr, ptr %t292
  store ptr %t293, ptr %l16, !tbaa !29
  %t295 = load ptr, ptr %l1, !tbaa !29
  %t297 = getelementptr { i64, [5 x i64] }, ptr %t295, i32 0, i32 1
  %t298 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t297, i32 0, i32 2
  %t299 = load ptr, ptr %t298
  store ptr %t299, ptr %l17, !tbaa !29
  br label %bb83
bb78:
  %t301 = load ptr, ptr %l1, !tbaa !29
  store ptr %t301, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t302 = load ptr, ptr %l196, !tbaa !29
  %t303 = icmp ne ptr %t302, null
  br i1 %t303, label %bb79, label %bb80
bb79:
  %t305 = load ptr, ptr %l196, !tbaa !29
  %t306 = load i64, ptr %t305, !range !{i64 0, i64 29}
  %t308 = icmp eq i64 %t306, 11
  store i1 %t308, ptr %l197, !tbaa !21
  br label %bb80
bb80:
  %t309 = load i1, ptr %l197, !tbaa !21
  br i1 %t309, label %bb81, label %bb82
bb81:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr { i64, [5 x i64] }, ptr %t310, i32 0, i32 1
  %t313 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t312, i32 0, i32 1
  %t314 = load ptr, ptr %t313
  store ptr %t314, ptr %l16, !tbaa !29
  %t316 = load ptr, ptr %l1, !tbaa !29
  %t318 = getelementptr { i64, [5 x i64] }, ptr %t316, i32 0, i32 1
  %t319 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t318, i32 0, i32 2
  %t320 = load ptr, ptr %t319
  store ptr %t320, ptr %l17, !tbaa !29
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t322, ptr %t323)
  br label %bb84
bb84:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t327, ptr %t328)
  br label %bb85
bb85:
  br label %bb249
bb86:
  %t332 = load ptr, ptr %l1, !tbaa !29
  store ptr %t332, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t333 = load ptr, ptr %l210, !tbaa !29
  %t334 = icmp ne ptr %t333, null
  br i1 %t334, label %bb87, label %bb88
bb87:
  %t336 = load ptr, ptr %l210, !tbaa !29
  %t337 = load i64, ptr %t336, !range !{i64 0, i64 29}
  %t339 = icmp eq i64 %t337, 12
  store i1 %t339, ptr %l211, !tbaa !21
  br label %bb88
bb88:
  %t340 = load i1, ptr %l211, !tbaa !21
  br i1 %t340, label %bb89, label %bb90
bb89:
  %t341 = load ptr, ptr %l1, !tbaa !29
  %t343 = getelementptr { i64, [5 x i64] }, ptr %t341, i32 0, i32 1
  %t344 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t343, i32 0, i32 1
  %t345 = load ptr, ptr %t344
  store ptr %t345, ptr %l18, !tbaa !29
  %t347 = load ptr, ptr %l1, !tbaa !29
  %t349 = getelementptr { i64, [5 x i64] }, ptr %t347, i32 0, i32 1
  %t350 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t349, i32 0, i32 2
  %t351 = load { i64, ptr }, ptr %t350
  store { i64, ptr } %t351, ptr %l19, !tbaa !27
  br label %bb91
bb90:
  br label %bb100
bb91:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t353, ptr %t354)
  br label %bb92
bb92:
  %t358 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t358, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t360 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t360, 0
  store i64 %t362, ptr %l22, !tbaa !24
  br label %bb93
bb93:
  %t364 = load i64, ptr %l21, !tbaa !24
  %t365 = load i64, ptr %l22, !tbaa !24
  %t368 = icmp slt i64 %t364, %t365
  %t370 = xor i1 %t368, true
  br i1 %t370, label %bb94, label %bb95
bb94:
  br label %bb99
bb95:
  br label %bb96
bb96:
  %t372 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t372, ptr %l228, !tbaa !27
  %t373 = load i64, ptr %l21, !tbaa !24
  %t375 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr ptr, ptr %t376, i64 %t373
  %t378 = load ptr, ptr %t377, !tbaa !39
  %t380 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t380, ptr %t378)
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t385 = load i64, ptr %l21, !tbaa !24
  %t387 = add i64 %t385, 1
  store i64 %t387, ptr %l21, !tbaa !24
  br label %bb93
bb99:
  br label %bb249
bb100:
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t390 = load ptr, ptr %l236, !tbaa !29
  %t391 = icmp ne ptr %t390, null
  br i1 %t391, label %bb101, label %bb102
bb101:
  %t393 = load ptr, ptr %l236, !tbaa !29
  %t394 = load i64, ptr %t393, !range !{i64 0, i64 29}
  %t396 = icmp eq i64 %t394, 13
  store i1 %t396, ptr %l237, !tbaa !21
  br label %bb102
bb102:
  %t397 = load i1, ptr %l237, !tbaa !21
  br i1 %t397, label %bb103, label %bb104
bb103:
  %t398 = load ptr, ptr %l1, !tbaa !29
  %t400 = getelementptr { i64, [5 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t400, i32 0, i32 1
  %t402 = load ptr, ptr %t401
  store ptr %t402, ptr %l24, !tbaa !29
  %t404 = load ptr, ptr %l1, !tbaa !29
  %t406 = getelementptr { i64, [5 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t406, i32 0, i32 2
  %t408 = load i32, ptr %t407
  store i32 %t408, ptr %l25, !tbaa !23
  %t410 = load ptr, ptr %l1, !tbaa !29
  %t412 = getelementptr { i64, [5 x i64] }, ptr %t410, i32 0, i32 1
  %t413 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t412, i32 0, i32 3
  %t414 = load { i64, ptr }, ptr %t413
  store { i64, ptr } %t414, ptr %l26, !tbaa !27
  br label %bb105
bb104:
  br label %bb116
bb105:
  %t416 = load ptr, ptr %l0, !tbaa !29
  store ptr %t416, ptr %l246, !tbaa !29
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load i32, ptr %l25, !tbaa !23
  %t421 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t417, i32 %t418)
  store %"compiler/names:Ref" %t421, ptr %l249
  br label %bb106
bb106:
  %t422 = load ptr, ptr %l246, !tbaa !29
  %t423 = load %"compiler/names:Ref", ptr %l249
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eread(ptr %v0, ptr %t422, %"compiler/names:Ref" %t423)
  br label %bb107
bb107:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t424, ptr %t425)
  br label %bb108
bb108:
  %t429 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t429, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t431 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t431, 0
  store i64 %t433, ptr %l29, !tbaa !24
  br label %bb109
bb109:
  %t435 = load i64, ptr %l28, !tbaa !24
  %t436 = load i64, ptr %l29, !tbaa !24
  %t439 = icmp slt i64 %t435, %t436
  %t441 = xor i1 %t439, true
  br i1 %t441, label %bb110, label %bb111
bb110:
  br label %bb115
bb111:
  br label %bb112
bb112:
  %t443 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t443, ptr %l260, !tbaa !27
  %t444 = load i64, ptr %l28, !tbaa !24
  %t446 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr ptr, ptr %t447, i64 %t444
  %t449 = load ptr, ptr %t448, !tbaa !39
  %t451 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t451, ptr %t449)
  br label %bb113
bb113:
  br label %bb114
bb114:
  %t456 = load i64, ptr %l28, !tbaa !24
  %t458 = add i64 %t456, 1
  store i64 %t458, ptr %l28, !tbaa !24
  br label %bb109
bb115:
  br label %bb249
bb116:
  %t460 = load ptr, ptr %l1, !tbaa !29
  store ptr %t460, ptr %l268, !tbaa !29
  store i1 false, ptr %l269, !tbaa !21
  %t461 = load ptr, ptr %l268, !tbaa !29
  %t462 = icmp ne ptr %t461, null
  br i1 %t462, label %bb117, label %bb118
bb117:
  %t464 = load ptr, ptr %l268, !tbaa !29
  %t465 = load i64, ptr %t464, !range !{i64 0, i64 29}
  %t467 = icmp eq i64 %t465, 14
  store i1 %t467, ptr %l269, !tbaa !21
  br label %bb118
bb118:
  %t468 = load i1, ptr %l269, !tbaa !21
  br i1 %t468, label %bb119, label %bb120
bb119:
  %t469 = load ptr, ptr %l1, !tbaa !29
  %t471 = getelementptr { i64, [5 x i64] }, ptr %t469, i32 0, i32 1
  %t472 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t471, i32 0, i32 1
  %t473 = load ptr, ptr %t472
  store ptr %t473, ptr %l31, !tbaa !29
  %t475 = load ptr, ptr %l1, !tbaa !29
  %t477 = getelementptr { i64, [5 x i64] }, ptr %t475, i32 0, i32 1
  %t478 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t477, i32 0, i32 2
  %t479 = load { i64, ptr }, ptr %t478
  store { i64, ptr } %t479, ptr %l32, !tbaa !27
  br label %bb121
bb120:
  br label %bb130
bb121:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t481, ptr %t482)
  br label %bb122
bb122:
  %t486 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t486, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t488 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t490 = extractvalue { i64, ptr } %t488, 0
  store i64 %t490, ptr %l35, !tbaa !24
  br label %bb123
bb123:
  %t492 = load i64, ptr %l34, !tbaa !24
  %t493 = load i64, ptr %l35, !tbaa !24
  %t496 = icmp slt i64 %t492, %t493
  %t498 = xor i1 %t496, true
  br i1 %t498, label %bb124, label %bb125
bb124:
  br label %bb129
bb125:
  br label %bb126
bb126:
  %t500 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t500, ptr %l286, !tbaa !27
  %t501 = load i64, ptr %l34, !tbaa !24
  %t503 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !27
  %t505 = getelementptr ptr, ptr %t504, i64 %t501
  %t506 = load ptr, ptr %t505, !tbaa !39
  %t508 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t508, ptr %t506)
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t513 = load i64, ptr %l34, !tbaa !24
  %t515 = add i64 %t513, 1
  store i64 %t515, ptr %l34, !tbaa !24
  br label %bb123
bb129:
  br label %bb249
bb130:
  %t517 = load ptr, ptr %l1, !tbaa !29
  store ptr %t517, ptr %l294, !tbaa !29
  store i1 false, ptr %l295, !tbaa !21
  %t518 = load ptr, ptr %l294, !tbaa !29
  %t519 = icmp ne ptr %t518, null
  br i1 %t519, label %bb131, label %bb132
bb131:
  %t521 = load ptr, ptr %l294, !tbaa !29
  %t522 = load i64, ptr %t521, !range !{i64 0, i64 29}
  %t524 = icmp eq i64 %t522, 15
  store i1 %t524, ptr %l295, !tbaa !21
  br label %bb132
bb132:
  %t525 = load i1, ptr %l295, !tbaa !21
  br i1 %t525, label %bb133, label %bb134
bb133:
  %t526 = load ptr, ptr %l1, !tbaa !29
  %t528 = getelementptr { i64, [5 x i64] }, ptr %t526, i32 0, i32 1
  %t529 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t528, i32 0, i32 0
  %t530 = load %"compiler/source:Span", ptr %t529
  store %"compiler/source:Span" %t530, ptr %l37
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr { i64, [5 x i64] }, ptr %t532, i32 0, i32 1
  %t535 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t534, i32 0, i32 1
  %t536 = load ptr, ptr %t535
  store ptr %t536, ptr %l38, !tbaa !29
  %t538 = load ptr, ptr %l1, !tbaa !29
  %t540 = getelementptr { i64, [5 x i64] }, ptr %t538, i32 0, i32 1
  %t541 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t540, i32 0, i32 2
  %t542 = load i32, ptr %t541
  store i32 %t542, ptr %l39, !tbaa !23
  br label %bb135
bb134:
  br label %bb137
bb135:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t545 = load %"compiler/source:Span", ptr %l37
  %t546 = load ptr, ptr %l38, !tbaa !29
  %t547 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emember(ptr %v0, ptr %v1, ptr %t544, %"compiler/source:Span" %t545, ptr %t546, i32 %t547)
  br label %bb136
bb136:
  br label %bb249
bb137:
  %t552 = load ptr, ptr %l1, !tbaa !29
  store ptr %t552, ptr %l308, !tbaa !29
  store i1 false, ptr %l309, !tbaa !21
  %t553 = load ptr, ptr %l308, !tbaa !29
  %t554 = icmp ne ptr %t553, null
  br i1 %t554, label %bb138, label %bb139
bb138:
  %t556 = load ptr, ptr %l308, !tbaa !29
  %t557 = load i64, ptr %t556, !range !{i64 0, i64 29}
  %t559 = icmp eq i64 %t557, 16
  store i1 %t559, ptr %l309, !tbaa !21
  br label %bb139
bb139:
  %t560 = load i1, ptr %l309, !tbaa !21
  br i1 %t560, label %bb140, label %bb141
bb140:
  %t561 = load ptr, ptr %l1, !tbaa !29
  %t563 = getelementptr { i64, [5 x i64] }, ptr %t561, i32 0, i32 1
  %t564 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t563, i32 0, i32 1
  %t565 = load ptr, ptr %t564
  store ptr %t565, ptr %l40, !tbaa !29
  %t567 = load ptr, ptr %l1, !tbaa !29
  %t569 = getelementptr { i64, [5 x i64] }, ptr %t567, i32 0, i32 1
  %t570 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t569, i32 0, i32 2
  %t571 = load { i64, ptr }, ptr %t570
  store { i64, ptr } %t571, ptr %l41, !tbaa !27
  br label %bb142
bb141:
  br label %bb151
bb142:
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t574 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t573, ptr %t574)
  br label %bb143
bb143:
  %t578 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t578, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t580 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t582 = extractvalue { i64, ptr } %t580, 0
  store i64 %t582, ptr %l44, !tbaa !24
  br label %bb144
bb144:
  %t584 = load i64, ptr %l43, !tbaa !24
  %t585 = load i64, ptr %l44, !tbaa !24
  %t588 = icmp slt i64 %t584, %t585
  %t590 = xor i1 %t588, true
  br i1 %t590, label %bb145, label %bb146
bb145:
  br label %bb150
bb146:
  br label %bb147
bb147:
  %t592 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t592, ptr %l326, !tbaa !27
  %t593 = load i64, ptr %l43, !tbaa !24
  %t595 = getelementptr { i64, ptr }, ptr %l326, i32 0, i32 1
  %t596 = load ptr, ptr %t595, !tbaa !27
  %t597 = getelementptr ptr, ptr %t596, i64 %t593
  %t598 = load ptr, ptr %t597, !tbaa !39
  %t600 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t600, ptr %t598)
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t605 = load i64, ptr %l43, !tbaa !24
  %t607 = add i64 %t605, 1
  store i64 %t607, ptr %l43, !tbaa !24
  br label %bb144
bb150:
  br label %bb249
bb151:
  %t609 = load ptr, ptr %l1, !tbaa !29
  store ptr %t609, ptr %l334, !tbaa !29
  store i1 false, ptr %l335, !tbaa !21
  %t610 = load ptr, ptr %l334, !tbaa !29
  %t611 = icmp ne ptr %t610, null
  br i1 %t611, label %bb152, label %bb153
bb152:
  %t613 = load ptr, ptr %l334, !tbaa !29
  %t614 = load i64, ptr %t613, !range !{i64 0, i64 29}
  %t616 = icmp eq i64 %t614, 17
  store i1 %t616, ptr %l335, !tbaa !21
  br label %bb153
bb153:
  %t617 = load i1, ptr %l335, !tbaa !21
  br i1 %t617, label %bb154, label %bb155
bb154:
  %t618 = load ptr, ptr %l1, !tbaa !29
  %t620 = getelementptr { i64, [5 x i64] }, ptr %t618, i32 0, i32 1
  %t621 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t620, i32 0, i32 1
  %t622 = load ptr, ptr %t621
  store ptr %t622, ptr %l46, !tbaa !29
  %t624 = load ptr, ptr %l1, !tbaa !29
  %t626 = getelementptr { i64, [5 x i64] }, ptr %t624, i32 0, i32 1
  %t627 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t626, i32 0, i32 2
  %t628 = load ptr, ptr %t627
  store ptr %t628, ptr %l47, !tbaa !29
  %t630 = load ptr, ptr %l1, !tbaa !29
  %t632 = getelementptr { i64, [5 x i64] }, ptr %t630, i32 0, i32 1
  %t633 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t632, i32 0, i32 3
  %t634 = load ptr, ptr %t633
  store ptr %t634, ptr %l48, !tbaa !29
  br label %bb156
bb155:
  br label %bb160
bb156:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t637 = load ptr, ptr %l46, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t636, ptr %t637)
  br label %bb157
bb157:
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t641, ptr %t642)
  br label %bb158
bb158:
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t646 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t645, ptr %t646)
  br label %bb159
bb159:
  br label %bb249
bb160:
  %t649 = load ptr, ptr %l1, !tbaa !29
  store ptr %t649, ptr %l351, !tbaa !29
  store i1 false, ptr %l352, !tbaa !21
  %t650 = load ptr, ptr %l351, !tbaa !29
  %t651 = icmp ne ptr %t650, null
  br i1 %t651, label %bb161, label %bb162
bb161:
  %t653 = load ptr, ptr %l351, !tbaa !29
  %t654 = load i64, ptr %t653, !range !{i64 0, i64 29}
  %t656 = icmp eq i64 %t654, 18
  store i1 %t656, ptr %l352, !tbaa !21
  br label %bb162
bb162:
  %t657 = load i1, ptr %l352, !tbaa !21
  br i1 %t657, label %bb163, label %bb164
bb163:
  %t658 = load ptr, ptr %l1, !tbaa !29
  %t660 = getelementptr { i64, [5 x i64] }, ptr %t658, i32 0, i32 1
  %t661 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t660, i32 0, i32 1
  %t662 = load ptr, ptr %t661
  store ptr %t662, ptr %l49, !tbaa !29
  %t664 = load ptr, ptr %l1, !tbaa !29
  %t666 = getelementptr { i64, [5 x i64] }, ptr %t664, i32 0, i32 1
  %t667 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t666, i32 0, i32 2
  %t668 = load { i64, ptr }, ptr %t667
  store { i64, ptr } %t668, ptr %l50, !tbaa !27
  br label %bb165
bb164:
  br label %bb177
bb165:
  %t670 = load ptr, ptr %l49, !tbaa !29
  %t672 = icmp eq ptr %t670, null
  %t674 = xor i1 %t672, true
  br i1 %t674, label %bb166, label %bb167
bb166:
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t677 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t676, ptr %t677)
  br label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb169
bb169:
  %t681 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t681, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t683 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t685 = extractvalue { i64, ptr } %t683, 0
  store i64 %t685, ptr %l53, !tbaa !24
  br label %bb170
bb170:
  %t687 = load i64, ptr %l52, !tbaa !24
  %t688 = load i64, ptr %l53, !tbaa !24
  %t691 = icmp slt i64 %t687, %t688
  %t693 = xor i1 %t691, true
  br i1 %t693, label %bb171, label %bb172
bb171:
  br label %bb176
bb172:
  br label %bb173
bb173:
  %t695 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t695, ptr %l372, !tbaa !27
  %t696 = load i64, ptr %l52, !tbaa !24
  %t698 = getelementptr { i64, ptr }, ptr %l372, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !27
  %t700 = getelementptr ptr, ptr %t699, i64 %t696
  %t701 = load ptr, ptr %t700, !tbaa !39
  %t703 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t703, ptr %t701)
  br label %bb174
bb174:
  br label %bb175
bb175:
  %t708 = load i64, ptr %l52, !tbaa !24
  %t710 = add i64 %t708, 1
  store i64 %t710, ptr %l52, !tbaa !24
  br label %bb170
bb176:
  br label %bb249
bb177:
  %t712 = load ptr, ptr %l1, !tbaa !29
  store ptr %t712, ptr %l380, !tbaa !29
  store i1 false, ptr %l381, !tbaa !21
  %t713 = load ptr, ptr %l380, !tbaa !29
  %t714 = icmp ne ptr %t713, null
  br i1 %t714, label %bb178, label %bb179
bb178:
  %t716 = load ptr, ptr %l380, !tbaa !29
  %t717 = load i64, ptr %t716, !range !{i64 0, i64 29}
  %t719 = icmp eq i64 %t717, 19
  store i1 %t719, ptr %l381, !tbaa !21
  br label %bb179
bb179:
  %t720 = load i1, ptr %l381, !tbaa !21
  br i1 %t720, label %bb180, label %bb181
bb180:
  %t721 = load ptr, ptr %l1, !tbaa !29
  %t723 = getelementptr { i64, [5 x i64] }, ptr %t721, i32 0, i32 1
  %t724 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t723, i32 0, i32 1
  %t725 = load { i64, ptr }, ptr %t724
  store { i64, ptr } %t725, ptr %l55, !tbaa !27
  br label %bb190
bb181:
  %t727 = load ptr, ptr %l1, !tbaa !29
  store ptr %t727, ptr %l386, !tbaa !29
  store i1 false, ptr %l387, !tbaa !21
  %t728 = load ptr, ptr %l386, !tbaa !29
  %t729 = icmp ne ptr %t728, null
  br i1 %t729, label %bb182, label %bb183
bb182:
  %t731 = load ptr, ptr %l386, !tbaa !29
  %t732 = load i64, ptr %t731, !range !{i64 0, i64 29}
  %t734 = icmp eq i64 %t732, 21
  store i1 %t734, ptr %l387, !tbaa !21
  br label %bb183
bb183:
  %t735 = load i1, ptr %l387, !tbaa !21
  br i1 %t735, label %bb184, label %bb185
bb184:
  %t736 = load ptr, ptr %l1, !tbaa !29
  %t738 = getelementptr { i64, [5 x i64] }, ptr %t736, i32 0, i32 1
  %t739 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t738, i32 0, i32 1
  %t740 = load { i64, ptr }, ptr %t739
  store { i64, ptr } %t740, ptr %l55, !tbaa !27
  br label %bb190
bb185:
  %t742 = load ptr, ptr %l1, !tbaa !29
  store ptr %t742, ptr %l392, !tbaa !29
  store i1 false, ptr %l393, !tbaa !21
  %t743 = load ptr, ptr %l392, !tbaa !29
  %t744 = icmp ne ptr %t743, null
  br i1 %t744, label %bb186, label %bb187
bb186:
  %t746 = load ptr, ptr %l392, !tbaa !29
  %t747 = load i64, ptr %t746, !range !{i64 0, i64 29}
  %t749 = icmp eq i64 %t747, 25
  store i1 %t749, ptr %l393, !tbaa !21
  br label %bb187
bb187:
  %t750 = load i1, ptr %l393, !tbaa !21
  br i1 %t750, label %bb188, label %bb189
bb188:
  %t751 = load ptr, ptr %l1, !tbaa !29
  %t753 = getelementptr { i64, [5 x i64] }, ptr %t751, i32 0, i32 1
  %t754 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t753, i32 0, i32 1
  %t755 = load { i64, ptr }, ptr %t754
  store { i64, ptr } %t755, ptr %l55, !tbaa !27
  br label %bb190
bb189:
  br label %bb198
bb190:
  %t757 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t757, ptr %l56, !tbaa !27
  store i64 0, ptr %l57, !tbaa !24
  %t759 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t761 = extractvalue { i64, ptr } %t759, 0
  store i64 %t761, ptr %l58, !tbaa !24
  br label %bb191
bb191:
  %t763 = load i64, ptr %l57, !tbaa !24
  %t764 = load i64, ptr %l58, !tbaa !24
  %t767 = icmp slt i64 %t763, %t764
  %t769 = xor i1 %t767, true
  br i1 %t769, label %bb192, label %bb193
bb192:
  br label %bb197
bb193:
  br label %bb194
bb194:
  %t771 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t771, ptr %l405, !tbaa !27
  %t772 = load i64, ptr %l57, !tbaa !24
  %t774 = getelementptr { i64, ptr }, ptr %l405, i32 0, i32 1
  %t775 = load ptr, ptr %t774, !tbaa !27
  %t776 = getelementptr ptr, ptr %t775, i64 %t772
  %t777 = load ptr, ptr %t776, !tbaa !39
  %t779 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t779, ptr %t777)
  br label %bb195
bb195:
  br label %bb196
bb196:
  %t784 = load i64, ptr %l57, !tbaa !24
  %t786 = add i64 %t784, 1
  store i64 %t786, ptr %l57, !tbaa !24
  br label %bb191
bb197:
  br label %bb249
bb198:
  %t788 = load ptr, ptr %l1, !tbaa !29
  store ptr %t788, ptr %l413, !tbaa !29
  store i1 false, ptr %l414, !tbaa !21
  %t789 = load ptr, ptr %l413, !tbaa !29
  %t790 = icmp ne ptr %t789, null
  br i1 %t790, label %bb199, label %bb200
bb199:
  %t792 = load ptr, ptr %l413, !tbaa !29
  %t793 = load i64, ptr %t792, !range !{i64 0, i64 29}
  %t795 = icmp eq i64 %t793, 20
  store i1 %t795, ptr %l414, !tbaa !21
  br label %bb200
bb200:
  %t796 = load i1, ptr %l414, !tbaa !21
  br i1 %t796, label %bb201, label %bb202
bb201:
  %t797 = load ptr, ptr %l1, !tbaa !29
  %t799 = getelementptr { i64, [5 x i64] }, ptr %t797, i32 0, i32 1
  %t800 = getelementptr { %"compiler/source:Span", ptr }, ptr %t799, i32 0, i32 0
  %t801 = load %"compiler/source:Span", ptr %t800
  store %"compiler/source:Span" %t801, ptr %l60
  %t803 = load ptr, ptr %l1, !tbaa !29
  %t805 = getelementptr { i64, [5 x i64] }, ptr %t803, i32 0, i32 1
  %t806 = getelementptr { %"compiler/source:Span", ptr }, ptr %t805, i32 0, i32 1
  %t807 = load ptr, ptr %t806
  store ptr %t807, ptr %l61, !tbaa !29
  br label %bb203
bb202:
  br label %bb214
bb203:
  %t809 = load ptr, ptr %l61, !tbaa !29
  %t811 = getelementptr %"compiler/ast:Compr", ptr %t809, i32 0, i32 0
  %t812 = load ptr, ptr %t811, !tbaa !29
  %t814 = icmp eq ptr %t812, null
  %t816 = xor i1 %t814, true
  br i1 %t816, label %bb204, label %bb205
bb204:
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load ptr, ptr %l61, !tbaa !29
  %t821 = getelementptr %"compiler/ast:Compr", ptr %t819, i32 0, i32 0
  %t822 = load ptr, ptr %t821, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t818, ptr %t822)
  br label %bb206
bb205:
  br label %bb207
bb206:
  br label %bb207
bb207:
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t826 = load ptr, ptr %l61, !tbaa !29
  %t828 = getelementptr %"compiler/ast:Compr", ptr %t826, i32 0, i32 4
  %t829 = load ptr, ptr %t828, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t825, ptr %t829)
  br label %bb208
bb208:
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t835 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t833)
  store i64 %t835, ptr %l433
  br label %bb209
bb209:
  %t836 = load i64, ptr %l433, !tbaa !24
  store i64 %t836, ptr %l62, !tbaa !24
  %t837 = load ptr, ptr %l0, !tbaa !29
  %t838 = getelementptr %"compiler/source:Span", ptr %l60, i32 0, i32 0
  %t839 = load i32, ptr %t838, !tbaa !23
  %t840 = load ptr, ptr %l61, !tbaa !29
  %t842 = getelementptr %"compiler/ast:Compr", ptr %t840, i32 0, i32 2
  %t843 = load i32, ptr %t842, !tbaa !23
  %t844 = load ptr, ptr %l61, !tbaa !29
  %t846 = getelementptr %"compiler/ast:Compr", ptr %t844, i32 0, i32 3
  %t847 = load i32, ptr %t846, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforNames(ptr %v0, ptr %t837, i32 %t839, i32 %t843, i32 %t847)
  br label %bb210
bb210:
  %t852 = load ptr, ptr %l0, !tbaa !29
  %t853 = load ptr, ptr %l61, !tbaa !29
  %t855 = getelementptr %"compiler/ast:Compr", ptr %t853, i32 0, i32 1
  %t856 = load ptr, ptr %t855, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t852, ptr %t856)
  br label %bb211
bb211:
  %t860 = load ptr, ptr %l0, !tbaa !29
  %t861 = load ptr, ptr %l61, !tbaa !29
  %t863 = getelementptr %"compiler/ast:Compr", ptr %t861, i32 0, i32 5
  %t864 = load ptr, ptr %t863, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t860, ptr %t864)
  br label %bb212
bb212:
  %t867 = load ptr, ptr %l0, !tbaa !29
  %t868 = load i64, ptr %l62, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t867, i64 %t868)
  br label %bb213
bb213:
  br label %bb249
bb214:
  %t871 = load ptr, ptr %l1, !tbaa !29
  store ptr %t871, ptr %l449, !tbaa !29
  store i1 false, ptr %l450, !tbaa !21
  %t872 = load ptr, ptr %l449, !tbaa !29
  %t873 = icmp ne ptr %t872, null
  br i1 %t873, label %bb215, label %bb216
bb215:
  %t875 = load ptr, ptr %l449, !tbaa !29
  %t876 = load i64, ptr %t875, !range !{i64 0, i64 29}
  %t878 = icmp eq i64 %t876, 22
  store i1 %t878, ptr %l450, !tbaa !21
  br label %bb216
bb216:
  %t879 = load i1, ptr %l450, !tbaa !21
  br i1 %t879, label %bb217, label %bb218
bb217:
  %t880 = load ptr, ptr %l1, !tbaa !29
  %t882 = getelementptr { i64, [5 x i64] }, ptr %t880, i32 0, i32 1
  %t883 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t882, i32 0, i32 1
  %t884 = load ptr, ptr %t883
  store ptr %t884, ptr %l63, !tbaa !29
  %t886 = load ptr, ptr %l1, !tbaa !29
  %t888 = getelementptr { i64, [5 x i64] }, ptr %t886, i32 0, i32 1
  %t889 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t888, i32 0, i32 2
  %t890 = load { i64, ptr }, ptr %t889
  store { i64, ptr } %t890, ptr %l64, !tbaa !27
  br label %bb219
bb218:
  br label %bb222
bb219:
  %t892 = load ptr, ptr %l0, !tbaa !29
  %t893 = load ptr, ptr %l63, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t892, ptr %t893)
  br label %bb220
bb220:
  %t897 = load ptr, ptr %l0, !tbaa !29
  %t898 = load { i64, ptr }, ptr %l64, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t897, { i64, ptr } %t898)
  br label %bb221
bb221:
  br label %bb249
bb222:
  %t901 = load ptr, ptr %l1, !tbaa !29
  store ptr %t901, ptr %l462, !tbaa !29
  store i1 false, ptr %l463, !tbaa !21
  %t902 = load ptr, ptr %l462, !tbaa !29
  %t903 = icmp ne ptr %t902, null
  br i1 %t903, label %bb223, label %bb224
bb223:
  %t905 = load ptr, ptr %l462, !tbaa !29
  %t906 = load i64, ptr %t905, !range !{i64 0, i64 29}
  %t908 = icmp eq i64 %t906, 23
  store i1 %t908, ptr %l463, !tbaa !21
  br label %bb224
bb224:
  %t909 = load i1, ptr %l463, !tbaa !21
  br i1 %t909, label %bb225, label %bb226
bb225:
  %t910 = load ptr, ptr %l1, !tbaa !29
  %t912 = getelementptr { i64, [5 x i64] }, ptr %t910, i32 0, i32 1
  %t913 = getelementptr { %"compiler/source:Span", ptr }, ptr %t912, i32 0, i32 1
  %t914 = load ptr, ptr %t913
  store ptr %t914, ptr %l65, !tbaa !29
  br label %bb227
bb226:
  br label %bb237
bb227:
  %t916 = load ptr, ptr %l0, !tbaa !29
  %t918 = getelementptr %"compiler/names:Resolver", ptr %t916, i32 0, i32 12
  %t919 = load i1, ptr %t918, !tbaa !21
  store i1 %t919, ptr %l66, !tbaa !21
  %t921 = load ptr, ptr %l0, !tbaa !29
  %t923 = getelementptr %"compiler/names:Resolver", ptr %t921, i32 0, i32 12
  store i1 false, ptr %t923, !tbaa !21
  %t924 = load ptr, ptr %l0, !tbaa !29
  %t926 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t924)
  store i64 %t926, ptr %l472
  br label %bb228
bb228:
  %t927 = load i64, ptr %l472, !tbaa !24
  store i64 %t927, ptr %l67, !tbaa !24
  %t928 = load ptr, ptr %l0, !tbaa !29
  %t930 = getelementptr %"compiler/names:Resolver", ptr %t928, i32 0, i32 13
  store i1 true, ptr %t930, !tbaa !21
  %t931 = load ptr, ptr %l0, !tbaa !29
  %t932 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t931, ptr %t932, i1 true)
  br label %bb229
bb229:
  %t935 = load ptr, ptr %l0, !tbaa !29
  %t937 = getelementptr %"compiler/names:Resolver", ptr %t935, i32 0, i32 13
  store i1 false, ptr %t937, !tbaa !21
  %t938 = load ptr, ptr %l0, !tbaa !29
  %t939 = load ptr, ptr %l65, !tbaa !29
  %t941 = getelementptr %"compiler/ast:Func", ptr %t939, i32 0, i32 3
  %t942 = load ptr, ptr %t941, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epushSig(ptr %v0, ptr %v1, ptr %t938, ptr %t942)
  br label %bb230
bb230:
  %t945 = load ptr, ptr %l65, !tbaa !29
  %t947 = getelementptr %"compiler/ast:Func", ptr %t945, i32 0, i32 4
  %t948 = load { i64, ptr }, ptr %t947, !tbaa !27
  %t950 = extractvalue { i64, ptr } %t948, 0
  %t952 = icmp sgt i64 %t950, 0
  br i1 %t952, label %bb231, label %bb232
bb231:
  %t954 = load ptr, ptr %l0, !tbaa !29
  %t955 = load ptr, ptr %l65, !tbaa !29
  %t957 = getelementptr %"compiler/ast:Func", ptr %t955, i32 0, i32 4
  %t958 = load { i64, ptr }, ptr %t957, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t954, { i64, ptr } %t958)
  br label %bb233
bb232:
  br label %bb234
bb233:
  br label %bb234
bb234:
  %t961 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopSig(ptr %v0, ptr %t961)
  br label %bb235
bb235:
  %t963 = load ptr, ptr %l0, !tbaa !29
  %t964 = load i64, ptr %l67, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t963, i64 %t964)
  br label %bb236
bb236:
  %t967 = load ptr, ptr %l0, !tbaa !29
  %t968 = load i1, ptr %l66, !tbaa !21
  %t971 = getelementptr %"compiler/names:Resolver", ptr %t967, i32 0, i32 12
  store i1 %t968, ptr %t971, !tbaa !21
  br label %bb249
bb237:
  %t972 = load ptr, ptr %l1, !tbaa !29
  store ptr %t972, ptr %l492, !tbaa !29
  store i1 false, ptr %l493, !tbaa !21
  %t973 = load ptr, ptr %l492, !tbaa !29
  %t974 = icmp ne ptr %t973, null
  br i1 %t974, label %bb238, label %bb239
bb238:
  %t976 = load ptr, ptr %l492, !tbaa !29
  %t977 = load i64, ptr %t976, !range !{i64 0, i64 29}
  %t979 = icmp eq i64 %t977, 24
  store i1 %t979, ptr %l493, !tbaa !21
  br label %bb239
bb239:
  %t980 = load i1, ptr %l493, !tbaa !21
  br i1 %t980, label %bb240, label %bb241
bb240:
  %t981 = load ptr, ptr %l1, !tbaa !29
  %t983 = getelementptr { i64, [5 x i64] }, ptr %t981, i32 0, i32 1
  %t984 = getelementptr { %"compiler/source:Span", ptr }, ptr %t983, i32 0, i32 1
  %t985 = load ptr, ptr %t984
  store ptr %t985, ptr %l68, !tbaa !29
  br label %bb242
bb241:
  br label %bb244
bb242:
  %t987 = load ptr, ptr %l0, !tbaa !29
  %t988 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ematchOf(ptr %v0, ptr %v1, ptr %t987, ptr %t988)
  br label %bb243
bb243:
  br label %bb249
bb244:
  br i1 true, label %bb245, label %bb246
bb245:
  br label %bb247
bb246:
  br label %bb248
bb247:
  br label %bb249
bb248:
  call void @__olang_check_failed(ptr @olang_loc_eb7a002d6449973_70bfc0171de666c7)
  unreachable
bb249:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efirstRaises(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/names:raised"
  %l9 = alloca i64
  %l10 = alloca %"compiler/names:raisedName"
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l42 = alloca %"compiler/names:raised"
  %l45 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i1
  %l53 = alloca i64
  %l54 = alloca %"compiler/names:raisedName"
  %l57 = alloca %"compiler/names:raisedName"
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i32
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca i64
  %l65 = alloca i1
  %l68 = alloca %"compiler/names:raisedName"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store i64 0, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/names:Resolver", ptr %t5, i32 0, i32 23
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eLen_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load i64, ptr %l14, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l21, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l21, !tbaa !24
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l18, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/names:Resolver", ptr %t57, i32 0, i32 23
  %t63 = call %"compiler/names:raised" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eAt_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %t59, i64 %t55)
  store %"compiler/names:raised" %t63, ptr %l42
  br label %bb13
bb13:
  %t64 = load %"compiler/names:raised", ptr %l42
  store %"compiler/names:raised" %t64, ptr %l8
  %t65 = load ptr, ptr %lp1
  %t66 = getelementptr %"compiler/names:raised", ptr %l8, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t70 = call i64 @compiler_2fnames_2eindexOfRaised(ptr %v1, ptr %t65, i32 %t67)
  store i64 %t70, ptr %l45
  br label %bb14
bb14:
  %t71 = load i64, ptr %l45, !tbaa !24
  store i64 %t71, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = icmp slt i64 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t76 = load ptr, ptr %lp1
  store ptr %t76, ptr %l48, !tbaa !29
  %t77 = getelementptr %"compiler/names:raised", ptr %l8, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  store i32 %t78, ptr %l49, !tbaa !23
  %t79 = getelementptr %"compiler/names:raised", ptr %l8, i32 0, i32 1
  %t80 = load %"compiler/source:Span", ptr %t79
  store %"compiler/source:Span" %t80, ptr %l50
  %t81 = getelementptr %"compiler/names:raised", ptr %l8, i32 0, i32 2
  %t82 = load i1, ptr %t81, !tbaa !21
  store i1 %t82, ptr %l51, !tbaa !21
  %t83 = load ptr, ptr %lp1
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eLen_H9e36587759e47da85a29e6c0abff1d1c(ptr %v1, ptr %t83)
  store i64 %t85, ptr %l53
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t86 = load i32, ptr %l49, !tbaa !23
  %t87 = load %"compiler/source:Span", ptr %l50
  %t88 = load i1, ptr %l51, !tbaa !21
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = call %"compiler/names:raisedName" @compiler_2fnames_3araisedName_2ector(ptr %s3, i32 %t86, %"compiler/source:Span" %t87, i64 1, i1 %t88, i64 %t89)
  store %"compiler/names:raisedName" %t90, ptr %l54
  br label %bb18
bb18:
  %t91 = load ptr, ptr %l48, !tbaa !29
  %t92 = load %"compiler/names:raisedName", ptr %l54
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2ePus_Hd55e6ab57c5af931645f87a55858e9a4(ptr %v1, ptr %t91, %"compiler/names:raisedName" %t92)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb20:
  %t93 = load ptr, ptr %lp1
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = call %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %v1, ptr %t93, i64 %t94)
  store %"compiler/names:raisedName" %t97, ptr %l57
  br label %bb21
bb21:
  %t98 = load %"compiler/names:raisedName", ptr %l57
  store %"compiler/names:raisedName" %t98, ptr %l10
  %t99 = load ptr, ptr %lp1
  store ptr %t99, ptr %l58, !tbaa !29
  %t100 = load i64, ptr %l9, !tbaa !24
  store i64 %t100, ptr %l59, !tbaa !24
  %t101 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  store i32 %t102, ptr %l60, !tbaa !23
  %t103 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 1
  %t104 = load %"compiler/source:Span", ptr %t103
  store %"compiler/source:Span" %t104, ptr %l61
  %t105 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 2
  %t106 = load i64, ptr %t105, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l63, !tbaa !24
  %t109 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 3
  %t110 = load i1, ptr %t109, !tbaa !21
  br i1 %t110, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb24
bb23:
  %t112 = getelementptr %"compiler/names:raised", ptr %l8, i32 0, i32 2
  %t113 = load i1, ptr %t112, !tbaa !21
  store i1 %t113, ptr %l65, !tbaa !21
  br label %bb24
bb24:
  %t115 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 4
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load i32, ptr %l60, !tbaa !23
  %t118 = load %"compiler/source:Span", ptr %l61
  %t119 = load i64, ptr %l63, !tbaa !24
  %t120 = load i1, ptr %l65, !tbaa !21
  %t122 = call %"compiler/names:raisedName" @compiler_2fnames_3araisedName_2ector(ptr %s2, i32 %t117, %"compiler/source:Span" %t118, i64 %t119, i1 %t120, i64 %t116)
  store %"compiler/names:raisedName" %t122, ptr %l68
  br label %bb25
bb25:
  %t123 = load ptr, ptr %l58, !tbaa !29
  %t124 = load i64, ptr %l59, !tbaa !24
  %t125 = load %"compiler/names:raisedName", ptr %l68
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eSet_H6810983465e8cb9e88422e8fd071646d(ptr %v1, ptr %t123, i64 %t124, %"compiler/names:raisedName" %t125)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t126 = load i64, ptr %l6, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l6, !tbaa !24
  br label %bb9
bb28:
  %t130 = load ptr, ptr %lp1
  %t131 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t130
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforName(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l27 = alloca i1
  %l31 = alloca %"compiler/names:local"
  %l34 = alloca i1
  %l40 = alloca ptr
  %l44 = alloca i1
  %l47 = alloca ptr
  %l52 = alloca { i64, [3 x i64] }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/msgs:Msg"
  %l61 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t5, i32 %t6)
  store { i64, ptr } %t9, ptr %l11
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t11, ptr %l12
  br label %bb4
bb4:
  %t12 = load i1, ptr %l12, !tbaa !21
  store i1 %t12, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/names:Resolver", ptr %t15, i32 0, i32 6
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = load i32, ptr %l2, !tbaa !23
  %t25 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t14, i64 %t18, i32 %a1, i32 %t20)
  store %"compiler/source:Span" %t25, ptr %l18
  br label %bb9
bb9:
  %t26 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t26, ptr %l3
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 8
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t29, i32 %t30)
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l24
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb11, label %ok.37, !prof !99
ok.37:
  store i64 %t34, ptr %l23
  br label %bb10
bb10:
  %t38 = load i64, ptr %l23, !tbaa !24
  store i64 %t38, ptr %l19, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l19, !tbaa !24
  br label %bb13
bb13:
  %t39 = load i64, ptr %l19, !tbaa !24
  store i64 %t39, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = icmp sge i64 %t40, 0
  br i1 %t42, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/names:Resolver", ptr %t44, i32 0, i32 7
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t46, i64 %t47)
  store %"compiler/names:local" %t50, ptr %l31
  br label %bb16
bb15:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb17
bb16:
  %t51 = getelementptr %"compiler/names:local", ptr %l31, i32 0, i32 2
  %t52 = load i32, ptr %t51, !range !{i32 0, i32 9}
  %t54 = trunc i64 1 to i32
  %t55 = icmp eq i32 %t52, %t54
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l27, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb22
bb19:
  %t58 = load i32, ptr %l2, !tbaa !23
  store i32 %t58, ptr %l5, !tbaa !23
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/names:Resolver", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/names:Resolver", ptr %t63, i32 0, i32 6
  %t66 = load i64, ptr %t65, !tbaa !24
  %t69 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t62, i64 %t66)
  store ptr %t69, ptr %l40
  br label %bb20
bb20:
  %t70 = load ptr, ptr %l40, !tbaa !29
  %t72 = getelementptr %"compiler/names:Table", ptr %t70, i32 0, i32 1
  %t73 = load i32, ptr %l5, !tbaa !23
  %t76 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t76, ptr %l44
  br label %bb21
bb21:
  %t77 = load i1, ptr %l44, !tbaa !21
  store i1 %t77, ptr %l34, !tbaa !21
  br label %bb22
bb22:
  %t78 = load i1, ptr %l34, !tbaa !21
  br i1 %t78, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/names:Resolver", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 4
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l47, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/names:Resolver", ptr %t87, i32 0, i32 6
  %t90 = load i64, ptr %t89, !tbaa !24
  %t91 = load %"compiler/source:Span", ptr %l3
  %t95 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t86, i64 %t90, %"compiler/source:Span" %t91)
  store { i64, [3 x i64] } %t95, ptr %l52
  br label %bb25
bb24:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l2, !tbaa !23
  %t98 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %t96, i32 %t97, %"compiler/source:Span" %t98, i1 true)
  br label %bb31
bb25:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l2, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t102, i32 %t103)
  store { i64, ptr } %t106, ptr %l55
  br label %bb26
bb26:
  %t107 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  %t109 = extractvalue { i64, ptr } %t107, 1
  %t110 = mul i64 %t108, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t111, ptr %t109, i64 %t110, i1 false)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l56, !tbaa !27
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l2, !tbaa !23
  %t118 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t114, i32 %t115)
  store { i64, ptr } %t118, ptr %l59
  br label %bb27
bb27:
  %t119 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t121 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInNameExists(ptr %s2, ptr %v0, ptr %s2, { i64, ptr } %t119, { i64, ptr } %t120)
  store %"compiler/msgs:Msg" %t121, ptr %l60
  br label %bb28
bb28:
  %t122 = load ptr, ptr %l47, !tbaa !29
  %t123 = load { i64, [3 x i64] }, ptr %l52
  %t124 = load %"compiler/msgs:Msg", ptr %l60
  %t125 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t122, { i64, [3 x i64] } %t123, %"compiler/msgs:Msg" %t124)
  store i64 %t125, ptr %l61
  br label %bb29
bb29:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l2, !tbaa !23
  %t128 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t126, i32 %t127, %"compiler/source:Span" %t128, i32 1)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforNames(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforName(ptr %v0, ptr %t1, i32 %t2, i32 %a2)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforName(ptr %v0, ptr %t7, i32 %t8, i32 %a3)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i64, ptr %l4, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t5, ptr %t6, i1 true)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Func", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2econtract(ptr %v0, ptr %v1, ptr %t9, ptr %t13)
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Func", ptr %t17, i32 0, i32 3
  %t20 = load ptr, ptr %t19, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epushSig(ptr %v0, ptr %v1, ptr %t16, ptr %t20)
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Func", ptr %t23, i32 0, i32 4
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Func", ptr %t33, i32 0, i32 4
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t32, { i64, ptr } %t36)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopSig(ptr %v0, ptr %t39)
  br label %bb9
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t41, i64 %t42)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/cond:Decision"
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l16 = alloca ptr
  %l27 = alloca ptr
  %l33 = alloca %"compiler/cond:Decision"
  %l39 = alloca ptr
  %l45 = alloca ptr
  %l47 = alloca i64
  %l53 = alloca %"compiler/source:Span"
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l62 = alloca ptr
  %l71 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca i1
  %l91 = alloca ptr
  %l101 = alloca ptr
  %l108 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 22
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyIf(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %ret
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:If", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:If", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb7, label %bb8
bb6:
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_886f7d48bba75e1e_e325b650ab06e3ea)
  unreachable
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:If", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %t29, ptr %t28)
  br label %bb10
bb10:
  br label %ret
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/names:Resolver", ptr %t31, i32 0, i32 12
  store i1 true, ptr %t33, !tbaa !21
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/ast:If", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t34, ptr %t38)
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/names:Resolver", ptr %t41, i32 0, i32 12
  store i1 false, ptr %t43, !tbaa !21
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:If", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  br i1 %t50, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_dbd61287de33a2c5_4d29ffa31fdf1ff1)
  unreachable
bb14:
  br label %bb15
bb15:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/ast:If", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load ptr, ptr %l27, !tbaa !29
  %t58 = call %"compiler/cond:Decision" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edecideLocal(ptr %v0, ptr %v1, ptr %t56, ptr %t55)
  store %"compiler/cond:Decision" %t58, ptr %l33
  br label %bb16
bb16:
  %t59 = load %"compiler/cond:Decision", ptr %l33
  store %"compiler/cond:Decision" %t59, ptr %l2
  %t60 = getelementptr %"compiler/cond:Decision", ptr %l2, i32 0, i32 0
  %t61 = load i32, ptr %t60, !range !{i32 0, i32 5}
  store i32 %t61, ptr %l3
  %t63 = getelementptr %"compiler/cond:Decision", ptr %l2, i32 0, i32 1
  %t64 = load i1, ptr %t63, !tbaa !21
  store i1 %t64, ptr %l4, !tbaa !21
  %t66 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t68 = trunc i64 4 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/names:Resolver", ptr %t71, i32 0, i32 16
  store ptr %t73, ptr %l39, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/names:Resolver", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/load:Loader", ptr %t77, i32 0, i32 5
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/names:Resolver", ptr %t80, i32 0, i32 6
  %t83 = load i64, ptr %t82, !tbaa !24
  %t86 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t79, i64 %t83)
  store ptr %t86, ptr %l45
  br label %bb19
bb18:
  br label %bb26
bb19:
  %t87 = load ptr, ptr %l45, !tbaa !29
  %t89 = getelementptr %"compiler/load:Module", ptr %t87, i32 0, i32 4
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t90, ptr %l47, !tbaa !24
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/ast:If", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_bee2df1b257c0b70_a796ae201fef93fc)
  unreachable
bb21:
  br label %bb22
bb22:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/ast:If", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t101)
  store %"compiler/source:Span" %t103, ptr %l53
  br label %bb23
bb23:
  %t104 = getelementptr %"compiler/source:Span", ptr %l53, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = sext i32 %t105 to i64
  %t108 = load i64, ptr %l47, !tbaa !24
  %t110 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t108, i64 %t107)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t110, ptr %l56
  br label %bb24
bb24:
  %t111 = load ptr, ptr %l39, !tbaa !29
  %t112 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t111, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t112, i1 true)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t113 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t115 = trunc i64 0 to i32
  %t116 = icmp eq i32 %t113, %t115
  store i1 %t116, ptr %l5, !tbaa !21
  %t118 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t120 = trunc i64 1 to i32
  %t121 = icmp eq i32 %t118, %t120
  %t123 = xor i1 %t121, true
  store i1 %t123, ptr %l6, !tbaa !21
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l62, !tbaa !29
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/ast:If", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  br i1 %t131, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_f74f5c810fb1384f_2035d8e6259ec36b)
  unreachable
bb28:
  br label %bb29
bb29:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr %"compiler/ast:If", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load i1, ptr %l5, !tbaa !21
  %t138 = load i1, ptr %l4, !tbaa !21
  %t139 = load i1, ptr %l6, !tbaa !21
  %t140 = load ptr, ptr %l62, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2echoose(ptr %v0, ptr %v1, ptr %t140, ptr %t136, i1 %t137, i1 %t138, i1 %t139)
  br label %bb30
bb30:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l71, !tbaa !29
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr %"compiler/ast:If", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  br i1 %t151, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_9a3445d364d03a02_c72e8fada9365de6)
  unreachable
bb32:
  br label %bb33
bb33:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/ast:If", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t157 = load ptr, ptr %l71, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %t157, ptr %t156)
  br label %bb34
bb34:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/ast:If", ptr %t159, i32 0, i32 2
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb35, label %bb36
bb35:
  br label %ret
bb36:
  br label %bb37
bb37:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr %"compiler/ast:If", ptr %t166, i32 0, i32 2
  %t169 = load ptr, ptr %t168, !tbaa !29
  store ptr %t169, ptr %l7, !tbaa !29
  %t171 = load ptr, ptr %l7, !tbaa !29
  store ptr %t171, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t172 = load ptr, ptr %l82, !tbaa !29
  %t173 = icmp ne ptr %t172, null
  br i1 %t173, label %bb38, label %bb39
bb38:
  %t175 = load ptr, ptr %l82, !tbaa !29
  %t176 = load i64, ptr %t175, !range !{i64 0, i64 22}
  %t178 = icmp eq i64 %t176, 5
  store i1 %t178, ptr %l83, !tbaa !21
  br label %bb39
bb39:
  %t179 = load i1, ptr %l83, !tbaa !21
  br i1 %t179, label %bb40, label %bb41
bb40:
  %t180 = load ptr, ptr %l7, !tbaa !29
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", ptr }, ptr %t182, i32 0, i32 1
  %t184 = load ptr, ptr %t183
  store ptr %t184, ptr %l8, !tbaa !29
  br label %bb42
bb41:
  br label %bb62
bb42:
  %t186 = load ptr, ptr %l8, !tbaa !29
  %t188 = getelementptr %"compiler/ast:If", ptr %t186, i32 0, i32 0
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = icmp eq ptr %t189, null
  br i1 %t191, label %bb43, label %bb44
bb43:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l91, !tbaa !29
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr %"compiler/ast:If", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = icmp eq ptr %t197, null
  br i1 %t199, label %bb45, label %bb46
bb44:
  %t201 = load i1, ptr %l5, !tbaa !21
  br i1 %t201, label %bb53, label %bb54
bb45:
  call void @__olang_check_failed(ptr @olang_loc_f2359f321711c0e9_83213f8b98ca37cd)
  unreachable
bb46:
  br label %bb47
bb47:
  %t203 = load ptr, ptr %l8, !tbaa !29
  %t205 = getelementptr %"compiler/ast:If", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t207 = load i1, ptr %l5, !tbaa !21
  %t208 = load i1, ptr %l4, !tbaa !21
  %t210 = xor i1 %t208, true
  %t211 = load i1, ptr %l6, !tbaa !21
  %t212 = load ptr, ptr %l91, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2echoose(ptr %v0, ptr %v1, ptr %t212, ptr %t206, i1 %t207, i1 %t210, i1 %t211)
  br label %bb48
bb48:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l101, !tbaa !29
  %t218 = load ptr, ptr %l8, !tbaa !29
  %t220 = getelementptr %"compiler/ast:If", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = icmp eq ptr %t221, null
  br i1 %t223, label %bb49, label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_530cce065f124df4_4e8587782c204bb8)
  unreachable
bb50:
  br label %bb51
bb51:
  %t225 = load ptr, ptr %l8, !tbaa !29
  %t227 = getelementptr %"compiler/ast:If", ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t229 = load ptr, ptr %l101, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %t229, ptr %t228)
  br label %bb52
bb52:
  br label %bb61
bb53:
  %t231 = load i1, ptr %l4, !tbaa !21
  store i1 %t231, ptr %l108, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb55
bb55:
  %t233 = load i1, ptr %l108, !tbaa !21
  br i1 %t233, label %bb56, label %bb57
bb56:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edropAll(ptr %v0, ptr %v1, ptr %t234, ptr %t235)
  br label %bb58
bb57:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eifStmt(ptr %v0, ptr %v1, ptr %t238, ptr %t239)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  br label %bb68
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t245 = getelementptr %"compiler/ast:If", ptr %t243, i32 0, i32 2
  %t246 = load ptr, ptr %t245, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t242, ptr %t246)
  br label %bb66
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_13e109869e44451a_84e972cbfcb81dee)
  unreachable
bb68:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eimportedType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/load:Import"
  %l5 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca %"compiler/load:Import"
  %l24 = alloca i1
  %l29 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca i1
  %l46 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 6
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l11
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t16 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 11
  store ptr %t16, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l14, !tbaa !24
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l16
  br label %bb3
bb3:
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %bb26
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/load:Import" %t32, ptr %l21
  br label %bb7
bb7:
  %t33 = load %"compiler/load:Import", ptr %l21
  store %"compiler/load:Import" %t33, ptr %l4
  %t34 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 5
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load i32, ptr %l1, !tbaa !23
  store i32 %t39, ptr %l5, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/names:Resolver", ptr %t41, i32 0, i32 1
  %t44 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 5
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t43, i64 %t45)
  store ptr %t48, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb12
bb10:
  %t49 = load ptr, ptr %l29, !tbaa !29
  %t51 = getelementptr %"compiler/names:Table", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l5, !tbaa !23
  %t55 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l33
  br label %bb11
bb11:
  %t56 = load i1, ptr %l33, !tbaa !21
  store i1 %t56, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l24, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t58, i32 %t59)
  store { i64, ptr } %t62, ptr %l37
  br label %bb15
bb14:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb21
bb15:
  %t63 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t63, ptr %l38, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i8, ptr %t65, i64 0
  %t67 = load i8, ptr %t66, !tbaa !32
  %t69 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t67)
  store i1 %t69, ptr %l40
  br label %bb16
bb16:
  %t70 = load i1, ptr %l40, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb20
bb18:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/names:Resolver", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/load:Loader", ptr %t74, i32 0, i32 5
  %t77 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 5
  %t78 = load i64, ptr %t77, !tbaa !24
  %t81 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t76, i64 %t78)
  store ptr %t81, ptr %l46
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l46, !tbaa !29
  %t84 = getelementptr %"compiler/load:Module", ptr %t82, i32 0, i32 30
  %t85 = load i1, ptr %t84, !tbaa !21
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t87 = load i1, ptr %l41, !tbaa !21
  store i1 %t87, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t88 = load i1, ptr %l34, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  store i1 true, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l3, !tbaa !24
  br label %bb2
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eintroduce(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i1
  %l24 = alloca %"compiler/names:local"
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/names:Ref"
  %l39 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca i32
  %l48 = alloca i64
  %l51 = alloca i64
  %l53 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  %t5 = xor i1 %t3, true
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/names:Resolver", ptr %t12, i32 0, i32 8
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t14, i32 %t15)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l17
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb6, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l16
  br label %bb5
bb5:
  %t23 = load i64, ptr %l16, !tbaa !24
  store i64 %t23, ptr %l12, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t24 = load i64, ptr %l12, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sge i64 %t25, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/names:Resolver", ptr %t29, i32 0, i32 7
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t31, i64 %t32)
  store %"compiler/names:local" %t35, ptr %l24
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t36 = getelementptr %"compiler/names:local", ptr %l24, i32 0, i32 2
  %t37 = load i32, ptr %t36, !range !{i32 0, i32 9}
  %t39 = trunc i64 8 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l20, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l27, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t44, ptr %l28
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/names:Resolver", ptr %t45, i32 0, i32 6
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t53 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 8, i64 %t48, i64 %t49)
  store %"compiler/names:Ref" %t53, ptr %l33
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t54 = load ptr, ptr %l27, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l28
  %t56 = load %"compiler/names:Ref", ptr %l33
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t54, %"compiler/source:Span" %t55, %"compiler/names:Ref" %t56)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/names:Resolver", ptr %t58, i32 0, i32 6
  %t61 = load i64, ptr %t60, !tbaa !24
  %t62 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t63 = load i32, ptr %t62, !tbaa !23
  %t64 = load i32, ptr %l2, !tbaa !23
  %t69 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t57, i64 %t61, i32 %t63, i32 %t64)
  store %"compiler/source:Span" %t69, ptr %l39
  br label %bb18
bb18:
  %t70 = load %"compiler/source:Span", ptr %l39
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t71, i32 %t72, %"compiler/source:Span" %t70, i32 8)
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l44, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t79, ptr %l45
  store i32 8, ptr %l46
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/names:Resolver", ptr %t80, i32 0, i32 6
  %t83 = load i64, ptr %t82, !tbaa !24
  store i64 %t83, ptr %l48, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/names:Resolver", ptr %t84, i32 0, i32 7
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l51
  br label %bb20
bb20:
  %t89 = load i64, ptr %l51, !tbaa !24
  %t90 = sub i64 %t89, 1
  %t91 = load i32, ptr %l46, !range !{i32 0, i32 9}
  %t92 = load i64, ptr %l48, !tbaa !24
  %t94 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 %t91, i64 %t92, i64 %t90)
  store %"compiler/names:Ref" %t94, ptr %l53
  br label %bb21
bb21:
  %t95 = load ptr, ptr %l44, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l45
  %t97 = load %"compiler/names:Ref", ptr %l53
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t95, %"compiler/source:Span" %t96, %"compiler/names:Ref" %t97)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ejudge(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/names:local"
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"compiler/names:local"
  %l22 = alloca i1
  %l26 = alloca { i64, ptr }
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l52 = alloca i1
  %l56 = alloca ptr
  %l62 = alloca ptr
  %l68 = alloca %"compiler/names:Unread"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l11, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 7
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l14
  br label %bb3
bb3:
  %t11 = load i64, ptr %l11, !tbaa !24
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l10, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/names:Resolver", ptr %t16, i32 0, i32 7
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t18, i64 %t19)
  store %"compiler/names:local" %t22, ptr %l19
  br label %bb8
bb8:
  %t23 = load %"compiler/names:local", ptr %l19
  store %"compiler/names:local" %t23, ptr %l2
  %t24 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 3
  %t25 = load i1, ptr %t24, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t29 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 5
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 0
  %t35 = load i32, ptr %t34, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t33, i32 %t35)
  store { i64, ptr } %t38, ptr %l26
  br label %bb15
bb15:
  %t39 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t39, ptr %l3, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 17
  store ptr %t42, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  %t44 = load i64, ptr %l5, !tbaa !24
  store i64 %t44, ptr %l29, !tbaa !24
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t45)
  store i64 %t47, ptr %l31
  br label %bb17
bb17:
  %t48 = load i64, ptr %l29, !tbaa !24
  %t49 = load i64, ptr %l31, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb18, label %bb19
bb18:
  br label %bb31
bb19:
  br label %bb20
bb20:
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t54, i64 %t55)
  store %"compiler/source:Span" %t58, ptr %l36
  br label %bb21
bb21:
  %t59 = load %"compiler/source:Span", ptr %l36
  store %"compiler/source:Span" %t59, ptr %l6
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/names:Resolver", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/load:Loader", ptr %t63, i32 0, i32 5
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/names:Resolver", ptr %t66, i32 0, i32 6
  %t69 = load i64, ptr %t68, !tbaa !24
  %t72 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t65, i64 %t69)
  store ptr %t72, ptr %l42
  br label %bb22
bb22:
  %t73 = load ptr, ptr %l42, !tbaa !29
  %t75 = getelementptr %"compiler/load:Module", ptr %t73, i32 0, i32 6
  %t76 = load ptr, ptr %t75, !tbaa !29
  store ptr %t76, ptr %l7, !tbaa !29
  %t78 = load ptr, ptr %l7, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_29838351972cb384_2d79eff554670e58)
  unreachable
bb24:
  br label %bb25
bb25:
  %t82 = load ptr, ptr %l7, !tbaa !29
  %t85 = getelementptr %"compiler/source:Source", ptr %t82, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t87 = load %"compiler/source:Span", ptr %l6
  %t88 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t92 = call i1 @compiler_2fnames_2eMentions(ptr %v0, ptr %v0, { i64, ptr } %t86, %"compiler/source:Span" %t87, { i64, ptr } %t88)
  store i1 %t92, ptr %l52
  br label %bb26
bb26:
  %t93 = load i1, ptr %l52, !tbaa !21
  br i1 %t93, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l5, !tbaa !24
  br label %bb16
bb31:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/names:Resolver", ptr %t98, i32 0, i32 18
  store ptr %t100, ptr %l56, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/names:Resolver", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/load:Loader", ptr %t104, i32 0, i32 5
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/names:Resolver", ptr %t107, i32 0, i32 6
  %t110 = load i64, ptr %t109, !tbaa !24
  %t113 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t106, i64 %t110)
  store ptr %t113, ptr %l62
  br label %bb32
bb32:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t116 = getelementptr %"compiler/load:Module", ptr %t114, i32 0, i32 4
  %t117 = load i64, ptr %t116, !tbaa !24
  %t118 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 1
  %t119 = load %"compiler/source:Span", ptr %t118
  %t120 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 0
  %t121 = load i32, ptr %t120, !tbaa !23
  %t122 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 4
  %t123 = load i1, ptr %t122, !tbaa !21
  %t128 = call %"compiler/names:Unread" @compiler_2fnames_3aUnread_2ector(ptr %s0, i64 %t117, %"compiler/source:Span" %t119, i32 %t121, i1 %t123)
  store %"compiler/names:Unread" %t128, ptr %l68
  br label %bb33
bb33:
  %t129 = load ptr, ptr %l56, !tbaa !29
  %t130 = load %"compiler/names:Unread", ptr %l68
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2ePush_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t129, %"compiler/names:Unread" %t130)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/names:Ref"
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l21 = alloca %"compiler/names:local"
  %l26 = alloca %"compiler/names:Ref"
  %l31 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i32
  %l43 = alloca %"compiler/names:Entry"
  %l48 = alloca %"compiler/names:Ref"
  %l49 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l61 = alloca %"compiler/names:Ref"
  %l62 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i32
  %l74 = alloca ptr
  %l79 = alloca i64
  %l82 = alloca %"compiler/names:Ref"
  %l85 = alloca { i64, ptr }
  %l90 = alloca i1
  %l92 = alloca %"compiler/names:Ref"
  %l93 = alloca %"compiler/names:Ref"
  %l97 = alloca %"compiler/names:Ref"
  %l98 = alloca i32
  %l100 = alloca %"compiler/names:Ref"
  %l105 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i32
  %l113 = alloca i32
  %l114 = alloca i64
  %l115 = alloca i64
  %l119 = alloca ptr
  %l123 = alloca i64
  %l124 = alloca i32
  %l125 = alloca %"compiler/names:Ref"
  %l127 = alloca i1
  %l129 = alloca %"compiler/names:Ref"
  %l131 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 8
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l15
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l14
  br label %bb1
bb1:
  %t12 = load i64, ptr %l14, !tbaa !24
  store i64 %t12, ptr %l10, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l10, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 7
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t20, i64 %t21)
  store %"compiler/names:local" %t24, ptr %l21
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t25 = getelementptr %"compiler/names:local", ptr %l21, i32 0, i32 2
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 9}
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 6
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t35 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s1, i32 %t26, i64 %t30, i64 %t31)
  store %"compiler/names:Ref" %t35, ptr %l26
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t36 = load %"compiler/names:Ref", ptr %l26
  store %"compiler/names:Ref" %t36, ptr %rv
  br label %ret
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 6
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t39, i64 %t43)
  store ptr %t46, ptr %l31
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l31, !tbaa !29
  store ptr %t47, ptr %l3, !tbaa !29
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t50 = getelementptr %"compiler/names:Table", ptr %t48, i32 0, i32 1
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t50, i32 %t51)
  %t55 = extractvalue { i32, i64 } %t54, 1
  %t56 = extractvalue { i32, i64 } %t54, 0
  store i32 %t56, ptr %l37
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb12, label %ok.58, !prof !99
ok.58:
  store i64 %t55, ptr %l36
  br label %bb11
bb11:
  %t59 = load i64, ptr %l36, !tbaa !24
  store i64 %t59, ptr %l32, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l32, !tbaa !24
  br label %bb14
bb14:
  %t60 = load i64, ptr %l32, !tbaa !24
  store i64 %t60, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = icmp sge i64 %t61, 0
  br i1 %t63, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr %"compiler/names:Table", ptr %t65, i32 0, i32 0
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s2, ptr %t67, i64 %t68)
  store %"compiler/names:Entry" %t71, ptr %l43
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t72 = getelementptr %"compiler/names:Entry", ptr %l43, i32 0, i32 2
  %t73 = load i32, ptr %t72, !range !{i32 0, i32 9}
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/names:Resolver", ptr %t74, i32 0, i32 6
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = load i64, ptr %l4, !tbaa !24
  %t82 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 %t73, i64 %t77, i64 %t78)
  store %"compiler/names:Ref" %t82, ptr %l48
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t83 = load %"compiler/names:Ref", ptr %l48
  store %"compiler/names:Ref" %t83, ptr %rv
  br label %ret
bb19:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/names:Table", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l1, !tbaa !23
  %t90 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t86, i32 %t87)
  %t91 = extractvalue { i32, i64 } %t90, 1
  %t92 = extractvalue { i32, i64 } %t90, 0
  store i32 %t92, ptr %l54
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb21, label %ok.94, !prof !99
ok.94:
  store i64 %t91, ptr %l53
  br label %bb20
bb20:
  %t95 = load i64, ptr %l53, !tbaa !24
  store i64 %t95, ptr %l49, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb23
bb23:
  %t96 = load i64, ptr %l49, !tbaa !24
  store i64 %t96, ptr %l5, !tbaa !24
  %t97 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp sge i64 %t97, 0
  br i1 %t99, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/names:Resolver", ptr %t101, i32 0, i32 6
  %t104 = load i64, ptr %t103, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t109 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s3, i32 4, i64 %t104, i64 %t105)
  store %"compiler/names:Ref" %t109, ptr %l61
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t110 = load %"compiler/names:Ref", ptr %l61
  store %"compiler/names:Ref" %t110, ptr %rv
  br label %ret
bb27:
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/names:Table", ptr %t111, i32 0, i32 3
  %t114 = load i32, ptr %l1, !tbaa !23
  %t117 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t113, i32 %t114)
  %t118 = extractvalue { i32, i64 } %t117, 1
  %t119 = extractvalue { i32, i64 } %t117, 0
  store i32 %t119, ptr %l67
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb29, label %ok.121, !prof !99
ok.121:
  store i64 %t118, ptr %l66
  br label %bb28
bb28:
  %t122 = load i64, ptr %l66, !tbaa !24
  store i64 %t122, ptr %l62, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l62, !tbaa !24
  br label %bb31
bb31:
  %t123 = load i64, ptr %l62, !tbaa !24
  store i64 %t123, ptr %l6, !tbaa !24
  %t124 = load i64, ptr %l6, !tbaa !24
  %t126 = icmp sge i64 %t124, 0
  br i1 %t126, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s4
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/names:Resolver", ptr %t128, i32 0, i32 22
  %t131 = load i1, ptr %t130, !tbaa !21
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb34, label %bb35
bb33:
  br label %bb40
bb34:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/names:Resolver", ptr %t135, i32 0, i32 19
  store ptr %t137, ptr %l74, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/names:Resolver", ptr %t138, i32 0, i32 6
  %t141 = load i64, ptr %t140, !tbaa !24
  %t142 = load i32, ptr %l1, !tbaa !23
  %t146 = call i64 @compiler_2fnames_2ekey(i64 %t141, i32 %t142)
  store i64 %t146, ptr %l79
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t147 = load ptr, ptr %l74, !tbaa !29
  %t148 = load i64, ptr %l79, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t147, i64 %t148, i1 true)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t149 = load i64, ptr %l6, !tbaa !24
  %t152 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s4, i32 5, i64 %t149, i64 -1)
  store %"compiler/names:Ref" %t152, ptr %l82
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t153 = load %"compiler/names:Ref", ptr %l82
  store %"compiler/names:Ref" %t153, ptr %rv
  br label %ret
bb40:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i32, ptr %l1, !tbaa !23
  %t158 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t154, i32 %t155)
  store { i64, ptr } %t158, ptr %l85
  br label %bb41
bb41:
  %t159 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t159, ptr %l7, !tbaa !27
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/names:Resolver", ptr %t160, i32 0, i32 0
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/load:Loader", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t170 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v0, ptr %t166, { i64, ptr } %t167)
  store i1 %t170, ptr %l90
  br label %bb42
bb42:
  %t171 = load i1, ptr %l90, !tbaa !21
  br i1 %t171, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t173 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s6, i32 6, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t173, ptr %l92
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t174 = load %"compiler/names:Ref", ptr %l92
  store %"compiler/names:Ref" %t174, ptr %rv
  br label %ret
bb46:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/names:Resolver", ptr %t175, i32 0, i32 3
  %t178 = load i32, ptr %l1, !tbaa !23
  %t181 = call { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H678d1b43e8b98a171ffdea8f28643d28(ptr %v0, ptr %t177, i32 %t178)
  %t182 = extractvalue { i32, %"compiler/names:Ref" } %t181, 1
  %t183 = extractvalue { i32, %"compiler/names:Ref" } %t181, 0
  store i32 %t183, ptr %l98
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb48, label %ok.185, !prof !99
ok.185:
  store %"compiler/names:Ref" %t182, ptr %l97
  br label %bb47
bb47:
  %t186 = load %"compiler/names:Ref", ptr %l97
  store %"compiler/names:Ref" %t186, ptr %l93
  br label %bb51
bb48:
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  %t188 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t188, ptr %l100
  br label %bb50
bb50:
  %t189 = load %"compiler/names:Ref", ptr %l100
  store %"compiler/names:Ref" %t189, ptr %l93
  br label %bb51
bb51:
  %t190 = load %"compiler/names:Ref", ptr %l93
  store %"compiler/names:Ref" %t190, ptr %l8
  %t191 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t192 = load i32, ptr %t191, !range !{i32 0, i32 9}
  %t194 = trunc i64 0 to i32
  %t195 = icmp eq i32 %t192, %t194
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb52, label %bb53
bb52:
  %t199 = load %"compiler/names:Ref", ptr %l8
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/names:Ref" %t199, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/names:Resolver", ptr %t201, i32 0, i32 2
  %t204 = load i32, ptr %l1, !tbaa !23
  %t207 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t203, i32 %t204)
  %t208 = extractvalue { i32, i64 } %t207, 1
  %t209 = extractvalue { i32, i64 } %t207, 0
  store i32 %t209, ptr %l110
  %t210 = icmp ne i32 %t209, 0
  br i1 %t210, label %bb56, label %ok.211, !prof !99
ok.211:
  store i64 %t208, ptr %l109
  br label %bb55
bb55:
  %t212 = load i64, ptr %l109, !tbaa !24
  store i64 %t212, ptr %l105, !tbaa !24
  br label %bb58
bb56:
  br label %bb57
bb57:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l105, !tbaa !24
  br label %bb58
bb58:
  %t213 = load i64, ptr %l105, !tbaa !24
  store i64 %t213, ptr %l9, !tbaa !24
  %t214 = load i64, ptr %l9, !tbaa !24
  %t216 = icmp sge i64 %t214, 0
  br i1 %t216, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 4, ptr %l113
  %t218 = load i64, ptr %l9, !tbaa !24
  store i64 %t218, ptr %l114, !tbaa !24
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/names:Resolver", ptr %t219, i32 0, i32 1
  %t222 = load i64, ptr %l9, !tbaa !24
  %t225 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t221, i64 %t222)
  store ptr %t225, ptr %l119
  br label %bb61
bb60:
  br label %bb67
bb61:
  %t226 = load ptr, ptr %l119, !tbaa !29
  %t228 = getelementptr %"compiler/names:Table", ptr %t226, i32 0, i32 2
  %t229 = load i32, ptr %l1, !tbaa !23
  %t232 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t228, i32 %t229)
  %t233 = extractvalue { i32, i64 } %t232, 1
  %t234 = extractvalue { i32, i64 } %t232, 0
  store i32 %t234, ptr %l124
  %t235 = icmp ne i32 %t234, 0
  br i1 %t235, label %bb63, label %ok.236, !prof !99
ok.236:
  store i64 %t233, ptr %l123
  br label %bb62
bb62:
  %t237 = load i64, ptr %l123, !tbaa !24
  store i64 %t237, ptr %l115, !tbaa !24
  br label %bb65
bb63:
  br label %bb64
bb64:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l115, !tbaa !24
  br label %bb65
bb65:
  %t238 = load i32, ptr %l113, !range !{i32 0, i32 9}
  %t239 = load i64, ptr %l114, !tbaa !24
  %t240 = load i64, ptr %l115, !tbaa !24
  %t241 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s8, i32 %t238, i64 %t239, i64 %t240)
  store %"compiler/names:Ref" %t241, ptr %l125
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t242 = load %"compiler/names:Ref", ptr %l125
  store %"compiler/names:Ref" %t242, ptr %rv
  br label %ret
bb67:
  %t243 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t245 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t243)
  store i1 %t245, ptr %l127
  br label %bb68
bb68:
  %t246 = load i1, ptr %l127, !tbaa !21
  br i1 %t246, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s9
  %t248 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s9, i32 7, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t248, ptr %l129
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t249 = load %"compiler/names:Ref", ptr %l129
  store %"compiler/names:Ref" %t249, ptr %rv
  br label %ret
bb72:
  %t251 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t251, ptr %l131
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  %t252 = load %"compiler/names:Ref", ptr %l131
  store %"compiler/names:Ref" %t252, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ematchOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l18 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Match", ptr %t9, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecaseOf(ptr %v0, ptr %v1, ptr %t34, ptr %t32)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emember(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/names:Ref"
  %l8 = alloca i64
  %l14 = alloca %"compiler/names:Ref"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/names:Ref"
  %l21 = alloca i32
  %l22 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasTarget(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i32, ptr %l3, !tbaa !23
  %t17 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ememberOf(ptr %v0, ptr %t11, i64 %t12, i32 %t13)
  store %"compiler/names:Ref" %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb14
bb4:
  %t18 = load %"compiler/names:Ref", ptr %l14
  store %"compiler/names:Ref" %t18, ptr %l5
  %t19 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 9}
  %t22 = trunc i64 0 to i32
  %t23 = icmp eq i32 %t20, %t22
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l19, !tbaa !24
  %t29 = load %"compiler/names:Ref", ptr %l5
  store %"compiler/names:Ref" %t29, ptr %l20
  %t30 = load i32, ptr %l3, !tbaa !23
  store i32 %t30, ptr %l21, !tbaa !23
  %t31 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t32 = load i32, ptr %t31, !tbaa !23
  store i32 %t32, ptr %l22, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t33, i32 %t34)
  store { i64, ptr } %t37, ptr %l25
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t41 = trunc i64 %t39 to i32
  %t42 = load i32, ptr %l22, !tbaa !23
  %t44 = sub i32 %t42, %t41
  %t45 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t46 = load i32, ptr %t45, !tbaa !23
  %t49 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t44, i32 %t46)
  store %"compiler/source:Span" %t49, ptr %l30
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l18, !tbaa !29
  %t51 = load i64, ptr %l19, !tbaa !24
  %t52 = load %"compiler/names:Ref", ptr %l20
  %t53 = load i32, ptr %l21, !tbaa !23
  %t54 = load %"compiler/source:Span", ptr %l30
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enotPrivate(ptr %v0, ptr %t50, i64 %t51, %"compiler/names:Ref" %t52, i32 %t53, %"compiler/source:Span" %t54)
  br label %bb9
bb9:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/names:Resolver", ptr %t55, i32 0, i32 5
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/names:Resolver", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/load:Loader", ptr %t61, i32 0, i32 5
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/names:Resolver", ptr %t64, i32 0, i32 6
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t63, i64 %t67)
  store ptr %t70, ptr %l38
  br label %bb10
bb10:
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t73 = getelementptr %"compiler/load:Module", ptr %t71, i32 0, i32 4
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t79 = call i64 @compiler_2fnames_2ekey(i64 %t74, i32 %t76)
  store i64 %t79, ptr %l42
  br label %bb11
bb11:
  %t80 = load %"compiler/names:Ref", ptr %l5
  %t81 = load ptr, ptr %l32, !tbaa !29
  %t82 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t81, i64 %t82, %"compiler/names:Ref" %t80)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  br label %ret
bb14:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t84, ptr %t85)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ememberOf(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l22 = alloca %"compiler/names:Entry"
  %l26 = alloca %"compiler/names:Ref"
  %l27 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l38 = alloca %"compiler/names:Ref"
  %l39 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l49 = alloca %"compiler/names:Ref"
  %l51 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/names:Table", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l16
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l15
  br label %bb2
bb2:
  %t20 = load i64, ptr %l15, !tbaa !24
  store i64 %t20, ptr %l11, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l11, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/names:Table", ptr %t26, i32 0, i32 0
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s1, ptr %t28, i64 %t29)
  store %"compiler/names:Entry" %t32, ptr %l22
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t33 = getelementptr %"compiler/names:Entry", ptr %l22, i32 0, i32 2
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 9}
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t40 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s1, i32 %t34, i64 %t35, i64 %t36)
  store %"compiler/names:Ref" %t40, ptr %l26
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/names:Ref", ptr %l26
  store %"compiler/names:Ref" %t41, ptr %rv
  br label %ret
bb10:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/names:Table", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t44, i32 %t45)
  %t49 = extractvalue { i32, i64 } %t48, 1
  %t50 = extractvalue { i32, i64 } %t48, 0
  store i32 %t50, ptr %l32
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb12, label %ok.52, !prof !99
ok.52:
  store i64 %t49, ptr %l31
  br label %bb11
bb11:
  %t53 = load i64, ptr %l31, !tbaa !24
  store i64 %t53, ptr %l27, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t54 = load i64, ptr %l27, !tbaa !24
  store i64 %t54, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t64 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 4, i64 %t59, i64 %t60)
  store %"compiler/names:Ref" %t64, ptr %l38
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t65 = load %"compiler/names:Ref", ptr %l38
  store %"compiler/names:Ref" %t65, ptr %rv
  br label %ret
bb18:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/names:Table", ptr %t66, i32 0, i32 3
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t68, i32 %t69)
  %t73 = extractvalue { i32, i64 } %t72, 1
  %t74 = extractvalue { i32, i64 } %t72, 0
  store i32 %t74, ptr %l44
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb20, label %ok.76, !prof !99
ok.76:
  store i64 %t73, ptr %l43
  br label %bb19
bb19:
  %t77 = load i64, ptr %l43, !tbaa !24
  store i64 %t77, ptr %l39, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l39, !tbaa !24
  br label %bb22
bb22:
  %t78 = load i64, ptr %l39, !tbaa !24
  store i64 %t78, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = icmp sge i64 %t79, 0
  br i1 %t81, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s3, i32 5, i64 %t83, i64 -1)
  store %"compiler/names:Ref" %t86, ptr %l49
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t87 = load %"compiler/names:Ref", ptr %l49
  store %"compiler/names:Ref" %t87, ptr %rv
  br label %ret
bb26:
  %t89 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t89, ptr %l51
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t90 = load %"compiler/names:Ref", ptr %l51
  store %"compiler/names:Ref" %t90, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ename(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/names:Ref"
  %l6 = alloca %"compiler/names:Ref"
  %l14 = alloca i1
  %l17 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/names:Ref" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/names:Ref", ptr %l6
  store %"compiler/names:Ref" %t6, ptr %l3
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load %"compiler/names:Ref", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t7, %"compiler/source:Span" %t8, %"compiler/names:Ref" %t9)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/names:Ref", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eread(ptr %v0, ptr %t13, %"compiler/names:Ref" %t14)
  br label %bb3
bb3:
  %t17 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 9}
  %t20 = trunc i64 0 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/names:Resolver", ptr %t23, i32 0, i32 12
  %t26 = load i1, ptr %t25, !tbaa !21
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l20
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t35, ptr %l21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l21, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  %t42 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownInCond(ptr %v0, ptr %t40, %"compiler/source:Span" %t41, i32 %t42)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/token:Token"
  %l21 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l77 = alloca { i64, ptr }
  %l82 = alloca i1
  %l89 = alloca i1
  %l96 = alloca { i64, ptr }
  %l98 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l107 = alloca i1
  %l110 = alloca %"compiler/source:Span"
  %l115 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l21
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l21, !tbaa !29
  store ptr %t11, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = getelementptr %"compiler/load:Module", ptr %t12, i32 0, i32 7
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  br i1 %t17, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_8d565d6672144814_e400a405fc887290)
  unreachable
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr %"compiler/load:Module", ptr %t19, i32 0, i32 7
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t25 = getelementptr %"compiler/scan:Tokens", ptr %t22, i32 0, i32 0
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb6, label %bb7
bb6:
  br label %bb13
bb7:
  br label %bb8
bb8:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sdiv i64 %t44, 2
  store i64 %t46, ptr %l8, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t48, ptr %l39, !tbaa !27
  %t49 = load i64, ptr %l8, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr %"compiler/token:Token", ptr %t52, i64 %t49
  %t54 = getelementptr %"compiler/token:Token", ptr %t53, i32 0, i32 2
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = icmp slt i32 %t55, %t56
  br i1 %t59, label %bb9, label %bb10
bb9:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb11
bb10:
  %t65 = load i64, ptr %l8, !tbaa !24
  store i64 %t65, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  br label %bb12
bb12:
  br label %bb5
bb13:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t71 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t67, i32 %a3)
  store { i64, ptr } %t71, ptr %l49
  br label %bb14
bb14:
  %t72 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t72, ptr %l9, !tbaa !27
  %t73 = load i64, ptr %l6, !tbaa !24
  store i64 %t73, ptr %l10, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t79 = load i64, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = icmp sgt i64 %t79, %t80
  br i1 %t83, label %bb15, label %bb16
bb15:
  %t85 = load i64, ptr %l12, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb20
bb17:
  %t89 = load i64, ptr %l11, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = sub i64 %t89, %t90
  %t94 = load i64, ptr %l12, !tbaa !24
  %t97 = add i64 %t93, %t94
  %t99 = sub i64 %t97, 1
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = sdiv i64 %t99, %t100
  store i64 %t103, ptr %l59, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb19
bb19:
  %t105 = load i64, ptr %l59, !tbaa !24
  store i64 %t105, ptr %l56, !tbaa !24
  br label %bb20
bb20:
  %t106 = load i64, ptr %l56, !tbaa !24
  store i64 %t106, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb21
bb21:
  %t107 = load i64, ptr %l14, !tbaa !24
  %t108 = load i64, ptr %l13, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb22, label %bb23
bb22:
  br label %bb49
bb23:
  br label %bb24
bb24:
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = mul i64 %t116, %t117
  %t123 = add i64 %t115, %t120
  store i64 %t123, ptr %l15, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t125, ptr %l77, !tbaa !27
  %t126 = load i64, ptr %l15, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/token:Token", ptr %t129, i64 %t126
  %t131 = load %"compiler/token:Token", ptr %t130
  store %"compiler/token:Token" %t131, ptr %l16
  %t133 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 0
  %t134 = load i32, ptr %t133, !range !{i32 0, i32 96}
  %t136 = trunc i64 0 to i32
  %t137 = icmp eq i32 %t134, %t136
  br i1 %t137, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb27
bb26:
  %t139 = load i64, ptr %l15, !tbaa !24
  %t140 = load i64, ptr %l6, !tbaa !24
  %t143 = sub i64 %t139, %t140
  %t145 = icmp sgt i64 %t143, 256
  store i1 %t145, ptr %l82, !tbaa !21
  br label %bb27
bb27:
  %t147 = load i1, ptr %l82, !tbaa !21
  br i1 %t147, label %bb28, label %bb29
bb28:
  br label %bb49
bb29:
  br label %bb30
bb30:
  %t148 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 0
  %t149 = load i32, ptr %t148, !range !{i32 0, i32 96}
  %t151 = trunc i64 1 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb31, label %bb32
bb31:
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/load:Module", ptr %t154, i32 0, i32 6
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  br i1 %t159, label %bb33, label %bb34
bb32:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb43
bb33:
  call void @__olang_check_failed(ptr @olang_loc_494c345e55bc9323_650b6e4eb2f730ef)
  unreachable
bb34:
  br label %bb35
bb35:
  %t161 = load ptr, ptr %l4, !tbaa !29
  %t163 = getelementptr %"compiler/load:Module", ptr %t161, i32 0, i32 6
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t167 = getelementptr %"compiler/source:Source", ptr %t164, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  store { i64, ptr } %t168, ptr %l96, !tbaa !27
  %t169 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 2
  %t170 = load i32, ptr %t169, !tbaa !23
  %t172 = sext i32 %t170 to i64
  store i64 %t172, ptr %l98, !tbaa !24
  %t173 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 3
  %t174 = load i32, ptr %t173, !tbaa !23
  %t176 = sext i32 %t174 to i64
  store i64 %t176, ptr %l100, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  store i64 %t178, ptr %l101, !tbaa !24
  %t179 = load i64, ptr %l98, !tbaa !24
  %t180 = icmp sge i64 %t179, 0
  br i1 %t180, label %bb36, label %bb37
bb36:
  %t182 = load i64, ptr %l98, !tbaa !24
  %t183 = load i64, ptr %l100, !tbaa !24
  %t184 = icmp sle i64 %t182, %t183
  br i1 %t184, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_9c997e82162b9a5a_f5a213d30049e536)
  unreachable
bb38:
  %t186 = load i64, ptr %l100, !tbaa !24
  %t187 = load i64, ptr %l101, !tbaa !24
  %t188 = icmp sle i64 %t186, %t187
  br i1 %t188, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_9c997e82162b9a5a_f5a213d30049e536)
  unreachable
bb40:
  %t190 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = load i64, ptr %l98, !tbaa !24
  %t193 = load i64, ptr %l100, !tbaa !24
  %t194 = getelementptr i8, ptr %t191, i64 %t192
  %t195 = sub i64 %t193, %t192
  %t196 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t194, 1
  %t198 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t201 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t197, { i64, ptr } %t198)
  store i1 %t201, ptr %l107
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_9c997e82162b9a5a_f5a213d30049e536)
  unreachable
bb42:
  %t202 = load i1, ptr %l107, !tbaa !21
  store i1 %t202, ptr %l89, !tbaa !21
  br label %bb43
bb43:
  %t203 = load i1, ptr %l89, !tbaa !21
  br i1 %t203, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t204 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 2
  %t205 = load i32, ptr %t204, !tbaa !23
  %t206 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 3
  %t207 = load i32, ptr %t206, !tbaa !23
  %t210 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s7, i32 %t205, i32 %t207)
  store %"compiler/source:Span" %t210, ptr %l110
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t211 = load %"compiler/source:Span", ptr %l110
  store %"compiler/source:Span" %t211, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t212 = load i64, ptr %l14, !tbaa !24
  %t214 = add i64 %t212, 1
  store i64 %t214, ptr %l14, !tbaa !24
  br label %bb21
bb49:
  %t216 = load i32, ptr %l2, !tbaa !23
  %t217 = load i32, ptr %l2, !tbaa !23
  %t220 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t216, i32 %t217)
  store %"compiler/source:Span" %t220, ptr %l115
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  %t221 = load %"compiler/source:Span", ptr %l115
  store %"compiler/source:Span" %t221, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enearRaise(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/names:raisedName" %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/names:raisedName"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/names:Entry"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/names:raised"
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca %"compiler/names:Entry"
  %l41 = alloca i1
  %l45 = alloca i1
  %l51 = alloca i64
  %l54 = alloca i1
  %l57 = alloca %"compiler/names:raisedName"
  %l59 = alloca i1
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l69 = alloca i1
  %l72 = alloca i1
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l78 = alloca i64
  %l88 = alloca i64
  %l90 = alloca i64
  %l95 = alloca %"compiler/names:raised"
  %l101 = alloca ptr
  %l105 = alloca { i64, [3 x i64] }
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l113 = alloca %"compiler/msgs:Msg"
  %l114 = alloca i64
  %s0 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/names:raisedName" %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/names:raisedName", ptr %l2, i32 0, i32 3
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:raisedName", ptr %l2, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t4, i32 %t6)
  store { i64, ptr } %t9, ptr %l19
  br label %bb4
bb4:
  %t10 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t11, ptr %l21, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l22, !tbaa !24
  %t14 = load i64, ptr %l22, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l23, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l22, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  store i64 2, ptr %l6, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/names:Resolver", ptr %t26, i32 0, i32 1
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store ptr %t32, ptr %l27
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l27, !tbaa !29
  %t36 = getelementptr %"compiler/names:Table", ptr %t33, i32 0, i32 0
  store ptr %t36, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l9, !tbaa !24
  store i64 %t38, ptr %l30, !tbaa !24
  %t39 = load ptr, ptr %l8, !tbaa !29
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l32
  br label %bb7
bb7:
  %t42 = load i64, ptr %l30, !tbaa !24
  %t43 = load i64, ptr %l32, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb44
bb9:
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l8, !tbaa !29
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store %"compiler/names:Entry" %t52, ptr %l37
  br label %bb11
bb11:
  %t53 = load %"compiler/names:Entry", ptr %l37
  store %"compiler/names:Entry" %t53, ptr %l10
  %t54 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 2
  %t55 = load i32, ptr %t54, !range !{i32 0, i32 9}
  %t57 = trunc i64 4 to i32
  %t58 = icmp eq i32 %t55, %t57
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb14
bb13:
  %t62 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 4
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %l41, !tbaa !21
  br label %bb14
bb14:
  %t69 = load i1, ptr %l41, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb17
bb16:
  %t70 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = getelementptr %"compiler/names:raisedName", ptr %l2, i32 0, i32 0
  %t73 = load i32, ptr %t72, !tbaa !23
  %t76 = icmp eq i32 %t71, %t73
  store i1 %t76, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t78 = load i1, ptr %l45, !tbaa !21
  br i1 %t78, label %bb18, label %bb19
bb18:
  br label %bb43
bb19:
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t84 = call i64 @compiler_2fnames_2eindexOfRaised(ptr %v1, ptr %t79, i32 %t81)
  store i64 %t84, ptr %l51
  br label %bb21
bb21:
  %t85 = load i64, ptr %l51, !tbaa !24
  store i64 %t85, ptr %l11, !tbaa !24
  %t86 = load i64, ptr %l11, !tbaa !24
  %t88 = icmp sge i64 %t86, 0
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t91 = load i64, ptr %l11, !tbaa !24
  %t94 = call %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %v1, ptr %t90, i64 %t91)
  store %"compiler/names:raisedName" %t94, ptr %l57
  br label %bb24
bb23:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb26
bb24:
  %t95 = load %"compiler/names:raisedName", ptr %l2
  %t96 = load %"compiler/names:raisedName", ptr %l57
  %t98 = call i1 @compiler_2fnames_2eoutranks(%"compiler/names:raisedName" %t96, %"compiler/names:raisedName" %t95)
  store i1 %t98, ptr %l59
  br label %bb25
bb25:
  %t99 = load i1, ptr %l59, !tbaa !21
  %t100 = xor i1 %t99, true
  store i1 %t100, ptr %l54, !tbaa !21
  br label %bb26
bb26:
  %t102 = load i1, ptr %l54, !tbaa !21
  br i1 %t102, label %bb27, label %bb28
bb27:
  br label %bb43
bb28:
  br label %bb29
bb29:
  %t103 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t103, ptr %l61, !tbaa !27
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t106 = load i32, ptr %t105, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t104, i32 %t106)
  store { i64, ptr } %t109, ptr %l64
  br label %bb30
bb30:
  %t110 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t112 = call i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v0, { i64, ptr } %t110, { i64, ptr } %t111)
  store i64 %t112, ptr %l65
  br label %bb31
bb31:
  %t113 = load i64, ptr %l65, !tbaa !24
  store i64 %t113, ptr %l12, !tbaa !24
  %t114 = load i64, ptr %l12, !tbaa !24
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  br i1 %t118, label %bb32, label %bb33
bb32:
  %t120 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = load i64, ptr %l12, !tbaa !24
  %t124 = call i1 @compiler_2fmsgs_2eNear(ptr %v0, { i64, ptr } %t120, i64 %t121)
  store i1 %t124, ptr %l72
  br label %bb34
bb33:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb35
bb34:
  %t125 = load i1, ptr %l72, !tbaa !21
  store i1 %t125, ptr %l69, !tbaa !21
  br label %bb35
bb35:
  %t126 = load i1, ptr %l69, !tbaa !21
  br i1 %t126, label %bb36, label %bb37
bb36:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t129 = load i32, ptr %t128, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t127, i32 %t129)
  store { i64, ptr } %t132, ptr %l75
  br label %bb38
bb37:
  br label %bb42
bb38:
  %t133 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t135)
  call void @olang_textcopy(ptr %t136, ptr %t134, i64 %t135)
  %t137 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l76, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t141 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l78, !tbaa !24
  %t144 = load i64, ptr %l78, !tbaa !24
  %t145 = icmp eq i64 %t140, %t144
  br i1 %t145, label %bb39, label %bb40
bb39:
  %t147 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = load i64, ptr %l78, !tbaa !24
  %t152 = mul i64 %t151, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t148, ptr %t150, i64 %t152, i1 false)
  br label %bb41
bb40:
  %t153 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t153, ptr %l5, !tbaa !27
  br label %bb41
bb41:
  %t154 = load i64, ptr %l12, !tbaa !24
  store i64 %t154, ptr %l6, !tbaa !24
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l9, !tbaa !24
  br label %bb6
bb44:
  %t160 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t164 = icmp eq i64 %t162, 0
  br i1 %t164, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb46:
  br label %bb47
bb47:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/names:Resolver", ptr %t166, i32 0, i32 23
  store ptr %t168, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb48
bb48:
  %t170 = load i64, ptr %l14, !tbaa !24
  store i64 %t170, ptr %l88, !tbaa !24
  %t171 = load ptr, ptr %l13, !tbaa !29
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eLen_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %t171)
  store i64 %t173, ptr %l90
  br label %bb49
bb49:
  %t174 = load i64, ptr %l88, !tbaa !24
  %t175 = load i64, ptr %l90, !tbaa !24
  %t176 = icmp slt i64 %t174, %t175
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb50, label %bb51
bb50:
  br label %bb63
bb51:
  br label %bb52
bb52:
  %t180 = load ptr, ptr %l13, !tbaa !29
  %t181 = load i64, ptr %l14, !tbaa !24
  %t184 = call %"compiler/names:raised" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eAt_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %t180, i64 %t181)
  store %"compiler/names:raised" %t184, ptr %l95
  br label %bb53
bb53:
  %t185 = load %"compiler/names:raised", ptr %l95
  store %"compiler/names:raised" %t185, ptr %l15
  %t186 = getelementptr %"compiler/names:raised", ptr %l15, i32 0, i32 0
  %t187 = load i32, ptr %t186, !tbaa !23
  %t188 = getelementptr %"compiler/names:raisedName", ptr %l2, i32 0, i32 0
  %t189 = load i32, ptr %t188, !tbaa !23
  %t192 = icmp eq i32 %t187, %t189
  br i1 %t192, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/names:Resolver", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/load:Loader", ptr %t197, i32 0, i32 4
  %t200 = load ptr, ptr %t199, !tbaa !29
  store ptr %t200, ptr %l101, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i64, ptr %l1, !tbaa !24
  %t203 = getelementptr %"compiler/names:raised", ptr %l15, i32 0, i32 1
  %t204 = load %"compiler/source:Span", ptr %t203
  %t208 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t201, i64 %t202, %"compiler/source:Span" %t204)
  store { i64, [3 x i64] } %t208, ptr %l105
  br label %bb56
bb55:
  br label %bb61
bb56:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/names:raisedName", ptr %l2, i32 0, i32 0
  %t211 = load i32, ptr %t210, !tbaa !23
  %t214 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s12, ptr %t209, i32 %t211)
  store { i64, ptr } %t214, ptr %l108
  br label %bb57
bb57:
  %t215 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l109, !tbaa !27
  %t222 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t224 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s12, { i64, ptr } %t222)
  store { i64, ptr } %t224, ptr %l111
  br label %bb58
bb58:
  %t225 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  %t227 = extractvalue { i64, ptr } %t225, 1
  %t228 = mul i64 %t226, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t229, ptr %t227, i64 %t228, i1 false)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  %t232 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t234 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eRaiseNearError(ptr %s12, ptr %s12, ptr %s12, { i64, ptr } %t232, { i64, ptr } %t231)
  store %"compiler/msgs:Msg" %t234, ptr %l113
  br label %bb59
bb59:
  %t235 = load ptr, ptr %l101, !tbaa !29
  %t236 = load { i64, [3 x i64] }, ptr %l105
  %t237 = load %"compiler/msgs:Msg", ptr %l113
  %t238 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s12, ptr %t235, { i64, [3 x i64] } %t236, %"compiler/msgs:Msg" %t237)
  store i64 %t238, ptr %l114
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s12)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t239 = load i64, ptr %l14, !tbaa !24
  %t241 = add i64 %t239, 1
  store i64 %t241, ptr %l14, !tbaa !24
  br label %bb48
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l20 = alloca { i64, [3 x i64] }
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  store i32 %t1, ptr %l4, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t3, i32 0, i32 1
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t12 = getelementptr %"compiler/names:Table", ptr %t10, i32 0, i32 3
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  %t31 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t25, i64 %t26, %"compiler/source:Span" %a3)
  store { i64, [3 x i64] } %t31, ptr %l20
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t32, i32 %t33)
  store { i64, ptr } %t36, ptr %l23
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = mul i64 %t38, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameClashesWithImport(ptr %s1, ptr %s1, { i64, ptr } %t43)
  store %"compiler/msgs:Msg" %t45, ptr %l25
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l16, !tbaa !29
  %t47 = load { i64, [3 x i64] }, ptr %l20
  %t48 = load %"compiler/msgs:Msg", ptr %l25
  %t49 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t46, { i64, [3 x i64] } %t47, %"compiler/msgs:Msg" %t48)
  store i64 %t49, ptr %l26
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoShadow(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"compiler/names:Entry"
  %l11 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l31 = alloca %"compiler/names:Entry"
  %l34 = alloca ptr
  %l39 = alloca { i64, [3 x i64] }
  %l42 = alloca %"compiler/msgs:Msg"
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/msgs:Msg"
  %l50 = alloca { i64, ptr }
  %l52 = alloca %"compiler/msgs:Msg"
  %l53 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l62 = alloca { i64, [3 x i64] }
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"compiler/msgs:Msg"
  %l72 = alloca i1
  %l75 = alloca ptr
  %l80 = alloca { i64, [3 x i64] }
  %l83 = alloca { i64, ptr }
  %l85 = alloca %"compiler/msgs:Msg"
  %l86 = alloca i64
  %l91 = alloca i1
  %l94 = alloca ptr
  %l99 = alloca { i64, [3 x i64] }
  %l102 = alloca { i64, ptr }
  %l104 = alloca %"compiler/msgs:Msg"
  %l105 = alloca i64
  %l110 = alloca i1
  %l111 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i1
  %l119 = alloca i1
  %l122 = alloca ptr
  %l127 = alloca { i64, [3 x i64] }
  %l130 = alloca { i64, ptr }
  %l132 = alloca %"compiler/msgs:Msg"
  %l133 = alloca i64
  %l134 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i32
  %l142 = alloca i1
  %l146 = alloca %"compiler/names:local"
  %l151 = alloca ptr
  %l156 = alloca { i64, [3 x i64] }
  %l159 = alloca { i64, ptr }
  %l161 = alloca %"compiler/msgs:Msg"
  %l162 = alloca i64
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/names:Resolver", ptr %t4, i32 0, i32 6
  %t7 = load i64, ptr %t6, !tbaa !24
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t7)
  store ptr %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l16, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l19
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/names:Table", ptr %t18, i32 0, i32 1
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t20, i32 %t21)
  %t25 = extractvalue { i32, i64 } %t24, 1
  %t26 = extractvalue { i32, i64 } %t24, 0
  store i32 %t26, ptr %l25
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb4, label %ok.28, !prof !99
ok.28:
  store i64 %t25, ptr %l24
  br label %bb3
bb3:
  %t29 = load i64, ptr %l24, !tbaa !24
  store i64 %t29, ptr %l20, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l20, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sge i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/names:Table", ptr %t35, i32 0, i32 0
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store %"compiler/names:Entry" %t41, ptr %l31
  br label %bb9
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/names:Resolver", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/load:Loader", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v0, ptr %t48, { i64, ptr } %t49)
  store i1 %t52, ptr %l72
  br label %bb23
bb9:
  %t53 = load %"compiler/names:Entry", ptr %l31
  store %"compiler/names:Entry" %t53, ptr %l6
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/names:Resolver", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/load:Loader", ptr %t57, i32 0, i32 4
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l34, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/names:Resolver", ptr %t62, i32 0, i32 6
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = load %"compiler/source:Span", ptr %l2
  %t70 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t61, i64 %t65, %"compiler/source:Span" %t66)
  store { i64, [3 x i64] } %t70, ptr %l39
  br label %bb10
bb10:
  %t71 = getelementptr %"compiler/names:Entry", ptr %l6, i32 0, i32 2
  %t72 = load i32, ptr %t71, !range !{i32 0, i32 9}
  %t74 = trunc i64 3 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb11, label %bb12
bb11:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l1, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t77, i32 %t78)
  store { i64, ptr } %t81, ptr %l45
  br label %bb13
bb12:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t82, i32 %t83)
  store { i64, ptr } %t86, ptr %l50
  br label %bb15
bb13:
  %t87 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t95 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsFunction(ptr %s1, ptr %s1, { i64, ptr } %t93)
  store %"compiler/msgs:Msg" %t95, ptr %l47
  br label %bb14
bb14:
  %t96 = load %"compiler/msgs:Msg", ptr %l47
  store %"compiler/msgs:Msg" %t96, ptr %l42
  br label %bb17
bb15:
  %t97 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  %t99 = extractvalue { i64, ptr } %t97, 1
  %t100 = mul i64 %t98, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t101, ptr %t99, i64 %t100, i1 false)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t105 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsGlobal(ptr %s1, ptr %s1, { i64, ptr } %t103)
  store %"compiler/msgs:Msg" %t105, ptr %l52
  br label %bb16
bb16:
  %t106 = load %"compiler/msgs:Msg", ptr %l52
  store %"compiler/msgs:Msg" %t106, ptr %l42
  br label %bb17
bb17:
  %t107 = load ptr, ptr %l34, !tbaa !29
  %t108 = load { i64, [3 x i64] }, ptr %l39
  %t109 = load %"compiler/msgs:Msg", ptr %l42
  %t110 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t107, { i64, [3 x i64] } %t108, %"compiler/msgs:Msg" %t109)
  store i64 %t110, ptr %l53
  br label %bb18
bb18:
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/names:Resolver", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 4
  %t118 = load ptr, ptr %t117, !tbaa !29
  store ptr %t118, ptr %l56, !tbaa !29
  store i64 %t111, ptr %l57, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/names:Resolver", ptr %t121, i32 0, i32 6
  %t124 = load i64, ptr %t123, !tbaa !24
  %t125 = getelementptr %"compiler/names:Entry", ptr %l6, i32 0, i32 1
  %t126 = load %"compiler/source:Span", ptr %t125
  %t130 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t120, i64 %t124, %"compiler/source:Span" %t126)
  store { i64, [3 x i64] } %t130, ptr %l62
  br label %bb19
bb19:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s1, ptr %t131, i32 %t132)
  store { i64, ptr } %t135, ptr %l65
  br label %bb20
bb20:
  %t136 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t138 = extractvalue { i64, ptr } %t136, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t144 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s1, ptr %s1, { i64, ptr } %t142)
  store %"compiler/msgs:Msg" %t144, ptr %l67
  br label %bb21
bb21:
  %t145 = load ptr, ptr %l56, !tbaa !29
  %t146 = load i64, ptr %l57, !tbaa !24
  %t147 = load { i64, [3 x i64] }, ptr %l62
  %t148 = load %"compiler/msgs:Msg", ptr %l67
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s1, ptr %t145, i64 %t146, { i64, [3 x i64] } %t147, %"compiler/msgs:Msg" %t148)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s1)
  br label %bb70
bb23:
  %t149 = load i1, ptr %l72, !tbaa !21
  br i1 %t149, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/names:Resolver", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/load:Loader", ptr %t153, i32 0, i32 4
  %t156 = load ptr, ptr %t155, !tbaa !29
  store ptr %t156, ptr %l75, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/names:Resolver", ptr %t158, i32 0, i32 6
  %t161 = load i64, ptr %t160, !tbaa !24
  %t162 = load %"compiler/source:Span", ptr %l2
  %t166 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t157, i64 %t161, %"compiler/source:Span" %t162)
  store { i64, [3 x i64] } %t166, ptr %l80
  br label %bb26
bb25:
  %t167 = load i32, ptr %l1, !tbaa !23
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/names:Resolver", ptr %t169, i32 0, i32 3
  %t175 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H6d33fbc050830e537410645e3c893b2c(ptr %v0, ptr %t171, i32 %t167)
  store i1 %t175, ptr %l91
  br label %bb30
bb26:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l1, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s3, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l83
  br label %bb27
bb27:
  %t181 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsBuildConst(ptr %s3, ptr %s3, { i64, ptr } %t187)
  store %"compiler/msgs:Msg" %t189, ptr %l85
  br label %bb28
bb28:
  %t190 = load ptr, ptr %l75, !tbaa !29
  %t191 = load { i64, [3 x i64] }, ptr %l80
  %t192 = load %"compiler/msgs:Msg", ptr %l85
  %t193 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t190, { i64, [3 x i64] } %t191, %"compiler/msgs:Msg" %t192)
  store i64 %t193, ptr %l86
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb30:
  %t194 = load i1, ptr %l91, !tbaa !21
  br i1 %t194, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/names:Resolver", ptr %t195, i32 0, i32 0
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/load:Loader", ptr %t198, i32 0, i32 4
  %t201 = load ptr, ptr %t200, !tbaa !29
  store ptr %t201, ptr %l94, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/names:Resolver", ptr %t203, i32 0, i32 6
  %t206 = load i64, ptr %t205, !tbaa !24
  %t207 = load %"compiler/source:Span", ptr %l2
  %t211 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t202, i64 %t206, %"compiler/source:Span" %t207)
  store { i64, [3 x i64] } %t211, ptr %l99
  br label %bb33
bb32:
  %t212 = load i32, ptr %l1, !tbaa !23
  %t214 = load ptr, ptr %l3, !tbaa !29
  %t216 = getelementptr %"compiler/names:Table", ptr %t214, i32 0, i32 2
  %t220 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t216, i32 %t212)
  store i1 %t220, ptr %l110
  br label %bb37
bb33:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l1, !tbaa !23
  %t225 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s5, ptr %t221, i32 %t222)
  store { i64, ptr } %t225, ptr %l102
  br label %bb34
bb34:
  %t226 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 0
  %t228 = extractvalue { i64, ptr } %t226, 1
  %t229 = mul i64 %t227, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t229)
  call void @llvm.memcpy.p0.p0.i64(ptr %t230, ptr %t228, i64 %t229, i1 false)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  %t234 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePreludeConstRedeclared(ptr %s5, ptr %s5, { i64, ptr } %t232)
  store %"compiler/msgs:Msg" %t234, ptr %l104
  br label %bb35
bb35:
  %t235 = load ptr, ptr %l94, !tbaa !29
  %t236 = load { i64, [3 x i64] }, ptr %l99
  %t237 = load %"compiler/msgs:Msg", ptr %l104
  %t238 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t235, { i64, [3 x i64] } %t236, %"compiler/msgs:Msg" %t237)
  store i64 %t238, ptr %l105
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb68
bb37:
  %t239 = load i1, ptr %l110, !tbaa !21
  br i1 %t239, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb41
bb39:
  %t240 = load i32, ptr %l1, !tbaa !23
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/names:Resolver", ptr %t242, i32 0, i32 2
  %t248 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t244, i32 %t240)
  store i1 %t248, ptr %l116
  br label %bb40
bb40:
  %t249 = load i1, ptr %l116, !tbaa !21
  store i1 %t249, ptr %l111, !tbaa !21
  br label %bb41
bb41:
  %t250 = load i1, ptr %l111, !tbaa !21
  br i1 %t250, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb45
bb43:
  %t251 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t253 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t251)
  store i1 %t253, ptr %l119
  br label %bb44
bb44:
  %t254 = load i1, ptr %l119, !tbaa !21
  store i1 %t254, ptr %l117, !tbaa !21
  br label %bb45
bb45:
  %t255 = load i1, ptr %l117, !tbaa !21
  br i1 %t255, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s7
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/names:Resolver", ptr %t256, i32 0, i32 0
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/load:Loader", ptr %t259, i32 0, i32 4
  %t262 = load ptr, ptr %t261, !tbaa !29
  store ptr %t262, ptr %l122, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/names:Resolver", ptr %t264, i32 0, i32 6
  %t267 = load i64, ptr %t266, !tbaa !24
  %t268 = load %"compiler/source:Span", ptr %l2
  %t272 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t263, i64 %t267, %"compiler/source:Span" %t268)
  store { i64, [3 x i64] } %t272, ptr %l127
  br label %bb48
bb47:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/names:Resolver", ptr %t273, i32 0, i32 8
  %t276 = load i32, ptr %l1, !tbaa !23
  %t279 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t275, i32 %t276)
  %t280 = extractvalue { i32, i64 } %t279, 1
  %t281 = extractvalue { i32, i64 } %t279, 0
  store i32 %t281, ptr %l139
  %t282 = icmp ne i32 %t281, 0
  br i1 %t282, label %bb53, label %ok.283, !prof !99
ok.283:
  store i64 %t280, ptr %l138
  br label %bb52
bb48:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i32, ptr %l1, !tbaa !23
  %t288 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s7, ptr %t284, i32 %t285)
  store { i64, ptr } %t288, ptr %l130
  br label %bb49
bb49:
  %t289 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 0
  %t291 = extractvalue { i64, ptr } %t289, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t297 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsType(ptr %s7, ptr %s7, { i64, ptr } %t295)
  store %"compiler/msgs:Msg" %t297, ptr %l132
  br label %bb50
bb50:
  %t298 = load ptr, ptr %l122, !tbaa !29
  %t299 = load { i64, [3 x i64] }, ptr %l127
  %t300 = load %"compiler/msgs:Msg", ptr %l132
  %t301 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t298, { i64, [3 x i64] } %t299, %"compiler/msgs:Msg" %t300)
  store i64 %t301, ptr %l133
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s7)
  br label %bb67
bb52:
  %t302 = load i64, ptr %l138, !tbaa !24
  store i64 %t302, ptr %l134, !tbaa !24
  br label %bb55
bb53:
  br label %bb54
bb54:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l134, !tbaa !24
  br label %bb55
bb55:
  %t303 = load i64, ptr %l134, !tbaa !24
  store i64 %t303, ptr %l11, !tbaa !24
  %t304 = load i64, ptr %l11, !tbaa !24
  %t306 = icmp sge i64 %t304, 0
  br i1 %t306, label %bb56, label %bb57
bb56:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/names:Resolver", ptr %t308, i32 0, i32 7
  %t311 = load i64, ptr %l11, !tbaa !24
  %t314 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t310, i64 %t311)
  store %"compiler/names:local" %t314, ptr %l146
  br label %bb58
bb57:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb59
bb58:
  %t315 = getelementptr %"compiler/names:local", ptr %l146, i32 0, i32 2
  %t316 = load i32, ptr %t315, !range !{i32 0, i32 9}
  %t318 = trunc i64 8 to i32
  %t319 = icmp eq i32 %t316, %t318
  store i1 %t319, ptr %l142, !tbaa !21
  br label %bb59
bb59:
  %t321 = load i1, ptr %l142, !tbaa !21
  br i1 %t321, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s9
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/names:Resolver", ptr %t322, i32 0, i32 0
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t327 = getelementptr %"compiler/load:Loader", ptr %t325, i32 0, i32 4
  %t328 = load ptr, ptr %t327, !tbaa !29
  store ptr %t328, ptr %l151, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/names:Resolver", ptr %t330, i32 0, i32 6
  %t333 = load i64, ptr %t332, !tbaa !24
  %t334 = load %"compiler/source:Span", ptr %l2
  %t338 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t329, i64 %t333, %"compiler/source:Span" %t334)
  store { i64, [3 x i64] } %t338, ptr %l156
  br label %bb62
bb61:
  br label %bb66
bb62:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i32, ptr %l1, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s9, ptr %t339, i32 %t340)
  store { i64, ptr } %t343, ptr %l159
  br label %bb63
bb63:
  %t344 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  %t346 = extractvalue { i64, ptr } %t344, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  %t352 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsType(ptr %s9, ptr %s9, { i64, ptr } %t350)
  store %"compiler/msgs:Msg" %t352, ptr %l161
  br label %bb64
bb64:
  %t353 = load ptr, ptr %l151, !tbaa !29
  %t354 = load { i64, [3 x i64] }, ptr %l156
  %t355 = load %"compiler/msgs:Msg", ptr %l161
  %t356 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t353, { i64, [3 x i64] } %t354, %"compiler/msgs:Msg" %t355)
  store i64 %t356, ptr %l162
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enotPrivate(ptr %v0, ptr %a0, i64 %a1, %"compiler/names:Ref" %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/names:Ref"
  %l3 = alloca i32
  %l5 = alloca %"compiler/msgs:Msg"
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca ptr
  %l31 = alloca %"compiler/msgs:Msg"
  %l34 = alloca { i64, ptr }
  %l36 = alloca %"compiler/msgs:Msg"
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"compiler/msgs:Msg"
  %l44 = alloca ptr
  %l49 = alloca { i64, [3 x i64] }
  %l51 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/names:Ref" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/names:Resolver", ptr %t2, i32 0, i32 6
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = icmp eq i64 %t1, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t10 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t11 = load i32, ptr %t10, !range !{i32 0, i32 9}
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t17 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 9}
  %t20 = trunc i64 5 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t28, ptr %l19
  br label %bb9
bb9:
  %t29 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t30 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t29)
  store i1 %t30, ptr %l20
  br label %bb10
bb10:
  %t31 = load i1, ptr %l20, !tbaa !21
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l16, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb15
bb13:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/names:Resolver", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/load:Loader", ptr %t36, i32 0, i32 5
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t38, i64 %t39)
  store ptr %t42, ptr %l26
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t45 = getelementptr %"compiler/load:Module", ptr %t43, i32 0, i32 30
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb15
bb15:
  %t48 = load i1, ptr %l21, !tbaa !21
  br i1 %t48, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  br label %bb18
bb18:
  %t49 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 9}
  %t52 = trunc i64 4 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t55, i32 %t56)
  store { i64, ptr } %t59, ptr %l34
  br label %bb21
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t60, i32 %t61)
  store { i64, ptr } %t64, ptr %l39
  br label %bb23
bb21:
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t73 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeIsPrivate(ptr %s0, ptr %s0, { i64, ptr } %t71)
  store %"compiler/msgs:Msg" %t73, ptr %l36
  br label %bb22
bb22:
  %t74 = load %"compiler/msgs:Msg", ptr %l36
  store %"compiler/msgs:Msg" %t74, ptr %l31
  br label %bb25
bb23:
  %t75 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  %t83 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarIsPrivate(ptr %s0, ptr %s0, { i64, ptr } %t81)
  store %"compiler/msgs:Msg" %t83, ptr %l41
  br label %bb24
bb24:
  %t84 = load %"compiler/msgs:Msg", ptr %l41
  store %"compiler/msgs:Msg" %t84, ptr %l31
  br label %bb25
bb25:
  %t85 = load %"compiler/msgs:Msg", ptr %l31
  store %"compiler/msgs:Msg" %t85, ptr %l5
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/names:Resolver", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/load:Loader", ptr %t89, i32 0, i32 4
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l44, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/names:Resolver", ptr %t94, i32 0, i32 6
  %t97 = load i64, ptr %t96, !tbaa !24
  %t102 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t93, i64 %t97, %"compiler/source:Span" %a4)
  store { i64, [3 x i64] } %t102, ptr %l49
  br label %bb26
bb26:
  %t103 = load %"compiler/msgs:Msg", ptr %l5
  %t104 = load ptr, ptr %l44, !tbaa !29
  %t105 = load { i64, [3 x i64] }, ptr %l49
  %t107 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s0, ptr %t104, { i64, [3 x i64] } %t105, %"compiler/msgs:Msg" %t103)
  store i64 %t107, ptr %l51
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l11 = alloca ptr
  %l17 = alloca { i64, [3 x i64] }
  %l18 = alloca %"compiler/msgs:Msg"
  %l19 = alloca i64
  %l27 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Param", ptr %t2, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  %t8 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t1, i32 %t5)
  store { i64, ptr } %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/names:Resolver", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/load:Loader", ptr %t15, i32 0, i32 4
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l11, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/names:Resolver", ptr %t20, i32 0, i32 6
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Param", ptr %t24, i32 0, i32 0
  %t27 = load %"compiler/source:Span", ptr %t26
  %t31 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t19, i64 %t23, %"compiler/source:Span" %t27)
  store { i64, [3 x i64] } %t31, ptr %l17
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t32 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %s1)
  store %"compiler/msgs:Msg" %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l11, !tbaa !29
  %t34 = load { i64, [3 x i64] }, ptr %l17
  %t35 = load %"compiler/msgs:Msg", ptr %l18
  %t36 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t33, { i64, [3 x i64] } %t34, %"compiler/msgs:Msg" %t35)
  store i64 %t36, ptr %l19
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/names:Resolver", ptr %t38, i32 0, i32 6
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Param", ptr %t42, i32 0, i32 0
  %t45 = getelementptr %"compiler/source:Span", ptr %t44, i32 0, i32 0
  %t46 = load i32, ptr %t45, !tbaa !23
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Param", ptr %t47, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  %t55 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t37, i64 %t41, i32 %t46, i32 %t50)
  store %"compiler/source:Span" %t55, ptr %l27
  br label %bb9
bb9:
  %t56 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t56, ptr %l3
  br i1 %a2, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/ast:Param", ptr %t60, i32 0, i32 1
  %t63 = load i32, ptr %t62, !tbaa !23
  %t64 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t59, i32 %t63, %"compiler/source:Span" %t64, i1 false)
  br label %bb12
bb11:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 6
  %t72 = load i64, ptr %t71, !tbaa !24
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Param", ptr %t73, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t77 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t68, i64 %t72, i32 %t76, %"compiler/source:Span" %t77)
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Param", ptr %t83, i32 0, i32 1
  %t86 = load i32, ptr %t85, !tbaa !23
  %t87 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t82, i32 %t86, %"compiler/source:Span" %t87, i32 1)
  br label %bb14
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/names:Ref"
  %l7 = alloca i1
  %l13 = alloca { i64, ptr }
  %l21 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/names:Ref"
  %l30 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:Path", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Path", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 0
  %t22 = load i32, ptr %t21, !tbaa !33
  store i32 %t22, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/names:Resolver", ptr %t25, i32 0, i32 6
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Path", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"compiler/source:Span", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load i32, ptr %l2, !tbaa !23
  %t39 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t24, i64 %t28, i32 %t33, i32 %t34)
  store %"compiler/source:Span" %t39, ptr %l21
  br label %bb7
bb7:
  %t40 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t40, ptr %l3
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t41, i32 %t42)
  store %"compiler/names:Ref" %t45, ptr %l24
  br label %bb8
bb8:
  %t46 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t46, ptr %l4
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l3
  %t49 = load %"compiler/names:Ref", ptr %l4
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t47, %"compiler/source:Span" %t48, %"compiler/names:Ref" %t49)
  br label %bb9
bb9:
  %t53 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t54 = load i32, ptr %t53, !range !{i32 0, i32 9}
  %t56 = trunc i64 0 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Path", ptr %t59, i32 0, i32 1
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t66 = icmp sge i64 %t64, 2
  store i1 %t66, ptr %l30, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t68 = load i1, ptr %l30, !tbaa !21
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l3
  %t71 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %t69, %"compiler/source:Span" %t70, i32 %t71)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l18 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l50 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca i1
  %l69 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca i1
  %l94 = alloca i1
  %l98 = alloca i1
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 6}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t17 = load ptr, ptr %l23, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l23, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 6}
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l24, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l24, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb10
bb10:
  br label %bb60
bb11:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t37 = load ptr, ptr %l32, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l32, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 6}
  %t43 = icmp eq i64 %t41, 2
  store i1 %t43, ptr %l33, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l33, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l4, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t53, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %t54
  store { i64, ptr } %t55, ptr %l5, !tbaa !27
  br label %bb16
bb15:
  br label %bb25
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t57, ptr %t58)
  br label %bb17
bb17:
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t62, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb19, label %bb20
bb19:
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t76 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t76, ptr %l50, !tbaa !27
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t77
  %t82 = load ptr, ptr %t81, !tbaa !39
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %t84, ptr %t82, ptr %t86)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l7, !tbaa !24
  br label %bb18
bb24:
  br label %bb60
bb25:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t95 = load ptr, ptr %l58, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb26, label %bb27
bb26:
  %t98 = load ptr, ptr %l58, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 6}
  %t101 = icmp eq i64 %t99, 3
  store i1 %t101, ptr %l59, !tbaa !21
  br label %bb27
bb27:
  %t102 = load i1, ptr %l59, !tbaa !21
  br i1 %t102, label %bb28, label %bb29
bb28:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32 }, ptr %t105, i32 0, i32 0
  %t107 = load %"compiler/source:Span", ptr %t106
  store %"compiler/source:Span" %t107, ptr %l10
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32 }, ptr %t111, i32 0, i32 1
  %t113 = load i32, ptr %t112
  store i32 %t113, ptr %l11, !tbaa !23
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t115 = load i32, ptr %l11, !tbaa !23
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t121 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t117, i32 %t115)
  store i1 %t121, ptr %l69
  br label %bb31
bb31:
  %t122 = load i1, ptr %l69, !tbaa !21
  %t123 = xor i1 %t122, true
  br i1 %t123, label %bb32, label %bb33
bb32:
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t126 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t125, i32 %t126)
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l11, !tbaa !23
  %t131 = load %"compiler/source:Span", ptr %l10
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %t129, i32 %t130, %"compiler/source:Span" %t131, i1 true)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb60
bb37:
  %t135 = load ptr, ptr %l1, !tbaa !29
  store ptr %t135, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t136 = load ptr, ptr %l76, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb38, label %bb39
bb38:
  %t139 = load ptr, ptr %l76, !tbaa !29
  %t140 = load i64, ptr %t139, !range !{i64 0, i64 6}
  %t142 = icmp eq i64 %t140, 5
  store i1 %t142, ptr %l77, !tbaa !21
  br label %bb39
bb39:
  %t143 = load i1, ptr %l77, !tbaa !21
  br i1 %t143, label %bb40, label %bb41
bb40:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t146, i32 0, i32 1
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l13, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t152, i32 0, i32 2
  %t154 = load i32, ptr %t153
  store i32 %t154, ptr %l14, !tbaa !23
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr { i64, [4 x i64] }, ptr %t156, i32 0, i32 1
  %t159 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t158, i32 0, i32 3
  %t160 = load %"compiler/source:Span", ptr %t159
  store %"compiler/source:Span" %t160, ptr %l15
  br label %bb42
bb41:
  br label %bb55
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t162, ptr %t163)
  br label %bb43
bb43:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i32, ptr %l14, !tbaa !23
  %t171 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t167, i32 %t168)
  store { i64, ptr } %t171, ptr %l91
  br label %bb44
bb44:
  %t172 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t172, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t173, ptr %l92
  br label %bb45
bb45:
  %t174 = load i1, ptr %l92, !tbaa !21
  %t175 = xor i1 %t174, true
  br i1 %t175, label %bb46, label %bb47
bb46:
  %t177 = load i32, ptr %l14, !tbaa !23
  %t179 = load ptr, ptr %l2, !tbaa !29
  %t183 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t179, i32 %t177)
  store i1 %t183, ptr %l98
  br label %bb48
bb47:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb49
bb48:
  %t184 = load i1, ptr %l98, !tbaa !21
  %t185 = xor i1 %t184, true
  store i1 %t185, ptr %l94, !tbaa !21
  br label %bb49
bb49:
  %t187 = load i1, ptr %l94, !tbaa !21
  br i1 %t187, label %bb50, label %bb51
bb50:
  %t188 = load ptr, ptr %l2, !tbaa !29
  %t189 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t188, i32 %t189)
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i32, ptr %l14, !tbaa !23
  %t194 = load %"compiler/source:Span", ptr %l15
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %t192, i32 %t193, %"compiler/source:Span" %t194, i1 true)
  br label %bb53
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_e5a1f3e08188ecc4_85420485b9e83138)
  unreachable
bb60:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopSig(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 22
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/names:Resolver", ptr %t8, i32 0, i32 25
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l8
  br label %bb3
bb3:
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = icmp eq i64 %t13, 0
  store i1 %t14, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l5, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/names:Resolver", ptr %t17, i32 0, i32 25
  %t21 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t19)
  %t22 = extractvalue { i32, i64 } %t21, 1
  %t23 = extractvalue { i32, i64 } %t21, 0
  store i32 %t23, ptr %l14
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb9, label %ok.25, !prof !99
ok.25:
  store i64 %t22, ptr %l13
  br label %bb8
bb8:
  %t26 = load i64, ptr %l13, !tbaa !24
  store i64 %t26, ptr %l10, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  br label %ret
bb11:
  %t27 = load i64, ptr %l10, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/names:Resolver", ptr %t28, i32 0, i32 24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t30, i64 %t27)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l5 = alloca i64
  %l9 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l12 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l26 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb2
bb2:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, %a1
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/names:Resolver", ptr %t13, i32 0, i32 9
  %t17 = call { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__He0d1b669a6d0fad4ef2d0863356e160c(ptr %v0, ptr %t15)
  %t18 = extractvalue { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } %t17, 1
  %t19 = extractvalue { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } %t17, 0
  store i32 %t19, ptr %l13
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb7, label %ok.21, !prof !99
ok.21:
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t18, ptr %l12
  br label %bb6
bb6:
  %t22 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l12
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t22, ptr %l9
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  br label %ret
bb9:
  %t23 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l9
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t23, ptr %l2
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/names:Resolver", ptr %t25, i32 0, i32 8
  %t28 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t32 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t27, i32 %t29)
  %t33 = extractvalue { i32, i64 } %t32, 1
  %t34 = extractvalue { i32, i64 } %t32, 0
  store i32 %t34, ptr %l20
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb11, label %ok.36, !prof !99
ok.36:
  store i64 %t33, ptr %l19
  br label %bb10
bb10:
  %t37 = load i64, ptr %l19, !tbaa !24
  store i64 %t37, ptr %l15, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l15, !tbaa !24
  br label %bb13
bb13:
  %t38 = load ptr, ptr %l14, !tbaa !29
  %t39 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ejudge(ptr %v0, ptr %t38, i64 %t39)
  br label %bb14
bb14:
  %t40 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/names:Resolver", ptr %t45, i32 0, i32 8
  %t48 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 0
  %t49 = load i32, ptr %t48, !tbaa !23
  %t52 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H7068c8717e9d582db2941dd2bdd79d55(ptr %v0, ptr %t47, i32 %t49)
  store i1 %t52, ptr %l26
  br label %bb17
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/names:Resolver", ptr %t53, i32 0, i32 8
  %t56 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t58 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l2, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t55, i32 %t57, i64 %t59)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb1
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epushSig(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i64
  %l22 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 22
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/names:Resolver", ptr %t8, i32 0, i32 25
  store ptr %t10, ptr %l10, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/names:Resolver", ptr %t11, i32 0, i32 24
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l10, !tbaa !29
  %t17 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t16, i64 %t17)
  br label %bb5
bb5:
  %t20 = getelementptr %"compiler/ast:Sig", ptr %a1, i32 0, i32 3
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l22, !tbaa !27
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 %t36
  %t41 = load ptr, ptr %t40, !tbaa !39
  store ptr %t41, ptr %l5, !tbaa !29
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Path", ptr %t43, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t50 = icmp eq i64 %t48, 1
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/names:Resolver", ptr %t52, i32 0, i32 24
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Path", ptr %t55, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l32, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 0
  %t62 = load i32, ptr %t61, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t54, i32 %t62)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l3, !tbaa !24
  br label %bb6
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedErrors(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca i1
  %l27 = alloca i64
  %l30 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca %"compiler/names:raisedName"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %t7)
  store ptr %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l12, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/load:Module", ptr %t12, i32 0, i32 3
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb4
bb3:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = getelementptr %"compiler/load:Module", ptr %t17, i32 0, i32 30
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l15, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l15, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t27 = icmp eq i64 %t25, 0
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyBodies(ptr %v0, ptr %v1, ptr %t30, i64 %t31, { i64, ptr } %t32)
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/names:Resolver", ptr %t36, i32 0, i32 23
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eLen_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l27
  br label %bb12
bb12:
  %t41 = load i64, ptr %l27, !tbaa !24
  %t42 = icmp eq i64 %t41, 0
  br i1 %t42, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efirstRaises(ptr %v0, ptr %s0, ptr %t44)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l30
  br label %bb16
bb16:
  %t47 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l4
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRaised(ptr %v0, ptr %s0, ptr %t48, i64 %t49, ptr %l4)
  br label %bb17
bb17:
  store ptr %l4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t54 = load i64, ptr %l6, !tbaa !24
  store i64 %t54, ptr %l35, !tbaa !24
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eLen_H9e36587759e47da85a29e6c0abff1d1c(ptr %s0, ptr %t55)
  store i64 %t57, ptr %l37
  br label %bb19
bb19:
  %t58 = load i64, ptr %l35, !tbaa !24
  %t59 = load i64, ptr %l37, !tbaa !24
  %t60 = icmp slt i64 %t58, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  br label %bb22
bb22:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = call %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %s0, ptr %t64, i64 %t65)
  store %"compiler/names:raisedName" %t68, ptr %l42
  br label %bb23
bb23:
  %t69 = load %"compiler/names:raisedName", ptr %l42
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enearRaise(ptr %v0, ptr %s0, ptr %t70, i64 %t71, %"compiler/names:raisedName" %t69, ptr %l4)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb18
bb26:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/names:Resolver", ptr %t81, i32 0, i32 23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eClear_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %t83)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb3:
  call void @__olang_check_failed(ptr @olang_loc_c86ac2e057a115e0_329ff77132980ab4)
  unreachable
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopBranch", ptr %t17, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp sgt i64 %t23, 0
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %l19, !tbaa !24
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TopIf", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c86ac2e057a115e0_329ff77132980ab4)
  unreachable
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t45 = load ptr, ptr %l18, !tbaa !29
  %t46 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedErrors(ptr %v0, ptr %v1, ptr %t45, i64 %t46, { i64, ptr } %t44)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TopIf", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  store i64 %t58, ptr %l32, !tbaa !24
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TopIf", ptr %t59, i32 0, i32 2
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb16, label %bb17
bb15:
  br label %bb20
bb16:
  call void @__olang_check_failed(ptr @olang_loc_67ada16116fb12ff_65bccde789f31043)
  unreachable
bb17:
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/ast:TopIf", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  %t74 = load ptr, ptr %l31, !tbaa !29
  %t75 = load i64, ptr %l32, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedIf(ptr %v0, ptr %v1, ptr %t74, i64 %t75, ptr %t69, i64 %t70, i64 %t73)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr %"compiler/ast:TopIf", ptr %t79, i32 0, i32 3
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t89 = load i64, ptr %l4, !tbaa !24
  %t91 = add i64 %t89, 1
  %t94 = icmp eq i64 %t88, %t91
  store i1 %t94, ptr %l45, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t96 = load i1, ptr %l45, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l50, !tbaa !29
  %t98 = load i64, ptr %l1, !tbaa !24
  store i64 %t98, ptr %l51, !tbaa !24
  %t99 = load ptr, ptr %l2, !tbaa !29
  %t101 = getelementptr %"compiler/ast:TopIf", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  call void @__olang_check_failed(ptr @olang_loc_6b96fe1cf5244e4e_c67e94ae0baa20c2)
  unreachable
bb27:
  br label %bb28
bb28:
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t108 = getelementptr %"compiler/ast:TopIf", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t112 = getelementptr %"compiler/ast:TopBranch", ptr %t109, i32 0, i32 1
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t114 = load ptr, ptr %l50, !tbaa !29
  %t115 = load i64, ptr %l51, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedErrors(ptr %v0, ptr %v1, ptr %t114, i64 %t115, { i64, ptr } %t113)
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eread(ptr %v0, ptr %a0, %"compiler/names:Ref" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/names:Ref"
  %l2 = alloca %"compiler/names:local"
  %l6 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i64
  %l13 = alloca i64
  %l18 = alloca %"compiler/names:local"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l28 = alloca %"compiler/names:local"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/names:Ref" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/names:Ref", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 9}
  %t4 = trunc i64 1 to i32
  %t5 = icmp eq i32 %t2, %t4
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t9 = getelementptr %"compiler/names:Ref", ptr %l1, i32 0, i32 2
  %t10 = load i64, ptr %t9, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb5:
  %t15 = getelementptr %"compiler/names:Ref", ptr %l1, i32 0, i32 2
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l10, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/names:Resolver", ptr %t17, i32 0, i32 7
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = load i64, ptr %l13, !tbaa !24
  %t24 = icmp sge i64 %t22, %t23
  store i1 %t24, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l9, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 7
  %t30 = getelementptr %"compiler/names:Ref", ptr %l1, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t34 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t29, i64 %t31)
  store %"compiler/names:local" %t34, ptr %l18
  br label %bb11
bb11:
  %t35 = load %"compiler/names:local", ptr %l18
  store %"compiler/names:local" %t35, ptr %l2
  %t36 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 5
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/names:Resolver", ptr %t39, i32 0, i32 7
  store ptr %t41, ptr %l21, !tbaa !29
  %t42 = getelementptr %"compiler/names:Ref", ptr %l1, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l22, !tbaa !24
  %t44 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 1
  %t47 = load %"compiler/source:Span", ptr %t46
  %t48 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 2
  %t49 = load i32, ptr %t48, !range !{i32 0, i32 9}
  %t50 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 3
  %t51 = load i1, ptr %t50, !tbaa !21
  %t52 = getelementptr %"compiler/names:local", ptr %l2, i32 0, i32 4
  %t53 = load i1, ptr %t52, !tbaa !21
  %t59 = call %"compiler/names:local" @compiler_2fnames_3alocal_2ector(ptr %s0, i32 %t45, %"compiler/source:Span" %t47, i32 %t49, i1 %t51, i1 %t53, i1 true)
  store %"compiler/names:local" %t59, ptr %l28
  br label %bb15
bb15:
  %t60 = load ptr, ptr %l21, !tbaa !29
  %t61 = load i64, ptr %l22, !tbaa !24
  %t62 = load %"compiler/names:local", ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eSetAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t60, i64 %t61, %"compiler/names:local" %t62)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l40 = alloca i64
  %l43 = alloca i64
  %l61 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca i1
  %l77 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l87 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i32
  %l95 = alloca i1
  %l99 = alloca %"compiler/names:local"
  %l104 = alloca i1
  %l109 = alloca %"compiler/names:Ref"
  %l118 = alloca ptr
  %l119 = alloca i1
  %l131 = alloca i1
  %l135 = alloca { i64, ptr }
  %l137 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i32
  %l145 = alloca i1
  %l149 = alloca %"compiler/names:local"
  %l154 = alloca i1
  %l159 = alloca %"compiler/names:Ref"
  %l173 = alloca ptr
  %l174 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca i1
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t6 = load ptr, ptr %l29, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l29, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 7}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l30, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l30, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t16, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  br label %bb8
bb7:
  br label %bb87
bb8:
  store i64 0, ptr %l4, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb14
bb11:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l43, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb13
bb13:
  %t50 = load i64, ptr %l43, !tbaa !24
  store i64 %t50, ptr %l40, !tbaa !24
  br label %bb14
bb14:
  %t51 = load i64, ptr %l40, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb16, label %bb17
bb16:
  br label %bb86
bb17:
  br label %bb18
bb18:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l61, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 %t68
  %t76 = load ptr, ptr %t75, !tbaa !39
  store ptr %t76, ptr %l10, !tbaa !29
  %t78 = load ptr, ptr %l10, !tbaa !29
  store ptr %t78, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t79 = load ptr, ptr %l64, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t82 = load ptr, ptr %l64, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 7}
  %t85 = icmp eq i64 %t83, 6
  store i1 %t85, ptr %l65, !tbaa !21
  br label %bb20
bb20:
  %t86 = load i1, ptr %l65, !tbaa !21
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t87 = load ptr, ptr %l10, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t89, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90
  store { i64, ptr } %t91, ptr %l11, !tbaa !27
  br label %bb23
bb22:
  br label %bb49
bb23:
  %t93 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t93, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l14, !tbaa !24
  br label %bb24
bb24:
  %t99 = load i64, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l14, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb25, label %bb26
bb25:
  br label %bb48
bb26:
  br label %bb27
bb27:
  %t107 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t107, ptr %l77, !tbaa !27
  %t108 = load i64, ptr %l13, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr ptr, ptr %t111, i64 %t108
  %t113 = load ptr, ptr %t112, !tbaa !39
  store ptr %t113, ptr %l15, !tbaa !29
  %t115 = load ptr, ptr %l15, !tbaa !29
  %t117 = getelementptr %"compiler/ast:Path", ptr %t115, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t122 = icmp ne i64 %t120, 1
  br i1 %t122, label %bb28, label %bb29
bb28:
  br label %bb47
bb29:
  br label %bb30
bb30:
  %t124 = load ptr, ptr %l15, !tbaa !29
  %t126 = getelementptr %"compiler/ast:Path", ptr %t124, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l85, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i32, ptr %t129, i64 0
  %t131 = load i32, ptr %t130, !tbaa !33
  store i32 %t131, ptr %l16, !tbaa !23
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/names:Resolver", ptr %t133, i32 0, i32 8
  %t136 = load i32, ptr %l16, !tbaa !23
  %t139 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t135, i32 %t136)
  %t140 = extractvalue { i32, i64 } %t139, 1
  %t141 = extractvalue { i32, i64 } %t139, 0
  store i32 %t141, ptr %l92
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb32, label %ok.143, !prof !99
ok.143:
  store i64 %t140, ptr %l91
  br label %bb31
bb31:
  %t144 = load i64, ptr %l91, !tbaa !24
  store i64 %t144, ptr %l87, !tbaa !24
  br label %bb34
bb32:
  br label %bb33
bb33:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l87, !tbaa !24
  br label %bb34
bb34:
  %t145 = load i64, ptr %l87, !tbaa !24
  store i64 %t145, ptr %l17, !tbaa !24
  %t146 = load i64, ptr %l17, !tbaa !24
  %t148 = icmp sge i64 %t146, 0
  br i1 %t148, label %bb35, label %bb36
bb35:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/names:Resolver", ptr %t150, i32 0, i32 7
  %t153 = load i64, ptr %l17, !tbaa !24
  %t156 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t152, i64 %t153)
  store %"compiler/names:local" %t156, ptr %l99
  br label %bb37
bb36:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb38
bb37:
  %t157 = getelementptr %"compiler/names:local", ptr %l99, i32 0, i32 2
  %t158 = load i32, ptr %t157, !range !{i32 0, i32 9}
  %t160 = trunc i64 8 to i32
  %t161 = icmp eq i32 %t158, %t160
  store i1 %t161, ptr %l95, !tbaa !21
  br label %bb38
bb38:
  %t163 = load i1, ptr %l95, !tbaa !21
  %t166 = xor i1 %t163, true
  br i1 %t166, label %bb39, label %bb40
bb39:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/names:Resolver", ptr %t169, i32 0, i32 6
  %t172 = load i64, ptr %t171, !tbaa !24
  %t173 = load i32, ptr %l16, !tbaa !23
  %t177 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeIn(ptr %v0, ptr %t168, i64 %t172, i32 %t173)
  store %"compiler/names:Ref" %t177, ptr %l109
  br label %bb41
bb40:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb42
bb41:
  %t178 = getelementptr %"compiler/names:Ref", ptr %l109, i32 0, i32 0
  %t179 = load i32, ptr %t178, !range !{i32 0, i32 9}
  %t181 = trunc i64 0 to i32
  %t182 = icmp eq i32 %t179, %t181
  store i1 %t182, ptr %l104, !tbaa !21
  br label %bb42
bb42:
  %t184 = load i1, ptr %l104, !tbaa !21
  br i1 %t184, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l15, !tbaa !29
  %t188 = getelementptr %"compiler/ast:Path", ptr %t186, i32 0, i32 0
  %t189 = load %"compiler/source:Span", ptr %t188
  %t190 = load i32, ptr %l16, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eintroduce(ptr %v0, ptr %s9, ptr %t185, %"compiler/source:Span" %t189, i32 %t190, ptr null)
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t194 = load i64, ptr %l13, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l13, !tbaa !24
  br label %bb24
bb48:
  br label %bb84
bb49:
  %t198 = load ptr, ptr %l10, !tbaa !29
  store ptr %t198, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t199 = load ptr, ptr %l118, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb50, label %bb51
bb50:
  %t202 = load ptr, ptr %l118, !tbaa !29
  %t203 = load i64, ptr %t202, !range !{i64 0, i64 7}
  %t205 = icmp eq i64 %t203, 0
  store i1 %t205, ptr %l119, !tbaa !21
  br label %bb51
bb51:
  %t206 = load i1, ptr %l119, !tbaa !21
  br i1 %t206, label %bb52, label %bb53
bb52:
  %t207 = load ptr, ptr %l10, !tbaa !29
  %t209 = getelementptr { i64, [5 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t209, i32 0, i32 0
  %t211 = load %"compiler/source:Span", ptr %t210
  store %"compiler/source:Span" %t211, ptr %l19
  %t213 = load ptr, ptr %l10, !tbaa !29
  %t215 = getelementptr { i64, [5 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t215, i32 0, i32 1
  %t217 = load { i64, ptr }, ptr %t216
  store { i64, ptr } %t217, ptr %l20, !tbaa !27
  %t219 = load ptr, ptr %l10, !tbaa !29
  %t221 = getelementptr { i64, [5 x i64] }, ptr %t219, i32 0, i32 1
  %t222 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t221, i32 0, i32 2
  %t223 = load { i64, ptr }, ptr %t222
  store { i64, ptr } %t223, ptr %l21, !tbaa !27
  br label %bb54
bb53:
  br label %bb78
bb54:
  %t225 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t229 = icmp eq i64 %t227, 1
  br i1 %t229, label %bb55, label %bb56
bb55:
  %t231 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t235 = icmp eq i64 %t233, 0
  store i1 %t235, ptr %l131, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb57
bb57:
  %t237 = load i1, ptr %l131, !tbaa !21
  br i1 %t237, label %bb58, label %bb59
bb58:
  %t238 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t238, ptr %l135, !tbaa !27
  %t239 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr i32, ptr %t240, i64 0
  %t242 = load i32, ptr %t241, !tbaa !33
  store i32 %t242, ptr %l22, !tbaa !23
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/names:Resolver", ptr %t244, i32 0, i32 8
  %t247 = load i32, ptr %l22, !tbaa !23
  %t250 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t246, i32 %t247)
  %t251 = extractvalue { i32, i64 } %t250, 1
  %t252 = extractvalue { i32, i64 } %t250, 0
  store i32 %t252, ptr %l142
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb61, label %ok.254, !prof !99
ok.254:
  store i64 %t251, ptr %l141
  br label %bb60
bb59:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t255, ptr %t256, i1 true)
  br label %bb76
bb60:
  %t260 = load i64, ptr %l141, !tbaa !24
  store i64 %t260, ptr %l137, !tbaa !24
  br label %bb63
bb61:
  br label %bb62
bb62:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l137, !tbaa !24
  br label %bb63
bb63:
  %t261 = load i64, ptr %l137, !tbaa !24
  store i64 %t261, ptr %l23, !tbaa !24
  %t262 = load i64, ptr %l23, !tbaa !24
  %t264 = icmp sge i64 %t262, 0
  br i1 %t264, label %bb64, label %bb65
bb64:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/names:Resolver", ptr %t266, i32 0, i32 7
  %t269 = load i64, ptr %l23, !tbaa !24
  %t272 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t268, i64 %t269)
  store %"compiler/names:local" %t272, ptr %l149
  br label %bb66
bb65:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb67
bb66:
  %t273 = getelementptr %"compiler/names:local", ptr %l149, i32 0, i32 2
  %t274 = load i32, ptr %t273, !range !{i32 0, i32 9}
  %t276 = trunc i64 8 to i32
  %t277 = icmp eq i32 %t274, %t276
  store i1 %t277, ptr %l145, !tbaa !21
  br label %bb67
bb67:
  %t279 = load i1, ptr %l145, !tbaa !21
  %t282 = xor i1 %t279, true
  br i1 %t282, label %bb68, label %bb69
bb68:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/names:Resolver", ptr %t285, i32 0, i32 6
  %t288 = load i64, ptr %t287, !tbaa !24
  %t289 = load i32, ptr %l22, !tbaa !23
  %t293 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeIn(ptr %v0, ptr %t284, i64 %t288, i32 %t289)
  store %"compiler/names:Ref" %t293, ptr %l159
  br label %bb70
bb69:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb71
bb70:
  %t294 = getelementptr %"compiler/names:Ref", ptr %l159, i32 0, i32 0
  %t295 = load i32, ptr %t294, !range !{i32 0, i32 9}
  %t297 = trunc i64 0 to i32
  %t298 = icmp eq i32 %t295, %t297
  store i1 %t298, ptr %l154, !tbaa !21
  br label %bb71
bb71:
  %t300 = load i1, ptr %l154, !tbaa !21
  br i1 %t300, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s13
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l19
  %t303 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eintroduce(ptr %v0, ptr %s13, ptr %t301, %"compiler/source:Span" %t302, i32 %t303, ptr null)
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  br label %bb84
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t307, ptr %t308, i1 true)
  br label %bb82
bb82:
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_1bcb50306faa07e3_18a30ea25b6c39c7)
  unreachable
bb84:
  br label %bb85
bb85:
  %t312 = load i64, ptr %l8, !tbaa !24
  %t314 = add i64 %t312, 1
  store i64 %t314, ptr %l8, !tbaa !24
  br label %bb15
bb86:
  br label %bb106
bb87:
  %t316 = load ptr, ptr %l1, !tbaa !29
  store ptr %t316, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t317 = load ptr, ptr %l173, !tbaa !29
  %t318 = icmp ne ptr %t317, null
  br i1 %t318, label %bb88, label %bb89
bb88:
  %t320 = load ptr, ptr %l173, !tbaa !29
  %t321 = load i64, ptr %t320, !range !{i64 0, i64 7}
  %t323 = icmp eq i64 %t321, 3
  store i1 %t323, ptr %l174, !tbaa !21
  br label %bb89
bb89:
  %t324 = load i1, ptr %l174, !tbaa !21
  br i1 %t324, label %bb90, label %bb91
bb90:
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr { i64, [5 x i64] }, ptr %t325, i32 0, i32 1
  %t328 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t327, i32 0, i32 1
  %t329 = load ptr, ptr %t328
  store ptr %t329, ptr %l25, !tbaa !29
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l25, !tbaa !29
  %t334 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t331, ptr %t332, i1 %t334)
  br label %bb93
bb93:
  br label %bb106
bb94:
  %t338 = load ptr, ptr %l1, !tbaa !29
  store ptr %t338, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t339 = load ptr, ptr %l183, !tbaa !29
  %t340 = icmp ne ptr %t339, null
  br i1 %t340, label %bb95, label %bb96
bb95:
  %t342 = load ptr, ptr %l183, !tbaa !29
  %t343 = load i64, ptr %t342, !range !{i64 0, i64 7}
  %t345 = icmp eq i64 %t343, 4
  store i1 %t345, ptr %l184, !tbaa !21
  br label %bb96
bb96:
  %t346 = load i1, ptr %l184, !tbaa !21
  br i1 %t346, label %bb97, label %bb98
bb97:
  %t347 = load ptr, ptr %l1, !tbaa !29
  %t349 = getelementptr { i64, [5 x i64] }, ptr %t347, i32 0, i32 1
  %t350 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t349, i32 0, i32 1
  %t351 = load ptr, ptr %t350
  store ptr %t351, ptr %l26, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load ptr, ptr %l26, !tbaa !29
  %t355 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t353, ptr %t354, i1 %t355)
  br label %bb100
bb100:
  br label %bb106
bb101:
  br i1 true, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_7fa72c55361929e2_2d15b450a98c4566)
  unreachable
bb106:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/names:Ref" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/names:Ref"
  %l6 = alloca i1
  %l11 = alloca ptr
  %l17 = alloca ptr
  %l21 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/names:Ref" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/names:Ref", ptr %l2, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 9}
  %t4 = trunc i64 0 to i32
  %t5 = icmp eq i32 %t2, %t4
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 22
  %t12 = load i1, ptr %t11, !tbaa !21
  %t14 = xor i1 %t12, true
  store i1 %t14, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l6, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/names:Resolver", ptr %t17, i32 0, i32 4
  store ptr %t19, ptr %l11, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/names:Resolver", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/load:Loader", ptr %t23, i32 0, i32 5
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/names:Resolver", ptr %t26, i32 0, i32 6
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t25, i64 %t29)
  store ptr %t32, ptr %l17
  br label %bb6
bb5:
  br label %bb9
bb6:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t35 = getelementptr %"compiler/load:Module", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  %t41 = call i64 @compiler_2fnames_2ekey(i64 %t36, i32 %t38)
  store i64 %t41, ptr %l21
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l2
  %t43 = load ptr, ptr %l11, !tbaa !29
  %t44 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t43, i64 %t44, %"compiler/names:Ref" %t42)
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l33 = alloca i1
  %l43 = alloca ptr
  %l51 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l135 = alloca i1
  %l144 = alloca ptr
  %l159 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Func", ptr %t7, i32 0, i32 5
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeParams(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t10)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Func", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb4, label %bb5
bb3:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb7
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f7af4f17da675e9e_7adee505b4454aba)
  unreachable
bb5:
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Param", ptr %t32, i32 0, i32 2
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  store i1 %t40, ptr %l33, !tbaa !21
  br label %bb7
bb7:
  %t42 = load i1, ptr %l33, !tbaa !21
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l43, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = icmp eq ptr %t47, null
  br i1 %t49, label %bb10, label %bb11
bb9:
  br label %bb18
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4b15e456fcf3a345_7adab712aa943e41)
  unreachable
bb11:
  br label %bb12
bb12:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Func", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Param", ptr %t54, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t59, ptr %t58, i1 false)
  br label %bb13
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l51, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Func", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_2e22b0ea443c0bf0_cc72b894f0b6250c)
  unreachable
bb15:
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Func", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Param", ptr %t72, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t77, ptr %t76)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Sig", ptr %t79, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l6, !tbaa !24
  br label %bb19
bb19:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb20, label %bb21
bb20:
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t96, ptr %l67, !tbaa !27
  %t97 = load i64, ptr %l5, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  store ptr %t102, ptr %l7, !tbaa !29
  %t104 = load ptr, ptr %l7, !tbaa !29
  %t106 = getelementptr %"compiler/ast:Param", ptr %t104, i32 0, i32 2
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = icmp eq ptr %t107, null
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb23, label %bb24
bb23:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l7, !tbaa !29
  %t116 = getelementptr %"compiler/ast:Param", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %t116, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t113, ptr %t117)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l5, !tbaa !24
  br label %bb19
bb28:
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t126 = getelementptr %"compiler/ast:Sig", ptr %t124, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  store i64 %t131, ptr %l10, !tbaa !24
  br label %bb29
bb29:
  %t133 = load i64, ptr %l9, !tbaa !24
  %t134 = load i64, ptr %l10, !tbaa !24
  %t137 = icmp slt i64 %t133, %t134
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb30, label %bb31
bb30:
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t141 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t141, ptr %l87, !tbaa !27
  %t142 = load i64, ptr %l9, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr ptr, ptr %t145, i64 %t142
  %t147 = load ptr, ptr %t146, !tbaa !39
  %t149 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t149, ptr %t147)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t154 = load i64, ptr %l9, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l9, !tbaa !24
  br label %bb29
bb35:
  %t158 = load ptr, ptr %l3, !tbaa !29
  %t160 = getelementptr %"compiler/ast:Sig", ptr %t158, i32 0, i32 3
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  store i64 %t165, ptr %l14, !tbaa !24
  br label %bb36
bb36:
  %t167 = load i64, ptr %l13, !tbaa !24
  %t168 = load i64, ptr %l14, !tbaa !24
  %t171 = icmp slt i64 %t167, %t168
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb37, label %bb38
bb37:
  br label %bb42
bb38:
  br label %bb39
bb39:
  %t175 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t175, ptr %l103, !tbaa !27
  %t176 = load i64, ptr %l13, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr ptr, ptr %t179, i64 %t176
  %t181 = load ptr, ptr %t180, !tbaa !39
  %t183 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t183, ptr %t181)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t188 = load i64, ptr %l13, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l13, !tbaa !24
  br label %bb36
bb42:
  %t192 = load ptr, ptr %l3, !tbaa !29
  %t194 = getelementptr %"compiler/ast:Sig", ptr %t192, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  store i64 %t199, ptr %l18, !tbaa !24
  br label %bb43
bb43:
  %t201 = load i64, ptr %l17, !tbaa !24
  %t202 = load i64, ptr %l18, !tbaa !24
  %t205 = icmp slt i64 %t201, %t202
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb44, label %bb45
bb44:
  br label %bb52
bb45:
  br label %bb46
bb46:
  %t209 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t209, ptr %l119, !tbaa !27
  %t210 = load i64, ptr %l17, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr ptr, ptr %t213, i64 %t210
  %t215 = load ptr, ptr %t214, !tbaa !39
  store ptr %t215, ptr %l19, !tbaa !29
  %t217 = load ptr, ptr %l19, !tbaa !29
  %t219 = getelementptr %"compiler/ast:Param", ptr %t217, i32 0, i32 3
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = icmp eq ptr %t220, null
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb47, label %bb48
bb47:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load ptr, ptr %l19, !tbaa !29
  %t229 = getelementptr %"compiler/ast:Param", ptr %t227, i32 0, i32 3
  %t230 = load ptr, ptr %t229, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t226, ptr %t230)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t233 = load i64, ptr %l17, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l17, !tbaa !24
  br label %bb43
bb52:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr %"compiler/ast:Func", ptr %t237, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = icmp eq ptr %t240, null
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb53, label %bb54
bb53:
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr %"compiler/ast:Func", ptr %t246, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = icmp eq ptr %t249, null
  br i1 %t251, label %bb55, label %bb56
bb54:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb58
bb55:
  call void @__olang_check_failed(ptr @olang_loc_668f2e502e7138cf_4506733ced80a77b)
  unreachable
bb56:
  br label %bb57
bb57:
  %t253 = load ptr, ptr %l1, !tbaa !29
  %t255 = getelementptr %"compiler/ast:Func", ptr %t253, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t259 = getelementptr %"compiler/ast:Param", ptr %t256, i32 0, i32 1
  %t260 = load i32, ptr %t259, !tbaa !23
  %t262 = icmp ne i32 %t260, 0
  store i1 %t262, ptr %l135, !tbaa !21
  br label %bb58
bb58:
  %t264 = load i1, ptr %l135, !tbaa !21
  br i1 %t264, label %bb59, label %bb60
bb59:
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l144, !tbaa !29
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t268 = getelementptr %"compiler/ast:Func", ptr %t266, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t271 = icmp eq ptr %t269, null
  br i1 %t271, label %bb61, label %bb62
bb60:
  br label %bb65
bb61:
  call void @__olang_check_failed(ptr @olang_loc_668f2e502e7138cf_4506733ced80a77b)
  unreachable
bb62:
  br label %bb63
bb63:
  %t273 = load ptr, ptr %l1, !tbaa !29
  %t275 = getelementptr %"compiler/ast:Func", ptr %t273, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t277 = load i1, ptr %l2, !tbaa !21
  %t278 = load ptr, ptr %l144, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %t278, ptr %t276, i1 %t277)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t281 = load ptr, ptr %l3, !tbaa !29
  %t283 = getelementptr %"compiler/ast:Sig", ptr %t281, i32 0, i32 0
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  store { i64, ptr } %t284, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t286 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t286, 0
  store i64 %t288, ptr %l22, !tbaa !24
  br label %bb66
bb66:
  %t290 = load i64, ptr %l21, !tbaa !24
  %t291 = load i64, ptr %l22, !tbaa !24
  %t294 = icmp slt i64 %t290, %t291
  %t296 = xor i1 %t294, true
  br i1 %t296, label %bb67, label %bb68
bb67:
  br label %bb72
bb68:
  br label %bb69
bb69:
  %t298 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t298, ptr %l159, !tbaa !27
  %t299 = load i64, ptr %l21, !tbaa !24
  %t301 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr ptr, ptr %t302, i64 %t299
  %t304 = load ptr, ptr %t303, !tbaa !39
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %t306, ptr %t304, i1 %t308)
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t312 = load i64, ptr %l21, !tbaa !24
  %t314 = add i64 %t312, 1
  store i64 %t314, ptr %l21, !tbaa !24
  br label %bb66
bb72:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l17 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 6
  store i64 %a1, ptr %t5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eClear_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t8)
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/names:Resolver", ptr %t10, i32 0, i32 8
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hb7e448baed1c9668005f7dc6325e5707(ptr %v0, ptr %t12)
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/names:Resolver", ptr %t14, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H263d9150b58237aac70cb39b886b10bb(ptr %v0, ptr %t16)
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eClear_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t20)
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/names:Resolver", ptr %t22, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eClear_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t24)
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/names:Resolver", ptr %t26, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t28)
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 12
  store i1 false, ptr %t32, !tbaa !21
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l17, !tbaa !29
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = getelementptr %"compiler/names:Resolver", ptr %t34, i32 0, i32 14
  %t36 = load i64, ptr %t35, !tbaa !24
  %t38 = add i64 %t36, 1
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 14
  store i64 %t38, ptr %t41, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l79 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i1
  %l112 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l132 = alloca i1
  %l141 = alloca i1
  %l144 = alloca { i64, ptr }
  %l145 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca i1
  %l172 = alloca ptr
  %l173 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i1
  %l201 = alloca ptr
  %l202 = alloca i1
  %l214 = alloca ptr
  %l215 = alloca i1
  %l221 = alloca i64
  %l242 = alloca ptr
  %l243 = alloca i1
  %l255 = alloca i64
  %l270 = alloca ptr
  %l271 = alloca i1
  %l283 = alloca ptr
  %l284 = alloca i1
  %l291 = alloca ptr
  %l292 = alloca i1
  %l304 = alloca { i64, ptr }
  %l312 = alloca ptr
  %l313 = alloca i1
  %l318 = alloca ptr
  %l319 = alloca i1
  %l327 = alloca ptr
  %l328 = alloca i1
  %l344 = alloca ptr
  %l345 = alloca i1
  %l356 = alloca ptr
  %l357 = alloca i1
  %l368 = alloca ptr
  %l369 = alloca i1
  %l383 = alloca { i64, ptr }
  %l393 = alloca ptr
  %l394 = alloca i1
  %l405 = alloca ptr
  %l406 = alloca i1
  %l412 = alloca i64
  %l418 = alloca ptr
  %l419 = alloca i1
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t6 = load ptr, ptr %l55, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l55, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l56, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l56, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb33
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  store ptr %t20, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t21 = load ptr, ptr %l61, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb9, label %bb10
bb9:
  %t24 = load ptr, ptr %l61, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 29}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l62, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l62, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 1
  %t33 = load i32, ptr %t32, !range !{i32 0, i32 96}
  store i32 %t33, ptr %l3
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l4, !tbaa !29
  br label %bb17
bb12:
  %t41 = load ptr, ptr %l2, !tbaa !29
  store ptr %t41, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t42 = load ptr, ptr %l69, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = load ptr, ptr %l69, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 29}
  %t48 = icmp eq i64 %t46, 4
  store i1 %t48, ptr %l70, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l70, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t52, i32 0, i32 1
  %t54 = load i32, ptr %t53, !range !{i32 0, i32 96}
  store i32 %t54, ptr %l3
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb26
bb17:
  %t62 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t64 = trunc i64 74 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb20
bb19:
  %t67 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t69 = trunc i64 75 to i32
  %t70 = icmp eq i32 %t67, %t69
  store i1 %t70, ptr %l79, !tbaa !21
  br label %bb20
bb20:
  %t72 = load i1, ptr %l79, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %t73, ptr %t74)
  br label %bb23
bb22:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t77, ptr %t78)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb32
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  br label %bb30
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_6855615fe1bb2138_9d7c9db084b0e41c)
  unreachable
bb32:
  br label %bb263
bb33:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t88 = load ptr, ptr %l90, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb34, label %bb35
bb34:
  %t91 = load ptr, ptr %l90, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 22}
  %t94 = icmp eq i64 %t92, 1
  store i1 %t94, ptr %l91, !tbaa !21
  br label %bb35
bb35:
  %t95 = load i1, ptr %l91, !tbaa !21
  br i1 %t95, label %bb36, label %bb37
bb36:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l5, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2evarDecl(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  br label %bb39
bb39:
  br label %bb263
bb40:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t107 = load ptr, ptr %l98, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb41, label %bb42
bb41:
  %t110 = load ptr, ptr %l98, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 22}
  %t113 = icmp eq i64 %t111, 2
  store i1 %t113, ptr %l99, !tbaa !21
  br label %bb42
bb42:
  %t114 = load i1, ptr %l99, !tbaa !21
  br i1 %t114, label %bb43, label %bb44
bb43:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", ptr }, ptr %t117, i32 0, i32 1
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l6, !tbaa !29
  br label %bb45
bb44:
  br label %bb84
bb45:
  %t121 = load ptr, ptr %l6, !tbaa !29
  %t123 = getelementptr %"compiler/ast:Multi", ptr %t121, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l9, !tbaa !24
  br label %bb46
bb46:
  %t130 = load i64, ptr %l8, !tbaa !24
  %t131 = load i64, ptr %l9, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb47, label %bb48
bb47:
  br label %bb52
bb48:
  br label %bb49
bb49:
  %t138 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t138, ptr %l112, !tbaa !27
  %t139 = load i64, ptr %l8, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr ptr, ptr %t142, i64 %t139
  %t144 = load ptr, ptr %t143, !tbaa !39
  %t146 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t146, ptr %t144)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t151 = load i64, ptr %l8, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l8, !tbaa !24
  br label %bb46
bb52:
  %t155 = load ptr, ptr %l6, !tbaa !29
  %t157 = getelementptr %"compiler/ast:Multi", ptr %t155, i32 0, i32 0
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  store { i64, ptr } %t158, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  store i64 %t162, ptr %l13, !tbaa !24
  br label %bb53
bb53:
  %t164 = load i64, ptr %l12, !tbaa !24
  %t165 = load i64, ptr %l13, !tbaa !24
  %t168 = icmp slt i64 %t164, %t165
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb54, label %bb55
bb54:
  br label %bb83
bb55:
  br label %bb56
bb56:
  %t172 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t172, ptr %l128, !tbaa !27
  %t173 = load i64, ptr %l12, !tbaa !24
  %t175 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr ptr, ptr %t176, i64 %t173
  %t178 = load ptr, ptr %t177, !tbaa !39
  store ptr %t178, ptr %l14, !tbaa !29
  %t180 = load ptr, ptr %l14, !tbaa !29
  store ptr %t180, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t181 = load ptr, ptr %l131, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb57, label %bb58
bb57:
  %t184 = load ptr, ptr %l131, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 29}
  %t187 = icmp eq i64 %t185, 0
  store i1 %t187, ptr %l132, !tbaa !21
  br label %bb58
bb58:
  %t188 = load i1, ptr %l132, !tbaa !21
  br i1 %t188, label %bb59, label %bb60
bb59:
  %t189 = load ptr, ptr %l14, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", i32 }, ptr %t191, i32 0, i32 0
  %t193 = load %"compiler/source:Span", ptr %t192
  store %"compiler/source:Span" %t193, ptr %l15
  %t195 = load ptr, ptr %l14, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32 }, ptr %t197, i32 0, i32 1
  %t199 = load i32, ptr %t198
  store i32 %t199, ptr %l16, !tbaa !23
  br label %bb61
bb60:
  br label %bb75
bb61:
  store %olang.scope zeroinitializer, ptr %s14
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t203 = getelementptr %"compiler/ast:Multi", ptr %t201, i32 0, i32 1
  %t204 = load i1, ptr %t203, !tbaa !21
  br i1 %t204, label %bb62, label %bb63
bb62:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i32, ptr %l16, !tbaa !23
  %t210 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t206, i32 %t207)
  store { i64, ptr } %t210, ptr %l144
  br label %bb64
bb63:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb66
bb64:
  %t211 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t212 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s14, { i64, ptr } %t211, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t212, ptr %l145
  br label %bb65
bb65:
  %t213 = load i1, ptr %l145, !tbaa !21
  %t214 = xor i1 %t213, true
  store i1 %t214, ptr %l141, !tbaa !21
  br label %bb66
bb66:
  %t216 = load i1, ptr %l141, !tbaa !21
  br i1 %t216, label %bb67, label %bb68
bb67:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l16, !tbaa !23
  %t219 = load %"compiler/source:Span", ptr %l15
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %t217, i32 %t218, %"compiler/source:Span" %t219, i1 true)
  br label %bb69
bb68:
  %t223 = load ptr, ptr %l6, !tbaa !29
  %t225 = getelementptr %"compiler/ast:Multi", ptr %t223, i32 0, i32 1
  %t226 = load i1, ptr %t225, !tbaa !21
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb70, label %bb71
bb69:
  br label %bb74
bb70:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %t230, ptr %t231)
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s14)
  br label %bb81
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %t234, ptr %t235)
  br label %bb79
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_6dda337cc9644709_4e0ee1c3f9c7cc4d)
  unreachable
bb81:
  br label %bb82
bb82:
  %t238 = load i64, ptr %l12, !tbaa !24
  %t240 = add i64 %t238, 1
  store i64 %t240, ptr %l12, !tbaa !24
  br label %bb53
bb83:
  br label %bb263
bb84:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l159, !tbaa !29
  store i1 false, ptr %l160, !tbaa !21
  %t243 = load ptr, ptr %l159, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb85, label %bb86
bb85:
  %t246 = load ptr, ptr %l159, !tbaa !29
  %t247 = load i64, ptr %t246, !range !{i64 0, i64 22}
  %t249 = icmp eq i64 %t247, 3
  store i1 %t249, ptr %l160, !tbaa !21
  br label %bb86
bb86:
  %t250 = load i1, ptr %l160, !tbaa !21
  br i1 %t250, label %bb87, label %bb88
bb87:
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t253, i32 0, i32 2
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l17, !tbaa !29
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t259, i32 0, i32 3
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l18, !tbaa !29
  br label %bb89
bb88:
  br label %bb92
bb89:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %t263, ptr %t264)
  br label %bb90
bb90:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t267, ptr %t268)
  br label %bb91
bb91:
  br label %bb263
bb92:
  %t272 = load ptr, ptr %l1, !tbaa !29
  store ptr %t272, ptr %l172, !tbaa !29
  store i1 false, ptr %l173, !tbaa !21
  %t273 = load ptr, ptr %l172, !tbaa !29
  %t274 = icmp ne ptr %t273, null
  br i1 %t274, label %bb93, label %bb94
bb93:
  %t276 = load ptr, ptr %l172, !tbaa !29
  %t277 = load i64, ptr %t276, !range !{i64 0, i64 22}
  %t279 = icmp eq i64 %t277, 4
  store i1 %t279, ptr %l173, !tbaa !21
  br label %bb94
bb94:
  %t280 = load i1, ptr %l173, !tbaa !21
  br i1 %t280, label %bb95, label %bb96
bb95:
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr { i64, [4 x i64] }, ptr %t281, i32 0, i32 1
  %t284 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t283, i32 0, i32 1
  %t285 = load ptr, ptr %t284
  store ptr %t285, ptr %l19, !tbaa !29
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t289, i32 0, i32 2
  %t291 = load { i64, ptr }, ptr %t290
  store { i64, ptr } %t291, ptr %l20, !tbaa !27
  br label %bb97
bb96:
  br label %bb100
bb97:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t293, ptr %t294)
  br label %bb98
bb98:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t298, { i64, ptr } %t299)
  br label %bb99
bb99:
  br label %bb263
bb100:
  %t302 = load ptr, ptr %l1, !tbaa !29
  store ptr %t302, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t303 = load ptr, ptr %l185, !tbaa !29
  %t304 = icmp ne ptr %t303, null
  br i1 %t304, label %bb101, label %bb102
bb101:
  %t306 = load ptr, ptr %l185, !tbaa !29
  %t307 = load i64, ptr %t306, !range !{i64 0, i64 22}
  %t309 = icmp eq i64 %t307, 5
  store i1 %t309, ptr %l186, !tbaa !21
  br label %bb102
bb102:
  %t310 = load i1, ptr %l186, !tbaa !21
  br i1 %t310, label %bb103, label %bb104
bb103:
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t313 = getelementptr { i64, [4 x i64] }, ptr %t311, i32 0, i32 1
  %t314 = getelementptr { %"compiler/source:Span", ptr }, ptr %t313, i32 0, i32 1
  %t315 = load ptr, ptr %t314
  store ptr %t315, ptr %l21, !tbaa !29
  br label %bb105
bb104:
  br label %bb107
bb105:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eifStmt(ptr %v0, ptr %v1, ptr %t317, ptr %t318)
  br label %bb106
bb106:
  br label %bb263
bb107:
  %t321 = load ptr, ptr %l1, !tbaa !29
  store ptr %t321, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t322 = load ptr, ptr %l193, !tbaa !29
  %t323 = icmp ne ptr %t322, null
  br i1 %t323, label %bb108, label %bb109
bb108:
  %t325 = load ptr, ptr %l193, !tbaa !29
  %t326 = load i64, ptr %t325, !range !{i64 0, i64 22}
  %t328 = icmp eq i64 %t326, 6
  store i1 %t328, ptr %l194, !tbaa !21
  br label %bb109
bb109:
  %t329 = load i1, ptr %l194, !tbaa !21
  br i1 %t329, label %bb110, label %bb111
bb110:
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr { i64, [4 x i64] }, ptr %t330, i32 0, i32 1
  %t333 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t332, i32 0, i32 1
  %t334 = load { i64, ptr }, ptr %t333
  store { i64, ptr } %t334, ptr %l22, !tbaa !27
  br label %bb112
bb111:
  br label %bb114
bb112:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t336, { i64, ptr } %t337)
  br label %bb113
bb113:
  br label %bb263
bb114:
  %t340 = load ptr, ptr %l1, !tbaa !29
  store ptr %t340, ptr %l201, !tbaa !29
  store i1 false, ptr %l202, !tbaa !21
  %t341 = load ptr, ptr %l201, !tbaa !29
  %t342 = icmp ne ptr %t341, null
  br i1 %t342, label %bb115, label %bb116
bb115:
  %t344 = load ptr, ptr %l201, !tbaa !29
  %t345 = load i64, ptr %t344, !range !{i64 0, i64 22}
  %t347 = icmp eq i64 %t345, 7
  store i1 %t347, ptr %l202, !tbaa !21
  br label %bb116
bb116:
  %t348 = load i1, ptr %l202, !tbaa !21
  br i1 %t348, label %bb117, label %bb118
bb117:
  %t349 = load ptr, ptr %l1, !tbaa !29
  %t351 = getelementptr { i64, [4 x i64] }, ptr %t349, i32 0, i32 1
  %t352 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t351, i32 0, i32 1
  %t353 = load ptr, ptr %t352
  store ptr %t353, ptr %l23, !tbaa !29
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 1
  %t358 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t357, i32 0, i32 2
  %t359 = load { i64, ptr }, ptr %t358
  store { i64, ptr } %t359, ptr %l24, !tbaa !27
  br label %bb119
bb118:
  br label %bb122
bb119:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t361, ptr %t362)
  br label %bb120
bb120:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t366, { i64, ptr } %t367)
  br label %bb121
bb121:
  br label %bb263
bb122:
  %t370 = load ptr, ptr %l1, !tbaa !29
  store ptr %t370, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t371 = load ptr, ptr %l214, !tbaa !29
  %t372 = icmp ne ptr %t371, null
  br i1 %t372, label %bb123, label %bb124
bb123:
  %t374 = load ptr, ptr %l214, !tbaa !29
  %t375 = load i64, ptr %t374, !range !{i64 0, i64 22}
  %t377 = icmp eq i64 %t375, 8
  store i1 %t377, ptr %l215, !tbaa !21
  br label %bb124
bb124:
  %t378 = load i1, ptr %l215, !tbaa !21
  br i1 %t378, label %bb125, label %bb126
bb125:
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [4 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", ptr }, ptr %t381, i32 0, i32 1
  %t383 = load ptr, ptr %t382
  store ptr %t383, ptr %l25, !tbaa !29
  br label %bb127
bb126:
  br label %bb137
bb127:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t387 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t385)
  store i64 %t387, ptr %l221
  br label %bb128
bb128:
  %t388 = load i64, ptr %l221, !tbaa !24
  store i64 %t388, ptr %l26, !tbaa !24
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l25, !tbaa !29
  %t392 = getelementptr %"compiler/ast:For3", ptr %t390, i32 0, i32 0
  %t393 = load ptr, ptr %t392, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t389, ptr %t393)
  br label %bb129
bb129:
  %t397 = load ptr, ptr %l25, !tbaa !29
  %t399 = getelementptr %"compiler/ast:For3", ptr %t397, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t402 = icmp eq ptr %t400, null
  %t404 = xor i1 %t402, true
  br i1 %t404, label %bb130, label %bb131
bb130:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load ptr, ptr %l25, !tbaa !29
  %t409 = getelementptr %"compiler/ast:For3", ptr %t407, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t406, ptr %t410)
  br label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb133
bb133:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load ptr, ptr %l25, !tbaa !29
  %t416 = getelementptr %"compiler/ast:For3", ptr %t414, i32 0, i32 2
  %t417 = load ptr, ptr %t416, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t413, ptr %t417)
  br label %bb134
bb134:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load ptr, ptr %l25, !tbaa !29
  %t424 = getelementptr %"compiler/ast:For3", ptr %t422, i32 0, i32 3
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t421, { i64, ptr } %t425)
  br label %bb135
bb135:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load i64, ptr %l26, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t428, i64 %t429)
  br label %bb136
bb136:
  br label %bb263
bb137:
  %t432 = load ptr, ptr %l1, !tbaa !29
  store ptr %t432, ptr %l242, !tbaa !29
  store i1 false, ptr %l243, !tbaa !21
  %t433 = load ptr, ptr %l242, !tbaa !29
  %t434 = icmp ne ptr %t433, null
  br i1 %t434, label %bb138, label %bb139
bb138:
  %t436 = load ptr, ptr %l242, !tbaa !29
  %t437 = load i64, ptr %t436, !range !{i64 0, i64 22}
  %t439 = icmp eq i64 %t437, 9
  store i1 %t439, ptr %l243, !tbaa !21
  br label %bb139
bb139:
  %t440 = load i1, ptr %l243, !tbaa !21
  br i1 %t440, label %bb140, label %bb141
bb140:
  %t441 = load ptr, ptr %l1, !tbaa !29
  %t443 = getelementptr { i64, [4 x i64] }, ptr %t441, i32 0, i32 1
  %t444 = getelementptr { %"compiler/source:Span", ptr }, ptr %t443, i32 0, i32 0
  %t445 = load %"compiler/source:Span", ptr %t444
  store %"compiler/source:Span" %t445, ptr %l27
  %t447 = load ptr, ptr %l1, !tbaa !29
  %t449 = getelementptr { i64, [4 x i64] }, ptr %t447, i32 0, i32 1
  %t450 = getelementptr { %"compiler/source:Span", ptr }, ptr %t449, i32 0, i32 1
  %t451 = load ptr, ptr %t450
  store ptr %t451, ptr %l28, !tbaa !29
  br label %bb142
bb141:
  br label %bb149
bb142:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load ptr, ptr %l28, !tbaa !29
  %t456 = getelementptr %"compiler/ast:ForIn", ptr %t454, i32 0, i32 2
  %t457 = load ptr, ptr %t456, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t453, ptr %t457)
  br label %bb143
bb143:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t461)
  store i64 %t463, ptr %l255
  br label %bb144
bb144:
  %t464 = load i64, ptr %l255, !tbaa !24
  store i64 %t464, ptr %l29, !tbaa !24
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = getelementptr %"compiler/source:Span", ptr %l27, i32 0, i32 0
  %t467 = load i32, ptr %t466, !tbaa !23
  %t468 = load ptr, ptr %l28, !tbaa !29
  %t470 = getelementptr %"compiler/ast:ForIn", ptr %t468, i32 0, i32 0
  %t471 = load i32, ptr %t470, !tbaa !23
  %t472 = load ptr, ptr %l28, !tbaa !29
  %t474 = getelementptr %"compiler/ast:ForIn", ptr %t472, i32 0, i32 1
  %t475 = load i32, ptr %t474, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforNames(ptr %v0, ptr %t465, i32 %t467, i32 %t471, i32 %t475)
  br label %bb145
bb145:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load ptr, ptr %l28, !tbaa !29
  %t483 = getelementptr %"compiler/ast:ForIn", ptr %t481, i32 0, i32 4
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t480, { i64, ptr } %t484)
  br label %bb146
bb146:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load i64, ptr %l29, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t487, i64 %t488)
  br label %bb147
bb147:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load ptr, ptr %l28, !tbaa !29
  %t494 = getelementptr %"compiler/ast:ForIn", ptr %t492, i32 0, i32 5
  %t495 = load { i64, ptr }, ptr %t494, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t491, { i64, ptr } %t495)
  br label %bb148
bb148:
  br label %bb263
bb149:
  %t498 = load ptr, ptr %l1, !tbaa !29
  store ptr %t498, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t499 = load ptr, ptr %l270, !tbaa !29
  %t500 = icmp ne ptr %t499, null
  br i1 %t500, label %bb150, label %bb151
bb150:
  %t502 = load ptr, ptr %l270, !tbaa !29
  %t503 = load i64, ptr %t502, !range !{i64 0, i64 22}
  %t505 = icmp eq i64 %t503, 10
  store i1 %t505, ptr %l271, !tbaa !21
  br label %bb151
bb151:
  %t506 = load i1, ptr %l271, !tbaa !21
  br i1 %t506, label %bb152, label %bb153
bb152:
  %t507 = load ptr, ptr %l1, !tbaa !29
  %t509 = getelementptr { i64, [4 x i64] }, ptr %t507, i32 0, i32 1
  %t510 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t509, i32 0, i32 1
  %t511 = load { i64, ptr }, ptr %t510
  store { i64, ptr } %t511, ptr %l30, !tbaa !27
  %t513 = load ptr, ptr %l1, !tbaa !29
  %t515 = getelementptr { i64, [4 x i64] }, ptr %t513, i32 0, i32 1
  %t516 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t515, i32 0, i32 2
  %t517 = load ptr, ptr %t516
  store ptr %t517, ptr %l31, !tbaa !29
  br label %bb154
bb153:
  br label %bb157
bb154:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t519, { i64, ptr } %t520)
  br label %bb155
bb155:
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t524 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t523, ptr %t524)
  br label %bb156
bb156:
  br label %bb263
bb157:
  %t528 = load ptr, ptr %l1, !tbaa !29
  store ptr %t528, ptr %l283, !tbaa !29
  store i1 false, ptr %l284, !tbaa !21
  %t529 = load ptr, ptr %l283, !tbaa !29
  %t530 = icmp ne ptr %t529, null
  br i1 %t530, label %bb158, label %bb159
bb158:
  %t532 = load ptr, ptr %l283, !tbaa !29
  %t533 = load i64, ptr %t532, !range !{i64 0, i64 22}
  %t535 = icmp eq i64 %t533, 11
  store i1 %t535, ptr %l284, !tbaa !21
  br label %bb159
bb159:
  %t536 = load i1, ptr %l284, !tbaa !21
  br i1 %t536, label %bb160, label %bb161
bb160:
  %t537 = load ptr, ptr %l1, !tbaa !29
  %t539 = getelementptr { i64, [4 x i64] }, ptr %t537, i32 0, i32 1
  %t540 = getelementptr { %"compiler/source:Span", ptr }, ptr %t539, i32 0, i32 1
  %t541 = load ptr, ptr %t540
  store ptr %t541, ptr %l32, !tbaa !29
  br label %bb162
bb161:
  br label %bb164
bb162:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ematchOf(ptr %v0, ptr %v1, ptr %t543, ptr %t544)
  br label %bb163
bb163:
  br label %bb263
bb164:
  %t547 = load ptr, ptr %l1, !tbaa !29
  store ptr %t547, ptr %l291, !tbaa !29
  store i1 false, ptr %l292, !tbaa !21
  %t548 = load ptr, ptr %l291, !tbaa !29
  %t549 = icmp ne ptr %t548, null
  br i1 %t549, label %bb165, label %bb166
bb165:
  %t551 = load ptr, ptr %l291, !tbaa !29
  %t552 = load i64, ptr %t551, !range !{i64 0, i64 22}
  %t554 = icmp eq i64 %t552, 12
  store i1 %t554, ptr %l292, !tbaa !21
  br label %bb166
bb166:
  %t555 = load i1, ptr %l292, !tbaa !21
  br i1 %t555, label %bb167, label %bb168
bb167:
  %t556 = load ptr, ptr %l1, !tbaa !29
  %t558 = getelementptr { i64, [4 x i64] }, ptr %t556, i32 0, i32 1
  %t559 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t558, i32 0, i32 1
  %t560 = load { i64, ptr }, ptr %t559
  store { i64, ptr } %t560, ptr %l33, !tbaa !27
  br label %bb169
bb168:
  br label %bb177
bb169:
  %t562 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t562, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t564 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t564, 0
  store i64 %t566, ptr %l36, !tbaa !24
  br label %bb170
bb170:
  %t568 = load i64, ptr %l35, !tbaa !24
  %t569 = load i64, ptr %l36, !tbaa !24
  %t572 = icmp slt i64 %t568, %t569
  %t574 = xor i1 %t572, true
  br i1 %t574, label %bb171, label %bb172
bb171:
  br label %bb176
bb172:
  br label %bb173
bb173:
  %t576 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t576, ptr %l304, !tbaa !27
  %t577 = load i64, ptr %l35, !tbaa !24
  %t579 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !27
  %t581 = getelementptr ptr, ptr %t580, i64 %t577
  %t582 = load ptr, ptr %t581, !tbaa !39
  %t584 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t584, ptr %t582)
  br label %bb174
bb174:
  br label %bb175
bb175:
  %t589 = load i64, ptr %l35, !tbaa !24
  %t591 = add i64 %t589, 1
  store i64 %t591, ptr %l35, !tbaa !24
  br label %bb170
bb176:
  br label %bb263
bb177:
  %t593 = load ptr, ptr %l1, !tbaa !29
  store ptr %t593, ptr %l312, !tbaa !29
  store i1 false, ptr %l313, !tbaa !21
  %t594 = load ptr, ptr %l312, !tbaa !29
  %t595 = icmp ne ptr %t594, null
  br i1 %t595, label %bb178, label %bb179
bb178:
  %t597 = load ptr, ptr %l312, !tbaa !29
  %t598 = load i64, ptr %t597, !range !{i64 0, i64 22}
  %t600 = icmp eq i64 %t598, 21
  store i1 %t600, ptr %l313, !tbaa !21
  br label %bb179
bb179:
  %t601 = load i1, ptr %l313, !tbaa !21
  br i1 %t601, label %bb180, label %bb181
bb180:
  %t602 = load ptr, ptr %l1, !tbaa !29
  %t604 = getelementptr { i64, [4 x i64] }, ptr %t602, i32 0, i32 1
  %t605 = getelementptr { %"compiler/source:Span", ptr }, ptr %t604, i32 0, i32 1
  %t606 = load ptr, ptr %t605
  store ptr %t606, ptr %l38, !tbaa !29
  br label %bb186
bb181:
  %t608 = load ptr, ptr %l1, !tbaa !29
  store ptr %t608, ptr %l318, !tbaa !29
  store i1 false, ptr %l319, !tbaa !21
  %t609 = load ptr, ptr %l318, !tbaa !29
  %t610 = icmp ne ptr %t609, null
  br i1 %t610, label %bb182, label %bb183
bb182:
  %t612 = load ptr, ptr %l318, !tbaa !29
  %t613 = load i64, ptr %t612, !range !{i64 0, i64 22}
  %t615 = icmp eq i64 %t613, 15
  store i1 %t615, ptr %l319, !tbaa !21
  br label %bb183
bb183:
  %t616 = load i1, ptr %l319, !tbaa !21
  br i1 %t616, label %bb184, label %bb185
bb184:
  %t617 = load ptr, ptr %l1, !tbaa !29
  %t619 = getelementptr { i64, [4 x i64] }, ptr %t617, i32 0, i32 1
  %t620 = getelementptr { %"compiler/source:Span", ptr }, ptr %t619, i32 0, i32 1
  %t621 = load ptr, ptr %t620
  store ptr %t621, ptr %l38, !tbaa !29
  br label %bb186
bb185:
  br label %bb188
bb186:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t623, ptr %t624)
  br label %bb187
bb187:
  br label %bb263
bb188:
  %t628 = load ptr, ptr %l1, !tbaa !29
  store ptr %t628, ptr %l327, !tbaa !29
  store i1 false, ptr %l328, !tbaa !21
  %t629 = load ptr, ptr %l327, !tbaa !29
  %t630 = icmp ne ptr %t629, null
  br i1 %t630, label %bb189, label %bb190
bb189:
  %t632 = load ptr, ptr %l327, !tbaa !29
  %t633 = load i64, ptr %t632, !range !{i64 0, i64 22}
  %t635 = icmp eq i64 %t633, 14
  store i1 %t635, ptr %l328, !tbaa !21
  br label %bb190
bb190:
  %t636 = load i1, ptr %l328, !tbaa !21
  br i1 %t636, label %bb191, label %bb192
bb191:
  %t637 = load ptr, ptr %l1, !tbaa !29
  %t639 = getelementptr { i64, [4 x i64] }, ptr %t637, i32 0, i32 1
  %t640 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t639, i32 0, i32 1
  %t641 = load ptr, ptr %t640
  store ptr %t641, ptr %l39, !tbaa !29
  %t643 = load ptr, ptr %l1, !tbaa !29
  %t645 = getelementptr { i64, [4 x i64] }, ptr %t643, i32 0, i32 1
  %t646 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t645, i32 0, i32 2
  %t647 = load ptr, ptr %t646
  store ptr %t647, ptr %l40, !tbaa !29
  br label %bb193
bb192:
  br label %bb199
bb193:
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t650 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t649, ptr %t650)
  br label %bb194
bb194:
  %t654 = load ptr, ptr %l40, !tbaa !29
  %t656 = icmp eq ptr %t654, null
  %t658 = xor i1 %t656, true
  br i1 %t658, label %bb195, label %bb196
bb195:
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t661 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t660, ptr %t661)
  br label %bb197
bb196:
  br label %bb198
bb197:
  br label %bb198
bb198:
  br label %bb263
bb199:
  %t665 = load ptr, ptr %l1, !tbaa !29
  store ptr %t665, ptr %l344, !tbaa !29
  store i1 false, ptr %l345, !tbaa !21
  %t666 = load ptr, ptr %l344, !tbaa !29
  %t667 = icmp ne ptr %t666, null
  br i1 %t667, label %bb200, label %bb201
bb200:
  %t669 = load ptr, ptr %l344, !tbaa !29
  %t670 = load i64, ptr %t669, !range !{i64 0, i64 22}
  %t672 = icmp eq i64 %t670, 13
  store i1 %t672, ptr %l345, !tbaa !21
  br label %bb201
bb201:
  %t673 = load i1, ptr %l345, !tbaa !21
  br i1 %t673, label %bb202, label %bb203
bb202:
  %t674 = load ptr, ptr %l1, !tbaa !29
  %t676 = getelementptr { i64, [4 x i64] }, ptr %t674, i32 0, i32 1
  %t677 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t676, i32 0, i32 2
  %t678 = load ptr, ptr %t677
  store ptr %t678, ptr %l41, !tbaa !29
  br label %bb204
bb203:
  br label %bb209
bb204:
  %t680 = load ptr, ptr %l41, !tbaa !29
  %t682 = icmp eq ptr %t680, null
  %t684 = xor i1 %t682, true
  br i1 %t684, label %bb205, label %bb206
bb205:
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t686, ptr %t687)
  br label %bb207
bb206:
  br label %bb208
bb207:
  br label %bb208
bb208:
  br label %bb263
bb209:
  %t691 = load ptr, ptr %l1, !tbaa !29
  store ptr %t691, ptr %l356, !tbaa !29
  store i1 false, ptr %l357, !tbaa !21
  %t692 = load ptr, ptr %l356, !tbaa !29
  %t693 = icmp ne ptr %t692, null
  br i1 %t693, label %bb210, label %bb211
bb210:
  %t695 = load ptr, ptr %l356, !tbaa !29
  %t696 = load i64, ptr %t695, !range !{i64 0, i64 22}
  %t698 = icmp eq i64 %t696, 16
  store i1 %t698, ptr %l357, !tbaa !21
  br label %bb211
bb211:
  %t699 = load i1, ptr %l357, !tbaa !21
  br i1 %t699, label %bb212, label %bb213
bb212:
  %t700 = load ptr, ptr %l1, !tbaa !29
  %t702 = getelementptr { i64, [4 x i64] }, ptr %t700, i32 0, i32 1
  %t703 = getelementptr { %"compiler/source:Span", ptr }, ptr %t702, i32 0, i32 1
  %t704 = load ptr, ptr %t703
  store ptr %t704, ptr %l42, !tbaa !29
  br label %bb214
bb213:
  br label %bb220
bb214:
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t708 = getelementptr %"compiler/names:Resolver", ptr %t706, i32 0, i32 22
  %t709 = load i1, ptr %t708, !tbaa !21
  br i1 %t709, label %bb215, label %bb216
bb215:
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t712 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyRaise(ptr %v0, ptr %v1, ptr %t711, ptr %t712)
  br label %bb217
bb216:
  %t715 = load ptr, ptr %l0, !tbaa !29
  %t716 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t715, ptr %t716)
  br label %bb218
bb217:
  br label %bb219
bb218:
  br label %bb219
bb219:
  br label %bb263
bb220:
  %t719 = load ptr, ptr %l1, !tbaa !29
  store ptr %t719, ptr %l368, !tbaa !29
  store i1 false, ptr %l369, !tbaa !21
  %t720 = load ptr, ptr %l368, !tbaa !29
  %t721 = icmp ne ptr %t720, null
  br i1 %t721, label %bb221, label %bb222
bb221:
  %t723 = load ptr, ptr %l368, !tbaa !29
  %t724 = load i64, ptr %t723, !range !{i64 0, i64 22}
  %t726 = icmp eq i64 %t724, 17
  store i1 %t726, ptr %l369, !tbaa !21
  br label %bb222
bb222:
  %t727 = load i1, ptr %l369, !tbaa !21
  br i1 %t727, label %bb223, label %bb224
bb223:
  %t728 = load ptr, ptr %l1, !tbaa !29
  %t730 = getelementptr { i64, [4 x i64] }, ptr %t728, i32 0, i32 1
  %t731 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t730, i32 0, i32 1
  %t732 = load { i64, ptr }, ptr %t731
  store { i64, ptr } %t732, ptr %l43, !tbaa !27
  %t734 = load ptr, ptr %l1, !tbaa !29
  %t736 = getelementptr { i64, [4 x i64] }, ptr %t734, i32 0, i32 1
  %t737 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t736, i32 0, i32 2
  %t738 = load ptr, ptr %t737
  store ptr %t738, ptr %l44, !tbaa !29
  br label %bb225
bb224:
  br label %bb234
bb225:
  %t740 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t740, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  %t742 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t744 = extractvalue { i64, ptr } %t742, 0
  store i64 %t744, ptr %l47, !tbaa !24
  br label %bb226
bb226:
  %t746 = load i64, ptr %l46, !tbaa !24
  %t747 = load i64, ptr %l47, !tbaa !24
  %t750 = icmp slt i64 %t746, %t747
  %t752 = xor i1 %t750, true
  br i1 %t752, label %bb227, label %bb228
bb227:
  br label %bb232
bb228:
  br label %bb229
bb229:
  %t754 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t754, ptr %l383, !tbaa !27
  %t755 = load i64, ptr %l46, !tbaa !24
  %t757 = getelementptr { i64, ptr }, ptr %l383, i32 0, i32 1
  %t758 = load ptr, ptr %t757, !tbaa !27
  %t759 = getelementptr ptr, ptr %t758, i64 %t755
  %t760 = load ptr, ptr %t759, !tbaa !39
  %t762 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %t762, ptr %t760)
  br label %bb230
bb230:
  br label %bb231
bb231:
  %t766 = load i64, ptr %l46, !tbaa !24
  %t768 = add i64 %t766, 1
  store i64 %t768, ptr %l46, !tbaa !24
  br label %bb226
bb232:
  %t770 = load ptr, ptr %l0, !tbaa !29
  %t771 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t770, ptr %t771)
  br label %bb233
bb233:
  br label %bb263
bb234:
  %t775 = load ptr, ptr %l1, !tbaa !29
  store ptr %t775, ptr %l393, !tbaa !29
  store i1 false, ptr %l394, !tbaa !21
  %t776 = load ptr, ptr %l393, !tbaa !29
  %t777 = icmp ne ptr %t776, null
  br i1 %t777, label %bb235, label %bb236
bb235:
  %t779 = load ptr, ptr %l393, !tbaa !29
  %t780 = load i64, ptr %t779, !range !{i64 0, i64 22}
  %t782 = icmp eq i64 %t780, 18
  store i1 %t782, ptr %l394, !tbaa !21
  br label %bb236
bb236:
  %t783 = load i1, ptr %l394, !tbaa !21
  br i1 %t783, label %bb237, label %bb238
bb237:
  %t784 = load ptr, ptr %l1, !tbaa !29
  %t786 = getelementptr { i64, [4 x i64] }, ptr %t784, i32 0, i32 1
  %t787 = getelementptr { %"compiler/source:Span", ptr }, ptr %t786, i32 0, i32 1
  %t788 = load ptr, ptr %t787
  store ptr %t788, ptr %l49, !tbaa !29
  br label %bb239
bb238:
  br label %bb242
bb239:
  %t790 = load ptr, ptr %l0, !tbaa !29
  %t791 = load ptr, ptr %l49, !tbaa !29
  %t793 = getelementptr %"compiler/ast:JoinS", ptr %t791, i32 0, i32 1
  %t794 = load { i64, ptr }, ptr %t793, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t790, { i64, ptr } %t794)
  br label %bb240
bb240:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t798 = load ptr, ptr %l49, !tbaa !29
  %t800 = getelementptr %"compiler/ast:JoinS", ptr %t798, i32 0, i32 2
  %t801 = load { i64, ptr }, ptr %t800, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t797, { i64, ptr } %t801)
  br label %bb241
bb241:
  br label %bb263
bb242:
  %t804 = load ptr, ptr %l1, !tbaa !29
  store ptr %t804, ptr %l405, !tbaa !29
  store i1 false, ptr %l406, !tbaa !21
  %t805 = load ptr, ptr %l405, !tbaa !29
  %t806 = icmp ne ptr %t805, null
  br i1 %t806, label %bb243, label %bb244
bb243:
  %t808 = load ptr, ptr %l405, !tbaa !29
  %t809 = load i64, ptr %t808, !range !{i64 0, i64 22}
  %t811 = icmp eq i64 %t809, 19
  store i1 %t811, ptr %l406, !tbaa !21
  br label %bb244
bb244:
  %t812 = load i1, ptr %l406, !tbaa !21
  br i1 %t812, label %bb245, label %bb246
bb245:
  %t813 = load ptr, ptr %l1, !tbaa !29
  %t815 = getelementptr { i64, [4 x i64] }, ptr %t813, i32 0, i32 1
  %t816 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t815, i32 0, i32 1
  %t817 = load ptr, ptr %t816
  store ptr %t817, ptr %l50, !tbaa !29
  br label %bb247
bb246:
  br label %bb251
bb247:
  %t819 = load ptr, ptr %l0, !tbaa !29
  %t821 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t819)
  store i64 %t821, ptr %l412
  br label %bb248
bb248:
  %t822 = load i64, ptr %l412, !tbaa !24
  store i64 %t822, ptr %l51, !tbaa !24
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t824 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t823, ptr %t824)
  br label %bb249
bb249:
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t829 = load i64, ptr %l51, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t828, i64 %t829)
  br label %bb250
bb250:
  br label %bb263
bb251:
  %t832 = load ptr, ptr %l1, !tbaa !29
  store ptr %t832, ptr %l418, !tbaa !29
  store i1 false, ptr %l419, !tbaa !21
  %t833 = load ptr, ptr %l418, !tbaa !29
  %t834 = icmp ne ptr %t833, null
  br i1 %t834, label %bb252, label %bb253
bb252:
  %t836 = load ptr, ptr %l418, !tbaa !29
  %t837 = load i64, ptr %t836, !range !{i64 0, i64 22}
  %t839 = icmp eq i64 %t837, 20
  store i1 %t839, ptr %l419, !tbaa !21
  br label %bb253
bb253:
  %t840 = load i1, ptr %l419, !tbaa !21
  br i1 %t840, label %bb254, label %bb255
bb254:
  %t841 = load ptr, ptr %l1, !tbaa !29
  %t843 = getelementptr { i64, [4 x i64] }, ptr %t841, i32 0, i32 1
  %t844 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t843, i32 0, i32 1
  %t845 = load { i64, ptr }, ptr %t844
  store { i64, ptr } %t845, ptr %l52, !tbaa !27
  br label %bb256
bb255:
  br label %bb258
bb256:
  %t847 = load ptr, ptr %l0, !tbaa !29
  %t848 = load { i64, ptr }, ptr %l52, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t847, { i64, ptr } %t848)
  br label %bb257
bb257:
  br label %bb263
bb258:
  br i1 true, label %bb259, label %bb260
bb259:
  br label %bb261
bb260:
  br label %bb262
bb261:
  br label %bb263
bb262:
  call void @__olang_check_failed(ptr @olang_loc_6c621cf945a32f52_fbb4d8308e24c5b6)
  unreachable
bb263:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esuggests(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/names:Entry"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l15 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l25 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l35 = alloca i1
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l64 = alloca i1
  %l67 = alloca i1
  %l72 = alloca i64
  %l73 = alloca [14 x { i64, ptr }]
  %l86 = alloca i64
  %l96 = alloca ptr
  %l99 = alloca i64
  %l101 = alloca i64
  %l106 = alloca %"compiler/names:Entry"
  %l107 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i64
  %l122 = alloca ptr
  %l125 = alloca i64
  %l127 = alloca i64
  %l132 = alloca { i64, ptr }
  %l135 = alloca i64
  %l143 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l144 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l146 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l147 = alloca i32
  %l149 = alloca i1
  %l150 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l154 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sge i64 %t3, 2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l20, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = sub i64 %t10, 1
  %t14 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t17)
  store i1 %t19, ptr %l25
  br label %bb3
bb2:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb4
bb3:
  %t20 = load i1, ptr %l25, !tbaa !21
  store i1 %t20, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l19, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l2, !tbaa !24
  br label %bb7
bb6:
  br label %bb37
bb7:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t30, ptr %l31, !tbaa !27
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t31, 1
  %t35 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t33
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t38)
  store i1 %t40, ptr %l35
  br label %bb10
bb9:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb11
bb10:
  %t41 = load i1, ptr %l35, !tbaa !21
  store i1 %t41, ptr %l30, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l30, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb15
bb15:
  br label %bb7
bb16:
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = load i64, ptr %l2, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t57 = icmp slt i64 %t55, 8
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t59, ptr %l45, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l46, !tbaa !24
  %t62 = icmp sge i64 0, 0
  br i1 %t62, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb33
bb19:
  %t64 = icmp sle i64 0, 1
  br i1 %t64, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb21:
  %t66 = load i64, ptr %l46, !tbaa !24
  %t67 = icmp sle i64 1, %t66
  br i1 %t67, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb23:
  %t69 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 0
  %t72 = sub i64 1, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  %t76 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v1, ptr %s1, { i64, ptr } %t74)
  store { i64, ptr } %t76, ptr %l51
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb25:
  %t77 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t77, ptr %l52, !tbaa !27
  %t78 = load i64, ptr %l2, !tbaa !24
  store i64 %t78, ptr %l53, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t79, 0
  store i64 %t82, ptr %l56, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l57, !tbaa !24
  %t85 = load i64, ptr %l53, !tbaa !24
  %t86 = icmp sge i64 %t85, 0
  br i1 %t86, label %bb26, label %bb27
bb26:
  %t88 = load i64, ptr %l53, !tbaa !24
  %t89 = load i64, ptr %l56, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb28:
  %t92 = load i64, ptr %l56, !tbaa !24
  %t93 = load i64, ptr %l57, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb30:
  %t96 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l53, !tbaa !24
  %t99 = load i64, ptr %l56, !tbaa !24
  %t100 = getelementptr i8, ptr %t97, i64 %t98
  %t101 = sub i64 %t99, %t98
  %t102 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  %t104 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = extractvalue { i64, ptr } %t103, 1
  %t109 = extractvalue { i64, ptr } %t103, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t105, i64 %t106)
  %t112 = getelementptr i8, ptr %t111, i64 %t106
  call void @olang_textcopy(ptr %t112, ptr %t108, i64 %t109)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } %t114, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t123 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %s1, { i64, ptr } %t121)
  store i1 %t123, ptr %l64
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb32:
  %t124 = load i1, ptr %l64, !tbaa !21
  store i1 %t124, ptr %l44, !tbaa !21
  br label %bb33
bb33:
  %t125 = load i1, ptr %l44, !tbaa !21
  br i1 %t125, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s1)
  br label %bb37
bb37:
  %t127 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t127, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t129, ptr %l67
  br label %bb38
bb38:
  %t130 = load i1, ptr %l67, !tbaa !21
  br i1 %t130, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t132 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t136 = icmp sle i64 %t134, 4
  br i1 %t136, label %bb42, label %bb43
bb42:
  store i64 2, ptr %l72, !tbaa !24
  br label %bb44
bb43:
  store i64 3, ptr %l72, !tbaa !24
  br label %bb44
bb44:
  %t138 = load i64, ptr %l72, !tbaa !24
  store i64 %t138, ptr %l3, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s6
  %t139 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 0
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %t139, !tbaa !37
  %t140 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %t140, !tbaa !37
  %t141 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 2
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %t141, !tbaa !37
  %t142 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 3
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %t142, !tbaa !37
  %t143 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %t143, !tbaa !37
  %t144 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %t144, !tbaa !37
  %t145 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %t145, !tbaa !37
  %t146 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 7
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %t146, !tbaa !37
  %t147 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %t147, !tbaa !37
  %t148 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 9
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %t148, !tbaa !37
  %t149 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t149, !tbaa !37
  %t150 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %t150, !tbaa !37
  %t151 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 12
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %t151, !tbaa !37
  %t152 = getelementptr [14 x { i64, ptr }], ptr %l73, i64 0, i64 13
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %t152, !tbaa !37
  %t153 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 224, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %l73, i64 224, i1 false)
  store ptr %t153, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t155 = load ptr, ptr %l4
  store i64 14, ptr %l6, !tbaa !24
  br label %bb45
bb45:
  %t158 = load i64, ptr %l5, !tbaa !24
  %t159 = load i64, ptr %l6, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb46, label %bb47
bb46:
  br label %bb54
bb47:
  br label %bb48
bb48:
  %t166 = load ptr, ptr %l4
  %t167 = load i64, ptr %l5, !tbaa !24
  %t170 = getelementptr [14 x { i64, ptr }], ptr %t166, i64 0, i64 %t167
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !37
  %t173 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t175 = load ptr, ptr @__olang_prog_scope
  %t178 = call i64 @compiler_2fmsgs_2eDistance(ptr %v1, ptr %t175, { i64, ptr } %t173, { i64, ptr } %t171)
  store i64 %t178, ptr %l86
  br label %bb49
bb49:
  %t179 = load i64, ptr %l3, !tbaa !24
  %t180 = load i64, ptr %l86, !tbaa !24
  %t182 = icmp slt i64 %t180, %t179
  br i1 %t182, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t185 = load i64, ptr %l5, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l5, !tbaa !24
  br label %bb45
bb54:
  call void @__olang_scope_close(ptr %s6)
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/names:Resolver", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/names:Resolver", ptr %t192, i32 0, i32 6
  %t195 = load i64, ptr %t194, !tbaa !24
  %t198 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t191, i64 %t195)
  store ptr %t198, ptr %l96
  br label %bb55
bb55:
  %t199 = load ptr, ptr %l96, !tbaa !29
  %t201 = getelementptr %"compiler/names:Table", ptr %t199, i32 0, i32 0
  store ptr %t201, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb56
bb56:
  %t203 = load i64, ptr %l9, !tbaa !24
  store i64 %t203, ptr %l99, !tbaa !24
  %t204 = load ptr, ptr %l8, !tbaa !29
  %t206 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t204)
  store i64 %t206, ptr %l101
  br label %bb57
bb57:
  %t207 = load i64, ptr %l99, !tbaa !24
  %t208 = load i64, ptr %l101, !tbaa !24
  %t209 = icmp slt i64 %t207, %t208
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb58, label %bb59
bb58:
  br label %bb68
bb59:
  br label %bb60
bb60:
  %t213 = load ptr, ptr %l8, !tbaa !29
  %t214 = load i64, ptr %l9, !tbaa !24
  %t217 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t213, i64 %t214)
  store %"compiler/names:Entry" %t217, ptr %l106
  br label %bb61
bb61:
  %t218 = load %"compiler/names:Entry", ptr %l106
  store %"compiler/names:Entry" %t218, ptr %l10
  %t219 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t219, ptr %l107, !tbaa !27
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t222 = load i32, ptr %t221, !tbaa !23
  %t225 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t220, i32 %t222)
  store { i64, ptr } %t225, ptr %l110
  br label %bb62
bb62:
  %t226 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t228 = call i64 @compiler_2fmsgs_2eDistance(ptr %v1, ptr %v0, { i64, ptr } %t226, { i64, ptr } %t227)
  store i64 %t228, ptr %l111
  br label %bb63
bb63:
  %t229 = load i64, ptr %l3, !tbaa !24
  %t230 = load i64, ptr %l111, !tbaa !24
  %t232 = icmp slt i64 %t230, %t229
  br i1 %t232, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t235 = load i64, ptr %l9, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l9, !tbaa !24
  br label %bb56
bb68:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/names:Resolver", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/load:Loader", ptr %t242, i32 0, i32 5
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/names:Resolver", ptr %t245, i32 0, i32 6
  %t248 = load i64, ptr %t247, !tbaa !24
  %t251 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t244, i64 %t248)
  store ptr %t251, ptr %l122
  br label %bb69
bb69:
  %t252 = load ptr, ptr %l122, !tbaa !29
  %t254 = getelementptr %"compiler/load:Module", ptr %t252, i32 0, i32 9
  store ptr %t254, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb70
bb70:
  %t256 = load i64, ptr %l12, !tbaa !24
  store i64 %t256, ptr %l125, !tbaa !24
  %t257 = load ptr, ptr %l11, !tbaa !29
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t257)
  store i64 %t259, ptr %l127
  br label %bb71
bb71:
  %t260 = load i64, ptr %l125, !tbaa !24
  %t261 = load i64, ptr %l127, !tbaa !24
  %t262 = icmp slt i64 %t260, %t261
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb72, label %bb73
bb72:
  br label %bb81
bb73:
  br label %bb74
bb74:
  %t266 = load ptr, ptr %l11, !tbaa !29
  %t267 = load i64, ptr %l12, !tbaa !24
  %t270 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t266, i64 %t267)
  store { i64, ptr } %t270, ptr %l132
  br label %bb75
bb75:
  %t271 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t276 = call i64 @compiler_2fmsgs_2eDistance(ptr %v1, ptr %v0, { i64, ptr } %t272, { i64, ptr } %t271)
  store i64 %t276, ptr %l135
  br label %bb76
bb76:
  %t277 = load i64, ptr %l3, !tbaa !24
  %t278 = load i64, ptr %l135, !tbaa !24
  %t280 = icmp slt i64 %t278, %t277
  br i1 %t280, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t283 = load i64, ptr %l12, !tbaa !24
  %t285 = add i64 %t283, 1
  store i64 %t285, ptr %l12, !tbaa !24
  br label %bb70
bb81:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/names:Resolver", ptr %t287, i32 0, i32 2
  %t291 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v0, ptr %t289)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t291, ptr %l143
  br label %bb82
bb82:
  %t292 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l143
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t292, ptr %l14
  br label %bb83
bb83:
  %t294 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %l14)
  %t295 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t294, 1
  %t296 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t294, 0
  store i32 %t296, ptr %l147
  %t297 = icmp ne i32 %t296, 0
  br i1 %t297, label %bb85, label %ok.298, !prof !99
ok.298:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t295, ptr %l146
  br label %bb84
bb84:
  %t299 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l146
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t299, ptr %l144
  br label %bb87
bb85:
  %t300 = load i32, ptr %l147, !tbaa !23
  %t301 = ashr i32 %t300, 16
  %t303 = icmp eq i32 %t301, 1
  store i1 %t303, ptr %l149, !tbaa !21
  br label %bb86
bb86:
  call void @__olang_ert_req_clear()
  br label %bb94
bb87:
  %t304 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l144
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t304, ptr %l15
  %t305 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t305, ptr %l150, !tbaa !27
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l15, i32 0, i32 0
  %t308 = load i32, ptr %t307, !tbaa !23
  %t311 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t306, i32 %t308)
  store { i64, ptr } %t311, ptr %l153
  br label %bb88
bb88:
  %t312 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t313 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t314 = call i64 @compiler_2fmsgs_2eDistance(ptr %v1, ptr %v0, { i64, ptr } %t312, { i64, ptr } %t313)
  store i64 %t314, ptr %l154
  br label %bb89
bb89:
  %t315 = load i64, ptr %l3, !tbaa !24
  %t316 = load i64, ptr %l154, !tbaa !24
  %t318 = icmp slt i64 %t316, %t315
  br i1 %t318, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  br label %bb83
bb94:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyBodies(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 18
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 15
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/names:Resolver", ptr %t13, i32 0, i32 20
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l14
  br label %bb3
bb3:
  %t18 = load i64, ptr %l14, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/names:Resolver", ptr %t19, i32 0, i32 22
  store i1 true, ptr %t21, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/names:Resolver", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/diag:Diagnostics", ptr %t28, i32 0, i32 21
  store i1 true, ptr %t30, !tbaa !21
  %t31 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %t31, i64 %a1, { i64, ptr } %a2)
  br label %bb4
bb4:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/load:Loader", ptr %t40, i32 0, i32 4
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/diag:Diagnostics", ptr %t43, i32 0, i32 21
  store i1 false, ptr %t45, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/names:Resolver", ptr %t46, i32 0, i32 22
  store i1 false, ptr %t48, !tbaa !21
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/names:Resolver", ptr %t49, i32 0, i32 18
  %t52 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eTruncate_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t51, i64 %t52)
  br label %bb5
bb5:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/names:Resolver", ptr %t55, i32 0, i32 15
  %t58 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H30ad8836952c6f4772e34a804c6491c6(ptr %v0, ptr %t57, i64 %t58)
  br label %bb6
bb6:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/names:Resolver", ptr %t61, i32 0, i32 20
  %t64 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H73edf45b0858a6ff3702d25efc23fa6e(ptr %v0, ptr %t63, i64 %t64)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l11 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:If", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t10, ptr %t14)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l11, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:If", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1b8bfcf5c54b80a6_f112f6c40c79d862)
  unreachable
bb6:
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:If", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Branch", ptr %t28, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t33 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t33, { i64, ptr } %t32)
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/ast:If", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/ast:If", ptr %t42, i32 0, i32 2
  %t45 = load ptr, ptr %t44, !tbaa !29
  store ptr %t45, ptr %l2, !tbaa !29
  %t47 = load ptr, ptr %l2, !tbaa !29
  store ptr %t47, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t48 = load ptr, ptr %l24, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = load ptr, ptr %l24, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 22}
  %t54 = icmp eq i64 %t52, 5
  store i1 %t54, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l25, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyIf(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  br label %bb17
bb17:
  br label %bb24
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/ast:If", ptr %t67, i32 0, i32 2
  %t70 = load ptr, ptr %t69, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t66, ptr %t70)
  br label %bb22
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_c04d895388279f34_2b6890ee7e2f3280)
  unreachable
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyRaise(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i1
  %l20 = alloca { i64, ptr }
  %l24 = alloca %"compiler/names:Ref"
  %l28 = alloca i1
  %l34 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca i1
  %l46 = alloca i64
  %l48 = alloca i64
  %l50 = alloca ptr
  %l53 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l62 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l90 = alloca i32
  %l96 = alloca ptr
  %l101 = alloca %"compiler/names:raised"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:Path", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp ne i64 %t10, 1
  store i1 %t12, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Path", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l20, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 0
  %t22 = load i32, ptr %t21, !tbaa !33
  store i32 %t22, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t24, i32 %t25)
  store %"compiler/names:Ref" %t28, ptr %l24
  br label %bb7
bb7:
  %t29 = getelementptr %"compiler/names:Ref", ptr %l24, i32 0, i32 0
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 9}
  %t32 = trunc i64 0 to i32
  %t33 = icmp eq i32 %t30, %t32
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb12
bb9:
  %t37 = load i32, ptr %l2, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/names:Resolver", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/names:Resolver", ptr %t42, i32 0, i32 6
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t41, i64 %t45)
  store ptr %t48, ptr %l34
  br label %bb10
bb10:
  %t49 = load ptr, ptr %l34, !tbaa !29
  %t51 = getelementptr %"compiler/names:Table", ptr %t49, i32 0, i32 4
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l38
  br label %bb11
bb11:
  %t56 = load i1, ptr %l38, !tbaa !21
  store i1 %t56, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l28, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb17
bb14:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t58, i32 %t59)
  store { i64, ptr } %t62, ptr %l42
  br label %bb15
bb15:
  %t63 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t63, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t64, ptr %l43
  br label %bb16
bb16:
  %t65 = load i1, ptr %l43, !tbaa !21
  store i1 %t65, ptr %l39, !tbaa !21
  br label %bb17
bb17:
  %t66 = load i1, ptr %l39, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb20
bb20:
  store i1 false, ptr %l4, !tbaa !21
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/names:Resolver", ptr %t67, i32 0, i32 25
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l46
  br label %bb21
bb21:
  %t72 = load i64, ptr %l46, !tbaa !24
  %t73 = icmp sgt i64 %t72, 0
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/names:Resolver", ptr %t75, i32 0, i32 25
  store ptr %t77, ptr %l50, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/names:Resolver", ptr %t78, i32 0, i32 25
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t80)
  store i64 %t82, ptr %l53
  br label %bb24
bb23:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/names:Resolver", ptr %t83, i32 0, i32 24
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l58
  br label %bb26
bb24:
  %t88 = load i64, ptr %l53, !tbaa !24
  %t89 = sub i64 %t88, 1
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t90, i64 %t89)
  store i64 %t92, ptr %l55
  br label %bb25
bb25:
  %t93 = load i64, ptr %l55, !tbaa !24
  store i64 %t93, ptr %l48, !tbaa !24
  br label %bb27
bb26:
  %t94 = load i64, ptr %l58, !tbaa !24
  store i64 %t94, ptr %l48, !tbaa !24
  br label %bb27
bb27:
  %t95 = load i64, ptr %l48, !tbaa !24
  store i64 %t95, ptr %l6, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/names:Resolver", ptr %t98, i32 0, i32 24
  %t102 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t100)
  store i64 %t102, ptr %l62
  br label %bb28
bb28:
  %t103 = load i64, ptr %l62, !tbaa !24
  store i64 %t103, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = icmp sgt i64 %t104, %t105
  br i1 %t108, label %bb29, label %bb30
bb29:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t112 = icmp sgt i64 %t110, 0
  br i1 %t112, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb34
bb31:
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t119 = load i64, ptr %l8, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t124 = sub i64 %t122, 1
  %t125 = load i64, ptr %l8, !tbaa !24
  %t128 = sdiv i64 %t124, %t125
  store i64 %t128, ptr %l69, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb33
bb33:
  %t130 = load i64, ptr %l69, !tbaa !24
  store i64 %t130, ptr %l66, !tbaa !24
  br label %bb34
bb34:
  %t131 = load i64, ptr %l66, !tbaa !24
  store i64 %t131, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb35
bb35:
  %t132 = load i64, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l9, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb36, label %bb37
bb36:
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t140 = load i64, ptr %l6, !tbaa !24
  %t141 = load i64, ptr %l10, !tbaa !24
  %t142 = load i64, ptr %l8, !tbaa !24
  %t145 = mul i64 %t141, %t142
  %t148 = add i64 %t140, %t145
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/names:Resolver", ptr %t150, i32 0, i32 24
  %t156 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t152, i64 %t148)
  store i32 %t156, ptr %l90
  br label %bb39
bb39:
  %t157 = load i32, ptr %l2, !tbaa !23
  %t158 = load i32, ptr %l90, !tbaa !23
  %t160 = icmp eq i32 %t158, %t157
  br i1 %t160, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t162 = load i64, ptr %l10, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l10, !tbaa !24
  br label %bb35
bb44:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/names:Resolver", ptr %t166, i32 0, i32 23
  store ptr %t168, ptr %l96, !tbaa !29
  %t169 = load i32, ptr %l2, !tbaa !23
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr %"compiler/ast:Path", ptr %t170, i32 0, i32 0
  %t173 = load %"compiler/source:Span", ptr %t172
  %t174 = load i1, ptr %l4, !tbaa !21
  %t178 = call %"compiler/names:raised" @compiler_2fnames_3araised_2ector(ptr %s0, i32 %t169, %"compiler/source:Span" %t173, i1 %t174)
  store %"compiler/names:raised" %t178, ptr %l101
  br label %bb45
bb45:
  %t179 = load ptr, ptr %l96, !tbaa !29
  %t180 = load %"compiler/names:raised", ptr %l101
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2ePush_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %t179, %"compiler/names:raised" %t180)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etableOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasesOf(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/names:Resolver", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/load:Loader", ptr %t8, i32 0, i32 5
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t10, i64 %t11)
  store ptr %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l9, !tbaa !29
  store ptr %t15, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 8
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/load:Module", ptr %t27, i32 0, i32 8
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v0, ptr %t25, i64 %t26, { i64, ptr } %t30)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l17 = alloca %"compiler/names:Ref"
  %l18 = alloca ptr
  %l19 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t23, ptr %l14
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t24, i32 %t25)
  store %"compiler/names:Ref" %t28, ptr %l17
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l13, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l14
  %t31 = load %"compiler/names:Ref", ptr %l17
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t29, %"compiler/source:Span" %t30, %"compiler/names:Ref" %t31)
  br label %bb7
bb7:
  br label %bb21
bb8:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 29}
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  br label %bb14
bb14:
  br label %bb21
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  br label %bb19
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c883e3bd313e2585_b0aaf26ba1585cf1)
  unreachable
bb21:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/names:Resolver", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t7, i32 %a1)
  store { i64, ptr } %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etopConds(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l11 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 12
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopIf", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t4, ptr %t8)
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/names:Resolver", ptr %t11, i32 0, i32 12
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l11, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:TopIf", ptr %t24, i32 0, i32 2
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  br i1 %t29, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e6063e0110b31a73_71b4269b957cfb57)
  unreachable
bb5:
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:TopIf", ptr %t31, i32 0, i32 2
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etopConds(ptr %v0, ptr %v1, ptr %t35, ptr %t34)
  br label %bb7
bb7:
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l110 = alloca i1
  %l116 = alloca i64
  %l128 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l166 = alloca i64
  %l175 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l215 = alloca i64
  %l217 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l219 = alloca i64
  %l221 = alloca i64
  %l226 = alloca i32
  %l227 = alloca ptr
  %l228 = alloca i32
  %l229 = alloca %"compiler/source:Span"
  %l238 = alloca ptr
  %l239 = alloca i1
  %l259 = alloca { i64, ptr }
  %l270 = alloca { i64, ptr }
  %l284 = alloca ptr
  %l285 = alloca i1
  %l301 = alloca { i64, ptr }
  %l316 = alloca { i64, ptr }
  %l331 = alloca { i64, ptr }
  %l335 = alloca i64
  %l350 = alloca ptr
  %l351 = alloca i1
  %l366 = alloca ptr
  %l367 = alloca i1
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TypeDecl", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb21
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb4, label %bb5
bb4:
  br label %bb20
bb5:
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l70, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  store ptr %t33, ptr %l5, !tbaa !29
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t37 = getelementptr %"compiler/ast:TypeParam", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = getelementptr %"compiler/ast:TypeParam", ptr %t45, i32 0, i32 2
  %t48 = load ptr, ptr %t47, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t44, ptr %t48)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr %"compiler/ast:TypeParam", ptr %t51, i32 0, i32 3
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t60 = load i64, ptr %l7, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t68, ptr %l88, !tbaa !27
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t76 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t76, ptr %t74)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t88 = getelementptr %"compiler/ast:TypeParam", ptr %t86, i32 0, i32 1
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/ast:TypeParam", ptr %t90, i32 0, i32 0
  %t93 = load %"compiler/source:Span", ptr %t92
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t85, i32 %t89, %"compiler/source:Span" %t93, i32 8)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t98 = load i64, ptr %l3, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l3, !tbaa !24
  br label %bb3
bb20:
  br label %bb21
bb21:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/ast:TypeDecl", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = icmp eq ptr %t105, null
  br i1 %t107, label %bb22, label %bb23
bb22:
  br label %ret
bb23:
  br label %bb24
bb24:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/ast:TypeDecl", ptr %t109, i32 0, i32 3
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l10, !tbaa !29
  %t114 = load ptr, ptr %l10, !tbaa !29
  store ptr %t114, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t115 = load ptr, ptr %l109, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb25, label %bb26
bb25:
  %t118 = load ptr, ptr %l109, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 5}
  %t121 = icmp eq i64 %t119, 0
  store i1 %t121, ptr %l110, !tbaa !21
  br label %bb26
bb26:
  %t122 = load i1, ptr %l110, !tbaa !21
  br i1 %t122, label %bb27, label %bb28
bb27:
  %t123 = load ptr, ptr %l10, !tbaa !29
  %t125 = getelementptr { i64, [6 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { ptr }, ptr %t125, i32 0, i32 0
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l11, !tbaa !29
  br label %bb29
bb28:
  br label %bb97
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l116
  br label %bb30
bb30:
  %t132 = load i64, ptr %l116, !tbaa !24
  store i64 %t132, ptr %l12, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l11, !tbaa !29
  %t136 = getelementptr %"compiler/ast:StructBody", ptr %t134, i32 0, i32 5
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeParams(ptr %v0, ptr %v1, ptr %t133, { i64, ptr } %t137)
  br label %bb31
bb31:
  %t140 = load ptr, ptr %l11, !tbaa !29
  %t142 = getelementptr %"compiler/ast:StructBody", ptr %t140, i32 0, i32 0
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  store i64 %t147, ptr %l15, !tbaa !24
  br label %bb32
bb32:
  %t149 = load i64, ptr %l14, !tbaa !24
  %t150 = load i64, ptr %l15, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  br label %bb35
bb35:
  %t157 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t157, ptr %l128, !tbaa !27
  %t158 = load i64, ptr %l14, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr ptr, ptr %t161, i64 %t158
  %t163 = load ptr, ptr %t162, !tbaa !39
  store ptr %t163, ptr %l16, !tbaa !29
  %t165 = load ptr, ptr %l16, !tbaa !29
  %t167 = getelementptr %"compiler/ast:Param", ptr %t165, i32 0, i32 2
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = icmp eq ptr %t168, null
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb36, label %bb37
bb36:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l16, !tbaa !29
  %t177 = getelementptr %"compiler/ast:Param", ptr %t175, i32 0, i32 2
  %t178 = load ptr, ptr %t177, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t174, ptr %t178)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t181 = load i64, ptr %l14, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l14, !tbaa !24
  br label %bb32
bb41:
  %t185 = load ptr, ptr %l11, !tbaa !29
  %t187 = getelementptr %"compiler/ast:StructBody", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = icmp eq ptr %t188, null
  %t192 = xor i1 %t190, true
  br i1 %t192, label %bb42, label %bb43
bb42:
  %t194 = load ptr, ptr %l11, !tbaa !29
  %t196 = getelementptr %"compiler/ast:StructBody", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = icmp eq ptr %t197, null
  br i1 %t199, label %bb44, label %bb45
bb43:
  br label %bb54
bb44:
  call void @__olang_check_failed(ptr @olang_loc_6e82bb982de183d3_df58ae24de93c697)
  unreachable
bb45:
  br label %bb46
bb46:
  %t201 = load ptr, ptr %l11, !tbaa !29
  %t203 = getelementptr %"compiler/ast:StructBody", ptr %t201, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t207 = getelementptr %"compiler/ast:Sig", ptr %t204, i32 0, i32 3
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t210 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  store i64 %t212, ptr %l19, !tbaa !24
  br label %bb47
bb47:
  %t214 = load i64, ptr %l18, !tbaa !24
  %t215 = load i64, ptr %l19, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb48, label %bb49
bb48:
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t222 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t222, ptr %l157, !tbaa !27
  %t223 = load i64, ptr %l18, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr ptr, ptr %t226, i64 %t223
  %t228 = load ptr, ptr %t227, !tbaa !39
  %t230 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t230, ptr %t228)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t235 = load i64, ptr %l18, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l18, !tbaa !24
  br label %bb47
bb53:
  br label %bb54
bb54:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t239)
  store i64 %t241, ptr %l166
  br label %bb55
bb55:
  %t242 = load i64, ptr %l166, !tbaa !24
  store i64 %t242, ptr %l21, !tbaa !24
  %t243 = load ptr, ptr %l11, !tbaa !29
  %t245 = getelementptr %"compiler/ast:StructBody", ptr %t243, i32 0, i32 0
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  store { i64, ptr } %t246, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t248, 0
  store i64 %t250, ptr %l24, !tbaa !24
  br label %bb56
bb56:
  %t252 = load i64, ptr %l23, !tbaa !24
  %t253 = load i64, ptr %l24, !tbaa !24
  %t256 = icmp slt i64 %t252, %t253
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb57, label %bb58
bb57:
  br label %bb66
bb58:
  br label %bb59
bb59:
  %t260 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t260, ptr %l175, !tbaa !27
  %t261 = load i64, ptr %l23, !tbaa !24
  %t263 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr ptr, ptr %t264, i64 %t261
  %t266 = load ptr, ptr %t265, !tbaa !39
  store ptr %t266, ptr %l25, !tbaa !29
  %t268 = load ptr, ptr %l25, !tbaa !29
  %t270 = getelementptr %"compiler/ast:Param", ptr %t268, i32 0, i32 3
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = icmp eq ptr %t271, null
  %t275 = xor i1 %t273, true
  br i1 %t275, label %bb60, label %bb61
bb60:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l25, !tbaa !29
  %t280 = getelementptr %"compiler/ast:Param", ptr %t278, i32 0, i32 3
  %t281 = load ptr, ptr %t280, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t277, ptr %t281)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %t284, ptr %t285, i1 true)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t288 = load i64, ptr %l23, !tbaa !24
  %t290 = add i64 %t288, 1
  store i64 %t290, ptr %l23, !tbaa !24
  br label %bb56
bb66:
  %t292 = load ptr, ptr %l11, !tbaa !29
  %t294 = getelementptr %"compiler/ast:StructBody", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = icmp eq ptr %t295, null
  %t299 = xor i1 %t297, true
  br i1 %t299, label %bb67, label %bb68
bb67:
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l193, !tbaa !29
  %t302 = load ptr, ptr %l11, !tbaa !29
  %t304 = getelementptr %"compiler/ast:StructBody", ptr %t302, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t307 = icmp eq ptr %t305, null
  br i1 %t307, label %bb69, label %bb70
bb68:
  br label %bb73
bb69:
  call void @__olang_check_failed(ptr @olang_loc_860724e602591604_160204475883fa78)
  unreachable
bb70:
  br label %bb71
bb71:
  %t309 = load ptr, ptr %l11, !tbaa !29
  %t311 = getelementptr %"compiler/ast:StructBody", ptr %t309, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t313 = load ptr, ptr %l193, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2econtract(ptr %v0, ptr %v1, ptr %t313, ptr %t312)
  br label %bb72
bb72:
  br label %bb73
bb73:
  %t315 = load ptr, ptr %l11, !tbaa !29
  %t317 = getelementptr %"compiler/ast:StructBody", ptr %t315, i32 0, i32 2
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t322 = icmp sgt i64 %t320, 0
  br i1 %t322, label %bb74, label %bb75
bb74:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load ptr, ptr %l11, !tbaa !29
  %t327 = getelementptr %"compiler/ast:StructBody", ptr %t325, i32 0, i32 2
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t324, { i64, ptr } %t328)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t331, i64 %t332)
  br label %bb78
bb78:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t335, i64 %t336)
  br label %bb79
bb79:
  %t339 = load ptr, ptr %l11, !tbaa !29
  %t341 = getelementptr %"compiler/ast:StructBody", ptr %t339, i32 0, i32 4
  %t342 = load { i64, ptr }, ptr %t341, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t342, 0
  %t346 = icmp sgt i64 %t344, 0
  br i1 %t346, label %bb80, label %bb81
bb80:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t348)
  store i64 %t350, ptr %l215
  br label %bb82
bb81:
  br label %bb96
bb82:
  %t351 = load i64, ptr %l215, !tbaa !24
  store i64 %t351, ptr %l26, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s26
  %t352 = load ptr, ptr %l11, !tbaa !29
  %t354 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fnames_2efieldNames(ptr %v1, ptr %s26, ptr %t352)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t354, ptr %l217
  br label %bb83
bb83:
  %t355 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l217
  %t356 = call ptr @__olang_scope_alloc_a(ptr %s26, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t355, ptr %t356
  store ptr %t356, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s27
  %t358 = load i64, ptr %l28, !tbaa !24
  store i64 %t358, ptr %l219, !tbaa !24
  %t359 = load ptr, ptr %l27, !tbaa !29
  %t361 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s26, ptr %t359)
  store i64 %t361, ptr %l221
  br label %bb85
bb85:
  %t362 = load i64, ptr %l219, !tbaa !24
  %t363 = load i64, ptr %l221, !tbaa !24
  %t364 = icmp slt i64 %t362, %t363
  %t366 = xor i1 %t364, true
  br i1 %t366, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s27)
  br label %bb93
bb87:
  br label %bb88
bb88:
  %t368 = load ptr, ptr %l27, !tbaa !29
  %t369 = load i64, ptr %l28, !tbaa !24
  %t372 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s26, ptr %t368, i64 %t369)
  store i32 %t372, ptr %l226
  br label %bb89
bb89:
  %t373 = load i32, ptr %l226, !tbaa !23
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l227, !tbaa !29
  store i32 %t373, ptr %l228, !tbaa !23
  %t376 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s27, i32 0, i32 0)
  store %"compiler/source:Span" %t376, ptr %l229
  br label %bb90
bb90:
  %t377 = load ptr, ptr %l227, !tbaa !29
  %t378 = load i32, ptr %l228, !tbaa !23
  %t379 = load %"compiler/source:Span", ptr %l229
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t377, i32 %t378, %"compiler/source:Span" %t379, i32 1)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s27)
  br label %bb92
bb92:
  %t381 = load i64, ptr %l28, !tbaa !24
  %t383 = add i64 %t381, 1
  store i64 %t383, ptr %l28, !tbaa !24
  br label %bb84
bb93:
  call void @__olang_scope_close(ptr %s26)
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l11, !tbaa !29
  %t388 = getelementptr %"compiler/ast:StructBody", ptr %t386, i32 0, i32 4
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t385, { i64, ptr } %t389)
  br label %bb94
bb94:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load i64, ptr %l26, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t392, i64 %t393)
  br label %bb95
bb95:
  br label %bb96
bb96:
  br label %bb171
bb97:
  %t396 = load ptr, ptr %l10, !tbaa !29
  store ptr %t396, ptr %l238, !tbaa !29
  store i1 false, ptr %l239, !tbaa !21
  %t397 = load ptr, ptr %l238, !tbaa !29
  %t398 = icmp ne ptr %t397, null
  br i1 %t398, label %bb98, label %bb99
bb98:
  %t400 = load ptr, ptr %l238, !tbaa !29
  %t401 = load i64, ptr %t400, !range !{i64 0, i64 5}
  %t403 = icmp eq i64 %t401, 1
  store i1 %t403, ptr %l239, !tbaa !21
  br label %bb99
bb99:
  %t404 = load i1, ptr %l239, !tbaa !21
  br i1 %t404, label %bb100, label %bb101
bb100:
  %t405 = load ptr, ptr %l10, !tbaa !29
  %t407 = getelementptr { i64, [6 x i64] }, ptr %t405, i32 0, i32 1
  %t408 = getelementptr { { i64, ptr }, ptr }, ptr %t407, i32 0, i32 0
  %t409 = load { i64, ptr }, ptr %t408
  store { i64, ptr } %t409, ptr %l30, !tbaa !27
  %t411 = load ptr, ptr %l10, !tbaa !29
  %t413 = getelementptr { i64, [6 x i64] }, ptr %t411, i32 0, i32 1
  %t414 = getelementptr { { i64, ptr }, ptr }, ptr %t413, i32 0, i32 1
  %t415 = load ptr, ptr %t414
  store ptr %t415, ptr %l31, !tbaa !29
  br label %bb102
bb101:
  br label %bb123
bb102:
  %t417 = load ptr, ptr %l31, !tbaa !29
  %t419 = icmp eq ptr %t417, null
  %t421 = xor i1 %t419, true
  br i1 %t421, label %bb103, label %bb104
bb103:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t423, ptr %t424)
  br label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb106
bb106:
  %t428 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t428, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t430 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t432 = extractvalue { i64, ptr } %t430, 0
  store i64 %t432, ptr %l34, !tbaa !24
  br label %bb107
bb107:
  %t434 = load i64, ptr %l33, !tbaa !24
  %t435 = load i64, ptr %l34, !tbaa !24
  %t438 = icmp slt i64 %t434, %t435
  %t440 = xor i1 %t438, true
  br i1 %t440, label %bb108, label %bb109
bb108:
  br label %bb122
bb109:
  br label %bb110
bb110:
  %t442 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t442, ptr %l259, !tbaa !27
  %t443 = load i64, ptr %l33, !tbaa !24
  %t445 = getelementptr { i64, ptr }, ptr %l259, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !27
  %t447 = getelementptr ptr, ptr %t446, i64 %t443
  %t448 = load ptr, ptr %t447, !tbaa !39
  %t452 = getelementptr %"compiler/ast:CaseDecl", ptr %t448, i32 0, i32 2
  %t453 = load { i64, ptr }, ptr %t452, !tbaa !27
  store { i64, ptr } %t453, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t455 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t457 = extractvalue { i64, ptr } %t455, 0
  store i64 %t457, ptr %l38, !tbaa !24
  br label %bb111
bb111:
  %t459 = load i64, ptr %l37, !tbaa !24
  %t460 = load i64, ptr %l38, !tbaa !24
  %t463 = icmp slt i64 %t459, %t460
  %t465 = xor i1 %t463, true
  br i1 %t465, label %bb112, label %bb113
bb112:
  br label %bb120
bb113:
  br label %bb114
bb114:
  %t467 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t467, ptr %l270, !tbaa !27
  %t468 = load i64, ptr %l37, !tbaa !24
  %t470 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !27
  %t472 = getelementptr ptr, ptr %t471, i64 %t468
  %t473 = load ptr, ptr %t472, !tbaa !39
  store ptr %t473, ptr %l39, !tbaa !29
  %t475 = load ptr, ptr %l39, !tbaa !29
  %t477 = getelementptr %"compiler/ast:Param", ptr %t475, i32 0, i32 2
  %t478 = load ptr, ptr %t477, !tbaa !29
  %t480 = icmp eq ptr %t478, null
  %t482 = xor i1 %t480, true
  br i1 %t482, label %bb115, label %bb116
bb115:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load ptr, ptr %l39, !tbaa !29
  %t487 = getelementptr %"compiler/ast:Param", ptr %t485, i32 0, i32 2
  %t488 = load ptr, ptr %t487, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t484, ptr %t488)
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t491 = load i64, ptr %l37, !tbaa !24
  %t493 = add i64 %t491, 1
  store i64 %t493, ptr %l37, !tbaa !24
  br label %bb111
bb120:
  br label %bb121
bb121:
  %t495 = load i64, ptr %l33, !tbaa !24
  %t497 = add i64 %t495, 1
  store i64 %t497, ptr %l33, !tbaa !24
  br label %bb107
bb122:
  br label %bb171
bb123:
  %t499 = load ptr, ptr %l10, !tbaa !29
  store ptr %t499, ptr %l284, !tbaa !29
  store i1 false, ptr %l285, !tbaa !21
  %t500 = load ptr, ptr %l284, !tbaa !29
  %t501 = icmp ne ptr %t500, null
  br i1 %t501, label %bb124, label %bb125
bb124:
  %t503 = load ptr, ptr %l284, !tbaa !29
  %t504 = load i64, ptr %t503, !range !{i64 0, i64 5}
  %t506 = icmp eq i64 %t504, 2
  store i1 %t506, ptr %l285, !tbaa !21
  br label %bb125
bb125:
  %t507 = load i1, ptr %l285, !tbaa !21
  br i1 %t507, label %bb126, label %bb127
bb126:
  %t508 = load ptr, ptr %l10, !tbaa !29
  %t510 = getelementptr { i64, [6 x i64] }, ptr %t508, i32 0, i32 1
  %t511 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t510, i32 0, i32 0
  %t512 = load { i64, ptr }, ptr %t511
  store { i64, ptr } %t512, ptr %l40, !tbaa !27
  %t514 = load ptr, ptr %l10, !tbaa !29
  %t516 = getelementptr { i64, [6 x i64] }, ptr %t514, i32 0, i32 1
  %t517 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t516, i32 0, i32 1
  %t518 = load { i64, ptr }, ptr %t517
  store { i64, ptr } %t518, ptr %l41, !tbaa !27
  %t520 = load ptr, ptr %l10, !tbaa !29
  %t522 = getelementptr { i64, [6 x i64] }, ptr %t520, i32 0, i32 1
  %t523 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t522, i32 0, i32 2
  %t524 = load { i64, ptr }, ptr %t523
  store { i64, ptr } %t524, ptr %l42, !tbaa !27
  br label %bb128
bb127:
  br label %bb153
bb128:
  %t526 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t526, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t528 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t530 = extractvalue { i64, ptr } %t528, 0
  store i64 %t530, ptr %l45, !tbaa !24
  br label %bb129
bb129:
  %t532 = load i64, ptr %l44, !tbaa !24
  %t533 = load i64, ptr %l45, !tbaa !24
  %t536 = icmp slt i64 %t532, %t533
  %t538 = xor i1 %t536, true
  br i1 %t538, label %bb130, label %bb131
bb130:
  br label %bb135
bb131:
  br label %bb132
bb132:
  %t540 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t540, ptr %l301, !tbaa !27
  %t541 = load i64, ptr %l44, !tbaa !24
  %t543 = getelementptr { i64, ptr }, ptr %l301, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = getelementptr ptr, ptr %t544, i64 %t541
  %t546 = load ptr, ptr %t545, !tbaa !39
  %t548 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t548, ptr %t546)
  br label %bb133
bb133:
  br label %bb134
bb134:
  %t553 = load i64, ptr %l44, !tbaa !24
  %t555 = add i64 %t553, 1
  store i64 %t555, ptr %l44, !tbaa !24
  br label %bb129
bb135:
  %t557 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t557, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  %t559 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t561 = extractvalue { i64, ptr } %t559, 0
  store i64 %t561, ptr %l49, !tbaa !24
  br label %bb136
bb136:
  %t563 = load i64, ptr %l48, !tbaa !24
  %t564 = load i64, ptr %l49, !tbaa !24
  %t567 = icmp slt i64 %t563, %t564
  %t569 = xor i1 %t567, true
  br i1 %t569, label %bb137, label %bb138
bb137:
  br label %bb142
bb138:
  br label %bb139
bb139:
  %t571 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t571, ptr %l316, !tbaa !27
  %t572 = load i64, ptr %l48, !tbaa !24
  %t574 = getelementptr { i64, ptr }, ptr %l316, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = getelementptr ptr, ptr %t575, i64 %t572
  %t577 = load ptr, ptr %t576, !tbaa !39
  %t579 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t579, ptr %t577)
  br label %bb140
bb140:
  br label %bb141
bb141:
  %t584 = load i64, ptr %l48, !tbaa !24
  %t586 = add i64 %t584, 1
  store i64 %t586, ptr %l48, !tbaa !24
  br label %bb136
bb142:
  %t588 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t588, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t590 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t592 = extractvalue { i64, ptr } %t590, 0
  store i64 %t592, ptr %l53, !tbaa !24
  br label %bb143
bb143:
  %t594 = load i64, ptr %l52, !tbaa !24
  %t595 = load i64, ptr %l53, !tbaa !24
  %t598 = icmp slt i64 %t594, %t595
  %t600 = xor i1 %t598, true
  br i1 %t600, label %bb144, label %bb145
bb144:
  br label %bb152
bb145:
  br label %bb146
bb146:
  %t602 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t602, ptr %l331, !tbaa !27
  %t603 = load i64, ptr %l52, !tbaa !24
  %t605 = getelementptr { i64, ptr }, ptr %l331, i32 0, i32 1
  %t606 = load ptr, ptr %t605, !tbaa !27
  %t607 = getelementptr ptr, ptr %t606, i64 %t603
  %t608 = load ptr, ptr %t607, !tbaa !39
  store ptr %t608, ptr %l54, !tbaa !29
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t612 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t610)
  store i64 %t612, ptr %l335
  br label %bb147
bb147:
  %t613 = load i64, ptr %l335, !tbaa !24
  store i64 %t613, ptr %l55, !tbaa !24
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load ptr, ptr %l54, !tbaa !29
  %t616 = load ptr, ptr %l54, !tbaa !29
  %t618 = getelementptr %"compiler/ast:Func", ptr %t616, i32 0, i32 3
  %t619 = load ptr, ptr %t618, !tbaa !29
  %t621 = getelementptr %"compiler/ast:Sig", ptr %t619, i32 0, i32 5
  %t622 = load ptr, ptr %t621, !tbaa !29
  %t624 = icmp eq ptr %t622, null
  %t626 = xor i1 %t624, true
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t614, ptr %t615, i1 %t626)
  br label %bb148
bb148:
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t631 = load ptr, ptr %l54, !tbaa !29
  %t633 = getelementptr %"compiler/ast:Func", ptr %t631, i32 0, i32 3
  %t634 = load ptr, ptr %t633, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2econtract(ptr %v0, ptr %v1, ptr %t630, ptr %t634)
  br label %bb149
bb149:
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t638 = load i64, ptr %l55, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t637, i64 %t638)
  br label %bb150
bb150:
  br label %bb151
bb151:
  %t641 = load i64, ptr %l52, !tbaa !24
  %t643 = add i64 %t641, 1
  store i64 %t643, ptr %l52, !tbaa !24
  br label %bb143
bb152:
  br label %bb171
bb153:
  %t645 = load ptr, ptr %l10, !tbaa !29
  store ptr %t645, ptr %l350, !tbaa !29
  store i1 false, ptr %l351, !tbaa !21
  %t646 = load ptr, ptr %l350, !tbaa !29
  %t647 = icmp ne ptr %t646, null
  br i1 %t647, label %bb154, label %bb155
bb154:
  %t649 = load ptr, ptr %l350, !tbaa !29
  %t650 = load i64, ptr %t649, !range !{i64 0, i64 5}
  %t652 = icmp eq i64 %t650, 3
  store i1 %t652, ptr %l351, !tbaa !21
  br label %bb155
bb155:
  %t653 = load i1, ptr %l351, !tbaa !21
  br i1 %t653, label %bb156, label %bb157
bb156:
  %t654 = load ptr, ptr %l10, !tbaa !29
  %t656 = getelementptr { i64, [6 x i64] }, ptr %t654, i32 0, i32 1
  %t657 = getelementptr { ptr, ptr }, ptr %t656, i32 0, i32 0
  %t658 = load ptr, ptr %t657
  store ptr %t658, ptr %l56, !tbaa !29
  %t660 = load ptr, ptr %l10, !tbaa !29
  %t662 = getelementptr { i64, [6 x i64] }, ptr %t660, i32 0, i32 1
  %t663 = getelementptr { ptr, ptr }, ptr %t662, i32 0, i32 1
  %t664 = load ptr, ptr %t663
  store ptr %t664, ptr %l57, !tbaa !29
  br label %bb158
bb157:
  br label %bb164
bb158:
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t667 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t666, ptr %t667)
  br label %bb159
bb159:
  %t671 = load ptr, ptr %l57, !tbaa !29
  %t673 = icmp eq ptr %t671, null
  %t675 = xor i1 %t673, true
  br i1 %t675, label %bb160, label %bb161
bb160:
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t678 = load ptr, ptr %l57, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efunc(ptr %v0, ptr %v1, ptr %t677, ptr %t678)
  br label %bb162
bb161:
  br label %bb163
bb162:
  br label %bb163
bb163:
  br label %bb171
bb164:
  %t681 = load ptr, ptr %l10, !tbaa !29
  store ptr %t681, ptr %l366, !tbaa !29
  store i1 false, ptr %l367, !tbaa !21
  %t682 = load ptr, ptr %l366, !tbaa !29
  %t683 = icmp ne ptr %t682, null
  br i1 %t683, label %bb165, label %bb166
bb165:
  %t685 = load ptr, ptr %l366, !tbaa !29
  %t686 = load i64, ptr %t685, !range !{i64 0, i64 5}
  %t688 = icmp eq i64 %t686, 4
  store i1 %t688, ptr %l367, !tbaa !21
  br label %bb166
bb166:
  %t689 = load i1, ptr %l367, !tbaa !21
  br i1 %t689, label %bb167, label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb170
bb169:
  br label %bb171
bb170:
  call void @__olang_check_failed(ptr @olang_loc_c9535db678f42df0_760e0f7ff8ef7f34)
  unreachable
bb171:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i32
  %l20 = alloca %"compiler/names:Ref"
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i64
  %l31 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i32
  %l41 = alloca %"compiler/names:Ref"
  %l44 = alloca { i64, ptr }
  %l45 = alloca i1
  %l47 = alloca %"compiler/names:Ref"
  %l49 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/names:Table", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t10, i32 %t11)
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l14
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18, !prof !99
ok.18:
  store i64 %t15, ptr %l13
  br label %bb2
bb2:
  %t19 = load i64, ptr %l13, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load i64, ptr %l1, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t30 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s1, i32 4, i64 %t25, i64 %t26)
  store %"compiler/names:Ref" %t30, ptr %l20
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/names:Ref", ptr %l20
  store %"compiler/names:Ref" %t31, ptr %rv
  br label %ret
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/names:Resolver", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t34, i32 %t35)
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l26
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb11, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l25
  br label %bb10
bb10:
  %t43 = load i64, ptr %l25, !tbaa !24
  store i64 %t43, ptr %l21, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb13
bb13:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 4, ptr %l29
  %t49 = load i64, ptr %l4, !tbaa !24
  store i64 %t49, ptr %l30, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/names:Resolver", ptr %t50, i32 0, i32 1
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t52, i64 %t53)
  store ptr %t56, ptr %l35
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t59 = getelementptr %"compiler/names:Table", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t59, i32 %t60)
  %t64 = extractvalue { i32, i64 } %t63, 1
  %t65 = extractvalue { i32, i64 } %t63, 0
  store i32 %t65, ptr %l40
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb18, label %ok.67, !prof !99
ok.67:
  store i64 %t64, ptr %l39
  br label %bb17
bb17:
  %t68 = load i64, ptr %l39, !tbaa !24
  store i64 %t68, ptr %l31, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l31, !tbaa !24
  br label %bb20
bb20:
  %t69 = load i32, ptr %l29, !range !{i32 0, i32 9}
  %t70 = load i64, ptr %l30, !tbaa !24
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 %t69, i64 %t70, i64 %t71)
  store %"compiler/names:Ref" %t72, ptr %l41
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t73 = load %"compiler/names:Ref", ptr %l41
  store %"compiler/names:Ref" %t73, ptr %rv
  br label %ret
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t74, i32 %t75)
  store { i64, ptr } %t78, ptr %l44
  br label %bb23
bb23:
  %t79 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t80 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t79)
  store i1 %t80, ptr %l45
  br label %bb24
bb24:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s3, i32 7, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t83, ptr %l47
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t84 = load %"compiler/names:Ref", ptr %l47
  store %"compiler/names:Ref" %t84, ptr %rv
  br label %ret
bb28:
  %t86 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t86, ptr %l49
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load %"compiler/names:Ref", ptr %l49
  store %"compiler/names:Ref" %t87, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeParams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l25 = alloca { i64, ptr }
  %l35 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l45 = alloca i64
  %l48 = alloca i64
  %l50 = alloca %"compiler/names:Ref"
  %l60 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l25, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 6
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeParam", ptr %t34, i32 0, i32 0
  %t37 = getelementptr %"compiler/source:Span", ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr %"compiler/ast:TypeParam", ptr %t39, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t47 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t29, i64 %t33, i32 %t38, i32 %t42)
  store %"compiler/source:Span" %t47, ptr %l35
  br label %bb8
bb8:
  %t48 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t48, ptr %l6
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = getelementptr %"compiler/ast:TypeParam", ptr %t50, i32 0, i32 1
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t49, i32 %t53, %"compiler/source:Span" %t54, i32 8)
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t60, ptr %l42
  store i32 8, ptr %l43
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/names:Resolver", ptr %t61, i32 0, i32 6
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l45, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/names:Resolver", ptr %t65, i32 0, i32 7
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t67)
  store i64 %t69, ptr %l48
  br label %bb10
bb10:
  %t70 = load i64, ptr %l48, !tbaa !24
  %t71 = sub i64 %t70, 1
  %t72 = load i32, ptr %l43, !range !{i32 0, i32 9}
  %t73 = load i64, ptr %l45, !tbaa !24
  %t75 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s3, i32 %t72, i64 %t73, i64 %t71)
  store %"compiler/names:Ref" %t75, ptr %l50
  br label %bb11
bb11:
  %t76 = load ptr, ptr %l41, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l42
  %t78 = load %"compiler/names:Ref", ptr %l50
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t76, %"compiler/source:Span" %t77, %"compiler/names:Ref" %t78)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t79 = load i64, ptr %l3, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l3, !tbaa !24
  br label %bb4
bb14:
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t83, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb16, label %bb17
bb16:
  br label %bb31
bb17:
  br label %bb18
bb18:
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t97, ptr %l60, !tbaa !27
  %t98 = load i64, ptr %l8, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr ptr, ptr %t101, i64 %t98
  %t103 = load ptr, ptr %t102, !tbaa !39
  store ptr %t103, ptr %l10, !tbaa !29
  %t105 = load ptr, ptr %l10, !tbaa !29
  %t107 = getelementptr %"compiler/ast:TypeParam", ptr %t105, i32 0, i32 2
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = icmp eq ptr %t108, null
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb19, label %bb20
bb19:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l10, !tbaa !29
  %t117 = getelementptr %"compiler/ast:TypeParam", ptr %t115, i32 0, i32 2
  %t118 = load ptr, ptr %t117, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t114, ptr %t118)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t121 = load ptr, ptr %l10, !tbaa !29
  %t123 = getelementptr %"compiler/ast:TypeParam", ptr %t121, i32 0, i32 3
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l13, !tbaa !24
  br label %bb23
bb23:
  %t130 = load i64, ptr %l12, !tbaa !24
  %t131 = load i64, ptr %l13, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t138 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t138, ptr %l78, !tbaa !27
  %t139 = load i64, ptr %l12, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr ptr, ptr %t142, i64 %t139
  %t144 = load ptr, ptr %t143, !tbaa !39
  %t146 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t146, ptr %t144)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l12, !tbaa !24
  br label %bb23
bb29:
  br label %bb30
bb30:
  %t155 = load i64, ptr %l8, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l8, !tbaa !24
  br label %bb15
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypePath(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/load:Import"
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca %"compiler/names:Ref"
  %l20 = alloca { i64, ptr }
  %l22 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i32
  %l30 = alloca i1
  %l34 = alloca %"compiler/names:local"
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l43 = alloca %"compiler/names:Ref"
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/names:Ref"
  %l51 = alloca { i64, ptr }
  %l53 = alloca i64
  %l58 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca i32
  %l67 = alloca %"compiler/names:Ref"
  %l73 = alloca %"compiler/source:Span"
  %l78 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i1
  %l90 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l96 = alloca i1
  %l98 = alloca i1
  %l104 = alloca ptr
  %l108 = alloca i1
  %l110 = alloca i1
  %l113 = alloca i1
  %l116 = alloca ptr
  %l118 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l121 = alloca { i64, ptr }
  %l122 = alloca %"compiler/msgs:Nearest"
  %l129 = alloca ptr
  %l132 = alloca i64
  %l134 = alloca i64
  %l139 = alloca %"compiler/load:Import"
  %l148 = alloca ptr
  %l153 = alloca { i64, [3 x i64] }
  %l156 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l161 = alloca %"compiler/msgs:Msg"
  %l162 = alloca i64
  %l165 = alloca i1
  %l169 = alloca ptr
  %l175 = alloca ptr
  %l179 = alloca i64
  %l183 = alloca i64
  %l186 = alloca { i64, ptr }
  %l194 = alloca %"compiler/names:Ref"
  %l195 = alloca ptr
  %l196 = alloca i64
  %l197 = alloca %"compiler/names:Ref"
  %l198 = alloca i32
  %l199 = alloca i32
  %l202 = alloca { i64, ptr }
  %l207 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l20, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i32, ptr %t9, i64 0
  %t11 = load i32, ptr %t10, !tbaa !33
  store i32 %t11, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/names:Resolver", ptr %t13, i32 0, i32 8
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t15, i32 %t16)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l27
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb4, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l26
  br label %bb3
bb2:
  br label %bb18
bb3:
  %t24 = load i64, ptr %l26, !tbaa !24
  store i64 %t24, ptr %l22, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l22, !tbaa !24
  store i64 %t25, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 7
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t32, i64 %t33)
  store %"compiler/names:local" %t36, ptr %l34
  br label %bb9
bb8:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb10
bb9:
  %t37 = getelementptr %"compiler/names:local", ptr %l34, i32 0, i32 2
  %t38 = load i32, ptr %t37, !range !{i32 0, i32 9}
  %t40 = trunc i64 8 to i32
  %t41 = icmp eq i32 %t38, %t40
  store i1 %t41, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l30, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l37, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t45, ptr %l38
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/names:Resolver", ptr %t46, i32 0, i32 6
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t54 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 8, i64 %t49, i64 %t50)
  store %"compiler/names:Ref" %t54, ptr %l43
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t55 = load ptr, ptr %l37, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l38
  %t57 = load %"compiler/names:Ref", ptr %l43
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t55, %"compiler/source:Span" %t56, %"compiler/names:Ref" %t57)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb15:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l44, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t59, ptr %l45
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/names:Resolver", ptr %t61, i32 0, i32 6
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = load i32, ptr %l3, !tbaa !23
  %t69 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeIn(ptr %v0, ptr %t60, i64 %t64, i32 %t65)
  store %"compiler/names:Ref" %t69, ptr %l50
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l44, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l45
  %t72 = load %"compiler/names:Ref", ptr %l50
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t70, %"compiler/source:Span" %t71, %"compiler/names:Ref" %t72)
  br label %bb17
bb17:
  br label %ret
bb18:
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t73, ptr %l51, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 0
  %t77 = load i32, ptr %t76, !tbaa !33
  store i32 %t77, ptr %l5, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/names:Resolver", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/names:Resolver", ptr %t82, i32 0, i32 6
  %t85 = load i64, ptr %t84, !tbaa !24
  %t88 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t81, i64 %t85)
  store ptr %t88, ptr %l58
  br label %bb19
bb19:
  %t89 = load ptr, ptr %l58, !tbaa !29
  %t91 = getelementptr %"compiler/names:Table", ptr %t89, i32 0, i32 3
  %t92 = load i32, ptr %l5, !tbaa !23
  %t95 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t91, i32 %t92)
  %t96 = extractvalue { i32, i64 } %t95, 1
  %t97 = extractvalue { i32, i64 } %t95, 0
  store i32 %t97, ptr %l63
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb21, label %ok.99, !prof !99
ok.99:
  store i64 %t96, ptr %l62
  br label %bb20
bb20:
  %t100 = load i64, ptr %l62, !tbaa !24
  store i64 %t100, ptr %l53, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb23
bb23:
  %t101 = load i64, ptr %l53, !tbaa !24
  %t102 = icmp slt i64 %t101, 0
  br i1 %t102, label %bb24, label %bb25
bb24:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l5, !tbaa !23
  %t108 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t104, i32 %t105)
  store %"compiler/names:Ref" %t108, ptr %l67
  br label %bb26
bb25:
  br label %bb82
bb26:
  %t109 = load %"compiler/names:Ref", ptr %l67
  store %"compiler/names:Ref" %t109, ptr %l6
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/names:Resolver", ptr %t111, i32 0, i32 6
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t116 = load i32, ptr %t115, !tbaa !23
  %t117 = load i32, ptr %l5, !tbaa !23
  %t122 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t110, i64 %t114, i32 %t116, i32 %t117)
  store %"compiler/source:Span" %t122, ptr %l73
  br label %bb27
bb27:
  %t123 = load %"compiler/source:Span", ptr %l73
  store %"compiler/source:Span" %t123, ptr %l7
  %t124 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t125 = load i32, ptr %t124, !range !{i32 0, i32 9}
  %t127 = trunc i64 0 to i32
  %t128 = icmp eq i32 %t125, %t127
  br i1 %t128, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/names:Resolver", ptr %t130, i32 0, i32 15
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t132)
  store i64 %t134, ptr %l78
  br label %bb30
bb29:
  br label %bb72
bb30:
  %t135 = load i64, ptr %l78, !tbaa !24
  store i64 %t135, ptr %l8, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l7
  %t138 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %t136, %"compiler/source:Span" %t137, i32 %t138)
  br label %bb31
bb31:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/names:Resolver", ptr %t142, i32 0, i32 15
  %t146 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t144)
  store i64 %t146, ptr %l84
  br label %bb32
bb32:
  %t147 = load i64, ptr %l8, !tbaa !24
  %t148 = load i64, ptr %l84, !tbaa !24
  %t150 = icmp eq i64 %t148, %t147
  br i1 %t150, label %bb33, label %bb34
bb33:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/names:Resolver", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/load:Loader", ptr %t155, i32 0, i32 0
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  store { i64, ptr } %t158, ptr %l90, !tbaa !27
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l5, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t159, i32 %t160)
  store { i64, ptr } %t163, ptr %l93
  br label %bb35
bb34:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb37
bb35:
  %t164 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t170 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t165, i64 %t166)
  %t178 = getelementptr i8, ptr %t177, i64 %t166
  call void @olang_textcopy(ptr %t178, ptr %t167, i64 %t168)
  %t179 = getelementptr i8, ptr %t178, i64 %t168
  call void @olang_textcopy(ptr %t179, ptr %t171, i64 %t172)
  %t180 = getelementptr i8, ptr %t179, i64 %t172
  call void @olang_textcopy(ptr %t180, ptr %t174, i64 %t175)
  %t181 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t177, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = extractvalue { i64, ptr } %t182, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  %t191 = call i1 @std_2fos_2eExists(ptr %s4, { i64, ptr } %t189)
  store i1 %t191, ptr %l96
  br label %bb36
bb36:
  %t192 = load i1, ptr %l96, !tbaa !21
  %t193 = xor i1 %t192, true
  store i1 %t193, ptr %l87, !tbaa !21
  br label %bb37
bb37:
  %t195 = load i1, ptr %l87, !tbaa !21
  br i1 %t195, label %bb38, label %bb39
bb38:
  %t196 = load i32, ptr %l5, !tbaa !23
  store i32 %t196, ptr %l9, !tbaa !23
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/names:Resolver", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/names:Resolver", ptr %t201, i32 0, i32 6
  %t204 = load i64, ptr %t203, !tbaa !24
  %t207 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t200, i64 %t204)
  store ptr %t207, ptr %l104
  br label %bb40
bb39:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb42
bb40:
  %t208 = load ptr, ptr %l104, !tbaa !29
  %t210 = getelementptr %"compiler/names:Table", ptr %t208, i32 0, i32 4
  %t211 = load i32, ptr %l9, !tbaa !23
  %t214 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t210, i32 %t211)
  store i1 %t214, ptr %l108
  br label %bb41
bb41:
  %t215 = load i1, ptr %l108, !tbaa !21
  %t216 = xor i1 %t215, true
  store i1 %t216, ptr %l98, !tbaa !21
  br label %bb42
bb42:
  %t218 = load i1, ptr %l98, !tbaa !21
  br i1 %t218, label %bb43, label %bb44
bb43:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr %l5, !tbaa !23
  %t223 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eImportSaid(ptr %v0, ptr %t219, i32 %t220)
  store i1 %t223, ptr %l113
  br label %bb45
bb44:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb46
bb45:
  %t224 = load i1, ptr %l113, !tbaa !21
  %t225 = xor i1 %t224, true
  store i1 %t225, ptr %l110, !tbaa !21
  br label %bb46
bb46:
  %t227 = load i1, ptr %l110, !tbaa !21
  br i1 %t227, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s6
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/names:Resolver", ptr %t228, i32 0, i32 15
  store ptr %t230, ptr %l116, !tbaa !29
  %t231 = load i32, ptr %l5, !tbaa !23
  %t233 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s6, i32 %t231, i64 -1)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t233, ptr %l118
  br label %bb49
bb48:
  br label %bb71
bb49:
  %t234 = load ptr, ptr %l116, !tbaa !29
  %t235 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l118
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %t234, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t235)
  br label %bb50
bb50:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i32, ptr %l5, !tbaa !23
  %t240 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t236, i32 %t237)
  store { i64, ptr } %t240, ptr %l121
  br label %bb51
bb51:
  %t241 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t242 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s6, { i64, ptr } %t241)
  store %"compiler/msgs:Nearest" %t242, ptr %l122
  br label %bb52
bb52:
  %t243 = load %"compiler/msgs:Nearest", ptr %l122
  %t244 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t243, ptr %t244
  store ptr %t244, ptr %l10, !tbaa !29
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/names:Resolver", ptr %t246, i32 0, i32 0
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/load:Loader", ptr %t249, i32 0, i32 5
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/names:Resolver", ptr %t252, i32 0, i32 6
  %t255 = load i64, ptr %t254, !tbaa !24
  %t258 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t251, i64 %t255)
  store ptr %t258, ptr %l129
  br label %bb53
bb53:
  %t259 = load ptr, ptr %l129, !tbaa !29
  %t261 = getelementptr %"compiler/load:Module", ptr %t259, i32 0, i32 11
  store ptr %t261, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb54
bb54:
  %t263 = load i64, ptr %l12, !tbaa !24
  store i64 %t263, ptr %l132, !tbaa !24
  %t264 = load ptr, ptr %l11, !tbaa !29
  %t266 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t264)
  store i64 %t266, ptr %l134
  br label %bb55
bb55:
  %t267 = load i64, ptr %l132, !tbaa !24
  %t268 = load i64, ptr %l134, !tbaa !24
  %t269 = icmp slt i64 %t267, %t268
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb56, label %bb57
bb56:
  br label %bb65
bb57:
  br label %bb58
bb58:
  %t273 = load ptr, ptr %l11, !tbaa !29
  %t274 = load i64, ptr %l12, !tbaa !24
  %t277 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t273, i64 %t274)
  store %"compiler/load:Import" %t277, ptr %l139
  br label %bb59
bb59:
  %t278 = load %"compiler/load:Import", ptr %l139
  store %"compiler/load:Import" %t278, ptr %l13
  %t279 = getelementptr %"compiler/load:Import", ptr %l13, i32 0, i32 5
  %t280 = load i64, ptr %t279, !tbaa !24
  %t282 = icmp sge i64 %t280, 0
  br i1 %t282, label %bb60, label %bb61
bb60:
  %t284 = load ptr, ptr %l10, !tbaa !29
  %t285 = getelementptr %"compiler/load:Import", ptr %l13, i32 0, i32 2
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s6, ptr %v0, ptr %t284, { i64, ptr } %t286)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t289 = load i64, ptr %l12, !tbaa !24
  %t291 = add i64 %t289, 1
  store i64 %t291, ptr %l12, !tbaa !24
  br label %bb54
bb65:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/names:Resolver", ptr %t293, i32 0, i32 0
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/load:Loader", ptr %t296, i32 0, i32 4
  %t299 = load ptr, ptr %t298, !tbaa !29
  store ptr %t299, ptr %l148, !tbaa !29
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/names:Resolver", ptr %t301, i32 0, i32 6
  %t304 = load i64, ptr %t303, !tbaa !24
  %t305 = load %"compiler/source:Span", ptr %l7
  %t309 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t300, i64 %t304, %"compiler/source:Span" %t305)
  store { i64, [3 x i64] } %t309, ptr %l153
  br label %bb66
bb66:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load i32, ptr %l5, !tbaa !23
  %t314 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s6, ptr %t310, i32 %t311)
  store { i64, ptr } %t314, ptr %l156
  br label %bb67
bb67:
  %t315 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 0
  %t317 = extractvalue { i64, ptr } %t315, 1
  %t318 = mul i64 %t316, 1
  %t319 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t318)
  call void @llvm.memcpy.p0.p0.i64(ptr %t319, ptr %t317, i64 %t318, i1 false)
  %t320 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  store { i64, ptr } %t321, ptr %l157, !tbaa !27
  %t322 = load ptr, ptr %l10, !tbaa !29
  %t324 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s6, ptr %s6, ptr %t322)
  store { i64, ptr } %t324, ptr %l159
  br label %bb68
bb68:
  %t325 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t325, 0
  %t327 = extractvalue { i64, ptr } %t325, 1
  %t328 = mul i64 %t326, 1
  %t329 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t328)
  call void @llvm.memcpy.p0.p0.i64(ptr %t329, ptr %t327, i64 %t328, i1 false)
  %t330 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t329, 1
  %t332 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t334 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownImport(ptr %s6, ptr %s6, ptr %s6, { i64, ptr } %t332, { i64, ptr } %t331)
  store %"compiler/msgs:Msg" %t334, ptr %l161
  br label %bb69
bb69:
  %t335 = load ptr, ptr %l148, !tbaa !29
  %t336 = load { i64, [3 x i64] }, ptr %l153
  %t337 = load %"compiler/msgs:Msg", ptr %l161
  %t338 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s6, ptr %t335, { i64, [3 x i64] } %t336, %"compiler/msgs:Msg" %t337)
  store i64 %t338, ptr %l162
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s6)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb72:
  %t339 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t340 = load i32, ptr %t339, !range !{i32 0, i32 9}
  %t342 = trunc i64 4 to i32
  %t343 = icmp eq i32 %t340, %t342
  br i1 %t343, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l165, !tbaa !21
  br label %bb75
bb74:
  %t345 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t346 = load i32, ptr %t345, !range !{i32 0, i32 9}
  %t348 = trunc i64 7 to i32
  %t349 = icmp eq i32 %t346, %t348
  store i1 %t349, ptr %l165, !tbaa !21
  br label %bb75
bb75:
  %t351 = load i1, ptr %l165, !tbaa !21
  br i1 %t351, label %bb76, label %bb77
bb76:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/names:Resolver", ptr %t352, i32 0, i32 5
  store ptr %t354, ptr %l169, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/names:Resolver", ptr %t355, i32 0, i32 0
  %t358 = load ptr, ptr %t357, !tbaa !29
  %t360 = getelementptr %"compiler/load:Loader", ptr %t358, i32 0, i32 5
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/names:Resolver", ptr %t361, i32 0, i32 6
  %t364 = load i64, ptr %t363, !tbaa !24
  %t367 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t360, i64 %t364)
  store ptr %t367, ptr %l175
  br label %bb78
bb77:
  br label %bb81
bb78:
  %t368 = load ptr, ptr %l175, !tbaa !29
  %t370 = getelementptr %"compiler/load:Module", ptr %t368, i32 0, i32 4
  %t371 = load i64, ptr %t370, !tbaa !24
  %t372 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t373 = load i32, ptr %t372, !tbaa !23
  %t376 = call i64 @compiler_2fnames_2ekey(i64 %t371, i32 %t373)
  store i64 %t376, ptr %l179
  br label %bb79
bb79:
  %t377 = load %"compiler/names:Ref", ptr %l6
  %t378 = load ptr, ptr %l169, !tbaa !29
  %t379 = load i64, ptr %l179, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t378, i64 %t379, %"compiler/names:Ref" %t377)
  br label %bb80
bb80:
  br label %bb81
bb81:
  br label %ret
bb82:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t385 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasModule(ptr %v0, ptr %v1, ptr %t381, { i64, ptr } %t382)
  store i64 %t385, ptr %l183
  br label %bb83
bb83:
  %t386 = load i64, ptr %l183, !tbaa !24
  store i64 %t386, ptr %l14, !tbaa !24
  %t387 = load i64, ptr %l14, !tbaa !24
  %t389 = icmp sge i64 %t387, 0
  br i1 %t389, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s12
  %t391 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t391, ptr %l186, !tbaa !27
  %t392 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t396 = sub i64 %t394, 1
  %t398 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i32, ptr %t399, i64 %t396
  %t401 = load i32, ptr %t400, !tbaa !33
  store i32 %t401, ptr %l15, !tbaa !23
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t404 = load i64, ptr %l14, !tbaa !24
  %t405 = load i32, ptr %l15, !tbaa !23
  %t409 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ememberOf(ptr %v0, ptr %t403, i64 %t404, i32 %t405)
  store %"compiler/names:Ref" %t409, ptr %l194
  br label %bb86
bb85:
  br label %bb91
bb86:
  %t410 = load %"compiler/names:Ref", ptr %l194
  store %"compiler/names:Ref" %t410, ptr %l16
  %t411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t411, ptr %l195, !tbaa !29
  %t412 = load i64, ptr %l14, !tbaa !24
  store i64 %t412, ptr %l196, !tbaa !24
  %t413 = load %"compiler/names:Ref", ptr %l16
  store %"compiler/names:Ref" %t413, ptr %l197
  %t414 = load i32, ptr %l15, !tbaa !23
  store i32 %t414, ptr %l198, !tbaa !23
  %t415 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t416 = load i32, ptr %t415, !tbaa !23
  store i32 %t416, ptr %l199, !tbaa !23
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load i32, ptr %l15, !tbaa !23
  %t421 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t417, i32 %t418)
  store { i64, ptr } %t421, ptr %l202
  br label %bb87
bb87:
  %t422 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t423 = extractvalue { i64, ptr } %t422, 0
  %t425 = trunc i64 %t423 to i32
  %t426 = load i32, ptr %l199, !tbaa !23
  %t428 = sub i32 %t426, %t425
  %t429 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t430 = load i32, ptr %t429, !tbaa !23
  %t433 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s12, i32 %t428, i32 %t430)
  store %"compiler/source:Span" %t433, ptr %l207
  br label %bb88
bb88:
  %t434 = load ptr, ptr %l195, !tbaa !29
  %t435 = load i64, ptr %l196, !tbaa !24
  %t436 = load %"compiler/names:Ref", ptr %l197
  %t437 = load i32, ptr %l198, !tbaa !23
  %t438 = load %"compiler/source:Span", ptr %l207
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enotPrivate(ptr %v0, ptr %t434, i64 %t435, %"compiler/names:Ref" %t436, i32 %t437, %"compiler/source:Span" %t438)
  br label %bb89
bb89:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load %"compiler/source:Span", ptr %l1
  %t441 = load %"compiler/names:Ref", ptr %l16
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t439, %"compiler/source:Span" %t440, %"compiler/names:Ref" %t441)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s12)
  br label %bb91
bb91:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca %"compiler/names:Ref"
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i1
  %l69 = alloca i64
  %l72 = alloca i64
  %l91 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l98 = alloca i1
  %l111 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  %l174 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l199 = alloca ptr
  %l200 = alloca i1
  %l213 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l226 = alloca i1
  %l238 = alloca i1
  %l241 = alloca { i64, ptr }
  %l242 = alloca i1
  %l246 = alloca %"compiler/names:Ref"
  %l247 = alloca ptr
  %l248 = alloca ptr
  %l250 = alloca i64
  %l252 = alloca %"compiler/source:Span"
  %l255 = alloca %"compiler/source:Span"
  %l259 = alloca ptr
  %l260 = alloca i1
  %l267 = alloca ptr
  %l268 = alloca i1
  %l276 = alloca ptr
  %l277 = alloca i1
  %l289 = alloca { i64, ptr }
  %s32 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t6 = load ptr, ptr %l51, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l51, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 7}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l52, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l52, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t28, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  br label %bb8
bb7:
  br label %bb23
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l2
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypePath(ptr %v0, ptr %v1, ptr %t32, %"compiler/source:Span" %t33, { i64, ptr } %t34)
  br label %bb9
bb9:
  store i64 0, ptr %l5, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb15
bb12:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l72, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb14
bb14:
  %t68 = load i64, ptr %l72, !tbaa !24
  store i64 %t68, ptr %l69, !tbaa !24
  br label %bb15
bb15:
  %t69 = load i64, ptr %l69, !tbaa !24
  store i64 %t69, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t89, ptr %l91, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr ptr, ptr %t93, i64 %t86
  %t95 = load ptr, ptr %t94, !tbaa !39
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t88, ptr %t95)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t99 = load i64, ptr %l9, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l9, !tbaa !24
  br label %bb16
bb22:
  br label %bb150
bb23:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t104 = load ptr, ptr %l97, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb24, label %bb25
bb24:
  %t107 = load ptr, ptr %l97, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 7}
  %t110 = icmp eq i64 %t108, 1
  store i1 %t110, ptr %l98, !tbaa !21
  br label %bb25
bb25:
  %t111 = load i1, ptr %l98, !tbaa !21
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l11, !tbaa !29
  br label %bb28
bb27:
  br label %bb53
bb28:
  %t118 = load ptr, ptr %l11, !tbaa !29
  %t120 = getelementptr %"compiler/ast:Sig", ptr %t118, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  store i64 %t125, ptr %l14, !tbaa !24
  br label %bb29
bb29:
  %t127 = load i64, ptr %l13, !tbaa !24
  %t128 = load i64, ptr %l14, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb30, label %bb31
bb30:
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t135 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t135, ptr %l111, !tbaa !27
  %t136 = load i64, ptr %l13, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr ptr, ptr %t139, i64 %t136
  %t141 = load ptr, ptr %t140, !tbaa !39
  store ptr %t141, ptr %l15, !tbaa !29
  %t143 = load ptr, ptr %l15, !tbaa !29
  %t145 = getelementptr %"compiler/ast:Param", ptr %t143, i32 0, i32 2
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = icmp eq ptr %t146, null
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb33, label %bb34
bb33:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l15, !tbaa !29
  %t155 = getelementptr %"compiler/ast:Param", ptr %t153, i32 0, i32 2
  %t156 = load ptr, ptr %t155, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t152, ptr %t156)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t159 = load i64, ptr %l13, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l13, !tbaa !24
  br label %bb29
bb38:
  %t163 = load ptr, ptr %l11, !tbaa !29
  %t165 = getelementptr %"compiler/ast:Sig", ptr %t163, i32 0, i32 1
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l18, !tbaa !24
  br label %bb39
bb39:
  %t172 = load i64, ptr %l17, !tbaa !24
  %t173 = load i64, ptr %l18, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb40, label %bb41
bb40:
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t180 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t180, ptr %l131, !tbaa !27
  %t181 = load i64, ptr %l17, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr ptr, ptr %t184, i64 %t181
  %t186 = load ptr, ptr %t185, !tbaa !39
  %t188 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t188, ptr %t186)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t193 = load i64, ptr %l17, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l17, !tbaa !24
  br label %bb39
bb45:
  %t197 = load ptr, ptr %l11, !tbaa !29
  %t199 = getelementptr %"compiler/ast:Sig", ptr %t197, i32 0, i32 3
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  store { i64, ptr } %t200, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t202 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  store i64 %t204, ptr %l22, !tbaa !24
  br label %bb46
bb46:
  %t206 = load i64, ptr %l21, !tbaa !24
  %t207 = load i64, ptr %l22, !tbaa !24
  %t210 = icmp slt i64 %t206, %t207
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb47, label %bb48
bb47:
  br label %bb52
bb48:
  br label %bb49
bb49:
  %t214 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t214, ptr %l147, !tbaa !27
  %t215 = load i64, ptr %l21, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr ptr, ptr %t218, i64 %t215
  %t220 = load ptr, ptr %t219, !tbaa !39
  %t222 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t222, ptr %t220)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t227 = load i64, ptr %l21, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l21, !tbaa !24
  br label %bb46
bb52:
  br label %bb150
bb53:
  %t231 = load ptr, ptr %l1, !tbaa !29
  store ptr %t231, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t232 = load ptr, ptr %l155, !tbaa !29
  %t233 = icmp ne ptr %t232, null
  br i1 %t233, label %bb54, label %bb55
bb54:
  %t235 = load ptr, ptr %l155, !tbaa !29
  %t236 = load i64, ptr %t235, !range !{i64 0, i64 7}
  %t238 = icmp eq i64 %t236, 2
  store i1 %t238, ptr %l156, !tbaa !21
  br label %bb55
bb55:
  %t239 = load i1, ptr %l156, !tbaa !21
  br i1 %t239, label %bb56, label %bb57
bb56:
  %t240 = load ptr, ptr %l1, !tbaa !29
  %t242 = getelementptr { i64, [5 x i64] }, ptr %t240, i32 0, i32 1
  %t243 = getelementptr { %"compiler/source:Span", ptr }, ptr %t242, i32 0, i32 1
  %t244 = load ptr, ptr %t243
  store ptr %t244, ptr %l24, !tbaa !29
  br label %bb58
bb57:
  br label %bb102
bb58:
  %t246 = load ptr, ptr %l24, !tbaa !29
  store ptr %t246, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t247 = load ptr, ptr %l161, !tbaa !29
  %t248 = icmp ne ptr %t247, null
  br i1 %t248, label %bb59, label %bb60
bb59:
  %t250 = load ptr, ptr %l161, !tbaa !29
  %t251 = load i64, ptr %t250, !range !{i64 0, i64 5}
  %t253 = icmp eq i64 %t251, 1
  store i1 %t253, ptr %l162, !tbaa !21
  br label %bb60
bb60:
  %t254 = load i1, ptr %l162, !tbaa !21
  br i1 %t254, label %bb61, label %bb62
bb61:
  %t255 = load ptr, ptr %l24, !tbaa !29
  %t257 = getelementptr { i64, [6 x i64] }, ptr %t255, i32 0, i32 1
  %t258 = getelementptr { { i64, ptr }, ptr }, ptr %t257, i32 0, i32 0
  %t259 = load { i64, ptr }, ptr %t258
  store { i64, ptr } %t259, ptr %l25, !tbaa !27
  br label %bb63
bb62:
  br label %bb80
bb63:
  %t261 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t261, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t263 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t263, 0
  store i64 %t265, ptr %l28, !tbaa !24
  br label %bb64
bb64:
  %t267 = load i64, ptr %l27, !tbaa !24
  %t268 = load i64, ptr %l28, !tbaa !24
  %t271 = icmp slt i64 %t267, %t268
  %t273 = xor i1 %t271, true
  br i1 %t273, label %bb65, label %bb66
bb65:
  br label %bb79
bb66:
  br label %bb67
bb67:
  %t275 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t275, ptr %l174, !tbaa !27
  %t276 = load i64, ptr %l27, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr ptr, ptr %t279, i64 %t276
  %t281 = load ptr, ptr %t280, !tbaa !39
  %t285 = getelementptr %"compiler/ast:CaseDecl", ptr %t281, i32 0, i32 2
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  store { i64, ptr } %t286, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t288 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t288, 0
  store i64 %t290, ptr %l32, !tbaa !24
  br label %bb68
bb68:
  %t292 = load i64, ptr %l31, !tbaa !24
  %t293 = load i64, ptr %l32, !tbaa !24
  %t296 = icmp slt i64 %t292, %t293
  %t298 = xor i1 %t296, true
  br i1 %t298, label %bb69, label %bb70
bb69:
  br label %bb77
bb70:
  br label %bb71
bb71:
  %t300 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t300, ptr %l185, !tbaa !27
  %t301 = load i64, ptr %l31, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr ptr, ptr %t304, i64 %t301
  %t306 = load ptr, ptr %t305, !tbaa !39
  store ptr %t306, ptr %l33, !tbaa !29
  %t308 = load ptr, ptr %l33, !tbaa !29
  %t310 = getelementptr %"compiler/ast:Param", ptr %t308, i32 0, i32 2
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = icmp eq ptr %t311, null
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb72, label %bb73
bb72:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load ptr, ptr %l33, !tbaa !29
  %t320 = getelementptr %"compiler/ast:Param", ptr %t318, i32 0, i32 2
  %t321 = load ptr, ptr %t320, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t317, ptr %t321)
  br label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t324 = load i64, ptr %l31, !tbaa !24
  %t326 = add i64 %t324, 1
  store i64 %t326, ptr %l31, !tbaa !24
  br label %bb68
bb77:
  br label %bb78
bb78:
  %t328 = load i64, ptr %l27, !tbaa !24
  %t330 = add i64 %t328, 1
  store i64 %t330, ptr %l27, !tbaa !24
  br label %bb64
bb79:
  br label %bb101
bb80:
  %t332 = load ptr, ptr %l24, !tbaa !29
  store ptr %t332, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t333 = load ptr, ptr %l199, !tbaa !29
  %t334 = icmp ne ptr %t333, null
  br i1 %t334, label %bb81, label %bb82
bb81:
  %t336 = load ptr, ptr %l199, !tbaa !29
  %t337 = load i64, ptr %t336, !range !{i64 0, i64 5}
  %t339 = icmp eq i64 %t337, 0
  store i1 %t339, ptr %l200, !tbaa !21
  br label %bb82
bb82:
  %t340 = load i1, ptr %l200, !tbaa !21
  br i1 %t340, label %bb83, label %bb84
bb83:
  %t341 = load ptr, ptr %l24, !tbaa !29
  %t343 = getelementptr { i64, [6 x i64] }, ptr %t341, i32 0, i32 1
  %t344 = getelementptr { ptr }, ptr %t343, i32 0, i32 0
  %t345 = load ptr, ptr %t344
  store ptr %t345, ptr %l34, !tbaa !29
  br label %bb85
bb84:
  br label %bb96
bb85:
  %t347 = load ptr, ptr %l34, !tbaa !29
  %t349 = getelementptr %"compiler/ast:StructBody", ptr %t347, i32 0, i32 0
  %t350 = load { i64, ptr }, ptr %t349, !tbaa !27
  store { i64, ptr } %t350, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t352 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t352, 0
  store i64 %t354, ptr %l37, !tbaa !24
  br label %bb86
bb86:
  %t356 = load i64, ptr %l36, !tbaa !24
  %t357 = load i64, ptr %l37, !tbaa !24
  %t360 = icmp slt i64 %t356, %t357
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb87, label %bb88
bb87:
  br label %bb95
bb88:
  br label %bb89
bb89:
  %t364 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t364, ptr %l213, !tbaa !27
  %t365 = load i64, ptr %l36, !tbaa !24
  %t367 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = getelementptr ptr, ptr %t368, i64 %t365
  %t370 = load ptr, ptr %t369, !tbaa !39
  store ptr %t370, ptr %l38, !tbaa !29
  %t372 = load ptr, ptr %l38, !tbaa !29
  %t374 = getelementptr %"compiler/ast:Param", ptr %t372, i32 0, i32 2
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t377 = icmp eq ptr %t375, null
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb90, label %bb91
bb90:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l38, !tbaa !29
  %t384 = getelementptr %"compiler/ast:Param", ptr %t382, i32 0, i32 2
  %t385 = load ptr, ptr %t384, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t381, ptr %t385)
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t388 = load i64, ptr %l36, !tbaa !24
  %t390 = add i64 %t388, 1
  store i64 %t390, ptr %l36, !tbaa !24
  br label %bb86
bb95:
  br label %bb101
bb96:
  br i1 true, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_3ee91b253925870d_db61affc9a997151)
  unreachable
bb101:
  br label %bb150
bb102:
  %t392 = load ptr, ptr %l1, !tbaa !29
  store ptr %t392, ptr %l225, !tbaa !29
  store i1 false, ptr %l226, !tbaa !21
  %t393 = load ptr, ptr %l225, !tbaa !29
  %t394 = icmp ne ptr %t393, null
  br i1 %t394, label %bb103, label %bb104
bb103:
  %t396 = load ptr, ptr %l225, !tbaa !29
  %t397 = load i64, ptr %t396, !range !{i64 0, i64 7}
  %t399 = icmp eq i64 %t397, 3
  store i1 %t399, ptr %l226, !tbaa !21
  br label %bb104
bb104:
  %t400 = load i1, ptr %l226, !tbaa !21
  br i1 %t400, label %bb105, label %bb106
bb105:
  %t401 = load ptr, ptr %l1, !tbaa !29
  %t403 = getelementptr { i64, [5 x i64] }, ptr %t401, i32 0, i32 1
  %t404 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t403, i32 0, i32 1
  %t405 = load ptr, ptr %t404
  store ptr %t405, ptr %l39, !tbaa !29
  %t407 = load ptr, ptr %l1, !tbaa !29
  %t409 = getelementptr { i64, [5 x i64] }, ptr %t407, i32 0, i32 1
  %t410 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t409, i32 0, i32 2
  %t411 = load i32, ptr %t410
  store i32 %t411, ptr %l40, !tbaa !23
  br label %bb107
bb106:
  br label %bb122
bb107:
  store %olang.scope zeroinitializer, ptr %s32
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t413, ptr %t414)
  br label %bb108
bb108:
  %t418 = load i32, ptr %l40, !tbaa !23
  %t420 = icmp ne i32 %t418, 0
  br i1 %t420, label %bb109, label %bb110
bb109:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load i32, ptr %l40, !tbaa !23
  %t426 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t422, i32 %t423)
  store { i64, ptr } %t426, ptr %l241
  br label %bb111
bb110:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb113
bb111:
  %t427 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t428 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s32, { i64, ptr } %t427, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t428, ptr %l242
  br label %bb112
bb112:
  %t429 = load i1, ptr %l242, !tbaa !21
  %t430 = xor i1 %t429, true
  store i1 %t430, ptr %l238, !tbaa !21
  br label %bb113
bb113:
  %t432 = load i1, ptr %l238, !tbaa !21
  br i1 %t432, label %bb114, label %bb115
bb114:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load i32, ptr %l40, !tbaa !23
  %t437 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t433, i32 %t434)
  store %"compiler/names:Ref" %t437, ptr %l246
  br label %bb116
bb115:
  br label %bb121
bb116:
  %t438 = load %"compiler/names:Ref", ptr %l246
  store %"compiler/names:Ref" %t438, ptr %l41
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l247, !tbaa !29
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l248, !tbaa !29
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/names:Resolver", ptr %t441, i32 0, i32 6
  %t444 = load i64, ptr %t443, !tbaa !24
  store i64 %t444, ptr %l250, !tbaa !24
  %t445 = load ptr, ptr %l39, !tbaa !29
  %t447 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t445)
  store %"compiler/source:Span" %t447, ptr %l252
  br label %bb117
bb117:
  %t448 = getelementptr %"compiler/source:Span", ptr %l252, i32 0, i32 1
  %t449 = load i32, ptr %t448, !tbaa !23
  %t450 = load i32, ptr %l40, !tbaa !23
  %t451 = load ptr, ptr %l248, !tbaa !29
  %t452 = load i64, ptr %l250, !tbaa !24
  %t455 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t451, i64 %t452, i32 %t449, i32 %t450)
  store %"compiler/source:Span" %t455, ptr %l255
  br label %bb118
bb118:
  %t456 = load %"compiler/names:Ref", ptr %l41
  %t457 = load ptr, ptr %l247, !tbaa !29
  %t458 = load %"compiler/source:Span", ptr %l255
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t457, %"compiler/source:Span" %t458, %"compiler/names:Ref" %t456)
  br label %bb119
bb119:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load %"compiler/names:Ref", ptr %l41
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eread(ptr %v0, ptr %t460, %"compiler/names:Ref" %t461)
  br label %bb120
bb120:
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s32)
  br label %bb150
bb122:
  %t464 = load ptr, ptr %l1, !tbaa !29
  store ptr %t464, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t465 = load ptr, ptr %l259, !tbaa !29
  %t466 = icmp ne ptr %t465, null
  br i1 %t466, label %bb123, label %bb124
bb123:
  %t468 = load ptr, ptr %l259, !tbaa !29
  %t469 = load i64, ptr %t468, !range !{i64 0, i64 7}
  %t471 = icmp eq i64 %t469, 4
  store i1 %t471, ptr %l260, !tbaa !21
  br label %bb124
bb124:
  %t472 = load i1, ptr %l260, !tbaa !21
  br i1 %t472, label %bb125, label %bb126
bb125:
  %t473 = load ptr, ptr %l1, !tbaa !29
  %t475 = getelementptr { i64, [5 x i64] }, ptr %t473, i32 0, i32 1
  %t476 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t475, i32 0, i32 1
  %t477 = load ptr, ptr %t476
  store ptr %t477, ptr %l42, !tbaa !29
  br label %bb127
bb126:
  br label %bb129
bb127:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t479, ptr %t480)
  br label %bb128
bb128:
  br label %bb150
bb129:
  %t483 = load ptr, ptr %l1, !tbaa !29
  store ptr %t483, ptr %l267, !tbaa !29
  store i1 false, ptr %l268, !tbaa !21
  %t484 = load ptr, ptr %l267, !tbaa !29
  %t485 = icmp ne ptr %t484, null
  br i1 %t485, label %bb130, label %bb131
bb130:
  %t487 = load ptr, ptr %l267, !tbaa !29
  %t488 = load i64, ptr %t487, !range !{i64 0, i64 7}
  %t490 = icmp eq i64 %t488, 5
  store i1 %t490, ptr %l268, !tbaa !21
  br label %bb131
bb131:
  %t491 = load i1, ptr %l268, !tbaa !21
  br i1 %t491, label %bb132, label %bb133
bb132:
  %t492 = load ptr, ptr %l1, !tbaa !29
  %t494 = getelementptr { i64, [5 x i64] }, ptr %t492, i32 0, i32 1
  %t495 = getelementptr { %"compiler/source:Span", ptr }, ptr %t494, i32 0, i32 1
  %t496 = load ptr, ptr %t495
  store ptr %t496, ptr %l43, !tbaa !29
  br label %bb134
bb133:
  br label %bb136
bb134:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t499 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t498, ptr %t499)
  br label %bb135
bb135:
  br label %bb150
bb136:
  %t503 = load ptr, ptr %l1, !tbaa !29
  store ptr %t503, ptr %l276, !tbaa !29
  store i1 false, ptr %l277, !tbaa !21
  %t504 = load ptr, ptr %l276, !tbaa !29
  %t505 = icmp ne ptr %t504, null
  br i1 %t505, label %bb137, label %bb138
bb137:
  %t507 = load ptr, ptr %l276, !tbaa !29
  %t508 = load i64, ptr %t507, !range !{i64 0, i64 7}
  %t510 = icmp eq i64 %t508, 6
  store i1 %t510, ptr %l277, !tbaa !21
  br label %bb138
bb138:
  %t511 = load i1, ptr %l277, !tbaa !21
  br i1 %t511, label %bb139, label %bb140
bb139:
  %t512 = load ptr, ptr %l1, !tbaa !29
  %t514 = getelementptr { i64, [5 x i64] }, ptr %t512, i32 0, i32 1
  %t515 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t514, i32 0, i32 1
  %t516 = load { i64, ptr }, ptr %t515
  store { i64, ptr } %t516, ptr %l44, !tbaa !27
  br label %bb141
bb140:
  br label %bb149
bb141:
  %t518 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t518, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  %t520 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t522 = extractvalue { i64, ptr } %t520, 0
  store i64 %t522, ptr %l47, !tbaa !24
  br label %bb142
bb142:
  %t524 = load i64, ptr %l46, !tbaa !24
  %t525 = load i64, ptr %l47, !tbaa !24
  %t528 = icmp slt i64 %t524, %t525
  %t530 = xor i1 %t528, true
  br i1 %t530, label %bb143, label %bb144
bb143:
  br label %bb148
bb144:
  br label %bb145
bb145:
  %t532 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t532, ptr %l289, !tbaa !27
  %t533 = load i64, ptr %l46, !tbaa !24
  %t535 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !27
  %t537 = getelementptr ptr, ptr %t536, i64 %t533
  %t538 = load ptr, ptr %t537, !tbaa !39
  %t540 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t540, ptr %t538)
  br label %bb146
bb146:
  br label %bb147
bb147:
  %t545 = load i64, ptr %l46, !tbaa !24
  %t547 = add i64 %t545, 1
  store i64 %t547, ptr %l46, !tbaa !24
  br label %bb142
bb148:
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_a7c82f44040ceddc_d58c094e813108c0)
  unreachable
bb150:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l13 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca { i64, ptr }
  %l27 = alloca i1
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l42 = alloca i1
  %l48 = alloca ptr
  %l50 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l53 = alloca ptr
  %l58 = alloca { i64, [3 x i64] }
  %l61 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l65 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 6
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t5, i64 %t9)
  store ptr %t12, ptr %l13
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t15 = getelementptr %"compiler/names:Table", ptr %t13, i32 0, i32 4
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l17
  br label %bb2
bb2:
  %t20 = load i1, ptr %l17, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l20
  br label %bb6
bb6:
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/load:Loader", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = extractvalue { i64, ptr } %t33, 0
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t42 = extractvalue { i64, ptr } %t34, 1
  %t43 = extractvalue { i64, ptr } %t34, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t36, i64 %t37)
  %t49 = getelementptr i8, ptr %t48, i64 %t37
  call void @olang_textcopy(ptr %t49, ptr %t38, i64 %t39)
  %t50 = getelementptr i8, ptr %t49, i64 %t39
  call void @olang_textcopy(ptr %t50, ptr %t42, i64 %t43)
  %t51 = getelementptr i8, ptr %t50, i64 %t43
  call void @olang_textcopy(ptr %t51, ptr %t45, i64 %t46)
  %t52 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t48, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t62 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t60)
  store i1 %t62, ptr %l27
  br label %bb7
bb7:
  %t63 = load i1, ptr %l27, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/names:Resolver", ptr %t66, i32 0, i32 15
  store ptr %t68, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t70 = load i64, ptr %l6, !tbaa !24
  store i64 %t70, ptr %l31, !tbaa !24
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l33
  br label %bb12
bb12:
  %t74 = load i64, ptr %l31, !tbaa !24
  %t75 = load i64, ptr %l33, !tbaa !24
  %t76 = icmp slt i64 %t74, %t75
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb13, label %bb14
bb13:
  br label %bb24
bb14:
  br label %bb15
bb15:
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Hd32f6fdf378a1d4c0e47f8552643012d(ptr %v0, ptr %t80, i64 %t81)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t84, ptr %l38
  br label %bb16
bb16:
  %t85 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l38
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t85, ptr %l7
  %t86 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l7, i32 0, i32 0
  %t87 = load i32, ptr %t86, !tbaa !23
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = icmp eq i32 %t87, %t88
  br i1 %t91, label %bb17, label %bb18
bb17:
  %t93 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l7, i32 0, i32 1
  %t94 = load i64, ptr %t93, !tbaa !24
  %t96 = icmp eq i64 %t94, -1
  store i1 %t96, ptr %l42, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb19
bb19:
  %t98 = load i1, ptr %l42, !tbaa !21
  br i1 %t98, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t99 = load i64, ptr %l6, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l6, !tbaa !24
  br label %bb11
bb24:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/names:Resolver", ptr %t103, i32 0, i32 15
  store ptr %t105, ptr %l48, !tbaa !29
  %t106 = load i32, ptr %l2, !tbaa !23
  %t108 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s0, i32 %t106, i64 -1)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t108, ptr %l50
  br label %bb25
bb25:
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t110 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %t109, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t110)
  br label %bb26
bb26:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/names:Resolver", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/load:Loader", ptr %t114, i32 0, i32 4
  %t117 = load ptr, ptr %t116, !tbaa !29
  store ptr %t117, ptr %l53, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/names:Resolver", ptr %t119, i32 0, i32 6
  %t122 = load i64, ptr %t121, !tbaa !24
  %t127 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t118, i64 %t122, %"compiler/source:Span" %a1)
  store { i64, [3 x i64] } %t127, ptr %l58
  br label %bb27
bb27:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l2, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t128, i32 %t129)
  store { i64, ptr } %t132, ptr %l61
  br label %bb28
bb28:
  %t133 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t140 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t143 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownImportStd(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t139, { i64, ptr } %t140)
  store %"compiler/msgs:Msg" %t143, ptr %l64
  br label %bb29
bb29:
  %t144 = load ptr, ptr %l53, !tbaa !29
  %t145 = load { i64, [3 x i64] }, ptr %l58
  %t146 = load %"compiler/msgs:Msg", ptr %l64
  %t147 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s0, ptr %t144, { i64, [3 x i64] } %t145, %"compiler/msgs:Msg" %t146)
  store i64 %t147, ptr %l65
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownInCond(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l13 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l41 = alloca i1
  %l49 = alloca ptr
  %l53 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l56 = alloca ptr
  %l61 = alloca { i64, [3 x i64] }
  %l64 = alloca { i64, ptr }
  %l67 = alloca %"compiler/msgs:Msg"
  %l68 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 6
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t5, i64 %t9)
  store ptr %t12, ptr %l13
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t15 = getelementptr %"compiler/names:Table", ptr %t13, i32 0, i32 4
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l17
  br label %bb2
bb2:
  %t20 = load i1, ptr %l17, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l20
  br label %bb6
bb6:
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esuggests(ptr %v0, ptr %v0, ptr %t27, { i64, ptr } %t28)
  store i1 %t31, ptr %l23
  br label %bb7
bb7:
  %t32 = load i1, ptr %l23, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb11
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eimportedType(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l27
  br label %bb10
bb10:
  %t38 = load i1, ptr %l27, !tbaa !21
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l24, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 15
  store ptr %t42, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t44 = load i64, ptr %l6, !tbaa !24
  store i64 %t44, ptr %l30, !tbaa !24
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t45)
  store i64 %t47, ptr %l32
  br label %bb16
bb16:
  %t48 = load i64, ptr %l30, !tbaa !24
  %t49 = load i64, ptr %l32, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb17, label %bb18
bb17:
  br label %bb28
bb18:
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Hd32f6fdf378a1d4c0e47f8552643012d(ptr %v0, ptr %t54, i64 %t55)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t58, ptr %l37
  br label %bb20
bb20:
  %t59 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l37
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t59, ptr %l7
  %t60 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l7, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = load i32, ptr %l2, !tbaa !23
  %t65 = icmp eq i32 %t61, %t62
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t67 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l7, i32 0, i32 1
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 14
  %t72 = load i64, ptr %t71, !tbaa !24
  %t75 = icmp eq i64 %t68, %t72
  store i1 %t75, ptr %l41, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t77 = load i1, ptr %l41, !tbaa !21
  br i1 %t77, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb15
bb28:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/names:Resolver", ptr %t82, i32 0, i32 15
  store ptr %t84, ptr %l49, !tbaa !29
  %t85 = load i32, ptr %l2, !tbaa !23
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/names:Resolver", ptr %t86, i32 0, i32 14
  %t89 = load i64, ptr %t88, !tbaa !24
  %t92 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s0, i32 %t85, i64 %t89)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t92, ptr %l53
  br label %bb29
bb29:
  %t93 = load ptr, ptr %l49, !tbaa !29
  %t94 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l53
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %t93, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t94)
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/names:Resolver", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/load:Loader", ptr %t98, i32 0, i32 4
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l56, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/names:Resolver", ptr %t103, i32 0, i32 6
  %t106 = load i64, ptr %t105, !tbaa !24
  %t111 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t102, i64 %t106, %"compiler/source:Span" %a1)
  store { i64, [3 x i64] } %t111, ptr %l61
  br label %bb31
bb31:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l2, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t112, i32 %t113)
  store { i64, ptr } %t116, ptr %l64
  br label %bb32
bb32:
  %t117 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  %t119 = extractvalue { i64, ptr } %t117, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t127 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownBuildName(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t123, { i64, ptr } %t124)
  store %"compiler/msgs:Msg" %t127, ptr %l67
  br label %bb33
bb33:
  %t128 = load ptr, ptr %l56, !tbaa !29
  %t129 = load { i64, [3 x i64] }, ptr %l61
  %t130 = load %"compiler/msgs:Msg", ptr %l67
  %t131 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s0, ptr %t128, { i64, [3 x i64] } %t129, %"compiler/msgs:Msg" %t130)
  store i64 %t131, ptr %l68
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunusedImports(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/load:Import"
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l15 = alloca ptr
  %l18 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca %"compiler/load:Import"
  %l39 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i32
  %l51 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i1
  %l59 = alloca i64
  %l61 = alloca i64
  %l66 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l70 = alloca i1
  %l80 = alloca i1
  %l86 = alloca ptr
  %l90 = alloca { i64, [3 x i64] }
  %l93 = alloca { i64, ptr }
  %l96 = alloca %"compiler/msgs:Msg"
  %l97 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %t7)
  store ptr %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l15, !tbaa !29
  store ptr %t11, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/load:Module", ptr %t12, i32 0, i32 30
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb3:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/load:Module", ptr %t17, i32 0, i32 6
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/names:Resolver", ptr %t25, i32 0, i32 21
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t27, i64 %t28)
  store i1 %t31, ptr %l26
  br label %bb7
bb7:
  %t32 = load i1, ptr %l26, !tbaa !21
  store i1 %t32, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l22, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/load:Module", ptr %t34, i32 0, i32 11
  store ptr %t36, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i64, ptr %l4, !tbaa !24
  store i64 %t38, ptr %l29, !tbaa !24
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l31
  br label %bb13
bb13:
  %t42 = load i64, ptr %l29, !tbaa !24
  %t43 = load i64, ptr %l31, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb15:
  br label %bb16
bb16:
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store %"compiler/load:Import" %t52, ptr %l36
  br label %bb17
bb17:
  %t53 = load %"compiler/load:Import", ptr %l36
  store %"compiler/load:Import" %t53, ptr %l5
  %t54 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 5
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb21
bb19:
  %t59 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 2
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t60, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t62, ptr %l41
  br label %bb20
bb20:
  %t63 = load i1, ptr %l41, !tbaa !21
  store i1 %t63, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t64 = load i1, ptr %l39, !tbaa !21
  br i1 %t64, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb25
bb23:
  %t65 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 2
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t68 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t66)
  store i1 %t68, ptr %l44
  br label %bb24
bb24:
  %t69 = load i1, ptr %l44, !tbaa !21
  store i1 %t69, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t70 = load i1, ptr %l42, !tbaa !21
  br i1 %t70, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb27:
  br label %bb28
bb28:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/names:Resolver", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/load:Loader", ptr %t74, i32 0, i32 3
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 2
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  %t82 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t77, { i64, ptr } %t79)
  store i32 %t82, ptr %l49
  br label %bb29
bb29:
  %t83 = load i32, ptr %l49, !tbaa !23
  store i32 %t83, ptr %l6, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/names:Resolver", ptr %t84, i32 0, i32 19
  store ptr %t86, ptr %l51, !tbaa !29
  %t87 = load i64, ptr %l1, !tbaa !24
  %t88 = load i32, ptr %l6, !tbaa !23
  %t92 = call i64 @compiler_2fnames_2ekey(i64 %t87, i32 %t88)
  store i64 %t92, ptr %l55
  br label %bb30
bb30:
  %t93 = load ptr, ptr %l51, !tbaa !29
  %t94 = load i64, ptr %l55, !tbaa !24
  %t95 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t93, i64 %t94)
  store i1 %t95, ptr %l56
  br label %bb31
bb31:
  %t96 = load i1, ptr %l56, !tbaa !21
  br i1 %t96, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb33:
  br label %bb34
bb34:
  store i1 false, ptr %l7, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/names:Resolver", ptr %t97, i32 0, i32 20
  store ptr %t99, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb35
bb35:
  %t101 = load i64, ptr %l9, !tbaa !24
  store i64 %t101, ptr %l59, !tbaa !24
  %t102 = load ptr, ptr %l8, !tbaa !29
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %t102)
  store i64 %t104, ptr %l61
  br label %bb36
bb36:
  %t105 = load i64, ptr %l59, !tbaa !24
  %t106 = load i64, ptr %l61, !tbaa !24
  %t107 = icmp slt i64 %t105, %t106
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb37, label %bb38
bb37:
  br label %bb52
bb38:
  br label %bb39
bb39:
  %t111 = load ptr, ptr %l8, !tbaa !29
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = call %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H1a77801a5ab3ea58cbf0ff15b43ff2de(ptr %v0, ptr %t111, i64 %t112)
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t115, ptr %l66
  br label %bb40
bb40:
  %t116 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l66
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t116, ptr %l10
  %t117 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l10, i32 0, i32 0
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = load i64, ptr %l1, !tbaa !24
  %t122 = icmp eq i64 %t118, %t119
  br i1 %t122, label %bb41, label %bb42
bb41:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = getelementptr %"compiler/load:Module", ptr %t124, i32 0, i32 6
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = icmp eq ptr %t127, null
  br i1 %t129, label %bb43, label %bb44
bb42:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb47
bb43:
  call void @__olang_check_failed(ptr @olang_loc_9053a89eb2ebe36f_9971388257a6393)
  unreachable
bb44:
  br label %bb45
bb45:
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr %"compiler/load:Module", ptr %t131, i32 0, i32 6
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t137 = getelementptr %"compiler/source:Source", ptr %t134, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t139 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l10, i32 0, i32 1
  %t140 = load %"compiler/source:Span", ptr %t139
  %t141 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 2
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  %t146 = call i1 @compiler_2fnames_2eMentions(ptr %v0, ptr %v0, { i64, ptr } %t138, %"compiler/source:Span" %t140, { i64, ptr } %t142)
  store i1 %t146, ptr %l80
  br label %bb46
bb46:
  %t147 = load i1, ptr %l80, !tbaa !21
  store i1 %t147, ptr %l70, !tbaa !21
  br label %bb47
bb47:
  %t148 = load i1, ptr %l70, !tbaa !21
  br i1 %t148, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t149 = load i64, ptr %l9, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l9, !tbaa !24
  br label %bb35
bb52:
  %t153 = load i1, ptr %l7, !tbaa !21
  br i1 %t153, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb54:
  br label %bb55
bb55:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/names:Resolver", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/load:Loader", ptr %t158, i32 0, i32 4
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l86, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i64, ptr %l1, !tbaa !24
  %t164 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 0
  %t165 = load %"compiler/source:Span", ptr %t164
  %t169 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t162, i64 %t163, %"compiler/source:Span" %t165)
  store { i64, [3 x i64] } %t169, ptr %l90
  br label %bb56
bb56:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l6, !tbaa !23
  %t174 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s3, ptr %t170, i32 %t171)
  store { i64, ptr } %t174, ptr %l93
  br label %bb57
bb57:
  %t175 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t177 = extractvalue { i64, ptr } %t175, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  %t182 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 3
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  %t186 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportUnused(ptr %s3, ptr %v0, ptr %s3, { i64, ptr } %t181, { i64, ptr } %t183)
  store %"compiler/msgs:Msg" %t186, ptr %l96
  br label %bb58
bb58:
  %t187 = load ptr, ptr %l86, !tbaa !29
  %t188 = load { i64, [3 x i64] }, ptr %l90
  %t189 = load %"compiler/msgs:Msg", ptr %l96
  %t190 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t187, { i64, [3 x i64] } %t188, %"compiler/msgs:Msg" %t189)
  store i64 %t190, ptr %l97
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb60:
  %t191 = load i64, ptr %l4, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l4, !tbaa !24
  br label %bb12
bb61:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2evarDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l32 = alloca { i64, ptr }
  %l42 = alloca i1
  %l46 = alloca i1
  %l51 = alloca i1
  %l61 = alloca i64
  %l64 = alloca i64
  %l86 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l107 = alloca i1
  %l123 = alloca { i64, ptr }
  %l130 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:VarDecl", ptr %t11, i32 0, i32 2
  %t14 = load ptr, ptr %t13, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t10, ptr %t14)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:VarDecl", ptr %t17, i32 0, i32 3
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l32, !tbaa !27
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t35
  %t40 = load ptr, ptr %t39, !tbaa !39
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t42, ptr %t40)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l3, !tbaa !24
  br label %bb5
bb11:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/ast:VarDecl", ptr %t51, i32 0, i32 5
  %t54 = load i1, ptr %t53, !tbaa !21
  br i1 %t54, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/ast:VarDecl", ptr %t56, i32 0, i32 2
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  store i1 %t61, ptr %l42, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb14
bb14:
  %t63 = load i1, ptr %l42, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/ast:VarDecl", ptr %t64, i32 0, i32 3
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp eq i64 %t69, 0
  store i1 %t71, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t73 = load i1, ptr %l46, !tbaa !21
  br i1 %t73, label %bb18, label %bb19
bb18:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/ast:VarDecl", ptr %t74, i32 0, i32 4
  %t77 = load i1, ptr %t76, !tbaa !21
  %t79 = xor i1 %t77, true
  store i1 %t79, ptr %l51, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb20
bb20:
  %t81 = load i1, ptr %l51, !tbaa !21
  br i1 %t81, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/ast:VarDecl", ptr %t82, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = icmp sgt i64 %t89, %t90
  br i1 %t93, label %bb24, label %bb25
bb24:
  %t95 = load i64, ptr %l8, !tbaa !24
  %t97 = icmp sgt i64 %t95, 0
  br i1 %t97, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb29
bb26:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = sub i64 %t99, %t100
  %t104 = load i64, ptr %l8, !tbaa !24
  %t107 = add i64 %t103, %t104
  %t109 = sub i64 %t107, 1
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = sdiv i64 %t109, %t110
  store i64 %t113, ptr %l64, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb28
bb28:
  %t115 = load i64, ptr %l64, !tbaa !24
  store i64 %t115, ptr %l61, !tbaa !24
  br label %bb29
bb29:
  %t116 = load i64, ptr %l61, !tbaa !24
  store i64 %t116, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  %t117 = load i64, ptr %l10, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb31, label %bb32
bb31:
  br label %bb40
bb32:
  br label %bb33
bb33:
  %t125 = load i64, ptr %l6, !tbaa !24
  %t126 = load i64, ptr %l10, !tbaa !24
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = mul i64 %t126, %t127
  %t133 = add i64 %t125, %t130
  store i64 %t133, ptr %l11, !tbaa !24
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr %"compiler/ast:VarDecl", ptr %t135, i32 0, i32 5
  %t138 = load i1, ptr %t137, !tbaa !21
  br i1 %t138, label %bb34, label %bb35
bb34:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr %"compiler/ast:VarDecl", ptr %t141, i32 0, i32 0
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %l86, !tbaa !27
  %t145 = load i64, ptr %l11, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i32, ptr %t148, i64 %t145
  %t150 = load i32, ptr %t149, !tbaa !33
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr %"compiler/ast:VarDecl", ptr %t151, i32 0, i32 1
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  store { i64, ptr } %t154, ptr %l90, !tbaa !27
  %t155 = load i64, ptr %l11, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr %"compiler/source:Span", ptr %t158, i64 %t155
  %t160 = load %"compiler/source:Span", ptr %t159
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t140, i32 %t150, %"compiler/source:Span" %t160, i1 true)
  br label %bb36
bb35:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/ast:VarDecl", ptr %t165, i32 0, i32 0
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  store { i64, ptr } %t168, ptr %l95, !tbaa !27
  %t169 = load i64, ptr %l11, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i32, ptr %t172, i64 %t169
  %t174 = load i32, ptr %t173, !tbaa !33
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/ast:VarDecl", ptr %t175, i32 0, i32 1
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l99, !tbaa !27
  %t179 = load i64, ptr %l11, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr %"compiler/source:Span", ptr %t182, i64 %t179
  %t184 = load %"compiler/source:Span", ptr %t183
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %t164, i32 %t174, %"compiler/source:Span" %t184, i1 false)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t188 = load i64, ptr %l10, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l10, !tbaa !24
  br label %bb30
bb40:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr %"compiler/ast:VarDecl", ptr %t192, i32 0, i32 5
  %t195 = load i1, ptr %t194, !tbaa !21
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb41, label %bb42
bb41:
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr %"compiler/ast:VarDecl", ptr %t199, i32 0, i32 3
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t207 = getelementptr %"compiler/ast:VarDecl", ptr %t205, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t213 = icmp eq i64 %t204, %t210
  store i1 %t213, ptr %l107, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb43
bb43:
  %t215 = load i1, ptr %l107, !tbaa !21
  br i1 %t215, label %bb44, label %bb45
bb44:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr %"compiler/ast:VarDecl", ptr %t216, i32 0, i32 0
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  store { i64, ptr } %t219, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t221 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 0
  store i64 %t223, ptr %l14, !tbaa !24
  br label %bb46
bb45:
  br label %bb57
bb46:
  %t225 = load i64, ptr %l13, !tbaa !24
  %t226 = load i64, ptr %l14, !tbaa !24
  %t229 = icmp slt i64 %t225, %t226
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb47, label %bb48
bb47:
  br label %bb56
bb48:
  br label %bb49
bb49:
  %t233 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t233, ptr %l123, !tbaa !27
  %t234 = load i64, ptr %l13, !tbaa !24
  %t236 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr i32, ptr %t237, i64 %t234
  %t239 = load i32, ptr %t238, !tbaa !33
  store i32 %t239, ptr %l15, !tbaa !23
  %t241 = load i32, ptr %l15, !tbaa !23
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/names:Resolver", ptr %t243, i32 0, i32 11
  %t249 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t245, i32 %t241)
  store i1 %t249, ptr %l130
  br label %bb50
bb50:
  %t250 = load i1, ptr %l130, !tbaa !21
  %t251 = xor i1 %t250, true
  br i1 %t251, label %bb51, label %bb52
bb51:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/names:Resolver", ptr %t253, i32 0, i32 11
  %t256 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t255, i32 %t256)
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t259 = load i64, ptr %l13, !tbaa !24
  %t261 = add i64 %t259, 1
  store i64 %t261, ptr %l13, !tbaa !24
  br label %bb46
bb56:
  br label %bb57
bb57:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = getelementptr %"compiler/ast:TopIf", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_c24d94d368b768d0_dc6a7a3b6fd73c94)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TopIf", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitBranch(ptr %v0, ptr %v1, ptr %t14, i64 %t15, ptr %t13)
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TopIf", ptr %t17, i32 0, i32 2
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l14, !tbaa !29
  %t27 = load i64, ptr %l1, !tbaa !24
  store i64 %t27, ptr %l15, !tbaa !24
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TopIf", ptr %t28, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb7, label %bb8
bb6:
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_93653db47984ae2f_98605133537f87a3)
  unreachable
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:TopIf", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load ptr, ptr %l14, !tbaa !29
  %t40 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %t39, i64 %t40, ptr %t38)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/ast:TopIf", ptr %t42, i32 0, i32 3
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l25, !tbaa !29
  %t52 = load i64, ptr %l1, !tbaa !24
  store i64 %t52, ptr %l26, !tbaa !24
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:TopIf", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb14, label %bb15
bb13:
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b66f44eae599aa7e_d468abe9cc136322)
  unreachable
bb15:
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:TopIf", ptr %t60, i32 0, i32 3
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load ptr, ptr %l25, !tbaa !29
  %t65 = load i64, ptr %l26, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitBranch(ptr %v0, ptr %v1, ptr %t64, i64 %t65, ptr %t63)
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitBranch(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca ptr
  %l36 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l106 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l115 = alloca i1
  %l127 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l131 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l167 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l176 = alloca i64
  %l178 = alloca i64
  %l179 = alloca i64
  %l184 = alloca { i64, ptr }
  %l187 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l190 = alloca i32
  %s20 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TopBranch", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/names:Resolver", ptr %t10, i32 0, i32 1
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t12, i64 %t13)
  store ptr %t16, ptr %l36
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l36, !tbaa !29
  store ptr %t17, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopBranch", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb6, label %bb7
bb6:
  br label %bb114
bb7:
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t35, ptr %l45, !tbaa !27
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 %t36
  %t41 = load ptr, ptr %t40, !tbaa !39
  store ptr %t41, ptr %l7, !tbaa !29
  %t43 = load ptr, ptr %l7, !tbaa !29
  store ptr %t43, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t44 = load ptr, ptr %l48, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load ptr, ptr %l48, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 11}
  %t50 = icmp eq i64 %t48, 7
  store i1 %t50, ptr %l49, !tbaa !21
  br label %bb10
bb10:
  %t51 = load i1, ptr %l49, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t52 = load ptr, ptr %l7, !tbaa !29
  %t54 = getelementptr { i64, [6 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l8, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %t58, i64 %t59, ptr %t60)
  br label %bb14
bb14:
  br label %bb112
bb15:
  %t64 = load ptr, ptr %l7, !tbaa !29
  store ptr %t64, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t65 = load ptr, ptr %l57, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb16, label %bb17
bb16:
  %t68 = load ptr, ptr %l57, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 11}
  %t71 = icmp eq i64 %t69, 0
  store i1 %t71, ptr %l58, !tbaa !21
  br label %bb17
bb17:
  %t72 = load i1, ptr %l58, !tbaa !21
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t73 = load ptr, ptr %l7, !tbaa !29
  %t75 = getelementptr { i64, [6 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { ptr }, ptr %t75, i32 0, i32 0
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l9, !tbaa !29
  br label %bb24
bb19:
  %t79 = load ptr, ptr %l7, !tbaa !29
  store ptr %t79, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t80 = load ptr, ptr %l63, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb20, label %bb21
bb20:
  %t83 = load ptr, ptr %l63, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 11}
  %t86 = icmp eq i64 %t84, 1
  store i1 %t86, ptr %l64, !tbaa !21
  br label %bb21
bb21:
  %t87 = load i1, ptr %l64, !tbaa !21
  br i1 %t87, label %bb22, label %bb23
bb22:
  %t88 = load ptr, ptr %l7, !tbaa !29
  %t90 = getelementptr { i64, [6 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { ptr }, ptr %t90, i32 0, i32 0
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l9, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t94 = load ptr, ptr %l3, !tbaa !29
  %t96 = getelementptr %"compiler/names:Table", ptr %t94, i32 0, i32 4
  %t97 = load ptr, ptr %l9, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Func", ptr %t97, i32 0, i32 2
  %t100 = load i32, ptr %t99, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t96, i32 %t100, i1 true)
  br label %bb25
bb25:
  br label %bb112
bb26:
  %t103 = load ptr, ptr %l7, !tbaa !29
  store ptr %t103, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t104 = load ptr, ptr %l73, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l73, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 11}
  %t110 = icmp eq i64 %t108, 2
  store i1 %t110, ptr %l74, !tbaa !21
  br label %bb28
bb28:
  %t111 = load i1, ptr %l74, !tbaa !21
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t112 = load ptr, ptr %l7, !tbaa !29
  %t114 = getelementptr { i64, [6 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l10, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t118 = load ptr, ptr %l3, !tbaa !29
  %t120 = getelementptr %"compiler/names:Table", ptr %t118, i32 0, i32 4
  %t121 = load ptr, ptr %l10, !tbaa !29
  %t123 = getelementptr %"compiler/ast:TypeDecl", ptr %t121, i32 0, i32 0
  %t124 = load i32, ptr %t123, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t120, i32 %t124, i1 true)
  br label %bb32
bb32:
  br label %bb112
bb33:
  %t127 = load ptr, ptr %l7, !tbaa !29
  store ptr %t127, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t128 = load ptr, ptr %l83, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb34, label %bb35
bb34:
  %t131 = load ptr, ptr %l83, !tbaa !29
  %t132 = load i64, ptr %t131, !range !{i64 0, i64 11}
  %t134 = icmp eq i64 %t132, 5
  store i1 %t134, ptr %l84, !tbaa !21
  br label %bb35
bb35:
  %t135 = load i1, ptr %l84, !tbaa !21
  br i1 %t135, label %bb36, label %bb37
bb36:
  %t136 = load ptr, ptr %l7, !tbaa !29
  %t138 = getelementptr { i64, [6 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t138, i32 0, i32 1
  %t140 = load i32, ptr %t139
  store i32 %t140, ptr %l11, !tbaa !23
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t142 = load ptr, ptr %l3, !tbaa !29
  %t144 = getelementptr %"compiler/names:Table", ptr %t142, i32 0, i32 4
  %t145 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t144, i32 %t145, i1 true)
  br label %bb39
bb39:
  br label %bb112
bb40:
  %t148 = load ptr, ptr %l7, !tbaa !29
  store ptr %t148, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t149 = load ptr, ptr %l92, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb41, label %bb42
bb41:
  %t152 = load ptr, ptr %l92, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 11}
  %t155 = icmp eq i64 %t153, 3
  store i1 %t155, ptr %l93, !tbaa !21
  br label %bb42
bb42:
  %t156 = load i1, ptr %l93, !tbaa !21
  br i1 %t156, label %bb43, label %bb44
bb43:
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t159 = getelementptr { i64, [6 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", ptr }, ptr %t159, i32 0, i32 1
  %t161 = load ptr, ptr %t160
  store ptr %t161, ptr %l12, !tbaa !29
  br label %bb45
bb44:
  br label %bb53
bb45:
  %t163 = load ptr, ptr %l12, !tbaa !29
  %t165 = getelementptr %"compiler/ast:VarDecl", ptr %t163, i32 0, i32 0
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l15, !tbaa !24
  br label %bb46
bb46:
  %t172 = load i64, ptr %l14, !tbaa !24
  %t173 = load i64, ptr %l15, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb47, label %bb48
bb47:
  br label %bb52
bb48:
  br label %bb49
bb49:
  %t180 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t180, ptr %l106, !tbaa !27
  %t181 = load i64, ptr %l14, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i32, ptr %t184, i64 %t181
  %t186 = load i32, ptr %t185, !tbaa !33
  %t188 = load ptr, ptr %l3, !tbaa !29
  %t190 = getelementptr %"compiler/names:Table", ptr %t188, i32 0, i32 4
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t190, i32 %t186, i1 true)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t194 = load i64, ptr %l14, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l14, !tbaa !24
  br label %bb46
bb52:
  br label %bb112
bb53:
  %t198 = load ptr, ptr %l7, !tbaa !29
  store ptr %t198, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t199 = load ptr, ptr %l114, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb54, label %bb55
bb54:
  %t202 = load ptr, ptr %l114, !tbaa !29
  %t203 = load i64, ptr %t202, !range !{i64 0, i64 11}
  %t205 = icmp eq i64 %t203, 10
  store i1 %t205, ptr %l115, !tbaa !21
  br label %bb55
bb55:
  %t206 = load i1, ptr %l115, !tbaa !21
  br i1 %t206, label %bb56, label %bb57
bb56:
  %t207 = load ptr, ptr %l7, !tbaa !29
  %t209 = getelementptr { i64, [6 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t209, i32 0, i32 2
  %t211 = load { i64, ptr }, ptr %t210
  store { i64, ptr } %t211, ptr %l17, !tbaa !27
  br label %bb58
bb57:
  br label %bb84
bb58:
  %t213 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t213, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t215 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t215, 0
  store i64 %t217, ptr %l20, !tbaa !24
  br label %bb59
bb59:
  %t219 = load i64, ptr %l19, !tbaa !24
  %t220 = load i64, ptr %l20, !tbaa !24
  %t223 = icmp slt i64 %t219, %t220
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb60, label %bb61
bb60:
  br label %bb83
bb61:
  br label %bb62
bb62:
  %t227 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t227, ptr %l127, !tbaa !27
  %t228 = load i64, ptr %l19, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr ptr, ptr %t231, i64 %t228
  %t233 = load ptr, ptr %t232, !tbaa !39
  store ptr %t233, ptr %l21, !tbaa !29
  %t235 = load ptr, ptr %l21, !tbaa !29
  store ptr %t235, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t236 = load ptr, ptr %l130, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb63, label %bb64
bb63:
  %t239 = load ptr, ptr %l130, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 11}
  %t242 = icmp eq i64 %t240, 1
  store i1 %t242, ptr %l131, !tbaa !21
  br label %bb64
bb64:
  %t243 = load i1, ptr %l131, !tbaa !21
  br i1 %t243, label %bb65, label %bb66
bb65:
  %t244 = load ptr, ptr %l21, !tbaa !29
  %t246 = getelementptr { i64, [6 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { ptr }, ptr %t246, i32 0, i32 0
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l22, !tbaa !29
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t250 = load ptr, ptr %l3, !tbaa !29
  %t252 = getelementptr %"compiler/names:Table", ptr %t250, i32 0, i32 4
  %t253 = load ptr, ptr %l22, !tbaa !29
  %t255 = getelementptr %"compiler/ast:Func", ptr %t253, i32 0, i32 2
  %t256 = load i32, ptr %t255, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t252, i32 %t256, i1 true)
  br label %bb68
bb68:
  br label %bb81
bb69:
  %t259 = load ptr, ptr %l21, !tbaa !29
  store ptr %t259, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t260 = load ptr, ptr %l140, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb70, label %bb71
bb70:
  %t263 = load ptr, ptr %l140, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 11}
  %t266 = icmp eq i64 %t264, 2
  store i1 %t266, ptr %l141, !tbaa !21
  br label %bb71
bb71:
  %t267 = load i1, ptr %l141, !tbaa !21
  br i1 %t267, label %bb72, label %bb73
bb72:
  %t268 = load ptr, ptr %l21, !tbaa !29
  %t270 = getelementptr { i64, [6 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", ptr }, ptr %t270, i32 0, i32 1
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l23, !tbaa !29
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t274 = load ptr, ptr %l3, !tbaa !29
  %t276 = getelementptr %"compiler/names:Table", ptr %t274, i32 0, i32 4
  %t277 = load ptr, ptr %l23, !tbaa !29
  %t279 = getelementptr %"compiler/ast:TypeDecl", ptr %t277, i32 0, i32 0
  %t280 = load i32, ptr %t279, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t276, i32 %t280, i1 true)
  br label %bb75
bb75:
  br label %bb81
bb76:
  br i1 true, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_1e4dfbf30e1c2de1_fce951bebdc2c845)
  unreachable
bb81:
  br label %bb82
bb82:
  %t283 = load i64, ptr %l19, !tbaa !24
  %t285 = add i64 %t283, 1
  store i64 %t285, ptr %l19, !tbaa !24
  br label %bb59
bb83:
  br label %bb112
bb84:
  %t287 = load ptr, ptr %l7, !tbaa !29
  store ptr %t287, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t288 = load ptr, ptr %l152, !tbaa !29
  %t289 = icmp ne ptr %t288, null
  br i1 %t289, label %bb85, label %bb86
bb85:
  %t291 = load ptr, ptr %l152, !tbaa !29
  %t292 = load i64, ptr %t291, !range !{i64 0, i64 11}
  %t294 = icmp eq i64 %t292, 4
  store i1 %t294, ptr %l153, !tbaa !21
  br label %bb86
bb86:
  %t295 = load i1, ptr %l153, !tbaa !21
  br i1 %t295, label %bb87, label %bb88
bb87:
  %t296 = load ptr, ptr %l7, !tbaa !29
  %t298 = getelementptr { i64, [6 x i64] }, ptr %t296, i32 0, i32 1
  %t299 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" }, ptr %t298, i32 0, i32 1
  %t300 = load i32, ptr %t299
  store i32 %t300, ptr %l24, !tbaa !23
  %t302 = load ptr, ptr %l7, !tbaa !29
  %t304 = getelementptr { i64, [6 x i64] }, ptr %t302, i32 0, i32 1
  %t305 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" }, ptr %t304, i32 0, i32 2
  %t306 = load %"compiler/source:Span", ptr %t305
  store %"compiler/source:Span" %t306, ptr %l25
  br label %bb89
bb88:
  br label %bb107
bb89:
  %t308 = load i32, ptr %l24, !tbaa !23
  store i32 %t308, ptr %l26, !tbaa !23
  %t310 = load i32, ptr %l26, !tbaa !23
  %t312 = icmp eq i32 %t310, 0
  br i1 %t312, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s20
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/names:Resolver", ptr %t314, i32 0, i32 0
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t319 = getelementptr %"compiler/load:Loader", ptr %t317, i32 0, i32 5
  %t320 = load i64, ptr %l1, !tbaa !24
  %t323 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t319, i64 %t320)
  store ptr %t323, ptr %l167
  br label %bb92
bb91:
  br label %bb105
bb92:
  %t324 = load ptr, ptr %l167, !tbaa !29
  %t326 = getelementptr %"compiler/load:Module", ptr %t324, i32 0, i32 6
  %t327 = load ptr, ptr %t326, !tbaa !29
  store ptr %t327, ptr %l27, !tbaa !29
  %t329 = load ptr, ptr %l27, !tbaa !29
  %t331 = icmp eq ptr %t329, null
  br i1 %t331, label %bb93, label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_8f9324689016fc99_e6d9e6ff9d8544ed)
  unreachable
bb94:
  br label %bb95
bb95:
  %t333 = load ptr, ptr %l27, !tbaa !29
  %t336 = getelementptr %"compiler/source:Source", ptr %t333, i32 0, i32 1
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l174, !tbaa !27
  %t338 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 0
  %t339 = load i32, ptr %t338, !tbaa !23
  %t341 = sext i32 %t339 to i64
  store i64 %t341, ptr %l176, !tbaa !24
  %t342 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 1
  %t343 = load i32, ptr %t342, !tbaa !23
  %t345 = sext i32 %t343 to i64
  store i64 %t345, ptr %l178, !tbaa !24
  %t346 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t346, 0
  store i64 %t347, ptr %l179, !tbaa !24
  %t348 = load i64, ptr %l176, !tbaa !24
  %t349 = icmp sge i64 %t348, 0
  br i1 %t349, label %bb96, label %bb97
bb96:
  %t351 = load i64, ptr %l176, !tbaa !24
  %t352 = load i64, ptr %l178, !tbaa !24
  %t353 = icmp sle i64 %t351, %t352
  br i1 %t353, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_df48d31874ab493c_9a8bc01bf27d4ba0)
  unreachable
bb98:
  %t355 = load i64, ptr %l178, !tbaa !24
  %t356 = load i64, ptr %l179, !tbaa !24
  %t357 = icmp sle i64 %t355, %t356
  br i1 %t357, label %bb100, label %bb101
bb99:
  call void @__olang_check_failed(ptr @olang_loc_df48d31874ab493c_9a8bc01bf27d4ba0)
  unreachable
bb100:
  %t359 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !27
  %t361 = load i64, ptr %l176, !tbaa !24
  %t362 = load i64, ptr %l178, !tbaa !24
  %t363 = getelementptr i8, ptr %t360, i64 %t361
  %t364 = sub i64 %t362, %t361
  %t365 = insertvalue { i64, ptr } undef, i64 %t364, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t363, 1
  %t368 = call { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %v0, ptr %s20, { i64, ptr } %t366)
  store { i64, ptr } %t368, ptr %l184
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_df48d31874ab493c_9a8bc01bf27d4ba0)
  unreachable
bb102:
  %t369 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/names:Resolver", ptr %t370, i32 0, i32 0
  %t373 = load ptr, ptr %t372, !tbaa !29
  %t375 = getelementptr %"compiler/load:Loader", ptr %t373, i32 0, i32 3
  %t376 = load ptr, ptr %t375, !tbaa !29
  store ptr %t376, ptr %l187, !tbaa !29
  %t379 = call { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %s20, { i64, ptr } %t369)
  store { i64, ptr } %t379, ptr %l189
  br label %bb103
bb103:
  %t380 = load ptr, ptr %l187, !tbaa !29
  %t381 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t382 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s20, ptr %t380, { i64, ptr } %t381)
  store i32 %t382, ptr %l190
  br label %bb104
bb104:
  %t383 = load i32, ptr %l190, !tbaa !23
  store i32 %t383, ptr %l26, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  br label %bb105
bb105:
  %t384 = load ptr, ptr %l3, !tbaa !29
  %t386 = getelementptr %"compiler/names:Table", ptr %t384, i32 0, i32 4
  %t387 = load i32, ptr %l26, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t386, i32 %t387, i1 true)
  br label %bb106
bb106:
  br label %bb112
bb107:
  br i1 true, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_7bce57629b898d4a_9c5170df02d1098e)
  unreachable
bb112:
  br label %bb113
bb113:
  %t390 = load i64, ptr %l5, !tbaa !24
  %t392 = add i64 %t390, 1
  store i64 %t392, ptr %l5, !tbaa !24
  br label %bb5
bb114:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fnames_2efieldNames(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca i1
  %l62 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:StructBody", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l24, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t30 = load ptr, ptr %lp1
  %t33 = getelementptr %"compiler/ast:Param", ptr %t28, i32 0, i32 1
  %t34 = load i32, ptr %t33, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t30, i32 %t34)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/ast:StructBody", ptr %t41, i32 0, i32 2
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t48 = icmp eq i64 %t46, 0
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t50 = load ptr, ptr %lp1
  %t51 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t50
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/ast:StructBody", ptr %t53, i32 0, i32 2
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb13, label %bb14
bb13:
  br label %bb35
bb14:
  br label %bb15
bb15:
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t70, ptr %l45, !tbaa !27
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 %t71
  %t76 = load ptr, ptr %t75, !tbaa !39
  store ptr %t76, ptr %l9, !tbaa !29
  %t78 = load ptr, ptr %l9, !tbaa !29
  store ptr %t78, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t79 = load ptr, ptr %l48, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = load ptr, ptr %l48, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 22}
  %t85 = icmp eq i64 %t83, 1
  store i1 %t85, ptr %l49, !tbaa !21
  br label %bb17
bb17:
  %t86 = load i1, ptr %l49, !tbaa !21
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t87 = load ptr, ptr %l9, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr }, ptr %t89, i32 0, i32 1
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l10, !tbaa !29
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t93 = load ptr, ptr %l10, !tbaa !29
  %t95 = getelementptr %"compiler/ast:VarDecl", ptr %t93, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  store i64 %t100, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  %t102 = load i64, ptr %l12, !tbaa !24
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = icmp slt i64 %t102, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb22, label %bb23
bb22:
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t110, ptr %l62, !tbaa !27
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i32, ptr %t114, i64 %t111
  %t116 = load i32, ptr %t115, !tbaa !33
  %t118 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t118, i32 %t116)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t122 = load i64, ptr %l12, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l12, !tbaa !24
  br label %bb21
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_6dee9be1cc02e387_998545862ea10f93)
  unreachable
bb33:
  br label %bb34
bb34:
  %t126 = load i64, ptr %l7, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l7, !tbaa !24
  br label %bb12
bb35:
  %t130 = load ptr, ptr %lp1
  %t131 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t130
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fnames_2eidentChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fnames_2eindexOfRaised(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l37 = alloca %"compiler/names:raisedName"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eLen_H9e36587759e47da85a29e6c0abff1d1c(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i64, ptr %l9, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = call %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %v0, ptr %t51, i64 %t53)
  store %"compiler/names:raisedName" %t56, ptr %l37
  br label %bb12
bb12:
  %t57 = getelementptr %"compiler/names:raisedName", ptr %l37, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  %t62 = icmp eq i32 %t58, %a1
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l7, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fnames_2ekey(i64 %a0, i32 %a1) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = shl i64 %a0, 32
  %t6 = sext i32 %a1 to i64
  %t9 = or i64 %t3, %t6
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i64 } @compiler_2fnames_2elineCol(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %rv = alloca { i64, i64 }
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 %a1, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l14, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store { i64, ptr } %a0, ptr %l35, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i8, ptr %t53, i64 %t47
  %t55 = load i8, ptr %t54, !tbaa !32
  %t57 = icmp eq i8 %t55, 10
  br i1 %t57, label %bb11, label %bb12
bb11:
  %t59 = load i64, ptr %l2, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  br label %bb13
bb12:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l3, !tbaa !24
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t67 = load i64, ptr %l8, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l8, !tbaa !24
  br label %bb7
bb15:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load i64, ptr %l3, !tbaa !24
  %t74 = insertvalue { i64, i64 } undef, i64 %t71, 0
  %t76 = insertvalue { i64, i64 } %t74, i64 %t72, 1
  store { i64, i64 } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 96}
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 96}
  %t18 = trunc i64 2 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  br label %bb17
bb7:
  %t23 = load i32, ptr %l1, !range !{i32 0, i32 96}
  %t25 = trunc i64 3 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  br label %bb16
bb9:
  %t30 = load i32, ptr %l1, !range !{i32 0, i32 96}
  %t32 = trunc i64 6 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t35, ptr %l24, !tbaa !27
  br label %bb15
bb11:
  %t37 = load i32, ptr %l1, !range !{i32 0, i32 96}
  %t39 = trunc i64 5 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t42, ptr %l29, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t44, ptr %l29, !tbaa !27
  br label %bb14
bb14:
  %t46 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t46, ptr %l24, !tbaa !27
  br label %bb15
bb15:
  %t47 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t47, ptr %l19, !tbaa !27
  br label %bb16
bb16:
  %t48 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t48, ptr %l14, !tbaa !27
  br label %bb17
bb17:
  %t49 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t49, ptr %l5, !tbaa !27
  br label %bb40
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t51 = load ptr, ptr %l34, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l34, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 29}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l35, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62, !range !{i32 0, i32 96}
  store i32 %t63, ptr %l2
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb28
bb23:
  %t71 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t73 = trunc i64 53 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = call { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v0, ptr %v1, ptr %t76)
  store { i64, ptr } %t78, ptr %l46
  br label %bb26
bb25:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t79, ptr %l44, !tbaa !27
  br label %bb27
bb26:
  %t81 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t81, ptr %l44, !tbaa !27
  br label %bb27
bb27:
  %t82 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t82, ptr %l5, !tbaa !27
  br label %bb40
bb28:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t84 = load ptr, ptr %l49, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 29}
  %t90 = icmp eq i64 %t88, 2
  store i1 %t90, ptr %l50, !tbaa !21
  br label %bb30
bb30:
  %t91 = load i1, ptr %l50, !tbaa !21
  br i1 %t91, label %bb31, label %bb32
bb31:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", ptr }, ptr %t94, i32 0, i32 1
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t98 = load ptr, ptr %l4, !tbaa !29
  %t100 = call { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v0, ptr %v1, ptr %t98)
  store { i64, ptr } %t100, ptr %l56
  br label %bb34
bb34:
  %t101 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t101, ptr %l5, !tbaa !27
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l57, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t102, ptr %l5, !tbaa !27
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_69822c0cac48a014_4fc53fd0a2f89a60)
  unreachable
bb40:
  %t104 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l59, !tbaa !24
  %t106 = load i64, ptr %l59, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l60, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l59, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t117, ptr %l5, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t118, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fnames_2eoutranks(%"compiler/names:raisedName" %a0, %"compiler/names:raisedName" %a1) #0 {
entry:
  %l0 = alloca %"compiler/names:raisedName"
  %l1 = alloca %"compiler/names:raisedName"
  %l5 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store %"compiler/names:raisedName" %a0, ptr %l0
  store %"compiler/names:raisedName" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/names:raisedName", ptr %l0, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/names:raisedName", ptr %l1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = icmp sgt i64 %t2, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb6
bb2:
  %t9 = getelementptr %"compiler/names:raisedName", ptr %l0, i32 0, i32 2
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = getelementptr %"compiler/names:raisedName", ptr %l1, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = icmp eq i64 %t10, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = getelementptr %"compiler/names:raisedName", ptr %l0, i32 0, i32 4
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = getelementptr %"compiler/names:raisedName", ptr %l1, i32 0, i32 4
  %t20 = load i64, ptr %t19, !tbaa !24
  %t23 = icmp slt i64 %t18, %t20
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l9, !tbaa !21
  store i1 %t25, ptr %l5, !tbaa !21
  br label %bb6
bb6:
  %t26 = load i1, ptr %l5, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fnames_2etestRules(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/cond:Consts"
  %l10 = alloca %"compiler/diag:Diagnostics"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"compiler/load:Loader"
  %l16 = alloca %"compiler/names:Resolver"
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/diag:Said"
  %l21 = alloca { i64, i64 }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i64
  %l56 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l66 = alloca i32
  %l68 = alloca i1
  %l71 = alloca %"compiler/cond:Consts"
  %l73 = alloca %"compiler/diag:Diagnostics"
  %l81 = alloca { i64, ptr }
  %l87 = alloca i32
  %l90 = alloca ptr
  %l97 = alloca %"compiler/fetch:Fetcher"
  %l98 = alloca ptr
  %l99 = alloca %"compiler/source:Names"
  %l102 = alloca %"compiler/load:Loader"
  %l105 = alloca { i64, ptr }
  %l109 = alloca i64
  %l111 = alloca %"compiler/names:Resolver"
  %l113 = alloca %"std/prelude/text:StringBuilder"
  %l115 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l117 = alloca i64
  %l119 = alloca i64
  %l124 = alloca %"compiler/diag:Said"
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, i64 }
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %l145 = alloca i32
  %l147 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t118 = alloca %"compiler/diag:Diagnostics", align 8
  %t196 = alloca %"compiler/load:Loader", align 8
  %t232 = alloca %"compiler/names:Resolver", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l26
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l25
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t6, ptr %l24, !tbaa !27
  br label %bb4
bb2:
  %t7 = load i32, ptr %l26, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  store i1 %t10, ptr %l28, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_7d6219e827f558e0_eeca058e7ab150ac)
  unreachable
bb4:
  %t11 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l4, !tbaa !24
  store i64 2, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb7:
  %t26 = load i64, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l37, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l37, !tbaa !24
  store i64 %t42, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l34, !tbaa !24
  store i64 %t43, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l8, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t63, ptr %l56, !tbaa !27
  %t64 = load i64, ptr %l8, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %t67, i64 %t64
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !37
  %t71 = extractvalue { i64, ptr } %t62, 1
  %t72 = extractvalue { i64, ptr } %t62, 0
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t77 = extractvalue { i64, ptr } %t69, 1
  %t78 = extractvalue { i64, ptr } %t69, 0
  %t79 = add i64 %t75, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = getelementptr i8, ptr %t80, i64 %t72
  call void @olang_textcopy(ptr %t81, ptr %t73, i64 %t74)
  %t82 = getelementptr i8, ptr %t81, i64 %t74
  call void @olang_textcopy(ptr %t82, ptr %t77, i64 %t78)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t80, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } %t84, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t92 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t92, ptr %l61, !tbaa !27
  %t93 = load i64, ptr %l8, !tbaa !24
  %t95 = add i64 %t93, 1
  %t97 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %t98, i64 %t95
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !37
  %t104 = call i32 @std_2fos_2eWriteFile(ptr %s3, ptr %v0, { i64, ptr } %t91, { i64, ptr } %t100)
  store i32 %t104, ptr %l66
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb16, label %ok.106, !prof !99
ok.106:
  br label %bb15
bb15:
  br label %bb18
bb16:
  %t107 = load i32, ptr %l66, !tbaa !23
  %t108 = ashr i32 %t107, 16
  %t110 = icmp eq i32 %t108, 1
  store i1 %t110, ptr %l68, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_ert_req_clear()
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t111 = load i64, ptr %l7, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l7, !tbaa !24
  br label %bb11
bb20:
  %t115 = call %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %s0)
  store %"compiler/cond:Consts" %t115, ptr %l71
  br label %bb21
bb21:
  %t116 = load %"compiler/cond:Consts", ptr %l71
  store %"compiler/cond:Consts" %t116, ptr %l9
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l9, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d63, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d64, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) }, i64 128, i64 0, i1 false, i1 false, i1 false)
  br label %bb22
bb22:
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t118, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l73, ptr %t118, i64 200, i1 false)
  br label %bb23
bb23:
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %l73, i64 200, i1 false)
  store { i64, ptr } %a1, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  store i64 %t123, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  %t125 = load i64, ptr %l12, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb25, label %bb26
bb25:
  br label %bb33
bb26:
  br label %bb27
bb27:
  %t133 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t133, ptr %l81, !tbaa !27
  %t134 = load i64, ptr %l12, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %t137, i64 %t134
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !37
  %t145 = call i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %s0, ptr %v1, ptr %s0, ptr %l9, { i64, ptr } %t139, ptr %l10)
  store i32 %t145, ptr %l87
  %t146 = icmp ne i32 %t145, 0
  br i1 %t146, label %bb29, label %ok.147, !prof !99
ok.147:
  br label %bb28
bb28:
  br label %bb31
bb29:
  br label %bb30
bb30:
  call void @__olang_ert_req_clear()
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l12, !tbaa !24
  br label %bb24
bb33:
  store ptr %l9, ptr %l90, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = extractvalue { i64, ptr } %t152, 0
  %t156 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t158 = add i64 %t155, %t157
  %t159 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t158)
  call void @olang_textcopy(ptr %t159, ptr %t154, i64 %t155)
  %t160 = getelementptr i8, ptr %t159, i64 %t155
  call void @olang_textcopy(ptr %t160, ptr %t156, i64 %t157)
  %t161 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t159, 1
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t165 = extractvalue { i64, ptr } %t162, 1
  %t166 = mul i64 %t164, 1
  %t167 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t166)
  call void @llvm.memcpy.p0.p0.i64(ptr %t167, ptr %t165, i64 %t166, i1 false)
  %t168 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  %t170 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 1
  %t173 = extractvalue { i64, ptr } %t170, 0
  %t174 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t172, i64 %t173)
  %t178 = getelementptr i8, ptr %t177, i64 %t173
  call void @olang_textcopy(ptr %t178, ptr %t174, i64 %t175)
  %t179 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t177, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = extractvalue { i64, ptr } %t180, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t190 = call %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t169, { i64, ptr } %t187, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d68, i32 0, i32 1) }, i1 false, i1 true)
  store %"compiler/fetch:Fetcher" %t190, ptr %l97
  br label %bb34
bb34:
  %t191 = load %"compiler/fetch:Fetcher", ptr %l97
  %t192 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 88, i64 8)
  store %"compiler/fetch:Fetcher" %t191, ptr %t192
  store ptr %t192, ptr %l98, !tbaa !29
  %t193 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %s0)
  store %"compiler/source:Names" %t193, ptr %l99
  br label %bb35
bb35:
  %t194 = load %"compiler/source:Names", ptr %l99
  %t195 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 16, i64 8)
  store %"compiler/source:Names" %t194, ptr %t195
  %t197 = load ptr, ptr %l90, !tbaa !29
  %t198 = load ptr, ptr %l98, !tbaa !29
  call void @compiler_2fload_3aLoader_2ector(ptr %t196, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %t197, ptr %t198, ptr %t195, ptr %l10)
  call void @llvm.memmove.p0.p0.i64(ptr %l102, ptr %t196, i64 144, i1 false)
  br label %bb36
bb36:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l102, i64 144, i1 false)
  %t201 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t202, ptr %l105, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %t204, i64 0
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !37
  %t208 = extractvalue { i64, ptr } %t201, 1
  %t209 = extractvalue { i64, ptr } %t201, 0
  %t210 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t212 = add i64 %t209, %t211
  %t214 = extractvalue { i64, ptr } %t206, 1
  %t215 = extractvalue { i64, ptr } %t206, 0
  %t216 = add i64 %t212, %t215
  %t217 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t216)
  call void @olang_textcopy(ptr %t217, ptr %t208, i64 %t209)
  %t218 = getelementptr i8, ptr %t217, i64 %t209
  call void @olang_textcopy(ptr %t218, ptr %t210, i64 %t211)
  %t219 = getelementptr i8, ptr %t218, i64 %t211
  call void @olang_textcopy(ptr %t219, ptr %t214, i64 %t215)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t217, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = extractvalue { i64, ptr } %t221, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t231 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } %t228)
  store i64 %t231, ptr %l109
  br label %bb37
bb37:
  call void @compiler_2fnames_3aResolver_2ector(ptr %t232, ptr %s0, ptr %s0, ptr %l15)
  call void @llvm.memmove.p0.p0.i64(ptr %l111, ptr %t232, i64 200, i1 false)
  br label %bb38
bb38:
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %l111, i64 200, i1 false)
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %s0, ptr %l16)
  br label %bb39
bb39:
  %t235 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t235, ptr %l113
  br label %bb40
bb40:
  %t236 = load %"std/prelude/text:StringBuilder", ptr %l113
  store %"std/prelude/text:StringBuilder" %t236, ptr %l17
  store %olang.scope zeroinitializer, ptr %s14
  %t238 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %s0, ptr %s14, ptr %l10)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %l115
  br label %bb41
bb41:
  %t239 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l115
  %t240 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t239, ptr %t240
  store ptr %t240, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s15
  %t242 = load i64, ptr %l19, !tbaa !24
  store i64 %t242, ptr %l117, !tbaa !24
  %t243 = load ptr, ptr %l18, !tbaa !29
  %t245 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %s14, ptr %t243)
  store i64 %t245, ptr %l119
  br label %bb43
bb43:
  %t246 = load i64, ptr %l117, !tbaa !24
  %t247 = load i64, ptr %l119, !tbaa !24
  %t248 = icmp slt i64 %t246, %t247
  %t250 = xor i1 %t248, true
  br i1 %t250, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s15)
  br label %bb51
bb45:
  br label %bb46
bb46:
  %t252 = load ptr, ptr %l18, !tbaa !29
  %t253 = load i64, ptr %l19, !tbaa !24
  %t256 = call %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %s14, ptr %s14, ptr %t252, i64 %t253)
  store %"compiler/diag:Said" %t256, ptr %l124
  br label %bb47
bb47:
  %t257 = load %"compiler/diag:Said", ptr %l124
  store %"compiler/diag:Said" %t257, ptr %l20
  %t258 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t258, ptr %l125, !tbaa !27
  %t259 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %t260, i64 1
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !37
  %t263 = getelementptr %"compiler/diag:Said", ptr %l20, i32 0, i32 2
  %t264 = load i64, ptr %t263, !tbaa !24
  %t267 = call { i64, i64 } @compiler_2fnames_2elineCol(ptr %v0, { i64, ptr } %t262, i64 %t264)
  store { i64, i64 } %t267, ptr %l128
  br label %bb48
bb48:
  %t268 = load { i64, i64 }, ptr %l128
  store { i64, i64 } %t268, ptr %l21
  %t269 = getelementptr { i64, i64 }, ptr %l21, i32 0, i32 0
  %t270 = load i64, ptr %t269, !tbaa !24
  %t272 = getelementptr { i64, i64 }, ptr %l21, i32 0, i32 1
  %t273 = load i64, ptr %t272, !tbaa !24
  %t275 = getelementptr %"compiler/diag:Said", ptr %l20, i32 0, i32 0
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t276, 1
  %t281 = extractvalue { i64, ptr } %t276, 0
  %t282 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t283 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t284 = add i64 %t281, %t283
  %t286 = call i64 @__olang_fmt_i64(ptr null, i64 %t270)
  %t287 = add i64 %t284, %t286
  %t288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t289 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t290 = add i64 %t287, %t289
  %t292 = call i64 @__olang_fmt_i64(ptr null, i64 %t273)
  %t293 = add i64 %t290, %t292
  %t294 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t296 = add i64 %t293, %t295
  %t297 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t296)
  call void @olang_textcopy(ptr %t297, ptr %t280, i64 %t281)
  %t298 = getelementptr i8, ptr %t297, i64 %t281
  call void @olang_textcopy(ptr %t298, ptr %t282, i64 %t283)
  %t299 = getelementptr i8, ptr %t298, i64 %t283
  %t300 = call i64 @__olang_fmt_i64(ptr %t299, i64 %t270)
  %t301 = getelementptr i8, ptr %t299, i64 %t286
  call void @olang_textcopy(ptr %t301, ptr %t288, i64 %t289)
  %t302 = getelementptr i8, ptr %t301, i64 %t289
  %t303 = call i64 @__olang_fmt_i64(ptr %t302, i64 %t273)
  %t304 = getelementptr i8, ptr %t302, i64 %t292
  call void @olang_textcopy(ptr %t304, ptr %t294, i64 %t295)
  %t305 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t297, 1
  %t308 = extractvalue { i64, ptr } %t306, 0
  %t309 = extractvalue { i64, ptr } %t306, 1
  %t310 = mul i64 %t308, 1
  %t311 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t310)
  call void @llvm.memcpy.p0.p0.i64(ptr %t311, ptr %t309, i64 %t310, i1 false)
  %t312 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t311, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l17, { i64, ptr } %t313)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s15)
  br label %bb50
bb50:
  %t316 = load i64, ptr %l19, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l19, !tbaa !24
  br label %bb42
bb51:
  call void @__olang_scope_close(ptr %s14)
  %t321 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l17)
  store { i64, ptr } %t321, ptr %l140
  br label %bb52
bb52:
  %t322 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t322, ptr %l141, !tbaa !27
  %t323 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t323, 0
  store i64 %t324, ptr %l142, !tbaa !24
  %t325 = load i64, ptr %l142, !tbaa !24
  %t326 = mul i64 %t325, 1
  %t327 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t326)
  %t328 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t327, 1
  store { i64, ptr } %t329, ptr %l143, !tbaa !27
  %t330 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = load i64, ptr %l142, !tbaa !24
  %t335 = mul i64 %t334, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t331, ptr %t333, i64 %t335, i1 false)
  %t336 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t336, ptr %l141, !tbaa !27
  %t337 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t339 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t337)
  store i32 %t339, ptr %l145
  %t340 = icmp ne i32 %t339, 0
  br i1 %t340, label %bb54, label %ok.341, !prof !99
ok.341:
  br label %bb53
bb53:
  br label %bb56
bb54:
  %t342 = load i32, ptr %l145, !tbaa !23
  %t343 = ashr i32 %t342, 16
  %t345 = icmp eq i32 %t343, 1
  store i1 %t345, ptr %l147, !tbaa !21
  br label %bb55
bb55:
  call void @__olang_ert_req_clear()
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t346 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t346, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fnames_2ewritable(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 7}
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t17, i32 0, i32 2
  %t19 = load i1, ptr %t18
  store i1 %t19, ptr %l1, !tbaa !21
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load i1, ptr %l1, !tbaa !21
  store i1 %t21, ptr %l5, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4eea153ddadf8a93_2aa3e7ca07d322c7)
  unreachable
bb14:
  %t23 = load i1, ptr %l5, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v0, ptr %v1, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i1 %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/names:Entry"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/names:Entry" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/names:Entry" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/names:Entry" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/names:Entry" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/names:Entry" %t18, ptr %a4, 4
  store %"compiler/names:Entry" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Entry", ptr %rv
  ret %"compiler/names:Entry" %rr
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/names:Ref"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/names:Ref" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/names:Ref" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/names:Ref" %t10, i64 %a2, 2
  store %"compiler/names:Ref" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_3aResolver_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca i1
  %l24 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"compiler/names:Resolver"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l28
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  %t5 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l29
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l3
  %t7 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l30
  br label %bb3
bb3:
  %t8 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l4
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l31
  br label %bb4
bb4:
  %t10 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l5
  %t11 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l32
  br label %bb5
bb5:
  %t12 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l6
  store i64 -1, ptr %l7, !tbaa !24
  %t13 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l33
  br label %bb6
bb6:
  %t14 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l8
  %t15 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l34
  br label %bb7
bb7:
  %t16 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l9
  %t17 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l35
  br label %bb8
bb8:
  %t18 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l10
  %t19 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l36
  br label %bb9
bb9:
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l11
  %t21 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l37
  br label %bb10
bb10:
  %t22 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l12
  store i1 false, ptr %l13, !tbaa !21
  store i1 false, ptr %l14, !tbaa !21
  store i64 0, ptr %l15, !tbaa !24
  %t23 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l38
  br label %bb11
bb11:
  %t24 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l16
  %t25 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l39
  br label %bb12
bb12:
  %t26 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l17
  %t27 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l40
  br label %bb13
bb13:
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l18
  %t29 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l41
  br label %bb14
bb14:
  %t30 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l19
  %t31 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l42
  br label %bb15
bb15:
  %t32 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l20
  %t33 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l43
  br label %bb16
bb16:
  %t34 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l21
  %t35 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l44
  br label %bb17
bb17:
  %t36 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l22
  store i1 false, ptr %l23, !tbaa !21
  %t37 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l45
  br label %bb18
bb18:
  %t38 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l24
  %t39 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l46
  br label %bb19
bb19:
  %t40 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l25
  %t41 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l47
  br label %bb20
bb20:
  %t42 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  %t43 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 0
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %t43, !tbaa !29
  %t45 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 1
  %t46 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %t45
  %t47 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 2
  %t48 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %t47
  %t49 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 3
  %t50 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %t49
  %t51 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 4
  %t52 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %t51
  %t53 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 5
  %t54 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %t53
  %t55 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 6
  %t56 = load i64, ptr %l7, !tbaa !24
  store i64 %t56, ptr %t55, !tbaa !24
  %t57 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 7
  %t58 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %t57
  %t59 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 8
  %t60 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %t59
  %t61 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 9
  %t62 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %t61
  %t63 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 10
  %t64 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %t63
  %t65 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 11
  %t66 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %t65
  %t67 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 12
  %t68 = load i1, ptr %l13, !tbaa !21
  store i1 %t68, ptr %t67, !tbaa !21
  %t69 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 13
  %t70 = load i1, ptr %l14, !tbaa !21
  store i1 %t70, ptr %t69, !tbaa !21
  %t71 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 14
  %t72 = load i64, ptr %l15, !tbaa !24
  store i64 %t72, ptr %t71, !tbaa !24
  %t73 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 15
  %t74 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %t73
  %t75 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 16
  %t76 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %t75
  %t77 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 17
  %t78 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %t77
  %t79 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 18
  %t80 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %t79
  %t81 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 19
  %t82 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %t81
  %t83 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 20
  %t84 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %t83
  %t85 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 21
  %t86 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %t85
  %t87 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 22
  %t88 = load i1, ptr %l23, !tbaa !21
  store i1 %t88, ptr %t87, !tbaa !21
  %t89 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 23
  %t90 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %t89
  %t91 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 24
  %t92 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t92, ptr %t91
  %t93 = getelementptr %"compiler/names:Resolver", ptr %l48, i32 0, i32 25
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %t93
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l48, i64 200, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:Table" @compiler_2fnames_3aTable_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/names:Table"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  %t3 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l6
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l1
  %t5 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l7
  br label %bb3
bb3:
  %t6 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l8
  br label %bb4
bb4:
  %t8 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l9
  br label %bb5
bb5:
  %t10 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t11 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t12 = insertvalue %"compiler/names:Table" undef, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 0
  %t13 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t14 = insertvalue %"compiler/names:Table" %t12, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 1
  %t15 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t16 = insertvalue %"compiler/names:Table" %t14, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 2
  %t17 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t18 = insertvalue %"compiler/names:Table" %t16, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 3
  %t20 = insertvalue %"compiler/names:Table" %t18, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, 4
  store %"compiler/names:Table" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Table", ptr %rv
  ret %"compiler/names:Table" %rr
}

define dso_local %"compiler/names:Unread" @compiler_2fnames_3aUnread_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i32 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/names:Unread"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/names:Unread" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/names:Unread" %t10, %"compiler/source:Span" %a1, 1
  %t14 = insertvalue %"compiler/names:Unread" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/names:Unread" %t14, i1 %a3, 3
  store %"compiler/names:Unread" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Unread", ptr %rv
  ret %"compiler/names:Unread" %rr
}

define dso_local %"compiler/names:local" @compiler_2fnames_3alocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i1 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %rv = alloca %"compiler/names:local"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/names:local" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/names:local" %t14, %"compiler/source:Span" %a1, 1
  %t18 = insertvalue %"compiler/names:local" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/names:local" %t18, i1 %a3, 3
  %t22 = insertvalue %"compiler/names:local" %t20, i1 %a4, 4
  %t24 = insertvalue %"compiler/names:local" %t22, i1 %a5, 5
  store %"compiler/names:local" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:local", ptr %rv
  ret %"compiler/names:local" %rr
}

define dso_local %"compiler/names:raisedName" @compiler_2fnames_3araisedName_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i64 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/names:raisedName"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/names:raisedName" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/names:raisedName" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/names:raisedName" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/names:raisedName" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/names:raisedName" %t18, i64 %a4, 4
  store %"compiler/names:raisedName" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:raisedName", ptr %rv
  ret %"compiler/names:raisedName" %rr
}

define dso_local %"compiler/names:raised" @compiler_2fnames_3araised_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i1 %a2) #0 {
entry:
  %rv = alloca %"compiler/names:raised"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/names:raised" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/names:raised" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/names:raised" %t10, i1 %a2, 2
  store %"compiler/names:raised" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:raised", ptr %rv
  ret %"compiler/names:raised" %rr
}

@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d1 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d7 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d8 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_ert_req_clear()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d23 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Byte" }>, align 8
@.d32 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d48 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d49 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d51 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d54 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d56 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d63 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d64 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d65 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86-64" }>, align 8
@.d66 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"/olang.lock" }>, align 8
@.d67 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/cache" }>, align 8
@.d68 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"file:///nowhere/" }>, align 8
@.d69 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"std" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2eIsIntName(ptr %v0, { i64, ptr } %a0)
@olang_loc_fb93c458ab7e801d_1c40062d0c03aab1 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H945cb5faf347f41d89f6885b75263baa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_e4f618869538c748_3c1fb892daabce2c = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_8527bf2a1f74a17e_1cb11e6247ae4c42 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %a0)
declare %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Hd32f6fdf378a1d4c0e47f8552643012d(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0)
declare %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eG_Hb4f204ca9d50eb43e30fe8770cb15d1a(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H456f40e55a35e282608933ec0991ad61(ptr %v0, ptr %a0, i32 %a1, %"compiler/names:Ref" %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameIsType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/names:Entry" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %v0)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultMut(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H6d33fbc050830e537410645e3c893b2c(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePreludeConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %a0, i64 %a1, %"compiler/names:Ref" %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_fd033da614d46a49_c57bfff01eec9785 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %a0, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2ePush_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0, %"compiler/names:local" %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3c4b516dc7f3c61f_40ef246315a2e453 = external constant [0 x i8]
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2fload_2ePending = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_d2d926149e7406c7_ee094aa2e5a4afab = external constant [0 x i8]
@olang_loc_68114e74278341f8_5424865478da1a14 = external constant [0 x i8]
declare %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H2dfd829fbe4fa38977b46d00afbe1a06(ptr %v0, ptr %a0, %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %a1)
@olang_loc_3167f851ad930e17_101a5d4c5c826523 = external constant [0 x i8]
@olang_loc_10b7a8cdf1f86826_4c22b802d51640a2 = external constant [0 x i8]
@olang_loc_4f6a732ad110320d_928733cb84224b09 = external constant [0 x i8]
@olang_loc_3f10f26d81c7593c_51efd4b9807fb190 = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
@olang_loc_1073219c408bafd2_e24f73113d5a6ea6 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@olang_loc_f4b8a71cbdc10f47_ba6792d0a606e23b = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultFit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2f2d72e397ff9e11_581917560c7c3b1d = external constant [0 x i8]
@olang_loc_217d72d4076f850a_92db47fb0f8e8bb6 = external constant [0 x i8]
@olang_loc_711e2a7edda36e32_9275b80f871f367e = external constant [0 x i8]
@olang_loc_60cefae456c43b96_68bed78927cbacfa = external constant [0 x i8]
@olang_loc_e46cc2517056eb7d_41b560901e6ccb81 = external constant [0 x i8]
@olang_loc_8bede4e7118dcaa8_b7291399ad78424c = external constant [0 x i8]
@olang_loc_c16bd254021e145_58d15072e112dec1 = external constant [0 x i8]
@olang_loc_b8b027e61d959c9e_58d57e65eac3eb3a = external constant [0 x i8]
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_24d74d734bb1c47c_a76eb538bdec4e08 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eClear_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9d7678395160f3eb_aad45a645d2f7c27 = external constant [0 x i8]
@olang_loc_606655a3d6c9146a_8558b81c90083f76 = external constant [0 x i8]
@olang_loc_ca6a9ef64ba15071_9b37ed8e39b0c3dd = external constant [0 x i8]
@olang_loc_cbc626cb57e27c38_a58d4f769ca64c8c = external constant [0 x i8]
declare %"compiler/cond:Eval" @compiler_2fcond_3aEval_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3)
declare %"compiler/cond:Decision" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAlreadyDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eLen_H9e36587759e47da85a29e6c0abff1d1c(ptr %v0, ptr %a0)
declare %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a58fd8af443a076b_ecb4599a293195d7 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eToArray_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eSetAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/names:local" %a2)
@olang_loc_aef4624c79a8a28b_a45312851bdbb01f = external constant [0 x i8]
@olang_loc_87cbb522e5e56b9c_2473c9b69de9380 = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCutOff(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_12490b43c47bea91_b34a6c7dd92a3b95 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_f9018996705a58e9_83925e810340c2fd = external constant [0 x i8]
@olang_loc_eb7a002d6449973_70bfc0171de666c7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eLen_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %a0)
declare %"compiler/names:raised" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eAt_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2ePus_Hd55e6ab57c5af931645f87a55858e9a4(ptr %v0, ptr %a0, %"compiler/names:raisedName" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eSet_H6810983465e8cb9e88422e8fd071646d(ptr %v0, ptr %a0, i64 %a1, %"compiler/names:raisedName" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInNameExists(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_886f7d48bba75e1e_e325b650ab06e3ea = external constant [0 x i8]
@olang_loc_dbd61287de33a2c5_4d29ffa31fdf1ff1 = external constant [0 x i8]
@olang_loc_bee2df1b257c0b70_a796ae201fef93fc = external constant [0 x i8]
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
@olang_loc_f74f5c810fb1384f_2035d8e6259ec36b = external constant [0 x i8]
@olang_loc_9a3445d364d03a02_c72e8fada9365de6 = external constant [0 x i8]
@olang_loc_f2359f321711c0e9_83213f8b98ca37cd = external constant [0 x i8]
@olang_loc_530cce065f124df4_4e8587782c204bb8 = external constant [0 x i8]
@olang_loc_13e109869e44451a_84e972cbfcb81dee = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_29838351972cb384_2d79eff554670e58 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2ePush_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0, %"compiler/names:Unread" %a1)
declare { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H678d1b43e8b98a171ffdea8f28643d28(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8d565d6672144814_e400a405fc887290 = external constant [0 x i8]
@olang_loc_494c345e55bc9323_650b6e4eb2f730ef = external constant [0 x i8]
@olang_loc_9c997e82162b9a5a_f5a213d30049e536 = external constant [0 x i8]
declare i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fmsgs_2eNear(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eRaiseNearError(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameClashesWithImport(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsFunction(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsGlobal(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsBuildConst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e5a1f3e08188ecc4_85420485b9e83138 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__He0d1b669a6d0fad4ef2d0863356e160c(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H7068c8717e9d582db2941dd2bdd79d55(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eClear_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %a0)
@olang_loc_c86ac2e057a115e0_329ff77132980ab4 = external constant [0 x i8]
@olang_loc_67ada16116fb12ff_65bccde789f31043 = external constant [0 x i8]
@olang_loc_6b96fe1cf5244e4e_c67e94ae0baa20c2 = external constant [0 x i8]
@olang_loc_1bcb50306faa07e3_18a30ea25b6c39c7 = external constant [0 x i8]
@olang_loc_7fa72c55361929e2_2d15b450a98c4566 = external constant [0 x i8]
@olang_loc_f7af4f17da675e9e_7adee505b4454aba = external constant [0 x i8]
@olang_loc_4b15e456fcf3a345_7adab712aa943e41 = external constant [0 x i8]
@olang_loc_2e22b0ea443c0bf0_cc72b894f0b6250c = external constant [0 x i8]
@olang_loc_668f2e502e7138cf_4506733ced80a77b = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eClear_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hb7e448baed1c9668005f7dc6325e5707(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H263d9150b58237aac70cb39b886b10bb(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
@olang_loc_6855615fe1bb2138_9d7c9db084b0e41c = external constant [0 x i8]
@olang_loc_6dda337cc9644709_4e0ee1c3f9c7cc4d = external constant [0 x i8]
@olang_loc_6c621cf945a32f52_fbb4d8308e24c5b6 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_f16fd081e6fbed18_62e1963dfff5da0c = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eTruncate_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H30ad8836952c6f4772e34a804c6491c6(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H73edf45b0858a6ff3702d25efc23fa6e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1b8bfcf5c54b80a6_f112f6c40c79d862 = external constant [0 x i8]
@olang_loc_c04d895388279f34_2b6890ee7e2f3280 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2ePush_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %a0, %"compiler/names:raised" %a1)
@olang_loc_c883e3bd313e2585_b0aaf26ba1585cf1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e6063e0110b31a73_71b4269b957cfb57 = external constant [0 x i8]
@olang_loc_6e82bb982de183d3_df58ae24de93c697 = external constant [0 x i8]
@olang_loc_860724e602591604_160204475883fa78 = external constant [0 x i8]
@olang_loc_c9535db678f42df0_760e0f7ff8ef7f34 = external constant [0 x i8]
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownImport(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_3ee91b253925870d_db61affc9a997151 = external constant [0 x i8]
@olang_loc_a7c82f44040ceddc_d58c094e813108c0 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownImportStd(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownBuildName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H1a77801a5ab3ea58cbf0ff15b43ff2de(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9053a89eb2ebe36f_9971388257a6393 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportUnused(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_c24d94d368b768d0_dc6a7a3b6fd73c94 = external constant [0 x i8]
@olang_loc_93653db47984ae2f_98605133537f87a3 = external constant [0 x i8]
@olang_loc_b66f44eae599aa7e_d468abe9cc136322 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_1e4dfbf30e1c2de1_fce951bebdc2c845 = external constant [0 x i8]
@olang_loc_8f9324689016fc99_e6d9e6ff9d8544ed = external constant [0 x i8]
@olang_loc_df48d31874ab493c_9a8bc01bf27d4ba0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %v0, { i64, ptr } %a0)
@olang_loc_7bce57629b898d4a_9c5170df02d1098e = external constant [0 x i8]
@olang_loc_6dee9be1cc02e387_998545862ea10f93 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
@olang_loc_69822c0cac48a014_4fc53fd0a2f89a60 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7d6219e827f558e0_eeca058e7ab150ac = external constant [0 x i8]
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare void @compiler_2fload_3aLoader_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_4eea153ddadf8a93_2aa3e7ca07d322c7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
