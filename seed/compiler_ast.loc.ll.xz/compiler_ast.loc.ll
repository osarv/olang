; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_2231a09e52c8bb46_65bd70f90f09695a = weak_odr constant [45 x i8] c"compiler/ast.olang:367: unreachable reached\0A\00"
@olang_loc_26f44abf4a087cb_1b5420f35f3adcaf = weak_odr constant [38 x i8] c"compiler/ast.olang:428: null reached\0A\00"
@olang_loc_4ec53bb81943b275_46293089da537299 = weak_odr constant [45 x i8] c"compiler/ast.olang:359: unreachable reached\0A\00"
@olang_loc_55eca5e8e4fb6f87_b7588236e57371eb = weak_odr constant [45 x i8] c"compiler/ast.olang:347: unreachable reached\0A\00"
@olang_loc_8f7e387f76106e1a_528835e8df6db77e = weak_odr constant [45 x i8] c"compiler/ast.olang:472: unreachable reached\0A\00"
@olang_loc_cfce0b7e4832e85f_3aa2be1abc8ef6db = weak_odr constant [45 x i8] c"compiler/ast.olang:394: unreachable reached\0A\00"
@olang_loc_f108e027b0d3370b_50be6dc1114317df = weak_odr constant [38 x i8] c"compiler/ast.olang:421: null reached\0A\00"
