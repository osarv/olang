; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_2231a09e52c8bb46_65bd70f90f09695a = weak_odr constant [45 x i8] c"compiler/ast.olang:363: unreachable reached\0A\00"
@olang_loc_4ec53bb81943b275_46293089da537299 = weak_odr constant [45 x i8] c"compiler/ast.olang:355: unreachable reached\0A\00"
@olang_loc_55eca5e8e4fb6f87_b7588236e57371eb = weak_odr constant [45 x i8] c"compiler/ast.olang:343: unreachable reached\0A\00"
@olang_loc_8f7e387f76106e1a_528835e8df6db77e = weak_odr constant [45 x i8] c"compiler/ast.olang:373: unreachable reached\0A\00"
