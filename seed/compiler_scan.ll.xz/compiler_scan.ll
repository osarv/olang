; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scan:scanner" = type { { i64, ptr }, %"std/prelude/list:List<compiler/token:Token>", %"std/prelude/list:List<compiler/scan:Diag>", %"std/prelude/list:List<std/prelude/text:Char>", i64, i1 }
%"std/prelude/list:List<compiler/token:Token>" = type { ptr }
%"std/prelude/list:List<compiler/scan:Diag>" = type { ptr }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/scan:Diag" = type { i32, i32, i32, i8 }
%"std/prelude/list:List<I64>" = type { ptr }
define dso_local %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/scan:scanner"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/token:Token"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/scan:scanner"
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca %"compiler/token:Token"
  %l26 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca %"compiler/scan:Tokens"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/scan:Tokens"
  %t76 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l11, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t3 = call %"compiler/scan:scanner" @compiler_2fscan_3ascanner_2ector(ptr %v0, ptr %s0, { i64, ptr } %t2)
  store %"compiler/scan:scanner" %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load %"compiler/scan:scanner", ptr %l12
  store %"compiler/scan:scanner" %t4, ptr %l1
  store ptr %l1, ptr %l13, !tbaa !29
  %t5 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2erun(ptr %s0, ptr %t5)
  br label %bb2
bb2:
  %t6 = getelementptr %"compiler/scan:scanner", ptr %l1, i32 0, i32 1
  store ptr %t6, ptr %l14, !tbaa !29
  %t7 = load ptr, ptr %l14, !tbaa !29
  %t8 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2eToArray_3ccompiler_2ftoken_3aToken_3e(ptr %s0, ptr %v1, ptr %t7)
  store { i64, ptr } %t8, ptr %l15
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t10, ptr %l16, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t12, ptr %l17, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l18, !tbaa !24
  %t15 = load i64, ptr %l18, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load i64, ptr %l5, !tbaa !24
  store i64 %t16, ptr %l19, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  store i64 %t17, ptr %l20, !tbaa !24
  %t18 = load i64, ptr %l19, !tbaa !24
  %t19 = load i64, ptr %l20, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  store i1 %t20, ptr %l21, !tbaa !21
  %t21 = load i1, ptr %l21, !tbaa !21
  %t22 = xor i1 %t21, true
  store i1 %t22, ptr %l22, !tbaa !21
  %t23 = load i1, ptr %l22, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l23, !tbaa !27
  %t25 = load i64, ptr %l5, !tbaa !24
  store i64 %t25, ptr %l24, !tbaa !24
  %t26 = load i64, ptr %l24, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr %"compiler/token:Token", ptr %t28, i64 %t26
  %t30 = load %"compiler/token:Token", ptr %t29
  store %"compiler/token:Token" %t30, ptr %l25
  %t31 = load %"compiler/token:Token", ptr %l25
  store %"compiler/token:Token" %t31, ptr %l7
  %t32 = getelementptr %"compiler/token:Token", ptr %l7, i32 0, i32 0
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l26
  store ptr %l26, ptr %l27, !tbaa !29
  store i32 94, ptr %l28
  store ptr %l28, ptr %l29, !tbaa !29
  %t34 = load ptr, ptr %l27, !tbaa !29
  %t35 = load ptr, ptr %l29, !tbaa !29
  %t36 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t34, ptr %t35)
  store i1 %t36, ptr %l30
  br label %bb8
bb8:
  %t37 = load i1, ptr %l30, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l31, !tbaa !24
  %t39 = load i64, ptr %l31, !tbaa !24
  %t40 = add i64 %t39, 1
  store i64 %t40, ptr %l32, !tbaa !24
  %t41 = load i64, ptr %l32, !tbaa !24
  store i64 %t41, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t42 = load i64, ptr %l5, !tbaa !24
  store i64 %t42, ptr %l33, !tbaa !24
  %t43 = load i64, ptr %l33, !tbaa !24
  %t44 = add i64 %t43, 1
  store i64 %t44, ptr %l34, !tbaa !24
  %t45 = load i64, ptr %l34, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb4
bb13:
  call void @__olang_scope_close(ptr %s1)
  %t46 = load i64, ptr %l3, !tbaa !24
  store i64 %t46, ptr %l35, !tbaa !24
  %t47 = load i64, ptr %l35, !tbaa !24
  %t48 = icmp sge i64 %t47, 0
  store i1 %t48, ptr %l36, !tbaa !21
  %t49 = load i1, ptr %l36, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t50 = load i64, ptr %l35, !tbaa !24
  %t51 = icmp sle i64 %t50, 2305843009213693951
  store i1 %t51, ptr %l37, !tbaa !21
  %t52 = load i1, ptr %l37, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb16:
  %t53 = load i64, ptr %l35, !tbaa !24
  %t54 = mul i64 %t53, 4
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l38, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  %t60 = extractvalue { i64, ptr } %t58, 1
  %t61 = mul i64 %t59, 4
  %t62 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l39, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t65, ptr %l8, !tbaa !27
  %t66 = load i64, ptr %l3, !tbaa !24
  store i64 %t66, ptr %l40, !tbaa !24
  %t67 = load i64, ptr %l40, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  store i1 %t68, ptr %l41, !tbaa !21
  %t69 = load i1, ptr %l41, !tbaa !21
  br i1 %t69, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb18:
  %t70 = load i64, ptr %l40, !tbaa !24
  %t71 = icmp sle i64 %t70, 2305843009213693951
  store i1 %t71, ptr %l42, !tbaa !21
  %t72 = load i1, ptr %l42, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb20:
  %t73 = load i64, ptr %l40, !tbaa !24
  %t74 = mul i64 %t73, 4
  %t75 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t74)
  store i64 0, ptr %t76
  br label %fill.77
fill.77:
  %t80 = load i64, ptr %t76
  %t81 = icmp slt i64 %t80, %t73
  br i1 %t81, label %fillb.78, label %filld.79
fillb.78:
  %t82 = getelementptr i32, ptr %t75, i64 %t80
  store i32 -1, ptr %t82
  %t83 = add i64 %t80, 1
  store i64 %t83, ptr %t76
  br label %fill.77
filld.79:
  %t84 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t75, 1
  store { i64, ptr } %t85, ptr %l43, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t88 = extractvalue { i64, ptr } %t86, 1
  %t89 = mul i64 %t87, 4
  %t90 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l44, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t93, ptr %l9, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t95, ptr %l46, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t96, ptr %l47, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @compiler_2fscan_2ematchBraces(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t97, { i64, ptr } %t98, { i64, ptr } %t99)
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb22:
  %t100 = getelementptr %"compiler/scan:scanner", ptr %l1, i32 0, i32 2
  store ptr %t100, ptr %l48, !tbaa !29
  %t101 = load ptr, ptr %l48, !tbaa !29
  %t102 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2eToArray_3ccompiler_2fscan_3aDiag_3e(ptr %s0, ptr %v1, ptr %t101)
  store { i64, ptr } %t102, ptr %l49
  br label %bb23
bb23:
  %t103 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t103, ptr %l10, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t104, ptr %l50, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t105, ptr %l51, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t106, ptr %l52, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t107, ptr %l53, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t112 = call %"compiler/scan:Tokens" @compiler_2fscan_3aTokens_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t108, { i64, ptr } %t109, { i64, ptr } %t110, { i64, ptr } %t111)
  store %"compiler/scan:Tokens" %t112, ptr %l54
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load %"compiler/scan:Tokens", ptr %l54
  store %"compiler/scan:Tokens" %t113, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:Tokens", ptr %rv
  ret %"compiler/scan:Tokens" %rr
}

define dso_local { i64, i1 } @compiler_2fscan_2eblockComment(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i8
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i8
  %l17 = alloca i8
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i8
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca { i64, i1 }
  %l29 = alloca i8
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca { i64, i1 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, i1 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l6, !tbaa !24
  %t2 = load i64, ptr %l6, !tbaa !24
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l7, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = add i64 %t8, 1
  store i64 %t9, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  store i64 %t10, ptr %l11, !tbaa !24
  %t11 = load i64, ptr %l10, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l12, !tbaa !21
  %t14 = load i1, ptr %l12, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l13, !tbaa !21
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb15
bb3:
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t19
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l16, !tbaa !22
  %t24 = load i8, ptr %l16, !tbaa !22
  store i8 %t24, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  store i8 %t25, ptr %l17, !tbaa !22
  %t26 = load i8, ptr %l17, !tbaa !22
  %t27 = icmp eq i8 %t26, 35
  store i1 %t27, ptr %l18, !tbaa !21
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load i64, ptr %l2, !tbaa !24
  store i64 %t30, ptr %l21, !tbaa !24
  %t31 = load i64, ptr %l21, !tbaa !24
  %t32 = add i64 %t31, 1
  store i64 %t32, ptr %l22, !tbaa !24
  %t33 = load i64, ptr %l22, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t33
  %t37 = load i8, ptr %t36, !tbaa !32
  store i8 %t37, ptr %l23, !tbaa !22
  %t38 = load i8, ptr %l23, !tbaa !22
  %t39 = icmp eq i8 %t38, 35
  store i1 %t39, ptr %l24, !tbaa !21
  %t40 = load i1, ptr %l24, !tbaa !21
  store i1 %t40, ptr %l19, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  %t41 = load i1, ptr %l19, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l2, !tbaa !24
  store i64 %t42, ptr %l25, !tbaa !24
  %t43 = load i64, ptr %l25, !tbaa !24
  %t44 = add i64 %t43, 2
  store i64 %t44, ptr %l26, !tbaa !24
  %t45 = load i1, ptr %l4, !tbaa !21
  store i1 %t45, ptr %l27, !tbaa !21
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = insertvalue { i64, i1 } undef, i64 %t46, 0
  %t48 = load i1, ptr %l27, !tbaa !21
  %t49 = insertvalue { i64, i1 } %t47, i1 %t48, 1
  store { i64, i1 } %t49, ptr %l28
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, i1 }, ptr %l28
  store { i64, i1 } %t50, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t51 = load i8, ptr %l5, !tbaa !22
  store i8 %t51, ptr %l29, !tbaa !22
  %t52 = load i8, ptr %l29, !tbaa !22
  %t53 = icmp eq i8 %t52, 10
  store i1 %t53, ptr %l30, !tbaa !21
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 true, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l2, !tbaa !24
  store i64 %t55, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l31, !tbaa !24
  %t57 = add i64 %t56, 1
  store i64 %t57, ptr %l32, !tbaa !24
  %t58 = load i64, ptr %l32, !tbaa !24
  store i64 %t58, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  br label %bb1
bb15:
  %t59 = load i1, ptr %l4, !tbaa !21
  store i1 %t59, ptr %l33, !tbaa !21
  %t60 = insertvalue { i64, i1 } undef, i64 -1, 0
  %t61 = load i1, ptr %l33, !tbaa !21
  %t62 = insertvalue { i64, i1 } %t60, i1 %t61, 1
  store { i64, i1 } %t62, ptr %l34
  call void @__olang_scope_close(ptr %s0)
  %t63 = load { i64, i1 }, ptr %l34
  store { i64, i1 } %t63, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i1 }, ptr %rv
  ret { i64, i1 } %rr
}

define dso_local i1 @compiler_2fscan_2ecanStart(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca { i32, i64 }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i8
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i8
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i8
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i8
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i8
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i8
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i8
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i8
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i8
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i32, i64 }
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i1
  %l51 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l6, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i8, ptr %t5, i64 %t3
  %t7 = load i8, ptr %t6, !tbaa !32
  store i8 %t7, ptr %l7, !tbaa !22
  %t8 = load i8, ptr %l7, !tbaa !22
  store i8 %t8, ptr %l2, !tbaa !22
  %t9 = load i8, ptr %l2, !tbaa !22
  store i8 %t9, ptr %l8, !tbaa !22
  %t10 = load i8, ptr %l8, !tbaa !22
  %t11 = call i1 @compiler_2fscan_2eisWordChar(i8 %t10)
  store i1 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i8, ptr %l2, !tbaa !22
  store i8 %t13, ptr %l11, !tbaa !22
  %t14 = load i8, ptr %l11, !tbaa !22
  %t15 = icmp eq i8 %t14, 32
  store i1 %t15, ptr %l12, !tbaa !21
  %t16 = load i1, ptr %l12, !tbaa !21
  store i1 %t16, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t18 = load i8, ptr %l2, !tbaa !22
  store i8 %t18, ptr %l14, !tbaa !22
  %t19 = load i8, ptr %l14, !tbaa !22
  %t20 = icmp eq i8 %t19, 9
  store i1 %t20, ptr %l15, !tbaa !21
  %t21 = load i1, ptr %l15, !tbaa !21
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb9:
  %t23 = load i8, ptr %l2, !tbaa !22
  store i8 %t23, ptr %l17, !tbaa !22
  %t24 = load i8, ptr %l17, !tbaa !22
  %t25 = icmp eq i8 %t24, 10
  store i1 %t25, ptr %l18, !tbaa !21
  %t26 = load i1, ptr %l18, !tbaa !21
  store i1 %t26, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb13
bb12:
  %t28 = load i8, ptr %l2, !tbaa !22
  store i8 %t28, ptr %l20, !tbaa !22
  %t29 = load i8, ptr %l20, !tbaa !22
  %t30 = icmp eq i8 %t29, 35
  store i1 %t30, ptr %l21, !tbaa !21
  %t31 = load i1, ptr %l21, !tbaa !21
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb16
bb15:
  %t33 = load i8, ptr %l2, !tbaa !22
  store i8 %t33, ptr %l23, !tbaa !22
  %t34 = load i8, ptr %l23, !tbaa !22
  %t35 = icmp eq i8 %t34, 34
  store i1 %t35, ptr %l24, !tbaa !21
  %t36 = load i1, ptr %l24, !tbaa !21
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb19
bb18:
  %t38 = load i8, ptr %l2, !tbaa !22
  store i8 %t38, ptr %l26, !tbaa !22
  %t39 = load i8, ptr %l26, !tbaa !22
  %t40 = icmp eq i8 %t39, 39
  store i1 %t40, ptr %l27, !tbaa !21
  %t41 = load i1, ptr %l27, !tbaa !21
  store i1 %t41, ptr %l25, !tbaa !21
  br label %bb19
bb19:
  %t42 = load i1, ptr %l25, !tbaa !21
  br i1 %t42, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 true, ptr %l28, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i1, ptr %l28, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t44 = load i8, ptr %l2, !tbaa !22
  store i8 %t44, ptr %l29, !tbaa !22
  %t45 = load i8, ptr %l29, !tbaa !22
  %t46 = icmp eq i8 %t45, 33
  store i1 %t46, ptr %l30, !tbaa !21
  %t47 = load i1, ptr %l30, !tbaa !21
  br i1 %t47, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l1, !tbaa !24
  store i64 %t48, ptr %l31, !tbaa !24
  %t49 = load i64, ptr %l31, !tbaa !24
  %t50 = add i64 %t49, 1
  store i64 %t50, ptr %l32, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l34, !tbaa !24
  %t54 = load i64, ptr %l32, !tbaa !24
  %t55 = load i64, ptr %l34, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  store i1 %t56, ptr %l35, !tbaa !21
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb25, label %bb26
bb24:
  br label %bb28
bb25:
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t58, ptr %l37, !tbaa !27
  %t59 = load i64, ptr %l1, !tbaa !24
  store i64 %t59, ptr %l38, !tbaa !24
  %t60 = load i64, ptr %l38, !tbaa !24
  %t61 = add i64 %t60, 1
  store i64 %t61, ptr %l39, !tbaa !24
  %t62 = load i64, ptr %l39, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 %t62
  %t66 = load i8, ptr %t65, !tbaa !32
  store i8 %t66, ptr %l40, !tbaa !22
  %t67 = load i8, ptr %l40, !tbaa !22
  %t68 = icmp eq i8 %t67, 61
  store i1 %t68, ptr %l41, !tbaa !21
  %t69 = load i1, ptr %l41, !tbaa !21
  store i1 %t69, ptr %l36, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t70 = load i1, ptr %l36, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
bb28:
  %t71 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  %t72 = load i64, ptr %l1, !tbaa !24
  store i64 %t72, ptr %l43, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t74 = load i64, ptr %l43, !tbaa !24
  %t75 = call { i32, i64 } @compiler_2fscan_2eoperator(ptr %v0, { i64, ptr } %t73, i64 %t74)
  store { i32, i64 } %t75, ptr %l44
  br label %bb29
bb29:
  %t76 = load { i32, i64 }, ptr %l44
  store { i32, i64 } %t76, ptr %l3
  %t77 = getelementptr { i32, i64 }, ptr %l3, i32 0, i32 0
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l45
  %t79 = load i32, ptr %l45
  store i32 %t79, ptr %l4
  %t80 = load i32, ptr %l4
  store i32 %t80, ptr %l46
  store ptr %l46, ptr %l47, !tbaa !29
  store i32 0, ptr %l48
  store ptr %l48, ptr %l49, !tbaa !29
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = load ptr, ptr %l49, !tbaa !29
  %t83 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t81, ptr %t82)
  store i1 %t83, ptr %l50
  br label %bb30
bb30:
  %t84 = load i1, ptr %l50, !tbaa !21
  %t85 = xor i1 %t84, true
  store i1 %t85, ptr %l51, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t86 = load i1, ptr %l51, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %v0, %"compiler/scan:Diag" %a0) #0 {
entry:
  %l0 = alloca %"compiler/scan:Diag"
  %l1 = alloca i8
  %l2 = alloca i32
  %l3 = alloca i8
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i8
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i32
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i32
  %l59 = alloca i1
  %l60 = alloca i8
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %l63 = alloca i1
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i32
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i8
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l75 = alloca i1
  %l76 = alloca i8
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i32
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i32
  %l87 = alloca i1
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.builder
  %s16room = alloca [64 x i8], align 8
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.builder
  %s20room = alloca [64 x i8], align 8
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.builder
  %s22room = alloca [64 x i8], align 8
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/scan:Diag" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/scan:Diag", ptr %l0, i32 0, i32 3
  %t2 = load i8, ptr %t1, !tbaa !22
  store i8 %t2, ptr %l3, !tbaa !22
  %t3 = load i8, ptr %l3, !tbaa !22
  store i8 %t3, ptr %l1, !tbaa !22
  %t4 = getelementptr %"compiler/scan:Diag", ptr %l0, i32 0, i32 0
  %t5 = load i32, ptr %t4
  store i32 %t5, ptr %l4
  %t6 = load i32, ptr %l4
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  store i32 %t7, ptr %l6
  %t8 = load i32, ptr %l6
  %t9 = trunc i64 0 to i32
  %t10 = icmp eq i32 %t8, %t9
  store i1 %t10, ptr %l7, !tbaa !21
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load i8, ptr %l1, !tbaa !22
  store i8 %t12, ptr %l8, !tbaa !22
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t13 = extractvalue { i64, ptr } { i64 22, ptr @.d2 }, 1
  %t14 = extractvalue { i64, ptr } { i64 22, ptr @.d2 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t13, i64 %t14)
  %t15 = load i8, ptr %l8, !tbaa !22
  %t16 = call ptr @__olang_sb_room(ptr %s2, i64 1)
  store i8 %t15, ptr %t16
  call void @__olang_sb_add(ptr %s2, i64 1)
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t17, i64 %t18)
  %t19 = load ptr, ptr %s2
  %t20 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb85
bb4:
  %t26 = load i32, ptr %l2
  store i32 %t26, ptr %l10
  %t27 = load i32, ptr %l10
  %t28 = trunc i64 1 to i32
  %t29 = icmp eq i32 %t27, %t28
  store i1 %t29, ptr %l11, !tbaa !21
  %t30 = load i1, ptr %l11, !tbaa !21
  br i1 %t30, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 38, ptr @.d4 }, ptr %l12, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t31, ptr %l13, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t32, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb85
bb8:
  %t33 = load i32, ptr %l2
  store i32 %t33, ptr %l14
  %t34 = load i32, ptr %l14
  %t35 = trunc i64 2 to i32
  %t36 = icmp eq i32 %t34, %t35
  store i1 %t36, ptr %l15, !tbaa !21
  %t37 = load i1, ptr %l15, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 45, ptr @.d5 }, ptr %l16, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t38, ptr %l17, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t39, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb85
bb12:
  %t40 = load i32, ptr %l2
  store i32 %t40, ptr %l18
  %t41 = load i32, ptr %l18
  %t42 = trunc i64 3 to i32
  %t43 = icmp eq i32 %t41, %t42
  store i1 %t43, ptr %l19, !tbaa !21
  %t44 = load i1, ptr %l19, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  store { i64, ptr } { i64 52, ptr @.d6 }, ptr %l20, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t45, ptr %l21, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t46, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb85
bb16:
  %t47 = load i32, ptr %l2
  store i32 %t47, ptr %l22
  %t48 = load i32, ptr %l22
  %t49 = trunc i64 4 to i32
  %t50 = icmp eq i32 %t48, %t49
  store i1 %t50, ptr %l23, !tbaa !21
  %t51 = load i1, ptr %l23, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  store { i64, ptr } { i64 94, ptr @.d7 }, ptr %l24, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t52, ptr %l25, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t53, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb85
bb20:
  %t54 = load i32, ptr %l2
  store i32 %t54, ptr %l26
  %t55 = load i32, ptr %l26
  %t56 = trunc i64 5 to i32
  %t57 = icmp eq i32 %t55, %t56
  store i1 %t57, ptr %l27, !tbaa !21
  %t58 = load i1, ptr %l27, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } { i64 95, ptr @.d8 }, ptr %l28, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t60, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb85
bb24:
  %t61 = load i32, ptr %l2
  store i32 %t61, ptr %l30
  %t62 = load i32, ptr %l30
  %t63 = trunc i64 6 to i32
  %t64 = icmp eq i32 %t62, %t63
  store i1 %t64, ptr %l31, !tbaa !21
  %t65 = load i1, ptr %l31, !tbaa !21
  br i1 %t65, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  store { i64, ptr } { i64 43, ptr @.d9 }, ptr %l32, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t66, ptr %l33, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t67, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb85
bb28:
  %t68 = load i32, ptr %l2
  store i32 %t68, ptr %l34
  %t69 = load i32, ptr %l34
  %t70 = trunc i64 7 to i32
  %t71 = icmp eq i32 %t69, %t70
  store i1 %t71, ptr %l35, !tbaa !21
  %t72 = load i1, ptr %l35, !tbaa !21
  br i1 %t72, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  store { i64, ptr } { i64 27, ptr @.d10 }, ptr %l36, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t73, ptr %l37, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t74, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb85
bb32:
  %t75 = load i32, ptr %l2
  store i32 %t75, ptr %l38
  %t76 = load i32, ptr %l38
  %t77 = trunc i64 8 to i32
  %t78 = icmp eq i32 %t76, %t77
  store i1 %t78, ptr %l39, !tbaa !21
  %t79 = load i1, ptr %l39, !tbaa !21
  br i1 %t79, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s10
  store { i64, ptr } { i64 62, ptr @.d11 }, ptr %l40, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t80, ptr %l41, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t81, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  br label %bb85
bb36:
  %t82 = load i32, ptr %l2
  store i32 %t82, ptr %l42
  %t83 = load i32, ptr %l42
  %t84 = trunc i64 9 to i32
  %t85 = icmp eq i32 %t83, %t84
  store i1 %t85, ptr %l43, !tbaa !21
  %t86 = load i1, ptr %l43, !tbaa !21
  br i1 %t86, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  store { i64, ptr } { i64 30, ptr @.d12 }, ptr %l44, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t87, ptr %l45, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t88, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb85
bb40:
  %t89 = load i32, ptr %l2
  store i32 %t89, ptr %l46
  %t90 = load i32, ptr %l46
  %t91 = trunc i64 10 to i32
  %t92 = icmp eq i32 %t90, %t91
  store i1 %t92, ptr %l47, !tbaa !21
  %t93 = load i1, ptr %l47, !tbaa !21
  br i1 %t93, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s12
  store { i64, ptr } { i64 40, ptr @.d13 }, ptr %l48, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t94, ptr %l49, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t95, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb85
bb44:
  %t96 = load i32, ptr %l2
  store i32 %t96, ptr %l50
  %t97 = load i32, ptr %l50
  %t98 = trunc i64 11 to i32
  %t99 = icmp eq i32 %t97, %t98
  store i1 %t99, ptr %l51, !tbaa !21
  %t100 = load i1, ptr %l51, !tbaa !21
  br i1 %t100, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  store { i64, ptr } { i64 23, ptr @.d14 }, ptr %l52, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t101, ptr %l53, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t102, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb85
bb48:
  %t103 = load i32, ptr %l2
  store i32 %t103, ptr %l54
  %t104 = load i32, ptr %l54
  %t105 = trunc i64 12 to i32
  %t106 = icmp eq i32 %t104, %t105
  store i1 %t106, ptr %l55, !tbaa !21
  %t107 = load i1, ptr %l55, !tbaa !21
  br i1 %t107, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s14
  store { i64, ptr } { i64 71, ptr @.d15 }, ptr %l56, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t108, ptr %l57, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t109, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb85
bb52:
  %t110 = load i32, ptr %l2
  store i32 %t110, ptr %l58
  %t111 = load i32, ptr %l58
  %t112 = trunc i64 13 to i32
  %t113 = icmp eq i32 %t111, %t112
  store i1 %t113, ptr %l59, !tbaa !21
  %t114 = load i1, ptr %l59, !tbaa !21
  br i1 %t114, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s15
  %t115 = load i8, ptr %l1, !tbaa !22
  store i8 %t115, ptr %l60, !tbaa !22
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s16
  store ptr %s16room, ptr %s16
  %t116 = extractvalue { i64, ptr } { i64 17, ptr @.d16 }, 1
  %t117 = extractvalue { i64, ptr } { i64 17, ptr @.d16 }, 0
  call void @__olang_sb_put(ptr %s16, ptr %t116, i64 %t117)
  %t118 = load i8, ptr %l60, !tbaa !22
  %t119 = call ptr @__olang_sb_room(ptr %s16, i64 1)
  store i8 %t118, ptr %t119
  call void @__olang_sb_add(ptr %s16, i64 1)
  %t120 = extractvalue { i64, ptr } { i64 40, ptr @.d17 }, 1
  %t121 = extractvalue { i64, ptr } { i64 40, ptr @.d17 }, 0
  call void @__olang_sb_put(ptr %s16, ptr %t120, i64 %t121)
  %t122 = load ptr, ptr %s16
  %t123 = getelementptr %olang.builder, ptr %s16, i32 0, i32 1
  %t124 = load i64, ptr %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t122, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l61, !tbaa !27
  call void @__olang_sb_done(ptr %s16)
  %t128 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t128, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  br label %bb85
bb56:
  %t129 = load i32, ptr %l2
  store i32 %t129, ptr %l62
  %t130 = load i32, ptr %l62
  %t131 = trunc i64 14 to i32
  %t132 = icmp eq i32 %t130, %t131
  store i1 %t132, ptr %l63, !tbaa !21
  %t133 = load i1, ptr %l63, !tbaa !21
  br i1 %t133, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s17
  store { i64, ptr } { i64 29, ptr @.d18 }, ptr %l64, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t134, ptr %l65, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t135, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb85
bb60:
  %t136 = load i32, ptr %l2
  store i32 %t136, ptr %l66
  %t137 = load i32, ptr %l66
  %t138 = trunc i64 15 to i32
  %t139 = icmp eq i32 %t137, %t138
  store i1 %t139, ptr %l67, !tbaa !21
  %t140 = load i1, ptr %l67, !tbaa !21
  br i1 %t140, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s18
  store { i64, ptr } { i64 24, ptr @.d19 }, ptr %l68, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t141, ptr %l69, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t142, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s18)
  br label %bb85
bb64:
  %t143 = load i32, ptr %l2
  store i32 %t143, ptr %l70
  %t144 = load i32, ptr %l70
  %t145 = trunc i64 16 to i32
  %t146 = icmp eq i32 %t144, %t145
  store i1 %t146, ptr %l71, !tbaa !21
  %t147 = load i1, ptr %l71, !tbaa !21
  br i1 %t147, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s19
  %t148 = load i8, ptr %l1, !tbaa !22
  store i8 %t148, ptr %l72, !tbaa !22
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s20
  store ptr %s20room, ptr %s20
  %t149 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  call void @__olang_sb_put(ptr %s20, ptr %t149, i64 %t150)
  %t151 = load i8, ptr %l72, !tbaa !22
  %t152 = call ptr @__olang_sb_room(ptr %s20, i64 1)
  store i8 %t151, ptr %t152
  call void @__olang_sb_add(ptr %s20, i64 1)
  %t153 = extractvalue { i64, ptr } { i64 28, ptr @.d21 }, 1
  %t154 = extractvalue { i64, ptr } { i64 28, ptr @.d21 }, 0
  call void @__olang_sb_put(ptr %s20, ptr %t153, i64 %t154)
  %t155 = load ptr, ptr %s20
  %t156 = getelementptr %olang.builder, ptr %s20, i32 0, i32 1
  %t157 = load i64, ptr %t156
  %t158 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t155, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  store { i64, ptr } %t160, ptr %l73, !tbaa !27
  call void @__olang_sb_done(ptr %s20)
  %t161 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t161, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb85
bb68:
  %t162 = load i32, ptr %l2
  store i32 %t162, ptr %l74
  %t163 = load i32, ptr %l74
  %t164 = trunc i64 17 to i32
  %t165 = icmp eq i32 %t163, %t164
  store i1 %t165, ptr %l75, !tbaa !21
  %t166 = load i1, ptr %l75, !tbaa !21
  br i1 %t166, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s21
  %t167 = load i8, ptr %l1, !tbaa !22
  store i8 %t167, ptr %l76, !tbaa !22
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s22
  store ptr %s22room, ptr %s22
  %t168 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 0
  call void @__olang_sb_put(ptr %s22, ptr %t168, i64 %t169)
  %t170 = load i8, ptr %l76, !tbaa !22
  %t171 = call ptr @__olang_sb_room(ptr %s22, i64 1)
  store i8 %t170, ptr %t171
  call void @__olang_sb_add(ptr %s22, i64 1)
  %t172 = extractvalue { i64, ptr } { i64 23, ptr @.d23 }, 1
  %t173 = extractvalue { i64, ptr } { i64 23, ptr @.d23 }, 0
  call void @__olang_sb_put(ptr %s22, ptr %t172, i64 %t173)
  %t174 = load ptr, ptr %s22
  %t175 = getelementptr %olang.builder, ptr %s22, i32 0, i32 1
  %t176 = load i64, ptr %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t176)
  call void @llvm.memcpy.p0.p0.i64(ptr %t177, ptr %t174, i64 %t176, i1 false)
  %t178 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  store { i64, ptr } %t179, ptr %l77, !tbaa !27
  call void @__olang_sb_done(ptr %s22)
  %t180 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t180, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s21)
  br label %bb85
bb72:
  %t181 = load i32, ptr %l2
  store i32 %t181, ptr %l78
  %t182 = load i32, ptr %l78
  %t183 = trunc i64 18 to i32
  %t184 = icmp eq i32 %t182, %t183
  store i1 %t184, ptr %l79, !tbaa !21
  %t185 = load i1, ptr %l79, !tbaa !21
  br i1 %t185, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s23
  store { i64, ptr } { i64 45, ptr @.d24 }, ptr %l80, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t186, ptr %l81, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t187, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s23)
  br label %bb85
bb76:
  %t188 = load i32, ptr %l2
  store i32 %t188, ptr %l82
  %t189 = load i32, ptr %l82
  %t190 = trunc i64 19 to i32
  %t191 = icmp eq i32 %t189, %t190
  store i1 %t191, ptr %l83, !tbaa !21
  %t192 = load i1, ptr %l83, !tbaa !21
  br i1 %t192, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s24
  store { i64, ptr } { i64 38, ptr @.d25 }, ptr %l84, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t193, ptr %l85, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t194, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s24)
  br label %bb85
bb80:
  %t195 = load i32, ptr %l2
  store i32 %t195, ptr %l86
  %t196 = load i32, ptr %l86
  %t197 = trunc i64 20 to i32
  %t198 = icmp eq i32 %t196, %t197
  store i1 %t198, ptr %l87, !tbaa !21
  %t199 = load i1, ptr %l87, !tbaa !21
  br i1 %t199, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s25
  store { i64, ptr } { i64 38, ptr @.d26 }, ptr %l88, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t200, ptr %l89, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t201, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s25)
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t202 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t202, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %v0, %"compiler/scan:Diag" %a0) #0 {
entry:
  %l0 = alloca %"compiler/scan:Diag"
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i32
  %l27 = alloca i1
  %l28 = alloca i32
  %l29 = alloca i1
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i32
  %l37 = alloca i1
  %l38 = alloca i32
  %l39 = alloca i1
  %l40 = alloca i32
  %l41 = alloca i1
  %l42 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i32
  %l45 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/scan:Diag" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/scan:Diag", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1
  store i32 %t2, ptr %l2
  %t3 = load i32, ptr %l2
  store i32 %t3, ptr %l1
  %t4 = load i32, ptr %l1
  store i32 %t4, ptr %l4
  %t5 = load i32, ptr %l4
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t5, %t6
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 3, ptr @.d28 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb69
bb4:
  %t9 = load i32, ptr %l1
  store i32 %t9, ptr %l6
  %t10 = load i32, ptr %l6
  %t11 = trunc i64 1 to i32
  %t12 = icmp eq i32 %t10, %t11
  store i1 %t12, ptr %l7, !tbaa !21
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t14 = load i32, ptr %l1
  store i32 %t14, ptr %l8
  %t15 = load i32, ptr %l8
  %t16 = trunc i64 2 to i32
  %t17 = icmp eq i32 %t15, %t16
  store i1 %t17, ptr %l9, !tbaa !21
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 2, ptr @.d29 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb69
bb10:
  %t19 = load i32, ptr %l1
  store i32 %t19, ptr %l10
  %t20 = load i32, ptr %l10
  %t21 = trunc i64 3 to i32
  %t22 = icmp eq i32 %t20, %t21
  store i1 %t22, ptr %l11, !tbaa !21
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 2, ptr @.d30 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb14:
  %t24 = load i32, ptr %l1
  store i32 %t24, ptr %l12
  %t25 = load i32, ptr %l12
  %t26 = trunc i64 4 to i32
  %t27 = icmp eq i32 %t25, %t26
  store i1 %t27, ptr %l13, !tbaa !21
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 3, ptr @.d31 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb69
bb18:
  %t29 = load i32, ptr %l1
  store i32 %t29, ptr %l14
  %t30 = load i32, ptr %l14
  %t31 = trunc i64 5 to i32
  %t32 = icmp eq i32 %t30, %t31
  store i1 %t32, ptr %l15, !tbaa !21
  %t33 = load i1, ptr %l15, !tbaa !21
  br i1 %t33, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  store { i64, ptr } { i64 4, ptr @.d32 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb69
bb22:
  %t34 = load i32, ptr %l1
  store i32 %t34, ptr %l16
  %t35 = load i32, ptr %l16
  %t36 = trunc i64 6 to i32
  %t37 = icmp eq i32 %t35, %t36
  store i1 %t37, ptr %l17, !tbaa !21
  %t38 = load i1, ptr %l17, !tbaa !21
  br i1 %t38, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  store { i64, ptr } { i64 3, ptr @.d33 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb69
bb26:
  %t39 = load i32, ptr %l1
  store i32 %t39, ptr %l18
  %t40 = load i32, ptr %l18
  %t41 = trunc i64 7 to i32
  %t42 = icmp eq i32 %t40, %t41
  store i1 %t42, ptr %l19, !tbaa !21
  %t43 = load i1, ptr %l19, !tbaa !21
  br i1 %t43, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  %t44 = load i32, ptr %l1
  store i32 %t44, ptr %l20
  %t45 = load i32, ptr %l20
  %t46 = trunc i64 8 to i32
  %t47 = icmp eq i32 %t45, %t46
  store i1 %t47, ptr %l21, !tbaa !21
  %t48 = load i1, ptr %l21, !tbaa !21
  br i1 %t48, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } { i64 3, ptr @.d34 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb69
bb32:
  %t49 = load i32, ptr %l1
  store i32 %t49, ptr %l22
  %t50 = load i32, ptr %l22
  %t51 = trunc i64 9 to i32
  %t52 = icmp eq i32 %t50, %t51
  store i1 %t52, ptr %l23, !tbaa !21
  %t53 = load i1, ptr %l23, !tbaa !21
  br i1 %t53, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  %t54 = load i32, ptr %l1
  store i32 %t54, ptr %l24
  %t55 = load i32, ptr %l24
  %t56 = trunc i64 10 to i32
  %t57 = icmp eq i32 %t55, %t56
  store i1 %t57, ptr %l25, !tbaa !21
  %t58 = load i1, ptr %l25, !tbaa !21
  br i1 %t58, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  %t59 = load i32, ptr %l1
  store i32 %t59, ptr %l26
  %t60 = load i32, ptr %l26
  %t61 = trunc i64 11 to i32
  %t62 = icmp eq i32 %t60, %t61
  store i1 %t62, ptr %l27, !tbaa !21
  %t63 = load i1, ptr %l27, !tbaa !21
  br i1 %t63, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  %t64 = load i32, ptr %l1
  store i32 %t64, ptr %l28
  %t65 = load i32, ptr %l28
  %t66 = trunc i64 12 to i32
  %t67 = icmp eq i32 %t65, %t66
  store i1 %t67, ptr %l29, !tbaa !21
  %t68 = load i1, ptr %l29, !tbaa !21
  br i1 %t68, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  store { i64, ptr } { i64 3, ptr @.d35 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb69
bb42:
  %t69 = load i32, ptr %l1
  store i32 %t69, ptr %l30
  %t70 = load i32, ptr %l30
  %t71 = trunc i64 13 to i32
  %t72 = icmp eq i32 %t70, %t71
  store i1 %t72, ptr %l31, !tbaa !21
  %t73 = load i1, ptr %l31, !tbaa !21
  br i1 %t73, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  store { i64, ptr } { i64 3, ptr @.d36 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb69
bb46:
  %t74 = load i32, ptr %l1
  store i32 %t74, ptr %l32
  %t75 = load i32, ptr %l32
  %t76 = trunc i64 14 to i32
  %t77 = icmp eq i32 %t75, %t76
  store i1 %t77, ptr %l33, !tbaa !21
  %t78 = load i1, ptr %l33, !tbaa !21
  br i1 %t78, label %bb47, label %bb48
bb47:
  br label %bb51
bb48:
  %t79 = load i32, ptr %l1
  store i32 %t79, ptr %l34
  %t80 = load i32, ptr %l34
  %t81 = trunc i64 16 to i32
  %t82 = icmp eq i32 %t80, %t81
  store i1 %t82, ptr %l35, !tbaa !21
  %t83 = load i1, ptr %l35, !tbaa !21
  br i1 %t83, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  store { i64, ptr } { i64 4, ptr @.d37 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  br label %bb69
bb52:
  %t84 = load i32, ptr %l1
  store i32 %t84, ptr %l36
  %t85 = load i32, ptr %l36
  %t86 = trunc i64 15 to i32
  %t87 = icmp eq i32 %t85, %t86
  store i1 %t87, ptr %l37, !tbaa !21
  %t88 = load i1, ptr %l37, !tbaa !21
  br i1 %t88, label %bb53, label %bb54
bb53:
  br label %bb57
bb54:
  %t89 = load i32, ptr %l1
  store i32 %t89, ptr %l38
  %t90 = load i32, ptr %l38
  %t91 = trunc i64 17 to i32
  %t92 = icmp eq i32 %t90, %t91
  store i1 %t92, ptr %l39, !tbaa !21
  %t93 = load i1, ptr %l39, !tbaa !21
  br i1 %t93, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s11
  store { i64, ptr } { i64 4, ptr @.d38 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb69
bb58:
  %t94 = load i32, ptr %l1
  store i32 %t94, ptr %l40
  %t95 = load i32, ptr %l40
  %t96 = trunc i64 18 to i32
  %t97 = icmp eq i32 %t95, %t96
  store i1 %t97, ptr %l41, !tbaa !21
  %t98 = load i1, ptr %l41, !tbaa !21
  br i1 %t98, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s12
  store { i64, ptr } { i64 4, ptr @.d39 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb69
bb62:
  %t99 = load i32, ptr %l1
  store i32 %t99, ptr %l42
  %t100 = load i32, ptr %l42
  %t101 = trunc i64 19 to i32
  %t102 = icmp eq i32 %t100, %t101
  store i1 %t102, ptr %l43, !tbaa !21
  %t103 = load i1, ptr %l43, !tbaa !21
  br i1 %t103, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  %t104 = load i32, ptr %l1
  store i32 %t104, ptr %l44
  %t105 = load i32, ptr %l44
  %t106 = trunc i64 20 to i32
  %t107 = icmp eq i32 %t105, %t106
  store i1 %t107, ptr %l45, !tbaa !21
  %t108 = load i1, ptr %l45, !tbaa !21
  br i1 %t108, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s13
  store { i64, ptr } { i64 3, ptr @.d40 }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @.c41)
  unreachable
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t109, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = getelementptr %"compiler/scan:Tokens", ptr %t2, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l7, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l8, !tbaa !24
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = sub i64 %t7, 1
  store i64 %t8, ptr %l9, !tbaa !24
  %t9 = load i64, ptr %l9, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l11, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = icmp sle i64 %t12, %t13
  store i1 %t14, ptr %l12, !tbaa !21
  %t15 = load i1, ptr %l12, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l13, !tbaa !21
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l14, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  store i64 %t19, ptr %l15, !tbaa !24
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = load i64, ptr %l15, !tbaa !24
  %t22 = add i64 %t20, %t21
  store i64 %t22, ptr %l16, !tbaa !24
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = sdiv i64 %t23, 2
  store i64 %t24, ptr %l17, !tbaa !24
  %t25 = load i64, ptr %l17, !tbaa !24
  store i64 %t25, ptr %l4, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load ptr, ptr %l18, !tbaa !29
  %t28 = getelementptr %"compiler/scan:Tokens", ptr %t27, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  store i64 %t30, ptr %l20, !tbaa !24
  %t31 = load i64, ptr %l20, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i32, ptr %t33, i64 %t31
  %t35 = load i32, ptr %t34, !tbaa !33
  store i32 %t35, ptr %l21, !tbaa !23
  %t36 = load i32, ptr %l21, !tbaa !23
  store i32 %t36, ptr %l5, !tbaa !23
  %t37 = load i32, ptr %l5, !tbaa !23
  store i32 %t37, ptr %l22, !tbaa !23
  %t38 = load i32, ptr %l1, !tbaa !23
  store i32 %t38, ptr %l23, !tbaa !23
  %t39 = load i32, ptr %l22, !tbaa !23
  %t40 = load i32, ptr %l23, !tbaa !23
  %t41 = icmp eq i32 %t39, %t40
  store i1 %t41, ptr %l24, !tbaa !21
  %t42 = load i1, ptr %l24, !tbaa !21
  br i1 %t42, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = getelementptr %"compiler/scan:Tokens", ptr %t44, i32 0, i32 2
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l26, !tbaa !27
  %t47 = load i64, ptr %l4, !tbaa !24
  store i64 %t47, ptr %l27, !tbaa !24
  %t48 = load i64, ptr %l27, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 %t48
  %t52 = load i32, ptr %t51, !tbaa !33
  store i32 %t52, ptr %l28, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t53 = load i32, ptr %l28, !tbaa !23
  store i32 %t53, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t54 = load i32, ptr %l5, !tbaa !23
  store i32 %t54, ptr %l29, !tbaa !23
  %t55 = load i32, ptr %l1, !tbaa !23
  store i32 %t55, ptr %l30, !tbaa !23
  %t56 = load i32, ptr %l29, !tbaa !23
  %t57 = load i32, ptr %l30, !tbaa !23
  %t58 = icmp slt i32 %t56, %t57
  store i1 %t58, ptr %l31, !tbaa !21
  %t59 = load i1, ptr %l31, !tbaa !21
  br i1 %t59, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load i64, ptr %l4, !tbaa !24
  store i64 %t60, ptr %l32, !tbaa !24
  %t61 = load i64, ptr %l32, !tbaa !24
  %t62 = add i64 %t61, 1
  store i64 %t62, ptr %l33, !tbaa !24
  %t63 = load i64, ptr %l33, !tbaa !24
  store i64 %t63, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load i64, ptr %l4, !tbaa !24
  store i64 %t64, ptr %l34, !tbaa !24
  %t65 = load i64, ptr %l34, !tbaa !24
  %t66 = sub i64 %t65, 1
  store i64 %t66, ptr %l35, !tbaa !24
  %t67 = load i64, ptr %l35, !tbaa !24
  store i64 %t67, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  br label %bb1
bb12:
  store i32 -1, ptr %l36, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t68 = load i32, ptr %l36, !tbaa !23
  store i32 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2echar(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca i8
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i8
  %l26 = alloca i8
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i8
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i8
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i8
  %l57 = alloca i8
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i8
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i8
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i8
  %l90 = alloca i1
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca i8
  %l96 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i1
  %l106 = alloca i1
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca i8
  %l110 = alloca i1
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca i8
  %l115 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i1
  %l122 = alloca i1
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca i8
  %l126 = alloca i1
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca ptr
  %l132 = alloca i32
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l10, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t5, ptr %l2, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l11, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l12, !tbaa !24
  %t9 = load i64, ptr %l12, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l13, !tbaa !24
  %t11 = load i64, ptr %l13, !tbaa !24
  %t12 = add i64 %t11, 1
  store i64 %t12, ptr %l14, !tbaa !24
  %t13 = load i64, ptr %l14, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %l15, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l16, !tbaa !24
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = load i64, ptr %l16, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l17, !tbaa !21
  %t19 = load i1, ptr %l17, !tbaa !21
  br i1 %t19, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l18, !tbaa !29
  store i32 9, ptr %l19
  %t21 = load i64, ptr %l1, !tbaa !24
  store i64 %t21, ptr %l20, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l21, !tbaa !24
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = load i32, ptr %l19
  %t25 = load i64, ptr %l20, !tbaa !24
  %t26 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t23, i32 %t24, i64 %t25, i64 %t26, i8 0)
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i64, ptr %l22, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
bb4:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l23, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load i64, ptr %l24, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t31
  %t35 = load i8, ptr %t34, !tbaa !32
  store i8 %t35, ptr %l25, !tbaa !22
  %t36 = load i8, ptr %l25, !tbaa !22
  store i8 %t36, ptr %l5, !tbaa !22
  %t37 = load i8, ptr %l5, !tbaa !22
  store i8 %t37, ptr %l26, !tbaa !22
  %t38 = load i8, ptr %l26, !tbaa !22
  %t39 = icmp eq i8 %t38, 10
  store i1 %t39, ptr %l27, !tbaa !21
  %t40 = load i1, ptr %l27, !tbaa !21
  br i1 %t40, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l28, !tbaa !29
  store i32 10, ptr %l29
  %t42 = load i64, ptr %l1, !tbaa !24
  store i64 %t42, ptr %l30, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  store i64 %t43, ptr %l31, !tbaa !24
  %t44 = load ptr, ptr %l28, !tbaa !29
  %t45 = load i32, ptr %l29
  %t46 = load i64, ptr %l30, !tbaa !24
  %t47 = load i64, ptr %l31, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t44, i32 %t45, i64 %t46, i64 %t47, i8 0)
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t48 = load i64, ptr %l4, !tbaa !24
  store i64 %t48, ptr %l32, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t49 = load i64, ptr %l32, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
bb8:
  %t50 = load i8, ptr %l5, !tbaa !22
  store i8 %t50, ptr %l33, !tbaa !22
  %t51 = load i8, ptr %l33, !tbaa !22
  %t52 = icmp eq i8 %t51, 39
  store i1 %t52, ptr %l34, !tbaa !21
  %t53 = load i1, ptr %l34, !tbaa !21
  br i1 %t53, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l35, !tbaa !29
  store i32 11, ptr %l36
  %t55 = load i64, ptr %l1, !tbaa !24
  store i64 %t55, ptr %l37, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  store i64 %t56, ptr %l38, !tbaa !24
  %t57 = load i64, ptr %l38, !tbaa !24
  %t58 = add i64 %t57, 1
  store i64 %t58, ptr %l39, !tbaa !24
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = load i32, ptr %l36
  %t61 = load i64, ptr %l37, !tbaa !24
  %t62 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t59, i32 %t60, i64 %t61, i64 %t62, i8 0)
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t63 = load i64, ptr %l4, !tbaa !24
  store i64 %t63, ptr %l40, !tbaa !24
  %t64 = load i64, ptr %l40, !tbaa !24
  %t65 = add i64 %t64, 1
  store i64 %t65, ptr %l41, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t66 = load i64, ptr %l41, !tbaa !24
  store i64 %t66, ptr %rv
  br label %ret
bb12:
  %t67 = load i8, ptr %l5, !tbaa !22
  store i8 %t67, ptr %l42, !tbaa !22
  %t68 = load i8, ptr %l42, !tbaa !22
  %t69 = icmp eq i8 %t68, 92
  store i1 %t69, ptr %l43, !tbaa !21
  %t70 = load i1, ptr %l43, !tbaa !21
  br i1 %t70, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load i64, ptr %l4, !tbaa !24
  store i64 %t71, ptr %l44, !tbaa !24
  %t72 = load i64, ptr %l44, !tbaa !24
  %t73 = add i64 %t72, 1
  store i64 %t73, ptr %l45, !tbaa !24
  %t74 = load i64, ptr %l3, !tbaa !24
  store i64 %t74, ptr %l46, !tbaa !24
  %t75 = load i64, ptr %l45, !tbaa !24
  %t76 = load i64, ptr %l46, !tbaa !24
  %t77 = icmp sge i64 %t75, %t76
  store i1 %t77, ptr %l47, !tbaa !21
  %t78 = load i1, ptr %l47, !tbaa !21
  br i1 %t78, label %bb15, label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s8
  %t79 = load i64, ptr %l4, !tbaa !24
  store i64 %t79, ptr %l77, !tbaa !24
  %t80 = load i64, ptr %l77, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l78, !tbaa !24
  %t82 = load i64, ptr %l78, !tbaa !24
  store i64 %t82, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb28
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l48, !tbaa !29
  store i32 9, ptr %l49
  %t84 = load i64, ptr %l1, !tbaa !24
  store i64 %t84, ptr %l50, !tbaa !24
  %t85 = load i64, ptr %l3, !tbaa !24
  store i64 %t85, ptr %l51, !tbaa !24
  %t86 = load ptr, ptr %l48, !tbaa !29
  %t87 = load i32, ptr %l49
  %t88 = load i64, ptr %l50, !tbaa !24
  %t89 = load i64, ptr %l51, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t86, i32 %t87, i64 %t88, i64 %t89, i8 0)
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t90 = load i64, ptr %l3, !tbaa !24
  store i64 %t90, ptr %l52, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t91 = load i64, ptr %l52, !tbaa !24
  store i64 %t91, ptr %rv
  br label %ret
bb18:
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l53, !tbaa !27
  %t93 = load i64, ptr %l4, !tbaa !24
  store i64 %t93, ptr %l54, !tbaa !24
  %t94 = load i64, ptr %l54, !tbaa !24
  %t95 = add i64 %t94, 1
  store i64 %t95, ptr %l55, !tbaa !24
  %t96 = load i64, ptr %l55, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i8, ptr %t98, i64 %t96
  %t100 = load i8, ptr %t99, !tbaa !32
  store i8 %t100, ptr %l56, !tbaa !22
  %t101 = load i8, ptr %l56, !tbaa !22
  store i8 %t101, ptr %l6, !tbaa !22
  %t102 = load i8, ptr %l6, !tbaa !22
  store i8 %t102, ptr %l57, !tbaa !22
  %t103 = load i8, ptr %l57, !tbaa !22
  %t104 = icmp eq i8 %t103, 10
  store i1 %t104, ptr %l58, !tbaa !21
  %t105 = load i1, ptr %l58, !tbaa !21
  br i1 %t105, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l59, !tbaa !29
  store i32 10, ptr %l60
  %t107 = load i64, ptr %l1, !tbaa !24
  store i64 %t107, ptr %l61, !tbaa !24
  %t108 = load i64, ptr %l4, !tbaa !24
  store i64 %t108, ptr %l62, !tbaa !24
  %t109 = load i64, ptr %l62, !tbaa !24
  %t110 = add i64 %t109, 1
  store i64 %t110, ptr %l63, !tbaa !24
  %t111 = load ptr, ptr %l59, !tbaa !29
  %t112 = load i32, ptr %l60
  %t113 = load i64, ptr %l61, !tbaa !24
  %t114 = load i64, ptr %l63, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t111, i32 %t112, i64 %t113, i64 %t114, i8 0)
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t115 = load i64, ptr %l4, !tbaa !24
  store i64 %t115, ptr %l64, !tbaa !24
  %t116 = load i64, ptr %l64, !tbaa !24
  %t117 = add i64 %t116, 1
  store i64 %t117, ptr %l65, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t118 = load i64, ptr %l65, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
bb22:
  %t119 = load i8, ptr %l6, !tbaa !22
  store i8 %t119, ptr %l66, !tbaa !22
  %t120 = load i8, ptr %l66, !tbaa !22
  %t121 = call i1 @compiler_2fscan_2eescapeOk(i8 %t120, i8 39)
  store i1 %t121, ptr %l67
  br label %bb23
bb23:
  %t122 = load i1, ptr %l67, !tbaa !21
  %t123 = xor i1 %t122, true
  store i1 %t123, ptr %l68, !tbaa !21
  %t124 = load i1, ptr %l68, !tbaa !21
  br i1 %t124, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l69, !tbaa !29
  store i32 13, ptr %l70
  %t126 = load i64, ptr %l4, !tbaa !24
  store i64 %t126, ptr %l71, !tbaa !24
  %t127 = load i64, ptr %l4, !tbaa !24
  store i64 %t127, ptr %l72, !tbaa !24
  %t128 = load i64, ptr %l72, !tbaa !24
  %t129 = add i64 %t128, 2
  store i64 %t129, ptr %l73, !tbaa !24
  %t130 = load i8, ptr %l6, !tbaa !22
  store i8 %t130, ptr %l74, !tbaa !22
  %t131 = load ptr, ptr %l69, !tbaa !29
  %t132 = load i32, ptr %l70
  %t133 = load i64, ptr %l71, !tbaa !24
  %t134 = load i64, ptr %l73, !tbaa !24
  %t135 = load i8, ptr %l74, !tbaa !22
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t131, i32 %t132, i64 %t133, i64 %t134, i8 %t135)
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb27
bb27:
  %t136 = load i64, ptr %l4, !tbaa !24
  store i64 %t136, ptr %l75, !tbaa !24
  %t137 = load i64, ptr %l75, !tbaa !24
  %t138 = add i64 %t137, 2
  store i64 %t138, ptr %l76, !tbaa !24
  %t139 = load i64, ptr %l76, !tbaa !24
  store i64 %t139, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  %t140 = load i64, ptr %l4, !tbaa !24
  store i64 %t140, ptr %l79, !tbaa !24
  %t141 = load i64, ptr %l3, !tbaa !24
  store i64 %t141, ptr %l80, !tbaa !24
  %t142 = load i64, ptr %l79, !tbaa !24
  %t143 = load i64, ptr %l80, !tbaa !24
  %t144 = icmp sge i64 %t142, %t143
  store i1 %t144, ptr %l81, !tbaa !21
  %t145 = load i1, ptr %l81, !tbaa !21
  br i1 %t145, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s9
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l82, !tbaa !29
  store i32 9, ptr %l83
  %t147 = load i64, ptr %l1, !tbaa !24
  store i64 %t147, ptr %l84, !tbaa !24
  %t148 = load i64, ptr %l3, !tbaa !24
  store i64 %t148, ptr %l85, !tbaa !24
  %t149 = load ptr, ptr %l82, !tbaa !29
  %t150 = load i32, ptr %l83
  %t151 = load i64, ptr %l84, !tbaa !24
  %t152 = load i64, ptr %l85, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t149, i32 %t150, i64 %t151, i64 %t152, i8 0)
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t153 = load i64, ptr %l3, !tbaa !24
  store i64 %t153, ptr %l86, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t154 = load i64, ptr %l86, !tbaa !24
  store i64 %t154, ptr %rv
  br label %ret
bb32:
  %t155 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t155, ptr %l87, !tbaa !27
  %t156 = load i64, ptr %l4, !tbaa !24
  store i64 %t156, ptr %l88, !tbaa !24
  %t157 = load i64, ptr %l88, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr i8, ptr %t159, i64 %t157
  %t161 = load i8, ptr %t160, !tbaa !32
  store i8 %t161, ptr %l89, !tbaa !22
  %t162 = load i8, ptr %l89, !tbaa !22
  %t163 = icmp eq i8 %t162, 39
  store i1 %t163, ptr %l90, !tbaa !21
  %t164 = load i1, ptr %l90, !tbaa !21
  br i1 %t164, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s10
  %t165 = load i64, ptr %l4, !tbaa !24
  store i64 %t165, ptr %l91, !tbaa !24
  %t166 = load i64, ptr %l91, !tbaa !24
  %t167 = add i64 %t166, 1
  store i64 %t167, ptr %l92, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t168 = load i64, ptr %l92, !tbaa !24
  store i64 %t168, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t169 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t169, ptr %l93, !tbaa !27
  %t170 = load i64, ptr %l4, !tbaa !24
  store i64 %t170, ptr %l94, !tbaa !24
  %t171 = load i64, ptr %l94, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i8, ptr %t173, i64 %t171
  %t175 = load i8, ptr %t174, !tbaa !32
  store i8 %t175, ptr %l95, !tbaa !22
  %t176 = load i8, ptr %l95, !tbaa !22
  %t177 = icmp eq i8 %t176, 10
  store i1 %t177, ptr %l96, !tbaa !21
  %t178 = load i1, ptr %l96, !tbaa !21
  br i1 %t178, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s11
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l97, !tbaa !29
  store i32 10, ptr %l98
  %t180 = load i64, ptr %l1, !tbaa !24
  store i64 %t180, ptr %l99, !tbaa !24
  %t181 = load i64, ptr %l4, !tbaa !24
  store i64 %t181, ptr %l100, !tbaa !24
  %t182 = load ptr, ptr %l97, !tbaa !29
  %t183 = load i32, ptr %l98
  %t184 = load i64, ptr %l99, !tbaa !24
  %t185 = load i64, ptr %l100, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t182, i32 %t183, i64 %t184, i64 %t185, i8 0)
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t186 = load i64, ptr %l4, !tbaa !24
  store i64 %t186, ptr %l101, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t187 = load i64, ptr %l101, !tbaa !24
  store i64 %t187, ptr %rv
  br label %ret
bb39:
  %t188 = load i64, ptr %l4, !tbaa !24
  store i64 %t188, ptr %l102, !tbaa !24
  %t189 = load i64, ptr %l102, !tbaa !24
  store i64 %t189, ptr %l7, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s12
  %t190 = load i64, ptr %l7, !tbaa !24
  store i64 %t190, ptr %l103, !tbaa !24
  %t191 = load i64, ptr %l3, !tbaa !24
  store i64 %t191, ptr %l104, !tbaa !24
  %t192 = load i64, ptr %l103, !tbaa !24
  %t193 = load i64, ptr %l104, !tbaa !24
  %t194 = icmp slt i64 %t192, %t193
  store i1 %t194, ptr %l105, !tbaa !21
  %t195 = load i1, ptr %l105, !tbaa !21
  br i1 %t195, label %bb41, label %bb42
bb41:
  %t196 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t196, ptr %l107, !tbaa !27
  %t197 = load i64, ptr %l7, !tbaa !24
  store i64 %t197, ptr %l108, !tbaa !24
  %t198 = load i64, ptr %l108, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i8, ptr %t200, i64 %t198
  %t202 = load i8, ptr %t201, !tbaa !32
  store i8 %t202, ptr %l109, !tbaa !22
  %t203 = load i8, ptr %l109, !tbaa !22
  %t204 = icmp ne i8 %t203, 39
  store i1 %t204, ptr %l110, !tbaa !21
  %t205 = load i1, ptr %l110, !tbaa !21
  store i1 %t205, ptr %l106, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb43
bb43:
  %t206 = load i1, ptr %l106, !tbaa !21
  br i1 %t206, label %bb44, label %bb45
bb44:
  %t207 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t207, ptr %l112, !tbaa !27
  %t208 = load i64, ptr %l7, !tbaa !24
  store i64 %t208, ptr %l113, !tbaa !24
  %t209 = load i64, ptr %l113, !tbaa !24
  %t210 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr i8, ptr %t211, i64 %t209
  %t213 = load i8, ptr %t212, !tbaa !32
  store i8 %t213, ptr %l114, !tbaa !22
  %t214 = load i8, ptr %l114, !tbaa !22
  %t215 = icmp ne i8 %t214, 10
  store i1 %t215, ptr %l115, !tbaa !21
  %t216 = load i1, ptr %l115, !tbaa !21
  store i1 %t216, ptr %l111, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb46
bb46:
  %t217 = load i1, ptr %l111, !tbaa !21
  %t218 = xor i1 %t217, true
  store i1 %t218, ptr %l116, !tbaa !21
  %t219 = load i1, ptr %l116, !tbaa !21
  br i1 %t219, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s12)
  br label %bb51
bb48:
  br label %bb49
bb49:
  %t220 = load i64, ptr %l7, !tbaa !24
  store i64 %t220, ptr %l117, !tbaa !24
  %t221 = load i64, ptr %l117, !tbaa !24
  %t222 = add i64 %t221, 1
  store i64 %t222, ptr %l118, !tbaa !24
  %t223 = load i64, ptr %l118, !tbaa !24
  store i64 %t223, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb50
bb50:
  br label %bb40
bb51:
  %t224 = load i64, ptr %l7, !tbaa !24
  store i64 %t224, ptr %l119, !tbaa !24
  %t225 = load i64, ptr %l3, !tbaa !24
  store i64 %t225, ptr %l120, !tbaa !24
  %t226 = load i64, ptr %l119, !tbaa !24
  %t227 = load i64, ptr %l120, !tbaa !24
  %t228 = icmp slt i64 %t226, %t227
  store i1 %t228, ptr %l121, !tbaa !21
  %t229 = load i1, ptr %l121, !tbaa !21
  br i1 %t229, label %bb52, label %bb53
bb52:
  %t230 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t230, ptr %l123, !tbaa !27
  %t231 = load i64, ptr %l7, !tbaa !24
  store i64 %t231, ptr %l124, !tbaa !24
  %t232 = load i64, ptr %l124, !tbaa !24
  %t233 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i8, ptr %t234, i64 %t232
  %t236 = load i8, ptr %t235, !tbaa !32
  store i8 %t236, ptr %l125, !tbaa !22
  %t237 = load i8, ptr %l125, !tbaa !22
  %t238 = icmp eq i8 %t237, 39
  store i1 %t238, ptr %l126, !tbaa !21
  %t239 = load i1, ptr %l126, !tbaa !21
  store i1 %t239, ptr %l122, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb54
bb54:
  %t240 = load i1, ptr %l122, !tbaa !21
  br i1 %t240, label %bb55, label %bb56
bb55:
  %t241 = load i64, ptr %l7, !tbaa !24
  store i64 %t241, ptr %l128, !tbaa !24
  %t242 = load i64, ptr %l128, !tbaa !24
  %t243 = add i64 %t242, 1
  store i64 %t243, ptr %l129, !tbaa !24
  %t244 = load i64, ptr %l129, !tbaa !24
  store i64 %t244, ptr %l127, !tbaa !24
  br label %bb57
bb56:
  %t245 = load i64, ptr %l7, !tbaa !24
  store i64 %t245, ptr %l130, !tbaa !24
  %t246 = load i64, ptr %l130, !tbaa !24
  store i64 %t246, ptr %l127, !tbaa !24
  br label %bb57
bb57:
  %t247 = load i64, ptr %l127, !tbaa !24
  store i64 %t247, ptr %l8, !tbaa !24
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l131, !tbaa !29
  store i32 12, ptr %l132
  %t249 = load i64, ptr %l1, !tbaa !24
  store i64 %t249, ptr %l133, !tbaa !24
  %t250 = load i64, ptr %l8, !tbaa !24
  store i64 %t250, ptr %l134, !tbaa !24
  %t251 = load ptr, ptr %l131, !tbaa !29
  %t252 = load i32, ptr %l132
  %t253 = load i64, ptr %l133, !tbaa !24
  %t254 = load i64, ptr %l134, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t251, i32 %t252, i64 %t253, i64 %t254, i8 0)
  br label %bb58
bb58:
  %t255 = load i64, ptr %l8, !tbaa !24
  store i64 %t255, ptr %l135, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t256 = load i64, ptr %l135, !tbaa !24
  store i64 %t256, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ecloseBeforeDecl(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i8
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i8
  %l58 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i8
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i8
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t2, i32 0, i32 3
  store ptr %t3, ptr %l7, !tbaa !29
  %t4 = load ptr, ptr %l7, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eLe_H123f33f8ddaac384b8a67c2466e49838(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  store i1 %t7, ptr %l9, !tbaa !21
  %t8 = load i1, ptr %l9, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l11, !tbaa !29
  %t10 = load ptr, ptr %l11, !tbaa !29
  %t11 = getelementptr %"compiler/scan:scanner", ptr %t10, i32 0, i32 4
  %t12 = load i64, ptr %t11, !tbaa !24
  store i64 %t12, ptr %l12, !tbaa !24
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = icmp sgt i64 %t13, 0
  store i1 %t14, ptr %l13, !tbaa !21
  %t15 = load i1, ptr %l13, !tbaa !21
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load i32, ptr %l1
  store i32 %t17, ptr %l14
  store ptr %l14, ptr %l15, !tbaa !29
  store i32 33, ptr %l16
  store ptr %l16, ptr %l17, !tbaa !29
  %t18 = load ptr, ptr %l15, !tbaa !29
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t20 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t18, ptr %t19)
  store i1 %t20, ptr %l18
  br label %bb8
bb8:
  %t21 = load i1, ptr %l18, !tbaa !21
  br i1 %t21, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb12
bb10:
  %t22 = load i32, ptr %l1
  store i32 %t22, ptr %l20
  store ptr %l20, ptr %l21, !tbaa !29
  store i32 43, ptr %l22
  store ptr %l22, ptr %l23, !tbaa !29
  %t23 = load ptr, ptr %l21, !tbaa !29
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t23, ptr %t24)
  store i1 %t25, ptr %l24
  br label %bb11
bb11:
  %t26 = load i1, ptr %l24, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb16
bb14:
  %t28 = load i32, ptr %l1
  store i32 %t28, ptr %l26
  store ptr %l26, ptr %l27, !tbaa !29
  store i32 42, ptr %l28
  store ptr %l28, ptr %l29, !tbaa !29
  %t29 = load ptr, ptr %l27, !tbaa !29
  %t30 = load ptr, ptr %l29, !tbaa !29
  %t31 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t29, ptr %t30)
  store i1 %t31, ptr %l30
  br label %bb15
bb15:
  %t32 = load i1, ptr %l30, !tbaa !21
  store i1 %t32, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb20
bb18:
  %t34 = load i32, ptr %l1
  store i32 %t34, ptr %l32
  store ptr %l32, ptr %l33, !tbaa !29
  store i32 45, ptr %l34
  store ptr %l34, ptr %l35, !tbaa !29
  %t35 = load ptr, ptr %l33, !tbaa !29
  %t36 = load ptr, ptr %l35, !tbaa !29
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t35, ptr %t36)
  store i1 %t37, ptr %l36
  br label %bb19
bb19:
  %t38 = load i1, ptr %l36, !tbaa !21
  store i1 %t38, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t39 = load i1, ptr %l31, !tbaa !21
  store i1 %t39, ptr %l3, !tbaa !21
  %t40 = load i32, ptr %l1
  store i32 %t40, ptr %l37
  store ptr %l37, ptr %l38, !tbaa !29
  store i32 37, ptr %l39
  store ptr %l39, ptr %l40, !tbaa !29
  %t41 = load ptr, ptr %l38, !tbaa !29
  %t42 = load ptr, ptr %l40, !tbaa !29
  %t43 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t41, ptr %t42)
  store i1 %t43, ptr %l41
  br label %bb21
bb21:
  %t44 = load i1, ptr %l41, !tbaa !21
  br i1 %t44, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l42, !tbaa !29
  %t46 = load ptr, ptr %l42, !tbaa !29
  %t47 = getelementptr %"compiler/scan:scanner", ptr %t46, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l43, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t49, ptr %l4, !tbaa !27
  %t50 = load i64, ptr %l2, !tbaa !24
  store i64 %t50, ptr %l44, !tbaa !24
  %t51 = load i64, ptr %l44, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  br label %bb24
bb23:
  br label %bb43
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load i64, ptr %l5, !tbaa !24
  store i64 %t52, ptr %l45, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t53, ptr %l46, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l47, !tbaa !24
  %t56 = load i64, ptr %l45, !tbaa !24
  %t57 = load i64, ptr %l47, !tbaa !24
  %t58 = icmp slt i64 %t56, %t57
  store i1 %t58, ptr %l48, !tbaa !21
  %t59 = load i1, ptr %l48, !tbaa !21
  br i1 %t59, label %bb25, label %bb26
bb25:
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t60, ptr %l50, !tbaa !27
  %t61 = load i64, ptr %l5, !tbaa !24
  store i64 %t61, ptr %l51, !tbaa !24
  %t62 = load i64, ptr %l51, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 %t62
  %t66 = load i8, ptr %t65, !tbaa !32
  store i8 %t66, ptr %l52, !tbaa !22
  %t67 = load i8, ptr %l52, !tbaa !22
  %t68 = icmp eq i8 %t67, 32
  store i1 %t68, ptr %l53, !tbaa !21
  %t69 = load i1, ptr %l53, !tbaa !21
  br i1 %t69, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb30
bb27:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb29
bb28:
  %t70 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t70, ptr %l55, !tbaa !27
  %t71 = load i64, ptr %l5, !tbaa !24
  store i64 %t71, ptr %l56, !tbaa !24
  %t72 = load i64, ptr %l56, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i8, ptr %t74, i64 %t72
  %t76 = load i8, ptr %t75, !tbaa !32
  store i8 %t76, ptr %l57, !tbaa !22
  %t77 = load i8, ptr %l57, !tbaa !22
  %t78 = icmp eq i8 %t77, 9
  store i1 %t78, ptr %l58, !tbaa !21
  %t79 = load i1, ptr %l58, !tbaa !21
  store i1 %t79, ptr %l54, !tbaa !21
  br label %bb29
bb29:
  %t80 = load i1, ptr %l54, !tbaa !21
  store i1 %t80, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t81 = load i1, ptr %l49, !tbaa !21
  %t82 = xor i1 %t81, true
  store i1 %t82, ptr %l59, !tbaa !21
  %t83 = load i1, ptr %l59, !tbaa !21
  br i1 %t83, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t84 = load i64, ptr %l5, !tbaa !24
  store i64 %t84, ptr %l60, !tbaa !24
  %t85 = load i64, ptr %l60, !tbaa !24
  %t86 = add i64 %t85, 1
  store i64 %t86, ptr %l61, !tbaa !24
  %t87 = load i64, ptr %l61, !tbaa !24
  store i64 %t87, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  br label %bb24
bb35:
  %t88 = load i64, ptr %l5, !tbaa !24
  store i64 %t88, ptr %l62, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t89, ptr %l63, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l64, !tbaa !24
  %t92 = load i64, ptr %l62, !tbaa !24
  %t93 = load i64, ptr %l64, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  store i1 %t94, ptr %l65, !tbaa !21
  %t95 = load i1, ptr %l65, !tbaa !21
  br i1 %t95, label %bb36, label %bb37
bb36:
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t96, ptr %l67, !tbaa !27
  %t97 = load i64, ptr %l5, !tbaa !24
  store i64 %t97, ptr %l68, !tbaa !24
  %t98 = load i64, ptr %l68, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i8, ptr %t100, i64 %t98
  %t102 = load i8, ptr %t101, !tbaa !32
  store i8 %t102, ptr %l69, !tbaa !22
  %t103 = load i8, ptr %l69, !tbaa !22
  %t104 = call i1 @compiler_2fscan_2eisLetter(i8 %t103)
  store i1 %t104, ptr %l70
  br label %bb38
bb37:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb42
bb38:
  %t105 = load i1, ptr %l70, !tbaa !21
  br i1 %t105, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb41
bb40:
  %t106 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t106, ptr %l72, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  store i64 %t107, ptr %l73, !tbaa !24
  %t108 = load i64, ptr %l73, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i8, ptr %t110, i64 %t108
  %t112 = load i8, ptr %t111, !tbaa !32
  store i8 %t112, ptr %l74, !tbaa !22
  %t113 = load i8, ptr %l74, !tbaa !22
  %t114 = icmp eq i8 %t113, 95
  store i1 %t114, ptr %l75, !tbaa !21
  %t115 = load i1, ptr %l75, !tbaa !21
  store i1 %t115, ptr %l71, !tbaa !21
  br label %bb41
bb41:
  %t116 = load i1, ptr %l71, !tbaa !21
  store i1 %t116, ptr %l66, !tbaa !21
  br label %bb42
bb42:
  %t117 = load i1, ptr %l66, !tbaa !21
  store i1 %t117, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  %t118 = load i1, ptr %l3, !tbaa !21
  store i1 %t118, ptr %l76, !tbaa !21
  %t119 = load i1, ptr %l76, !tbaa !21
  br i1 %t119, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s4
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l77, !tbaa !29
  %t121 = load ptr, ptr %l77, !tbaa !29
  %t122 = getelementptr %"compiler/scan:scanner", ptr %t121, i32 0, i32 3
  store ptr %t122, ptr %l78, !tbaa !29
  %t123 = load ptr, ptr %l78, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eCl_He62a1125a32dfc5a59291318c690abf4(ptr %v0, ptr %t123)
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i8 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i8
  %l13 = alloca %"compiler/scan:Diag"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i8 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t2, i32 0, i32 2
  store ptr %t3, ptr %l6, !tbaa !29
  %t4 = load i32, ptr %l1
  store i32 %t4, ptr %l7
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l9, !tbaa !23
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l10, !tbaa !24
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = trunc i64 %t9 to i32
  store i32 %t10, ptr %l11, !tbaa !23
  %t11 = load i8, ptr %l4, !tbaa !22
  store i8 %t11, ptr %l12, !tbaa !22
  %t12 = load i32, ptr %l7
  %t13 = load i32, ptr %l9, !tbaa !23
  %t14 = load i32, ptr %l11, !tbaa !23
  %t15 = load i8, ptr %l12, !tbaa !22
  %t16 = call %"compiler/scan:Diag" @compiler_2fscan_3aDiag_2ector(ptr %s0, i32 %t12, i32 %t13, i32 %t14, i8 %t15)
  store %"compiler/scan:Diag" %t16, ptr %l13
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = load %"compiler/scan:Diag", ptr %l13
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2ePush_3ccompiler_2fscan_3aDiag_3e(ptr %v0, ptr %t17, %"compiler/scan:Diag" %t18)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i8
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i8
  %l22 = alloca i8
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i8
  %l28 = alloca i1
  %l29 = alloca i8
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i8
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i8
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i8
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca { i64, i64 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l11, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t5, ptr %l3, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l12, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l13, !tbaa !24
  %t9 = load i64, ptr %l13, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l14, !tbaa !24
  %t11 = load i64, ptr %l14, !tbaa !24
  store i64 %t11, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i8 0, ptr %l7, !tbaa !22
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load i64, ptr %l5, !tbaa !24
  store i64 %t12, ptr %l15, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l16, !tbaa !24
  %t14 = load i64, ptr %l15, !tbaa !24
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp slt i64 %t14, %t15
  store i1 %t16, ptr %l17, !tbaa !21
  %t17 = load i1, ptr %l17, !tbaa !21
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l18, !tbaa !21
  %t19 = load i1, ptr %l18, !tbaa !21
  br i1 %t19, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb28
bb3:
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t20, ptr %l19, !tbaa !27
  %t21 = load i64, ptr %l5, !tbaa !24
  store i64 %t21, ptr %l20, !tbaa !24
  %t22 = load i64, ptr %l20, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i8, ptr %t24, i64 %t22
  %t26 = load i8, ptr %t25, !tbaa !32
  store i8 %t26, ptr %l21, !tbaa !22
  %t27 = load i8, ptr %l21, !tbaa !22
  store i8 %t27, ptr %l8, !tbaa !22
  %t28 = load i8, ptr %l8, !tbaa !22
  store i8 %t28, ptr %l22, !tbaa !22
  %t29 = load i64, ptr %l2, !tbaa !24
  store i64 %t29, ptr %l23, !tbaa !24
  %t30 = load i8, ptr %l22, !tbaa !22
  %t31 = load i64, ptr %l23, !tbaa !24
  %t32 = call i1 @compiler_2fscan_2edigitOf(i8 %t30, i64 %t31)
  store i1 %t32, ptr %l24
  br label %bb5
bb5:
  %t33 = load i1, ptr %l24, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i64, ptr %l6, !tbaa !24
  store i64 %t34, ptr %l25, !tbaa !24
  %t35 = load i64, ptr %l25, !tbaa !24
  %t36 = add i64 %t35, 1
  store i64 %t36, ptr %l26, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i8, ptr %l8, !tbaa !22
  store i8 %t38, ptr %l27, !tbaa !22
  %t39 = load i8, ptr %l27, !tbaa !22
  %t40 = icmp eq i8 %t39, 95
  store i1 %t40, ptr %l28, !tbaa !21
  %t41 = load i1, ptr %l28, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t42 = load i8, ptr %l7, !tbaa !22
  store i8 %t42, ptr %l29, !tbaa !22
  %t43 = load i64, ptr %l2, !tbaa !24
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load i8, ptr %l29, !tbaa !22
  %t45 = load i64, ptr %l30, !tbaa !24
  %t46 = call i1 @compiler_2fscan_2edigitOf(i8 %t44, i64 %t45)
  store i1 %t46, ptr %l31
  br label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s6
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  br label %bb28
bb10:
  %t47 = load i1, ptr %l31, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t48 = load i64, ptr %l5, !tbaa !24
  store i64 %t48, ptr %l33, !tbaa !24
  %t49 = load i64, ptr %l33, !tbaa !24
  %t50 = add i64 %t49, 1
  store i64 %t50, ptr %l34, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l35, !tbaa !24
  %t52 = load i64, ptr %l34, !tbaa !24
  %t53 = load i64, ptr %l35, !tbaa !24
  %t54 = icmp slt i64 %t52, %t53
  store i1 %t54, ptr %l36, !tbaa !21
  %t55 = load i1, ptr %l36, !tbaa !21
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb13
bb13:
  %t56 = load i1, ptr %l32, !tbaa !21
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t57 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t57, ptr %l38, !tbaa !27
  %t58 = load i64, ptr %l5, !tbaa !24
  store i64 %t58, ptr %l39, !tbaa !24
  %t59 = load i64, ptr %l39, !tbaa !24
  %t60 = add i64 %t59, 1
  store i64 %t60, ptr %l40, !tbaa !24
  %t61 = load i64, ptr %l40, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i8, ptr %t63, i64 %t61
  %t65 = load i8, ptr %t64, !tbaa !32
  store i8 %t65, ptr %l41, !tbaa !22
  %t66 = load i64, ptr %l2, !tbaa !24
  store i64 %t66, ptr %l42, !tbaa !24
  %t67 = load i8, ptr %l41, !tbaa !22
  %t68 = load i64, ptr %l42, !tbaa !24
  %t69 = call i1 @compiler_2fscan_2edigitOf(i8 %t67, i64 %t68)
  store i1 %t69, ptr %l43
  br label %bb16
bb15:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb16:
  %t70 = load i1, ptr %l43, !tbaa !21
  store i1 %t70, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t71 = load i1, ptr %l37, !tbaa !21
  store i1 %t71, ptr %l9, !tbaa !21
  %t72 = load i1, ptr %l9, !tbaa !21
  store i1 %t72, ptr %l44, !tbaa !21
  %t73 = load i1, ptr %l44, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l45, !tbaa !21
  %t75 = load i1, ptr %l45, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t76 = load i8, ptr %l7, !tbaa !22
  store i8 %t76, ptr %l47, !tbaa !22
  %t77 = load i8, ptr %l47, !tbaa !22
  %t78 = icmp ne i8 %t77, 95
  store i1 %t78, ptr %l48, !tbaa !21
  %t79 = load i1, ptr %l48, !tbaa !21
  store i1 %t79, ptr %l46, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t80 = load i1, ptr %l46, !tbaa !21
  br i1 %t80, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l49, !tbaa !29
  store i32 18, ptr %l50
  %t82 = load i64, ptr %l5, !tbaa !24
  store i64 %t82, ptr %l51, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  store i64 %t83, ptr %l52, !tbaa !24
  %t84 = load i64, ptr %l52, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l53, !tbaa !24
  %t86 = load ptr, ptr %l49, !tbaa !29
  %t87 = load i32, ptr %l50
  %t88 = load i64, ptr %l51, !tbaa !24
  %t89 = load i64, ptr %l53, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t86, i32 %t87, i64 %t88, i64 %t89, i8 0)
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t90 = load i8, ptr %l8, !tbaa !22
  store i8 %t90, ptr %l54, !tbaa !22
  %t91 = load i8, ptr %l54, !tbaa !22
  store i8 %t91, ptr %l7, !tbaa !22
  %t92 = load i64, ptr %l5, !tbaa !24
  store i64 %t92, ptr %l55, !tbaa !24
  %t93 = load i64, ptr %l55, !tbaa !24
  %t94 = add i64 %t93, 1
  store i64 %t94, ptr %l56, !tbaa !24
  %t95 = load i64, ptr %l56, !tbaa !24
  store i64 %t95, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb27:
  br label %bb1
bb28:
  %t96 = load i64, ptr %l5, !tbaa !24
  store i64 %t96, ptr %l57, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  store i64 %t97, ptr %l58, !tbaa !24
  %t98 = load i64, ptr %l57, !tbaa !24
  %t99 = insertvalue { i64, i64 } undef, i64 %t98, 0
  %t100 = load i64, ptr %l58, !tbaa !24
  %t101 = insertvalue { i64, i64 } %t99, i64 %t100, 1
  store { i64, i64 } %t101, ptr %l59
  call void @__olang_scope_close(ptr %s0)
  %t102 = load { i64, i64 }, ptr %l59
  store { i64, i64 } %t102, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i32, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2enumber(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca i1
  %l6 = alloca { i64, i64 }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, i64 }
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, i64 }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, i64 }
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i8
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i8
  %l35 = alloca i8
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i8
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i8
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i8
  %l45 = alloca i1
  %l46 = alloca i8
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i8
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i64
  %l56 = alloca { i64, i64 }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca i32
  %l64 = alloca i32
  %l65 = alloca i32
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i8
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca i8
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca i32
  %l84 = alloca i32
  %l85 = alloca i32
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i8
  %l92 = alloca i32
  %l93 = alloca i64
  %l94 = alloca { i32, i64 }
  %l95 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca { i64, i64 }
  %l98 = alloca i64
  %l99 = alloca i32
  %l100 = alloca { i64, ptr }
  %l101 = alloca i64
  %l102 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca { i64, i64 }
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i32
  %l118 = alloca { i64, ptr }
  %l119 = alloca i64
  %l120 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i1
  %l129 = alloca i1
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca i8
  %l133 = alloca i1
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca i8
  %l138 = alloca i1
  %l139 = alloca i64
  %l140 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i1
  %l144 = alloca i1
  %l145 = alloca { i64, ptr }
  %l146 = alloca i64
  %l147 = alloca i8
  %l148 = alloca i1
  %l149 = alloca i1
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca i8
  %l153 = alloca i1
  %l154 = alloca i64
  %l155 = alloca i64
  %l156 = alloca { i64, ptr }
  %l157 = alloca i64
  %l158 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca i64
  %l161 = alloca { i64, i64 }
  %l162 = alloca i64
  %l163 = alloca i32
  %l164 = alloca i64
  %l165 = alloca { i32, i64 }
  %l166 = alloca i32
  %l167 = alloca i64
  %l168 = alloca { i32, i64 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  %t2 = load ptr, ptr %l18, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l19, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t5, ptr %l2, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l20, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l21, !tbaa !24
  %t9 = load i64, ptr %l21, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t10, ptr %l22, !tbaa !27
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l23, !tbaa !24
  %t12 = load i64, ptr %l23, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr i8, ptr %t14, i64 %t12
  %t16 = load i8, ptr %t15, !tbaa !32
  store i8 %t16, ptr %l24, !tbaa !22
  %t17 = load i8, ptr %l24, !tbaa !22
  %t18 = icmp eq i8 %t17, 48
  store i1 %t18, ptr %l25, !tbaa !21
  %t19 = load i1, ptr %l25, !tbaa !21
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t20 = load i64, ptr %l1, !tbaa !24
  store i64 %t20, ptr %l27, !tbaa !24
  %t21 = load i64, ptr %l27, !tbaa !24
  %t22 = add i64 %t21, 1
  store i64 %t22, ptr %l28, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  store i64 %t23, ptr %l29, !tbaa !24
  %t24 = load i64, ptr %l28, !tbaa !24
  %t25 = load i64, ptr %l29, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  store i1 %t26, ptr %l30, !tbaa !21
  %t27 = load i1, ptr %l30, !tbaa !21
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb3
bb3:
  %t28 = load i1, ptr %l26, !tbaa !21
  br i1 %t28, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l31, !tbaa !27
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l32, !tbaa !24
  %t31 = load i64, ptr %l32, !tbaa !24
  %t32 = add i64 %t31, 1
  store i64 %t32, ptr %l33, !tbaa !24
  %t33 = load i64, ptr %l33, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t33
  %t37 = load i8, ptr %t36, !tbaa !32
  store i8 %t37, ptr %l34, !tbaa !22
  %t38 = load i8, ptr %l34, !tbaa !22
  store i8 %t38, ptr %l4, !tbaa !22
  %t39 = load i8, ptr %l4, !tbaa !22
  store i8 %t39, ptr %l35, !tbaa !22
  %t40 = load i8, ptr %l35, !tbaa !22
  %t41 = icmp eq i8 %t40, 120
  store i1 %t41, ptr %l36, !tbaa !21
  %t42 = load i1, ptr %l36, !tbaa !21
  br i1 %t42, label %bb6, label %bb7
bb5:
  br label %bb47
bb6:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb8
bb7:
  %t43 = load i8, ptr %l4, !tbaa !22
  store i8 %t43, ptr %l38, !tbaa !22
  %t44 = load i8, ptr %l38, !tbaa !22
  %t45 = icmp eq i8 %t44, 88
  store i1 %t45, ptr %l39, !tbaa !21
  %t46 = load i1, ptr %l39, !tbaa !21
  store i1 %t46, ptr %l37, !tbaa !21
  br label %bb8
bb8:
  %t47 = load i1, ptr %l37, !tbaa !21
  br i1 %t47, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb11
bb10:
  %t48 = load i8, ptr %l4, !tbaa !22
  store i8 %t48, ptr %l41, !tbaa !22
  %t49 = load i8, ptr %l41, !tbaa !22
  %t50 = icmp eq i8 %t49, 98
  store i1 %t50, ptr %l42, !tbaa !21
  %t51 = load i1, ptr %l42, !tbaa !21
  store i1 %t51, ptr %l40, !tbaa !21
  br label %bb11
bb11:
  %t52 = load i1, ptr %l40, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb14
bb13:
  %t53 = load i8, ptr %l4, !tbaa !22
  store i8 %t53, ptr %l44, !tbaa !22
  %t54 = load i8, ptr %l44, !tbaa !22
  %t55 = icmp eq i8 %t54, 66
  store i1 %t55, ptr %l45, !tbaa !21
  %t56 = load i1, ptr %l45, !tbaa !21
  store i1 %t56, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l43, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i8, ptr %l4, !tbaa !22
  store i8 %t58, ptr %l46, !tbaa !22
  %t59 = load i8, ptr %l46, !tbaa !22
  %t60 = icmp eq i8 %t59, 120
  store i1 %t60, ptr %l47, !tbaa !21
  %t61 = load i1, ptr %l47, !tbaa !21
  br i1 %t61, label %bb17, label %bb18
bb16:
  br label %bb46
bb17:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb19
bb18:
  %t62 = load i8, ptr %l4, !tbaa !22
  store i8 %t62, ptr %l49, !tbaa !22
  %t63 = load i8, ptr %l49, !tbaa !22
  %t64 = icmp eq i8 %t63, 88
  store i1 %t64, ptr %l50, !tbaa !21
  %t65 = load i1, ptr %l50, !tbaa !21
  store i1 %t65, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t66 = load i1, ptr %l48, !tbaa !21
  store i1 %t66, ptr %l5, !tbaa !21
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l51, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  store i64 %t68, ptr %l52, !tbaa !24
  %t69 = load i64, ptr %l52, !tbaa !24
  %t70 = add i64 %t69, 2
  store i64 %t70, ptr %l53, !tbaa !24
  %t71 = load i1, ptr %l5, !tbaa !21
  store i1 %t71, ptr %l54, !tbaa !21
  %t72 = load i1, ptr %l54, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  store i64 16, ptr %l55, !tbaa !24
  br label %bb22
bb21:
  store i64 2, ptr %l55, !tbaa !24
  br label %bb22
bb22:
  %t73 = load ptr, ptr %l51, !tbaa !29
  %t74 = load i64, ptr %l53, !tbaa !24
  %t75 = load i64, ptr %l55, !tbaa !24
  %t76 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t73, i64 %t74, i64 %t75)
  store { i64, i64 } %t76, ptr %l56
  br label %bb23
bb23:
  %t77 = load { i64, i64 }, ptr %l56
  store { i64, i64 } %t77, ptr %l6
  %t78 = getelementptr { i64, i64 }, ptr %l6, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  store i64 %t79, ptr %l57, !tbaa !24
  %t80 = load i64, ptr %l57, !tbaa !24
  store i64 %t80, ptr %l7, !tbaa !24
  %t81 = getelementptr { i64, i64 }, ptr %l6, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  store i64 %t82, ptr %l58, !tbaa !24
  %t83 = load i64, ptr %l58, !tbaa !24
  store i64 %t83, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l8, !tbaa !24
  store i64 %t84, ptr %l59, !tbaa !24
  %t85 = load i64, ptr %l59, !tbaa !24
  %t86 = icmp eq i64 %t85, 0
  store i1 %t86, ptr %l60, !tbaa !21
  %t87 = load i1, ptr %l60, !tbaa !21
  br i1 %t87, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l61, !tbaa !29
  %t89 = load i1, ptr %l5, !tbaa !21
  store i1 %t89, ptr %l62, !tbaa !21
  %t90 = load i1, ptr %l62, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  store i32 14, ptr %l64
  %t91 = load i32, ptr %l64
  store i32 %t91, ptr %l63
  br label %bb28
bb27:
  store i32 15, ptr %l65
  %t92 = load i32, ptr %l65
  store i32 %t92, ptr %l63
  br label %bb28
bb28:
  %t93 = load i64, ptr %l1, !tbaa !24
  store i64 %t93, ptr %l66, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  store i64 %t94, ptr %l67, !tbaa !24
  %t95 = load ptr, ptr %l61, !tbaa !29
  %t96 = load i32, ptr %l63
  %t97 = load i64, ptr %l66, !tbaa !24
  %t98 = load i64, ptr %l67, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t95, i32 %t96, i64 %t97, i64 %t98, i8 0)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t99 = load i64, ptr %l7, !tbaa !24
  store i64 %t99, ptr %l68, !tbaa !24
  %t100 = load i64, ptr %l3, !tbaa !24
  store i64 %t100, ptr %l69, !tbaa !24
  %t101 = load i64, ptr %l68, !tbaa !24
  %t102 = load i64, ptr %l69, !tbaa !24
  %t103 = icmp slt i64 %t101, %t102
  store i1 %t103, ptr %l70, !tbaa !21
  %t104 = load i1, ptr %l70, !tbaa !21
  br i1 %t104, label %bb31, label %bb32
bb31:
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l72, !tbaa !27
  %t106 = load i64, ptr %l7, !tbaa !24
  store i64 %t106, ptr %l73, !tbaa !24
  %t107 = load i64, ptr %l73, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i8, ptr %t109, i64 %t107
  %t111 = load i8, ptr %t110, !tbaa !32
  store i8 %t111, ptr %l74, !tbaa !22
  %t112 = load i8, ptr %l74, !tbaa !22
  %t113 = call i1 @compiler_2fscan_2eisDigit(i8 %t112)
  store i1 %t113, ptr %l75
  br label %bb33
bb32:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb38
bb33:
  %t114 = load i1, ptr %l75, !tbaa !21
  br i1 %t114, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb37
bb35:
  %t115 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t115, ptr %l77, !tbaa !27
  %t116 = load i64, ptr %l7, !tbaa !24
  store i64 %t116, ptr %l78, !tbaa !24
  %t117 = load i64, ptr %l78, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i8, ptr %t119, i64 %t117
  %t121 = load i8, ptr %t120, !tbaa !32
  store i8 %t121, ptr %l79, !tbaa !22
  %t122 = load i8, ptr %l79, !tbaa !22
  %t123 = call i1 @compiler_2fscan_2eisLetter(i8 %t122)
  store i1 %t123, ptr %l80
  br label %bb36
bb36:
  %t124 = load i1, ptr %l80, !tbaa !21
  store i1 %t124, ptr %l76, !tbaa !21
  br label %bb37
bb37:
  %t125 = load i1, ptr %l76, !tbaa !21
  store i1 %t125, ptr %l71, !tbaa !21
  br label %bb38
bb38:
  %t126 = load i1, ptr %l71, !tbaa !21
  br i1 %t126, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s4
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l81, !tbaa !29
  %t128 = load i1, ptr %l5, !tbaa !21
  store i1 %t128, ptr %l82, !tbaa !21
  %t129 = load i1, ptr %l82, !tbaa !21
  br i1 %t129, label %bb41, label %bb42
bb40:
  br label %bb45
bb41:
  store i32 16, ptr %l84
  %t130 = load i32, ptr %l84
  store i32 %t130, ptr %l83
  br label %bb43
bb42:
  store i32 17, ptr %l85
  %t131 = load i32, ptr %l85
  store i32 %t131, ptr %l83
  br label %bb43
bb43:
  %t132 = load i64, ptr %l7, !tbaa !24
  store i64 %t132, ptr %l86, !tbaa !24
  %t133 = load i64, ptr %l7, !tbaa !24
  store i64 %t133, ptr %l87, !tbaa !24
  %t134 = load i64, ptr %l87, !tbaa !24
  %t135 = add i64 %t134, 1
  store i64 %t135, ptr %l88, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t136, ptr %l89, !tbaa !27
  %t137 = load i64, ptr %l7, !tbaa !24
  store i64 %t137, ptr %l90, !tbaa !24
  %t138 = load i64, ptr %l90, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i8, ptr %t140, i64 %t138
  %t142 = load i8, ptr %t141, !tbaa !32
  store i8 %t142, ptr %l91, !tbaa !22
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t144 = load i32, ptr %l83
  %t145 = load i64, ptr %l86, !tbaa !24
  %t146 = load i64, ptr %l88, !tbaa !24
  %t147 = load i8, ptr %l91, !tbaa !22
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t143, i32 %t144, i64 %t145, i64 %t146, i8 %t147)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb45:
  store i32 2, ptr %l92
  %t148 = load i64, ptr %l7, !tbaa !24
  store i64 %t148, ptr %l93, !tbaa !24
  %t149 = load i32, ptr %l92
  %t150 = insertvalue { i32, i64 } undef, i32 %t149, 0
  %t151 = load i64, ptr %l93, !tbaa !24
  %t152 = insertvalue { i32, i64 } %t150, i64 %t151, 1
  store { i32, i64 } %t152, ptr %l94
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t153 = load { i32, i64 }, ptr %l94
  store { i32, i64 } %t153, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s1)
  br label %bb47
bb47:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l95, !tbaa !29
  %t155 = load i64, ptr %l1, !tbaa !24
  store i64 %t155, ptr %l96, !tbaa !24
  %t156 = load ptr, ptr %l95, !tbaa !29
  %t157 = load i64, ptr %l96, !tbaa !24
  %t158 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t156, i64 %t157, i64 10)
  store { i64, i64 } %t158, ptr %l97
  br label %bb48
bb48:
  %t159 = load { i64, i64 }, ptr %l97
  store { i64, i64 } %t159, ptr %l9
  %t160 = getelementptr { i64, i64 }, ptr %l9, i32 0, i32 0
  %t161 = load i64, ptr %t160, !tbaa !24
  store i64 %t161, ptr %l98, !tbaa !24
  %t162 = load i64, ptr %l98, !tbaa !24
  store i64 %t162, ptr %l10, !tbaa !24
  store i32 2, ptr %l99
  %t163 = load i32, ptr %l99
  store i32 %t163, ptr %l11
  %t164 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t164, ptr %l100, !tbaa !27
  %t165 = load i64, ptr %l10, !tbaa !24
  store i64 %t165, ptr %l101, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t167 = load i64, ptr %l101, !tbaa !24
  %t168 = call i1 @compiler_2fscan_2efractionAt(ptr %v0, { i64, ptr } %t166, i64 %t167)
  store i1 %t168, ptr %l102
  br label %bb49
bb49:
  %t169 = load i1, ptr %l102, !tbaa !21
  br i1 %t169, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s5
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l103, !tbaa !29
  %t171 = load i64, ptr %l10, !tbaa !24
  store i64 %t171, ptr %l104, !tbaa !24
  %t172 = load i64, ptr %l104, !tbaa !24
  %t173 = add i64 %t172, 1
  store i64 %t173, ptr %l105, !tbaa !24
  %t174 = load ptr, ptr %l103, !tbaa !29
  %t175 = load i64, ptr %l105, !tbaa !24
  %t176 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t174, i64 %t175, i64 10)
  store { i64, i64 } %t176, ptr %l106
  br label %bb52
bb51:
  br label %bb62
bb52:
  %t177 = load { i64, i64 }, ptr %l106
  store { i64, i64 } %t177, ptr %l12
  %t178 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 0
  %t179 = load i64, ptr %t178, !tbaa !24
  store i64 %t179, ptr %l107, !tbaa !24
  %t180 = load i64, ptr %l107, !tbaa !24
  store i64 %t180, ptr %l13, !tbaa !24
  %t181 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 1
  %t182 = load i64, ptr %t181, !tbaa !24
  store i64 %t182, ptr %l108, !tbaa !24
  %t183 = load i64, ptr %l108, !tbaa !24
  store i64 %t183, ptr %l14, !tbaa !24
  %t184 = load i64, ptr %l14, !tbaa !24
  store i64 %t184, ptr %l109, !tbaa !24
  %t185 = load i64, ptr %l109, !tbaa !24
  %t186 = icmp eq i64 %t185, 0
  store i1 %t186, ptr %l110, !tbaa !21
  %t187 = load i1, ptr %l110, !tbaa !21
  br i1 %t187, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s6
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l111, !tbaa !29
  store i32 19, ptr %l112
  %t189 = load i64, ptr %l10, !tbaa !24
  store i64 %t189, ptr %l113, !tbaa !24
  %t190 = load i64, ptr %l10, !tbaa !24
  store i64 %t190, ptr %l114, !tbaa !24
  %t191 = load i64, ptr %l114, !tbaa !24
  %t192 = add i64 %t191, 1
  store i64 %t192, ptr %l115, !tbaa !24
  %t193 = load ptr, ptr %l111, !tbaa !29
  %t194 = load i32, ptr %l112
  %t195 = load i64, ptr %l113, !tbaa !24
  %t196 = load i64, ptr %l115, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t193, i32 %t194, i64 %t195, i64 %t196, i8 0)
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_scope_close(ptr %s6)
  br label %bb56
bb56:
  %t197 = load i64, ptr %l13, !tbaa !24
  store i64 %t197, ptr %l116, !tbaa !24
  %t198 = load i64, ptr %l116, !tbaa !24
  store i64 %t198, ptr %l10, !tbaa !24
  store i32 3, ptr %l117
  %t199 = load i32, ptr %l117
  store i32 %t199, ptr %l11
  %t200 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t200, ptr %l118, !tbaa !27
  %t201 = load i64, ptr %l10, !tbaa !24
  store i64 %t201, ptr %l119, !tbaa !24
  %t202 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t203 = load i64, ptr %l119, !tbaa !24
  %t204 = call i1 @compiler_2fscan_2efractionAt(ptr %v0, { i64, ptr } %t202, i64 %t203)
  store i1 %t204, ptr %l120
  br label %bb57
bb57:
  %t205 = load i1, ptr %l120, !tbaa !21
  br i1 %t205, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s7
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l121, !tbaa !29
  store i32 20, ptr %l122
  %t207 = load i64, ptr %l10, !tbaa !24
  store i64 %t207, ptr %l123, !tbaa !24
  %t208 = load i64, ptr %l10, !tbaa !24
  store i64 %t208, ptr %l124, !tbaa !24
  %t209 = load i64, ptr %l124, !tbaa !24
  %t210 = add i64 %t209, 1
  store i64 %t210, ptr %l125, !tbaa !24
  %t211 = load ptr, ptr %l121, !tbaa !29
  %t212 = load i32, ptr %l122
  %t213 = load i64, ptr %l123, !tbaa !24
  %t214 = load i64, ptr %l125, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t211, i32 %t212, i64 %t213, i64 %t214, i8 0)
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s7)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb62:
  %t215 = load i64, ptr %l10, !tbaa !24
  store i64 %t215, ptr %l126, !tbaa !24
  %t216 = load i64, ptr %l3, !tbaa !24
  store i64 %t216, ptr %l127, !tbaa !24
  %t217 = load i64, ptr %l126, !tbaa !24
  %t218 = load i64, ptr %l127, !tbaa !24
  %t219 = icmp slt i64 %t217, %t218
  store i1 %t219, ptr %l128, !tbaa !21
  %t220 = load i1, ptr %l128, !tbaa !21
  br i1 %t220, label %bb63, label %bb64
bb63:
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t221, ptr %l130, !tbaa !27
  %t222 = load i64, ptr %l10, !tbaa !24
  store i64 %t222, ptr %l131, !tbaa !24
  %t223 = load i64, ptr %l131, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i8, ptr %t225, i64 %t223
  %t227 = load i8, ptr %t226, !tbaa !32
  store i8 %t227, ptr %l132, !tbaa !22
  %t228 = load i8, ptr %l132, !tbaa !22
  %t229 = icmp eq i8 %t228, 101
  store i1 %t229, ptr %l133, !tbaa !21
  %t230 = load i1, ptr %l133, !tbaa !21
  br i1 %t230, label %bb65, label %bb66
bb64:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb68
bb65:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb67
bb66:
  %t231 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t231, ptr %l135, !tbaa !27
  %t232 = load i64, ptr %l10, !tbaa !24
  store i64 %t232, ptr %l136, !tbaa !24
  %t233 = load i64, ptr %l136, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i8, ptr %t235, i64 %t233
  %t237 = load i8, ptr %t236, !tbaa !32
  store i8 %t237, ptr %l137, !tbaa !22
  %t238 = load i8, ptr %l137, !tbaa !22
  %t239 = icmp eq i8 %t238, 69
  store i1 %t239, ptr %l138, !tbaa !21
  %t240 = load i1, ptr %l138, !tbaa !21
  store i1 %t240, ptr %l134, !tbaa !21
  br label %bb67
bb67:
  %t241 = load i1, ptr %l134, !tbaa !21
  store i1 %t241, ptr %l129, !tbaa !21
  br label %bb68
bb68:
  %t242 = load i1, ptr %l129, !tbaa !21
  br i1 %t242, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s8
  %t243 = load i64, ptr %l10, !tbaa !24
  store i64 %t243, ptr %l139, !tbaa !24
  %t244 = load i64, ptr %l139, !tbaa !24
  %t245 = add i64 %t244, 1
  store i64 %t245, ptr %l140, !tbaa !24
  %t246 = load i64, ptr %l140, !tbaa !24
  store i64 %t246, ptr %l15, !tbaa !24
  %t247 = load i64, ptr %l15, !tbaa !24
  store i64 %t247, ptr %l141, !tbaa !24
  %t248 = load i64, ptr %l3, !tbaa !24
  store i64 %t248, ptr %l142, !tbaa !24
  %t249 = load i64, ptr %l141, !tbaa !24
  %t250 = load i64, ptr %l142, !tbaa !24
  %t251 = icmp slt i64 %t249, %t250
  store i1 %t251, ptr %l143, !tbaa !21
  %t252 = load i1, ptr %l143, !tbaa !21
  br i1 %t252, label %bb71, label %bb72
bb70:
  br label %bb85
bb71:
  %t253 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t253, ptr %l145, !tbaa !27
  %t254 = load i64, ptr %l15, !tbaa !24
  store i64 %t254, ptr %l146, !tbaa !24
  %t255 = load i64, ptr %l146, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr i8, ptr %t257, i64 %t255
  %t259 = load i8, ptr %t258, !tbaa !32
  store i8 %t259, ptr %l147, !tbaa !22
  %t260 = load i8, ptr %l147, !tbaa !22
  %t261 = icmp eq i8 %t260, 43
  store i1 %t261, ptr %l148, !tbaa !21
  %t262 = load i1, ptr %l148, !tbaa !21
  br i1 %t262, label %bb73, label %bb74
bb72:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb76
bb73:
  store i1 true, ptr %l149, !tbaa !21
  br label %bb75
bb74:
  %t263 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t263, ptr %l150, !tbaa !27
  %t264 = load i64, ptr %l15, !tbaa !24
  store i64 %t264, ptr %l151, !tbaa !24
  %t265 = load i64, ptr %l151, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i8, ptr %t267, i64 %t265
  %t269 = load i8, ptr %t268, !tbaa !32
  store i8 %t269, ptr %l152, !tbaa !22
  %t270 = load i8, ptr %l152, !tbaa !22
  %t271 = icmp eq i8 %t270, 45
  store i1 %t271, ptr %l153, !tbaa !21
  %t272 = load i1, ptr %l153, !tbaa !21
  store i1 %t272, ptr %l149, !tbaa !21
  br label %bb75
bb75:
  %t273 = load i1, ptr %l149, !tbaa !21
  store i1 %t273, ptr %l144, !tbaa !21
  br label %bb76
bb76:
  %t274 = load i1, ptr %l144, !tbaa !21
  br i1 %t274, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s9
  %t275 = load i64, ptr %l15, !tbaa !24
  store i64 %t275, ptr %l154, !tbaa !24
  %t276 = load i64, ptr %l154, !tbaa !24
  %t277 = add i64 %t276, 1
  store i64 %t277, ptr %l155, !tbaa !24
  %t278 = load i64, ptr %l155, !tbaa !24
  store i64 %t278, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb79
bb78:
  br label %bb79
bb79:
  %t279 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t279, ptr %l156, !tbaa !27
  %t280 = load i64, ptr %l15, !tbaa !24
  store i64 %t280, ptr %l157, !tbaa !24
  %t281 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t282 = load i64, ptr %l157, !tbaa !24
  %t283 = call i1 @compiler_2fscan_2eexponentDigits(ptr %v0, { i64, ptr } %t281, i64 %t282)
  store i1 %t283, ptr %l158
  br label %bb80
bb80:
  %t284 = load i1, ptr %l158, !tbaa !21
  br i1 %t284, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s10
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l159, !tbaa !29
  %t286 = load i64, ptr %l15, !tbaa !24
  store i64 %t286, ptr %l160, !tbaa !24
  %t287 = load ptr, ptr %l159, !tbaa !29
  %t288 = load i64, ptr %l160, !tbaa !24
  %t289 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t287, i64 %t288, i64 10)
  store { i64, i64 } %t289, ptr %l161
  br label %bb83
bb82:
  br label %bb84
bb83:
  %t290 = load { i64, i64 }, ptr %l161
  store { i64, i64 } %t290, ptr %l16
  %t291 = getelementptr { i64, i64 }, ptr %l16, i32 0, i32 0
  %t292 = load i64, ptr %t291, !tbaa !24
  store i64 %t292, ptr %l162, !tbaa !24
  %t293 = load i64, ptr %l162, !tbaa !24
  store i64 %t293, ptr %l17, !tbaa !24
  store i32 3, ptr %l163
  %t294 = load i64, ptr %l17, !tbaa !24
  store i64 %t294, ptr %l164, !tbaa !24
  %t295 = load i32, ptr %l163
  %t296 = insertvalue { i32, i64 } undef, i32 %t295, 0
  %t297 = load i64, ptr %l164, !tbaa !24
  %t298 = insertvalue { i32, i64 } %t296, i64 %t297, 1
  store { i32, i64 } %t298, ptr %l165
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t299 = load { i32, i64 }, ptr %l165
  store { i32, i64 } %t299, ptr %rv
  br label %ret
bb84:
  call void @__olang_scope_close(ptr %s8)
  br label %bb85
bb85:
  %t300 = load i32, ptr %l11
  store i32 %t300, ptr %l166
  %t301 = load i64, ptr %l10, !tbaa !24
  store i64 %t301, ptr %l167, !tbaa !24
  %t302 = load i32, ptr %l166
  %t303 = insertvalue { i32, i64 } undef, i32 %t302, 0
  %t304 = load i64, ptr %l167, !tbaa !24
  %t305 = insertvalue { i32, i64 } %t303, i64 %t304, 1
  store { i32, i64 } %t305, ptr %l168
  call void @__olang_scope_close(ptr %s0)
  %t306 = load { i32, i64 }, ptr %l168
  store { i32, i64 } %t306, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca { i64, i1 }
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i8
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca { i32, i64 }
  %l16 = alloca { i32, i64 }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca i8
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i8
  %l34 = alloca i8
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i8
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i8
  %l42 = alloca i1
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i8
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i8
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, i1 }
  %l61 = alloca i64
  %l62 = alloca i1
  %l63 = alloca i64
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i1
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i1
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca i8
  %l86 = alloca i32
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i8
  %l90 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i8
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i32
  %l99 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca ptr
  %l102 = alloca i1
  %l103 = alloca i32
  %l104 = alloca i32
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i32
  %l111 = alloca i8
  %l112 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i64
  %l115 = alloca { i32, i64 }
  %l116 = alloca i32
  %l117 = alloca i64
  %l118 = alloca i8
  %l119 = alloca i1
  %l120 = alloca i32
  %l121 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i8
  %l125 = alloca i1
  %l126 = alloca i32
  %l127 = alloca ptr
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca { i32, i64 }
  %l133 = alloca i32
  %l134 = alloca i64
  %l135 = alloca i32
  %l136 = alloca ptr
  %l137 = alloca i32
  %l138 = alloca ptr
  %l139 = alloca i1
  %l140 = alloca i8
  %l141 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i64
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i32
  %l150 = alloca i1
  %l151 = alloca i1
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i64
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca i64
  %l159 = alloca i32
  %l160 = alloca i64
  %l161 = alloca i32
  %l162 = alloca %"compiler/token:Token"
  %l163 = alloca i32
  %l164 = alloca i8
  %l165 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i1
  %l168 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca i64
  %l172 = alloca i64
  %l173 = alloca i64
  %l174 = alloca ptr
  %l175 = alloca i64
  %l176 = alloca i64
  %l177 = alloca { i64, ptr }
  %l178 = alloca i64
  %l179 = alloca i64
  %l180 = alloca i64
  %l181 = alloca i8
  %l182 = alloca i1
  %l183 = alloca i32
  %l184 = alloca i32
  %l185 = alloca i8
  %l186 = alloca i1
  %l187 = alloca i32
  %l188 = alloca i32
  %l189 = alloca i32
  %l190 = alloca ptr
  %l191 = alloca i32
  %l192 = alloca i64
  %l193 = alloca i64
  %l194 = alloca i8
  %l195 = alloca i64
  %l196 = alloca i1
  %l197 = alloca i8
  %l198 = alloca i8
  %l199 = alloca i8
  %l200 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i1
  %l203 = alloca i8
  %l204 = alloca i8
  %l205 = alloca i8
  %l206 = alloca i64
  %l207 = alloca i1
  %l208 = alloca i1
  %l209 = alloca { i64, ptr }
  %l210 = alloca i64
  %l211 = alloca i64
  %l212 = alloca i8
  %l213 = alloca i1
  %l214 = alloca i1
  %l215 = alloca i8
  %l216 = alloca i8
  %l217 = alloca i8
  %l218 = alloca i1
  %l219 = alloca i1
  %l220 = alloca i64
  %l221 = alloca i1
  %l222 = alloca ptr
  %l223 = alloca i32
  %l224 = alloca i64
  %l225 = alloca i1
  %l226 = alloca i1
  %l227 = alloca i32
  %l228 = alloca ptr
  %l229 = alloca i32
  %l230 = alloca ptr
  %l231 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca i32
  %l234 = alloca i64
  %l235 = alloca i64
  %l236 = alloca i64
  %l237 = alloca i1
  %l238 = alloca i1
  %l239 = alloca i32
  %l240 = alloca i1
  %l241 = alloca i1
  %l242 = alloca i32
  %l243 = alloca ptr
  %l244 = alloca i32
  %l245 = alloca ptr
  %l246 = alloca i1
  %l247 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca ptr
  %l250 = alloca i32
  %l251 = alloca i64
  %l252 = alloca i32
  %l253 = alloca i64
  %l254 = alloca i32
  %l255 = alloca %"compiler/token:Token"
  %l256 = alloca ptr
  %l257 = alloca ptr
  %l258 = alloca i32
  %l259 = alloca i8
  %l260 = alloca i64
  %l261 = alloca i32
  %l262 = alloca i64
  %l263 = alloca i32
  %l264 = alloca %"compiler/token:Token"
  %l265 = alloca ptr
  %l266 = alloca i32
  %l267 = alloca i32
  %l268 = alloca i64
  %l269 = alloca i64
  %l270 = alloca i32
  %l271 = alloca ptr
  %l272 = alloca i32
  %l273 = alloca ptr
  %l274 = alloca i1
  %l275 = alloca ptr
  %l276 = alloca i32
  %l277 = alloca i64
  %l278 = alloca i64
  %l279 = alloca i64
  %l280 = alloca i32
  %l281 = alloca i1
  %l282 = alloca ptr
  %l283 = alloca ptr
  %l284 = alloca i32
  %l285 = alloca i64
  %l286 = alloca i32
  %l287 = alloca i64
  %l288 = alloca i32
  %l289 = alloca %"compiler/token:Token"
  %l290 = alloca ptr
  %l291 = alloca ptr
  %l292 = alloca i32
  %l293 = alloca i8
  %l294 = alloca i64
  %l295 = alloca i32
  %l296 = alloca i64
  %l297 = alloca i32
  %l298 = alloca %"compiler/token:Token"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l22, !tbaa !29
  %t2 = load ptr, ptr %l22, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l23, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t5, ptr %l1, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t6, ptr %l24, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l25, !tbaa !24
  %t9 = load i64, ptr %l25, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  store i32 0, ptr %l26
  %t10 = load i32, ptr %l26
  store i32 %t10, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l27, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  store i64 %t12, ptr %l28, !tbaa !24
  %t13 = load i64, ptr %l27, !tbaa !24
  %t14 = load i64, ptr %l28, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  store i1 %t15, ptr %l29, !tbaa !21
  %t16 = load i1, ptr %l29, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l30, !tbaa !21
  %t18 = load i1, ptr %l30, !tbaa !21
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t19, ptr %l31, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l32, !tbaa !24
  %t21 = load i64, ptr %l32, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t21
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l33, !tbaa !22
  %t26 = load i8, ptr %l33, !tbaa !22
  store i8 %t26, ptr %l7, !tbaa !22
  %t27 = load i8, ptr %l7, !tbaa !22
  store i8 %t27, ptr %l34, !tbaa !22
  %t28 = load i8, ptr %l34, !tbaa !22
  %t29 = icmp eq i8 %t28, 32
  store i1 %t29, ptr %l35, !tbaa !21
  %t30 = load i1, ptr %l35, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb8
bb7:
  %t31 = load i8, ptr %l7, !tbaa !22
  store i8 %t31, ptr %l37, !tbaa !22
  %t32 = load i8, ptr %l37, !tbaa !22
  %t33 = icmp eq i8 %t32, 9
  store i1 %t33, ptr %l38, !tbaa !21
  %t34 = load i1, ptr %l38, !tbaa !21
  store i1 %t34, ptr %l36, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l36, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %l39, !tbaa !24
  %t37 = load i64, ptr %l39, !tbaa !24
  %t38 = add i64 %t37, 1
  store i64 %t38, ptr %l40, !tbaa !24
  %t39 = load i64, ptr %l40, !tbaa !24
  store i64 %t39, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t40 = load i8, ptr %l7, !tbaa !22
  store i8 %t40, ptr %l41, !tbaa !22
  %t41 = load i8, ptr %l41, !tbaa !22
  %t42 = icmp eq i8 %t41, 10
  store i1 %t42, ptr %l42, !tbaa !21
  %t43 = load i1, ptr %l42, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  store i1 true, ptr %l4, !tbaa !21
  %t44 = load i64, ptr %l3, !tbaa !24
  store i64 %t44, ptr %l43, !tbaa !24
  %t45 = load i64, ptr %l43, !tbaa !24
  %t46 = add i64 %t45, 1
  store i64 %t46, ptr %l44, !tbaa !24
  %t47 = load i64, ptr %l44, !tbaa !24
  store i64 %t47, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb12:
  store %olang.scope zeroinitializer, ptr %s6
  %t48 = load i8, ptr %l7, !tbaa !22
  store i8 %t48, ptr %l45, !tbaa !22
  %t49 = load i8, ptr %l45, !tbaa !22
  %t50 = icmp eq i8 %t49, 35
  store i1 %t50, ptr %l46, !tbaa !21
  %t51 = load i1, ptr %l46, !tbaa !21
  br i1 %t51, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s7
  %t52 = load i64, ptr %l3, !tbaa !24
  store i64 %t52, ptr %l47, !tbaa !24
  %t53 = load i64, ptr %l47, !tbaa !24
  %t54 = add i64 %t53, 1
  store i64 %t54, ptr %l48, !tbaa !24
  %t55 = load i64, ptr %l2, !tbaa !24
  store i64 %t55, ptr %l49, !tbaa !24
  %t56 = load i64, ptr %l48, !tbaa !24
  %t57 = load i64, ptr %l49, !tbaa !24
  %t58 = icmp slt i64 %t56, %t57
  store i1 %t58, ptr %l50, !tbaa !21
  %t59 = load i1, ptr %l50, !tbaa !21
  br i1 %t59, label %bb15, label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s14
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb15:
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t60, ptr %l52, !tbaa !27
  %t61 = load i64, ptr %l3, !tbaa !24
  store i64 %t61, ptr %l53, !tbaa !24
  %t62 = load i64, ptr %l53, !tbaa !24
  %t63 = add i64 %t62, 1
  store i64 %t63, ptr %l54, !tbaa !24
  %t64 = load i64, ptr %l54, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i8, ptr %t66, i64 %t64
  %t68 = load i8, ptr %t67, !tbaa !32
  store i8 %t68, ptr %l55, !tbaa !22
  %t69 = load i8, ptr %l55, !tbaa !22
  %t70 = icmp eq i8 %t69, 35
  store i1 %t70, ptr %l56, !tbaa !21
  %t71 = load i1, ptr %l56, !tbaa !21
  store i1 %t71, ptr %l51, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb17
bb17:
  %t72 = load i1, ptr %l51, !tbaa !21
  br i1 %t72, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s8
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t73, ptr %l57, !tbaa !27
  %t74 = load i64, ptr %l3, !tbaa !24
  store i64 %t74, ptr %l58, !tbaa !24
  %t75 = load i64, ptr %l58, !tbaa !24
  %t76 = add i64 %t75, 2
  store i64 %t76, ptr %l59, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t78 = load i64, ptr %l59, !tbaa !24
  %t79 = call { i64, i1 } @compiler_2fscan_2eblockComment(ptr %v0, { i64, ptr } %t77, i64 %t78)
  store { i64, i1 } %t79, ptr %l60
  br label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s12
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t80, ptr %l73, !tbaa !27
  %t81 = load i64, ptr %l3, !tbaa !24
  store i64 %t81, ptr %l74, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t83 = load i64, ptr %l74, !tbaa !24
  %t84 = call i64 @compiler_2fscan_2elineEnd(ptr %v0, { i64, ptr } %t82, i64 %t83)
  store i64 %t84, ptr %l75
  br label %bb28
bb20:
  %t85 = load { i64, i1 }, ptr %l60
  store { i64, i1 } %t85, ptr %l8
  %t86 = getelementptr { i64, i1 }, ptr %l8, i32 0, i32 0
  %t87 = load i64, ptr %t86, !tbaa !24
  store i64 %t87, ptr %l61, !tbaa !24
  %t88 = load i64, ptr %l61, !tbaa !24
  store i64 %t88, ptr %l9, !tbaa !24
  %t89 = getelementptr { i64, i1 }, ptr %l8, i32 0, i32 1
  %t90 = load i1, ptr %t89, !tbaa !21
  store i1 %t90, ptr %l62, !tbaa !21
  %t91 = load i1, ptr %l62, !tbaa !21
  store i1 %t91, ptr %l10, !tbaa !21
  %t92 = load i64, ptr %l9, !tbaa !24
  store i64 %t92, ptr %l63, !tbaa !24
  %t93 = load i64, ptr %l63, !tbaa !24
  %t94 = icmp slt i64 %t93, 0
  store i1 %t94, ptr %l64, !tbaa !21
  %t95 = load i1, ptr %l64, !tbaa !21
  br i1 %t95, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s9
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l65, !tbaa !29
  store i32 6, ptr %l66
  %t97 = load i64, ptr %l3, !tbaa !24
  store i64 %t97, ptr %l67, !tbaa !24
  %t98 = load i64, ptr %l3, !tbaa !24
  store i64 %t98, ptr %l68, !tbaa !24
  %t99 = load i64, ptr %l68, !tbaa !24
  %t100 = add i64 %t99, 2
  store i64 %t100, ptr %l69, !tbaa !24
  %t101 = load ptr, ptr %l65, !tbaa !29
  %t102 = load i32, ptr %l66
  %t103 = load i64, ptr %l67, !tbaa !24
  %t104 = load i64, ptr %l69, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t101, i32 %t102, i64 %t103, i64 %t104, i8 0)
  br label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s10
  %t105 = load i1, ptr %l10, !tbaa !21
  store i1 %t105, ptr %l71, !tbaa !21
  %t106 = load i1, ptr %l71, !tbaa !21
  br i1 %t106, label %bb24, label %bb25
bb23:
  %t107 = load i64, ptr %l2, !tbaa !24
  store i64 %t107, ptr %l70, !tbaa !24
  %t108 = load i64, ptr %l70, !tbaa !24
  store i64 %t108, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb27
bb24:
  store %olang.scope zeroinitializer, ptr %s11
  store i1 true, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t109 = load i64, ptr %l9, !tbaa !24
  store i64 %t109, ptr %l72, !tbaa !24
  %t110 = load i64, ptr %l72, !tbaa !24
  store i64 %t110, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s8)
  br label %bb32
bb28:
  %t111 = load i64, ptr %l75, !tbaa !24
  store i64 %t111, ptr %l3, !tbaa !24
  %t112 = load i64, ptr %l3, !tbaa !24
  store i64 %t112, ptr %l76, !tbaa !24
  %t113 = load i64, ptr %l2, !tbaa !24
  store i64 %t113, ptr %l77, !tbaa !24
  %t114 = load i64, ptr %l76, !tbaa !24
  %t115 = load i64, ptr %l77, !tbaa !24
  %t116 = icmp eq i64 %t114, %t115
  store i1 %t116, ptr %l78, !tbaa !21
  %t117 = load i1, ptr %l78, !tbaa !21
  br i1 %t117, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s13
  store i1 true, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb31
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s12)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb36:
  br label %bb2
bb37:
  %t118 = load i64, ptr %l3, !tbaa !24
  store i64 %t118, ptr %l79, !tbaa !24
  %t119 = load i64, ptr %l2, !tbaa !24
  store i64 %t119, ptr %l80, !tbaa !24
  %t120 = load i64, ptr %l79, !tbaa !24
  %t121 = load i64, ptr %l80, !tbaa !24
  %t122 = icmp sge i64 %t120, %t121
  store i1 %t122, ptr %l81, !tbaa !21
  %t123 = load i1, ptr %l81, !tbaa !21
  br i1 %t123, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s15
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s1)
  br label %bb144
bb39:
  br label %bb40
bb40:
  %t124 = load i64, ptr %l3, !tbaa !24
  store i64 %t124, ptr %l82, !tbaa !24
  %t125 = load i64, ptr %l82, !tbaa !24
  store i64 %t125, ptr %l11, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t126, ptr %l83, !tbaa !27
  %t127 = load i64, ptr %l3, !tbaa !24
  store i64 %t127, ptr %l84, !tbaa !24
  %t128 = load i64, ptr %l84, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i8, ptr %t130, i64 %t128
  %t132 = load i8, ptr %t131, !tbaa !32
  store i8 %t132, ptr %l85, !tbaa !22
  %t133 = load i8, ptr %l85, !tbaa !22
  store i8 %t133, ptr %l12, !tbaa !22
  store i32 0, ptr %l86
  %t134 = load i32, ptr %l86
  store i32 %t134, ptr %l13
  %t135 = load i64, ptr %l3, !tbaa !24
  store i64 %t135, ptr %l87, !tbaa !24
  %t136 = load i64, ptr %l87, !tbaa !24
  %t137 = add i64 %t136, 1
  store i64 %t137, ptr %l88, !tbaa !24
  %t138 = load i64, ptr %l88, !tbaa !24
  store i64 %t138, ptr %l14, !tbaa !24
  %t139 = load i8, ptr %l12, !tbaa !22
  store i8 %t139, ptr %l89, !tbaa !22
  %t140 = load i8, ptr %l89, !tbaa !22
  %t141 = call i1 @compiler_2fscan_2eisLetter(i8 %t140)
  store i1 %t141, ptr %l90
  br label %bb41
bb41:
  %t142 = load i1, ptr %l90, !tbaa !21
  br i1 %t142, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb44
bb43:
  %t143 = load i8, ptr %l12, !tbaa !22
  store i8 %t143, ptr %l92, !tbaa !22
  %t144 = load i8, ptr %l92, !tbaa !22
  %t145 = icmp eq i8 %t144, 95
  store i1 %t145, ptr %l93, !tbaa !21
  %t146 = load i1, ptr %l93, !tbaa !21
  store i1 %t146, ptr %l91, !tbaa !21
  br label %bb44
bb44:
  %t147 = load i1, ptr %l91, !tbaa !21
  br i1 %t147, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s16
  %t148 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t148, ptr %l94, !tbaa !27
  %t149 = load i64, ptr %l3, !tbaa !24
  store i64 %t149, ptr %l95, !tbaa !24
  %t150 = load i64, ptr %l95, !tbaa !24
  %t151 = add i64 %t150, 1
  store i64 %t151, ptr %l96, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t153 = load i64, ptr %l96, !tbaa !24
  %t154 = call i64 @compiler_2fscan_2ewordEnd(ptr %v0, { i64, ptr } %t152, i64 %t153)
  store i64 %t154, ptr %l97
  br label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s17
  %t155 = load i8, ptr %l12, !tbaa !22
  store i8 %t155, ptr %l111, !tbaa !22
  %t156 = load i8, ptr %l111, !tbaa !22
  %t157 = call i1 @compiler_2fscan_2eisDigit(i8 %t156)
  store i1 %t157, ptr %l112
  br label %bb53
bb47:
  %t158 = load i64, ptr %l97, !tbaa !24
  store i64 %t158, ptr %l14, !tbaa !24
  %t159 = load i32, ptr %l5
  store i32 %t159, ptr %l98
  store ptr %l98, ptr %l99, !tbaa !29
  store i32 58, ptr %l100
  store ptr %l100, ptr %l101, !tbaa !29
  %t160 = load ptr, ptr %l99, !tbaa !29
  %t161 = load ptr, ptr %l101, !tbaa !29
  %t162 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t160, ptr %t161)
  store i1 %t162, ptr %l102
  br label %bb48
bb48:
  %t163 = load i1, ptr %l102, !tbaa !21
  br i1 %t163, label %bb49, label %bb50
bb49:
  store i32 1, ptr %l104
  %t164 = load i32, ptr %l104
  store i32 %t164, ptr %l103
  br label %bb52
bb50:
  %t165 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t165, ptr %l105, !tbaa !27
  %t166 = load i64, ptr %l3, !tbaa !24
  store i64 %t166, ptr %l106, !tbaa !24
  %t167 = load i64, ptr %l14, !tbaa !24
  store i64 %t167, ptr %l107, !tbaa !24
  %t168 = load i64, ptr %l3, !tbaa !24
  store i64 %t168, ptr %l108, !tbaa !24
  %t169 = load i64, ptr %l107, !tbaa !24
  %t170 = load i64, ptr %l108, !tbaa !24
  %t171 = sub i64 %t169, %t170
  store i64 %t171, ptr %l109, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t173 = load i64, ptr %l106, !tbaa !24
  %t174 = load i64, ptr %l109, !tbaa !24
  %t175 = call i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %t172, i64 %t173, i64 %t174)
  store i32 %t175, ptr %l110
  br label %bb51
bb51:
  %t176 = load i32, ptr %l110
  store i32 %t176, ptr %l103
  br label %bb52
bb52:
  %t177 = load i32, ptr %l103
  store i32 %t177, ptr %l13
  call void @__olang_scope_close(ptr %s16)
  br label %bb99
bb53:
  %t178 = load i1, ptr %l112, !tbaa !21
  br i1 %t178, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s18
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l113, !tbaa !29
  %t180 = load i64, ptr %l3, !tbaa !24
  store i64 %t180, ptr %l114, !tbaa !24
  %t181 = load ptr, ptr %l113, !tbaa !29
  %t182 = load i64, ptr %l114, !tbaa !24
  %t183 = call { i32, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2enumber(ptr %v0, ptr %t181, i64 %t182)
  store { i32, i64 } %t183, ptr %l115
  br label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s19
  %t184 = load i8, ptr %l12, !tbaa !22
  store i8 %t184, ptr %l118, !tbaa !22
  %t185 = load i8, ptr %l118, !tbaa !22
  %t186 = icmp eq i8 %t185, 34
  store i1 %t186, ptr %l119, !tbaa !21
  %t187 = load i1, ptr %l119, !tbaa !21
  br i1 %t187, label %bb57, label %bb58
bb56:
  %t188 = load { i32, i64 }, ptr %l115
  store { i32, i64 } %t188, ptr %l15
  %t189 = getelementptr { i32, i64 }, ptr %l15, i32 0, i32 0
  %t190 = load i32, ptr %t189
  store i32 %t190, ptr %l116
  %t191 = load i32, ptr %l116
  store i32 %t191, ptr %l13
  %t192 = getelementptr { i32, i64 }, ptr %l15, i32 0, i32 1
  %t193 = load i64, ptr %t192, !tbaa !24
  store i64 %t193, ptr %l117, !tbaa !24
  %t194 = load i64, ptr %l117, !tbaa !24
  store i64 %t194, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb98
bb57:
  store %olang.scope zeroinitializer, ptr %s20
  store i32 5, ptr %l120
  %t195 = load i32, ptr %l120
  store i32 %t195, ptr %l13
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l121, !tbaa !29
  %t197 = load i64, ptr %l3, !tbaa !24
  store i64 %t197, ptr %l122, !tbaa !24
  %t198 = load ptr, ptr %l121, !tbaa !29
  %t199 = load i64, ptr %l122, !tbaa !24
  %t200 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2estr(ptr %v0, ptr %t198, i64 %t199)
  store i64 %t200, ptr %l123
  br label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s21
  %t201 = load i8, ptr %l12, !tbaa !22
  store i8 %t201, ptr %l124, !tbaa !22
  %t202 = load i8, ptr %l124, !tbaa !22
  %t203 = icmp eq i8 %t202, 39
  store i1 %t203, ptr %l125, !tbaa !21
  %t204 = load i1, ptr %l125, !tbaa !21
  br i1 %t204, label %bb60, label %bb61
bb59:
  %t205 = load i64, ptr %l123, !tbaa !24
  store i64 %t205, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb97
bb60:
  store %olang.scope zeroinitializer, ptr %s22
  store i32 4, ptr %l126
  %t206 = load i32, ptr %l126
  store i32 %t206, ptr %l13
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l127, !tbaa !29
  %t208 = load i64, ptr %l3, !tbaa !24
  store i64 %t208, ptr %l128, !tbaa !24
  %t209 = load ptr, ptr %l127, !tbaa !29
  %t210 = load i64, ptr %l128, !tbaa !24
  %t211 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2echar(ptr %v0, ptr %t209, i64 %t210)
  store i64 %t211, ptr %l129
  br label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s23
  %t212 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t212, ptr %l130, !tbaa !27
  %t213 = load i64, ptr %l3, !tbaa !24
  store i64 %t213, ptr %l131, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t215 = load i64, ptr %l131, !tbaa !24
  %t216 = call { i32, i64 } @compiler_2fscan_2eoperator(ptr %v0, { i64, ptr } %t214, i64 %t215)
  store { i32, i64 } %t216, ptr %l132
  br label %bb63
bb62:
  %t217 = load i64, ptr %l129, !tbaa !24
  store i64 %t217, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb96
bb63:
  %t218 = load { i32, i64 }, ptr %l132
  store { i32, i64 } %t218, ptr %l16
  %t219 = getelementptr { i32, i64 }, ptr %l16, i32 0, i32 0
  %t220 = load i32, ptr %t219
  store i32 %t220, ptr %l133
  %t221 = load i32, ptr %l133
  store i32 %t221, ptr %l13
  %t222 = getelementptr { i32, i64 }, ptr %l16, i32 0, i32 1
  %t223 = load i64, ptr %t222, !tbaa !24
  store i64 %t223, ptr %l134, !tbaa !24
  %t224 = load i64, ptr %l134, !tbaa !24
  store i64 %t224, ptr %l14, !tbaa !24
  %t225 = load i32, ptr %l13
  store i32 %t225, ptr %l135
  store ptr %l135, ptr %l136, !tbaa !29
  store i32 0, ptr %l137
  store ptr %l137, ptr %l138, !tbaa !29
  %t226 = load ptr, ptr %l136, !tbaa !29
  %t227 = load ptr, ptr %l138, !tbaa !29
  %t228 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t226, ptr %t227)
  store i1 %t228, ptr %l139
  br label %bb64
bb64:
  %t229 = load i1, ptr %l139, !tbaa !21
  br i1 %t229, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s24
  %t230 = load i8, ptr %l12, !tbaa !22
  store i8 %t230, ptr %l140, !tbaa !22
  %t231 = load i8, ptr %l140, !tbaa !22
  %t232 = icmp eq i8 %t231, 59
  store i1 %t232, ptr %l141, !tbaa !21
  %t233 = load i1, ptr %l141, !tbaa !21
  br i1 %t233, label %bb67, label %bb68
bb66:
  br label %bb95
bb67:
  store %olang.scope zeroinitializer, ptr %s25
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l142, !tbaa !29
  store i32 4, ptr %l143
  %t235 = load i64, ptr %l3, !tbaa !24
  store i64 %t235, ptr %l144, !tbaa !24
  %t236 = load i64, ptr %l3, !tbaa !24
  store i64 %t236, ptr %l145, !tbaa !24
  %t237 = load i64, ptr %l145, !tbaa !24
  %t238 = add i64 %t237, 1
  store i64 %t238, ptr %l146, !tbaa !24
  %t239 = load ptr, ptr %l142, !tbaa !29
  %t240 = load i32, ptr %l143
  %t241 = load i64, ptr %l144, !tbaa !24
  %t242 = load i64, ptr %l146, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t239, i32 %t240, i64 %t241, i64 %t242, i8 0)
  br label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s27
  %t243 = load i8, ptr %l12, !tbaa !22
  store i8 %t243, ptr %l164, !tbaa !22
  %t244 = load i8, ptr %l164, !tbaa !22
  %t245 = icmp eq i8 %t244, 13
  store i1 %t245, ptr %l165, !tbaa !21
  %t246 = load i1, ptr %l165, !tbaa !21
  br i1 %t246, label %bb79, label %bb80
bb69:
  %t247 = load i64, ptr %l3, !tbaa !24
  store i64 %t247, ptr %l147, !tbaa !24
  %t248 = load i64, ptr %l147, !tbaa !24
  %t249 = add i64 %t248, 1
  store i64 %t249, ptr %l148, !tbaa !24
  %t250 = load i64, ptr %l148, !tbaa !24
  store i64 %t250, ptr %l3, !tbaa !24
  %t251 = load i32, ptr %l5
  store i32 %t251, ptr %l149
  %t252 = load i32, ptr %l149
  %t253 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %t252)
  store i1 %t253, ptr %l150
  br label %bb70
bb70:
  %t254 = load i1, ptr %l150, !tbaa !21
  br i1 %t254, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s26
  %t255 = load i1, ptr %l4, !tbaa !21
  store i1 %t255, ptr %l151, !tbaa !21
  %t256 = load i1, ptr %l151, !tbaa !21
  br i1 %t256, label %bb73, label %bb74
bb72:
  br label %bb78
bb73:
  %t257 = load i64, ptr %l6, !tbaa !24
  store i64 %t257, ptr %l153, !tbaa !24
  %t258 = load i64, ptr %l153, !tbaa !24
  store i64 %t258, ptr %l152, !tbaa !24
  br label %bb75
bb74:
  %t259 = load i64, ptr %l11, !tbaa !24
  store i64 %t259, ptr %l154, !tbaa !24
  %t260 = load i64, ptr %l154, !tbaa !24
  store i64 %t260, ptr %l152, !tbaa !24
  br label %bb75
bb75:
  %t261 = load i64, ptr %l152, !tbaa !24
  store i64 %t261, ptr %l17, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l155, !tbaa !29
  %t263 = load ptr, ptr %l155, !tbaa !29
  %t264 = getelementptr %"compiler/scan:scanner", ptr %t263, i32 0, i32 1
  store ptr %t264, ptr %l156, !tbaa !29
  store i32 8, ptr %l157
  %t265 = load i64, ptr %l17, !tbaa !24
  store i64 %t265, ptr %l158, !tbaa !24
  %t266 = load i64, ptr %l158, !tbaa !24
  %t267 = trunc i64 %t266 to i32
  store i32 %t267, ptr %l159, !tbaa !23
  %t268 = load i64, ptr %l17, !tbaa !24
  store i64 %t268, ptr %l160, !tbaa !24
  %t269 = load i64, ptr %l160, !tbaa !24
  %t270 = trunc i64 %t269 to i32
  store i32 %t270, ptr %l161, !tbaa !23
  %t271 = load i32, ptr %l157
  %t272 = load i32, ptr %l159, !tbaa !23
  %t273 = load i32, ptr %l161, !tbaa !23
  %t274 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s26, i32 %t271, i8 0, i32 %t272, i32 %t273)
  store %"compiler/token:Token" %t274, ptr %l162
  br label %bb76
bb76:
  %t275 = load ptr, ptr %l156, !tbaa !29
  %t276 = load %"compiler/token:Token", ptr %l162
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t275, %"compiler/token:Token" %t276)
  br label %bb77
bb77:
  store i32 8, ptr %l163
  %t277 = load i32, ptr %l163
  store i32 %t277, ptr %l5
  call void @__olang_scope_close(ptr %s26)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s25)
  br label %bb94
bb79:
  store %olang.scope zeroinitializer, ptr %s28
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l166, !tbaa !29
  %t279 = load ptr, ptr %l166, !tbaa !29
  %t280 = getelementptr %"compiler/scan:scanner", ptr %t279, i32 0, i32 5
  %t281 = load i1, ptr %t280, !tbaa !21
  store i1 %t281, ptr %l167, !tbaa !21
  %t282 = load i1, ptr %l167, !tbaa !21
  %t283 = xor i1 %t282, true
  store i1 %t283, ptr %l168, !tbaa !21
  %t284 = load i1, ptr %l168, !tbaa !21
  br i1 %t284, label %bb81, label %bb82
bb80:
  store %olang.scope zeroinitializer, ptr %s30
  %t285 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t285, ptr %l177, !tbaa !27
  %t286 = load i64, ptr %l3, !tbaa !24
  store i64 %t286, ptr %l178, !tbaa !24
  %t287 = load i64, ptr %l178, !tbaa !24
  %t288 = add i64 %t287, 1
  store i64 %t288, ptr %l179, !tbaa !24
  %t289 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t290 = load i64, ptr %l179, !tbaa !24
  %t291 = call i64 @compiler_2fscan_2ejunkEnd(ptr %v0, { i64, ptr } %t289, i64 %t290)
  store i64 %t291, ptr %l180
  br label %bb85
bb81:
  store %olang.scope zeroinitializer, ptr %s29
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l169, !tbaa !29
  store i32 3, ptr %l170
  %t293 = load i64, ptr %l3, !tbaa !24
  store i64 %t293, ptr %l171, !tbaa !24
  %t294 = load i64, ptr %l3, !tbaa !24
  store i64 %t294, ptr %l172, !tbaa !24
  %t295 = load i64, ptr %l172, !tbaa !24
  %t296 = add i64 %t295, 1
  store i64 %t296, ptr %l173, !tbaa !24
  %t297 = load ptr, ptr %l169, !tbaa !29
  %t298 = load i32, ptr %l170
  %t299 = load i64, ptr %l171, !tbaa !24
  %t300 = load i64, ptr %l173, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t297, i32 %t298, i64 %t299, i64 %t300, i8 0)
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s29)
  br label %bb84
bb84:
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l174, !tbaa !29
  %t302 = load ptr, ptr %l174, !tbaa !29
  %t303 = getelementptr %"compiler/scan:scanner", ptr %t302, i32 0, i32 5
  store i1 true, ptr %t303, !tbaa !21
  %t304 = load i64, ptr %l3, !tbaa !24
  store i64 %t304, ptr %l175, !tbaa !24
  %t305 = load i64, ptr %l175, !tbaa !24
  %t306 = add i64 %t305, 1
  store i64 %t306, ptr %l176, !tbaa !24
  %t307 = load i64, ptr %l176, !tbaa !24
  store i64 %t307, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s28)
  br label %bb93
bb85:
  %t308 = load i64, ptr %l180, !tbaa !24
  store i64 %t308, ptr %l18, !tbaa !24
  %t309 = load i8, ptr %l12, !tbaa !22
  store i8 %t309, ptr %l181, !tbaa !22
  %t310 = load i8, ptr %l181, !tbaa !22
  %t311 = icmp eq i8 %t310, 0
  store i1 %t311, ptr %l182, !tbaa !21
  %t312 = load i1, ptr %l182, !tbaa !21
  br i1 %t312, label %bb86, label %bb87
bb86:
  store i32 2, ptr %l184
  %t313 = load i32, ptr %l184
  store i32 %t313, ptr %l183
  br label %bb91
bb87:
  %t314 = load i8, ptr %l12, !tbaa !22
  store i8 %t314, ptr %l185, !tbaa !22
  %t315 = load i8, ptr %l185, !tbaa !22
  %t316 = icmp uge i8 %t315, -128
  store i1 %t316, ptr %l186, !tbaa !21
  %t317 = load i1, ptr %l186, !tbaa !21
  br i1 %t317, label %bb88, label %bb89
bb88:
  store i32 1, ptr %l188
  %t318 = load i32, ptr %l188
  store i32 %t318, ptr %l187
  br label %bb90
bb89:
  store i32 0, ptr %l189
  %t319 = load i32, ptr %l189
  store i32 %t319, ptr %l187
  br label %bb90
bb90:
  %t320 = load i32, ptr %l187
  store i32 %t320, ptr %l183
  br label %bb91
bb91:
  %t321 = load i32, ptr %l183
  store i32 %t321, ptr %l19
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l190, !tbaa !29
  %t323 = load i32, ptr %l19
  store i32 %t323, ptr %l191
  %t324 = load i64, ptr %l3, !tbaa !24
  store i64 %t324, ptr %l192, !tbaa !24
  %t325 = load i64, ptr %l18, !tbaa !24
  store i64 %t325, ptr %l193, !tbaa !24
  %t326 = load i8, ptr %l12, !tbaa !22
  store i8 %t326, ptr %l194, !tbaa !22
  %t327 = load ptr, ptr %l190, !tbaa !29
  %t328 = load i32, ptr %l191
  %t329 = load i64, ptr %l192, !tbaa !24
  %t330 = load i64, ptr %l193, !tbaa !24
  %t331 = load i8, ptr %l194, !tbaa !22
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t327, i32 %t328, i64 %t329, i64 %t330, i8 %t331)
  br label %bb92
bb92:
  %t332 = load i64, ptr %l18, !tbaa !24
  store i64 %t332, ptr %l195, !tbaa !24
  %t333 = load i64, ptr %l195, !tbaa !24
  store i64 %t333, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s30)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s27)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s1)
  br label %bb143
bb95:
  call void @__olang_scope_close(ptr %s23)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s21)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s19)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s17)
  br label %bb99
bb99:
  store i8 0, ptr %l20, !tbaa !22
  %t334 = load i1, ptr %l4, !tbaa !21
  store i1 %t334, ptr %l196, !tbaa !21
  %t335 = load i1, ptr %l196, !tbaa !21
  br i1 %t335, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s31
  %t336 = load i8, ptr %l20, !tbaa !22
  store i8 %t336, ptr %l197, !tbaa !22
  %t337 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  store i8 %t337, ptr %l198, !tbaa !22
  %t338 = load i8, ptr %l197, !tbaa !22
  %t339 = load i8, ptr %l198, !tbaa !22
  %t340 = or i8 %t338, %t339
  store i8 %t340, ptr %l199, !tbaa !22
  %t341 = load i8, ptr %l199, !tbaa !22
  store i8 %t341, ptr %l20, !tbaa !22
  call void @__olang_scope_close(ptr %s31)
  br label %bb102
bb101:
  br label %bb102
bb102:
  %t342 = load i64, ptr %l11, !tbaa !24
  store i64 %t342, ptr %l200, !tbaa !24
  %t343 = load i64, ptr %l6, !tbaa !24
  store i64 %t343, ptr %l201, !tbaa !24
  %t344 = load i64, ptr %l200, !tbaa !24
  %t345 = load i64, ptr %l201, !tbaa !24
  %t346 = icmp sgt i64 %t344, %t345
  store i1 %t346, ptr %l202, !tbaa !21
  %t347 = load i1, ptr %l202, !tbaa !21
  br i1 %t347, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s32
  %t348 = load i8, ptr %l20, !tbaa !22
  store i8 %t348, ptr %l203, !tbaa !22
  %t349 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  store i8 %t349, ptr %l204, !tbaa !22
  %t350 = load i8, ptr %l203, !tbaa !22
  %t351 = load i8, ptr %l204, !tbaa !22
  %t352 = or i8 %t350, %t351
  store i8 %t352, ptr %l205, !tbaa !22
  %t353 = load i8, ptr %l205, !tbaa !22
  store i8 %t353, ptr %l20, !tbaa !22
  call void @__olang_scope_close(ptr %s32)
  br label %bb105
bb104:
  br label %bb105
bb105:
  %t354 = load i64, ptr %l11, !tbaa !24
  store i64 %t354, ptr %l206, !tbaa !24
  %t355 = load i64, ptr %l206, !tbaa !24
  %t356 = icmp eq i64 %t355, 0
  store i1 %t356, ptr %l207, !tbaa !21
  %t357 = load i1, ptr %l207, !tbaa !21
  br i1 %t357, label %bb106, label %bb107
bb106:
  store i1 true, ptr %l208, !tbaa !21
  br label %bb108
bb107:
  %t358 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t358, ptr %l209, !tbaa !27
  %t359 = load i64, ptr %l11, !tbaa !24
  store i64 %t359, ptr %l210, !tbaa !24
  %t360 = load i64, ptr %l210, !tbaa !24
  %t361 = sub i64 %t360, 1
  store i64 %t361, ptr %l211, !tbaa !24
  %t362 = load i64, ptr %l211, !tbaa !24
  %t363 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr i8, ptr %t364, i64 %t362
  %t366 = load i8, ptr %t365, !tbaa !32
  store i8 %t366, ptr %l212, !tbaa !22
  %t367 = load i8, ptr %l212, !tbaa !22
  %t368 = icmp eq i8 %t367, 10
  store i1 %t368, ptr %l213, !tbaa !21
  %t369 = load i1, ptr %l213, !tbaa !21
  store i1 %t369, ptr %l208, !tbaa !21
  br label %bb108
bb108:
  %t370 = load i1, ptr %l208, !tbaa !21
  store i1 %t370, ptr %l21, !tbaa !21
  %t371 = load i1, ptr %l21, !tbaa !21
  store i1 %t371, ptr %l214, !tbaa !21
  %t372 = load i1, ptr %l214, !tbaa !21
  br i1 %t372, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s33
  %t373 = load i8, ptr %l20, !tbaa !22
  store i8 %t373, ptr %l215, !tbaa !22
  %t374 = load i8, ptr @G_2ecompiler_2ftoken_2eLineStart, !tbaa !22
  store i8 %t374, ptr %l216, !tbaa !22
  %t375 = load i8, ptr %l215, !tbaa !22
  %t376 = load i8, ptr %l216, !tbaa !22
  %t377 = or i8 %t375, %t376
  store i8 %t377, ptr %l217, !tbaa !22
  %t378 = load i8, ptr %l217, !tbaa !22
  store i8 %t378, ptr %l20, !tbaa !22
  call void @__olang_scope_close(ptr %s33)
  br label %bb111
bb110:
  br label %bb111
bb111:
  %t379 = load i1, ptr %l21, !tbaa !21
  store i1 %t379, ptr %l218, !tbaa !21
  %t380 = load i1, ptr %l218, !tbaa !21
  br i1 %t380, label %bb112, label %bb113
bb112:
  %t381 = load i64, ptr %l11, !tbaa !24
  store i64 %t381, ptr %l220, !tbaa !24
  %t382 = load i64, ptr %l220, !tbaa !24
  %t383 = icmp sgt i64 %t382, 0
  store i1 %t383, ptr %l221, !tbaa !21
  %t384 = load i1, ptr %l221, !tbaa !21
  store i1 %t384, ptr %l219, !tbaa !21
  br label %bb114
bb113:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb114
bb114:
  %t385 = load i1, ptr %l219, !tbaa !21
  br i1 %t385, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s34
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l222, !tbaa !29
  %t387 = load i32, ptr %l13
  store i32 %t387, ptr %l223
  %t388 = load i64, ptr %l14, !tbaa !24
  store i64 %t388, ptr %l224, !tbaa !24
  %t389 = load ptr, ptr %l222, !tbaa !29
  %t390 = load i32, ptr %l223
  %t391 = load i64, ptr %l224, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ecloseBeforeDecl(ptr %v0, ptr %t389, i32 %t390, i64 %t391)
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_scope_close(ptr %s34)
  br label %bb118
bb118:
  %t392 = load i1, ptr %l4, !tbaa !21
  store i1 %t392, ptr %l225, !tbaa !21
  %t393 = load i1, ptr %l225, !tbaa !21
  br i1 %t393, label %bb119, label %bb120
bb119:
  %t394 = load i32, ptr %l5
  store i32 %t394, ptr %l227
  store ptr %l227, ptr %l228, !tbaa !29
  store i32 57, ptr %l229
  store ptr %l229, ptr %l230, !tbaa !29
  %t395 = load ptr, ptr %l228, !tbaa !29
  %t396 = load ptr, ptr %l230, !tbaa !29
  %t397 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t395, ptr %t396)
  store i1 %t397, ptr %l231
  br label %bb121
bb120:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb122
bb121:
  %t398 = load i1, ptr %l231, !tbaa !21
  store i1 %t398, ptr %l226, !tbaa !21
  br label %bb122
bb122:
  %t399 = load i1, ptr %l226, !tbaa !21
  br i1 %t399, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s35
  %t400 = load ptr, ptr %l0, !tbaa !29
  store ptr %t400, ptr %l232, !tbaa !29
  store i32 5, ptr %l233
  %t401 = load i64, ptr %l6, !tbaa !24
  store i64 %t401, ptr %l234, !tbaa !24
  %t402 = load i64, ptr %l234, !tbaa !24
  %t403 = sub i64 %t402, 1
  store i64 %t403, ptr %l235, !tbaa !24
  %t404 = load i64, ptr %l6, !tbaa !24
  store i64 %t404, ptr %l236, !tbaa !24
  %t405 = load ptr, ptr %l232, !tbaa !29
  %t406 = load i32, ptr %l233
  %t407 = load i64, ptr %l235, !tbaa !24
  %t408 = load i64, ptr %l236, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t405, i32 %t406, i64 %t407, i64 %t408, i8 0)
  br label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_scope_close(ptr %s35)
  br label %bb126
bb126:
  %t409 = load i1, ptr %l4, !tbaa !21
  store i1 %t409, ptr %l237, !tbaa !21
  %t410 = load i1, ptr %l237, !tbaa !21
  br i1 %t410, label %bb127, label %bb128
bb127:
  %t411 = load i32, ptr %l5
  store i32 %t411, ptr %l239
  %t412 = load i32, ptr %l239
  %t413 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %t412)
  store i1 %t413, ptr %l240
  br label %bb129
bb128:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb130
bb129:
  %t414 = load i1, ptr %l240, !tbaa !21
  store i1 %t414, ptr %l238, !tbaa !21
  br label %bb130
bb130:
  %t415 = load i1, ptr %l238, !tbaa !21
  br i1 %t415, label %bb131, label %bb132
bb131:
  %t416 = load i32, ptr %l13
  store i32 %t416, ptr %l242
  store ptr %l242, ptr %l243, !tbaa !29
  store i32 13, ptr %l244
  store ptr %l244, ptr %l245, !tbaa !29
  %t417 = load ptr, ptr %l243, !tbaa !29
  %t418 = load ptr, ptr %l245, !tbaa !29
  %t419 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t417, ptr %t418)
  store i1 %t419, ptr %l246
  br label %bb133
bb132:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb134
bb133:
  %t420 = load i1, ptr %l246, !tbaa !21
  %t421 = xor i1 %t420, true
  store i1 %t421, ptr %l247, !tbaa !21
  %t422 = load i1, ptr %l247, !tbaa !21
  store i1 %t422, ptr %l241, !tbaa !21
  br label %bb134
bb134:
  %t423 = load i1, ptr %l241, !tbaa !21
  br i1 %t423, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s36
  %t424 = load ptr, ptr %l0, !tbaa !29
  store ptr %t424, ptr %l248, !tbaa !29
  %t425 = load ptr, ptr %l248, !tbaa !29
  %t426 = getelementptr %"compiler/scan:scanner", ptr %t425, i32 0, i32 1
  store ptr %t426, ptr %l249, !tbaa !29
  store i32 8, ptr %l250
  %t427 = load i64, ptr %l6, !tbaa !24
  store i64 %t427, ptr %l251, !tbaa !24
  %t428 = load i64, ptr %l251, !tbaa !24
  %t429 = trunc i64 %t428 to i32
  store i32 %t429, ptr %l252, !tbaa !23
  %t430 = load i64, ptr %l6, !tbaa !24
  store i64 %t430, ptr %l253, !tbaa !24
  %t431 = load i64, ptr %l253, !tbaa !24
  %t432 = trunc i64 %t431 to i32
  store i32 %t432, ptr %l254, !tbaa !23
  %t433 = load i32, ptr %l250
  %t434 = load i32, ptr %l252, !tbaa !23
  %t435 = load i32, ptr %l254, !tbaa !23
  %t436 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s36, i32 %t433, i8 0, i32 %t434, i32 %t435)
  store %"compiler/token:Token" %t436, ptr %l255
  br label %bb137
bb136:
  br label %bb139
bb137:
  %t437 = load ptr, ptr %l249, !tbaa !29
  %t438 = load %"compiler/token:Token", ptr %l255
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t437, %"compiler/token:Token" %t438)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s36)
  br label %bb139
bb139:
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l256, !tbaa !29
  %t440 = load ptr, ptr %l256, !tbaa !29
  %t441 = getelementptr %"compiler/scan:scanner", ptr %t440, i32 0, i32 1
  store ptr %t441, ptr %l257, !tbaa !29
  %t442 = load i32, ptr %l13
  store i32 %t442, ptr %l258
  %t443 = load i8, ptr %l20, !tbaa !22
  store i8 %t443, ptr %l259, !tbaa !22
  %t444 = load i64, ptr %l11, !tbaa !24
  store i64 %t444, ptr %l260, !tbaa !24
  %t445 = load i64, ptr %l260, !tbaa !24
  %t446 = trunc i64 %t445 to i32
  store i32 %t446, ptr %l261, !tbaa !23
  %t447 = load i64, ptr %l14, !tbaa !24
  store i64 %t447, ptr %l262, !tbaa !24
  %t448 = load i64, ptr %l262, !tbaa !24
  %t449 = trunc i64 %t448 to i32
  store i32 %t449, ptr %l263, !tbaa !23
  %t450 = load i32, ptr %l258
  %t451 = load i8, ptr %l259, !tbaa !22
  %t452 = load i32, ptr %l261, !tbaa !23
  %t453 = load i32, ptr %l263, !tbaa !23
  %t454 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s1, i32 %t450, i8 %t451, i32 %t452, i32 %t453)
  store %"compiler/token:Token" %t454, ptr %l264
  br label %bb140
bb140:
  %t455 = load ptr, ptr %l257, !tbaa !29
  %t456 = load %"compiler/token:Token", ptr %l264
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t455, %"compiler/token:Token" %t456)
  br label %bb141
bb141:
  %t457 = load ptr, ptr %l0, !tbaa !29
  store ptr %t457, ptr %l265, !tbaa !29
  %t458 = load i32, ptr %l13
  store i32 %t458, ptr %l266
  %t459 = load ptr, ptr %l265, !tbaa !29
  %t460 = load i32, ptr %l266
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2etrack(ptr %v0, ptr %t459, i32 %t460)
  br label %bb142
bb142:
  %t461 = load i32, ptr %l13
  store i32 %t461, ptr %l267
  %t462 = load i32, ptr %l267
  store i32 %t462, ptr %l5
  %t463 = load i64, ptr %l14, !tbaa !24
  store i64 %t463, ptr %l268, !tbaa !24
  %t464 = load i64, ptr %l268, !tbaa !24
  store i64 %t464, ptr %l6, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  %t465 = load i64, ptr %l14, !tbaa !24
  store i64 %t465, ptr %l269, !tbaa !24
  %t466 = load i64, ptr %l269, !tbaa !24
  store i64 %t466, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb143
bb143:
  br label %bb1
bb144:
  %t467 = load i32, ptr %l5
  store i32 %t467, ptr %l270
  store ptr %l270, ptr %l271, !tbaa !29
  store i32 57, ptr %l272
  store ptr %l272, ptr %l273, !tbaa !29
  %t468 = load ptr, ptr %l271, !tbaa !29
  %t469 = load ptr, ptr %l273, !tbaa !29
  %t470 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t468, ptr %t469)
  store i1 %t470, ptr %l274
  br label %bb145
bb145:
  %t471 = load i1, ptr %l274, !tbaa !21
  br i1 %t471, label %bb146, label %bb147
bb146:
  store %olang.scope zeroinitializer, ptr %s37
  %t472 = load ptr, ptr %l0, !tbaa !29
  store ptr %t472, ptr %l275, !tbaa !29
  store i32 5, ptr %l276
  %t473 = load i64, ptr %l6, !tbaa !24
  store i64 %t473, ptr %l277, !tbaa !24
  %t474 = load i64, ptr %l277, !tbaa !24
  %t475 = sub i64 %t474, 1
  store i64 %t475, ptr %l278, !tbaa !24
  %t476 = load i64, ptr %l6, !tbaa !24
  store i64 %t476, ptr %l279, !tbaa !24
  %t477 = load ptr, ptr %l275, !tbaa !29
  %t478 = load i32, ptr %l276
  %t479 = load i64, ptr %l278, !tbaa !24
  %t480 = load i64, ptr %l279, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t477, i32 %t478, i64 %t479, i64 %t480, i8 0)
  br label %bb148
bb147:
  br label %bb149
bb148:
  call void @__olang_scope_close(ptr %s37)
  br label %bb149
bb149:
  %t481 = load i32, ptr %l5
  store i32 %t481, ptr %l280
  %t482 = load i32, ptr %l280
  %t483 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %t482)
  store i1 %t483, ptr %l281
  br label %bb150
bb150:
  %t484 = load i1, ptr %l281, !tbaa !21
  br i1 %t484, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s38
  %t485 = load ptr, ptr %l0, !tbaa !29
  store ptr %t485, ptr %l282, !tbaa !29
  %t486 = load ptr, ptr %l282, !tbaa !29
  %t487 = getelementptr %"compiler/scan:scanner", ptr %t486, i32 0, i32 1
  store ptr %t487, ptr %l283, !tbaa !29
  store i32 8, ptr %l284
  %t488 = load i64, ptr %l6, !tbaa !24
  store i64 %t488, ptr %l285, !tbaa !24
  %t489 = load i64, ptr %l285, !tbaa !24
  %t490 = trunc i64 %t489 to i32
  store i32 %t490, ptr %l286, !tbaa !23
  %t491 = load i64, ptr %l6, !tbaa !24
  store i64 %t491, ptr %l287, !tbaa !24
  %t492 = load i64, ptr %l287, !tbaa !24
  %t493 = trunc i64 %t492 to i32
  store i32 %t493, ptr %l288, !tbaa !23
  %t494 = load i32, ptr %l284
  %t495 = load i32, ptr %l286, !tbaa !23
  %t496 = load i32, ptr %l288, !tbaa !23
  %t497 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s38, i32 %t494, i8 0, i32 %t495, i32 %t496)
  store %"compiler/token:Token" %t497, ptr %l289
  br label %bb153
bb152:
  br label %bb155
bb153:
  %t498 = load ptr, ptr %l283, !tbaa !29
  %t499 = load %"compiler/token:Token", ptr %l289
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t498, %"compiler/token:Token" %t499)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s38)
  br label %bb155
bb155:
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l290, !tbaa !29
  %t501 = load ptr, ptr %l290, !tbaa !29
  %t502 = getelementptr %"compiler/scan:scanner", ptr %t501, i32 0, i32 1
  store ptr %t502, ptr %l291, !tbaa !29
  store i32 0, ptr %l292
  %t503 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  store i8 %t503, ptr %l293, !tbaa !22
  %t504 = load i64, ptr %l2, !tbaa !24
  store i64 %t504, ptr %l294, !tbaa !24
  %t505 = load i64, ptr %l294, !tbaa !24
  %t506 = trunc i64 %t505 to i32
  store i32 %t506, ptr %l295, !tbaa !23
  %t507 = load i64, ptr %l2, !tbaa !24
  store i64 %t507, ptr %l296, !tbaa !24
  %t508 = load i64, ptr %l296, !tbaa !24
  %t509 = trunc i64 %t508 to i32
  store i32 %t509, ptr %l297, !tbaa !23
  %t510 = load i32, ptr %l292
  %t511 = load i8, ptr %l293, !tbaa !22
  %t512 = load i32, ptr %l295, !tbaa !23
  %t513 = load i32, ptr %l297, !tbaa !23
  %t514 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s0, i32 %t510, i8 %t511, i32 %t512, i32 %t513)
  store %"compiler/token:Token" %t514, ptr %l298
  br label %bb156
bb156:
  %t515 = load ptr, ptr %l291, !tbaa !29
  %t516 = load %"compiler/token:Token", ptr %l298
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t515, %"compiler/token:Token" %t516)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2estr(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca i8
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i8
  %l24 = alloca i8
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i8
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i8
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i8
  %l50 = alloca i8
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i8
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i8
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t5, ptr %l2, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l9, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l10, !tbaa !24
  %t9 = load i64, ptr %l10, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l11, !tbaa !24
  %t11 = load i64, ptr %l11, !tbaa !24
  %t12 = add i64 %t11, 1
  store i64 %t12, ptr %l12, !tbaa !24
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %l13, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l14, !tbaa !24
  %t16 = load i64, ptr %l13, !tbaa !24
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l15, !tbaa !21
  %t19 = load i1, ptr %l15, !tbaa !21
  br i1 %t19, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  store i32 7, ptr %l17
  %t21 = load i64, ptr %l1, !tbaa !24
  store i64 %t21, ptr %l18, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l19, !tbaa !24
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i32, ptr %l17
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t23, i32 %t24, i64 %t25, i64 %t26, i8 0)
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i64, ptr %l20, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
bb5:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l21, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  store i64 %t30, ptr %l22, !tbaa !24
  %t31 = load i64, ptr %l22, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t31
  %t35 = load i8, ptr %t34, !tbaa !32
  store i8 %t35, ptr %l23, !tbaa !22
  %t36 = load i8, ptr %l23, !tbaa !22
  store i8 %t36, ptr %l5, !tbaa !22
  %t37 = load i8, ptr %l5, !tbaa !22
  store i8 %t37, ptr %l24, !tbaa !22
  %t38 = load i8, ptr %l24, !tbaa !22
  %t39 = icmp eq i8 %t38, 34
  store i1 %t39, ptr %l25, !tbaa !21
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load i64, ptr %l4, !tbaa !24
  store i64 %t41, ptr %l26, !tbaa !24
  %t42 = load i64, ptr %l26, !tbaa !24
  %t43 = add i64 %t42, 1
  store i64 %t43, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t44 = load i64, ptr %l27, !tbaa !24
  store i64 %t44, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t45 = load i8, ptr %l5, !tbaa !22
  store i8 %t45, ptr %l28, !tbaa !22
  %t46 = load i8, ptr %l28, !tbaa !22
  %t47 = icmp eq i8 %t46, 10
  store i1 %t47, ptr %l29, !tbaa !21
  %t48 = load i1, ptr %l29, !tbaa !21
  br i1 %t48, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  store i32 8, ptr %l31
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l33, !tbaa !24
  %t52 = load ptr, ptr %l30, !tbaa !29
  %t53 = load i32, ptr %l31
  %t54 = load i64, ptr %l32, !tbaa !24
  %t55 = load i64, ptr %l33, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t52, i32 %t53, i64 %t54, i64 %t55, i8 0)
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t56 = load i64, ptr %l4, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %rv
  br label %ret
bb12:
  %t58 = load i8, ptr %l5, !tbaa !22
  store i8 %t58, ptr %l35, !tbaa !22
  %t59 = load i8, ptr %l35, !tbaa !22
  %t60 = icmp eq i8 %t59, 92
  store i1 %t60, ptr %l36, !tbaa !21
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t62 = load i64, ptr %l4, !tbaa !24
  store i64 %t62, ptr %l37, !tbaa !24
  %t63 = load i64, ptr %l37, !tbaa !24
  %t64 = add i64 %t63, 1
  store i64 %t64, ptr %l38, !tbaa !24
  %t65 = load i64, ptr %l3, !tbaa !24
  store i64 %t65, ptr %l39, !tbaa !24
  %t66 = load i64, ptr %l38, !tbaa !24
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = icmp sge i64 %t66, %t67
  store i1 %t68, ptr %l40, !tbaa !21
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s9
  %t70 = load i64, ptr %l4, !tbaa !24
  store i64 %t70, ptr %l70, !tbaa !24
  %t71 = load i64, ptr %l70, !tbaa !24
  %t72 = add i64 %t71, 1
  store i64 %t72, ptr %l71, !tbaa !24
  %t73 = load i64, ptr %l71, !tbaa !24
  store i64 %t73, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l41, !tbaa !29
  store i32 7, ptr %l42
  %t75 = load i64, ptr %l1, !tbaa !24
  store i64 %t75, ptr %l43, !tbaa !24
  %t76 = load i64, ptr %l3, !tbaa !24
  store i64 %t76, ptr %l44, !tbaa !24
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = load i32, ptr %l42
  %t79 = load i64, ptr %l43, !tbaa !24
  %t80 = load i64, ptr %l44, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t77, i32 %t78, i64 %t79, i64 %t80, i8 0)
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t81 = load i64, ptr %l3, !tbaa !24
  store i64 %t81, ptr %l45, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t82 = load i64, ptr %l45, !tbaa !24
  store i64 %t82, ptr %rv
  br label %ret
bb18:
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t83, ptr %l46, !tbaa !27
  %t84 = load i64, ptr %l4, !tbaa !24
  store i64 %t84, ptr %l47, !tbaa !24
  %t85 = load i64, ptr %l47, !tbaa !24
  %t86 = add i64 %t85, 1
  store i64 %t86, ptr %l48, !tbaa !24
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 %t87
  %t91 = load i8, ptr %t90, !tbaa !32
  store i8 %t91, ptr %l49, !tbaa !22
  %t92 = load i8, ptr %l49, !tbaa !22
  store i8 %t92, ptr %l6, !tbaa !22
  %t93 = load i8, ptr %l6, !tbaa !22
  store i8 %t93, ptr %l50, !tbaa !22
  %t94 = load i8, ptr %l50, !tbaa !22
  %t95 = icmp eq i8 %t94, 10
  store i1 %t95, ptr %l51, !tbaa !21
  %t96 = load i1, ptr %l51, !tbaa !21
  br i1 %t96, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s7
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l52, !tbaa !29
  store i32 8, ptr %l53
  %t98 = load i64, ptr %l1, !tbaa !24
  store i64 %t98, ptr %l54, !tbaa !24
  %t99 = load i64, ptr %l4, !tbaa !24
  store i64 %t99, ptr %l55, !tbaa !24
  %t100 = load i64, ptr %l55, !tbaa !24
  %t101 = add i64 %t100, 1
  store i64 %t101, ptr %l56, !tbaa !24
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t103 = load i32, ptr %l53
  %t104 = load i64, ptr %l54, !tbaa !24
  %t105 = load i64, ptr %l56, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t102, i32 %t103, i64 %t104, i64 %t105, i8 0)
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t106 = load i64, ptr %l4, !tbaa !24
  store i64 %t106, ptr %l57, !tbaa !24
  %t107 = load i64, ptr %l57, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l58, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t109 = load i64, ptr %l58, !tbaa !24
  store i64 %t109, ptr %rv
  br label %ret
bb22:
  %t110 = load i8, ptr %l6, !tbaa !22
  store i8 %t110, ptr %l59, !tbaa !22
  %t111 = load i8, ptr %l59, !tbaa !22
  %t112 = call i1 @compiler_2fscan_2eescapeOk(i8 %t111, i8 34)
  store i1 %t112, ptr %l60
  br label %bb23
bb23:
  %t113 = load i1, ptr %l60, !tbaa !21
  %t114 = xor i1 %t113, true
  store i1 %t114, ptr %l61, !tbaa !21
  %t115 = load i1, ptr %l61, !tbaa !21
  br i1 %t115, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s8
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l62, !tbaa !29
  store i32 13, ptr %l63
  %t117 = load i64, ptr %l4, !tbaa !24
  store i64 %t117, ptr %l64, !tbaa !24
  %t118 = load i64, ptr %l4, !tbaa !24
  store i64 %t118, ptr %l65, !tbaa !24
  %t119 = load i64, ptr %l65, !tbaa !24
  %t120 = add i64 %t119, 2
  store i64 %t120, ptr %l66, !tbaa !24
  %t121 = load i8, ptr %l6, !tbaa !22
  store i8 %t121, ptr %l67, !tbaa !22
  %t122 = load ptr, ptr %l62, !tbaa !29
  %t123 = load i32, ptr %l63
  %t124 = load i64, ptr %l64, !tbaa !24
  %t125 = load i64, ptr %l66, !tbaa !24
  %t126 = load i8, ptr %l67, !tbaa !22
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t122, i32 %t123, i64 %t124, i64 %t125, i8 %t126)
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s8)
  br label %bb27
bb27:
  %t127 = load i64, ptr %l4, !tbaa !24
  store i64 %t127, ptr %l68, !tbaa !24
  %t128 = load i64, ptr %l68, !tbaa !24
  %t129 = add i64 %t128, 2
  store i64 %t129, ptr %l69, !tbaa !24
  %t130 = load i64, ptr %l69, !tbaa !24
  store i64 %t130, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s1)
  br label %bb29
bb29:
  br label %bb1
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2etrack(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i8
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i8
  %l41 = alloca i8
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i8
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i8
  %l58 = alloca i32
  %l59 = alloca i8
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1
  store i32 %t1, ptr %l5
  %t2 = load i32, ptr %l5
  %t3 = trunc i64 90 to i32
  %t4 = icmp eq i32 %t2, %t3
  store i1 %t4, ptr %l6, !tbaa !21
  %t5 = load i1, ptr %l6, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = getelementptr %"compiler/scan:scanner", ptr %t7, i32 0, i32 3
  store ptr %t8, ptr %l8, !tbaa !29
  %t9 = load ptr, ptr %l8, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H849b787d6464fd61c7b36d59bd222081(ptr %v0, ptr %t9, i8 40)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb53
bb5:
  %t10 = load i32, ptr %l1
  store i32 %t10, ptr %l9
  %t11 = load i32, ptr %l9
  %t12 = trunc i64 92 to i32
  %t13 = icmp eq i32 %t11, %t12
  store i1 %t13, ptr %l10, !tbaa !21
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = getelementptr %"compiler/scan:scanner", ptr %t16, i32 0, i32 3
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H849b787d6464fd61c7b36d59bd222081(ptr %v0, ptr %t18, i8 91)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb10:
  %t19 = load i32, ptr %l1
  store i32 %t19, ptr %l13
  %t20 = load i32, ptr %l13
  %t21 = trunc i64 94 to i32
  %t22 = icmp eq i32 %t20, %t21
  store i1 %t22, ptr %l14, !tbaa !21
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb15
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l15, !tbaa !29
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = getelementptr %"compiler/scan:scanner", ptr %t25, i32 0, i32 3
  store ptr %t26, ptr %l16, !tbaa !29
  %t27 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H849b787d6464fd61c7b36d59bd222081(ptr %v0, ptr %t27, i8 123)
  br label %bb14
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l17, !tbaa !29
  %t30 = getelementptr %"compiler/scan:scanner", ptr %t29, i32 0, i32 4
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = add i64 %t32, 1
  store i64 %t33, ptr %l19, !tbaa !24
  %t34 = load i64, ptr %l19, !tbaa !24
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = getelementptr %"compiler/scan:scanner", ptr %t35, i32 0, i32 4
  store i64 %t34, ptr %t36, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb53
bb15:
  %t37 = load i32, ptr %l1
  store i32 %t37, ptr %l20
  %t38 = load i32, ptr %l20
  %t39 = trunc i64 91 to i32
  %t40 = icmp eq i32 %t38, %t39
  store i1 %t40, ptr %l21, !tbaa !21
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  %t42 = load i32, ptr %l1
  store i32 %t42, ptr %l22
  %t43 = load i32, ptr %l22
  %t44 = trunc i64 93 to i32
  %t45 = icmp eq i32 %t43, %t44
  store i1 %t45, ptr %l23, !tbaa !21
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb34
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l24, !tbaa !29
  %t48 = load ptr, ptr %l24, !tbaa !29
  %t49 = getelementptr %"compiler/scan:scanner", ptr %t48, i32 0, i32 3
  store ptr %t49, ptr %l25, !tbaa !29
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eLe_H123f33f8ddaac384b8a67c2466e49838(ptr %v0, ptr %t50)
  store i64 %t51, ptr %l26
  br label %bb21
bb21:
  %t52 = load i64, ptr %l26, !tbaa !24
  store i64 %t52, ptr %l2, !tbaa !24
  %t53 = load i32, ptr %l1
  store i32 %t53, ptr %l27
  store ptr %l27, ptr %l28, !tbaa !29
  store i32 91, ptr %l29
  store ptr %l29, ptr %l30, !tbaa !29
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load ptr, ptr %l30, !tbaa !29
  %t56 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t54, ptr %t55)
  store i1 %t56, ptr %l31
  br label %bb22
bb22:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb23, label %bb24
bb23:
  store i8 40, ptr %l32, !tbaa !22
  br label %bb25
bb24:
  store i8 91, ptr %l32, !tbaa !22
  br label %bb25
bb25:
  %t58 = load i8, ptr %l32, !tbaa !22
  store i8 %t58, ptr %l3, !tbaa !22
  %t59 = load i64, ptr %l2, !tbaa !24
  store i64 %t59, ptr %l33, !tbaa !24
  %t60 = load i64, ptr %l33, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  store i1 %t61, ptr %l34, !tbaa !21
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb26, label %bb27
bb26:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l36, !tbaa !29
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = getelementptr %"compiler/scan:scanner", ptr %t64, i32 0, i32 3
  store ptr %t65, ptr %l37, !tbaa !29
  %t66 = load i64, ptr %l2, !tbaa !24
  store i64 %t66, ptr %l38, !tbaa !24
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = sub i64 %t67, 1
  store i64 %t68, ptr %l39, !tbaa !24
  %t69 = load ptr, ptr %l37, !tbaa !29
  %t70 = load i64, ptr %l39, !tbaa !24
  %t71 = call i8 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eAt_Hf7c9ea4b95413b3e180a7d1bf48077d2(ptr %v0, ptr %t69, i64 %t70)
  store i8 %t71, ptr %l40
  br label %bb28
bb27:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb29
bb28:
  %t72 = load i8, ptr %l3, !tbaa !22
  store i8 %t72, ptr %l41, !tbaa !22
  %t73 = load i8, ptr %l40, !tbaa !22
  %t74 = load i8, ptr %l41, !tbaa !22
  %t75 = icmp eq i8 %t73, %t74
  store i1 %t75, ptr %l42, !tbaa !21
  %t76 = load i1, ptr %l42, !tbaa !21
  store i1 %t76, ptr %l35, !tbaa !21
  br label %bb29
bb29:
  %t77 = load i1, ptr %l35, !tbaa !21
  br i1 %t77, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l43, !tbaa !29
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = getelementptr %"compiler/scan:scanner", ptr %t79, i32 0, i32 3
  store ptr %t80, ptr %l44, !tbaa !29
  %t81 = load i64, ptr %l2, !tbaa !24
  store i64 %t81, ptr %l45, !tbaa !24
  %t82 = load i64, ptr %l45, !tbaa !24
  %t83 = sub i64 %t82, 1
  store i64 %t83, ptr %l46, !tbaa !24
  %t84 = load ptr, ptr %l44, !tbaa !29
  %t85 = load i64, ptr %l46, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eTr_Hab73bf4217594c1b2a8b440aaf66708e(ptr %v0, ptr %t84, i64 %t85)
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb53
bb34:
  %t86 = load i32, ptr %l1
  store i32 %t86, ptr %l47
  %t87 = load i32, ptr %l47
  %t88 = trunc i64 95 to i32
  %t89 = icmp eq i32 %t87, %t88
  store i1 %t89, ptr %l48, !tbaa !21
  %t90 = load i1, ptr %l48, !tbaa !21
  br i1 %t90, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb52
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l49, !tbaa !29
  %t92 = load ptr, ptr %l49, !tbaa !29
  %t93 = getelementptr %"compiler/scan:scanner", ptr %t92, i32 0, i32 3
  store ptr %t93, ptr %l50, !tbaa !29
  %t94 = load ptr, ptr %l50, !tbaa !29
  %t95 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eLe_H123f33f8ddaac384b8a67c2466e49838(ptr %v0, ptr %t94)
  store i64 %t95, ptr %l51
  br label %bb39
bb39:
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = icmp sgt i64 %t96, 0
  store i1 %t97, ptr %l52, !tbaa !21
  %t98 = load i1, ptr %l52, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l53, !tbaa !21
  %t100 = load i1, ptr %l53, !tbaa !21
  br i1 %t100, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb41:
  br label %bb42
bb42:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l55, !tbaa !29
  %t102 = load ptr, ptr %l55, !tbaa !29
  %t103 = getelementptr %"compiler/scan:scanner", ptr %t102, i32 0, i32 3
  store ptr %t103, ptr %l56, !tbaa !29
  %t104 = load ptr, ptr %l56, !tbaa !29
  %t105 = call { i32, i8 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePo_H4d205b82f6a792bc14020f9f8d3dea15(ptr %v0, ptr %t104)
  %t106 = extractvalue { i32, i8 } %t105, 1
  %t107 = extractvalue { i32, i8 } %t105, 0
  store i32 %t107, ptr %l58
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb44, label %ok.109
ok.109:
  store i8 %t106, ptr %l57
  br label %bb43
bb43:
  %t110 = load i8, ptr %l57, !tbaa !22
  store i8 %t110, ptr %l54, !tbaa !22
  br label %bb46
bb44:
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb46:
  %t111 = load i8, ptr %l54, !tbaa !22
  store i8 %t111, ptr %l4, !tbaa !22
  %t112 = load i8, ptr %l4, !tbaa !22
  store i8 %t112, ptr %l59, !tbaa !22
  %t113 = load i8, ptr %l59, !tbaa !22
  %t114 = icmp eq i8 %t113, 123
  store i1 %t114, ptr %l60, !tbaa !21
  %t115 = load i1, ptr %l60, !tbaa !21
  br i1 %t115, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s9
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l61, !tbaa !29
  %t117 = load ptr, ptr %l61, !tbaa !29
  %t118 = getelementptr %"compiler/scan:scanner", ptr %t117, i32 0, i32 4
  %t119 = load i64, ptr %t118, !tbaa !24
  store i64 %t119, ptr %l62, !tbaa !24
  %t120 = load i64, ptr %l62, !tbaa !24
  %t121 = sub i64 %t120, 1
  store i64 %t121, ptr %l63, !tbaa !24
  %t122 = load i64, ptr %l63, !tbaa !24
  %t123 = load ptr, ptr %l61, !tbaa !29
  %t124 = getelementptr %"compiler/scan:scanner", ptr %t123, i32 0, i32 4
  store i64 %t122, ptr %t124, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb50:
  br label %bb38
bb51:
  call void @__olang_scope_close(ptr %s6)
  br label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  call void @__olang_scope_close(ptr %s10)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscan_2edigitOf(i8 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i8
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i8
  %l12 = alloca i1
  %l13 = alloca i8
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp eq i64 %t2, 16
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = call i1 @compiler_2fscan_2eisHexDigit(i8 %t6)
  store i1 %t7, ptr %l5
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
bb4:
  %t9 = load i64, ptr %l1, !tbaa !24
  store i64 %t9, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp eq i64 %t10, 2
  store i1 %t11, ptr %l7, !tbaa !21
  %t12 = load i1, ptr %l7, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i8, ptr %l0, !tbaa !22
  store i8 %t13, ptr %l8, !tbaa !22
  %t14 = load i8, ptr %l8, !tbaa !22
  %t15 = icmp eq i8 %t14, 48
  store i1 %t15, ptr %l9, !tbaa !21
  %t16 = load i1, ptr %l9, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb6:
  br label %bb10
bb7:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb9
bb8:
  %t17 = load i8, ptr %l0, !tbaa !22
  store i8 %t17, ptr %l11, !tbaa !22
  %t18 = load i8, ptr %l11, !tbaa !22
  %t19 = icmp eq i8 %t18, 49
  store i1 %t19, ptr %l12, !tbaa !21
  %t20 = load i1, ptr %l12, !tbaa !21
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i1, ptr %l10, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb10:
  %t22 = load i8, ptr %l0, !tbaa !22
  store i8 %t22, ptr %l13, !tbaa !22
  %t23 = load i8, ptr %l13, !tbaa !22
  %t24 = call i1 @compiler_2fscan_2eisDigit(i8 %t23)
  store i1 %t24, ptr %l14
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i1, ptr %l14, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eescapeOk(i8 %a0, i8 %a1) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i8
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i8
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i8
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i8
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i8
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i8
  %l18 = alloca i8
  %l19 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l2, !tbaa !22
  %t2 = load i8, ptr %l2, !tbaa !22
  %t3 = icmp eq i8 %t2, 110
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l5, !tbaa !22
  %t6 = load i8, ptr %l5, !tbaa !22
  %t7 = icmp eq i8 %t6, 116
  store i1 %t7, ptr %l6, !tbaa !21
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb6
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  store i8 %t10, ptr %l8, !tbaa !22
  %t11 = load i8, ptr %l8, !tbaa !22
  %t12 = icmp eq i8 %t11, 114
  store i1 %t12, ptr %l9, !tbaa !21
  %t13 = load i1, ptr %l9, !tbaa !21
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb9
bb8:
  %t15 = load i8, ptr %l0, !tbaa !22
  store i8 %t15, ptr %l11, !tbaa !22
  %t16 = load i8, ptr %l11, !tbaa !22
  %t17 = icmp eq i8 %t16, 48
  store i1 %t17, ptr %l12, !tbaa !21
  %t18 = load i1, ptr %l12, !tbaa !21
  store i1 %t18, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb12
bb11:
  %t20 = load i8, ptr %l0, !tbaa !22
  store i8 %t20, ptr %l14, !tbaa !22
  %t21 = load i8, ptr %l14, !tbaa !22
  %t22 = icmp eq i8 %t21, 92
  store i1 %t22, ptr %l15, !tbaa !21
  %t23 = load i1, ptr %l15, !tbaa !21
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb15
bb14:
  %t25 = load i8, ptr %l0, !tbaa !22
  store i8 %t25, ptr %l17, !tbaa !22
  %t26 = load i8, ptr %l1, !tbaa !22
  store i8 %t26, ptr %l18, !tbaa !22
  %t27 = load i8, ptr %l17, !tbaa !22
  %t28 = load i8, ptr %l18, !tbaa !22
  %t29 = icmp eq i8 %t27, %t28
  store i1 %t29, ptr %l19, !tbaa !21
  %t30 = load i1, ptr %l19, !tbaa !21
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load i1, ptr %l16, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eexponentDigits(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i8
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i8
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i8
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l9, !tbaa !21
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l12, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t15
  %t19 = load i8, ptr %t18, !tbaa !32
  store i8 %t19, ptr %l13, !tbaa !22
  %t20 = load i8, ptr %l13, !tbaa !22
  %t21 = call i1 @compiler_2fscan_2eisDigit(i8 %t20)
  store i1 %t21, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb4:
  %t22 = load i1, ptr %l14, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  store i64 %t24, ptr %l17, !tbaa !24
  %t25 = load i64, ptr %l17, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t25
  %t29 = load i8, ptr %t28, !tbaa !32
  store i8 %t29, ptr %l18, !tbaa !22
  %t30 = load i8, ptr %l18, !tbaa !22
  %t31 = icmp eq i8 %t30, 95
  store i1 %t31, ptr %l19, !tbaa !21
  %t32 = load i1, ptr %l19, !tbaa !21
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l15, !tbaa !21
  store i1 %t33, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l10, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l20, !tbaa !21
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %l22, !tbaa !24
  %t39 = load i64, ptr %l22, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i8, ptr %t41, i64 %t39
  %t43 = load i8, ptr %t42, !tbaa !32
  store i8 %t43, ptr %l23, !tbaa !22
  %t44 = load i8, ptr %l23, !tbaa !22
  %t45 = call i1 @compiler_2fscan_2eisDigit(i8 %t44)
  store i1 %t45, ptr %l24
  br label %bb12
bb12:
  %t46 = load i1, ptr %l24, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 true, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t47 = load i1, ptr %l25, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t48 = load i64, ptr %l2, !tbaa !24
  store i64 %t48, ptr %l26, !tbaa !24
  %t49 = load i64, ptr %l26, !tbaa !24
  %t50 = add i64 %t49, 1
  store i64 %t50, ptr %l27, !tbaa !24
  %t51 = load i64, ptr %l27, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  br label %bb1
bb17:
  store i1 false, ptr %l28, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t52 = load i1, ptr %l28, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2efractionAt(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i8
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i8
  %l28 = alloca i1
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t2, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sge i64 %t5, %t6
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t11
  %t15 = load i8, ptr %t14, !tbaa !32
  store i8 %t15, ptr %l9, !tbaa !22
  %t16 = load i8, ptr %l9, !tbaa !22
  %t17 = icmp ne i8 %t16, 46
  store i1 %t17, ptr %l10, !tbaa !21
  %t18 = load i1, ptr %l10, !tbaa !21
  store i1 %t18, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l6, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l11, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i1, ptr %l11, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load i64, ptr %l1, !tbaa !24
  store i64 %t21, ptr %l12, !tbaa !24
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = add i64 %t22, 1
  store i64 %t23, ptr %l13, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t24, ptr %l14, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l15, !tbaa !24
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = load i64, ptr %l15, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l16, !tbaa !21
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t32 = load i64, ptr %l1, !tbaa !24
  store i64 %t32, ptr %l19, !tbaa !24
  %t33 = load i64, ptr %l19, !tbaa !24
  %t34 = add i64 %t33, 1
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i8, ptr %t37, i64 %t35
  %t39 = load i8, ptr %t38, !tbaa !32
  store i8 %t39, ptr %l21, !tbaa !22
  %t40 = load i8, ptr %l21, !tbaa !22
  %t41 = call i1 @compiler_2fscan_2eisLetter(i8 %t40)
  store i1 %t41, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb13
bb9:
  %t42 = load i1, ptr %l22, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t43, ptr %l24, !tbaa !27
  %t44 = load i64, ptr %l1, !tbaa !24
  store i64 %t44, ptr %l25, !tbaa !24
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = add i64 %t45, 1
  store i64 %t46, ptr %l26, !tbaa !24
  %t47 = load i64, ptr %l26, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i8, ptr %t49, i64 %t47
  %t51 = load i8, ptr %t50, !tbaa !32
  store i8 %t51, ptr %l27, !tbaa !22
  %t52 = load i8, ptr %l27, !tbaa !22
  %t53 = icmp eq i8 %t52, 95
  store i1 %t53, ptr %l28, !tbaa !21
  %t54 = load i1, ptr %l28, !tbaa !21
  store i1 %t54, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t55 = load i1, ptr %l23, !tbaa !21
  store i1 %t55, ptr %l17, !tbaa !21
  br label %bb13
bb13:
  %t56 = load i1, ptr %l17, !tbaa !21
  %t57 = xor i1 %t56, true
  store i1 %t57, ptr %l29, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i1, ptr %l29, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eisDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp uge i8 %t2, 48
  store i1 %t3, ptr %l2, !tbaa !21
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = icmp ule i8 %t6, 57
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l3, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eisHexDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i8
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i8
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i8
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = call i1 @compiler_2fscan_2eisDigit(i8 %t2)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb7
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = icmp uge i8 %t6, 97
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t9 = load i8, ptr %l0, !tbaa !22
  store i8 %t9, ptr %l7, !tbaa !22
  %t10 = load i8, ptr %l7, !tbaa !22
  %t11 = icmp ule i8 %t10, 102
  store i1 %t11, ptr %l8, !tbaa !21
  %t12 = load i1, ptr %l8, !tbaa !21
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t13 = load i1, ptr %l6, !tbaa !21
  store i1 %t13, ptr %l3, !tbaa !21
  br label %bb7
bb7:
  %t14 = load i1, ptr %l3, !tbaa !21
  br i1 %t14, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb9:
  %t15 = load i8, ptr %l0, !tbaa !22
  store i8 %t15, ptr %l10, !tbaa !22
  %t16 = load i8, ptr %l10, !tbaa !22
  %t17 = icmp uge i8 %t16, 65
  store i1 %t17, ptr %l11, !tbaa !21
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb10, label %bb11
bb10:
  %t19 = load i8, ptr %l0, !tbaa !22
  store i8 %t19, ptr %l13, !tbaa !22
  %t20 = load i8, ptr %l13, !tbaa !22
  %t21 = icmp ule i8 %t20, 70
  store i1 %t21, ptr %l14, !tbaa !21
  %t22 = load i1, ptr %l14, !tbaa !21
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t23 = load i1, ptr %l12, !tbaa !21
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i1, ptr %l9, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eisLetter(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i8
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i8
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp uge i8 %t2, 97
  store i1 %t3, ptr %l2, !tbaa !21
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = icmp ule i8 %t6, 122
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  store i8 %t10, ptr %l7, !tbaa !22
  %t11 = load i8, ptr %l7, !tbaa !22
  %t12 = icmp uge i8 %t11, 65
  store i1 %t12, ptr %l8, !tbaa !21
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load i8, ptr %l0, !tbaa !22
  store i8 %t14, ptr %l10, !tbaa !22
  %t15 = load i8, ptr %l10, !tbaa !22
  %t16 = icmp ule i8 %t15, 90
  store i1 %t16, ptr %l11, !tbaa !21
  %t17 = load i1, ptr %l11, !tbaa !21
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i1, ptr %l6, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eisWordChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i8
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = call i1 @compiler_2fscan_2eisLetter(i8 %t2)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = call i1 @compiler_2fscan_2eisDigit(i8 %t6)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  store i8 %t10, ptr %l7, !tbaa !22
  %t11 = load i8, ptr %l7, !tbaa !22
  %t12 = icmp eq i8 %t11, 95
  store i1 %t12, ptr %l8, !tbaa !21
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i1, ptr %l6, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscan_2ejunkEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i8
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l9, !tbaa !21
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l12, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t15
  %t19 = load i8, ptr %t18, !tbaa !32
  store i8 %t19, ptr %l13, !tbaa !22
  %t20 = load i8, ptr %l13, !tbaa !22
  %t21 = icmp ne i8 %t20, 13
  store i1 %t21, ptr %l14, !tbaa !21
  %t22 = load i1, ptr %l14, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t24, ptr %l16, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  store i64 %t25, ptr %l17, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = call i1 @compiler_2fscan_2ecanStart(ptr %v0, { i64, ptr } %t26, i64 %t27)
  store i1 %t28, ptr %l18
  br label %bb7
bb6:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  %t29 = load i1, ptr %l18, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l19, !tbaa !21
  %t31 = load i1, ptr %l19, !tbaa !21
  store i1 %t31, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l15, !tbaa !21
  %t33 = xor i1 %t32, true
  store i1 %t33, ptr %l20, !tbaa !21
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l21, !tbaa !24
  %t36 = load i64, ptr %l21, !tbaa !24
  %t37 = add i64 %t36, 1
  store i64 %t37, ptr %l22, !tbaa !24
  %t38 = load i64, ptr %l22, !tbaa !24
  store i64 %t38, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  br label %bb1
bb13:
  %t39 = load i64, ptr %l2, !tbaa !24
  store i64 %t39, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i64, ptr %l23, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscan_2elineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i8
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l9, !tbaa !21
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l12, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t15
  %t19 = load i8, ptr %t18, !tbaa !32
  store i8 %t19, ptr %l13, !tbaa !22
  %t20 = load i8, ptr %l13, !tbaa !22
  %t21 = icmp ne i8 %t20, 10
  store i1 %t21, ptr %l14, !tbaa !21
  %t22 = load i1, ptr %l14, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l10, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l15, !tbaa !21
  %t25 = load i1, ptr %l15, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t30 = load i64, ptr %l2, !tbaa !24
  store i64 %t30, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscan_2ematchBraces(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/list:List<I64>"
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/token:Token"
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/list:List<I64>"
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca %"compiler/token:Token"
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %l49 = alloca i64
  %l50 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s0)
  store %"std/prelude/list:List<I64>" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List<I64>", ptr %l11
  store %"std/prelude/list:List<I64>" %t2, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l12, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t5, ptr %l13, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l14, !tbaa !24
  %t8 = load i64, ptr %l14, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l7, !tbaa !24
  store i64 %t10, ptr %l16, !tbaa !24
  %t11 = load i64, ptr %l15, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l17, !tbaa !21
  %t14 = load i1, ptr %l17, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l18, !tbaa !21
  %t16 = load i1, ptr %l18, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l6, !tbaa !24
  store i64 %t17, ptr %l19, !tbaa !24
  %t18 = load i64, ptr %l19, !tbaa !24
  store i64 %t18, ptr %l8, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t19, ptr %l20, !tbaa !27
  %t20 = load i64, ptr %l6, !tbaa !24
  store i64 %t20, ptr %l21, !tbaa !24
  %t21 = load i64, ptr %l21, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr %"compiler/token:Token", ptr %t23, i64 %t21
  %t25 = load %"compiler/token:Token", ptr %t24
  store %"compiler/token:Token" %t25, ptr %l22
  %t26 = load %"compiler/token:Token", ptr %l22
  store %"compiler/token:Token" %t26, ptr %l9
  %t27 = getelementptr %"compiler/token:Token", ptr %l9, i32 0, i32 0
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l23
  store ptr %l23, ptr %l24, !tbaa !29
  store i32 94, ptr %l25
  store ptr %l25, ptr %l26, !tbaa !29
  %t29 = load ptr, ptr %l24, !tbaa !29
  %t30 = load ptr, ptr %l26, !tbaa !29
  %t31 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t29, ptr %t30)
  store i1 %t31, ptr %l27
  br label %bb6
bb6:
  %t32 = load i1, ptr %l27, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t33, ptr %l28, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l29, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  store i64 %t35, ptr %l30, !tbaa !24
  %t36 = load i64, ptr %l30, !tbaa !24
  %t37 = trunc i64 %t36 to i32
  store i32 %t37, ptr %l31, !tbaa !23
  %t38 = load i32, ptr %l31, !tbaa !23
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 %t39
  store i32 %t38, ptr %t42, !tbaa !33
  store ptr %l3, ptr %l32, !tbaa !29
  %t43 = load i64, ptr %l4, !tbaa !24
  store i64 %t43, ptr %l33, !tbaa !24
  %t44 = load ptr, ptr %l32, !tbaa !29
  %t45 = load i64, ptr %l33, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t44, i64 %t45)
  br label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = getelementptr %"compiler/token:Token", ptr %l9, i32 0, i32 0
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l36
  store ptr %l36, ptr %l37, !tbaa !29
  store i32 95, ptr %l38
  store ptr %l38, ptr %l39, !tbaa !29
  %t48 = load ptr, ptr %l37, !tbaa !29
  %t49 = load ptr, ptr %l39, !tbaa !29
  %t50 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t48, ptr %t49)
  store i1 %t50, ptr %l40
  br label %bb10
bb9:
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l34, !tbaa !24
  %t52 = load i64, ptr %l34, !tbaa !24
  %t53 = add i64 %t52, 1
  store i64 %t53, ptr %l35, !tbaa !24
  %t54 = load i64, ptr %l35, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb10:
  %t55 = load i1, ptr %l40, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l3, ptr %l42, !tbaa !29
  %t56 = load ptr, ptr %l42, !tbaa !29
  %t57 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %t56)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l44
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb14, label %ok.61
ok.61:
  store i64 %t58, ptr %l43
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t62 = load i64, ptr %l43, !tbaa !24
  store i64 %t62, ptr %l41, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb16:
  %t63 = load i64, ptr %l41, !tbaa !24
  store i64 %t63, ptr %l10, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t64, ptr %l45, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  store i64 %t65, ptr %l46, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  store i64 %t66, ptr %l47, !tbaa !24
  %t67 = load i64, ptr %l47, !tbaa !24
  %t68 = trunc i64 %t67 to i32
  store i32 %t68, ptr %l48, !tbaa !23
  %t69 = load i32, ptr %l48, !tbaa !23
  %t70 = load i64, ptr %l46, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 %t70
  store i32 %t69, ptr %t73, !tbaa !33
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s7
  %t74 = load i64, ptr %l6, !tbaa !24
  store i64 %t74, ptr %l49, !tbaa !24
  %t75 = load i64, ptr %l49, !tbaa !24
  %t76 = add i64 %t75, 1
  store i64 %t76, ptr %l50, !tbaa !24
  %t77 = load i64, ptr %l50, !tbaa !24
  store i64 %t77, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb2
bb20:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, i64 } @compiler_2fscan_2eoperator(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i8
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i8
  %l19 = alloca i8
  %l20 = alloca i1
  %l21 = alloca i8
  %l22 = alloca i1
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i32, i64 }
  %l27 = alloca i8
  %l28 = alloca i1
  %l29 = alloca i32
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i32, i64 }
  %l33 = alloca i32
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca { i32, i64 }
  %l37 = alloca i8
  %l38 = alloca i1
  %l39 = alloca i8
  %l40 = alloca i1
  %l41 = alloca i32
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i32, i64 }
  %l45 = alloca i8
  %l46 = alloca i1
  %l47 = alloca i32
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca { i32, i64 }
  %l51 = alloca i32
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i32, i64 }
  %l55 = alloca i8
  %l56 = alloca i1
  %l57 = alloca i8
  %l58 = alloca i1
  %l59 = alloca i32
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca { i32, i64 }
  %l63 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca { i32, i64 }
  %l67 = alloca i8
  %l68 = alloca i1
  %l69 = alloca i8
  %l70 = alloca i1
  %l71 = alloca i32
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca { i32, i64 }
  %l75 = alloca i32
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca { i32, i64 }
  %l79 = alloca i8
  %l80 = alloca i1
  %l81 = alloca i8
  %l82 = alloca i1
  %l83 = alloca i32
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca { i32, i64 }
  %l87 = alloca i32
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca { i32, i64 }
  %l91 = alloca i8
  %l92 = alloca i1
  %l93 = alloca i8
  %l94 = alloca i1
  %l95 = alloca i32
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca { i32, i64 }
  %l99 = alloca i32
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca { i32, i64 }
  %l103 = alloca i8
  %l104 = alloca i1
  %l105 = alloca i8
  %l106 = alloca i1
  %l107 = alloca i32
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca { i32, i64 }
  %l111 = alloca i32
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca { i32, i64 }
  %l115 = alloca i8
  %l116 = alloca i1
  %l117 = alloca i8
  %l118 = alloca i1
  %l119 = alloca i32
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca { i32, i64 }
  %l123 = alloca i32
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca { i32, i64 }
  %l127 = alloca i8
  %l128 = alloca i1
  %l129 = alloca i8
  %l130 = alloca i1
  %l131 = alloca i32
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca { i32, i64 }
  %l135 = alloca i32
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca { i32, i64 }
  %l139 = alloca i8
  %l140 = alloca i1
  %l141 = alloca i8
  %l142 = alloca i1
  %l143 = alloca i32
  %l144 = alloca i64
  %l145 = alloca i64
  %l146 = alloca { i32, i64 }
  %l147 = alloca i8
  %l148 = alloca i1
  %l149 = alloca i32
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca { i32, i64 }
  %l153 = alloca i32
  %l154 = alloca i64
  %l155 = alloca i64
  %l156 = alloca { i32, i64 }
  %l157 = alloca i8
  %l158 = alloca i1
  %l159 = alloca i8
  %l160 = alloca i1
  %l161 = alloca i32
  %l162 = alloca i64
  %l163 = alloca i64
  %l164 = alloca { i32, i64 }
  %l165 = alloca i32
  %l166 = alloca i64
  %l167 = alloca i64
  %l168 = alloca { i32, i64 }
  %l169 = alloca i8
  %l170 = alloca i1
  %l171 = alloca i8
  %l172 = alloca i1
  %l173 = alloca i64
  %l174 = alloca i64
  %l175 = alloca i64
  %l176 = alloca i1
  %l177 = alloca i1
  %l178 = alloca { i64, ptr }
  %l179 = alloca i64
  %l180 = alloca i64
  %l181 = alloca i8
  %l182 = alloca i1
  %l183 = alloca i32
  %l184 = alloca i64
  %l185 = alloca i64
  %l186 = alloca { i32, i64 }
  %l187 = alloca i32
  %l188 = alloca i64
  %l189 = alloca i64
  %l190 = alloca { i32, i64 }
  %l191 = alloca i8
  %l192 = alloca i1
  %l193 = alloca i32
  %l194 = alloca i64
  %l195 = alloca i64
  %l196 = alloca { i32, i64 }
  %l197 = alloca i32
  %l198 = alloca i64
  %l199 = alloca i64
  %l200 = alloca { i32, i64 }
  %l201 = alloca i8
  %l202 = alloca i1
  %l203 = alloca i8
  %l204 = alloca i1
  %l205 = alloca i64
  %l206 = alloca i64
  %l207 = alloca i64
  %l208 = alloca i1
  %l209 = alloca i1
  %l210 = alloca { i64, ptr }
  %l211 = alloca i64
  %l212 = alloca i64
  %l213 = alloca i8
  %l214 = alloca i1
  %l215 = alloca i32
  %l216 = alloca i64
  %l217 = alloca i64
  %l218 = alloca { i32, i64 }
  %l219 = alloca i32
  %l220 = alloca i64
  %l221 = alloca i64
  %l222 = alloca { i32, i64 }
  %l223 = alloca i8
  %l224 = alloca i1
  %l225 = alloca i32
  %l226 = alloca i64
  %l227 = alloca i64
  %l228 = alloca { i32, i64 }
  %l229 = alloca i32
  %l230 = alloca i64
  %l231 = alloca i64
  %l232 = alloca { i32, i64 }
  %l233 = alloca i8
  %l234 = alloca i1
  %l235 = alloca i32
  %l236 = alloca i64
  %l237 = alloca i64
  %l238 = alloca { i32, i64 }
  %l239 = alloca i8
  %l240 = alloca i1
  %l241 = alloca i32
  %l242 = alloca i64
  %l243 = alloca i64
  %l244 = alloca { i32, i64 }
  %l245 = alloca i8
  %l246 = alloca i1
  %l247 = alloca i32
  %l248 = alloca i64
  %l249 = alloca i64
  %l250 = alloca { i32, i64 }
  %l251 = alloca i8
  %l252 = alloca i1
  %l253 = alloca i32
  %l254 = alloca i64
  %l255 = alloca i64
  %l256 = alloca { i32, i64 }
  %l257 = alloca i8
  %l258 = alloca i1
  %l259 = alloca i32
  %l260 = alloca i64
  %l261 = alloca i64
  %l262 = alloca { i32, i64 }
  %l263 = alloca i8
  %l264 = alloca i1
  %l265 = alloca i32
  %l266 = alloca i64
  %l267 = alloca i64
  %l268 = alloca { i32, i64 }
  %l269 = alloca i8
  %l270 = alloca i1
  %l271 = alloca i32
  %l272 = alloca i64
  %l273 = alloca i64
  %l274 = alloca { i32, i64 }
  %l275 = alloca i8
  %l276 = alloca i1
  %l277 = alloca i32
  %l278 = alloca i64
  %l279 = alloca i64
  %l280 = alloca { i32, i64 }
  %l281 = alloca i8
  %l282 = alloca i1
  %l283 = alloca i32
  %l284 = alloca i64
  %l285 = alloca i64
  %l286 = alloca { i32, i64 }
  %l287 = alloca i8
  %l288 = alloca i1
  %l289 = alloca i32
  %l290 = alloca i64
  %l291 = alloca i64
  %l292 = alloca { i32, i64 }
  %l293 = alloca i8
  %l294 = alloca i1
  %l295 = alloca i32
  %l296 = alloca i64
  %l297 = alloca i64
  %l298 = alloca { i32, i64 }
  %l299 = alloca i8
  %l300 = alloca i1
  %l301 = alloca i32
  %l302 = alloca i64
  %l303 = alloca i64
  %l304 = alloca { i32, i64 }
  %l305 = alloca i32
  %l306 = alloca i64
  %l307 = alloca i64
  %l308 = alloca { i32, i64 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load i64, ptr %l6, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l7, !tbaa !27
  %t6 = load i64, ptr %l1, !tbaa !24
  store i64 %t6, ptr %l8, !tbaa !24
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 %t7
  %t11 = load i8, ptr %t10, !tbaa !32
  store i8 %t11, ptr %l9, !tbaa !22
  %t12 = load i8, ptr %l9, !tbaa !22
  store i8 %t12, ptr %l3, !tbaa !22
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l10, !tbaa !24
  %t15 = add i64 %t14, 1
  store i64 %t15, ptr %l11, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %l12, !tbaa !24
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l13, !tbaa !21
  %t20 = load i1, ptr %l13, !tbaa !21
  br i1 %t20, label %bb1, label %bb2
bb1:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t22 = load i64, ptr %l1, !tbaa !24
  store i64 %t22, ptr %l16, !tbaa !24
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = add i64 %t23, 1
  store i64 %t24, ptr %l17, !tbaa !24
  %t25 = load i64, ptr %l17, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t25
  %t29 = load i8, ptr %t28, !tbaa !32
  store i8 %t29, ptr %l18, !tbaa !22
  %t30 = load i8, ptr %l18, !tbaa !22
  store i8 %t30, ptr %l14, !tbaa !22
  br label %bb3
bb2:
  store i8 0, ptr %l14, !tbaa !22
  br label %bb3
bb3:
  %t31 = load i8, ptr %l14, !tbaa !22
  store i8 %t31, ptr %l4, !tbaa !22
  %t32 = load i8, ptr %l3, !tbaa !22
  store i8 %t32, ptr %l19, !tbaa !22
  %t33 = load i8, ptr %l19, !tbaa !22
  %t34 = icmp eq i8 %t33, 43
  store i1 %t34, ptr %l20, !tbaa !21
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb13
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load i8, ptr %l4, !tbaa !22
  store i8 %t36, ptr %l21, !tbaa !22
  %t37 = load i8, ptr %l21, !tbaa !22
  %t38 = icmp eq i8 %t37, 43
  store i1 %t38, ptr %l22, !tbaa !21
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 73, ptr %l23
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %l24, !tbaa !24
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = add i64 %t41, 2
  store i64 %t42, ptr %l25, !tbaa !24
  %t43 = load i32, ptr %l23
  %t44 = insertvalue { i32, i64 } undef, i32 %t43, 0
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = insertvalue { i32, i64 } %t44, i64 %t45, 1
  store { i32, i64 } %t46, ptr %l26
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i32, i64 }, ptr %l26
  store { i32, i64 } %t47, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t48 = load i8, ptr %l4, !tbaa !22
  store i8 %t48, ptr %l27, !tbaa !22
  %t49 = load i8, ptr %l27, !tbaa !22
  %t50 = icmp eq i8 %t49, 61
  store i1 %t50, ptr %l28, !tbaa !21
  %t51 = load i1, ptr %l28, !tbaa !21
  br i1 %t51, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 63, ptr %l29
  %t52 = load i64, ptr %l1, !tbaa !24
  store i64 %t52, ptr %l30, !tbaa !24
  %t53 = load i64, ptr %l30, !tbaa !24
  %t54 = add i64 %t53, 2
  store i64 %t54, ptr %l31, !tbaa !24
  %t55 = load i32, ptr %l29
  %t56 = insertvalue { i32, i64 } undef, i32 %t55, 0
  %t57 = load i64, ptr %l31, !tbaa !24
  %t58 = insertvalue { i32, i64 } %t56, i64 %t57, 1
  store { i32, i64 } %t58, ptr %l32
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i32, i64 }, ptr %l32
  store { i32, i64 } %t59, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  store i32 51, ptr %l33
  %t60 = load i64, ptr %l1, !tbaa !24
  store i64 %t60, ptr %l34, !tbaa !24
  %t61 = load i64, ptr %l34, !tbaa !24
  %t62 = add i64 %t61, 1
  store i64 %t62, ptr %l35, !tbaa !24
  %t63 = load i32, ptr %l33
  %t64 = insertvalue { i32, i64 } undef, i32 %t63, 0
  %t65 = load i64, ptr %l35, !tbaa !24
  %t66 = insertvalue { i32, i64 } %t64, i64 %t65, 1
  store { i32, i64 } %t66, ptr %l36
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t67 = load { i32, i64 }, ptr %l36
  store { i32, i64 } %t67, ptr %rv
  br label %ret
bb13:
  %t68 = load i8, ptr %l3, !tbaa !22
  store i8 %t68, ptr %l37, !tbaa !22
  %t69 = load i8, ptr %l37, !tbaa !22
  %t70 = icmp eq i8 %t69, 45
  store i1 %t70, ptr %l38, !tbaa !21
  %t71 = load i1, ptr %l38, !tbaa !21
  br i1 %t71, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb23
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load i8, ptr %l4, !tbaa !22
  store i8 %t72, ptr %l39, !tbaa !22
  %t73 = load i8, ptr %l39, !tbaa !22
  %t74 = icmp eq i8 %t73, 45
  store i1 %t74, ptr %l40, !tbaa !21
  %t75 = load i1, ptr %l40, !tbaa !21
  br i1 %t75, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  store i32 74, ptr %l41
  %t76 = load i64, ptr %l1, !tbaa !24
  store i64 %t76, ptr %l42, !tbaa !24
  %t77 = load i64, ptr %l42, !tbaa !24
  %t78 = add i64 %t77, 2
  store i64 %t78, ptr %l43, !tbaa !24
  %t79 = load i32, ptr %l41
  %t80 = insertvalue { i32, i64 } undef, i32 %t79, 0
  %t81 = load i64, ptr %l43, !tbaa !24
  %t82 = insertvalue { i32, i64 } %t80, i64 %t81, 1
  store { i32, i64 } %t82, ptr %l44
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i32, i64 }, ptr %l44
  store { i32, i64 } %t83, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t84 = load i8, ptr %l4, !tbaa !22
  store i8 %t84, ptr %l45, !tbaa !22
  %t85 = load i8, ptr %l45, !tbaa !22
  %t86 = icmp eq i8 %t85, 61
  store i1 %t86, ptr %l46, !tbaa !21
  %t87 = load i1, ptr %l46, !tbaa !21
  br i1 %t87, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  store i32 64, ptr %l47
  %t88 = load i64, ptr %l1, !tbaa !24
  store i64 %t88, ptr %l48, !tbaa !24
  %t89 = load i64, ptr %l48, !tbaa !24
  %t90 = add i64 %t89, 2
  store i64 %t90, ptr %l49, !tbaa !24
  %t91 = load i32, ptr %l47
  %t92 = insertvalue { i32, i64 } undef, i32 %t91, 0
  %t93 = load i64, ptr %l49, !tbaa !24
  %t94 = insertvalue { i32, i64 } %t92, i64 %t93, 1
  store { i32, i64 } %t94, ptr %l50
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t95 = load { i32, i64 }, ptr %l50
  store { i32, i64 } %t95, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  store i32 52, ptr %l51
  %t96 = load i64, ptr %l1, !tbaa !24
  store i64 %t96, ptr %l52, !tbaa !24
  %t97 = load i64, ptr %l52, !tbaa !24
  %t98 = add i64 %t97, 1
  store i64 %t98, ptr %l53, !tbaa !24
  %t99 = load i32, ptr %l51
  %t100 = insertvalue { i32, i64 } undef, i32 %t99, 0
  %t101 = load i64, ptr %l53, !tbaa !24
  %t102 = insertvalue { i32, i64 } %t100, i64 %t101, 1
  store { i32, i64 } %t102, ptr %l54
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t103 = load { i32, i64 }, ptr %l54
  store { i32, i64 } %t103, ptr %rv
  br label %ret
bb23:
  %t104 = load i8, ptr %l3, !tbaa !22
  store i8 %t104, ptr %l55, !tbaa !22
  %t105 = load i8, ptr %l55, !tbaa !22
  %t106 = icmp eq i8 %t105, 42
  store i1 %t106, ptr %l56, !tbaa !21
  %t107 = load i1, ptr %l56, !tbaa !21
  br i1 %t107, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb30
bb26:
  store %olang.scope zeroinitializer, ptr %s7
  %t108 = load i8, ptr %l4, !tbaa !22
  store i8 %t108, ptr %l57, !tbaa !22
  %t109 = load i8, ptr %l57, !tbaa !22
  %t110 = icmp eq i8 %t109, 61
  store i1 %t110, ptr %l58, !tbaa !21
  %t111 = load i1, ptr %l58, !tbaa !21
  br i1 %t111, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 65, ptr %l59
  %t112 = load i64, ptr %l1, !tbaa !24
  store i64 %t112, ptr %l60, !tbaa !24
  %t113 = load i64, ptr %l60, !tbaa !24
  %t114 = add i64 %t113, 2
  store i64 %t114, ptr %l61, !tbaa !24
  %t115 = load i32, ptr %l59
  %t116 = insertvalue { i32, i64 } undef, i32 %t115, 0
  %t117 = load i64, ptr %l61, !tbaa !24
  %t118 = insertvalue { i32, i64 } %t116, i64 %t117, 1
  store { i32, i64 } %t118, ptr %l62
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i32, i64 }, ptr %l62
  store { i32, i64 } %t119, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  store i32 53, ptr %l63
  %t120 = load i64, ptr %l1, !tbaa !24
  store i64 %t120, ptr %l64, !tbaa !24
  %t121 = load i64, ptr %l64, !tbaa !24
  %t122 = add i64 %t121, 1
  store i64 %t122, ptr %l65, !tbaa !24
  %t123 = load i32, ptr %l63
  %t124 = insertvalue { i32, i64 } undef, i32 %t123, 0
  %t125 = load i64, ptr %l65, !tbaa !24
  %t126 = insertvalue { i32, i64 } %t124, i64 %t125, 1
  store { i32, i64 } %t126, ptr %l66
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t127 = load { i32, i64 }, ptr %l66
  store { i32, i64 } %t127, ptr %rv
  br label %ret
bb30:
  %t128 = load i8, ptr %l3, !tbaa !22
  store i8 %t128, ptr %l67, !tbaa !22
  %t129 = load i8, ptr %l67, !tbaa !22
  %t130 = icmp eq i8 %t129, 47
  store i1 %t130, ptr %l68, !tbaa !21
  %t131 = load i1, ptr %l68, !tbaa !21
  br i1 %t131, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb37
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t132 = load i8, ptr %l4, !tbaa !22
  store i8 %t132, ptr %l69, !tbaa !22
  %t133 = load i8, ptr %l69, !tbaa !22
  %t134 = icmp eq i8 %t133, 61
  store i1 %t134, ptr %l70, !tbaa !21
  %t135 = load i1, ptr %l70, !tbaa !21
  br i1 %t135, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s10
  store i32 66, ptr %l71
  %t136 = load i64, ptr %l1, !tbaa !24
  store i64 %t136, ptr %l72, !tbaa !24
  %t137 = load i64, ptr %l72, !tbaa !24
  %t138 = add i64 %t137, 2
  store i64 %t138, ptr %l73, !tbaa !24
  %t139 = load i32, ptr %l71
  %t140 = insertvalue { i32, i64 } undef, i32 %t139, 0
  %t141 = load i64, ptr %l73, !tbaa !24
  %t142 = insertvalue { i32, i64 } %t140, i64 %t141, 1
  store { i32, i64 } %t142, ptr %l74
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t143 = load { i32, i64 }, ptr %l74
  store { i32, i64 } %t143, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  store i32 54, ptr %l75
  %t144 = load i64, ptr %l1, !tbaa !24
  store i64 %t144, ptr %l76, !tbaa !24
  %t145 = load i64, ptr %l76, !tbaa !24
  %t146 = add i64 %t145, 1
  store i64 %t146, ptr %l77, !tbaa !24
  %t147 = load i32, ptr %l75
  %t148 = insertvalue { i32, i64 } undef, i32 %t147, 0
  %t149 = load i64, ptr %l77, !tbaa !24
  %t150 = insertvalue { i32, i64 } %t148, i64 %t149, 1
  store { i32, i64 } %t150, ptr %l78
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t151 = load { i32, i64 }, ptr %l78
  store { i32, i64 } %t151, ptr %rv
  br label %ret
bb37:
  %t152 = load i8, ptr %l3, !tbaa !22
  store i8 %t152, ptr %l79, !tbaa !22
  %t153 = load i8, ptr %l79, !tbaa !22
  %t154 = icmp eq i8 %t153, 37
  store i1 %t154, ptr %l80, !tbaa !21
  %t155 = load i1, ptr %l80, !tbaa !21
  br i1 %t155, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb44
bb40:
  store %olang.scope zeroinitializer, ptr %s11
  %t156 = load i8, ptr %l4, !tbaa !22
  store i8 %t156, ptr %l81, !tbaa !22
  %t157 = load i8, ptr %l81, !tbaa !22
  %t158 = icmp eq i8 %t157, 61
  store i1 %t158, ptr %l82, !tbaa !21
  %t159 = load i1, ptr %l82, !tbaa !21
  br i1 %t159, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s12
  store i32 67, ptr %l83
  %t160 = load i64, ptr %l1, !tbaa !24
  store i64 %t160, ptr %l84, !tbaa !24
  %t161 = load i64, ptr %l84, !tbaa !24
  %t162 = add i64 %t161, 2
  store i64 %t162, ptr %l85, !tbaa !24
  %t163 = load i32, ptr %l83
  %t164 = insertvalue { i32, i64 } undef, i32 %t163, 0
  %t165 = load i64, ptr %l85, !tbaa !24
  %t166 = insertvalue { i32, i64 } %t164, i64 %t165, 1
  store { i32, i64 } %t166, ptr %l86
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t167 = load { i32, i64 }, ptr %l86
  store { i32, i64 } %t167, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  store i32 55, ptr %l87
  %t168 = load i64, ptr %l1, !tbaa !24
  store i64 %t168, ptr %l88, !tbaa !24
  %t169 = load i64, ptr %l88, !tbaa !24
  %t170 = add i64 %t169, 1
  store i64 %t170, ptr %l89, !tbaa !24
  %t171 = load i32, ptr %l87
  %t172 = insertvalue { i32, i64 } undef, i32 %t171, 0
  %t173 = load i64, ptr %l89, !tbaa !24
  %t174 = insertvalue { i32, i64 } %t172, i64 %t173, 1
  store { i32, i64 } %t174, ptr %l90
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t175 = load { i32, i64 }, ptr %l90
  store { i32, i64 } %t175, ptr %rv
  br label %ret
bb44:
  %t176 = load i8, ptr %l3, !tbaa !22
  store i8 %t176, ptr %l91, !tbaa !22
  %t177 = load i8, ptr %l91, !tbaa !22
  %t178 = icmp eq i8 %t177, 38
  store i1 %t178, ptr %l92, !tbaa !21
  %t179 = load i1, ptr %l92, !tbaa !21
  br i1 %t179, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb51
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  %t180 = load i8, ptr %l4, !tbaa !22
  store i8 %t180, ptr %l93, !tbaa !22
  %t181 = load i8, ptr %l93, !tbaa !22
  %t182 = icmp eq i8 %t181, 61
  store i1 %t182, ptr %l94, !tbaa !21
  %t183 = load i1, ptr %l94, !tbaa !21
  br i1 %t183, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s14
  store i32 70, ptr %l95
  %t184 = load i64, ptr %l1, !tbaa !24
  store i64 %t184, ptr %l96, !tbaa !24
  %t185 = load i64, ptr %l96, !tbaa !24
  %t186 = add i64 %t185, 2
  store i64 %t186, ptr %l97, !tbaa !24
  %t187 = load i32, ptr %l95
  %t188 = insertvalue { i32, i64 } undef, i32 %t187, 0
  %t189 = load i64, ptr %l97, !tbaa !24
  %t190 = insertvalue { i32, i64 } %t188, i64 %t189, 1
  store { i32, i64 } %t190, ptr %l98
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t191 = load { i32, i64 }, ptr %l98
  store { i32, i64 } %t191, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  store i32 83, ptr %l99
  %t192 = load i64, ptr %l1, !tbaa !24
  store i64 %t192, ptr %l100, !tbaa !24
  %t193 = load i64, ptr %l100, !tbaa !24
  %t194 = add i64 %t193, 1
  store i64 %t194, ptr %l101, !tbaa !24
  %t195 = load i32, ptr %l99
  %t196 = insertvalue { i32, i64 } undef, i32 %t195, 0
  %t197 = load i64, ptr %l101, !tbaa !24
  %t198 = insertvalue { i32, i64 } %t196, i64 %t197, 1
  store { i32, i64 } %t198, ptr %l102
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i32, i64 }, ptr %l102
  store { i32, i64 } %t199, ptr %rv
  br label %ret
bb51:
  %t200 = load i8, ptr %l3, !tbaa !22
  store i8 %t200, ptr %l103, !tbaa !22
  %t201 = load i8, ptr %l103, !tbaa !22
  %t202 = icmp eq i8 %t201, 124
  store i1 %t202, ptr %l104, !tbaa !21
  %t203 = load i1, ptr %l104, !tbaa !21
  br i1 %t203, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb58
bb54:
  store %olang.scope zeroinitializer, ptr %s15
  %t204 = load i8, ptr %l4, !tbaa !22
  store i8 %t204, ptr %l105, !tbaa !22
  %t205 = load i8, ptr %l105, !tbaa !22
  %t206 = icmp eq i8 %t205, 61
  store i1 %t206, ptr %l106, !tbaa !21
  %t207 = load i1, ptr %l106, !tbaa !21
  br i1 %t207, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s16
  store i32 71, ptr %l107
  %t208 = load i64, ptr %l1, !tbaa !24
  store i64 %t208, ptr %l108, !tbaa !24
  %t209 = load i64, ptr %l108, !tbaa !24
  %t210 = add i64 %t209, 2
  store i64 %t210, ptr %l109, !tbaa !24
  %t211 = load i32, ptr %l107
  %t212 = insertvalue { i32, i64 } undef, i32 %t211, 0
  %t213 = load i64, ptr %l109, !tbaa !24
  %t214 = insertvalue { i32, i64 } %t212, i64 %t213, 1
  store { i32, i64 } %t214, ptr %l110
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t215 = load { i32, i64 }, ptr %l110
  store { i32, i64 } %t215, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  store i32 84, ptr %l111
  %t216 = load i64, ptr %l1, !tbaa !24
  store i64 %t216, ptr %l112, !tbaa !24
  %t217 = load i64, ptr %l112, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l113, !tbaa !24
  %t219 = load i32, ptr %l111
  %t220 = insertvalue { i32, i64 } undef, i32 %t219, 0
  %t221 = load i64, ptr %l113, !tbaa !24
  %t222 = insertvalue { i32, i64 } %t220, i64 %t221, 1
  store { i32, i64 } %t222, ptr %l114
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t223 = load { i32, i64 }, ptr %l114
  store { i32, i64 } %t223, ptr %rv
  br label %ret
bb58:
  %t224 = load i8, ptr %l3, !tbaa !22
  store i8 %t224, ptr %l115, !tbaa !22
  %t225 = load i8, ptr %l115, !tbaa !22
  %t226 = icmp eq i8 %t225, 94
  store i1 %t226, ptr %l116, !tbaa !21
  %t227 = load i1, ptr %l116, !tbaa !21
  br i1 %t227, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb65
bb61:
  store %olang.scope zeroinitializer, ptr %s17
  %t228 = load i8, ptr %l4, !tbaa !22
  store i8 %t228, ptr %l117, !tbaa !22
  %t229 = load i8, ptr %l117, !tbaa !22
  %t230 = icmp eq i8 %t229, 61
  store i1 %t230, ptr %l118, !tbaa !21
  %t231 = load i1, ptr %l118, !tbaa !21
  br i1 %t231, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s18
  store i32 72, ptr %l119
  %t232 = load i64, ptr %l1, !tbaa !24
  store i64 %t232, ptr %l120, !tbaa !24
  %t233 = load i64, ptr %l120, !tbaa !24
  %t234 = add i64 %t233, 2
  store i64 %t234, ptr %l121, !tbaa !24
  %t235 = load i32, ptr %l119
  %t236 = insertvalue { i32, i64 } undef, i32 %t235, 0
  %t237 = load i64, ptr %l121, !tbaa !24
  %t238 = insertvalue { i32, i64 } %t236, i64 %t237, 1
  store { i32, i64 } %t238, ptr %l122
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t239 = load { i32, i64 }, ptr %l122
  store { i32, i64 } %t239, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  store i32 85, ptr %l123
  %t240 = load i64, ptr %l1, !tbaa !24
  store i64 %t240, ptr %l124, !tbaa !24
  %t241 = load i64, ptr %l124, !tbaa !24
  %t242 = add i64 %t241, 1
  store i64 %t242, ptr %l125, !tbaa !24
  %t243 = load i32, ptr %l123
  %t244 = insertvalue { i32, i64 } undef, i32 %t243, 0
  %t245 = load i64, ptr %l125, !tbaa !24
  %t246 = insertvalue { i32, i64 } %t244, i64 %t245, 1
  store { i32, i64 } %t246, ptr %l126
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t247 = load { i32, i64 }, ptr %l126
  store { i32, i64 } %t247, ptr %rv
  br label %ret
bb65:
  %t248 = load i8, ptr %l3, !tbaa !22
  store i8 %t248, ptr %l127, !tbaa !22
  %t249 = load i8, ptr %l127, !tbaa !22
  %t250 = icmp eq i8 %t249, 58
  store i1 %t250, ptr %l128, !tbaa !21
  %t251 = load i1, ptr %l128, !tbaa !21
  br i1 %t251, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb72
bb68:
  store %olang.scope zeroinitializer, ptr %s19
  %t252 = load i8, ptr %l4, !tbaa !22
  store i8 %t252, ptr %l129, !tbaa !22
  %t253 = load i8, ptr %l129, !tbaa !22
  %t254 = icmp eq i8 %t253, 61
  store i1 %t254, ptr %l130, !tbaa !21
  %t255 = load i1, ptr %l130, !tbaa !21
  br i1 %t255, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s20
  store i32 62, ptr %l131
  %t256 = load i64, ptr %l1, !tbaa !24
  store i64 %t256, ptr %l132, !tbaa !24
  %t257 = load i64, ptr %l132, !tbaa !24
  %t258 = add i64 %t257, 2
  store i64 %t258, ptr %l133, !tbaa !24
  %t259 = load i32, ptr %l131
  %t260 = insertvalue { i32, i64 } undef, i32 %t259, 0
  %t261 = load i64, ptr %l133, !tbaa !24
  %t262 = insertvalue { i32, i64 } %t260, i64 %t261, 1
  store { i32, i64 } %t262, ptr %l134
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t263 = load { i32, i64 }, ptr %l134
  store { i32, i64 } %t263, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  store i32 61, ptr %l135
  %t264 = load i64, ptr %l1, !tbaa !24
  store i64 %t264, ptr %l136, !tbaa !24
  %t265 = load i64, ptr %l136, !tbaa !24
  %t266 = add i64 %t265, 1
  store i64 %t266, ptr %l137, !tbaa !24
  %t267 = load i32, ptr %l135
  %t268 = insertvalue { i32, i64 } undef, i32 %t267, 0
  %t269 = load i64, ptr %l137, !tbaa !24
  %t270 = insertvalue { i32, i64 } %t268, i64 %t269, 1
  store { i32, i64 } %t270, ptr %l138
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t271 = load { i32, i64 }, ptr %l138
  store { i32, i64 } %t271, ptr %rv
  br label %ret
bb72:
  %t272 = load i8, ptr %l3, !tbaa !22
  store i8 %t272, ptr %l139, !tbaa !22
  %t273 = load i8, ptr %l139, !tbaa !22
  %t274 = icmp eq i8 %t273, 61
  store i1 %t274, ptr %l140, !tbaa !21
  %t275 = load i1, ptr %l140, !tbaa !21
  br i1 %t275, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb82
bb75:
  store %olang.scope zeroinitializer, ptr %s21
  %t276 = load i8, ptr %l4, !tbaa !22
  store i8 %t276, ptr %l141, !tbaa !22
  %t277 = load i8, ptr %l141, !tbaa !22
  %t278 = icmp eq i8 %t277, 61
  store i1 %t278, ptr %l142, !tbaa !21
  %t279 = load i1, ptr %l142, !tbaa !21
  br i1 %t279, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s22
  store i32 75, ptr %l143
  %t280 = load i64, ptr %l1, !tbaa !24
  store i64 %t280, ptr %l144, !tbaa !24
  %t281 = load i64, ptr %l144, !tbaa !24
  %t282 = add i64 %t281, 2
  store i64 %t282, ptr %l145, !tbaa !24
  %t283 = load i32, ptr %l143
  %t284 = insertvalue { i32, i64 } undef, i32 %t283, 0
  %t285 = load i64, ptr %l145, !tbaa !24
  %t286 = insertvalue { i32, i64 } %t284, i64 %t285, 1
  store { i32, i64 } %t286, ptr %l146
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t287 = load { i32, i64 }, ptr %l146
  store { i32, i64 } %t287, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t288 = load i8, ptr %l4, !tbaa !22
  store i8 %t288, ptr %l147, !tbaa !22
  %t289 = load i8, ptr %l147, !tbaa !22
  %t290 = icmp eq i8 %t289, 62
  store i1 %t290, ptr %l148, !tbaa !21
  %t291 = load i1, ptr %l148, !tbaa !21
  br i1 %t291, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s23
  store i32 76, ptr %l149
  %t292 = load i64, ptr %l1, !tbaa !24
  store i64 %t292, ptr %l150, !tbaa !24
  %t293 = load i64, ptr %l150, !tbaa !24
  %t294 = add i64 %t293, 2
  store i64 %t294, ptr %l151, !tbaa !24
  %t295 = load i32, ptr %l149
  %t296 = insertvalue { i32, i64 } undef, i32 %t295, 0
  %t297 = load i64, ptr %l151, !tbaa !24
  %t298 = insertvalue { i32, i64 } %t296, i64 %t297, 1
  store { i32, i64 } %t298, ptr %l152
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t299 = load { i32, i64 }, ptr %l152
  store { i32, i64 } %t299, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  store i32 60, ptr %l153
  %t300 = load i64, ptr %l1, !tbaa !24
  store i64 %t300, ptr %l154, !tbaa !24
  %t301 = load i64, ptr %l154, !tbaa !24
  %t302 = add i64 %t301, 1
  store i64 %t302, ptr %l155, !tbaa !24
  %t303 = load i32, ptr %l153
  %t304 = insertvalue { i32, i64 } undef, i32 %t303, 0
  %t305 = load i64, ptr %l155, !tbaa !24
  %t306 = insertvalue { i32, i64 } %t304, i64 %t305, 1
  store { i32, i64 } %t306, ptr %l156
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t307 = load { i32, i64 }, ptr %l156
  store { i32, i64 } %t307, ptr %rv
  br label %ret
bb82:
  %t308 = load i8, ptr %l3, !tbaa !22
  store i8 %t308, ptr %l157, !tbaa !22
  %t309 = load i8, ptr %l157, !tbaa !22
  %t310 = icmp eq i8 %t309, 33
  store i1 %t310, ptr %l158, !tbaa !21
  %t311 = load i1, ptr %l158, !tbaa !21
  br i1 %t311, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb89
bb85:
  store %olang.scope zeroinitializer, ptr %s24
  %t312 = load i8, ptr %l4, !tbaa !22
  store i8 %t312, ptr %l159, !tbaa !22
  %t313 = load i8, ptr %l159, !tbaa !22
  %t314 = icmp eq i8 %t313, 61
  store i1 %t314, ptr %l160, !tbaa !21
  %t315 = load i1, ptr %l160, !tbaa !21
  br i1 %t315, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s25
  store i32 77, ptr %l161
  %t316 = load i64, ptr %l1, !tbaa !24
  store i64 %t316, ptr %l162, !tbaa !24
  %t317 = load i64, ptr %l162, !tbaa !24
  %t318 = add i64 %t317, 2
  store i64 %t318, ptr %l163, !tbaa !24
  %t319 = load i32, ptr %l161
  %t320 = insertvalue { i32, i64 } undef, i32 %t319, 0
  %t321 = load i64, ptr %l163, !tbaa !24
  %t322 = insertvalue { i32, i64 } %t320, i64 %t321, 1
  store { i32, i64 } %t322, ptr %l164
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t323 = load { i32, i64 }, ptr %l164
  store { i32, i64 } %t323, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  store i32 78, ptr %l165
  %t324 = load i64, ptr %l1, !tbaa !24
  store i64 %t324, ptr %l166, !tbaa !24
  %t325 = load i64, ptr %l166, !tbaa !24
  %t326 = add i64 %t325, 1
  store i64 %t326, ptr %l167, !tbaa !24
  %t327 = load i32, ptr %l165
  %t328 = insertvalue { i32, i64 } undef, i32 %t327, 0
  %t329 = load i64, ptr %l167, !tbaa !24
  %t330 = insertvalue { i32, i64 } %t328, i64 %t329, 1
  store { i32, i64 } %t330, ptr %l168
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t331 = load { i32, i64 }, ptr %l168
  store { i32, i64 } %t331, ptr %rv
  br label %ret
bb89:
  %t332 = load i8, ptr %l3, !tbaa !22
  store i8 %t332, ptr %l169, !tbaa !22
  %t333 = load i8, ptr %l169, !tbaa !22
  %t334 = icmp eq i8 %t333, 60
  store i1 %t334, ptr %l170, !tbaa !21
  %t335 = load i1, ptr %l170, !tbaa !21
  br i1 %t335, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb105
bb92:
  store %olang.scope zeroinitializer, ptr %s26
  %t336 = load i8, ptr %l4, !tbaa !22
  store i8 %t336, ptr %l171, !tbaa !22
  %t337 = load i8, ptr %l171, !tbaa !22
  %t338 = icmp eq i8 %t337, 60
  store i1 %t338, ptr %l172, !tbaa !21
  %t339 = load i1, ptr %l172, !tbaa !21
  br i1 %t339, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s27
  %t340 = load i64, ptr %l1, !tbaa !24
  store i64 %t340, ptr %l173, !tbaa !24
  %t341 = load i64, ptr %l173, !tbaa !24
  %t342 = add i64 %t341, 2
  store i64 %t342, ptr %l174, !tbaa !24
  %t343 = load i64, ptr %l2, !tbaa !24
  store i64 %t343, ptr %l175, !tbaa !24
  %t344 = load i64, ptr %l174, !tbaa !24
  %t345 = load i64, ptr %l175, !tbaa !24
  %t346 = icmp slt i64 %t344, %t345
  store i1 %t346, ptr %l176, !tbaa !21
  %t347 = load i1, ptr %l176, !tbaa !21
  br i1 %t347, label %bb95, label %bb96
bb94:
  br label %bb101
bb95:
  %t348 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t348, ptr %l178, !tbaa !27
  %t349 = load i64, ptr %l1, !tbaa !24
  store i64 %t349, ptr %l179, !tbaa !24
  %t350 = load i64, ptr %l179, !tbaa !24
  %t351 = add i64 %t350, 2
  store i64 %t351, ptr %l180, !tbaa !24
  %t352 = load i64, ptr %l180, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr i8, ptr %t354, i64 %t352
  %t356 = load i8, ptr %t355, !tbaa !32
  store i8 %t356, ptr %l181, !tbaa !22
  %t357 = load i8, ptr %l181, !tbaa !22
  %t358 = icmp eq i8 %t357, 61
  store i1 %t358, ptr %l182, !tbaa !21
  %t359 = load i1, ptr %l182, !tbaa !21
  store i1 %t359, ptr %l177, !tbaa !21
  br label %bb97
bb96:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb97
bb97:
  %t360 = load i1, ptr %l177, !tbaa !21
  br i1 %t360, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s28
  store i32 68, ptr %l183
  %t361 = load i64, ptr %l1, !tbaa !24
  store i64 %t361, ptr %l184, !tbaa !24
  %t362 = load i64, ptr %l184, !tbaa !24
  %t363 = add i64 %t362, 3
  store i64 %t363, ptr %l185, !tbaa !24
  %t364 = load i32, ptr %l183
  %t365 = insertvalue { i32, i64 } undef, i32 %t364, 0
  %t366 = load i64, ptr %l185, !tbaa !24
  %t367 = insertvalue { i32, i64 } %t365, i64 %t366, 1
  store { i32, i64 } %t367, ptr %l186
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  %t368 = load { i32, i64 }, ptr %l186
  store { i32, i64 } %t368, ptr %rv
  br label %ret
bb99:
  br label %bb100
bb100:
  store i32 88, ptr %l187
  %t369 = load i64, ptr %l1, !tbaa !24
  store i64 %t369, ptr %l188, !tbaa !24
  %t370 = load i64, ptr %l188, !tbaa !24
  %t371 = add i64 %t370, 2
  store i64 %t371, ptr %l189, !tbaa !24
  %t372 = load i32, ptr %l187
  %t373 = insertvalue { i32, i64 } undef, i32 %t372, 0
  %t374 = load i64, ptr %l189, !tbaa !24
  %t375 = insertvalue { i32, i64 } %t373, i64 %t374, 1
  store { i32, i64 } %t375, ptr %l190
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  %t376 = load { i32, i64 }, ptr %l190
  store { i32, i64 } %t376, ptr %rv
  br label %ret
bb101:
  %t377 = load i8, ptr %l4, !tbaa !22
  store i8 %t377, ptr %l191, !tbaa !22
  %t378 = load i8, ptr %l191, !tbaa !22
  %t379 = icmp eq i8 %t378, 61
  store i1 %t379, ptr %l192, !tbaa !21
  %t380 = load i1, ptr %l192, !tbaa !21
  br i1 %t380, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s29
  store i32 80, ptr %l193
  %t381 = load i64, ptr %l1, !tbaa !24
  store i64 %t381, ptr %l194, !tbaa !24
  %t382 = load i64, ptr %l194, !tbaa !24
  %t383 = add i64 %t382, 2
  store i64 %t383, ptr %l195, !tbaa !24
  %t384 = load i32, ptr %l193
  %t385 = insertvalue { i32, i64 } undef, i32 %t384, 0
  %t386 = load i64, ptr %l195, !tbaa !24
  %t387 = insertvalue { i32, i64 } %t385, i64 %t386, 1
  store { i32, i64 } %t387, ptr %l196
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  %t388 = load { i32, i64 }, ptr %l196
  store { i32, i64 } %t388, ptr %rv
  br label %ret
bb103:
  br label %bb104
bb104:
  store i32 79, ptr %l197
  %t389 = load i64, ptr %l1, !tbaa !24
  store i64 %t389, ptr %l198, !tbaa !24
  %t390 = load i64, ptr %l198, !tbaa !24
  %t391 = add i64 %t390, 1
  store i64 %t391, ptr %l199, !tbaa !24
  %t392 = load i32, ptr %l197
  %t393 = insertvalue { i32, i64 } undef, i32 %t392, 0
  %t394 = load i64, ptr %l199, !tbaa !24
  %t395 = insertvalue { i32, i64 } %t393, i64 %t394, 1
  store { i32, i64 } %t395, ptr %l200
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  %t396 = load { i32, i64 }, ptr %l200
  store { i32, i64 } %t396, ptr %rv
  br label %ret
bb105:
  %t397 = load i8, ptr %l3, !tbaa !22
  store i8 %t397, ptr %l201, !tbaa !22
  %t398 = load i8, ptr %l201, !tbaa !22
  %t399 = icmp eq i8 %t398, 62
  store i1 %t399, ptr %l202, !tbaa !21
  %t400 = load i1, ptr %l202, !tbaa !21
  br i1 %t400, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb121
bb108:
  store %olang.scope zeroinitializer, ptr %s30
  %t401 = load i8, ptr %l4, !tbaa !22
  store i8 %t401, ptr %l203, !tbaa !22
  %t402 = load i8, ptr %l203, !tbaa !22
  %t403 = icmp eq i8 %t402, 62
  store i1 %t403, ptr %l204, !tbaa !21
  %t404 = load i1, ptr %l204, !tbaa !21
  br i1 %t404, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s31
  %t405 = load i64, ptr %l1, !tbaa !24
  store i64 %t405, ptr %l205, !tbaa !24
  %t406 = load i64, ptr %l205, !tbaa !24
  %t407 = add i64 %t406, 2
  store i64 %t407, ptr %l206, !tbaa !24
  %t408 = load i64, ptr %l2, !tbaa !24
  store i64 %t408, ptr %l207, !tbaa !24
  %t409 = load i64, ptr %l206, !tbaa !24
  %t410 = load i64, ptr %l207, !tbaa !24
  %t411 = icmp slt i64 %t409, %t410
  store i1 %t411, ptr %l208, !tbaa !21
  %t412 = load i1, ptr %l208, !tbaa !21
  br i1 %t412, label %bb111, label %bb112
bb110:
  br label %bb117
bb111:
  %t413 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t413, ptr %l210, !tbaa !27
  %t414 = load i64, ptr %l1, !tbaa !24
  store i64 %t414, ptr %l211, !tbaa !24
  %t415 = load i64, ptr %l211, !tbaa !24
  %t416 = add i64 %t415, 2
  store i64 %t416, ptr %l212, !tbaa !24
  %t417 = load i64, ptr %l212, !tbaa !24
  %t418 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !27
  %t420 = getelementptr i8, ptr %t419, i64 %t417
  %t421 = load i8, ptr %t420, !tbaa !32
  store i8 %t421, ptr %l213, !tbaa !22
  %t422 = load i8, ptr %l213, !tbaa !22
  %t423 = icmp eq i8 %t422, 61
  store i1 %t423, ptr %l214, !tbaa !21
  %t424 = load i1, ptr %l214, !tbaa !21
  store i1 %t424, ptr %l209, !tbaa !21
  br label %bb113
bb112:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb113
bb113:
  %t425 = load i1, ptr %l209, !tbaa !21
  br i1 %t425, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s32
  store i32 69, ptr %l215
  %t426 = load i64, ptr %l1, !tbaa !24
  store i64 %t426, ptr %l216, !tbaa !24
  %t427 = load i64, ptr %l216, !tbaa !24
  %t428 = add i64 %t427, 3
  store i64 %t428, ptr %l217, !tbaa !24
  %t429 = load i32, ptr %l215
  %t430 = insertvalue { i32, i64 } undef, i32 %t429, 0
  %t431 = load i64, ptr %l217, !tbaa !24
  %t432 = insertvalue { i32, i64 } %t430, i64 %t431, 1
  store { i32, i64 } %t432, ptr %l218
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  %t433 = load { i32, i64 }, ptr %l218
  store { i32, i64 } %t433, ptr %rv
  br label %ret
bb115:
  br label %bb116
bb116:
  store i32 89, ptr %l219
  %t434 = load i64, ptr %l1, !tbaa !24
  store i64 %t434, ptr %l220, !tbaa !24
  %t435 = load i64, ptr %l220, !tbaa !24
  %t436 = add i64 %t435, 2
  store i64 %t436, ptr %l221, !tbaa !24
  %t437 = load i32, ptr %l219
  %t438 = insertvalue { i32, i64 } undef, i32 %t437, 0
  %t439 = load i64, ptr %l221, !tbaa !24
  %t440 = insertvalue { i32, i64 } %t438, i64 %t439, 1
  store { i32, i64 } %t440, ptr %l222
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  %t441 = load { i32, i64 }, ptr %l222
  store { i32, i64 } %t441, ptr %rv
  br label %ret
bb117:
  %t442 = load i8, ptr %l4, !tbaa !22
  store i8 %t442, ptr %l223, !tbaa !22
  %t443 = load i8, ptr %l223, !tbaa !22
  %t444 = icmp eq i8 %t443, 61
  store i1 %t444, ptr %l224, !tbaa !21
  %t445 = load i1, ptr %l224, !tbaa !21
  br i1 %t445, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s33
  store i32 82, ptr %l225
  %t446 = load i64, ptr %l1, !tbaa !24
  store i64 %t446, ptr %l226, !tbaa !24
  %t447 = load i64, ptr %l226, !tbaa !24
  %t448 = add i64 %t447, 2
  store i64 %t448, ptr %l227, !tbaa !24
  %t449 = load i32, ptr %l225
  %t450 = insertvalue { i32, i64 } undef, i32 %t449, 0
  %t451 = load i64, ptr %l227, !tbaa !24
  %t452 = insertvalue { i32, i64 } %t450, i64 %t451, 1
  store { i32, i64 } %t452, ptr %l228
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  %t453 = load { i32, i64 }, ptr %l228
  store { i32, i64 } %t453, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  store i32 81, ptr %l229
  %t454 = load i64, ptr %l1, !tbaa !24
  store i64 %t454, ptr %l230, !tbaa !24
  %t455 = load i64, ptr %l230, !tbaa !24
  %t456 = add i64 %t455, 1
  store i64 %t456, ptr %l231, !tbaa !24
  %t457 = load i32, ptr %l229
  %t458 = insertvalue { i32, i64 } undef, i32 %t457, 0
  %t459 = load i64, ptr %l231, !tbaa !24
  %t460 = insertvalue { i32, i64 } %t458, i64 %t459, 1
  store { i32, i64 } %t460, ptr %l232
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  %t461 = load { i32, i64 }, ptr %l232
  store { i32, i64 } %t461, ptr %rv
  br label %ret
bb121:
  %t462 = load i8, ptr %l3, !tbaa !22
  store i8 %t462, ptr %l233, !tbaa !22
  %t463 = load i8, ptr %l233, !tbaa !22
  %t464 = icmp eq i8 %t463, 64
  store i1 %t464, ptr %l234, !tbaa !21
  %t465 = load i1, ptr %l234, !tbaa !21
  br i1 %t465, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb125
bb124:
  store %olang.scope zeroinitializer, ptr %s34
  store i32 56, ptr %l235
  %t466 = load i64, ptr %l1, !tbaa !24
  store i64 %t466, ptr %l236, !tbaa !24
  %t467 = load i64, ptr %l236, !tbaa !24
  %t468 = add i64 %t467, 1
  store i64 %t468, ptr %l237, !tbaa !24
  %t469 = load i32, ptr %l235
  %t470 = insertvalue { i32, i64 } undef, i32 %t469, 0
  %t471 = load i64, ptr %l237, !tbaa !24
  %t472 = insertvalue { i32, i64 } %t470, i64 %t471, 1
  store { i32, i64 } %t472, ptr %l238
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  %t473 = load { i32, i64 }, ptr %l238
  store { i32, i64 } %t473, ptr %rv
  br label %ret
bb125:
  %t474 = load i8, ptr %l3, !tbaa !22
  store i8 %t474, ptr %l239, !tbaa !22
  %t475 = load i8, ptr %l239, !tbaa !22
  %t476 = icmp eq i8 %t475, 44
  store i1 %t476, ptr %l240, !tbaa !21
  %t477 = load i1, ptr %l240, !tbaa !21
  br i1 %t477, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s35
  store i32 57, ptr %l241
  %t478 = load i64, ptr %l1, !tbaa !24
  store i64 %t478, ptr %l242, !tbaa !24
  %t479 = load i64, ptr %l242, !tbaa !24
  %t480 = add i64 %t479, 1
  store i64 %t480, ptr %l243, !tbaa !24
  %t481 = load i32, ptr %l241
  %t482 = insertvalue { i32, i64 } undef, i32 %t481, 0
  %t483 = load i64, ptr %l243, !tbaa !24
  %t484 = insertvalue { i32, i64 } %t482, i64 %t483, 1
  store { i32, i64 } %t484, ptr %l244
  call void @__olang_scope_close(ptr %s35)
  call void @__olang_scope_close(ptr %s0)
  %t485 = load { i32, i64 }, ptr %l244
  store { i32, i64 } %t485, ptr %rv
  br label %ret
bb129:
  %t486 = load i8, ptr %l3, !tbaa !22
  store i8 %t486, ptr %l245, !tbaa !22
  %t487 = load i8, ptr %l245, !tbaa !22
  %t488 = icmp eq i8 %t487, 46
  store i1 %t488, ptr %l246, !tbaa !21
  %t489 = load i1, ptr %l246, !tbaa !21
  br i1 %t489, label %bb130, label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s36
  store i32 58, ptr %l247
  %t490 = load i64, ptr %l1, !tbaa !24
  store i64 %t490, ptr %l248, !tbaa !24
  %t491 = load i64, ptr %l248, !tbaa !24
  %t492 = add i64 %t491, 1
  store i64 %t492, ptr %l249, !tbaa !24
  %t493 = load i32, ptr %l247
  %t494 = insertvalue { i32, i64 } undef, i32 %t493, 0
  %t495 = load i64, ptr %l249, !tbaa !24
  %t496 = insertvalue { i32, i64 } %t494, i64 %t495, 1
  store { i32, i64 } %t496, ptr %l250
  call void @__olang_scope_close(ptr %s36)
  call void @__olang_scope_close(ptr %s0)
  %t497 = load { i32, i64 }, ptr %l250
  store { i32, i64 } %t497, ptr %rv
  br label %ret
bb133:
  %t498 = load i8, ptr %l3, !tbaa !22
  store i8 %t498, ptr %l251, !tbaa !22
  %t499 = load i8, ptr %l251, !tbaa !22
  %t500 = icmp eq i8 %t499, 63
  store i1 %t500, ptr %l252, !tbaa !21
  %t501 = load i1, ptr %l252, !tbaa !21
  br i1 %t501, label %bb134, label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s37
  store i32 59, ptr %l253
  %t502 = load i64, ptr %l1, !tbaa !24
  store i64 %t502, ptr %l254, !tbaa !24
  %t503 = load i64, ptr %l254, !tbaa !24
  %t504 = add i64 %t503, 1
  store i64 %t504, ptr %l255, !tbaa !24
  %t505 = load i32, ptr %l253
  %t506 = insertvalue { i32, i64 } undef, i32 %t505, 0
  %t507 = load i64, ptr %l255, !tbaa !24
  %t508 = insertvalue { i32, i64 } %t506, i64 %t507, 1
  store { i32, i64 } %t508, ptr %l256
  call void @__olang_scope_close(ptr %s37)
  call void @__olang_scope_close(ptr %s0)
  %t509 = load { i32, i64 }, ptr %l256
  store { i32, i64 } %t509, ptr %rv
  br label %ret
bb137:
  %t510 = load i8, ptr %l3, !tbaa !22
  store i8 %t510, ptr %l257, !tbaa !22
  %t511 = load i8, ptr %l257, !tbaa !22
  %t512 = icmp eq i8 %t511, 126
  store i1 %t512, ptr %l258, !tbaa !21
  %t513 = load i1, ptr %l258, !tbaa !21
  br i1 %t513, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s38
  store i32 86, ptr %l259
  %t514 = load i64, ptr %l1, !tbaa !24
  store i64 %t514, ptr %l260, !tbaa !24
  %t515 = load i64, ptr %l260, !tbaa !24
  %t516 = add i64 %t515, 1
  store i64 %t516, ptr %l261, !tbaa !24
  %t517 = load i32, ptr %l259
  %t518 = insertvalue { i32, i64 } undef, i32 %t517, 0
  %t519 = load i64, ptr %l261, !tbaa !24
  %t520 = insertvalue { i32, i64 } %t518, i64 %t519, 1
  store { i32, i64 } %t520, ptr %l262
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s0)
  %t521 = load { i32, i64 }, ptr %l262
  store { i32, i64 } %t521, ptr %rv
  br label %ret
bb141:
  %t522 = load i8, ptr %l3, !tbaa !22
  store i8 %t522, ptr %l263, !tbaa !22
  %t523 = load i8, ptr %l263, !tbaa !22
  %t524 = icmp eq i8 %t523, 36
  store i1 %t524, ptr %l264, !tbaa !21
  %t525 = load i1, ptr %l264, !tbaa !21
  br i1 %t525, label %bb142, label %bb143
bb142:
  br label %bb144
bb143:
  br label %bb145
bb144:
  store %olang.scope zeroinitializer, ptr %s39
  store i32 87, ptr %l265
  %t526 = load i64, ptr %l1, !tbaa !24
  store i64 %t526, ptr %l266, !tbaa !24
  %t527 = load i64, ptr %l266, !tbaa !24
  %t528 = add i64 %t527, 1
  store i64 %t528, ptr %l267, !tbaa !24
  %t529 = load i32, ptr %l265
  %t530 = insertvalue { i32, i64 } undef, i32 %t529, 0
  %t531 = load i64, ptr %l267, !tbaa !24
  %t532 = insertvalue { i32, i64 } %t530, i64 %t531, 1
  store { i32, i64 } %t532, ptr %l268
  call void @__olang_scope_close(ptr %s39)
  call void @__olang_scope_close(ptr %s0)
  %t533 = load { i32, i64 }, ptr %l268
  store { i32, i64 } %t533, ptr %rv
  br label %ret
bb145:
  %t534 = load i8, ptr %l3, !tbaa !22
  store i8 %t534, ptr %l269, !tbaa !22
  %t535 = load i8, ptr %l269, !tbaa !22
  %t536 = icmp eq i8 %t535, 40
  store i1 %t536, ptr %l270, !tbaa !21
  %t537 = load i1, ptr %l270, !tbaa !21
  br i1 %t537, label %bb146, label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s40
  store i32 90, ptr %l271
  %t538 = load i64, ptr %l1, !tbaa !24
  store i64 %t538, ptr %l272, !tbaa !24
  %t539 = load i64, ptr %l272, !tbaa !24
  %t540 = add i64 %t539, 1
  store i64 %t540, ptr %l273, !tbaa !24
  %t541 = load i32, ptr %l271
  %t542 = insertvalue { i32, i64 } undef, i32 %t541, 0
  %t543 = load i64, ptr %l273, !tbaa !24
  %t544 = insertvalue { i32, i64 } %t542, i64 %t543, 1
  store { i32, i64 } %t544, ptr %l274
  call void @__olang_scope_close(ptr %s40)
  call void @__olang_scope_close(ptr %s0)
  %t545 = load { i32, i64 }, ptr %l274
  store { i32, i64 } %t545, ptr %rv
  br label %ret
bb149:
  %t546 = load i8, ptr %l3, !tbaa !22
  store i8 %t546, ptr %l275, !tbaa !22
  %t547 = load i8, ptr %l275, !tbaa !22
  %t548 = icmp eq i8 %t547, 41
  store i1 %t548, ptr %l276, !tbaa !21
  %t549 = load i1, ptr %l276, !tbaa !21
  br i1 %t549, label %bb150, label %bb151
bb150:
  br label %bb152
bb151:
  br label %bb153
bb152:
  store %olang.scope zeroinitializer, ptr %s41
  store i32 91, ptr %l277
  %t550 = load i64, ptr %l1, !tbaa !24
  store i64 %t550, ptr %l278, !tbaa !24
  %t551 = load i64, ptr %l278, !tbaa !24
  %t552 = add i64 %t551, 1
  store i64 %t552, ptr %l279, !tbaa !24
  %t553 = load i32, ptr %l277
  %t554 = insertvalue { i32, i64 } undef, i32 %t553, 0
  %t555 = load i64, ptr %l279, !tbaa !24
  %t556 = insertvalue { i32, i64 } %t554, i64 %t555, 1
  store { i32, i64 } %t556, ptr %l280
  call void @__olang_scope_close(ptr %s41)
  call void @__olang_scope_close(ptr %s0)
  %t557 = load { i32, i64 }, ptr %l280
  store { i32, i64 } %t557, ptr %rv
  br label %ret
bb153:
  %t558 = load i8, ptr %l3, !tbaa !22
  store i8 %t558, ptr %l281, !tbaa !22
  %t559 = load i8, ptr %l281, !tbaa !22
  %t560 = icmp eq i8 %t559, 91
  store i1 %t560, ptr %l282, !tbaa !21
  %t561 = load i1, ptr %l282, !tbaa !21
  br i1 %t561, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s42
  store i32 92, ptr %l283
  %t562 = load i64, ptr %l1, !tbaa !24
  store i64 %t562, ptr %l284, !tbaa !24
  %t563 = load i64, ptr %l284, !tbaa !24
  %t564 = add i64 %t563, 1
  store i64 %t564, ptr %l285, !tbaa !24
  %t565 = load i32, ptr %l283
  %t566 = insertvalue { i32, i64 } undef, i32 %t565, 0
  %t567 = load i64, ptr %l285, !tbaa !24
  %t568 = insertvalue { i32, i64 } %t566, i64 %t567, 1
  store { i32, i64 } %t568, ptr %l286
  call void @__olang_scope_close(ptr %s42)
  call void @__olang_scope_close(ptr %s0)
  %t569 = load { i32, i64 }, ptr %l286
  store { i32, i64 } %t569, ptr %rv
  br label %ret
bb157:
  %t570 = load i8, ptr %l3, !tbaa !22
  store i8 %t570, ptr %l287, !tbaa !22
  %t571 = load i8, ptr %l287, !tbaa !22
  %t572 = icmp eq i8 %t571, 93
  store i1 %t572, ptr %l288, !tbaa !21
  %t573 = load i1, ptr %l288, !tbaa !21
  br i1 %t573, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  store %olang.scope zeroinitializer, ptr %s43
  store i32 93, ptr %l289
  %t574 = load i64, ptr %l1, !tbaa !24
  store i64 %t574, ptr %l290, !tbaa !24
  %t575 = load i64, ptr %l290, !tbaa !24
  %t576 = add i64 %t575, 1
  store i64 %t576, ptr %l291, !tbaa !24
  %t577 = load i32, ptr %l289
  %t578 = insertvalue { i32, i64 } undef, i32 %t577, 0
  %t579 = load i64, ptr %l291, !tbaa !24
  %t580 = insertvalue { i32, i64 } %t578, i64 %t579, 1
  store { i32, i64 } %t580, ptr %l292
  call void @__olang_scope_close(ptr %s43)
  call void @__olang_scope_close(ptr %s0)
  %t581 = load { i32, i64 }, ptr %l292
  store { i32, i64 } %t581, ptr %rv
  br label %ret
bb161:
  %t582 = load i8, ptr %l3, !tbaa !22
  store i8 %t582, ptr %l293, !tbaa !22
  %t583 = load i8, ptr %l293, !tbaa !22
  %t584 = icmp eq i8 %t583, 123
  store i1 %t584, ptr %l294, !tbaa !21
  %t585 = load i1, ptr %l294, !tbaa !21
  br i1 %t585, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  store %olang.scope zeroinitializer, ptr %s44
  store i32 94, ptr %l295
  %t586 = load i64, ptr %l1, !tbaa !24
  store i64 %t586, ptr %l296, !tbaa !24
  %t587 = load i64, ptr %l296, !tbaa !24
  %t588 = add i64 %t587, 1
  store i64 %t588, ptr %l297, !tbaa !24
  %t589 = load i32, ptr %l295
  %t590 = insertvalue { i32, i64 } undef, i32 %t589, 0
  %t591 = load i64, ptr %l297, !tbaa !24
  %t592 = insertvalue { i32, i64 } %t590, i64 %t591, 1
  store { i32, i64 } %t592, ptr %l298
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s0)
  %t593 = load { i32, i64 }, ptr %l298
  store { i32, i64 } %t593, ptr %rv
  br label %ret
bb165:
  %t594 = load i8, ptr %l3, !tbaa !22
  store i8 %t594, ptr %l299, !tbaa !22
  %t595 = load i8, ptr %l299, !tbaa !22
  %t596 = icmp eq i8 %t595, 125
  store i1 %t596, ptr %l300, !tbaa !21
  %t597 = load i1, ptr %l300, !tbaa !21
  br i1 %t597, label %bb166, label %bb167
bb166:
  br label %bb168
bb167:
  br label %bb169
bb168:
  store %olang.scope zeroinitializer, ptr %s45
  store i32 95, ptr %l301
  %t598 = load i64, ptr %l1, !tbaa !24
  store i64 %t598, ptr %l302, !tbaa !24
  %t599 = load i64, ptr %l302, !tbaa !24
  %t600 = add i64 %t599, 1
  store i64 %t600, ptr %l303, !tbaa !24
  %t601 = load i32, ptr %l301
  %t602 = insertvalue { i32, i64 } undef, i32 %t601, 0
  %t603 = load i64, ptr %l303, !tbaa !24
  %t604 = insertvalue { i32, i64 } %t602, i64 %t603, 1
  store { i32, i64 } %t604, ptr %l304
  call void @__olang_scope_close(ptr %s45)
  call void @__olang_scope_close(ptr %s0)
  %t605 = load { i32, i64 }, ptr %l304
  store { i32, i64 } %t605, ptr %rv
  br label %ret
bb169:
  store %olang.scope zeroinitializer, ptr %s46
  store i32 0, ptr %l305
  %t606 = load i64, ptr %l1, !tbaa !24
  store i64 %t606, ptr %l306, !tbaa !24
  %t607 = load i64, ptr %l306, !tbaa !24
  %t608 = add i64 %t607, 1
  store i64 %t608, ptr %l307, !tbaa !24
  %t609 = load i32, ptr %l305
  %t610 = insertvalue { i32, i64 } undef, i32 %t609, 0
  %t611 = load i64, ptr %l307, !tbaa !24
  %t612 = insertvalue { i32, i64 } %t610, i64 %t611, 1
  store { i32, i64 } %t612, ptr %l308
  call void @__olang_scope_close(ptr %s46)
  call void @__olang_scope_close(ptr %s0)
  %t613 = load { i32, i64 }, ptr %l308
  store { i32, i64 } %t613, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i64 @compiler_2fscan_2ewordEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i8
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l9, !tbaa !21
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l12, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t15
  %t19 = load i8, ptr %t18, !tbaa !32
  store i8 %t19, ptr %l13, !tbaa !22
  %t20 = load i8, ptr %l13, !tbaa !22
  %t21 = call i1 @compiler_2fscan_2eisWordChar(i8 %t20)
  store i1 %t21, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t22 = load i1, ptr %l14, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l10, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l15, !tbaa !21
  %t25 = load i1, ptr %l15, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t30 = load i64, ptr %l2, !tbaa !24
  store i64 %t30, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/scan:Diag" @compiler_2fscan_3aDiag_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i8 %a3) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i8
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i8
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i8
  %l12 = alloca %"compiler/scan:Diag"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scan:Diag"
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i8 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l8
  %t2 = load i32, ptr %l8
  store i32 %t2, ptr %l4
  %t3 = load i32, ptr %l1, !tbaa !23
  store i32 %t3, ptr %l9, !tbaa !23
  %t4 = load i32, ptr %l9, !tbaa !23
  store i32 %t4, ptr %l5, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  store i32 %t5, ptr %l10, !tbaa !23
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l6, !tbaa !23
  %t7 = load i8, ptr %l3, !tbaa !22
  store i8 %t7, ptr %l11, !tbaa !22
  %t8 = load i8, ptr %l11, !tbaa !22
  store i8 %t8, ptr %l7, !tbaa !22
  %t9 = load i32, ptr %l4
  %t10 = insertvalue %"compiler/scan:Diag" undef, i32 %t9, 0
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = insertvalue %"compiler/scan:Diag" %t10, i32 %t11, 1
  %t13 = load i32, ptr %l6, !tbaa !23
  %t14 = insertvalue %"compiler/scan:Diag" %t12, i32 %t13, 2
  %t15 = load i8, ptr %l7, !tbaa !22
  %t16 = insertvalue %"compiler/scan:Diag" %t14, i8 %t15, 3
  store %"compiler/scan:Diag" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/scan:Diag", ptr %l12
  store %"compiler/scan:Diag" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:Diag", ptr %rv
  ret %"compiler/scan:Diag" %rr
}

define dso_local %"compiler/scan:Tokens" @compiler_2fscan_3aTokens_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/scan:Tokens"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scan:Tokens"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l8, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t2, ptr %l4, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l9, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t5, ptr %l10, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t7, ptr %l11, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t10 = insertvalue %"compiler/scan:Tokens" undef, { i64, ptr } %t9, 0
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t12 = insertvalue %"compiler/scan:Tokens" %t10, { i64, ptr } %t11, 1
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = insertvalue %"compiler/scan:Tokens" %t12, { i64, ptr } %t13, 2
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = insertvalue %"compiler/scan:Tokens" %t14, { i64, ptr } %t15, 3
  store %"compiler/scan:Tokens" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/scan:Tokens", ptr %l12
  store %"compiler/scan:Tokens" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:Tokens", ptr %rv
  ret %"compiler/scan:Tokens" %rr
}

define dso_local %"compiler/scan:scanner" @compiler_2fscan_3ascanner_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/list:List<compiler/token:Token>"
  %l3 = alloca %"std/prelude/list:List<compiler/scan:Diag>"
  %l4 = alloca %"std/prelude/list:List<std/prelude/text:Char>"
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/list:List<compiler/token:Token>"
  %l9 = alloca %"std/prelude/list:List<compiler/scan:Diag>"
  %l10 = alloca %"std/prelude/list:List<std/prelude/text:Char>"
  %l11 = alloca %"compiler/scan:scanner"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scan:scanner"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t2, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List<compiler/token:Token>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e(ptr %t3)
  store %"std/prelude/list:List<compiler/token:Token>" %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List<compiler/token:Token>", ptr %l8
  store %"std/prelude/list:List<compiler/token:Token>" %t5, ptr %l2
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/list:List<compiler/scan:Diag>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e(ptr %t6)
  store %"std/prelude/list:List<compiler/scan:Diag>" %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List<compiler/scan:Diag>", ptr %l9
  store %"std/prelude/list:List<compiler/scan:Diag>" %t8, ptr %l3
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List<std/prelude/text:Char>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e(ptr %t9)
  store %"std/prelude/list:List<std/prelude/text:Char>" %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load %"std/prelude/list:List<std/prelude/text:Char>", ptr %l10
  store %"std/prelude/list:List<std/prelude/text:Char>" %t11, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = insertvalue %"compiler/scan:scanner" undef, { i64, ptr } %t12, 0
  %t14 = load %"std/prelude/list:List<compiler/token:Token>", ptr %l2
  %t15 = insertvalue %"compiler/scan:scanner" %t13, %"std/prelude/list:List<compiler/token:Token>" %t14, 1
  %t16 = load %"std/prelude/list:List<compiler/scan:Diag>", ptr %l3
  %t17 = insertvalue %"compiler/scan:scanner" %t15, %"std/prelude/list:List<compiler/scan:Diag>" %t16, 2
  %t18 = load %"std/prelude/list:List<std/prelude/text:Char>", ptr %l4
  %t19 = insertvalue %"compiler/scan:scanner" %t17, %"std/prelude/list:List<std/prelude/text:Char>" %t18, 3
  %t20 = load i64, ptr %l5, !tbaa !24
  %t21 = insertvalue %"compiler/scan:scanner" %t19, i64 %t20, 4
  %t22 = load i1, ptr %l6, !tbaa !21
  %t23 = insertvalue %"compiler/scan:scanner" %t21, i1 %t22, 5
  store %"compiler/scan:scanner" %t23, ptr %l11
  call void @__olang_scope_close(ptr %s0)
  %t24 = load %"compiler/scan:scanner", ptr %l11
  store %"compiler/scan:scanner" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:scanner", ptr %rv
  ret %"compiler/scan:scanner" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [52 x i8] c"compiler/scan.olang:126: array length out of range\0A\00"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.c1 = private unnamed_addr constant [52 x i8] c"compiler/scan.olang:127: array length out of range\0A\00"
@.d2 = private constant [22 x i8] c"unexpected character '"
declare void @__olang_sb_put(ptr, ptr, i64)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d3 = private constant [1 x i8] c"'"
declare void @__olang_sb_done(ptr)
@.d4 = private constant [38 x i8] c"non-ASCII byte - olang source is ASCII"
@.d5 = private constant [45 x i8] c"NUL byte in the source - is this a text file?"
@.d6 = private constant [52 x i8] c"carriage return - save the file with LF line endings"
@.d7 = private constant [94 x i8] c"olang has no ';' - a statement ends where its line does; put the next one on a line of its own"
@.d8 = private constant [95 x i8] c"a comma never ends a line - items on different lines are separated by the line break; remove it"
@.d9 = private constant [43 x i8] c"unterminated block comment - '##' closes it"
@.d10 = private constant [27 x i8] c"unterminated string literal"
@.d11 = private constant [62 x i8] c"string literal not closed on its line - write \5Cn for a newline"
@.d12 = private constant [30 x i8] c"unterminated character literal"
@.d13 = private constant [40 x i8] c"character literal not closed on its line"
@.d14 = private constant [23 x i8] c"empty character literal"
@.d15 = private constant [71 x i8] c"character literal holds more than one character - text is written in \22\22"
@.d16 = private constant [17 x i8] c"unknown escape '\5C"
@.d17 = private constant [40 x i8] c"' - the escapes are \5Cn \5Ct \5Cr \5C0 \5C\5C \5C' \5C\22"
@.d18 = private constant [29 x i8] c"'0x' needs hexadecimal digits"
@.d19 = private constant [24 x i8] c"'0b' needs binary digits"
@.d20 = private constant [1 x i8] c"'"
@.d21 = private constant [28 x i8] c"' is not a hexadecimal digit"
@.d22 = private constant [1 x i8] c"'"
@.d23 = private constant [23 x i8] c"' is not a binary digit"
@.d24 = private constant [45 x i8] c"'_' in a number must stand between two digits"
@.d25 = private constant [38 x i8] c"a decimal point needs a digit after it"
@.d26 = private constant [38 x i8] c"a number has at most one decimal point"
@.c27 = private unnamed_addr constant [50 x i8] c"compiler/scan.olang:70: reached unreachable code\0A\00"
@.d28 = private constant [3 x i8] c"L16"
@.d29 = private constant [2 x i8] c"L1"
@.d30 = private constant [2 x i8] c"L3"
@.d31 = private constant [3 x i8] c"L18"
@.d32 = private constant [4 x i8] c"L18a"
@.d33 = private constant [3 x i8] c"L4a"
@.d34 = private constant [3 x i8] c"L14"
@.d35 = private constant [3 x i8] c"L13"
@.d36 = private constant [3 x i8] c"L15"
@.d37 = private constant [4 x i8] c"L10a"
@.d38 = private constant [4 x i8] c"L10c"
@.d39 = private constant [4 x i8] c"L10b"
@.d40 = private constant [3 x i8] c"L12"
@.c41 = private unnamed_addr constant [50 x i8] c"compiler/scan.olang:50: reached unreachable code\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List<compiler/token:Token>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/token:Token>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/token:Token>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/token:Token>" @std_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/token:Token>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/token:Token>", ptr %l0
  store %"std/prelude/list:List<compiler/token:Token>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/token:Token>", ptr %rv
  ret %"std/prelude/list:List<compiler/token:Token>" %rr
}

define linkonce_odr %"std/prelude/list:List<compiler/scan:Diag>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/scan:Diag>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/scan:Diag>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/scan:Diag>" @std_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/scan:Diag>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/scan:Diag>", ptr %l0
  store %"std/prelude/list:List<compiler/scan:Diag>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/scan:Diag>", ptr %rv
  ret %"std/prelude/list:List<compiler/scan:Diag>" %rr
}

define linkonce_odr %"std/prelude/list:List<std/prelude/text:Char>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:Char>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:Char>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:Char>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:Char>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/prelude/text:Char>", ptr %l0
  store %"std/prelude/list:List<std/prelude/text:Char>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:Char>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:Char>" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2eToArray_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2eToArray_3ccompiler_2fscan_3aDiag_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eLe_H123f33f8ddaac384b8a67c2466e49838(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eCl_He62a1125a32dfc5a59291318c690abf4(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2ePush_3ccompiler_2fscan_3aDiag_3e(ptr %v0, ptr %a0, %"compiler/scan:Diag" %a1)
declare i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %a0)
declare %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %v0, i32 %a0, i8 %a1, i32 %a2, i32 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %a0, %"compiler/token:Token" %a1)
@G_2ecompiler_2ftoken_2eLineBreak = external global i8
@G_2ecompiler_2ftoken_2eSpace = external global i8
@G_2ecompiler_2ftoken_2eLineStart = external global i8
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H849b787d6464fd61c7b36d59bd222081(ptr %v0, ptr %a0, i8 %a1)
declare i8 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eAt_Hf7c9ea4b95413b3e180a7d1bf48077d2(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eTr_Hab73bf4217594c1b2a8b440aaf66708e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i8 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePo_H4d205b82f6a792bc14020f9f8d3dea15(ptr %v0, ptr %a0)
declare %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/list:List<compiler/token:Token>" @std_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/scan:Diag>" @std_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<std/prelude/text:Char>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
