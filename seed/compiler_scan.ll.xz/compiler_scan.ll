; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scan:scanner" = type { { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/scan:Diag" = type { i32, i32, i32, i8 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
define dso_local %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/scan:scanner"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/token:Token"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca %"compiler/scan:scanner"
  %l15 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i1
  %l35 = alloca i64
  %l39 = alloca i64
  %l47 = alloca { i64, ptr }
  %l52 = alloca %"compiler/scan:Tokens"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/scan:Tokens"
  %t69 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/scan:scanner" @compiler_2fscan_3ascanner_2ector(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store %"compiler/scan:scanner" %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load %"compiler/scan:scanner", ptr %l12
  store %"compiler/scan:scanner" %t4, ptr %l1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2erun(ptr %s0, ptr %l1)
  br label %bb2
bb2:
  %t6 = getelementptr %"compiler/scan:scanner", ptr %l1, i32 0, i32 1
  %t8 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2eToArray_3ccompiler_2ftoken_3aToken_3e(ptr %s0, ptr %v1, ptr %t6)
  store { i64, ptr } %t8, ptr %l15
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l23, !tbaa !27
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr %"compiler/token:Token", ptr %t28, i64 %t25
  %t30 = load %"compiler/token:Token", ptr %t29
  store %"compiler/token:Token" %t30, ptr %l7
  %t32 = getelementptr %"compiler/token:Token", ptr %l7, i32 0, i32 0
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l26
  store i32 92, ptr %l28
  %t36 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l26, ptr %l28)
  store i1 %t36, ptr %l30
  br label %bb8
bb8:
  %t37 = load i1, ptr %l30, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l5, !tbaa !24
  br label %bb4
bb13:
  %t46 = load i64, ptr %l3, !tbaa !24
  store i64 %t46, ptr %l35, !tbaa !24
  %t47 = load i64, ptr %l35, !tbaa !24
  %t48 = icmp sge i64 %t47, 0
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t50 = load i64, ptr %l35, !tbaa !24
  %t51 = icmp sle i64 %t50, 2305843009213693951
  br i1 %t51, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb16:
  %t53 = load i64, ptr %l35, !tbaa !24
  %t54 = mul i64 %t53, 4
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l8, !tbaa !27
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  %t60 = load i64, ptr %l39, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  br i1 %t61, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb18:
  %t63 = load i64, ptr %l39, !tbaa !24
  %t64 = icmp sle i64 %t63, 2305843009213693951
  br i1 %t64, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb20:
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = mul i64 %t66, 4
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  store i64 0, ptr %t69
  br label %fill.70
fill.70:
  %t73 = load i64, ptr %t69
  %t74 = icmp slt i64 %t73, %t66
  br i1 %t74, label %fillb.71, label %filld.72
fillb.71:
  %t75 = getelementptr i32, ptr %t68, i64 %t73
  store i32 -1, ptr %t75
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %t69
  br label %fill.70
filld.72:
  %t77 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t68, 1
  store { i64, ptr } %t78, ptr %l9, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2fscan_2ematchBraces(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t80, { i64, ptr } %t81, { i64, ptr } %t82)
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb22:
  %t86 = getelementptr %"compiler/scan:scanner", ptr %l1, i32 0, i32 2
  %t88 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2eToArray_3ccompiler_2fscan_3aDiag_3e(ptr %s0, ptr %v1, ptr %t86)
  store { i64, ptr } %t88, ptr %l47
  br label %bb23
bb23:
  %t89 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t98 = call %"compiler/scan:Tokens" @compiler_2fscan_3aTokens_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t90, { i64, ptr } %t91, { i64, ptr } %t92, { i64, ptr } %t89)
  store %"compiler/scan:Tokens" %t98, ptr %l52
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t99 = load %"compiler/scan:Tokens", ptr %l52
  store %"compiler/scan:Tokens" %t99, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:Tokens", ptr %rv
  ret %"compiler/scan:Tokens" %rr
}

define dso_local { i64, i1 } @compiler_2fscan_2eblockComment(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i8
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, i1 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = add i64 %t7, 1
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb15
bb3:
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 35
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = add i64 %t30, 1
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  %t39 = icmp eq i8 %t37, 35
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  %t41 = load i1, ptr %l19, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 2
  %t45 = load i1, ptr %l4, !tbaa !21
  %t47 = insertvalue { i64, i1 } undef, i64 %t44, 0
  %t49 = insertvalue { i64, i1 } %t47, i1 %t45, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, i1 } %t49, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t51 = load i8, ptr %l5, !tbaa !22
  %t53 = icmp eq i8 %t51, 10
  br i1 %t53, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  br label %bb1
bb15:
  %t59 = load i1, ptr %l4, !tbaa !21
  %t60 = insertvalue { i64, i1 } undef, i64 -1, 0
  %t62 = insertvalue { i64, i1 } %t60, i1 %t59, 1
  store { i64, i1 } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i1 }, ptr %rv
  ret { i64, i1 } %rr
}

define dso_local i1 @compiler_2fscan_2ecanStart(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca { i32, i64 }
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l44 = alloca { i32, i64 }
  %l46 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i8, ptr %t5, i64 %t2
  %t7 = load i8, ptr %t6, !tbaa !32
  store i8 %t7, ptr %l2, !tbaa !22
  %t9 = load i8, ptr %l2, !tbaa !22
  %t11 = call i1 @compiler_2fscan_2eisWordChar(i8 %t9)
  store i1 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i8, ptr %l2, !tbaa !22
  %t15 = icmp eq i8 %t13, 32
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t18 = load i8, ptr %l2, !tbaa !22
  %t20 = icmp eq i8 %t18, 9
  store i1 %t20, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb9:
  %t23 = load i8, ptr %l2, !tbaa !22
  %t25 = icmp eq i8 %t23, 10
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb13
bb12:
  %t28 = load i8, ptr %l2, !tbaa !22
  %t30 = icmp eq i8 %t28, 35
  store i1 %t30, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb16
bb15:
  %t33 = load i8, ptr %l2, !tbaa !22
  %t35 = icmp eq i8 %t33, 34
  store i1 %t35, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb19
bb18:
  %t38 = load i8, ptr %l2, !tbaa !22
  %t40 = icmp eq i8 %t38, 39
  store i1 %t40, ptr %l25, !tbaa !21
  br label %bb19
bb19:
  %t42 = load i1, ptr %l25, !tbaa !21
  br i1 %t42, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t44 = load i8, ptr %l2, !tbaa !22
  %t46 = icmp eq i8 %t44, 33
  br i1 %t46, label %bb23, label %bb24
bb23:
  %t48 = load i64, ptr %l1, !tbaa !24
  %t50 = add i64 %t48, 1
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t56 = icmp slt i64 %t50, %t53
  br i1 %t56, label %bb25, label %bb26
bb24:
  br label %bb28
bb25:
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t58, ptr %l37, !tbaa !27
  %t59 = load i64, ptr %l1, !tbaa !24
  %t61 = add i64 %t59, 1
  %t63 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 %t61
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp eq i8 %t66, 61
  store i1 %t68, ptr %l36, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb27
bb27:
  %t70 = load i1, ptr %l36, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
bb28:
  %t71 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call { i32, i64 } @compiler_2fscan_2eoperator(ptr %v0, { i64, ptr } %t71, i64 %t72)
  store { i32, i64 } %t75, ptr %l44
  br label %bb29
bb29:
  %t76 = load { i32, i64 }, ptr %l44
  store { i32, i64 } %t76, ptr %l3
  %t77 = getelementptr { i32, i64 }, ptr %l3, i32 0, i32 0
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l46
  store i32 0, ptr %l48
  %t83 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l46, ptr %l48)
  store i1 %t83, ptr %l50
  br label %bb30
bb30:
  %t84 = load i1, ptr %l50, !tbaa !21
  %t85 = xor i1 %t84, true
  store i1 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %v0, %"compiler/scan:Diag" %a0) #0 {
entry:
  %l0 = alloca %"compiler/scan:Diag"
  %l1 = alloca i8
  %l2 = alloca i32
  %l5 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/scan:Diag" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/scan:Diag", ptr %l0, i32 0, i32 3
  %t2 = load i8, ptr %t1, !tbaa !22
  store i8 %t2, ptr %l1, !tbaa !22
  %t4 = getelementptr %"compiler/scan:Diag", ptr %l0, i32 0, i32 0
  %t5 = load i32, ptr %t4
  store i32 %t5, ptr %l2
  %t7 = load i32, ptr %l2
  %t9 = trunc i64 0 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t12 = load i8, ptr %l1, !tbaa !22
  %t13 = extractvalue { i64, ptr } { i64 22, ptr @.d2 }, 1
  %t14 = extractvalue { i64, ptr } { i64 22, ptr @.d2 }, 0
  %t16 = add i64 %t14, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t13, i64 %t14)
  %t21 = getelementptr i8, ptr %t20, i64 %t14
  store i8 %t12, ptr %t21
  %t22 = getelementptr i8, ptr %t21, i64 1
  call void @olang_textcopy(ptr %t22, ptr %t17, i64 %t18)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t20, 1
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  br label %bb85
bb4:
  %t26 = load i32, ptr %l2
  %t28 = trunc i64 1 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 38, ptr @.d4 }, ptr %l12, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  br label %bb85
bb8:
  %t33 = load i32, ptr %l2
  %t35 = trunc i64 2 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 45, ptr @.d5 }, ptr %l16, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  br label %bb85
bb12:
  %t40 = load i32, ptr %l2
  %t42 = trunc i64 3 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 52, ptr @.d6 }, ptr %l20, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  br label %bb85
bb16:
  %t47 = load i32, ptr %l2
  %t49 = trunc i64 4 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 94, ptr @.d7 }, ptr %l24, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t52, ptr %l5, !tbaa !27
  br label %bb85
bb20:
  %t54 = load i32, ptr %l2
  %t56 = trunc i64 5 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 95, ptr @.d8 }, ptr %l28, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t59, ptr %l5, !tbaa !27
  br label %bb85
bb24:
  %t61 = load i32, ptr %l2
  %t63 = trunc i64 6 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 43, ptr @.d9 }, ptr %l32, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t66, ptr %l5, !tbaa !27
  br label %bb85
bb28:
  %t68 = load i32, ptr %l2
  %t70 = trunc i64 7 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 27, ptr @.d10 }, ptr %l36, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t73, ptr %l5, !tbaa !27
  br label %bb85
bb32:
  %t75 = load i32, ptr %l2
  %t77 = trunc i64 8 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 62, ptr @.d11 }, ptr %l40, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t80, ptr %l5, !tbaa !27
  br label %bb85
bb36:
  %t82 = load i32, ptr %l2
  %t84 = trunc i64 9 to i32
  %t85 = icmp eq i32 %t82, %t84
  br i1 %t85, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 30, ptr @.d12 }, ptr %l44, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  br label %bb85
bb40:
  %t89 = load i32, ptr %l2
  %t91 = trunc i64 10 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 40, ptr @.d13 }, ptr %l48, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t94, ptr %l5, !tbaa !27
  br label %bb85
bb44:
  %t96 = load i32, ptr %l2
  %t98 = trunc i64 11 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 23, ptr @.d14 }, ptr %l52, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t101, ptr %l5, !tbaa !27
  br label %bb85
bb48:
  %t103 = load i32, ptr %l2
  %t105 = trunc i64 12 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 71, ptr @.d15 }, ptr %l56, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t108, ptr %l5, !tbaa !27
  br label %bb85
bb52:
  %t110 = load i32, ptr %l2
  %t112 = trunc i64 13 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t115 = load i8, ptr %l1, !tbaa !22
  %t116 = extractvalue { i64, ptr } { i64 17, ptr @.d16 }, 1
  %t117 = extractvalue { i64, ptr } { i64 17, ptr @.d16 }, 0
  %t119 = add i64 %t117, 1
  %t120 = extractvalue { i64, ptr } { i64 40, ptr @.d17 }, 1
  %t121 = extractvalue { i64, ptr } { i64 40, ptr @.d17 }, 0
  %t122 = add i64 %t119, %t121
  %t123 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t116, i64 %t117)
  %t124 = getelementptr i8, ptr %t123, i64 %t117
  store i8 %t115, ptr %t124
  %t125 = getelementptr i8, ptr %t124, i64 1
  call void @olang_textcopy(ptr %t125, ptr %t120, i64 %t121)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t123, 1
  store { i64, ptr } %t127, ptr %l5, !tbaa !27
  br label %bb85
bb56:
  %t129 = load i32, ptr %l2
  %t131 = trunc i64 14 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store { i64, ptr } { i64 29, ptr @.d18 }, ptr %l64, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t134, ptr %l5, !tbaa !27
  br label %bb85
bb60:
  %t136 = load i32, ptr %l2
  %t138 = trunc i64 15 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  store { i64, ptr } { i64 24, ptr @.d19 }, ptr %l68, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t141, ptr %l5, !tbaa !27
  br label %bb85
bb64:
  %t143 = load i32, ptr %l2
  %t145 = trunc i64 16 to i32
  %t146 = icmp eq i32 %t143, %t145
  br i1 %t146, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t148 = load i8, ptr %l1, !tbaa !22
  %t149 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  %t152 = add i64 %t150, 1
  %t153 = extractvalue { i64, ptr } { i64 28, ptr @.d21 }, 1
  %t154 = extractvalue { i64, ptr } { i64 28, ptr @.d21 }, 0
  %t155 = add i64 %t152, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t149, i64 %t150)
  %t157 = getelementptr i8, ptr %t156, i64 %t150
  store i8 %t148, ptr %t157
  %t158 = getelementptr i8, ptr %t157, i64 1
  call void @olang_textcopy(ptr %t158, ptr %t153, i64 %t154)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t156, 1
  store { i64, ptr } %t160, ptr %l5, !tbaa !27
  br label %bb85
bb68:
  %t162 = load i32, ptr %l2
  %t164 = trunc i64 17 to i32
  %t165 = icmp eq i32 %t162, %t164
  br i1 %t165, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t167 = load i8, ptr %l1, !tbaa !22
  %t168 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 0
  %t171 = add i64 %t169, 1
  %t172 = extractvalue { i64, ptr } { i64 23, ptr @.d23 }, 1
  %t173 = extractvalue { i64, ptr } { i64 23, ptr @.d23 }, 0
  %t174 = add i64 %t171, %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t168, i64 %t169)
  %t176 = getelementptr i8, ptr %t175, i64 %t169
  store i8 %t167, ptr %t176
  %t177 = getelementptr i8, ptr %t176, i64 1
  call void @olang_textcopy(ptr %t177, ptr %t172, i64 %t173)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t175, 1
  store { i64, ptr } %t179, ptr %l5, !tbaa !27
  br label %bb85
bb72:
  %t181 = load i32, ptr %l2
  %t183 = trunc i64 18 to i32
  %t184 = icmp eq i32 %t181, %t183
  br i1 %t184, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  store { i64, ptr } { i64 45, ptr @.d24 }, ptr %l80, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t186, ptr %l5, !tbaa !27
  br label %bb85
bb76:
  %t188 = load i32, ptr %l2
  %t190 = trunc i64 19 to i32
  %t191 = icmp eq i32 %t188, %t190
  br i1 %t191, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  store { i64, ptr } { i64 38, ptr @.d25 }, ptr %l84, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t193, ptr %l5, !tbaa !27
  br label %bb85
bb80:
  %t195 = load i32, ptr %l2
  %t197 = trunc i64 20 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store { i64, ptr } { i64 38, ptr @.d26 }, ptr %l88, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t200, ptr %l5, !tbaa !27
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb85:
  %t202 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 0
  store i64 %t203, ptr %l90, !tbaa !24
  %t204 = load i64, ptr %l90, !tbaa !24
  %t205 = mul i64 %t204, 1
  %t206 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t205)
  %t207 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  store { i64, ptr } %t208, ptr %l91, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = load i64, ptr %l90, !tbaa !24
  %t214 = mul i64 %t213, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t210, ptr %t212, i64 %t214, i1 false)
  %t215 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t215, ptr %l5, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t216, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %v0, %"compiler/scan:Diag" %a0) #0 {
entry:
  %l0 = alloca %"compiler/scan:Diag"
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/scan:Diag" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/scan:Diag", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1
  store i32 %t2, ptr %l1
  %t4 = load i32, ptr %l1
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 3, ptr @.d28 }, ptr %l3, !tbaa !27
  br label %bb69
bb4:
  %t9 = load i32, ptr %l1
  %t11 = trunc i64 1 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t14 = load i32, ptr %l1
  %t16 = trunc i64 2 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } { i64 2, ptr @.d29 }, ptr %l3, !tbaa !27
  br label %bb69
bb10:
  %t19 = load i32, ptr %l1
  %t21 = trunc i64 3 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 2, ptr @.d30 }, ptr %l3, !tbaa !27
  br label %bb69
bb14:
  %t24 = load i32, ptr %l1
  %t26 = trunc i64 4 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 3, ptr @.d31 }, ptr %l3, !tbaa !27
  br label %bb69
bb18:
  %t29 = load i32, ptr %l1
  %t31 = trunc i64 5 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr @.d32 }, ptr %l3, !tbaa !27
  br label %bb69
bb22:
  %t34 = load i32, ptr %l1
  %t36 = trunc i64 6 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 3, ptr @.d33 }, ptr %l3, !tbaa !27
  br label %bb69
bb26:
  %t39 = load i32, ptr %l1
  %t41 = trunc i64 7 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  %t44 = load i32, ptr %l1
  %t46 = trunc i64 8 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 3, ptr @.d34 }, ptr %l3, !tbaa !27
  br label %bb69
bb32:
  %t49 = load i32, ptr %l1
  %t51 = trunc i64 9 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  %t54 = load i32, ptr %l1
  %t56 = trunc i64 10 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  %t59 = load i32, ptr %l1
  %t61 = trunc i64 11 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  %t64 = load i32, ptr %l1
  %t66 = trunc i64 12 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 3, ptr @.d35 }, ptr %l3, !tbaa !27
  br label %bb69
bb42:
  %t69 = load i32, ptr %l1
  %t71 = trunc i64 13 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store { i64, ptr } { i64 3, ptr @.d36 }, ptr %l3, !tbaa !27
  br label %bb69
bb46:
  %t74 = load i32, ptr %l1
  %t76 = trunc i64 14 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb47, label %bb48
bb47:
  br label %bb51
bb48:
  %t79 = load i32, ptr %l1
  %t81 = trunc i64 16 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 4, ptr @.d37 }, ptr %l3, !tbaa !27
  br label %bb69
bb52:
  %t84 = load i32, ptr %l1
  %t86 = trunc i64 15 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb53, label %bb54
bb53:
  br label %bb57
bb54:
  %t89 = load i32, ptr %l1
  %t91 = trunc i64 17 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store { i64, ptr } { i64 4, ptr @.d38 }, ptr %l3, !tbaa !27
  br label %bb69
bb58:
  %t94 = load i32, ptr %l1
  %t96 = trunc i64 18 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store { i64, ptr } { i64 4, ptr @.d39 }, ptr %l3, !tbaa !27
  br label %bb69
bb62:
  %t99 = load i32, ptr %l1
  %t101 = trunc i64 19 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  %t104 = load i32, ptr %l1
  %t106 = trunc i64 20 to i32
  %t107 = icmp eq i32 %t104, %t106
  br i1 %t107, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  store { i64, ptr } { i64 3, ptr @.d40 }, ptr %l3, !tbaa !27
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @.c41)
  unreachable
bb69:
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t109, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:Tokens", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = sub i64 %t6, 1
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp sle i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sdiv i64 %t22, 2
  store i64 %t24, ptr %l4, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scan:Tokens", ptr %t26, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i32, ptr %t33, i64 %t30
  %t35 = load i32, ptr %t34, !tbaa !33
  store i32 %t35, ptr %l5, !tbaa !23
  %t37 = load i32, ptr %l5, !tbaa !23
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = icmp eq i32 %t37, %t38
  br i1 %t41, label %bb5, label %bb6
bb5:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scan:Tokens", ptr %t43, i32 0, i32 2
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l26, !tbaa !27
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 %t47
  %t52 = load i32, ptr %t51, !tbaa !33
  call void @__olang_scope_close(ptr %s1)
  store i32 %t52, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t54 = load i32, ptr %l5, !tbaa !23
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = icmp slt i32 %t54, %t55
  br i1 %t58, label %bb8, label %bb9
bb8:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l2, !tbaa !24
  br label %bb10
bb9:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t66 = sub i64 %t64, 1
  store i64 %t66, ptr %l3, !tbaa !24
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  br label %bb1
bb12:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2echar(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca i8
  %l7 = alloca i64
  %l8 = alloca i64
  %l23 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l67 = alloca i1
  %l87 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l106 = alloca i1
  %l107 = alloca { i64, ptr }
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l122 = alloca i1
  %l123 = alloca { i64, ptr }
  %l127 = alloca i64
  %s12 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = add i64 %t10, 1
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sge i64 %t14, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t20, i32 9, i64 %t21, i64 %t22, i8 0)
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
bb4:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l23, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  store i8 %t35, ptr %l5, !tbaa !22
  %t37 = load i8, ptr %l5, !tbaa !22
  %t39 = icmp eq i8 %t37, 10
  br i1 %t39, label %bb5, label %bb6
bb5:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t41, i32 10, i64 %t42, i64 %t43, i8 0)
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t48 = load i64, ptr %l4, !tbaa !24
  store i64 %t48, ptr %rv
  br label %ret
bb8:
  %t50 = load i8, ptr %l5, !tbaa !22
  %t52 = icmp eq i8 %t50, 39
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l1, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = add i64 %t56, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t54, i32 11, i64 %t55, i64 %t58, i8 0)
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %rv
  br label %ret
bb12:
  %t67 = load i8, ptr %l5, !tbaa !22
  %t69 = icmp eq i8 %t67, 92
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  %t74 = load i64, ptr %l3, !tbaa !24
  %t77 = icmp sge i64 %t73, %t74
  br i1 %t77, label %bb15, label %bb16
bb14:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l4, !tbaa !24
  br label %bb28
bb15:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t83, i32 9, i64 %t84, i64 %t85, i8 0)
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t90 = load i64, ptr %l3, !tbaa !24
  store i64 %t90, ptr %rv
  br label %ret
bb18:
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l53, !tbaa !27
  %t93 = load i64, ptr %l4, !tbaa !24
  %t95 = add i64 %t93, 1
  %t97 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i8, ptr %t98, i64 %t95
  %t100 = load i8, ptr %t99, !tbaa !32
  store i8 %t100, ptr %l6, !tbaa !22
  %t102 = load i8, ptr %l6, !tbaa !22
  %t104 = icmp eq i8 %t102, 10
  br i1 %t104, label %bb19, label %bb20
bb19:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l1, !tbaa !24
  %t108 = load i64, ptr %l4, !tbaa !24
  %t110 = add i64 %t108, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t106, i32 10, i64 %t107, i64 %t110, i8 0)
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t115 = load i64, ptr %l4, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %rv
  br label %ret
bb22:
  %t119 = load i8, ptr %l6, !tbaa !22
  %t121 = call i1 @compiler_2fscan_2eescapeOk(i8 %t119, i8 39)
  store i1 %t121, ptr %l67
  br label %bb23
bb23:
  %t122 = load i1, ptr %l67, !tbaa !21
  %t123 = xor i1 %t122, true
  br i1 %t123, label %bb24, label %bb25
bb24:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i64, ptr %l4, !tbaa !24
  %t127 = load i64, ptr %l4, !tbaa !24
  %t129 = add i64 %t127, 2
  %t130 = load i8, ptr %l6, !tbaa !22
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t125, i32 13, i64 %t126, i64 %t129, i8 %t130)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t136 = load i64, ptr %l4, !tbaa !24
  %t138 = add i64 %t136, 2
  store i64 %t138, ptr %l4, !tbaa !24
  br label %bb28
bb28:
  %t140 = load i64, ptr %l4, !tbaa !24
  %t141 = load i64, ptr %l3, !tbaa !24
  %t144 = icmp sge i64 %t140, %t141
  br i1 %t144, label %bb29, label %bb30
bb29:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i64, ptr %l1, !tbaa !24
  %t148 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t146, i32 9, i64 %t147, i64 %t148, i8 0)
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t153 = load i64, ptr %l3, !tbaa !24
  store i64 %t153, ptr %rv
  br label %ret
bb32:
  %t155 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t155, ptr %l87, !tbaa !27
  %t156 = load i64, ptr %l4, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr i8, ptr %t159, i64 %t156
  %t161 = load i8, ptr %t160, !tbaa !32
  %t163 = icmp eq i8 %t161, 39
  br i1 %t163, label %bb33, label %bb34
bb33:
  %t165 = load i64, ptr %l4, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t169 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t169, ptr %l93, !tbaa !27
  %t170 = load i64, ptr %l4, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i8, ptr %t173, i64 %t170
  %t175 = load i8, ptr %t174, !tbaa !32
  %t177 = icmp eq i8 %t175, 10
  br i1 %t177, label %bb36, label %bb37
bb36:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l1, !tbaa !24
  %t181 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t179, i32 10, i64 %t180, i64 %t181, i8 0)
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t186 = load i64, ptr %l4, !tbaa !24
  store i64 %t186, ptr %rv
  br label %ret
bb39:
  %t188 = load i64, ptr %l4, !tbaa !24
  store i64 %t188, ptr %l7, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s12
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l3, !tbaa !24
  %t194 = icmp slt i64 %t190, %t191
  br i1 %t194, label %bb41, label %bb42
bb41:
  %t196 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t196, ptr %l107, !tbaa !27
  %t197 = load i64, ptr %l7, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i8, ptr %t200, i64 %t197
  %t202 = load i8, ptr %t201, !tbaa !32
  %t204 = icmp ne i8 %t202, 39
  store i1 %t204, ptr %l106, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb43
bb43:
  %t206 = load i1, ptr %l106, !tbaa !21
  br i1 %t206, label %bb44, label %bb45
bb44:
  %t207 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t207, ptr %l112, !tbaa !27
  %t208 = load i64, ptr %l7, !tbaa !24
  %t210 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr i8, ptr %t211, i64 %t208
  %t213 = load i8, ptr %t212, !tbaa !32
  %t215 = icmp ne i8 %t213, 10
  store i1 %t215, ptr %l111, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb46
bb46:
  %t217 = load i1, ptr %l111, !tbaa !21
  %t218 = xor i1 %t217, true
  br i1 %t218, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s12)
  br label %bb51
bb48:
  br label %bb49
bb49:
  %t220 = load i64, ptr %l7, !tbaa !24
  %t222 = add i64 %t220, 1
  store i64 %t222, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb50
bb50:
  br label %bb40
bb51:
  %t224 = load i64, ptr %l7, !tbaa !24
  %t225 = load i64, ptr %l3, !tbaa !24
  %t228 = icmp slt i64 %t224, %t225
  br i1 %t228, label %bb52, label %bb53
bb52:
  %t230 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t230, ptr %l123, !tbaa !27
  %t231 = load i64, ptr %l7, !tbaa !24
  %t233 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i8, ptr %t234, i64 %t231
  %t236 = load i8, ptr %t235, !tbaa !32
  %t238 = icmp eq i8 %t236, 39
  store i1 %t238, ptr %l122, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb54
bb54:
  %t240 = load i1, ptr %l122, !tbaa !21
  br i1 %t240, label %bb55, label %bb56
bb55:
  %t241 = load i64, ptr %l7, !tbaa !24
  %t243 = add i64 %t241, 1
  store i64 %t243, ptr %l127, !tbaa !24
  br label %bb57
bb56:
  %t245 = load i64, ptr %l7, !tbaa !24
  store i64 %t245, ptr %l127, !tbaa !24
  br label %bb57
bb57:
  %t247 = load i64, ptr %l127, !tbaa !24
  store i64 %t247, ptr %l8, !tbaa !24
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i64, ptr %l1, !tbaa !24
  %t250 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t248, i32 12, i64 %t249, i64 %t250, i8 0)
  br label %bb58
bb58:
  %t255 = load i64, ptr %l8, !tbaa !24
  store i64 %t255, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ecloseBeforeDecl(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i32
  %l16 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i32
  %l34 = alloca i32
  %l36 = alloca i1
  %l37 = alloca i32
  %l39 = alloca i32
  %l41 = alloca i1
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 3
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eLe_H123f33f8ddaac384b8a67c2466e49838(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/scan:scanner", ptr %t9, i32 0, i32 4
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = icmp sgt i64 %t12, 0
  store i1 %t14, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load i32, ptr %l1
  store i32 %t17, ptr %l14
  store i32 33, ptr %l16
  %t20 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l14, ptr %l16)
  store i1 %t20, ptr %l18
  br label %bb8
bb8:
  %t21 = load i1, ptr %l18, !tbaa !21
  br i1 %t21, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb12
bb10:
  %t22 = load i32, ptr %l1
  store i32 %t22, ptr %l20
  store i32 41, ptr %l22
  %t25 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l20, ptr %l22)
  store i1 %t25, ptr %l24
  br label %bb11
bb11:
  %t26 = load i1, ptr %l24, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb16
bb14:
  %t28 = load i32, ptr %l1
  store i32 %t28, ptr %l26
  store i32 40, ptr %l28
  %t31 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l26, ptr %l28)
  store i1 %t31, ptr %l30
  br label %bb15
bb15:
  %t32 = load i1, ptr %l30, !tbaa !21
  store i1 %t32, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb20
bb18:
  %t34 = load i32, ptr %l1
  store i32 %t34, ptr %l32
  store i32 43, ptr %l34
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l32, ptr %l34)
  store i1 %t37, ptr %l36
  br label %bb19
bb19:
  %t38 = load i1, ptr %l36, !tbaa !21
  store i1 %t38, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t39 = load i1, ptr %l31, !tbaa !21
  store i1 %t39, ptr %l3, !tbaa !21
  %t40 = load i32, ptr %l1
  store i32 %t40, ptr %l37
  store i32 37, ptr %l39
  %t43 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l37, ptr %l39)
  store i1 %t43, ptr %l41
  br label %bb21
bb21:
  %t44 = load i1, ptr %l41, !tbaa !21
  br i1 %t44, label %bb22, label %bb23
bb22:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/scan:scanner", ptr %t45, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l4, !tbaa !27
  store i64 %a2, ptr %l5, !tbaa !24
  br label %bb24
bb23:
  br label %bb43
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t58 = icmp slt i64 %t52, %t55
  br i1 %t58, label %bb25, label %bb26
bb25:
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t60, ptr %l50, !tbaa !27
  %t61 = load i64, ptr %l5, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 %t61
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp eq i8 %t66, 32
  br i1 %t68, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb30
bb27:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb29
bb28:
  %t70 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t70, ptr %l55, !tbaa !27
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i8, ptr %t74, i64 %t71
  %t76 = load i8, ptr %t75, !tbaa !32
  %t78 = icmp eq i8 %t76, 9
  store i1 %t78, ptr %l54, !tbaa !21
  br label %bb29
bb29:
  %t80 = load i1, ptr %l54, !tbaa !21
  store i1 %t80, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t81 = load i1, ptr %l49, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t84 = load i64, ptr %l5, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  br label %bb24
bb35:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t94 = icmp slt i64 %t88, %t91
  br i1 %t94, label %bb36, label %bb37
bb36:
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t96, ptr %l67, !tbaa !27
  %t97 = load i64, ptr %l5, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i8, ptr %t100, i64 %t97
  %t102 = load i8, ptr %t101, !tbaa !32
  %t104 = call i1 @compiler_2fscan_2eisLetter(i8 %t102)
  store i1 %t104, ptr %l70
  br label %bb38
bb37:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb42
bb38:
  %t105 = load i1, ptr %l70, !tbaa !21
  br i1 %t105, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb41
bb40:
  %t106 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t106, ptr %l72, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i8, ptr %t110, i64 %t107
  %t112 = load i8, ptr %t111, !tbaa !32
  %t114 = icmp eq i8 %t112, 95
  store i1 %t114, ptr %l71, !tbaa !21
  br label %bb41
bb41:
  %t116 = load i1, ptr %l71, !tbaa !21
  store i1 %t116, ptr %l66, !tbaa !21
  br label %bb42
bb42:
  %t117 = load i1, ptr %l66, !tbaa !21
  store i1 %t117, ptr %l3, !tbaa !21
  br label %bb43
bb43:
  %t118 = load i1, ptr %l3, !tbaa !21
  br i1 %t118, label %bb44, label %bb45
bb44:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/scan:scanner", ptr %t120, i32 0, i32 3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eCl_He62a1125a32dfc5a59291318c690abf4(ptr %v0, ptr %t122)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i8 %a4) #0 {
entry:
  %l6 = alloca ptr
  %l13 = alloca %"compiler/scan:Diag"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/scan:scanner", ptr %a0, i32 0, i32 2
  store ptr %t3, ptr %l6, !tbaa !29
  %t7 = trunc i64 %a2 to i32
  %t10 = trunc i64 %a3 to i32
  %t16 = call %"compiler/scan:Diag" @compiler_2fscan_3aDiag_2ector(ptr %s0, i32 %a1, i32 %t7, i32 %t10, i8 %a4)
  store %"compiler/scan:Diag" %t16, ptr %l13
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = load %"compiler/scan:Diag", ptr %l13
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2ePush_3ccompiler_2fscan_3aDiag_3e(ptr %v0, ptr %t17, %"compiler/scan:Diag" %t18)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i8
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l43 = alloca i1
  %l46 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  store i64 %a1, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i8 0, ptr %l7, !tbaa !22
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load i64, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb28
bb3:
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t20, ptr %l19, !tbaa !27
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i8, ptr %t24, i64 %t21
  %t26 = load i8, ptr %t25, !tbaa !32
  store i8 %t26, ptr %l8, !tbaa !22
  %t28 = load i8, ptr %l8, !tbaa !22
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = call i1 @compiler_2fscan_2edigitOf(i8 %t28, i64 %t29)
  store i1 %t32, ptr %l24
  br label %bb5
bb5:
  %t33 = load i1, ptr %l24, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l6, !tbaa !24
  br label %bb26
bb7:
  %t38 = load i8, ptr %l8, !tbaa !22
  %t40 = icmp eq i8 %t38, 95
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load i8, ptr %l7, !tbaa !22
  %t43 = load i64, ptr %l2, !tbaa !24
  %t46 = call i1 @compiler_2fscan_2edigitOf(i8 %t42, i64 %t43)
  store i1 %t46, ptr %l31
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb28
bb10:
  %t47 = load i1, ptr %l31, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t50 = add i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  store i1 %t54, ptr %l32, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb13
bb13:
  %t56 = load i1, ptr %l32, !tbaa !21
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t57 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t57, ptr %l38, !tbaa !27
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = add i64 %t58, 1
  %t62 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i8, ptr %t63, i64 %t60
  %t65 = load i8, ptr %t64, !tbaa !32
  %t66 = load i64, ptr %l2, !tbaa !24
  %t69 = call i1 @compiler_2fscan_2edigitOf(i8 %t65, i64 %t66)
  store i1 %t69, ptr %l43
  br label %bb16
bb15:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb16:
  %t70 = load i1, ptr %l43, !tbaa !21
  store i1 %t70, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t71 = load i1, ptr %l37, !tbaa !21
  %t74 = xor i1 %t71, true
  br i1 %t74, label %bb18, label %bb19
bb18:
  %t76 = load i8, ptr %l7, !tbaa !22
  %t78 = icmp ne i8 %t76, 95
  store i1 %t78, ptr %l46, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t80 = load i1, ptr %l46, !tbaa !21
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t83, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t81, i32 18, i64 %t82, i64 %t85, i8 0)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t90 = load i8, ptr %l8, !tbaa !22
  store i8 %t90, ptr %l7, !tbaa !22
  %t92 = load i64, ptr %l5, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb27:
  br label %bb1
bb28:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = insertvalue { i64, i64 } undef, i64 %t96, 0
  %t101 = insertvalue { i64, i64 } %t99, i64 %t97, 1
  store { i64, i64 } %t101, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i32, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2enumber(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca i1
  %l6 = alloca { i64, i64 }
  %l7 = alloca i64
  %l9 = alloca { i64, i64 }
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, i64 }
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, i64 }
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l31 = alloca { i64, ptr }
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l48 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca i64
  %l55 = alloca i64
  %l56 = alloca { i64, i64 }
  %l61 = alloca ptr
  %l63 = alloca i32
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca i1
  %l81 = alloca ptr
  %l83 = alloca i32
  %l89 = alloca { i64, ptr }
  %l97 = alloca { i64, i64 }
  %l102 = alloca i1
  %l106 = alloca { i64, i64 }
  %l120 = alloca i1
  %l129 = alloca i1
  %l130 = alloca { i64, ptr }
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l144 = alloca i1
  %l145 = alloca { i64, ptr }
  %l149 = alloca i1
  %l150 = alloca { i64, ptr }
  %l158 = alloca i1
  %l161 = alloca { i64, i64 }
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t10, ptr %l22, !tbaa !27
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr i8, ptr %t14, i64 %t11
  %t16 = load i8, ptr %t15, !tbaa !32
  %t18 = icmp eq i8 %t16, 48
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = add i64 %t20, 1
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  store i1 %t26, ptr %l26, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb3
bb3:
  %t28 = load i1, ptr %l26, !tbaa !21
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l31, !tbaa !27
  %t30 = load i64, ptr %l1, !tbaa !24
  %t32 = add i64 %t30, 1
  %t34 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  store i8 %t37, ptr %l4, !tbaa !22
  %t39 = load i8, ptr %l4, !tbaa !22
  %t41 = icmp eq i8 %t39, 120
  br i1 %t41, label %bb6, label %bb7
bb5:
  br label %bb47
bb6:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb8
bb7:
  %t43 = load i8, ptr %l4, !tbaa !22
  %t45 = icmp eq i8 %t43, 88
  store i1 %t45, ptr %l37, !tbaa !21
  br label %bb8
bb8:
  %t47 = load i1, ptr %l37, !tbaa !21
  br i1 %t47, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb11
bb10:
  %t48 = load i8, ptr %l4, !tbaa !22
  %t50 = icmp eq i8 %t48, 98
  store i1 %t50, ptr %l40, !tbaa !21
  br label %bb11
bb11:
  %t52 = load i1, ptr %l40, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb14
bb13:
  %t53 = load i8, ptr %l4, !tbaa !22
  %t55 = icmp eq i8 %t53, 66
  store i1 %t55, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l43, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load i8, ptr %l4, !tbaa !22
  %t60 = icmp eq i8 %t58, 120
  br i1 %t60, label %bb17, label %bb18
bb16:
  br label %bb46
bb17:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb19
bb18:
  %t62 = load i8, ptr %l4, !tbaa !22
  %t64 = icmp eq i8 %t62, 88
  store i1 %t64, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t66 = load i1, ptr %l48, !tbaa !21
  store i1 %t66, ptr %l5, !tbaa !21
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l51, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  %t70 = add i64 %t68, 2
  store i64 %t70, ptr %l53, !tbaa !24
  %t71 = load i1, ptr %l5, !tbaa !21
  br i1 %t71, label %bb20, label %bb21
bb20:
  store i64 16, ptr %l55, !tbaa !24
  br label %bb22
bb21:
  store i64 2, ptr %l55, !tbaa !24
  br label %bb22
bb22:
  %t73 = load ptr, ptr %l51, !tbaa !29
  %t74 = load i64, ptr %l53, !tbaa !24
  %t75 = load i64, ptr %l55, !tbaa !24
  %t76 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t73, i64 %t74, i64 %t75)
  store { i64, i64 } %t76, ptr %l56
  br label %bb23
bb23:
  %t77 = load { i64, i64 }, ptr %l56
  store { i64, i64 } %t77, ptr %l6
  %t78 = getelementptr { i64, i64 }, ptr %l6, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  %t81 = getelementptr { i64, i64 }, ptr %l6, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t86 = icmp eq i64 %t82, 0
  br i1 %t86, label %bb24, label %bb25
bb24:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l61, !tbaa !29
  %t89 = load i1, ptr %l5, !tbaa !21
  br i1 %t89, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  store i32 14, ptr %l63
  br label %bb28
bb27:
  store i32 15, ptr %l63
  br label %bb28
bb28:
  %t93 = load i64, ptr %l1, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load ptr, ptr %l61, !tbaa !29
  %t96 = load i32, ptr %l63
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t95, i32 %t96, i64 %t93, i64 %t94, i8 0)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load i64, ptr %l3, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  br i1 %t103, label %bb31, label %bb32
bb31:
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l72, !tbaa !27
  %t106 = load i64, ptr %l7, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i8, ptr %t109, i64 %t106
  %t111 = load i8, ptr %t110, !tbaa !32
  %t113 = call i1 @compiler_2fscan_2eisDigit(i8 %t111)
  store i1 %t113, ptr %l75
  br label %bb33
bb32:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb38
bb33:
  %t114 = load i1, ptr %l75, !tbaa !21
  br i1 %t114, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb37
bb35:
  %t115 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t115, ptr %l77, !tbaa !27
  %t116 = load i64, ptr %l7, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i8, ptr %t119, i64 %t116
  %t121 = load i8, ptr %t120, !tbaa !32
  %t123 = call i1 @compiler_2fscan_2eisLetter(i8 %t121)
  store i1 %t123, ptr %l80
  br label %bb36
bb36:
  %t124 = load i1, ptr %l80, !tbaa !21
  store i1 %t124, ptr %l76, !tbaa !21
  br label %bb37
bb37:
  %t125 = load i1, ptr %l76, !tbaa !21
  store i1 %t125, ptr %l71, !tbaa !21
  br label %bb38
bb38:
  %t126 = load i1, ptr %l71, !tbaa !21
  br i1 %t126, label %bb39, label %bb40
bb39:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l81, !tbaa !29
  %t128 = load i1, ptr %l5, !tbaa !21
  br i1 %t128, label %bb41, label %bb42
bb40:
  br label %bb45
bb41:
  store i32 16, ptr %l83
  br label %bb43
bb42:
  store i32 17, ptr %l83
  br label %bb43
bb43:
  %t132 = load i64, ptr %l7, !tbaa !24
  %t133 = load i64, ptr %l7, !tbaa !24
  %t135 = add i64 %t133, 1
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t136, ptr %l89, !tbaa !27
  %t137 = load i64, ptr %l7, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i8, ptr %t140, i64 %t137
  %t142 = load i8, ptr %t141, !tbaa !32
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t144 = load i32, ptr %l83
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t143, i32 %t144, i64 %t132, i64 %t135, i8 %t142)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t148 = load i64, ptr %l7, !tbaa !24
  %t150 = insertvalue { i32, i64 } undef, i32 2, 0
  %t152 = insertvalue { i32, i64 } %t150, i64 %t148, 1
  store { i32, i64 } %t152, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i64, ptr %l1, !tbaa !24
  %t158 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t154, i64 %t155, i64 10)
  store { i64, i64 } %t158, ptr %l97
  br label %bb48
bb48:
  %t159 = load { i64, i64 }, ptr %l97
  store { i64, i64 } %t159, ptr %l9
  %t160 = getelementptr { i64, i64 }, ptr %l9, i32 0, i32 0
  %t161 = load i64, ptr %t160, !tbaa !24
  store i64 %t161, ptr %l10, !tbaa !24
  store i32 2, ptr %l11
  %t164 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t165 = load i64, ptr %l10, !tbaa !24
  %t168 = call i1 @compiler_2fscan_2efractionAt(ptr %v0, { i64, ptr } %t164, i64 %t165)
  store i1 %t168, ptr %l102
  br label %bb49
bb49:
  %t169 = load i1, ptr %l102, !tbaa !21
  br i1 %t169, label %bb50, label %bb51
bb50:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i64, ptr %l10, !tbaa !24
  %t173 = add i64 %t171, 1
  %t176 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t170, i64 %t173, i64 10)
  store { i64, i64 } %t176, ptr %l106
  br label %bb52
bb51:
  br label %bb62
bb52:
  %t177 = load { i64, i64 }, ptr %l106
  store { i64, i64 } %t177, ptr %l12
  %t178 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 0
  %t179 = load i64, ptr %t178, !tbaa !24
  store i64 %t179, ptr %l13, !tbaa !24
  %t181 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 1
  %t182 = load i64, ptr %t181, !tbaa !24
  %t186 = icmp eq i64 %t182, 0
  br i1 %t186, label %bb53, label %bb54
bb53:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i64, ptr %l10, !tbaa !24
  %t190 = load i64, ptr %l10, !tbaa !24
  %t192 = add i64 %t190, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t188, i32 19, i64 %t189, i64 %t192, i8 0)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  %t197 = load i64, ptr %l13, !tbaa !24
  store i64 %t197, ptr %l10, !tbaa !24
  store i32 3, ptr %l11
  %t200 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t201 = load i64, ptr %l10, !tbaa !24
  %t204 = call i1 @compiler_2fscan_2efractionAt(ptr %v0, { i64, ptr } %t200, i64 %t201)
  store i1 %t204, ptr %l120
  br label %bb57
bb57:
  %t205 = load i1, ptr %l120, !tbaa !21
  br i1 %t205, label %bb58, label %bb59
bb58:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i64, ptr %l10, !tbaa !24
  %t208 = load i64, ptr %l10, !tbaa !24
  %t210 = add i64 %t208, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t206, i32 20, i64 %t207, i64 %t210, i8 0)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t215 = load i64, ptr %l10, !tbaa !24
  %t216 = load i64, ptr %l3, !tbaa !24
  %t219 = icmp slt i64 %t215, %t216
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t221, ptr %l130, !tbaa !27
  %t222 = load i64, ptr %l10, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i8, ptr %t225, i64 %t222
  %t227 = load i8, ptr %t226, !tbaa !32
  %t229 = icmp eq i8 %t227, 101
  br i1 %t229, label %bb65, label %bb66
bb64:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb68
bb65:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb67
bb66:
  %t231 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t231, ptr %l135, !tbaa !27
  %t232 = load i64, ptr %l10, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i8, ptr %t235, i64 %t232
  %t237 = load i8, ptr %t236, !tbaa !32
  %t239 = icmp eq i8 %t237, 69
  store i1 %t239, ptr %l134, !tbaa !21
  br label %bb67
bb67:
  %t241 = load i1, ptr %l134, !tbaa !21
  store i1 %t241, ptr %l129, !tbaa !21
  br label %bb68
bb68:
  %t242 = load i1, ptr %l129, !tbaa !21
  br i1 %t242, label %bb69, label %bb70
bb69:
  %t243 = load i64, ptr %l10, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l15, !tbaa !24
  %t247 = load i64, ptr %l15, !tbaa !24
  %t248 = load i64, ptr %l3, !tbaa !24
  %t251 = icmp slt i64 %t247, %t248
  br i1 %t251, label %bb71, label %bb72
bb70:
  br label %bb85
bb71:
  %t253 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t253, ptr %l145, !tbaa !27
  %t254 = load i64, ptr %l15, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr i8, ptr %t257, i64 %t254
  %t259 = load i8, ptr %t258, !tbaa !32
  %t261 = icmp eq i8 %t259, 43
  br i1 %t261, label %bb73, label %bb74
bb72:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb76
bb73:
  store i1 true, ptr %l149, !tbaa !21
  br label %bb75
bb74:
  %t263 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t263, ptr %l150, !tbaa !27
  %t264 = load i64, ptr %l15, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i8, ptr %t267, i64 %t264
  %t269 = load i8, ptr %t268, !tbaa !32
  %t271 = icmp eq i8 %t269, 45
  store i1 %t271, ptr %l149, !tbaa !21
  br label %bb75
bb75:
  %t273 = load i1, ptr %l149, !tbaa !21
  store i1 %t273, ptr %l144, !tbaa !21
  br label %bb76
bb76:
  %t274 = load i1, ptr %l144, !tbaa !21
  br i1 %t274, label %bb77, label %bb78
bb77:
  %t275 = load i64, ptr %l15, !tbaa !24
  %t277 = add i64 %t275, 1
  store i64 %t277, ptr %l15, !tbaa !24
  br label %bb79
bb78:
  br label %bb79
bb79:
  %t279 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t280 = load i64, ptr %l15, !tbaa !24
  %t283 = call i1 @compiler_2fscan_2eexponentDigits(ptr %v0, { i64, ptr } %t279, i64 %t280)
  store i1 %t283, ptr %l158
  br label %bb80
bb80:
  %t284 = load i1, ptr %l158, !tbaa !21
  br i1 %t284, label %bb81, label %bb82
bb81:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load i64, ptr %l15, !tbaa !24
  %t289 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t285, i64 %t286, i64 10)
  store { i64, i64 } %t289, ptr %l161
  br label %bb83
bb82:
  br label %bb84
bb83:
  %t290 = load { i64, i64 }, ptr %l161
  store { i64, i64 } %t290, ptr %l16
  %t291 = getelementptr { i64, i64 }, ptr %l16, i32 0, i32 0
  %t292 = load i64, ptr %t291, !tbaa !24
  %t296 = insertvalue { i32, i64 } undef, i32 3, 0
  %t298 = insertvalue { i32, i64 } %t296, i64 %t292, 1
  store { i32, i64 } %t298, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t300 = load i32, ptr %l11
  %t301 = load i64, ptr %l10, !tbaa !24
  %t303 = insertvalue { i32, i64 } undef, i32 %t300, 0
  %t305 = insertvalue { i32, i64 } %t303, i64 %t301, 1
  store { i32, i64 } %t305, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca { i64, i1 }
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i8
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca { i32, i64 }
  %l16 = alloca { i32, i64 }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i8
  %l21 = alloca i1
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, i1 }
  %l75 = alloca i64
  %l83 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca i1
  %l97 = alloca i64
  %l98 = alloca i32
  %l100 = alloca i32
  %l102 = alloca i1
  %l103 = alloca i32
  %l110 = alloca i32
  %l112 = alloca i1
  %l115 = alloca { i32, i64 }
  %l123 = alloca i64
  %l129 = alloca i64
  %l132 = alloca { i32, i64 }
  %l135 = alloca i32
  %l137 = alloca i32
  %l139 = alloca i1
  %l150 = alloca i1
  %l152 = alloca i64
  %l156 = alloca ptr
  %l162 = alloca %"compiler/token:Token"
  %l180 = alloca i64
  %l183 = alloca i32
  %l187 = alloca i32
  %l208 = alloca i1
  %l209 = alloca { i64, ptr }
  %l219 = alloca i1
  %l226 = alloca i1
  %l227 = alloca i32
  %l229 = alloca i32
  %l231 = alloca i1
  %l238 = alloca i1
  %l240 = alloca i1
  %l241 = alloca i1
  %l242 = alloca i32
  %l244 = alloca i32
  %l246 = alloca i1
  %l249 = alloca ptr
  %l255 = alloca %"compiler/token:Token"
  %l257 = alloca ptr
  %l264 = alloca %"compiler/token:Token"
  %l270 = alloca i32
  %l272 = alloca i32
  %l274 = alloca i1
  %l281 = alloca i1
  %l283 = alloca ptr
  %l289 = alloca %"compiler/token:Token"
  %l291 = alloca ptr
  %l298 = alloca %"compiler/token:Token"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  store i32 0, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t19, ptr %l31, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l7, !tbaa !22
  %t27 = load i8, ptr %l7, !tbaa !22
  %t29 = icmp eq i8 %t27, 32
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb8
bb7:
  %t31 = load i8, ptr %l7, !tbaa !22
  %t33 = icmp eq i8 %t31, 9
  store i1 %t33, ptr %l36, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l36, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb35
bb10:
  %t40 = load i8, ptr %l7, !tbaa !22
  %t42 = icmp eq i8 %t40, 10
  br i1 %t42, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l4, !tbaa !21
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l3, !tbaa !24
  br label %bb34
bb12:
  %t48 = load i8, ptr %l7, !tbaa !22
  %t50 = icmp eq i8 %t48, 35
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  %t55 = load i64, ptr %l2, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  br i1 %t58, label %bb15, label %bb16
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb15:
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t60, ptr %l52, !tbaa !27
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = add i64 %t61, 1
  %t65 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i8, ptr %t66, i64 %t63
  %t68 = load i8, ptr %t67, !tbaa !32
  %t70 = icmp eq i8 %t68, 35
  store i1 %t70, ptr %l51, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb17
bb17:
  %t72 = load i1, ptr %l51, !tbaa !21
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = add i64 %t74, 2
  %t79 = call { i64, i1 } @compiler_2fscan_2eblockComment(ptr %v0, { i64, ptr } %t73, i64 %t76)
  store { i64, i1 } %t79, ptr %l60
  br label %bb20
bb19:
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t81 = load i64, ptr %l3, !tbaa !24
  %t84 = call i64 @compiler_2fscan_2elineEnd(ptr %v0, { i64, ptr } %t80, i64 %t81)
  store i64 %t84, ptr %l75
  br label %bb28
bb20:
  %t85 = load { i64, i1 }, ptr %l60
  store { i64, i1 } %t85, ptr %l8
  %t86 = getelementptr { i64, i1 }, ptr %l8, i32 0, i32 0
  %t87 = load i64, ptr %t86, !tbaa !24
  store i64 %t87, ptr %l9, !tbaa !24
  %t89 = getelementptr { i64, i1 }, ptr %l8, i32 0, i32 1
  %t90 = load i1, ptr %t89, !tbaa !21
  store i1 %t90, ptr %l10, !tbaa !21
  %t92 = load i64, ptr %l9, !tbaa !24
  %t94 = icmp slt i64 %t92, 0
  br i1 %t94, label %bb21, label %bb22
bb21:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load i64, ptr %l3, !tbaa !24
  %t100 = add i64 %t98, 2
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t96, i32 6, i64 %t97, i64 %t100, i8 0)
  br label %bb23
bb22:
  %t105 = load i1, ptr %l10, !tbaa !21
  br i1 %t105, label %bb24, label %bb25
bb23:
  %t107 = load i64, ptr %l2, !tbaa !24
  store i64 %t107, ptr %l3, !tbaa !24
  br label %bb27
bb24:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t109 = load i64, ptr %l9, !tbaa !24
  store i64 %t109, ptr %l3, !tbaa !24
  br label %bb27
bb27:
  br label %bb32
bb28:
  %t111 = load i64, ptr %l75, !tbaa !24
  store i64 %t111, ptr %l3, !tbaa !24
  %t112 = load i64, ptr %l3, !tbaa !24
  %t113 = load i64, ptr %l2, !tbaa !24
  %t116 = icmp eq i64 %t112, %t113
  br i1 %t116, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb36:
  br label %bb2
bb37:
  %t118 = load i64, ptr %l3, !tbaa !24
  %t119 = load i64, ptr %l2, !tbaa !24
  %t122 = icmp sge i64 %t118, %t119
  br i1 %t122, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s1)
  br label %bb144
bb39:
  br label %bb40
bb40:
  %t124 = load i64, ptr %l3, !tbaa !24
  store i64 %t124, ptr %l11, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t126, ptr %l83, !tbaa !27
  %t127 = load i64, ptr %l3, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i8, ptr %t130, i64 %t127
  %t132 = load i8, ptr %t131, !tbaa !32
  store i8 %t132, ptr %l12, !tbaa !22
  store i32 0, ptr %l13
  %t135 = load i64, ptr %l3, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l14, !tbaa !24
  %t139 = load i8, ptr %l12, !tbaa !22
  %t141 = call i1 @compiler_2fscan_2eisLetter(i8 %t139)
  store i1 %t141, ptr %l90
  br label %bb41
bb41:
  %t142 = load i1, ptr %l90, !tbaa !21
  br i1 %t142, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb44
bb43:
  %t143 = load i8, ptr %l12, !tbaa !22
  %t145 = icmp eq i8 %t143, 95
  store i1 %t145, ptr %l91, !tbaa !21
  br label %bb44
bb44:
  %t147 = load i1, ptr %l91, !tbaa !21
  br i1 %t147, label %bb45, label %bb46
bb45:
  %t148 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t149 = load i64, ptr %l3, !tbaa !24
  %t151 = add i64 %t149, 1
  %t154 = call i64 @compiler_2fscan_2ewordEnd(ptr %v0, { i64, ptr } %t148, i64 %t151)
  store i64 %t154, ptr %l97
  br label %bb47
bb46:
  %t155 = load i8, ptr %l12, !tbaa !22
  %t157 = call i1 @compiler_2fscan_2eisDigit(i8 %t155)
  store i1 %t157, ptr %l112
  br label %bb53
bb47:
  %t158 = load i64, ptr %l97, !tbaa !24
  store i64 %t158, ptr %l14, !tbaa !24
  %t159 = load i32, ptr %l5
  store i32 %t159, ptr %l98
  store i32 56, ptr %l100
  %t162 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l98, ptr %l100)
  store i1 %t162, ptr %l102
  br label %bb48
bb48:
  %t163 = load i1, ptr %l102, !tbaa !21
  br i1 %t163, label %bb49, label %bb50
bb49:
  store i32 1, ptr %l103
  br label %bb52
bb50:
  %t165 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t166 = load i64, ptr %l3, !tbaa !24
  %t167 = load i64, ptr %l14, !tbaa !24
  %t168 = load i64, ptr %l3, !tbaa !24
  %t171 = sub i64 %t167, %t168
  %t175 = call i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %t165, i64 %t166, i64 %t171)
  store i32 %t175, ptr %l110
  br label %bb51
bb51:
  %t176 = load i32, ptr %l110
  store i32 %t176, ptr %l103
  br label %bb52
bb52:
  %t177 = load i32, ptr %l103
  store i32 %t177, ptr %l13
  br label %bb99
bb53:
  %t178 = load i1, ptr %l112, !tbaa !21
  br i1 %t178, label %bb54, label %bb55
bb54:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l3, !tbaa !24
  %t183 = call { i32, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2enumber(ptr %v0, ptr %t179, i64 %t180)
  store { i32, i64 } %t183, ptr %l115
  br label %bb56
bb55:
  %t184 = load i8, ptr %l12, !tbaa !22
  %t186 = icmp eq i8 %t184, 34
  br i1 %t186, label %bb57, label %bb58
bb56:
  %t188 = load { i32, i64 }, ptr %l115
  store { i32, i64 } %t188, ptr %l15
  %t189 = getelementptr { i32, i64 }, ptr %l15, i32 0, i32 0
  %t190 = load i32, ptr %t189
  store i32 %t190, ptr %l13
  %t192 = getelementptr { i32, i64 }, ptr %l15, i32 0, i32 1
  %t193 = load i64, ptr %t192, !tbaa !24
  store i64 %t193, ptr %l14, !tbaa !24
  br label %bb98
bb57:
  store i32 5, ptr %l13
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i64, ptr %l3, !tbaa !24
  %t200 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2estr(ptr %v0, ptr %t196, i64 %t197)
  store i64 %t200, ptr %l123
  br label %bb59
bb58:
  %t201 = load i8, ptr %l12, !tbaa !22
  %t203 = icmp eq i8 %t201, 39
  br i1 %t203, label %bb60, label %bb61
bb59:
  %t205 = load i64, ptr %l123, !tbaa !24
  store i64 %t205, ptr %l14, !tbaa !24
  br label %bb97
bb60:
  store i32 4, ptr %l13
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i64, ptr %l3, !tbaa !24
  %t211 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2echar(ptr %v0, ptr %t207, i64 %t208)
  store i64 %t211, ptr %l129
  br label %bb62
bb61:
  %t212 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t213 = load i64, ptr %l3, !tbaa !24
  %t216 = call { i32, i64 } @compiler_2fscan_2eoperator(ptr %v0, { i64, ptr } %t212, i64 %t213)
  store { i32, i64 } %t216, ptr %l132
  br label %bb63
bb62:
  %t217 = load i64, ptr %l129, !tbaa !24
  store i64 %t217, ptr %l14, !tbaa !24
  br label %bb96
bb63:
  %t218 = load { i32, i64 }, ptr %l132
  store { i32, i64 } %t218, ptr %l16
  %t219 = getelementptr { i32, i64 }, ptr %l16, i32 0, i32 0
  %t220 = load i32, ptr %t219
  store i32 %t220, ptr %l13
  %t222 = getelementptr { i32, i64 }, ptr %l16, i32 0, i32 1
  %t223 = load i64, ptr %t222, !tbaa !24
  store i64 %t223, ptr %l14, !tbaa !24
  %t225 = load i32, ptr %l13
  store i32 %t225, ptr %l135
  store i32 0, ptr %l137
  %t228 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l135, ptr %l137)
  store i1 %t228, ptr %l139
  br label %bb64
bb64:
  %t229 = load i1, ptr %l139, !tbaa !21
  br i1 %t229, label %bb65, label %bb66
bb65:
  %t230 = load i8, ptr %l12, !tbaa !22
  %t232 = icmp eq i8 %t230, 59
  br i1 %t232, label %bb67, label %bb68
bb66:
  br label %bb95
bb67:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i64, ptr %l3, !tbaa !24
  %t236 = load i64, ptr %l3, !tbaa !24
  %t238 = add i64 %t236, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t234, i32 4, i64 %t235, i64 %t238, i8 0)
  br label %bb69
bb68:
  %t243 = load i8, ptr %l12, !tbaa !22
  %t245 = icmp eq i8 %t243, 13
  br i1 %t245, label %bb79, label %bb80
bb69:
  %t247 = load i64, ptr %l3, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l3, !tbaa !24
  %t251 = load i32, ptr %l5
  %t253 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %t251)
  store i1 %t253, ptr %l150
  br label %bb70
bb70:
  %t254 = load i1, ptr %l150, !tbaa !21
  br i1 %t254, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s26
  %t255 = load i1, ptr %l4, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb72:
  br label %bb78
bb73:
  %t257 = load i64, ptr %l6, !tbaa !24
  store i64 %t257, ptr %l152, !tbaa !24
  br label %bb75
bb74:
  %t259 = load i64, ptr %l11, !tbaa !24
  store i64 %t259, ptr %l152, !tbaa !24
  br label %bb75
bb75:
  %t261 = load i64, ptr %l152, !tbaa !24
  store i64 %t261, ptr %l17, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/scan:scanner", ptr %t262, i32 0, i32 1
  store ptr %t264, ptr %l156, !tbaa !29
  %t265 = load i64, ptr %l17, !tbaa !24
  %t267 = trunc i64 %t265 to i32
  %t268 = load i64, ptr %l17, !tbaa !24
  %t270 = trunc i64 %t268 to i32
  %t274 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s26, i32 8, i8 0, i32 %t267, i32 %t270)
  store %"compiler/token:Token" %t274, ptr %l162
  br label %bb76
bb76:
  %t275 = load ptr, ptr %l156, !tbaa !29
  %t276 = load %"compiler/token:Token", ptr %l162
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t275, %"compiler/token:Token" %t276)
  br label %bb77
bb77:
  store i32 8, ptr %l5
  call void @__olang_scope_close(ptr %s26)
  br label %bb78
bb78:
  br label %bb94
bb79:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/scan:scanner", ptr %t278, i32 0, i32 5
  %t281 = load i1, ptr %t280, !tbaa !21
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb81, label %bb82
bb80:
  %t285 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t286 = load i64, ptr %l3, !tbaa !24
  %t288 = add i64 %t286, 1
  %t291 = call i64 @compiler_2fscan_2ejunkEnd(ptr %v0, { i64, ptr } %t285, i64 %t288)
  store i64 %t291, ptr %l180
  br label %bb85
bb81:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load i64, ptr %l3, !tbaa !24
  %t294 = load i64, ptr %l3, !tbaa !24
  %t296 = add i64 %t294, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t292, i32 3, i64 %t293, i64 %t296, i8 0)
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb84
bb84:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/scan:scanner", ptr %t301, i32 0, i32 5
  store i1 true, ptr %t303, !tbaa !21
  %t304 = load i64, ptr %l3, !tbaa !24
  %t306 = add i64 %t304, 1
  store i64 %t306, ptr %l3, !tbaa !24
  br label %bb93
bb85:
  %t308 = load i64, ptr %l180, !tbaa !24
  store i64 %t308, ptr %l18, !tbaa !24
  %t309 = load i8, ptr %l12, !tbaa !22
  %t311 = icmp eq i8 %t309, 0
  br i1 %t311, label %bb86, label %bb87
bb86:
  store i32 2, ptr %l183
  br label %bb91
bb87:
  %t314 = load i8, ptr %l12, !tbaa !22
  %t316 = icmp uge i8 %t314, -128
  br i1 %t316, label %bb88, label %bb89
bb88:
  store i32 1, ptr %l187
  br label %bb90
bb89:
  store i32 0, ptr %l187
  br label %bb90
bb90:
  %t320 = load i32, ptr %l187
  store i32 %t320, ptr %l183
  br label %bb91
bb91:
  %t321 = load i32, ptr %l183
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i64, ptr %l3, !tbaa !24
  %t325 = load i64, ptr %l18, !tbaa !24
  %t326 = load i8, ptr %l12, !tbaa !22
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t322, i32 %t321, i64 %t324, i64 %t325, i8 %t326)
  br label %bb92
bb92:
  %t332 = load i64, ptr %l18, !tbaa !24
  store i64 %t332, ptr %l3, !tbaa !24
  br label %bb93
bb93:
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s1)
  br label %bb143
bb95:
  br label %bb96
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  br label %bb99
bb99:
  store i8 0, ptr %l20, !tbaa !22
  %t334 = load i1, ptr %l4, !tbaa !21
  br i1 %t334, label %bb100, label %bb101
bb100:
  %t336 = load i8, ptr %l20, !tbaa !22
  %t337 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t340 = or i8 %t336, %t337
  store i8 %t340, ptr %l20, !tbaa !22
  br label %bb102
bb101:
  br label %bb102
bb102:
  %t342 = load i64, ptr %l11, !tbaa !24
  %t343 = load i64, ptr %l6, !tbaa !24
  %t346 = icmp sgt i64 %t342, %t343
  br i1 %t346, label %bb103, label %bb104
bb103:
  %t348 = load i8, ptr %l20, !tbaa !22
  %t349 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t352 = or i8 %t348, %t349
  store i8 %t352, ptr %l20, !tbaa !22
  br label %bb105
bb104:
  br label %bb105
bb105:
  %t354 = load i64, ptr %l11, !tbaa !24
  %t356 = icmp eq i64 %t354, 0
  br i1 %t356, label %bb106, label %bb107
bb106:
  store i1 true, ptr %l208, !tbaa !21
  br label %bb108
bb107:
  %t358 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t358, ptr %l209, !tbaa !27
  %t359 = load i64, ptr %l11, !tbaa !24
  %t361 = sub i64 %t359, 1
  %t363 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr i8, ptr %t364, i64 %t361
  %t366 = load i8, ptr %t365, !tbaa !32
  %t368 = icmp eq i8 %t366, 10
  store i1 %t368, ptr %l208, !tbaa !21
  br label %bb108
bb108:
  %t370 = load i1, ptr %l208, !tbaa !21
  store i1 %t370, ptr %l21, !tbaa !21
  %t371 = load i1, ptr %l21, !tbaa !21
  br i1 %t371, label %bb109, label %bb110
bb109:
  %t373 = load i8, ptr %l20, !tbaa !22
  %t374 = load i8, ptr @G_2ecompiler_2ftoken_2eLineStart, !tbaa !22
  %t377 = or i8 %t373, %t374
  store i8 %t377, ptr %l20, !tbaa !22
  br label %bb111
bb110:
  br label %bb111
bb111:
  %t379 = load i1, ptr %l21, !tbaa !21
  br i1 %t379, label %bb112, label %bb113
bb112:
  %t381 = load i64, ptr %l11, !tbaa !24
  %t383 = icmp sgt i64 %t381, 0
  store i1 %t383, ptr %l219, !tbaa !21
  br label %bb114
bb113:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb114
bb114:
  %t385 = load i1, ptr %l219, !tbaa !21
  br i1 %t385, label %bb115, label %bb116
bb115:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load i32, ptr %l13
  %t388 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ecloseBeforeDecl(ptr %v0, ptr %t386, i32 %t387, i64 %t388)
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb118
bb118:
  %t392 = load i1, ptr %l4, !tbaa !21
  br i1 %t392, label %bb119, label %bb120
bb119:
  %t394 = load i32, ptr %l5
  store i32 %t394, ptr %l227
  store i32 55, ptr %l229
  %t397 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l227, ptr %l229)
  store i1 %t397, ptr %l231
  br label %bb121
bb120:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb122
bb121:
  %t398 = load i1, ptr %l231, !tbaa !21
  store i1 %t398, ptr %l226, !tbaa !21
  br label %bb122
bb122:
  %t399 = load i1, ptr %l226, !tbaa !21
  br i1 %t399, label %bb123, label %bb124
bb123:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load i64, ptr %l6, !tbaa !24
  %t403 = sub i64 %t401, 1
  %t404 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t400, i32 5, i64 %t403, i64 %t404, i8 0)
  br label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb126
bb126:
  %t409 = load i1, ptr %l4, !tbaa !21
  br i1 %t409, label %bb127, label %bb128
bb127:
  %t411 = load i32, ptr %l5
  %t413 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %t411)
  store i1 %t413, ptr %l240
  br label %bb129
bb128:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb130
bb129:
  %t414 = load i1, ptr %l240, !tbaa !21
  store i1 %t414, ptr %l238, !tbaa !21
  br label %bb130
bb130:
  %t415 = load i1, ptr %l238, !tbaa !21
  br i1 %t415, label %bb131, label %bb132
bb131:
  %t416 = load i32, ptr %l13
  store i32 %t416, ptr %l242
  store i32 13, ptr %l244
  %t419 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l242, ptr %l244)
  store i1 %t419, ptr %l246
  br label %bb133
bb132:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb134
bb133:
  %t420 = load i1, ptr %l246, !tbaa !21
  %t421 = xor i1 %t420, true
  store i1 %t421, ptr %l241, !tbaa !21
  br label %bb134
bb134:
  %t423 = load i1, ptr %l241, !tbaa !21
  br i1 %t423, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s36
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/scan:scanner", ptr %t424, i32 0, i32 1
  store ptr %t426, ptr %l249, !tbaa !29
  %t427 = load i64, ptr %l6, !tbaa !24
  %t429 = trunc i64 %t427 to i32
  %t430 = load i64, ptr %l6, !tbaa !24
  %t432 = trunc i64 %t430 to i32
  %t436 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s36, i32 8, i8 0, i32 %t429, i32 %t432)
  store %"compiler/token:Token" %t436, ptr %l255
  br label %bb137
bb136:
  br label %bb139
bb137:
  %t437 = load ptr, ptr %l249, !tbaa !29
  %t438 = load %"compiler/token:Token", ptr %l255
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t437, %"compiler/token:Token" %t438)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s36)
  br label %bb139
bb139:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/scan:scanner", ptr %t439, i32 0, i32 1
  store ptr %t441, ptr %l257, !tbaa !29
  %t442 = load i32, ptr %l13
  %t443 = load i8, ptr %l20, !tbaa !22
  %t444 = load i64, ptr %l11, !tbaa !24
  %t446 = trunc i64 %t444 to i32
  %t447 = load i64, ptr %l14, !tbaa !24
  %t449 = trunc i64 %t447 to i32
  %t454 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s1, i32 %t442, i8 %t443, i32 %t446, i32 %t449)
  store %"compiler/token:Token" %t454, ptr %l264
  br label %bb140
bb140:
  %t455 = load ptr, ptr %l257, !tbaa !29
  %t456 = load %"compiler/token:Token", ptr %l264
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t455, %"compiler/token:Token" %t456)
  br label %bb141
bb141:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load i32, ptr %l13
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2etrack(ptr %v0, ptr %t457, i32 %t458)
  br label %bb142
bb142:
  %t461 = load i32, ptr %l13
  store i32 %t461, ptr %l5
  %t463 = load i64, ptr %l14, !tbaa !24
  store i64 %t463, ptr %l6, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  %t465 = load i64, ptr %l14, !tbaa !24
  store i64 %t465, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb143
bb143:
  br label %bb1
bb144:
  %t467 = load i32, ptr %l5
  store i32 %t467, ptr %l270
  store i32 55, ptr %l272
  %t470 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l270, ptr %l272)
  store i1 %t470, ptr %l274
  br label %bb145
bb145:
  %t471 = load i1, ptr %l274, !tbaa !21
  br i1 %t471, label %bb146, label %bb147
bb146:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load i64, ptr %l6, !tbaa !24
  %t475 = sub i64 %t473, 1
  %t476 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t472, i32 5, i64 %t475, i64 %t476, i8 0)
  br label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb149
bb149:
  %t481 = load i32, ptr %l5
  %t483 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %t481)
  store i1 %t483, ptr %l281
  br label %bb150
bb150:
  %t484 = load i1, ptr %l281, !tbaa !21
  br i1 %t484, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s38
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/scan:scanner", ptr %t485, i32 0, i32 1
  store ptr %t487, ptr %l283, !tbaa !29
  %t488 = load i64, ptr %l6, !tbaa !24
  %t490 = trunc i64 %t488 to i32
  %t491 = load i64, ptr %l6, !tbaa !24
  %t493 = trunc i64 %t491 to i32
  %t497 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s38, i32 8, i8 0, i32 %t490, i32 %t493)
  store %"compiler/token:Token" %t497, ptr %l289
  br label %bb153
bb152:
  br label %bb155
bb153:
  %t498 = load ptr, ptr %l283, !tbaa !29
  %t499 = load %"compiler/token:Token", ptr %l289
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t498, %"compiler/token:Token" %t499)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s38)
  br label %bb155
bb155:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/scan:scanner", ptr %t500, i32 0, i32 1
  store ptr %t502, ptr %l291, !tbaa !29
  %t503 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t504 = load i64, ptr %l2, !tbaa !24
  %t506 = trunc i64 %t504 to i32
  %t507 = load i64, ptr %l2, !tbaa !24
  %t509 = trunc i64 %t507 to i32
  %t514 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s0, i32 0, i8 %t503, i32 %t506, i32 %t509)
  store %"compiler/token:Token" %t514, ptr %l298
  br label %bb156
bb156:
  %t515 = load ptr, ptr %l291, !tbaa !29
  %t516 = load %"compiler/token:Token", ptr %l298
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t515, %"compiler/token:Token" %t516)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2estr(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca i8
  %l21 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l60 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = add i64 %t10, 1
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sge i64 %t14, %t15
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t20, i32 7, i64 %t21, i64 %t22, i8 0)
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t27 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t27, ptr %rv
  br label %ret
bb5:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l21, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  store i8 %t35, ptr %l5, !tbaa !22
  %t37 = load i8, ptr %l5, !tbaa !22
  %t39 = icmp eq i8 %t37, 34
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t41, 1
  call void @__olang_scope_close(ptr %s1)
  store i64 %t43, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t45 = load i8, ptr %l5, !tbaa !22
  %t47 = icmp eq i8 %t45, 10
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t49, i32 8, i64 %t50, i64 %t51, i8 0)
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t56 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t56, ptr %rv
  br label %ret
bb12:
  %t58 = load i8, ptr %l5, !tbaa !22
  %t60 = icmp eq i8 %t58, 92
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t62 = load i64, ptr %l4, !tbaa !24
  %t64 = add i64 %t62, 1
  %t65 = load i64, ptr %l3, !tbaa !24
  %t68 = icmp sge i64 %t64, %t65
  br i1 %t68, label %bb15, label %bb16
bb14:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb28
bb15:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l1, !tbaa !24
  %t76 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t74, i32 7, i64 %t75, i64 %t76, i8 0)
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t81 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t81, ptr %rv
  br label %ret
bb18:
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t83, ptr %l46, !tbaa !27
  %t84 = load i64, ptr %l4, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 %t86
  %t91 = load i8, ptr %t90, !tbaa !32
  store i8 %t91, ptr %l6, !tbaa !22
  %t93 = load i8, ptr %l6, !tbaa !22
  %t95 = icmp eq i8 %t93, 10
  br i1 %t95, label %bb19, label %bb20
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i64, ptr %l1, !tbaa !24
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = add i64 %t99, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t97, i32 8, i64 %t98, i64 %t101, i8 0)
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t106 = load i64, ptr %l4, !tbaa !24
  %t108 = add i64 %t106, 1
  call void @__olang_scope_close(ptr %s1)
  store i64 %t108, ptr %rv
  br label %ret
bb22:
  %t110 = load i8, ptr %l6, !tbaa !22
  %t112 = call i1 @compiler_2fscan_2eescapeOk(i8 %t110, i8 34)
  store i1 %t112, ptr %l60
  br label %bb23
bb23:
  %t113 = load i1, ptr %l60, !tbaa !21
  %t114 = xor i1 %t113, true
  br i1 %t114, label %bb24, label %bb25
bb24:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i64, ptr %l4, !tbaa !24
  %t118 = load i64, ptr %l4, !tbaa !24
  %t120 = add i64 %t118, 2
  %t121 = load i8, ptr %l6, !tbaa !22
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t116, i32 13, i64 %t117, i64 %t120, i8 %t121)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t127 = load i64, ptr %l4, !tbaa !24
  %t129 = add i64 %t127, 2
  store i64 %t129, ptr %l4, !tbaa !24
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s1)
  br label %bb29
bb29:
  br label %bb1
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2etrack(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i8
  %l17 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i8
  %l35 = alloca i1
  %l40 = alloca i8
  %l51 = alloca i64
  %l54 = alloca i8
  %l57 = alloca i8
  %l58 = alloca i32
  %l61 = alloca ptr
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1
  %t3 = trunc i64 88 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scan:scanner", ptr %t6, i32 0, i32 3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H849b787d6464fd61c7b36d59bd222081(ptr %v0, ptr %t8, i8 40)
  br label %bb4
bb4:
  br label %bb53
bb5:
  %t10 = load i32, ptr %l1
  %t12 = trunc i64 90 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scan:scanner", ptr %t15, i32 0, i32 3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H849b787d6464fd61c7b36d59bd222081(ptr %v0, ptr %t17, i8 91)
  br label %bb9
bb9:
  br label %bb53
bb10:
  %t19 = load i32, ptr %l1
  %t21 = trunc i64 92 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scan:scanner", ptr %t24, i32 0, i32 3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H849b787d6464fd61c7b36d59bd222081(ptr %v0, ptr %t26, i8 123)
  br label %bb14
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l17, !tbaa !29
  %t30 = getelementptr %"compiler/scan:scanner", ptr %t29, i32 0, i32 4
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = add i64 %t31, 1
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = getelementptr %"compiler/scan:scanner", ptr %t35, i32 0, i32 4
  store i64 %t33, ptr %t36, !tbaa !24
  br label %bb53
bb15:
  %t37 = load i32, ptr %l1
  %t39 = trunc i64 89 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  %t42 = load i32, ptr %l1
  %t44 = trunc i64 91 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb34
bb20:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scan:scanner", ptr %t47, i32 0, i32 3
  %t51 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eLe_H123f33f8ddaac384b8a67c2466e49838(ptr %v0, ptr %t49)
  store i64 %t51, ptr %l26
  br label %bb21
bb21:
  %t52 = load i64, ptr %l26, !tbaa !24
  store i64 %t52, ptr %l2, !tbaa !24
  %t53 = load i32, ptr %l1
  store i32 %t53, ptr %l27
  store i32 89, ptr %l29
  %t56 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l27, ptr %l29)
  store i1 %t56, ptr %l31
  br label %bb22
bb22:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb23, label %bb24
bb23:
  store i8 40, ptr %l32, !tbaa !22
  br label %bb25
bb24:
  store i8 91, ptr %l32, !tbaa !22
  br label %bb25
bb25:
  %t58 = load i8, ptr %l32, !tbaa !22
  store i8 %t58, ptr %l3, !tbaa !22
  %t59 = load i64, ptr %l2, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb26, label %bb27
bb26:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scan:scanner", ptr %t63, i32 0, i32 3
  %t66 = load i64, ptr %l2, !tbaa !24
  %t68 = sub i64 %t66, 1
  %t71 = call i8 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eAt_Hf7c9ea4b95413b3e180a7d1bf48077d2(ptr %v0, ptr %t65, i64 %t68)
  store i8 %t71, ptr %l40
  br label %bb28
bb27:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb29
bb28:
  %t72 = load i8, ptr %l3, !tbaa !22
  %t73 = load i8, ptr %l40, !tbaa !22
  %t75 = icmp eq i8 %t73, %t72
  store i1 %t75, ptr %l35, !tbaa !21
  br label %bb29
bb29:
  %t77 = load i1, ptr %l35, !tbaa !21
  br i1 %t77, label %bb30, label %bb31
bb30:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/scan:scanner", ptr %t78, i32 0, i32 3
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = sub i64 %t81, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eTr_Hab73bf4217594c1b2a8b440aaf66708e(ptr %v0, ptr %t80, i64 %t83)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb53
bb34:
  %t86 = load i32, ptr %l1
  %t88 = trunc i64 93 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb52
bb37:
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/scan:scanner", ptr %t91, i32 0, i32 3
  %t95 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eLe_H123f33f8ddaac384b8a67c2466e49838(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l51
  br label %bb39
bb39:
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = icmp sgt i64 %t96, 0
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb41:
  br label %bb42
bb42:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/scan:scanner", ptr %t101, i32 0, i32 3
  %t105 = call { i32, i8 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePo_H4d205b82f6a792bc14020f9f8d3dea15(ptr %v0, ptr %t103)
  %t106 = extractvalue { i32, i8 } %t105, 1
  %t107 = extractvalue { i32, i8 } %t105, 0
  store i32 %t107, ptr %l58
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb44, label %ok.109
ok.109:
  store i8 %t106, ptr %l57
  br label %bb43
bb43:
  %t110 = load i8, ptr %l57, !tbaa !22
  store i8 %t110, ptr %l54, !tbaa !22
  br label %bb46
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb46:
  %t111 = load i8, ptr %l54, !tbaa !22
  %t114 = icmp eq i8 %t111, 123
  br i1 %t114, label %bb47, label %bb48
bb47:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l61, !tbaa !29
  %t117 = load ptr, ptr %l61, !tbaa !29
  %t118 = getelementptr %"compiler/scan:scanner", ptr %t117, i32 0, i32 4
  %t119 = load i64, ptr %t118, !tbaa !24
  %t121 = sub i64 %t119, 1
  %t123 = load ptr, ptr %l61, !tbaa !29
  %t124 = getelementptr %"compiler/scan:scanner", ptr %t123, i32 0, i32 4
  store i64 %t121, ptr %t124, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb50:
  br label %bb38
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscan_2edigitOf(i8 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i64
  %l5 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @compiler_2fscan_2eisHexDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
bb4:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp eq i64 %t9, 2
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = load i8, ptr %l0, !tbaa !22
  %t15 = icmp eq i8 %t13, 48
  br i1 %t15, label %bb7, label %bb8
bb6:
  br label %bb10
bb7:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb9
bb8:
  %t17 = load i8, ptr %l0, !tbaa !22
  %t19 = icmp eq i8 %t17, 49
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t21 = load i1, ptr %l10, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb10:
  %t22 = load i8, ptr %l0, !tbaa !22
  %t24 = call i1 @compiler_2fscan_2eisDigit(i8 %t22)
  store i1 %t24, ptr %l14
  br label %bb11
bb11:
  %t25 = load i1, ptr %l14, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eescapeOk(i8 %a0, i8 %a1) #0 {
entry:
  %l0 = alloca i8
  %l4 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp eq i8 %t1, 110
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp eq i8 %t5, 116
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb6
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 114
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb9
bb8:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp eq i8 %t15, 48
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb12
bb11:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp eq i8 %t20, 92
  store i1 %t22, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb15
bb14:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t29 = icmp eq i8 %t25, %a1
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l16, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eexponentDigits(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l24 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = call i1 @compiler_2fscan_2eisDigit(i8 %t19)
  store i1 %t21, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb4:
  %t22 = load i1, ptr %l14, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  %t31 = icmp eq i8 %t29, 95
  store i1 %t31, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l15, !tbaa !21
  store i1 %t33, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l10, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = load i64, ptr %l2, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i8, ptr %t41, i64 %t38
  %t43 = load i8, ptr %t42, !tbaa !32
  %t45 = call i1 @compiler_2fscan_2eisDigit(i8 %t43)
  store i1 %t45, ptr %l24
  br label %bb12
bb12:
  %t46 = load i1, ptr %l24, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  br label %bb1
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2efractionAt(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp sge i64 %t1, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp ne i8 %t15, 46
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l6, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = add i64 %t21, 1
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t29 = icmp slt i64 %t23, %t26
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = add i64 %t32, 1
  %t36 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i8, ptr %t37, i64 %t34
  %t39 = load i8, ptr %t38, !tbaa !32
  %t41 = call i1 @compiler_2fscan_2eisLetter(i8 %t39)
  store i1 %t41, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb13
bb9:
  %t42 = load i1, ptr %l22, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t43, ptr %l24, !tbaa !27
  %t44 = load i64, ptr %l1, !tbaa !24
  %t46 = add i64 %t44, 1
  %t48 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i8, ptr %t49, i64 %t46
  %t51 = load i8, ptr %t50, !tbaa !32
  %t53 = icmp eq i8 %t51, 95
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t55 = load i1, ptr %l23, !tbaa !21
  store i1 %t55, ptr %l17, !tbaa !21
  br label %bb13
bb13:
  %t56 = load i1, ptr %l17, !tbaa !21
  %t57 = xor i1 %t56, true
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eisDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp uge i8 %t1, 48
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp ule i8 %t5, 57
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eisHexDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @compiler_2fscan_2eisDigit(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb7
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp uge i8 %t5, 97
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load i8, ptr %l0, !tbaa !22
  %t11 = icmp ule i8 %t9, 102
  store i1 %t11, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t13 = load i1, ptr %l6, !tbaa !21
  store i1 %t13, ptr %l3, !tbaa !21
  br label %bb7
bb7:
  %t14 = load i1, ptr %l3, !tbaa !21
  br i1 %t14, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb9:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp uge i8 %t15, 65
  br i1 %t17, label %bb10, label %bb11
bb10:
  %t19 = load i8, ptr %l0, !tbaa !22
  %t21 = icmp ule i8 %t19, 70
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t23 = load i1, ptr %l12, !tbaa !21
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t24 = load i1, ptr %l9, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eisLetter(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp uge i8 %t1, 97
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp ule i8 %t5, 122
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp uge i8 %t10, 65
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load i8, ptr %l0, !tbaa !22
  %t16 = icmp ule i8 %t14, 90
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l6, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eisWordChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @compiler_2fscan_2eisLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @compiler_2fscan_2eisDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscan_2ejunkEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l15 = alloca i1
  %l18 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = icmp ne i8 %t19, 13
  store i1 %t21, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call i1 @compiler_2fscan_2ecanStart(ptr %v0, { i64, ptr } %t24, i64 %t25)
  store i1 %t28, ptr %l18
  br label %bb7
bb6:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  %t29 = load i1, ptr %l18, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l15, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t35 = load i64, ptr %l2, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  br label %bb1
bb13:
  %t39 = load i64, ptr %l2, !tbaa !24
  store i64 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscan_2elineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = icmp ne i8 %t19, 10
  store i1 %t21, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l10, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t30 = load i64, ptr %l2, !tbaa !24
  store i64 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscan_2ematchBraces(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/token:Token"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca { i64, ptr }
  %l23 = alloca i32
  %l25 = alloca i32
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l36 = alloca i32
  %l38 = alloca i32
  %l40 = alloca i1
  %l41 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l7, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l6, !tbaa !24
  store i64 %t17, ptr %l8, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t19, ptr %l20, !tbaa !27
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr %"compiler/token:Token", ptr %t23, i64 %t20
  %t25 = load %"compiler/token:Token", ptr %t24
  store %"compiler/token:Token" %t25, ptr %l9
  %t27 = getelementptr %"compiler/token:Token", ptr %l9, i32 0, i32 0
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l23
  store i32 92, ptr %l25
  %t31 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l23, ptr %l25)
  store i1 %t31, ptr %l27
  br label %bb6
bb6:
  %t32 = load i1, ptr %l27, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  store { i64, ptr } %a1, ptr %l28, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  %t40 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 %t34
  store i32 %t37, ptr %t42, !tbaa !33
  %t43 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t43)
  br label %bb9
bb8:
  %t46 = getelementptr %"compiler/token:Token", ptr %l9, i32 0, i32 0
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l36
  store i32 93, ptr %l38
  %t50 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l36, ptr %l38)
  store i1 %t50, ptr %l40
  br label %bb10
bb9:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb18
bb10:
  %t55 = load i1, ptr %l40, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t57 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %l3)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l44
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb14, label %ok.61
ok.61:
  store i64 %t58, ptr %l43
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t62 = load i64, ptr %l43, !tbaa !24
  store i64 %t62, ptr %l41, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb16:
  %t63 = load i64, ptr %l41, !tbaa !24
  store { i64, ptr } %a2, ptr %l45, !tbaa !27
  %t66 = load i64, ptr %l8, !tbaa !24
  %t68 = trunc i64 %t66 to i32
  %t71 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 %t63
  store i32 %t68, ptr %t73, !tbaa !33
  br label %bb17
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb2
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, i64 } @compiler_2fscan_2eoperator(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i8
  %l7 = alloca { i64, ptr }
  %l14 = alloca i8
  %l15 = alloca { i64, ptr }
  %l177 = alloca i1
  %l178 = alloca { i64, ptr }
  %l209 = alloca i1
  %l210 = alloca { i64, ptr }
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l7, !tbaa !27
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 %t6
  %t11 = load i8, ptr %t10, !tbaa !32
  store i8 %t11, ptr %l3, !tbaa !22
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = add i64 %t13, 1
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  store i8 %t29, ptr %l14, !tbaa !22
  br label %bb3
bb2:
  store i8 0, ptr %l14, !tbaa !22
  br label %bb3
bb3:
  %t31 = load i8, ptr %l14, !tbaa !22
  store i8 %t31, ptr %l4, !tbaa !22
  %t32 = load i8, ptr %l3, !tbaa !22
  %t34 = icmp eq i8 %t32, 43
  br i1 %t34, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb13
bb6:
  %t36 = load i8, ptr %l4, !tbaa !22
  %t38 = icmp eq i8 %t36, 43
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = load i64, ptr %l1, !tbaa !24
  %t42 = add i64 %t40, 2
  %t44 = insertvalue { i32, i64 } undef, i32 71, 0
  %t46 = insertvalue { i32, i64 } %t44, i64 %t42, 1
  store { i32, i64 } %t46, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t48 = load i8, ptr %l4, !tbaa !22
  %t50 = icmp eq i8 %t48, 61
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = load i64, ptr %l1, !tbaa !24
  %t54 = add i64 %t52, 2
  %t56 = insertvalue { i32, i64 } undef, i32 61, 0
  %t58 = insertvalue { i32, i64 } %t56, i64 %t54, 1
  store { i32, i64 } %t58, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = add i64 %t60, 1
  %t64 = insertvalue { i32, i64 } undef, i32 49, 0
  %t66 = insertvalue { i32, i64 } %t64, i64 %t62, 1
  store { i32, i64 } %t66, ptr %rv
  br label %ret
bb13:
  %t68 = load i8, ptr %l3, !tbaa !22
  %t70 = icmp eq i8 %t68, 45
  br i1 %t70, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb23
bb16:
  %t72 = load i8, ptr %l4, !tbaa !22
  %t74 = icmp eq i8 %t72, 45
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t76 = load i64, ptr %l1, !tbaa !24
  %t78 = add i64 %t76, 2
  %t80 = insertvalue { i32, i64 } undef, i32 72, 0
  %t82 = insertvalue { i32, i64 } %t80, i64 %t78, 1
  store { i32, i64 } %t82, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t84 = load i8, ptr %l4, !tbaa !22
  %t86 = icmp eq i8 %t84, 61
  br i1 %t86, label %bb20, label %bb21
bb20:
  %t88 = load i64, ptr %l1, !tbaa !24
  %t90 = add i64 %t88, 2
  %t92 = insertvalue { i32, i64 } undef, i32 62, 0
  %t94 = insertvalue { i32, i64 } %t92, i64 %t90, 1
  store { i32, i64 } %t94, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = add i64 %t96, 1
  %t100 = insertvalue { i32, i64 } undef, i32 50, 0
  %t102 = insertvalue { i32, i64 } %t100, i64 %t98, 1
  store { i32, i64 } %t102, ptr %rv
  br label %ret
bb23:
  %t104 = load i8, ptr %l3, !tbaa !22
  %t106 = icmp eq i8 %t104, 42
  br i1 %t106, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t108 = load i8, ptr %l4, !tbaa !22
  %t110 = icmp eq i8 %t108, 61
  br i1 %t110, label %bb27, label %bb28
bb27:
  %t112 = load i64, ptr %l1, !tbaa !24
  %t114 = add i64 %t112, 2
  %t116 = insertvalue { i32, i64 } undef, i32 63, 0
  %t118 = insertvalue { i32, i64 } %t116, i64 %t114, 1
  store { i32, i64 } %t118, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t120 = load i64, ptr %l1, !tbaa !24
  %t122 = add i64 %t120, 1
  %t124 = insertvalue { i32, i64 } undef, i32 51, 0
  %t126 = insertvalue { i32, i64 } %t124, i64 %t122, 1
  store { i32, i64 } %t126, ptr %rv
  br label %ret
bb30:
  %t128 = load i8, ptr %l3, !tbaa !22
  %t130 = icmp eq i8 %t128, 47
  br i1 %t130, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb37
bb33:
  %t132 = load i8, ptr %l4, !tbaa !22
  %t134 = icmp eq i8 %t132, 61
  br i1 %t134, label %bb34, label %bb35
bb34:
  %t136 = load i64, ptr %l1, !tbaa !24
  %t138 = add i64 %t136, 2
  %t140 = insertvalue { i32, i64 } undef, i32 64, 0
  %t142 = insertvalue { i32, i64 } %t140, i64 %t138, 1
  store { i32, i64 } %t142, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t144 = load i64, ptr %l1, !tbaa !24
  %t146 = add i64 %t144, 1
  %t148 = insertvalue { i32, i64 } undef, i32 52, 0
  %t150 = insertvalue { i32, i64 } %t148, i64 %t146, 1
  store { i32, i64 } %t150, ptr %rv
  br label %ret
bb37:
  %t152 = load i8, ptr %l3, !tbaa !22
  %t154 = icmp eq i8 %t152, 37
  br i1 %t154, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t156 = load i8, ptr %l4, !tbaa !22
  %t158 = icmp eq i8 %t156, 61
  br i1 %t158, label %bb41, label %bb42
bb41:
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = add i64 %t160, 2
  %t164 = insertvalue { i32, i64 } undef, i32 65, 0
  %t166 = insertvalue { i32, i64 } %t164, i64 %t162, 1
  store { i32, i64 } %t166, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t168 = load i64, ptr %l1, !tbaa !24
  %t170 = add i64 %t168, 1
  %t172 = insertvalue { i32, i64 } undef, i32 53, 0
  %t174 = insertvalue { i32, i64 } %t172, i64 %t170, 1
  store { i32, i64 } %t174, ptr %rv
  br label %ret
bb44:
  %t176 = load i8, ptr %l3, !tbaa !22
  %t178 = icmp eq i8 %t176, 38
  br i1 %t178, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb51
bb47:
  %t180 = load i8, ptr %l4, !tbaa !22
  %t182 = icmp eq i8 %t180, 61
  br i1 %t182, label %bb48, label %bb49
bb48:
  %t184 = load i64, ptr %l1, !tbaa !24
  %t186 = add i64 %t184, 2
  %t188 = insertvalue { i32, i64 } undef, i32 68, 0
  %t190 = insertvalue { i32, i64 } %t188, i64 %t186, 1
  store { i32, i64 } %t190, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t192 = load i64, ptr %l1, !tbaa !24
  %t194 = add i64 %t192, 1
  %t196 = insertvalue { i32, i64 } undef, i32 81, 0
  %t198 = insertvalue { i32, i64 } %t196, i64 %t194, 1
  store { i32, i64 } %t198, ptr %rv
  br label %ret
bb51:
  %t200 = load i8, ptr %l3, !tbaa !22
  %t202 = icmp eq i8 %t200, 124
  br i1 %t202, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb58
bb54:
  %t204 = load i8, ptr %l4, !tbaa !22
  %t206 = icmp eq i8 %t204, 61
  br i1 %t206, label %bb55, label %bb56
bb55:
  %t208 = load i64, ptr %l1, !tbaa !24
  %t210 = add i64 %t208, 2
  %t212 = insertvalue { i32, i64 } undef, i32 69, 0
  %t214 = insertvalue { i32, i64 } %t212, i64 %t210, 1
  store { i32, i64 } %t214, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t216 = load i64, ptr %l1, !tbaa !24
  %t218 = add i64 %t216, 1
  %t220 = insertvalue { i32, i64 } undef, i32 82, 0
  %t222 = insertvalue { i32, i64 } %t220, i64 %t218, 1
  store { i32, i64 } %t222, ptr %rv
  br label %ret
bb58:
  %t224 = load i8, ptr %l3, !tbaa !22
  %t226 = icmp eq i8 %t224, 94
  br i1 %t226, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t228 = load i8, ptr %l4, !tbaa !22
  %t230 = icmp eq i8 %t228, 61
  br i1 %t230, label %bb62, label %bb63
bb62:
  %t232 = load i64, ptr %l1, !tbaa !24
  %t234 = add i64 %t232, 2
  %t236 = insertvalue { i32, i64 } undef, i32 70, 0
  %t238 = insertvalue { i32, i64 } %t236, i64 %t234, 1
  store { i32, i64 } %t238, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  %t240 = load i64, ptr %l1, !tbaa !24
  %t242 = add i64 %t240, 1
  %t244 = insertvalue { i32, i64 } undef, i32 83, 0
  %t246 = insertvalue { i32, i64 } %t244, i64 %t242, 1
  store { i32, i64 } %t246, ptr %rv
  br label %ret
bb65:
  %t248 = load i8, ptr %l3, !tbaa !22
  %t250 = icmp eq i8 %t248, 58
  br i1 %t250, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb72
bb68:
  %t252 = load i8, ptr %l4, !tbaa !22
  %t254 = icmp eq i8 %t252, 61
  br i1 %t254, label %bb69, label %bb70
bb69:
  %t256 = load i64, ptr %l1, !tbaa !24
  %t258 = add i64 %t256, 2
  %t260 = insertvalue { i32, i64 } undef, i32 60, 0
  %t262 = insertvalue { i32, i64 } %t260, i64 %t258, 1
  store { i32, i64 } %t262, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  %t264 = load i64, ptr %l1, !tbaa !24
  %t266 = add i64 %t264, 1
  %t268 = insertvalue { i32, i64 } undef, i32 59, 0
  %t270 = insertvalue { i32, i64 } %t268, i64 %t266, 1
  store { i32, i64 } %t270, ptr %rv
  br label %ret
bb72:
  %t272 = load i8, ptr %l3, !tbaa !22
  %t274 = icmp eq i8 %t272, 61
  br i1 %t274, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb82
bb75:
  %t276 = load i8, ptr %l4, !tbaa !22
  %t278 = icmp eq i8 %t276, 61
  br i1 %t278, label %bb76, label %bb77
bb76:
  %t280 = load i64, ptr %l1, !tbaa !24
  %t282 = add i64 %t280, 2
  %t284 = insertvalue { i32, i64 } undef, i32 73, 0
  %t286 = insertvalue { i32, i64 } %t284, i64 %t282, 1
  store { i32, i64 } %t286, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t288 = load i8, ptr %l4, !tbaa !22
  %t290 = icmp eq i8 %t288, 62
  br i1 %t290, label %bb79, label %bb80
bb79:
  %t292 = load i64, ptr %l1, !tbaa !24
  %t294 = add i64 %t292, 2
  %t296 = insertvalue { i32, i64 } undef, i32 74, 0
  %t298 = insertvalue { i32, i64 } %t296, i64 %t294, 1
  store { i32, i64 } %t298, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  %t300 = load i64, ptr %l1, !tbaa !24
  %t302 = add i64 %t300, 1
  %t304 = insertvalue { i32, i64 } undef, i32 58, 0
  %t306 = insertvalue { i32, i64 } %t304, i64 %t302, 1
  store { i32, i64 } %t306, ptr %rv
  br label %ret
bb82:
  %t308 = load i8, ptr %l3, !tbaa !22
  %t310 = icmp eq i8 %t308, 33
  br i1 %t310, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb89
bb85:
  %t312 = load i8, ptr %l4, !tbaa !22
  %t314 = icmp eq i8 %t312, 61
  br i1 %t314, label %bb86, label %bb87
bb86:
  %t316 = load i64, ptr %l1, !tbaa !24
  %t318 = add i64 %t316, 2
  %t320 = insertvalue { i32, i64 } undef, i32 75, 0
  %t322 = insertvalue { i32, i64 } %t320, i64 %t318, 1
  store { i32, i64 } %t322, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  %t324 = load i64, ptr %l1, !tbaa !24
  %t326 = add i64 %t324, 1
  %t328 = insertvalue { i32, i64 } undef, i32 76, 0
  %t330 = insertvalue { i32, i64 } %t328, i64 %t326, 1
  store { i32, i64 } %t330, ptr %rv
  br label %ret
bb89:
  %t332 = load i8, ptr %l3, !tbaa !22
  %t334 = icmp eq i8 %t332, 60
  br i1 %t334, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb105
bb92:
  %t336 = load i8, ptr %l4, !tbaa !22
  %t338 = icmp eq i8 %t336, 60
  br i1 %t338, label %bb93, label %bb94
bb93:
  %t340 = load i64, ptr %l1, !tbaa !24
  %t342 = add i64 %t340, 2
  %t343 = load i64, ptr %l2, !tbaa !24
  %t346 = icmp slt i64 %t342, %t343
  br i1 %t346, label %bb95, label %bb96
bb94:
  br label %bb101
bb95:
  %t348 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t348, ptr %l178, !tbaa !27
  %t349 = load i64, ptr %l1, !tbaa !24
  %t351 = add i64 %t349, 2
  %t353 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr i8, ptr %t354, i64 %t351
  %t356 = load i8, ptr %t355, !tbaa !32
  %t358 = icmp eq i8 %t356, 61
  store i1 %t358, ptr %l177, !tbaa !21
  br label %bb97
bb96:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb97
bb97:
  %t360 = load i1, ptr %l177, !tbaa !21
  br i1 %t360, label %bb98, label %bb99
bb98:
  %t361 = load i64, ptr %l1, !tbaa !24
  %t363 = add i64 %t361, 3
  %t365 = insertvalue { i32, i64 } undef, i32 66, 0
  %t367 = insertvalue { i32, i64 } %t365, i64 %t363, 1
  store { i32, i64 } %t367, ptr %rv
  br label %ret
bb99:
  br label %bb100
bb100:
  %t369 = load i64, ptr %l1, !tbaa !24
  %t371 = add i64 %t369, 2
  %t373 = insertvalue { i32, i64 } undef, i32 86, 0
  %t375 = insertvalue { i32, i64 } %t373, i64 %t371, 1
  store { i32, i64 } %t375, ptr %rv
  br label %ret
bb101:
  %t377 = load i8, ptr %l4, !tbaa !22
  %t379 = icmp eq i8 %t377, 61
  br i1 %t379, label %bb102, label %bb103
bb102:
  %t381 = load i64, ptr %l1, !tbaa !24
  %t383 = add i64 %t381, 2
  %t385 = insertvalue { i32, i64 } undef, i32 78, 0
  %t387 = insertvalue { i32, i64 } %t385, i64 %t383, 1
  store { i32, i64 } %t387, ptr %rv
  br label %ret
bb103:
  br label %bb104
bb104:
  %t389 = load i64, ptr %l1, !tbaa !24
  %t391 = add i64 %t389, 1
  %t393 = insertvalue { i32, i64 } undef, i32 77, 0
  %t395 = insertvalue { i32, i64 } %t393, i64 %t391, 1
  store { i32, i64 } %t395, ptr %rv
  br label %ret
bb105:
  %t397 = load i8, ptr %l3, !tbaa !22
  %t399 = icmp eq i8 %t397, 62
  br i1 %t399, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb121
bb108:
  %t401 = load i8, ptr %l4, !tbaa !22
  %t403 = icmp eq i8 %t401, 62
  br i1 %t403, label %bb109, label %bb110
bb109:
  %t405 = load i64, ptr %l1, !tbaa !24
  %t407 = add i64 %t405, 2
  %t408 = load i64, ptr %l2, !tbaa !24
  %t411 = icmp slt i64 %t407, %t408
  br i1 %t411, label %bb111, label %bb112
bb110:
  br label %bb117
bb111:
  %t413 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t413, ptr %l210, !tbaa !27
  %t414 = load i64, ptr %l1, !tbaa !24
  %t416 = add i64 %t414, 2
  %t418 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !27
  %t420 = getelementptr i8, ptr %t419, i64 %t416
  %t421 = load i8, ptr %t420, !tbaa !32
  %t423 = icmp eq i8 %t421, 61
  store i1 %t423, ptr %l209, !tbaa !21
  br label %bb113
bb112:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb113
bb113:
  %t425 = load i1, ptr %l209, !tbaa !21
  br i1 %t425, label %bb114, label %bb115
bb114:
  %t426 = load i64, ptr %l1, !tbaa !24
  %t428 = add i64 %t426, 3
  %t430 = insertvalue { i32, i64 } undef, i32 67, 0
  %t432 = insertvalue { i32, i64 } %t430, i64 %t428, 1
  store { i32, i64 } %t432, ptr %rv
  br label %ret
bb115:
  br label %bb116
bb116:
  %t434 = load i64, ptr %l1, !tbaa !24
  %t436 = add i64 %t434, 2
  %t438 = insertvalue { i32, i64 } undef, i32 87, 0
  %t440 = insertvalue { i32, i64 } %t438, i64 %t436, 1
  store { i32, i64 } %t440, ptr %rv
  br label %ret
bb117:
  %t442 = load i8, ptr %l4, !tbaa !22
  %t444 = icmp eq i8 %t442, 61
  br i1 %t444, label %bb118, label %bb119
bb118:
  %t446 = load i64, ptr %l1, !tbaa !24
  %t448 = add i64 %t446, 2
  %t450 = insertvalue { i32, i64 } undef, i32 80, 0
  %t452 = insertvalue { i32, i64 } %t450, i64 %t448, 1
  store { i32, i64 } %t452, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t454 = load i64, ptr %l1, !tbaa !24
  %t456 = add i64 %t454, 1
  %t458 = insertvalue { i32, i64 } undef, i32 79, 0
  %t460 = insertvalue { i32, i64 } %t458, i64 %t456, 1
  store { i32, i64 } %t460, ptr %rv
  br label %ret
bb121:
  %t462 = load i8, ptr %l3, !tbaa !22
  %t464 = icmp eq i8 %t462, 64
  br i1 %t464, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb125
bb124:
  %t466 = load i64, ptr %l1, !tbaa !24
  %t468 = add i64 %t466, 1
  %t470 = insertvalue { i32, i64 } undef, i32 54, 0
  %t472 = insertvalue { i32, i64 } %t470, i64 %t468, 1
  store { i32, i64 } %t472, ptr %rv
  br label %ret
bb125:
  %t474 = load i8, ptr %l3, !tbaa !22
  %t476 = icmp eq i8 %t474, 44
  br i1 %t476, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  %t478 = load i64, ptr %l1, !tbaa !24
  %t480 = add i64 %t478, 1
  %t482 = insertvalue { i32, i64 } undef, i32 55, 0
  %t484 = insertvalue { i32, i64 } %t482, i64 %t480, 1
  store { i32, i64 } %t484, ptr %rv
  br label %ret
bb129:
  %t486 = load i8, ptr %l3, !tbaa !22
  %t488 = icmp eq i8 %t486, 46
  br i1 %t488, label %bb130, label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb133
bb132:
  %t490 = load i64, ptr %l1, !tbaa !24
  %t492 = add i64 %t490, 1
  %t494 = insertvalue { i32, i64 } undef, i32 56, 0
  %t496 = insertvalue { i32, i64 } %t494, i64 %t492, 1
  store { i32, i64 } %t496, ptr %rv
  br label %ret
bb133:
  %t498 = load i8, ptr %l3, !tbaa !22
  %t500 = icmp eq i8 %t498, 63
  br i1 %t500, label %bb134, label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb137
bb136:
  %t502 = load i64, ptr %l1, !tbaa !24
  %t504 = add i64 %t502, 1
  %t506 = insertvalue { i32, i64 } undef, i32 57, 0
  %t508 = insertvalue { i32, i64 } %t506, i64 %t504, 1
  store { i32, i64 } %t508, ptr %rv
  br label %ret
bb137:
  %t510 = load i8, ptr %l3, !tbaa !22
  %t512 = icmp eq i8 %t510, 126
  br i1 %t512, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  %t514 = load i64, ptr %l1, !tbaa !24
  %t516 = add i64 %t514, 1
  %t518 = insertvalue { i32, i64 } undef, i32 84, 0
  %t520 = insertvalue { i32, i64 } %t518, i64 %t516, 1
  store { i32, i64 } %t520, ptr %rv
  br label %ret
bb141:
  %t522 = load i8, ptr %l3, !tbaa !22
  %t524 = icmp eq i8 %t522, 36
  br i1 %t524, label %bb142, label %bb143
bb142:
  br label %bb144
bb143:
  br label %bb145
bb144:
  %t526 = load i64, ptr %l1, !tbaa !24
  %t528 = add i64 %t526, 1
  %t530 = insertvalue { i32, i64 } undef, i32 85, 0
  %t532 = insertvalue { i32, i64 } %t530, i64 %t528, 1
  store { i32, i64 } %t532, ptr %rv
  br label %ret
bb145:
  %t534 = load i8, ptr %l3, !tbaa !22
  %t536 = icmp eq i8 %t534, 40
  br i1 %t536, label %bb146, label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb149
bb148:
  %t538 = load i64, ptr %l1, !tbaa !24
  %t540 = add i64 %t538, 1
  %t542 = insertvalue { i32, i64 } undef, i32 88, 0
  %t544 = insertvalue { i32, i64 } %t542, i64 %t540, 1
  store { i32, i64 } %t544, ptr %rv
  br label %ret
bb149:
  %t546 = load i8, ptr %l3, !tbaa !22
  %t548 = icmp eq i8 %t546, 41
  br i1 %t548, label %bb150, label %bb151
bb150:
  br label %bb152
bb151:
  br label %bb153
bb152:
  %t550 = load i64, ptr %l1, !tbaa !24
  %t552 = add i64 %t550, 1
  %t554 = insertvalue { i32, i64 } undef, i32 89, 0
  %t556 = insertvalue { i32, i64 } %t554, i64 %t552, 1
  store { i32, i64 } %t556, ptr %rv
  br label %ret
bb153:
  %t558 = load i8, ptr %l3, !tbaa !22
  %t560 = icmp eq i8 %t558, 91
  br i1 %t560, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb157
bb156:
  %t562 = load i64, ptr %l1, !tbaa !24
  %t564 = add i64 %t562, 1
  %t566 = insertvalue { i32, i64 } undef, i32 90, 0
  %t568 = insertvalue { i32, i64 } %t566, i64 %t564, 1
  store { i32, i64 } %t568, ptr %rv
  br label %ret
bb157:
  %t570 = load i8, ptr %l3, !tbaa !22
  %t572 = icmp eq i8 %t570, 93
  br i1 %t572, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  %t574 = load i64, ptr %l1, !tbaa !24
  %t576 = add i64 %t574, 1
  %t578 = insertvalue { i32, i64 } undef, i32 91, 0
  %t580 = insertvalue { i32, i64 } %t578, i64 %t576, 1
  store { i32, i64 } %t580, ptr %rv
  br label %ret
bb161:
  %t582 = load i8, ptr %l3, !tbaa !22
  %t584 = icmp eq i8 %t582, 123
  br i1 %t584, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  %t586 = load i64, ptr %l1, !tbaa !24
  %t588 = add i64 %t586, 1
  %t590 = insertvalue { i32, i64 } undef, i32 92, 0
  %t592 = insertvalue { i32, i64 } %t590, i64 %t588, 1
  store { i32, i64 } %t592, ptr %rv
  br label %ret
bb165:
  %t594 = load i8, ptr %l3, !tbaa !22
  %t596 = icmp eq i8 %t594, 125
  br i1 %t596, label %bb166, label %bb167
bb166:
  br label %bb168
bb167:
  br label %bb169
bb168:
  %t598 = load i64, ptr %l1, !tbaa !24
  %t600 = add i64 %t598, 1
  %t602 = insertvalue { i32, i64 } undef, i32 93, 0
  %t604 = insertvalue { i32, i64 } %t602, i64 %t600, 1
  store { i32, i64 } %t604, ptr %rv
  br label %ret
bb169:
  %t606 = load i64, ptr %l1, !tbaa !24
  %t608 = add i64 %t606, 1
  %t610 = insertvalue { i32, i64 } undef, i32 0, 0
  %t612 = insertvalue { i32, i64 } %t610, i64 %t608, 1
  store { i32, i64 } %t612, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2fscan_2espelled(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/token:Token"
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca { i64, ptr }
  %l19 = alloca i32
  %l21 = alloca i32
  %l23 = alloca i1
  %l25 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t5 = getelementptr %"compiler/scan:Tokens", ptr %a1, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb4:
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr %"compiler/token:Token", ptr %t24, i64 %t21
  %t26 = load %"compiler/token:Token", ptr %t25
  store %"compiler/token:Token" %t26, ptr %l6
  %t28 = getelementptr %"compiler/token:Token", ptr %l6, i32 0, i32 0
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l19
  store i32 0, ptr %l21
  %t32 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l19, ptr %l21)
  store i1 %t32, ptr %l23
  br label %bb6
bb6:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb8:
  br label %bb9
bb9:
  %t35 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t35, ptr %l25
  br label %bb10
bb10:
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = icmp sgt i64 %t36, 0
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 32)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  store ptr %l2, ptr %l28, !tbaa !29
  %t40 = getelementptr %"compiler/token:Token", ptr %l6, i32 0, i32 0
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l29
  store i32 8, ptr %l31
  %t44 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l29, ptr %l31)
  store i1 %t44, ptr %l33
  br label %bb15
bb15:
  %t45 = load i1, ptr %l33, !tbaa !21
  br i1 %t45, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 1, ptr @.d42 }, ptr %l34, !tbaa !27
  br label %bb24
bb17:
  store { i64, ptr } %a0, ptr %l35, !tbaa !27
  %t47 = getelementptr %"compiler/token:Token", ptr %l6, i32 0, i32 2
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = sext i32 %t48 to i64
  store i64 %t50, ptr %l37, !tbaa !24
  %t51 = getelementptr %"compiler/token:Token", ptr %l6, i32 0, i32 3
  %t52 = load i32, ptr %t51, !tbaa !23
  %t54 = sext i32 %t52 to i64
  store i64 %t54, ptr %l39, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l40, !tbaa !24
  %t57 = load i64, ptr %l37, !tbaa !24
  %t58 = icmp sge i64 %t57, 0
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t60 = load i64, ptr %l37, !tbaa !24
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sle i64 %t60, %t61
  br i1 %t62, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c43)
  unreachable
bb20:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = load i64, ptr %l40, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @.c43)
  unreachable
bb22:
  %t68 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l37, !tbaa !24
  %t71 = load i64, ptr %l39, !tbaa !24
  %t72 = getelementptr i8, ptr %t69, i64 %t70
  %t73 = sub i64 %t71, %t70
  %t74 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t72, 1
  store { i64, ptr } %t75, ptr %l34, !tbaa !27
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @.c43)
  unreachable
bb24:
  %t77 = load ptr, ptr %l28, !tbaa !29
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t77, { i64, ptr } %t78)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l4, !tbaa !24
  br label %bb2
bb27:
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t84, ptr %l48
  br label %bb28
bb28:
  %t85 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t85, ptr %l49, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l50, !tbaa !24
  %t88 = load i64, ptr %l50, !tbaa !24
  %t89 = mul i64 %t88, 1
  %t90 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l51, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l50, !tbaa !24
  %t98 = mul i64 %t97, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t94, ptr %t96, i64 %t98, i1 false)
  %t99 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t99, ptr %l49, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t100 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fscan_2ewordEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l14 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = call i1 @compiler_2fscan_2eisWordChar(i8 %t19)
  store i1 %t21, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t22 = load i1, ptr %l14, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l10, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t30 = load i64, ptr %l2, !tbaa !24
  store i64 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/scan:Diag" @compiler_2fscan_3aDiag_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i8 %a3) #0 {
entry:
  %rv = alloca %"compiler/scan:Diag"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/scan:Diag" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/scan:Diag" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/scan:Diag" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/scan:Diag" %t14, i8 %a3, 3
  store %"compiler/scan:Diag" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:Diag", ptr %rv
  ret %"compiler/scan:Diag" %rr
}

define dso_local %"compiler/scan:Tokens" @compiler_2fscan_3aTokens_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/scan:Tokens"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/scan:Tokens" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/scan:Tokens" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/scan:Tokens" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/scan:Tokens" %t14, { i64, ptr } %a3, 3
  store %"compiler/scan:Tokens" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:Tokens", ptr %rv
  ret %"compiler/scan:Tokens" %rr
}

define dso_local %"compiler/scan:scanner" @compiler_2fscan_3ascanner_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/scan:scanner"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l2
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e(ptr %t6)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = insertvalue %"compiler/scan:scanner" undef, { i64, ptr } %t12, 0
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t15 = insertvalue %"compiler/scan:scanner" %t13, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, 1
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t17 = insertvalue %"compiler/scan:scanner" %t15, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, 2
  %t19 = insertvalue %"compiler/scan:scanner" %t17, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 3
  %t21 = insertvalue %"compiler/scan:scanner" %t19, i64 0, 4
  %t23 = insertvalue %"compiler/scan:scanner" %t21, i1 false, 5
  store %"compiler/scan:scanner" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:scanner", ptr %rv
  ret %"compiler/scan:scanner" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [52 x i8] c"compiler/scan.olang:126: array length out of range\0A\00"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.c1 = private unnamed_addr constant [52 x i8] c"compiler/scan.olang:127: array length out of range\0A\00"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d2 = private constant [22 x i8] c"unexpected character '"
@.d3 = private constant [1 x i8] c"'"
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d4 = private constant [38 x i8] c"non-ASCII byte - olang source is ASCII"
@.d5 = private constant [45 x i8] c"NUL byte in the source - is this a text file?"
@.d6 = private constant [52 x i8] c"carriage return - save the file with LF line endings"
@.d7 = private constant [94 x i8] c"olang has no ';' - a statement ends where its line does; put the next one on a line of its own"
@.d8 = private constant [95 x i8] c"a comma never ends a line - items on different lines are separated by the line break; remove it"
@.d9 = private constant [43 x i8] c"unterminated block comment - '##' closes it"
@.d10 = private constant [27 x i8] c"unterminated string literal"
@.d11 = private constant [62 x i8] c"string literal not closed on its line - write \5Cn for a newline"
@.d12 = private constant [30 x i8] c"unterminated character literal"
@.d13 = private constant [40 x i8] c"character literal not closed on its line"
@.d14 = private constant [23 x i8] c"empty character literal"
@.d15 = private constant [71 x i8] c"character literal holds more than one character - text is written in \22\22"
@.d16 = private constant [17 x i8] c"unknown escape '\5C"
@.d17 = private constant [40 x i8] c"' - the escapes are \5Cn \5Ct \5Cr \5C0 \5C\5C \5C' \5C\22"
@.d18 = private constant [29 x i8] c"'0x' needs hexadecimal digits"
@.d19 = private constant [24 x i8] c"'0b' needs binary digits"
@.d20 = private constant [1 x i8] c"'"
@.d21 = private constant [28 x i8] c"' is not a hexadecimal digit"
@.d22 = private constant [1 x i8] c"'"
@.d23 = private constant [23 x i8] c"' is not a binary digit"
@.d24 = private constant [45 x i8] c"'_' in a number must stand between two digits"
@.d25 = private constant [38 x i8] c"a decimal point needs a digit after it"
@.d26 = private constant [38 x i8] c"a number has at most one decimal point"
@.c27 = private unnamed_addr constant [45 x i8] c"compiler/scan.olang:70: unreachable reached\0A\00"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d28 = private constant [3 x i8] c"L16"
@.d29 = private constant [2 x i8] c"L1"
@.d30 = private constant [2 x i8] c"L3"
@.d31 = private constant [3 x i8] c"L18"
@.d32 = private constant [4 x i8] c"L18a"
@.d33 = private constant [3 x i8] c"L4a"
@.d34 = private constant [3 x i8] c"L14"
@.d35 = private constant [3 x i8] c"L13"
@.d36 = private constant [3 x i8] c"L15"
@.d37 = private constant [4 x i8] c"L10a"
@.d38 = private constant [4 x i8] c"L10c"
@.d39 = private constant [4 x i8] c"L10b"
@.d40 = private constant [3 x i8] c"L12"
@.c41 = private unnamed_addr constant [45 x i8] c"compiler/scan.olang:50: unreachable reached\0A\00"
@.d42 = private constant [1 x i8] c";"
@.c43 = private unnamed_addr constant [52 x i8] c"compiler/scan.olang:629: slice bounds out of range\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2eToArray_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2eToArray_3ccompiler_2fscan_3aDiag_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eLe_H123f33f8ddaac384b8a67c2466e49838(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eCl_He62a1125a32dfc5a59291318c690abf4(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2ePush_3ccompiler_2fscan_3aDiag_3e(ptr %v0, ptr %a0, %"compiler/scan:Diag" %a1)
declare i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %a0)
declare %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %v0, i32 %a0, i8 %a1, i32 %a2, i32 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %a0, %"compiler/token:Token" %a1)
@G_2ecompiler_2ftoken_2eLineBreak = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\01" }>, align 8
@G_2ecompiler_2ftoken_2eSpace = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\02" }>, align 8
@G_2ecompiler_2ftoken_2eLineStart = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\04" }>, align 8
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H849b787d6464fd61c7b36d59bd222081(ptr %v0, ptr %a0, i8 %a1)
declare i8 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eAt_Hf7c9ea4b95413b3e180a7d1bf48077d2(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eTr_Hab73bf4217594c1b2a8b440aaf66708e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i8 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePo_H4d205b82f6a792bc14020f9f8d3dea15(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aToken_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscan_3aDiag_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
