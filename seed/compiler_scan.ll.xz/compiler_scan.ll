; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scan:scanner" = type { { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/scan:Diag" = type { i32, i32, i32, i8 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t4, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/scan:scanner"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/token:Token"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca %"compiler/scan:scanner"
  %l15 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca i1
  %l27 = alloca { i64, ptr }
  %l38 = alloca i64
  %l42 = alloca i64
  %l50 = alloca { i64, ptr }
  %l55 = alloca %"compiler/scan:Tokens"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scan:Tokens"
  %t80 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/scan:scanner" @compiler_2fscan_3ascanner_2ector(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store %"compiler/scan:scanner" %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load %"compiler/scan:scanner", ptr %l12
  store %"compiler/scan:scanner" %t4, ptr %l1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2erun(ptr %s0, ptr %l1)
  br label %bb2
bb2:
  %t6 = getelementptr %"compiler/scan:scanner", ptr %l1, i32 0, i32 1
  %t8 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aToken_3e_2eToArray_3ccompiler_2ftoken_3aToken_3e(ptr %s0, ptr %v1, ptr %t6)
  store { i64, ptr } %t8, ptr %l15
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = sub i64 %t16, 1
  store i64 %t17, ptr %l19, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp slt i64 %t18, 2147483648
  %t20 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sge i64 %t20, 0
  %t24 = and i1 %t19, %t21
  store i1 %t24, ptr %l22, !tbaa !21
  br label %bb4
bb4:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb5, label %bb6
bb5:
  br label %bb12
bb6:
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l27, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/token:Token", ptr %t37, i64 %t34
  %t39 = load %"compiler/token:Token", ptr %t38
  store %"compiler/token:Token" %t39, ptr %l7
  %t41 = getelementptr %"compiler/token:Token", ptr %l7, i32 0, i32 0
  %t42 = load i32, ptr %t41, !range !{i32 0, i32 116}
  %t44 = trunc i64 114 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %l5, !tbaa !24
  br label %bb4
bb12:
  %t57 = load i64, ptr %l3, !tbaa !24
  store i64 %t57, ptr %l38, !tbaa !24
  %t58 = load i64, ptr %l38, !tbaa !24
  %t59 = icmp sge i64 %t58, 0
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = load i64, ptr %l38, !tbaa !24
  %t62 = icmp sle i64 %t61, 2305843009213693951
  br i1 %t62, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_bcb8545b4a157296_c09080caec3ed55a)
  unreachable
bb15:
  %t64 = load i64, ptr %l38, !tbaa !24
  %t65 = mul i64 %t64, 4
  %t66 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l8, !tbaa !27
  %t70 = load i64, ptr %l3, !tbaa !24
  store i64 %t70, ptr %l42, !tbaa !24
  %t71 = load i64, ptr %l42, !tbaa !24
  %t72 = icmp sge i64 %t71, 0
  br i1 %t72, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_bcb8545b4a157296_c09080caec3ed55a)
  unreachable
bb17:
  %t74 = load i64, ptr %l42, !tbaa !24
  %t75 = icmp sle i64 %t74, 2305843009213693951
  br i1 %t75, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_5edef46376bb22ab_dbf9e31b0e24ed2f)
  unreachable
bb19:
  %t77 = load i64, ptr %l42, !tbaa !24
  %t78 = mul i64 %t77, 4
  %t79 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t78)
  store i64 0, ptr %t80
  br label %fill.81
fill.81:
  %t84 = load i64, ptr %t80
  %t85 = icmp slt i64 %t84, %t77
  br i1 %t85, label %fillb.82, label %filld.83
fillb.82:
  %t86 = getelementptr i32, ptr %t79, i64 %t84
  store i32 -1, ptr %t86
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %t80
  br label %fill.81
filld.83:
  %t88 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t79, 1
  store { i64, ptr } %t89, ptr %l9, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2fscan_2ematchBraces(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t91, { i64, ptr } %t92, { i64, ptr } %t93)
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_5edef46376bb22ab_dbf9e31b0e24ed2f)
  unreachable
bb21:
  %t97 = getelementptr %"compiler/scan:scanner", ptr %l1, i32 0, i32 2
  %t99 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscan_3aDiag_3e_2eToArray_3ccompiler_2fscan_3aDiag_3e(ptr %s0, ptr %v1, ptr %t97)
  store { i64, ptr } %t99, ptr %l50
  br label %bb22
bb22:
  %t100 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t109 = call %"compiler/scan:Tokens" @compiler_2fscan_3aTokens_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t101, { i64, ptr } %t102, { i64, ptr } %t103, { i64, ptr } %t100)
  store %"compiler/scan:Tokens" %t109, ptr %l55
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t110 = load %"compiler/scan:Tokens", ptr %l55
  store %"compiler/scan:Tokens" %t110, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:Tokens", ptr %rv
  ret %"compiler/scan:Tokens" %rr
}

define dso_local i1 @compiler_2fscan_2eblankLine(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i1
  %l39 = alloca { i64, ptr }
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l3, !tbaa !24
  store i64 %a2, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = sub i64 %t33, 1
  store i64 %t34, ptr %l26, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t35, 2147483648
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp sge i64 %t37, 0
  %t41 = and i1 %t36, %t38
  store i1 %t41, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb8, label %bb9
bb8:
  br label %bb18
bb9:
  br label %bb10
bb10:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t60, ptr %l39, !tbaa !27
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 %t61
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp ne i8 %t66, 32
  br i1 %t68, label %bb11, label %bb12
bb11:
  %t70 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t70, ptr %l44, !tbaa !27
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i8, ptr %t74, i64 %t71
  %t76 = load i8, ptr %t75, !tbaa !32
  %t78 = icmp ne i8 %t76, 9
  store i1 %t78, ptr %l43, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb13
bb13:
  %t80 = load i1, ptr %l43, !tbaa !21
  br i1 %t80, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l7, !tbaa !24
  br label %bb7
bb18:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eHelp(ptr %v0, %"compiler/scan:Diag" %a0) #0 {
entry:
  %l0 = alloca %"compiler/scan:Diag"
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/scan:Diag" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/scan:Diag", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 31}
  store i32 %t2, ptr %l1
  %t4 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t6 = trunc i64 5 to i32
  %t7 = icmp eq i32 %t4, %t6
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  br label %bb27
bb4:
  %t11 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t13 = trunc i64 6 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  br label %bb27
bb8:
  %t18 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t20 = trunc i64 19 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  %t23 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t25 = trunc i64 14 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t28, ptr %l3, !tbaa !27
  br label %bb27
bb14:
  %t30 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t32 = trunc i64 1 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t35, ptr %l3, !tbaa !27
  br label %bb27
bb18:
  %t37 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t39 = trunc i64 2 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t44, ptr %l3, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_987371ebee6d680a_1a9f2e533741df1e)
  unreachable
bb27:
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l28, !tbaa !24
  %t48 = load i64, ptr %l28, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l29, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l28, !tbaa !24
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t59, ptr %l3, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eNote(ptr %v0, %"compiler/scan:Diag" %a0) #0 {
entry:
  %l0 = alloca %"compiler/scan:Diag"
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/scan:Diag" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/scan:Diag", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 31}
  store i32 %t2, ptr %l1
  %t4 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t6 = trunc i64 5 to i32
  %t7 = icmp eq i32 %t4, %t6
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  br label %bb13
bb4:
  %t11 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t13 = trunc i64 6 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_5fa49199d15530eb_36bb6c13fc6f006f)
  unreachable
bb13:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l14, !tbaa !24
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = mul i64 %t22, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l15, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l14, !tbaa !24
  %t32 = mul i64 %t31, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %t30, i64 %t32, i1 false)
  %t33 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:Tokens", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = sub i64 %t6, 1
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp sle i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb12
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sdiv i64 %t22, 2
  store i64 %t24, ptr %l4, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scan:Tokens", ptr %t26, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i32, ptr %t33, i64 %t30
  %t35 = load i32, ptr %t34, !tbaa !33
  store i32 %t35, ptr %l5, !tbaa !23
  %t37 = load i32, ptr %l5, !tbaa !23
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = icmp eq i32 %t37, %t38
  br i1 %t41, label %bb5, label %bb6
bb5:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scan:Tokens", ptr %t43, i32 0, i32 2
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l26, !tbaa !27
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 %t47
  %t52 = load i32, ptr %t51, !tbaa !33
  store i32 %t52, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t54 = load i32, ptr %l5, !tbaa !23
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = icmp slt i32 %t54, %t55
  br i1 %t58, label %bb8, label %bb9
bb8:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l2, !tbaa !24
  br label %bb10
bb9:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t66 = sub i64 %t64, 1
  store i64 %t66, ptr %l3, !tbaa !24
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb1
bb12:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i8 %a4) #0 {
entry:
  %l6 = alloca ptr
  %l13 = alloca %"compiler/scan:Diag"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/scan:scanner", ptr %a0, i32 0, i32 2
  store ptr %t3, ptr %l6, !tbaa !29
  %t7 = trunc i64 %a2 to i32
  %t10 = trunc i64 %a3 to i32
  %t16 = call %"compiler/scan:Diag" @compiler_2fscan_3aDiag_2ector(ptr %s0, i32 %a1, i32 %t7, i32 %t10, i8 %a4)
  store %"compiler/scan:Diag" %t16, ptr %l13
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = load %"compiler/scan:Diag", ptr %l13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscan_3aDiag_3e_2ePush_3ccompiler_2fscan_3aDiag_3e(ptr %v0, ptr %t17, %"compiler/scan:Diag" %t18)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eescape(ptr %v0, ptr %a0, i64 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca { i64, i64 }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l35 = alloca i64
  %l48 = alloca { i64, i64 }
  %l51 = alloca { i64, i64 }
  %l52 = alloca i32
  %l64 = alloca i1
  %l67 = alloca i1
  %l76 = alloca i1
  %l86 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i8 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t10, ptr %l13, !tbaa !27
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = add i64 %t11, 1
  %t15 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i8, ptr %t16, i64 %t13
  %t18 = load i8, ptr %t17, !tbaa !32
  store i8 %t18, ptr %l5, !tbaa !22
  %t20 = load i8, ptr %l5, !tbaa !22
  %t22 = icmp eq i8 %t20, 120
  br i1 %t22, label %bb1, label %bb2
bb1:
  %t24 = load i64, ptr %l1, !tbaa !24
  %t26 = add i64 %t24, 3
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  br i1 %t30, label %bb3, label %bb4
bb2:
  br label %bb15
bb3:
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t32, ptr %l24, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = add i64 %t33, 2
  %t37 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i8, ptr %t38, i64 %t35
  %t40 = load i8, ptr %t39, !tbaa !32
  %t42 = call i64 @compiler_2fscan_2ehexDigit(i8 %t40)
  store i64 %t42, ptr %l28
  br label %bb5
bb4:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb6
bb5:
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb6
bb6:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t47, ptr %l31, !tbaa !27
  %t48 = load i64, ptr %l1, !tbaa !24
  %t50 = add i64 %t48, 3
  %t52 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i8, ptr %t53, i64 %t50
  %t55 = load i8, ptr %t54, !tbaa !32
  %t57 = call i64 @compiler_2fscan_2ehexDigit(i8 %t55)
  store i64 %t57, ptr %l35
  br label %bb9
bb8:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb10
bb9:
  %t58 = load i64, ptr %l35, !tbaa !24
  %t59 = icmp sge i64 %t58, 0
  store i1 %t59, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t62 = load i64, ptr %l1, !tbaa !24
  %t64 = add i64 %t62, 4
  store i64 %t64, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = load i64, ptr %l1, !tbaa !24
  %t70 = add i64 %t68, 2
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t66, i32 16, i64 %t67, i64 %t70, i8 0)
  br label %bb14
bb14:
  %t75 = load i64, ptr %l1, !tbaa !24
  %t77 = add i64 %t75, 2
  store i64 %t77, ptr %rv
  br label %ret
bb15:
  %t79 = load i8, ptr %l5, !tbaa !22
  %t81 = icmp eq i8 %t79, 117
  br i1 %t81, label %bb16, label %bb17
bb16:
  %t83 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = call { i32, { i64, i64 } } @compiler_2fscan_2eunicodeEscape(ptr %v0, { i64, ptr } %t83, i64 %t84)
  %t88 = extractvalue { i32, { i64, i64 } } %t87, 1
  %t89 = extractvalue { i32, { i64, i64 } } %t87, 0
  store i32 %t89, ptr %l52
  %t90 = icmp ne i32 %t89, 0
  br i1 %t90, label %bb19, label %ok.91, !prof !99
ok.91:
  store { i64, i64 } %t88, ptr %l51
  br label %bb18
bb17:
  br label %bb40
bb18:
  %t92 = load { i64, i64 }, ptr %l51
  store { i64, i64 } %t92, ptr %l48
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l1, !tbaa !24
  %t95 = load i64, ptr %l1, !tbaa !24
  %t97 = add i64 %t95, 2
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t93, i32 17, i64 %t94, i64 %t97, i8 0)
  br label %bb21
bb21:
  %t102 = load i64, ptr %l1, !tbaa !24
  %t104 = add i64 %t102, 2
  store i64 %t104, ptr %rv
  br label %ret
bb22:
  %t106 = load { i64, i64 }, ptr %l48
  store { i64, i64 } %t106, ptr %l6
  %t107 = getelementptr { i64, i64 }, ptr %l6, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  store i64 %t108, ptr %l7, !tbaa !24
  %t110 = getelementptr { i64, i64 }, ptr %l6, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t115 = icmp sgt i64 %t113, 1114111
  br i1 %t115, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb28
bb24:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t119 = icmp sge i64 %t117, 55296
  br i1 %t119, label %bb25, label %bb26
bb25:
  %t121 = load i64, ptr %l7, !tbaa !24
  %t123 = icmp sle i64 %t121, 57343
  store i1 %t123, ptr %l67, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb27
bb27:
  %t125 = load i1, ptr %l67, !tbaa !21
  store i1 %t125, ptr %l64, !tbaa !21
  br label %bb28
bb28:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb29, label %bb30
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l1, !tbaa !24
  %t129 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t127, i32 18, i64 %t128, i64 %t129, i8 0)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t134 = load i8, ptr %l2, !tbaa !22
  %t136 = icmp eq i8 %t134, 39
  br i1 %t136, label %bb33, label %bb34
bb33:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t140 = icmp sge i64 %t138, 128
  store i1 %t140, ptr %l76, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb35
bb35:
  %t142 = load i1, ptr %l76, !tbaa !21
  br i1 %t142, label %bb36, label %bb37
bb36:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i64, ptr %l1, !tbaa !24
  %t145 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t143, i32 19, i64 %t144, i64 %t145, i8 0)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t150 = load i64, ptr %l8, !tbaa !24
  store i64 %t150, ptr %rv
  br label %ret
bb40:
  %t152 = load i8, ptr %l5, !tbaa !22
  %t153 = load i8, ptr %l2, !tbaa !22
  %t156 = call i1 @compiler_2fscan_2eescapeOk(i8 %t152, i8 %t153)
  store i1 %t156, ptr %l86
  br label %bb41
bb41:
  %t157 = load i1, ptr %l86, !tbaa !21
  %t158 = xor i1 %t157, true
  br i1 %t158, label %bb42, label %bb43
bb42:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i64, ptr %l1, !tbaa !24
  %t162 = load i64, ptr %l1, !tbaa !24
  %t164 = add i64 %t162, 2
  %t165 = load i8, ptr %l5, !tbaa !22
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t160, i32 15, i64 %t161, i64 %t164, i8 %t165)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t171 = load i64, ptr %l1, !tbaa !24
  %t173 = add i64 %t171, 2
  store i64 %t173, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscan_2eescapeOk(i8 %a0, i8 %a1) #0 {
entry:
  %l0 = alloca i8
  %l4 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp eq i8 %t1, 110
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp eq i8 %t5, 116
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb6
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 114
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb9
bb8:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp eq i8 %t15, 48
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb12
bb11:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp eq i8 %t20, 92
  store i1 %t22, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb15
bb14:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t29 = icmp eq i8 %t25, %a1
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l16, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscan_2ehexDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %l11 = alloca i1
  %l20 = alloca i1
  %rv = alloca i64
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp uge i8 %t1, 48
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp ule i8 %t5, 57
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = sub i8 %t10, 48
  %t14 = zext i8 %t12 to i64
  store i64 %t14, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load i8, ptr %l0, !tbaa !22
  %t18 = icmp uge i8 %t16, 97
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp ule i8 %t20, 102
  store i1 %t22, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = sub i8 %t25, 97
  %t29 = zext i8 %t27 to i64
  %t31 = add i64 %t29, 10
  store i64 %t31, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t33 = load i8, ptr %l0, !tbaa !22
  %t35 = icmp uge i8 %t33, 65
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load i8, ptr %l0, !tbaa !22
  %t39 = icmp ule i8 %t37, 70
  store i1 %t39, ptr %l20, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t41 = load i1, ptr %l20, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t42 = load i8, ptr %l0, !tbaa !22
  %t44 = sub i8 %t42, 65
  %t46 = zext i8 %t44 to i64
  %t48 = add i64 %t46, 10
  store i64 %t48, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscan_2eisDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp uge i8 %t1, 48
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp ule i8 %t5, 57
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eisLetter(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp uge i8 %t1, 97
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp ule i8 %t5, 122
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp uge i8 %t10, 65
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load i8, ptr %l0, !tbaa !22
  %t16 = icmp ule i8 %t14, 90
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l6, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eisWordChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @compiler_2fscan_2eisLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @compiler_2fscan_2eisDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscan_2elastLineStart(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } %a0, ptr %l7, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp ne i8 %t15, 10
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l6, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t22, 1
  store i64 %t25, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t27 = load i64, ptr %l2, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscan_2elineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = icmp ne i8 %t19, 10
  store i1 %t21, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l10, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = add i64 %t26, 1
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscan_2ematchBraces(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/token:Token"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l36 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l7, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l6, !tbaa !24
  store i64 %t17, ptr %l8, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t19, ptr %l20, !tbaa !27
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr %"compiler/token:Token", ptr %t23, i64 %t20
  %t25 = load %"compiler/token:Token", ptr %t24
  store %"compiler/token:Token" %t25, ptr %l9
  %t27 = getelementptr %"compiler/token:Token", ptr %l9, i32 0, i32 0
  %t28 = load i32, ptr %t27, !range !{i32 0, i32 116}
  %t30 = trunc i64 114 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb6, label %bb7
bb6:
  store { i64, ptr } %a1, ptr %l25, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  %t40 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 %t34
  store i32 %t37, ptr %t42, !tbaa !33
  %t43 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t43)
  br label %bb8
bb7:
  %t46 = getelementptr %"compiler/token:Token", ptr %l9, i32 0, i32 0
  %t47 = load i32, ptr %t46, !range !{i32 0, i32 116}
  %t49 = trunc i64 115 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb9, label %bb10
bb8:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %l4, !tbaa !24
  br label %bb16
bb9:
  %t58 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %l3)
  %t59 = extractvalue { i32, i64 } %t58, 1
  %t60 = extractvalue { i32, i64 } %t58, 0
  store i32 %t60, ptr %l39
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb12, label %ok.62, !prof !99
ok.62:
  store i64 %t59, ptr %l38
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t63 = load i64, ptr %l38, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  br label %bb17
bb14:
  %t64 = load i64, ptr %l36, !tbaa !24
  store { i64, ptr } %a2, ptr %l40, !tbaa !27
  %t67 = load i64, ptr %l8, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  %t72 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 %t64
  store i32 %t69, ptr %t74, !tbaa !33
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %l6, !tbaa !24
  br label %bb2
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fscan_2espelled(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/token:Token"
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca { i64, ptr }
  %l22 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t5 = getelementptr %"compiler/scan:Tokens", ptr %a1, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb25
bb4:
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr %"compiler/token:Token", ptr %t24, i64 %t21
  %t26 = load %"compiler/token:Token", ptr %t25
  store %"compiler/token:Token" %t26, ptr %l6
  %t28 = getelementptr %"compiler/token:Token", ptr %l6, i32 0, i32 0
  %t29 = load i32, ptr %t28, !range !{i32 0, i32 116}
  %t31 = trunc i64 0 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb25
bb7:
  br label %bb8
bb8:
  %t35 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t35, ptr %l22
  br label %bb9
bb9:
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = icmp sgt i64 %t36, 0
  br i1 %t37, label %bb10, label %bb11
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 32)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  store ptr %l2, ptr %l25, !tbaa !29
  %t40 = getelementptr %"compiler/token:Token", ptr %l6, i32 0, i32 0
  %t41 = load i32, ptr %t40, !range !{i32 0, i32 116}
  %t43 = trunc i64 8 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l28, !tbaa !27
  br label %bb22
bb15:
  store { i64, ptr } %a0, ptr %l29, !tbaa !27
  %t47 = getelementptr %"compiler/token:Token", ptr %l6, i32 0, i32 2
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = sext i32 %t48 to i64
  store i64 %t50, ptr %l31, !tbaa !24
  %t51 = getelementptr %"compiler/token:Token", ptr %l6, i32 0, i32 3
  %t52 = load i32, ptr %t51, !tbaa !23
  %t54 = sext i32 %t52 to i64
  store i64 %t54, ptr %l33, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l34, !tbaa !24
  %t57 = load i64, ptr %l31, !tbaa !24
  %t58 = icmp sge i64 %t57, 0
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t60 = load i64, ptr %l31, !tbaa !24
  %t61 = load i64, ptr %l33, !tbaa !24
  %t62 = icmp sle i64 %t60, %t61
  br i1 %t62, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_ee9cb139bec139e6_8761f47a368b1bd2)
  unreachable
bb18:
  %t64 = load i64, ptr %l33, !tbaa !24
  %t65 = load i64, ptr %l34, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_ee9cb139bec139e6_8761f47a368b1bd2)
  unreachable
bb20:
  %t68 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l31, !tbaa !24
  %t71 = load i64, ptr %l33, !tbaa !24
  %t72 = getelementptr i8, ptr %t69, i64 %t70
  %t73 = sub i64 %t71, %t70
  %t74 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t72, 1
  store { i64, ptr } %t75, ptr %l28, !tbaa !27
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ee9cb139bec139e6_8761f47a368b1bd2)
  unreachable
bb22:
  %t77 = load ptr, ptr %l25, !tbaa !29
  %t78 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t77, { i64, ptr } %t78)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l4, !tbaa !24
  br label %bb2
bb25:
  %t85 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t85, ptr %l43
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t86 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, i64 } } @compiler_2fscan_2eunicodeEscape(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca i64
  %l29 = alloca i1
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l40 = alloca i64
  %l49 = alloca i1
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, i64 } }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = add i64 %t5, 2
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sge i64 %t7, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l12, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = add i64 %t14, 2
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  %t23 = icmp ne i8 %t21, 123
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t25 = load i1, ptr %l11, !tbaa !21
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = insertvalue { i32, { i64, i64 } } zeroinitializer, i32 65536, 0
  store { i32, { i64, i64 } } %t27, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  store i64 0, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = add i64 %t28, 3
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t38, ptr %l24, !tbaa !27
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i8, ptr %t42, i64 %t39
  %t44 = load i8, ptr %t43, !tbaa !32
  %t46 = call i64 @compiler_2fscan_2ehexDigit(i8 %t44)
  store i64 %t46, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb11
bb10:
  %t47 = load i64, ptr %l27, !tbaa !24
  %t48 = icmp sge i64 %t47, 0
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t50 = load i1, ptr %l23, !tbaa !21
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l1, !tbaa !24
  %t54 = add i64 %t52, 9
  %t57 = icmp slt i64 %t51, %t54
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t59 = load i1, ptr %l29, !tbaa !21
  %t60 = xor i1 %t59, true
  br i1 %t60, label %bb15, label %bb16
bb15:
  br label %bb20
bb16:
  br label %bb17
bb17:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = mul i64 %t62, 16
  store i64 %t64, ptr %l36, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t65, ptr %l37, !tbaa !27
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i8, ptr %t69, i64 %t66
  %t71 = load i8, ptr %t70, !tbaa !32
  %t73 = call i64 @compiler_2fscan_2ehexDigit(i8 %t71)
  store i64 %t73, ptr %l40
  br label %bb18
bb18:
  %t74 = load i64, ptr %l36, !tbaa !24
  %t75 = load i64, ptr %l40, !tbaa !24
  %t76 = add i64 %t74, %t75
  store i64 %t76, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l4, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l4, !tbaa !24
  br label %bb19
bb19:
  br label %bb7
bb20:
  %t83 = load i64, ptr %l4, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t86 = add i64 %t84, 3
  %t89 = icmp eq i64 %t83, %t86
  br i1 %t89, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb23
bb22:
  %t91 = load i64, ptr %l4, !tbaa !24
  %t92 = load i64, ptr %l2, !tbaa !24
  %t95 = icmp sge i64 %t91, %t92
  store i1 %t95, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t97 = load i1, ptr %l49, !tbaa !21
  br i1 %t97, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb26
bb25:
  %t98 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t98, ptr %l54, !tbaa !27
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i8, ptr %t102, i64 %t99
  %t104 = load i8, ptr %t103, !tbaa !32
  %t106 = icmp ne i8 %t104, 125
  store i1 %t106, ptr %l53, !tbaa !21
  br label %bb26
bb26:
  %t108 = load i1, ptr %l53, !tbaa !21
  br i1 %t108, label %bb27, label %bb28
bb27:
  %t110 = insertvalue { i32, { i64, i64 } } zeroinitializer, i32 65536, 0
  store { i32, { i64, i64 } } %t110, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t111 = load i64, ptr %l3, !tbaa !24
  %t112 = load i64, ptr %l4, !tbaa !24
  %t114 = add i64 %t112, 1
  %t116 = insertvalue { i64, i64 } undef, i64 %t111, 0
  %t118 = insertvalue { i64, i64 } %t116, i64 %t114, 1
  %t120 = insertvalue { i32, { i64, i64 } } zeroinitializer, { i64, i64 } %t118, 1
  store { i32, { i64, i64 } } %t120, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, i64 } }, ptr %rv
  ret { i32, { i64, i64 } } %rr
}

define dso_local i64 @compiler_2fscan_2eutf8Width(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca i64
  %l25 = alloca i1
  %l28 = alloca i64
  %l31 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i1
  %l44 = alloca { i64, ptr }
  %l50 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l64 = alloca i1
  %l78 = alloca i64
  %l81 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i1
  %l103 = alloca { i64, ptr }
  %l107 = alloca i1
  %l108 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l14, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i8, ptr %t5, i64 %t2
  %t7 = load i8, ptr %t6, !tbaa !32
  store i8 %t7, ptr %l3, !tbaa !22
  %t9 = load i8, ptr %l3, !tbaa !22
  %t11 = icmp uge i8 %t9, -62
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i8, ptr %l3, !tbaa !22
  %t15 = icmp ule i8 %t13, -33
  store i1 %t15, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l19, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i64 2, ptr %l22, !tbaa !24
  br label %bb18
bb5:
  %t18 = load i8, ptr %l3, !tbaa !22
  %t20 = icmp uge i8 %t18, -32
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load i8, ptr %l3, !tbaa !22
  %t24 = icmp ule i8 %t22, -17
  store i1 %t24, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l25, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i64 3, ptr %l28, !tbaa !24
  br label %bb17
bb10:
  %t27 = load i8, ptr %l3, !tbaa !22
  %t29 = icmp uge i8 %t27, -16
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load i8, ptr %l3, !tbaa !22
  %t33 = icmp ule i8 %t31, -12
  store i1 %t33, ptr %l31, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l31, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb14:
  store i64 4, ptr %l34, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb16
bb16:
  %t36 = load i64, ptr %l34, !tbaa !24
  store i64 %t36, ptr %l28, !tbaa !24
  br label %bb17
bb17:
  %t37 = load i64, ptr %l28, !tbaa !24
  store i64 %t37, ptr %l22, !tbaa !24
  br label %bb18
bb18:
  %t38 = load i64, ptr %l22, !tbaa !24
  store i64 %t38, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp eq i64 %t39, 0
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb21
bb20:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t51 = icmp sgt i64 %t47, %a2
  store i1 %t51, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t53 = load i1, ptr %l37, !tbaa !21
  br i1 %t53, label %bb22, label %bb23
bb22:
  store i64 0, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l44, !tbaa !27
  %t56 = load i64, ptr %l1, !tbaa !24
  %t58 = add i64 %t56, 1
  %t60 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  store i8 %t63, ptr %l5, !tbaa !22
  %t65 = load i8, ptr %l3, !tbaa !22
  %t67 = icmp eq i8 %t65, -32
  br i1 %t67, label %bb25, label %bb26
bb25:
  store i64 160, ptr %l50, !tbaa !24
  br label %bb30
bb26:
  %t69 = load i8, ptr %l3, !tbaa !22
  %t71 = icmp eq i8 %t69, -16
  br i1 %t71, label %bb27, label %bb28
bb27:
  store i64 144, ptr %l53, !tbaa !24
  br label %bb29
bb28:
  store i64 128, ptr %l53, !tbaa !24
  br label %bb29
bb29:
  %t73 = load i64, ptr %l53, !tbaa !24
  store i64 %t73, ptr %l50, !tbaa !24
  br label %bb30
bb30:
  %t74 = load i64, ptr %l50, !tbaa !24
  store i64 %t74, ptr %l6, !tbaa !24
  %t75 = load i8, ptr %l3, !tbaa !22
  %t77 = icmp eq i8 %t75, -19
  br i1 %t77, label %bb31, label %bb32
bb31:
  store i64 159, ptr %l56, !tbaa !24
  br label %bb36
bb32:
  %t79 = load i8, ptr %l3, !tbaa !22
  %t81 = icmp eq i8 %t79, -12
  br i1 %t81, label %bb33, label %bb34
bb33:
  store i64 143, ptr %l59, !tbaa !24
  br label %bb35
bb34:
  store i64 191, ptr %l59, !tbaa !24
  br label %bb35
bb35:
  %t83 = load i64, ptr %l59, !tbaa !24
  store i64 %t83, ptr %l56, !tbaa !24
  br label %bb36
bb36:
  %t84 = load i64, ptr %l56, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  %t85 = load i8, ptr %l5, !tbaa !22
  %t87 = zext i8 %t85 to i64
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  br i1 %t91, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb39
bb38:
  %t93 = load i8, ptr %l5, !tbaa !22
  %t95 = zext i8 %t93 to i64
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  store i1 %t99, ptr %l64, !tbaa !21
  br label %bb39
bb39:
  %t101 = load i1, ptr %l64, !tbaa !21
  br i1 %t101, label %bb40, label %bb41
bb40:
  store i64 0, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t103 = load i64, ptr %l1, !tbaa !24
  %t105 = add i64 %t103, 2
  store i64 %t105, ptr %l8, !tbaa !24
  %t107 = load i64, ptr %l1, !tbaa !24
  %t108 = load i64, ptr %l4, !tbaa !24
  %t111 = add i64 %t107, %t108
  store i64 %t111, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t113 = load i64, ptr %l9, !tbaa !24
  %t114 = load i64, ptr %l8, !tbaa !24
  %t117 = icmp sgt i64 %t113, %t114
  br i1 %t117, label %bb43, label %bb44
bb43:
  %t119 = load i64, ptr %l10, !tbaa !24
  %t121 = icmp sgt i64 %t119, 0
  br i1 %t121, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb48
bb45:
  %t123 = load i64, ptr %l9, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = sub i64 %t123, %t124
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = add i64 %t127, %t128
  %t133 = sub i64 %t131, 1
  %t134 = load i64, ptr %l10, !tbaa !24
  %t137 = sdiv i64 %t133, %t134
  store i64 %t137, ptr %l81, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb47
bb47:
  %t139 = load i64, ptr %l81, !tbaa !24
  store i64 %t139, ptr %l78, !tbaa !24
  br label %bb48
bb48:
  %t140 = load i64, ptr %l78, !tbaa !24
  store i64 %t140, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = sub i64 %t141, 1
  store i64 %t142, ptr %l90, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t144 = icmp slt i64 %t143, 2147483648
  %t145 = load i64, ptr %l12, !tbaa !24
  %t146 = icmp sge i64 %t145, 0
  %t149 = and i1 %t144, %t146
  store i1 %t149, ptr %l93, !tbaa !21
  br label %bb49
bb49:
  %t150 = load i64, ptr %l12, !tbaa !24
  %t151 = load i64, ptr %l11, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb50, label %bb51
bb50:
  br label %bb60
bb51:
  br label %bb52
bb52:
  %t158 = load i64, ptr %l8, !tbaa !24
  %t159 = load i64, ptr %l12, !tbaa !24
  %t160 = load i64, ptr %l10, !tbaa !24
  %t163 = mul i64 %t159, %t160
  %t166 = add i64 %t158, %t163
  store i64 %t166, ptr %l13, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t168, ptr %l103, !tbaa !27
  %t169 = load i64, ptr %l13, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i8, ptr %t172, i64 %t169
  %t174 = load i8, ptr %t173, !tbaa !32
  %t176 = icmp ult i8 %t174, -128
  br i1 %t176, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l107, !tbaa !21
  br label %bb55
bb54:
  %t178 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t178, ptr %l108, !tbaa !27
  %t179 = load i64, ptr %l13, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr i8, ptr %t182, i64 %t179
  %t184 = load i8, ptr %t183, !tbaa !32
  %t186 = icmp ugt i8 %t184, -65
  store i1 %t186, ptr %l107, !tbaa !21
  br label %bb55
bb55:
  %t188 = load i1, ptr %l107, !tbaa !21
  br i1 %t188, label %bb56, label %bb57
bb56:
  store i64 0, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t190 = load i64, ptr %l12, !tbaa !24
  %t193 = add i64 %t190, 1
  store i64 %t193, ptr %l12, !tbaa !24
  br label %bb49
bb60:
  %t195 = load i64, ptr %l4, !tbaa !24
  store i64 %t195, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/scan:Diag" @compiler_2fscan_3aDiag_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i8 %a3) #0 {
entry:
  %rv = alloca %"compiler/scan:Diag"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/scan:Diag" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/scan:Diag" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/scan:Diag" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/scan:Diag" %t14, i8 %a3, 3
  store %"compiler/scan:Diag" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:Diag", ptr %rv
  ret %"compiler/scan:Diag" %rr
}

define dso_local %"compiler/scan:Tokens" @compiler_2fscan_3aTokens_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/scan:Tokens"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/scan:Tokens" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/scan:Tokens" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/scan:Tokens" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/scan:Tokens" %t14, { i64, ptr } %a3, 3
  store %"compiler/scan:Tokens" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:Tokens", ptr %rv
  ret %"compiler/scan:Tokens" %rr
}

define dso_local %"compiler/scan:scanner" @compiler_2fscan_3ascanner_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/scan:scanner"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aToken_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscan_3aDiag_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l9
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l3
  %t7 = call ptr @__olang_scope_hold(ptr %v1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l10, !tbaa !24
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2fscan_3ascanner_2e3
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = call ptr @__olang_region_make(ptr %v1)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l10
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %t14, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l12
  br label %bb5
bb5:
  %t16 = load i1, ptr @olang_2esole_2ecompiler_2fscan_3ascanner_2e3
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12, i32 0, i32 0
  %t21 = load { i64, ptr }, ptr %t20
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = call ptr @__olang_region_or(ptr %t22, ptr null)
  %t24 = call ptr @__olang_region_home(ptr %t23)
  %t25 = icmp ne ptr %t24, null
  %t26 = select i1 %t25, ptr %t24, ptr null
  call void @__olang_region_settle_in(ptr %t19, ptr %t26)
  br label %bb7
bb7:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = insertvalue %"compiler/scan:scanner" undef, { i64, ptr } %t28, 0
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  %t31 = insertvalue %"compiler/scan:scanner" %t29, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, 1
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t33 = insertvalue %"compiler/scan:scanner" %t31, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, 2
  %t35 = insertvalue %"compiler/scan:scanner" %t33, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, 3
  %t37 = insertvalue %"compiler/scan:scanner" %t35, i64 0, 4
  %t39 = insertvalue %"compiler/scan:scanner" %t37, i1 false, 5
  store %"compiler/scan:scanner" %t39, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scan:scanner", ptr %rv
  ret %"compiler/scan:scanner" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"put the next statement on a line of its own" }>, align 8
@.d1 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"remove it" }>, align 8
@.d2 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"write the text in \22\22" }>, align 8
@.d3 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"a name is ASCII letters, digits and '_' - non-ASCII text goes in a comment or a literal" }>, align 8
@.d4 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c"save the file as UTF-8 - a byte that is no text is written \5CxHH in a literal" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"a statement ends where its line does" }>, align 8
@.d7 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c"items on different lines are separated by the line break" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c";" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fscan_3ascanner_2e3 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2erun(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aToken_3e_2eToArray_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_bcb8545b4a157296_c09080caec3ed55a = external constant [0 x i8]
@olang_loc_5edef46376bb22ab_dbf9e31b0e24ed2f = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscan_3aDiag_3e_2eToArray_3ccompiler_2fscan_3aDiag_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_987371ebee6d680a_1a9f2e533741df1e = external constant [0 x i8]
@olang_loc_5fa49199d15530eb_36bb6c13fc6f006f = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscan_3aDiag_3e_2ePush_3ccompiler_2fscan_3aDiag_3e(ptr %v0, ptr %a0, %"compiler/scan:Diag" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_ee9cb139bec139e6_8761f47a368b1bd2 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aToken_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscan_3aDiag_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
