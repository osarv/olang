; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, i32 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/bindgen:cparse" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/bindgen:cx" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/bindgen:gen" = type { { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/bindgen:ctype" = type { i32, { i64, ptr }, i64, i1, i64, i64 }
%"compiler/bindgen:ctp" = type { { i64, ptr }, i64 }
%"compiler/bindgen:cMacro" = type { { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/bindgen:record" = type { { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, i1, i64, i1, { i64, ptr }, i1, i64, i64 }
%"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/json:Object" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/bindgen:cFunc" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, { i64, ptr } }
define dso_local i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca %"std/io:Writer"
  %l4 = alloca i32
  %l5 = alloca %"std/io:Writer"
  %l10 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 2, i64 65536)
  store %"std/io:Writer" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/io:Writer", ptr %l5
  store %"std/io:Writer" %t2, ptr %l3
  %t10 = call i32 @compiler_2fbindgen_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %s0, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %l3)
  store i32 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i32, ptr %l10, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t13 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l3)
  store i32 %t13, ptr %l12
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb4, label %ok.15, !prof !99
ok.15:
  br label %bb3
bb3:
  br label %bb6
bb4:
  %t16 = load i32, ptr %l12, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  br label %bb6
bb6:
  %t20 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fbindgen_2ecPrec(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i1
  %l5 = alloca i1
  %l7 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i64 1, ptr %l1, !tbaa !24
  br label %bb79
bb5:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb6
bb6:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 2, ptr %l1, !tbaa !24
  br label %bb79
bb10:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t11, ptr %l7
  br label %bb11
bb11:
  %t12 = load i1, ptr %l7, !tbaa !21
  br i1 %t12, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 3, ptr %l1, !tbaa !24
  br label %bb79
bb15:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t15, ptr %l9
  br label %bb16
bb16:
  %t16 = load i1, ptr %l9, !tbaa !21
  br i1 %t16, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 4, ptr %l1, !tbaa !24
  br label %bb79
bb20:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t19, ptr %l11
  br label %bb21
bb21:
  %t20 = load i1, ptr %l11, !tbaa !21
  br i1 %t20, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i64 5, ptr %l1, !tbaa !24
  br label %bb79
bb25:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t23, ptr %l13
  br label %bb26
bb26:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t27, ptr %l15
  br label %bb29
bb29:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i64 6, ptr %l1, !tbaa !24
  br label %bb79
bb33:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t31, ptr %l17
  br label %bb34
bb34:
  %t32 = load i1, ptr %l17, !tbaa !21
  br i1 %t32, label %bb35, label %bb36
bb35:
  br label %bb46
bb36:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t35, ptr %l19
  br label %bb37
bb37:
  %t36 = load i1, ptr %l19, !tbaa !21
  br i1 %t36, label %bb38, label %bb39
bb38:
  br label %bb46
bb39:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t37, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t39, ptr %l21
  br label %bb40
bb40:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb41, label %bb42
bb41:
  br label %bb46
bb42:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t41, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t43, ptr %l23
  br label %bb43
bb43:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store i64 7, ptr %l1, !tbaa !24
  br label %bb79
bb47:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t47, ptr %l25
  br label %bb48
bb48:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb49, label %bb50
bb49:
  br label %bb54
bb50:
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t49, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t51, ptr %l27
  br label %bb51
bb51:
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i64 8, ptr %l1, !tbaa !24
  br label %bb79
bb55:
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t53, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t55, ptr %l29
  br label %bb56
bb56:
  %t56 = load i1, ptr %l29, !tbaa !21
  br i1 %t56, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t57, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t59, ptr %l31
  br label %bb59
bb59:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i64 9, ptr %l1, !tbaa !24
  br label %bb79
bb63:
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t63, ptr %l33
  br label %bb64
bb64:
  %t64 = load i1, ptr %l33, !tbaa !21
  br i1 %t64, label %bb65, label %bb66
bb65:
  br label %bb73
bb66:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t67, ptr %l35
  br label %bb67
bb67:
  %t68 = load i1, ptr %l35, !tbaa !21
  br i1 %t68, label %bb68, label %bb69
bb68:
  br label %bb73
bb69:
  %t69 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t71, ptr %l37
  br label %bb70
bb70:
  %t72 = load i1, ptr %l37, !tbaa !21
  br i1 %t72, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  store i64 10, ptr %l1, !tbaa !24
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_760c7c7ac1a62521_16c6052ca99c0395)
  unreachable
bb79:
  call void @__olang_scope_close(ptr %s0)
  %t73 = load i64, ptr %l1, !tbaa !24
  store i64 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @compiler_2fbindgen_2echarValue(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i8
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i32
  %l47 = alloca i64
  %l48 = alloca i32
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i32
  %l67 = alloca i64
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp slt i64 %t3, 3
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = sub i64 %t12, 1
  store i64 %t14, ptr %l10, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = icmp sge i64 1, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l10, !tbaa !24
  %t20 = icmp sle i64 1, %t19
  br i1 %t20, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_e777242b492df290_2cbbd43a2df6cacc)
  unreachable
bb6:
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = load i64, ptr %l11, !tbaa !24
  %t24 = icmp sle i64 %t22, %t23
  br i1 %t24, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_e777242b492df290_2cbbd43a2df6cacc)
  unreachable
bb8:
  %t26 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l10, !tbaa !24
  %t29 = getelementptr i8, ptr %t27, i64 1
  %t30 = sub i64 %t28, 1
  %t31 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t29, 1
  store { i64, ptr } %t32, ptr %l1, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t34, ptr %l16, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 0
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = icmp ne i8 %t38, 92
  br i1 %t40, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e777242b492df290_2cbbd43a2df6cacc)
  unreachable
bb10:
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = icmp ne i64 %t44, 1
  br i1 %t46, label %bb12, label %bb13
bb11:
  br label %bb15
bb12:
  %t49 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t49, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %l23, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 0
  %t54 = load i8, ptr %t53, !tbaa !32
  %t57 = zext i8 %t54 to i64
  %t59 = insertvalue { i32, i64 } zeroinitializer, i64 %t57, 1
  store { i32, i64 } %t59, ptr %rv
  br label %ret
bb15:
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp slt i64 %t62, 2
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t67 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t67, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l31, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 1
  %t72 = load i8, ptr %t71, !tbaa !32
  store i8 %t72, ptr %l2, !tbaa !22
  %t74 = load i8, ptr %l2, !tbaa !22
  %t76 = icmp eq i8 %t74, 120
  br i1 %t76, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t78, ptr %l36, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t79, 0
  store i64 %t82, ptr %l39, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l40, !tbaa !24
  %t85 = icmp sge i64 2, 0
  br i1 %t85, label %bb21, label %bb22
bb20:
  br label %bb33
bb21:
  %t87 = load i64, ptr %l39, !tbaa !24
  %t88 = icmp sle i64 2, %t87
  br i1 %t88, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_aa3527431bc6906d_d98aa20bf76f5ef9)
  unreachable
bb23:
  %t90 = load i64, ptr %l39, !tbaa !24
  %t91 = load i64, ptr %l40, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_aa3527431bc6906d_d98aa20bf76f5ef9)
  unreachable
bb25:
  %t94 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l39, !tbaa !24
  %t97 = getelementptr i8, ptr %t95, i64 2
  %t98 = sub i64 %t96, 2
  %t99 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  store { i64, ptr } %t100, ptr %l44, !tbaa !27
  %t101 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s5, i64 16)
  %t102 = extractvalue { i32, i64 } %t101, 1
  %t103 = extractvalue { i32, i64 } %t101, 0
  store i32 %t103, ptr %l46
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb28, label %ok.105, !prof !99
ok.105:
  store i64 %t102, ptr %l45
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_aa3527431bc6906d_d98aa20bf76f5ef9)
  unreachable
bb27:
  %t106 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t107 = load i64, ptr %l45, !tbaa !24
  %t108 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t106, i64 %t107)
  %t109 = extractvalue { i32, i64 } %t108, 1
  %t110 = extractvalue { i32, i64 } %t108, 0
  store i32 %t110, ptr %l48
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb31, label %ok.112, !prof !99
ok.112:
  store i64 %t109, ptr %l47
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  %t114 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t114, ptr %rv
  br label %ret
bb30:
  %t115 = load i64, ptr %l47, !tbaa !24
  store i64 %t115, ptr %l35, !tbaa !24
  br label %bb32
bb31:
  br label %bb29
bb32:
  call void @__olang_scope_close(ptr %s5)
  %t116 = load i64, ptr %l35, !tbaa !24
  %t117 = insertvalue { i32, i64 } zeroinitializer, i64 %t116, 1
  store { i32, i64 } %t117, ptr %rv
  br label %ret
bb33:
  %t118 = load i8, ptr %l2, !tbaa !22
  %t120 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t118)
  store i1 %t120, ptr %l51
  br label %bb34
bb34:
  %t121 = load i1, ptr %l51, !tbaa !21
  br i1 %t121, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t122 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t122, ptr %l53, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t123, 0
  store i64 %t126, ptr %l56, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  store i64 %t128, ptr %l57, !tbaa !24
  %t129 = icmp sge i64 1, 0
  br i1 %t129, label %bb37, label %bb38
bb36:
  br label %bb49
bb37:
  %t131 = load i64, ptr %l56, !tbaa !24
  %t132 = icmp sle i64 1, %t131
  br i1 %t132, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_5d1582c4176ede0e_4f5ef5c07175765a)
  unreachable
bb39:
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = load i64, ptr %l57, !tbaa !24
  %t136 = icmp sle i64 %t134, %t135
  br i1 %t136, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_5d1582c4176ede0e_4f5ef5c07175765a)
  unreachable
bb41:
  %t138 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = load i64, ptr %l56, !tbaa !24
  %t141 = getelementptr i8, ptr %t139, i64 1
  %t142 = sub i64 %t140, 1
  %t143 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t141, 1
  store { i64, ptr } %t144, ptr %l61, !tbaa !27
  %t145 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s7, i64 8)
  %t146 = extractvalue { i32, i64 } %t145, 1
  %t147 = extractvalue { i32, i64 } %t145, 0
  store i32 %t147, ptr %l63
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb44, label %ok.149, !prof !99
ok.149:
  store i64 %t146, ptr %l62
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_5d1582c4176ede0e_4f5ef5c07175765a)
  unreachable
bb43:
  %t150 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t151 = load i64, ptr %l62, !tbaa !24
  %t152 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t150, i64 %t151)
  %t153 = extractvalue { i32, i64 } %t152, 1
  %t154 = extractvalue { i32, i64 } %t152, 0
  store i32 %t154, ptr %l65
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb47, label %ok.156, !prof !99
ok.156:
  store i64 %t153, ptr %l64
  br label %bb46
bb44:
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  %t158 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t158, ptr %rv
  br label %ret
bb46:
  %t159 = load i64, ptr %l64, !tbaa !24
  store i64 %t159, ptr %l52, !tbaa !24
  br label %bb48
bb47:
  br label %bb45
bb48:
  call void @__olang_scope_close(ptr %s7)
  %t160 = load i64, ptr %l52, !tbaa !24
  %t161 = insertvalue { i32, i64 } zeroinitializer, i64 %t160, 1
  store { i32, i64 } %t161, ptr %rv
  br label %ret
bb49:
  %t162 = load i8, ptr %l2, !tbaa !22
  %t164 = icmp eq i8 %t162, 110
  br i1 %t164, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store i64 10, ptr %l67, !tbaa !24
  br label %bb86
bb53:
  %t166 = load i8, ptr %l2, !tbaa !22
  %t168 = icmp eq i8 %t166, 116
  br i1 %t168, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i64 9, ptr %l67, !tbaa !24
  br label %bb86
bb57:
  %t170 = load i8, ptr %l2, !tbaa !22
  %t172 = icmp eq i8 %t170, 114
  br i1 %t172, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  store i64 13, ptr %l67, !tbaa !24
  br label %bb86
bb61:
  %t174 = load i8, ptr %l2, !tbaa !22
  %t176 = icmp eq i8 %t174, 48
  br i1 %t176, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb86
bb65:
  %t178 = load i8, ptr %l2, !tbaa !22
  %t180 = icmp eq i8 %t178, 97
  br i1 %t180, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  store i64 7, ptr %l67, !tbaa !24
  br label %bb86
bb69:
  %t182 = load i8, ptr %l2, !tbaa !22
  %t184 = icmp eq i8 %t182, 98
  br i1 %t184, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  store i64 8, ptr %l67, !tbaa !24
  br label %bb86
bb73:
  %t186 = load i8, ptr %l2, !tbaa !22
  %t188 = icmp eq i8 %t186, 102
  br i1 %t188, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  store i64 12, ptr %l67, !tbaa !24
  br label %bb86
bb77:
  %t190 = load i8, ptr %l2, !tbaa !22
  %t192 = icmp eq i8 %t190, 118
  br i1 %t192, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  store i64 11, ptr %l67, !tbaa !24
  br label %bb86
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  %t194 = load i8, ptr %l2, !tbaa !22
  %t197 = zext i8 %t194 to i64
  store i64 %t197, ptr %l67, !tbaa !24
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_c1a7519d080599a4_d00fb28b8b3fdec0)
  unreachable
bb86:
  %t199 = load i64, ptr %l67, !tbaa !24
  %t200 = insertvalue { i32, i64 } zeroinitializer, i64 %t199, 1
  store { i32, i64 } %t200, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, %"std/os:Output" } @compiler_2fbindgen_2eclangSays(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca %"std/os:Output"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:Output"
  %l6 = alloca i32
  %l8 = alloca i1
  %rv = alloca { i32, %"std/os:Output" }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t4 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %a0, { i64, ptr } %t3, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) })
  %t5 = extractvalue { i32, %"std/os:Output" } %t4, 1
  %t6 = extractvalue { i32, %"std/os:Output" } %t4, 0
  store i32 %t6, ptr %l6
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store %"std/os:Output" %t5, ptr %l5
  br label %bb1
bb1:
  %t9 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t9, ptr %l2
  br label %bb4
bb2:
  %t10 = load i32, ptr %l6, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t15 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 65536, 0
  store { i32, %"std/os:Output" } %t15, ptr %rv
  br label %ret
bb4:
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t16, ptr %lp1
  %t17 = load %"std/os:Output", ptr %l2
  %t18 = load ptr, ptr %lp1
  store %"std/os:Output" %t17, ptr %t18
  %t19 = load ptr, ptr %lp1
  %t20 = load %"std/os:Output", ptr %t19
  %t22 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t20, 1
  store { i32, %"std/os:Output" } %t22, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:cparse", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/bindgen:cparse", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp slt i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/bindgen:cparse", ptr %t15, i32 0, i32 0
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l9, !tbaa !27
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/bindgen:cparse", ptr %t19, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %t25, i64 %t22
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !37
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = extractvalue { i64, ptr } %t27, 0
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t29, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l7, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t35, ptr %l7, !tbaa !27
  br label %bb3
bb3:
  %t37 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l16, !tbaa !24
  %t39 = load i64, ptr %l16, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l17, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l16, !tbaa !24
  %t49 = mul i64 %t48, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t50, ptr %l7, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t6 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v1, ptr %a0, i32 6, { i64, ptr } %a1, i64 -1, i1 false, i64 0)
  store i64 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/bindgen:cx" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/bindgen:cx"
  %l10 = alloca %"compiler/bindgen:cx"
  %rv = alloca %"compiler/bindgen:cx"
  store ptr %a0, ptr %l0
  store %"compiler/bindgen:cx" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/bindgen:cx", ptr %l1, i32 0, i32 1
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t6 = icmp eq i64 %t2, %t3
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load %"compiler/bindgen:cx", ptr %l1
  store %"compiler/bindgen:cx" %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = getelementptr %"compiler/bindgen:cx", ptr %l1, i32 0, i32 0
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t15 = extractvalue { i64, ptr } %t11, 1
  %t16 = extractvalue { i64, ptr } %t11, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t12, i64 %t13)
  %t22 = getelementptr i8, ptr %t21, i64 %t13
  call void @olang_textcopy(ptr %t22, ptr %t15, i64 %t16)
  %t23 = getelementptr i8, ptr %t22, i64 %t16
  call void @olang_textcopy(ptr %t23, ptr %t18, i64 %t19)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t21, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t33 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t36 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t32, i64 %t33, i64 -1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t36, ptr %l10
  br label %bb4
bb4:
  %t37 = load %"compiler/bindgen:cx", ptr %l10
  store %"compiler/bindgen:cx" %t37, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cx", ptr %rv
  ret %"compiler/bindgen:cx" %rr
}

define dso_local %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecLead(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/bindgen:cx" %a1, %"compiler/bindgen:cx" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/bindgen:cx"
  %l2 = alloca %"compiler/bindgen:cx"
  %l6 = alloca i1
  %l14 = alloca i1
  %l22 = alloca i1
  %l27 = alloca %"compiler/bindgen:cx"
  %l29 = alloca %"compiler/bindgen:cx"
  %rv = alloca %"compiler/bindgen:cx"
  store ptr %a0, ptr %l0
  store %"compiler/bindgen:cx" %a1, ptr %l1
  store %"compiler/bindgen:cx" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/bindgen:cx", ptr %l1, i32 0, i32 1
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2fbindgen_2eKVar, !tbaa !24
  %t6 = icmp eq i64 %t2, %t3
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t8 = getelementptr %"compiler/bindgen:cx", ptr %l1, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2fbindgen_2eKType, !tbaa !24
  %t13 = icmp eq i64 %t9, %t10
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load %"compiler/bindgen:cx", ptr %l1
  store %"compiler/bindgen:cx" %t16, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = getelementptr %"compiler/bindgen:cx", ptr %l2, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  %t20 = load i64, ptr @G_2ecompiler_2fbindgen_2eKVar, !tbaa !24
  %t23 = icmp eq i64 %t19, %t20
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t25 = getelementptr %"compiler/bindgen:cx", ptr %l2, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = load i64, ptr @G_2ecompiler_2fbindgen_2eKType, !tbaa !24
  %t30 = icmp eq i64 %t26, %t27
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l14, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load %"compiler/bindgen:cx", ptr %l2
  store %"compiler/bindgen:cx" %t33, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t35 = getelementptr %"compiler/bindgen:cx", ptr %l1, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = load i64, ptr @G_2ecompiler_2fbindgen_2eKFloat, !tbaa !24
  %t40 = icmp eq i64 %t36, %t37
  br i1 %t40, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb15
bb14:
  %t42 = getelementptr %"compiler/bindgen:cx", ptr %l2, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load i64, ptr @G_2ecompiler_2fbindgen_2eKFloat, !tbaa !24
  %t47 = icmp eq i64 %t43, %t44
  store i1 %t47, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l22, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load i64, ptr @G_2ecompiler_2fbindgen_2eKFloat, !tbaa !24
  %t52 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v3, ptr %v3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, i64 %t50)
  store %"compiler/bindgen:cx" %t52, ptr %l27
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t53 = load %"compiler/bindgen:cx", ptr %l27
  store %"compiler/bindgen:cx" %t53, ptr %rv
  br label %ret
bb19:
  %t54 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t56 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v3, ptr %v3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, i64 %t54)
  store %"compiler/bindgen:cx" %t56, ptr %l29
  br label %bb20
bb20:
  %t57 = load %"compiler/bindgen:cx", ptr %l29
  store %"compiler/bindgen:cx" %t57, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cx", ptr %rv
  ret %"compiler/bindgen:cx" %rr
}

define dso_local %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/bindgen:cx" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/bindgen:cx"
  %l10 = alloca %"compiler/bindgen:cx"
  %rv = alloca %"compiler/bindgen:cx"
  store ptr %a0, ptr %l0
  store %"compiler/bindgen:cx" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/bindgen:cx", ptr %l1, i32 0, i32 1
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t6 = icmp ne i64 %t2, %t3
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load %"compiler/bindgen:cx", ptr %l1
  store %"compiler/bindgen:cx" %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = getelementptr %"compiler/bindgen:cx", ptr %l1, i32 0, i32 0
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t12 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t15 = extractvalue { i64, ptr } %t11, 1
  %t16 = extractvalue { i64, ptr } %t11, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t12, i64 %t13)
  %t22 = getelementptr i8, ptr %t21, i64 %t13
  call void @olang_textcopy(ptr %t22, ptr %t15, i64 %t16)
  %t23 = getelementptr i8, ptr %t22, i64 %t16
  call void @olang_textcopy(ptr %t23, ptr %t18, i64 %t19)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t21, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t33 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t36 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v2, ptr %v2, { i64, ptr } %t32, i64 %t33)
  store %"compiler/bindgen:cx" %t36, ptr %l10
  br label %bb4
bb4:
  %t37 = load %"compiler/bindgen:cx", ptr %l10
  store %"compiler/bindgen:cx" %t37, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cx", ptr %rv
  ret %"compiler/bindgen:cx" %rr
}

define dso_local { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecPrimary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l12 = alloca i1
  %l14 = alloca i32
  %l16 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca %"compiler/bindgen:cx"
  %l24 = alloca %"compiler/bindgen:cx"
  %l25 = alloca i32
  %l28 = alloca { i64, ptr }
  %l30 = alloca i1
  %l33 = alloca i32
  %l35 = alloca ptr
  %l40 = alloca i1
  %l41 = alloca i1
  %l44 = alloca %"compiler/bindgen:cx"
  %l47 = alloca %"compiler/bindgen:cx"
  %l48 = alloca i32
  %l52 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i32
  %l60 = alloca %"compiler/bindgen:cx"
  %l64 = alloca i32
  %l66 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i32
  %l80 = alloca %"compiler/bindgen:cx"
  %l81 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i32
  %l91 = alloca { i64, ptr }
  %l99 = alloca %"compiler/bindgen:cx"
  %l101 = alloca { i64, ptr }
  %l103 = alloca i1
  %l104 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l111 = alloca i1
  %l116 = alloca i32
  %l118 = alloca ptr
  %l121 = alloca %"std/prelude/text:StringBuilder"
  %l127 = alloca { i64, ptr }
  %l129 = alloca i1
  %l135 = alloca { i64, ptr }
  %l137 = alloca i1
  %l143 = alloca i32
  %l145 = alloca ptr
  %l149 = alloca ptr
  %l150 = alloca ptr
  %l151 = alloca %"compiler/bindgen:cx"
  %l154 = alloca %"compiler/bindgen:cx"
  %l155 = alloca i32
  %l157 = alloca %"compiler/bindgen:cx"
  %l161 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l168 = alloca i1
  %l170 = alloca i64
  %l174 = alloca %"compiler/bindgen:cx"
  %l179 = alloca i32
  %l182 = alloca %"compiler/bindgen:cx"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/bindgen:cx" }
  %t230 = alloca { { i64, ptr }, ptr }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %v2, ptr %t1)
  store { i64, ptr } %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t4, ptr %lp2
  %t5 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t6 = load ptr, ptr %lp2
  store { i64, ptr } %t5, ptr %t6, !tbaa !27
  %t7 = load ptr, ptr %lp2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i1, ptr %l12, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s1, ptr %t12, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i32 %t14, ptr %l14
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb6, label %ok.16, !prof !99
ok.16:
  br label %bb5
bb4:
  br label %bb8
bb5:
  br label %bb7
bb6:
  %t17 = load i32, ptr %l14, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t17, 0
  %t23 = shl i32 %t21, 16
  %t24 = or i32 %t23, %t19
  %t25 = select i1 %t22, i32 0, i32 %t24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t27 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t25, 0
  store { i32, %"compiler/bindgen:cx" } %t27, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = getelementptr %"compiler/bindgen:cparse", ptr %t29, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = add i64 %t31, 1
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = getelementptr %"compiler/bindgen:cparse", ptr %t35, i32 0, i32 2
  store i64 %t33, ptr %t36, !tbaa !24
  %t37 = load ptr, ptr %lp2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t40, ptr %l20
  br label %bb9
bb9:
  %t41 = load i1, ptr %l20, !tbaa !21
  br i1 %t41, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t46 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t42, ptr %t43)
  %t47 = extractvalue { i32, %"compiler/bindgen:cx" } %t46, 1
  %t48 = extractvalue { i32, %"compiler/bindgen:cx" } %t46, 0
  store i32 %t48, ptr %l25
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb13, label %ok.50, !prof !99
ok.50:
  store %"compiler/bindgen:cx" %t47, ptr %l24
  br label %bb12
bb11:
  br label %bb23
bb12:
  %t51 = load %"compiler/bindgen:cx", ptr %l24
  store %"compiler/bindgen:cx" %t51, ptr %l21
  br label %bb14
bb13:
  %t52 = load i32, ptr %l25, !tbaa !23
  %t53 = lshr i32 %t52, 16
  %t54 = and i32 %t52, 65535
  %t55 = icmp eq i32 %t53, 1
  %t56 = select i1 %t55, i32 1, i32 0
  %t57 = icmp eq i32 %t52, 0
  %t58 = shl i32 %t56, 16
  %t59 = or i32 %t58, %t54
  %t60 = select i1 %t57, i32 0, i32 %t59
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t62 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t60, 0
  store { i32, %"compiler/bindgen:cx" } %t62, ptr %rv
  br label %ret
bb14:
  %t63 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t63, ptr %lp3
  %t64 = load %"compiler/bindgen:cx", ptr %l21
  %t65 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t64, ptr %t65
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s2, ptr %t66)
  store { i64, ptr } %t68, ptr %l28
  br label %bb15
bb15:
  %t69 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t75, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t77, ptr %l30
  br label %bb16
bb16:
  %t78 = load i1, ptr %l30, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s3, ptr %t81, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i32 %t83, ptr %l33
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb20, label %ok.85, !prof !99
ok.85:
  br label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb21
bb20:
  %t86 = load i32, ptr %l33, !tbaa !23
  %t87 = lshr i32 %t86, 16
  %t88 = and i32 %t86, 65535
  %t89 = icmp eq i32 %t87, 1
  %t90 = select i1 %t89, i32 1, i32 0
  %t91 = icmp eq i32 %t86, 0
  %t92 = shl i32 %t90, 16
  %t93 = or i32 %t92, %t88
  %t94 = select i1 %t91, i32 0, i32 %t93
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t96 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t94, 0
  store { i32, %"compiler/bindgen:cx" } %t96, ptr %rv
  br label %ret
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l35, !tbaa !29
  %t98 = load ptr, ptr %l35, !tbaa !29
  %t99 = getelementptr %"compiler/bindgen:cparse", ptr %t98, i32 0, i32 2
  %t100 = load i64, ptr %t99, !tbaa !24
  %t102 = add i64 %t100, 1
  %t104 = load ptr, ptr %l35, !tbaa !29
  %t105 = getelementptr %"compiler/bindgen:cparse", ptr %t104, i32 0, i32 2
  store i64 %t102, ptr %t105, !tbaa !24
  %t106 = load ptr, ptr %lp3
  %t107 = load %"compiler/bindgen:cx", ptr %t106
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t109 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t107, 1
  store { i32, %"compiler/bindgen:cx" } %t109, ptr %rv
  br label %ret
bb23:
  %t110 = load ptr, ptr %lp2
  %t111 = getelementptr { i64, ptr }, ptr %t110, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 0
  %t114 = load i8, ptr %t113, !tbaa !32
  %t116 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t114)
  store i1 %t116, ptr %l40
  br label %bb24
bb24:
  %t117 = load i1, ptr %l40, !tbaa !21
  br i1 %t117, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb27
bb26:
  %t118 = load ptr, ptr %lp2
  %t119 = getelementptr { i64, ptr }, ptr %t118, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i8, ptr %t120, i64 0
  %t122 = load i8, ptr %t121, !tbaa !32
  %t124 = icmp eq i8 %t122, 46
  store i1 %t124, ptr %l41, !tbaa !21
  br label %bb27
bb27:
  %t126 = load i1, ptr %l41, !tbaa !21
  br i1 %t126, label %bb28, label %bb29
bb28:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %lp2
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  %t132 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNumber(ptr %v0, ptr %v2, ptr %v2, ptr %t127, { i64, ptr } %t129)
  %t133 = extractvalue { i32, %"compiler/bindgen:cx" } %t132, 1
  %t134 = extractvalue { i32, %"compiler/bindgen:cx" } %t132, 0
  store i32 %t134, ptr %l48
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb31, label %ok.136, !prof !99
ok.136:
  store %"compiler/bindgen:cx" %t133, ptr %l47
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t137 = load %"compiler/bindgen:cx", ptr %l47
  store %"compiler/bindgen:cx" %t137, ptr %l44
  br label %bb32
bb31:
  %t138 = load i32, ptr %l48, !tbaa !23
  %t139 = lshr i32 %t138, 16
  %t140 = and i32 %t138, 65535
  %t141 = icmp eq i32 %t139, 1
  %t142 = select i1 %t141, i32 1, i32 0
  %t143 = icmp eq i32 %t138, 0
  %t144 = shl i32 %t142, 16
  %t145 = or i32 %t144, %t140
  %t146 = select i1 %t143, i32 0, i32 %t145
  call void @__olang_scope_close(ptr %s0)
  %t148 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t146, 0
  store { i32, %"compiler/bindgen:cx" } %t148, ptr %rv
  br label %ret
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t149 = load %"compiler/bindgen:cx", ptr %l44
  %t150 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t149, 1
  store { i32, %"compiler/bindgen:cx" } %t150, ptr %rv
  br label %ret
bb33:
  %t151 = load ptr, ptr %lp2
  %t152 = getelementptr { i64, ptr }, ptr %t151, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i8, ptr %t153, i64 0
  %t155 = load i8, ptr %t154, !tbaa !32
  %t157 = icmp eq i8 %t155, 39
  br i1 %t157, label %bb34, label %bb35
bb34:
  %t159 = load ptr, ptr %lp2
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = call { i32, i64 } @compiler_2fbindgen_2echarValue(ptr %v2, { i64, ptr } %t160)
  %t163 = extractvalue { i32, i64 } %t162, 1
  %t164 = extractvalue { i32, i64 } %t162, 0
  store i32 %t164, ptr %l55
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb37, label %ok.166, !prof !99
ok.166:
  store i64 %t163, ptr %l54
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t167 = load i64, ptr %l54, !tbaa !24
  store i64 %t167, ptr %l52, !tbaa !24
  br label %bb38
bb37:
  %t168 = load i32, ptr %l55, !tbaa !23
  %t169 = lshr i32 %t168, 16
  %t170 = and i32 %t168, 65535
  %t171 = icmp eq i32 %t169, 1
  %t172 = select i1 %t171, i32 1, i32 0
  %t173 = icmp eq i32 %t168, 0
  %t174 = shl i32 %t172, 16
  %t175 = or i32 %t174, %t170
  %t176 = select i1 %t173, i32 0, i32 %t175
  call void @__olang_scope_close(ptr %s0)
  %t178 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t176, 0
  store { i32, %"compiler/bindgen:cx" } %t178, ptr %rv
  br label %ret
bb38:
  %t179 = load i64, ptr %l52, !tbaa !24
  %t180 = call i64 @__olang_fmt_i64(ptr null, i64 %t179)
  %t181 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t180)
  %t182 = call i64 @__olang_fmt_i64(ptr %t181, i64 %t179)
  %t183 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t181, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = extractvalue { i64, ptr } %t184, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  %t192 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t195 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v2, ptr %v2, { i64, ptr } %t191, i64 %t192)
  store %"compiler/bindgen:cx" %t195, ptr %l60
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t196 = load %"compiler/bindgen:cx", ptr %l60
  %t197 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t196, 1
  store { i32, %"compiler/bindgen:cx" } %t197, ptr %rv
  br label %ret
bb40:
  %t198 = load ptr, ptr %lp2
  %t199 = getelementptr { i64, ptr }, ptr %t198, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i8, ptr %t200, i64 0
  %t202 = load i8, ptr %t201, !tbaa !32
  %t204 = icmp eq i8 %t202, 34
  br i1 %t204, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s7, ptr %t206, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i32 %t208, ptr %l64
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb44, label %ok.210, !prof !99
ok.210:
  br label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb45
bb44:
  %t211 = load i32, ptr %l64, !tbaa !23
  %t212 = lshr i32 %t211, 16
  %t213 = and i32 %t211, 65535
  %t214 = icmp eq i32 %t212, 1
  %t215 = select i1 %t214, i32 1, i32 0
  %t216 = icmp eq i32 %t211, 0
  %t217 = shl i32 %t215, 16
  %t218 = or i32 %t217, %t213
  %t219 = select i1 %t216, i32 0, i32 %t218
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t221 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t219, 0
  store { i32, %"compiler/bindgen:cx" } %t221, ptr %rv
  br label %ret
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr %"compiler/bindgen:cparse", ptr %t222, i32 0, i32 1
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  %t226 = load ptr, ptr %lp2
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t228 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t229 = ptrtoint ptr %t228 to i64
  %t231 = getelementptr { { i64, ptr }, ptr }, ptr %t230, i32 0, i32 0
  store { i64, ptr } %t227, ptr %t231, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t233 = getelementptr { { i64, ptr }, ptr }, ptr %t230, i32 0, i32 1
  store ptr %v2, ptr %t233, !tbaa !28
  %t234 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_34, 0
  %t235 = insertvalue { ptr, ptr } %t234, ptr %t230, 1
  %t238 = extractvalue { ptr, ptr } %t235, 0
  %t239 = extractvalue { ptr, ptr } %t235, 1
  %t240 = call { i32, i64 } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eFindIndex_3cstd_2f_H0cdaf28864c9da4990596b1986b376a0(ptr %v1, ptr %s0, { i64, ptr } %t225, ptr %t238, ptr %t239)
  %t241 = extractvalue { i32, i64 } %t240, 1
  %t242 = extractvalue { i32, i64 } %t240, 0
  store i32 %t242, ptr %l72
  %t243 = icmp ne i32 %t242, 0
  br i1 %t243, label %bb48, label %ok.244, !prof !99
ok.244:
  store i64 %t241, ptr %l71
  br label %bb47
bb47:
  %t245 = load i64, ptr %l71, !tbaa !24
  store i64 %t245, ptr %l66, !tbaa !24
  br label %bb50
bb48:
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l66, !tbaa !24
  br label %bb50
bb50:
  %t246 = load i64, ptr %l66, !tbaa !24
  store i64 %t246, ptr %l4, !tbaa !24
  %t247 = load i64, ptr %l4, !tbaa !24
  %t249 = icmp sge i64 %t247, 0
  br i1 %t249, label %bb51, label %bb52
bb51:
  %t251 = load i64, ptr %l4, !tbaa !24
  %t252 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t253 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t255 = call i64 @__olang_fmt_i64(ptr null, i64 %t251)
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t252, i64 %t253)
  %t258 = getelementptr i8, ptr %t257, i64 %t253
  %t259 = call i64 @__olang_fmt_i64(ptr %t258, i64 %t251)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t269 = load i64, ptr @G_2ecompiler_2fbindgen_2eKVar, !tbaa !24
  %t270 = load i64, ptr %l4, !tbaa !24
  %t274 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t268, i64 %t269, i64 %t270, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t274, ptr %l80
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t275 = load %"compiler/bindgen:cx", ptr %l80
  %t276 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t275, 1
  store { i32, %"compiler/bindgen:cx" } %t276, ptr %rv
  br label %ret
bb54:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/bindgen:gen", ptr %t277, i32 0, i32 11
  %t280 = load ptr, ptr %lp2
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !27
  %t284 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v2, ptr %t279, { i64, ptr } %t281)
  %t285 = extractvalue { i32, i64 } %t284, 1
  %t286 = extractvalue { i32, i64 } %t284, 0
  store i32 %t286, ptr %l86
  %t287 = icmp ne i32 %t286, 0
  br i1 %t287, label %bb56, label %ok.288, !prof !99
ok.288:
  store i64 %t285, ptr %l85
  br label %bb55
bb55:
  %t289 = load i64, ptr %l85, !tbaa !24
  store i64 %t289, ptr %l81, !tbaa !24
  br label %bb58
bb56:
  br label %bb57
bb57:
  call void @__olang_ert_req_clear()
  store i64 -9223372036854775808, ptr %l81, !tbaa !24
  br label %bb58
bb58:
  %t290 = load i64, ptr %l81, !tbaa !24
  store i64 %t290, ptr %l5, !tbaa !24
  %t291 = load i64, ptr %l5, !tbaa !24
  %t293 = icmp ne i64 %t291, -9223372036854775808
  br i1 %t293, label %bb59, label %bb60
bb59:
  %t295 = load i64, ptr %l5, !tbaa !24
  %t297 = icmp slt i64 %t295, 0
  br i1 %t297, label %bb61, label %bb62
bb60:
  br label %bb65
bb61:
  %t299 = load i64, ptr %l5, !tbaa !24
  %t300 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t303 = call i64 @__olang_fmt_i64(ptr null, i64 %t299)
  %t304 = add i64 %t301, %t303
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t307 = add i64 %t304, %t306
  %t308 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t307)
  call void @olang_textcopy(ptr %t308, ptr %t300, i64 %t301)
  %t309 = getelementptr i8, ptr %t308, i64 %t301
  %t310 = call i64 @__olang_fmt_i64(ptr %t309, i64 %t299)
  %t311 = getelementptr i8, ptr %t309, i64 %t303
  call void @olang_textcopy(ptr %t311, ptr %t305, i64 %t306)
  %t312 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t308, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t316 = extractvalue { i64, ptr } %t313, 1
  %t317 = mul i64 %t315, 1
  %t318 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t317)
  call void @llvm.memcpy.p0.p0.i64(ptr %t318, ptr %t316, i64 %t317, i1 false)
  %t319 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t318, 1
  store { i64, ptr } %t320, ptr %l91, !tbaa !27
  br label %bb63
bb62:
  %t322 = load i64, ptr %l5, !tbaa !24
  %t324 = call i64 @__olang_fmt_i64(ptr null, i64 %t322)
  %t325 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t324)
  %t326 = call i64 @__olang_fmt_i64(ptr %t325, i64 %t322)
  %t327 = insertvalue { i64, ptr } undef, i64 %t324, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t325, 1
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t331 = extractvalue { i64, ptr } %t328, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  store { i64, ptr } %t335, ptr %l91, !tbaa !27
  br label %bb63
bb63:
  %t337 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t338 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t340 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v2, ptr %v2, { i64, ptr } %t338, i64 %t337)
  store %"compiler/bindgen:cx" %t340, ptr %l99
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t341 = load %"compiler/bindgen:cx", ptr %l99
  %t342 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t341, 1
  store { i32, %"compiler/bindgen:cx" } %t342, ptr %rv
  br label %ret
bb65:
  %t343 = load ptr, ptr %l1, !tbaa !29
  %t345 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s0, ptr %t343)
  store { i64, ptr } %t345, ptr %l101
  br label %bb66
bb66:
  %t346 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t346, 0
  %t348 = extractvalue { i64, ptr } %t346, 1
  %t349 = mul i64 %t347, 1
  %t350 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t349)
  call void @llvm.memcpy.p0.p0.i64(ptr %t350, ptr %t348, i64 %t349, i1 false)
  %t351 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t350, 1
  %t354 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t352, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t354, ptr %l103
  br label %bb67
bb67:
  %t355 = load i1, ptr %l103, !tbaa !21
  br i1 %t355, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s13
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/bindgen:gen", ptr %t356, i32 0, i32 15
  %t359 = load ptr, ptr %lp2
  %t360 = load { i64, ptr }, ptr %t359, !tbaa !27
  %t363 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v2, ptr %v2, ptr %t358, { i64, ptr } %t360)
  %t364 = extractvalue { i32, { i64, ptr } } %t363, 1
  %t365 = extractvalue { i32, { i64, ptr } } %t363, 0
  store i32 %t365, ptr %l109
  %t366 = icmp ne i32 %t365, 0
  br i1 %t366, label %bb71, label %ok.367, !prof !99
ok.367:
  store { i64, ptr } %t364, ptr %l108
  br label %bb70
bb69:
  br label %bb115
bb70:
  %t368 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t368, ptr %l104, !tbaa !27
  br label %bb73
bb71:
  br label %bb72
bb72:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l104, !tbaa !27
  br label %bb73
bb73:
  %t369 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t369, ptr %lp6
  %t370 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t371 = load ptr, ptr %lp6
  store { i64, ptr } %t370, ptr %t371, !tbaa !27
  %t372 = load ptr, ptr %lp6
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  %t375 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s13, { i64, ptr } %t373, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t375, ptr %l111
  br label %bb74
bb74:
  %t376 = load i1, ptr %l111, !tbaa !21
  br i1 %t376, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s14
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load ptr, ptr %lp2
  %t379 = load { i64, ptr }, ptr %t378, !tbaa !27
  %t380 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t381 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t383 = extractvalue { i64, ptr } %t379, 1
  %t384 = extractvalue { i64, ptr } %t379, 0
  %t385 = add i64 %t381, %t384
  %t386 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t387 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t388 = add i64 %t385, %t387
  %t389 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t388)
  call void @olang_textcopy(ptr %t389, ptr %t380, i64 %t381)
  %t390 = getelementptr i8, ptr %t389, i64 %t381
  call void @olang_textcopy(ptr %t390, ptr %t383, i64 %t384)
  %t391 = getelementptr i8, ptr %t390, i64 %t384
  call void @olang_textcopy(ptr %t391, ptr %t386, i64 %t387)
  %t392 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t389, 1
  %t395 = extractvalue { i64, ptr } %t393, 0
  %t396 = extractvalue { i64, ptr } %t393, 1
  %t397 = mul i64 %t395, 1
  %t398 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t397)
  call void @llvm.memcpy.p0.p0.i64(ptr %t398, ptr %t396, i64 %t397, i1 false)
  %t399 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t398, 1
  %t403 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s14, ptr %t377, { i64, ptr } %t400)
  store i32 %t403, ptr %l116
  %t404 = icmp ne i32 %t403, 0
  br i1 %t404, label %bb78, label %ok.405, !prof !99
ok.405:
  br label %bb77
bb76:
  br label %bb80
bb77:
  br label %bb79
bb78:
  %t406 = load i32, ptr %l116, !tbaa !23
  %t407 = lshr i32 %t406, 16
  %t408 = and i32 %t406, 65535
  %t409 = icmp eq i32 %t407, 1
  %t410 = select i1 %t409, i32 1, i32 0
  %t411 = icmp eq i32 %t406, 0
  %t412 = shl i32 %t410, 16
  %t413 = or i32 %t412, %t408
  %t414 = select i1 %t411, i32 0, i32 %t413
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t416 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t414, 0
  store { i32, %"compiler/bindgen:cx" } %t416, ptr %rv
  br label %ret
bb79:
  call void @__olang_scope_close(ptr %s14)
  br label %bb80
bb80:
  %t417 = load ptr, ptr %l1, !tbaa !29
  store ptr %t417, ptr %l118, !tbaa !29
  %t418 = load ptr, ptr %l118, !tbaa !29
  %t419 = getelementptr %"compiler/bindgen:cparse", ptr %t418, i32 0, i32 2
  %t420 = load i64, ptr %t419, !tbaa !24
  %t422 = add i64 %t420, 1
  %t424 = load ptr, ptr %l118, !tbaa !29
  %t425 = getelementptr %"compiler/bindgen:cparse", ptr %t424, i32 0, i32 2
  store i64 %t422, ptr %t425, !tbaa !24
  %t426 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s13)
  store %"std/prelude/text:StringBuilder" %t426, ptr %l121
  br label %bb81
bb81:
  %t427 = load %"std/prelude/text:StringBuilder", ptr %l121
  store %"std/prelude/text:StringBuilder" %t427, ptr %l7
  %t428 = load ptr, ptr %lp2
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t429, 1
  %t432 = extractvalue { i64, ptr } %t429, 0
  %t433 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t434 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t435 = add i64 %t432, %t434
  %t436 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t435)
  call void @olang_textcopy(ptr %t436, ptr %t431, i64 %t432)
  %t437 = getelementptr i8, ptr %t436, i64 %t432
  call void @olang_textcopy(ptr %t437, ptr %t433, i64 %t434)
  %t438 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t436, 1
  %t441 = extractvalue { i64, ptr } %t439, 0
  %t442 = extractvalue { i64, ptr } %t439, 1
  %t443 = mul i64 %t441, 1
  %t444 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t443)
  call void @llvm.memcpy.p0.p0.i64(ptr %t444, ptr %t442, i64 %t443, i1 false)
  %t445 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr %t444, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l7, { i64, ptr } %t446)
  br label %bb82
bb82:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s17
  %t449 = load ptr, ptr %l1, !tbaa !29
  %t451 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s17, ptr %t449)
  store { i64, ptr } %t451, ptr %l127
  br label %bb84
bb84:
  %t452 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 0
  %t454 = extractvalue { i64, ptr } %t452, 1
  %t455 = mul i64 %t453, 1
  %t456 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t455)
  call void @llvm.memcpy.p0.p0.i64(ptr %t456, ptr %t454, i64 %t455, i1 false)
  %t457 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  %t460 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s17, ptr %s17, { i64, ptr } %t458, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t460, ptr %l129
  br label %bb85
bb85:
  %t461 = load i1, ptr %l129, !tbaa !21
  %t462 = xor i1 %t461, true
  %t464 = xor i1 %t462, true
  br i1 %t464, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s17)
  br label %bb107
bb87:
  br label %bb88
bb88:
  %t466 = load i64, ptr %l8, !tbaa !24
  %t468 = icmp sgt i64 %t466, 0
  br i1 %t468, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s18
  %t470 = load ptr, ptr %l1, !tbaa !29
  %t472 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s18, ptr %t470)
  store { i64, ptr } %t472, ptr %l135
  br label %bb91
bb90:
  br label %bb100
bb91:
  %t473 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t473, 0
  %t475 = extractvalue { i64, ptr } %t473, 1
  %t476 = mul i64 %t474, 1
  %t477 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t476)
  call void @llvm.memcpy.p0.p0.i64(ptr %t477, ptr %t475, i64 %t476, i1 false)
  %t478 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t479 = insertvalue { i64, ptr } %t478, ptr %t477, 1
  %t481 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s18, ptr %s18, { i64, ptr } %t479, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t481, ptr %l137
  br label %bb92
bb92:
  %t482 = load i1, ptr %l137, !tbaa !21
  %t483 = xor i1 %t482, true
  br i1 %t483, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s19
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load ptr, ptr %lp2
  %t487 = load { i64, ptr }, ptr %t486, !tbaa !27
  %t488 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t489 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t491 = extractvalue { i64, ptr } %t487, 1
  %t492 = extractvalue { i64, ptr } %t487, 0
  %t493 = add i64 %t489, %t492
  %t494 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t495 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t496 = add i64 %t493, %t495
  %t497 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t496)
  call void @olang_textcopy(ptr %t497, ptr %t488, i64 %t489)
  %t498 = getelementptr i8, ptr %t497, i64 %t489
  call void @olang_textcopy(ptr %t498, ptr %t491, i64 %t492)
  %t499 = getelementptr i8, ptr %t498, i64 %t492
  call void @olang_textcopy(ptr %t499, ptr %t494, i64 %t495)
  %t500 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t497, 1
  %t503 = extractvalue { i64, ptr } %t501, 0
  %t504 = extractvalue { i64, ptr } %t501, 1
  %t505 = mul i64 %t503, 1
  %t506 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t505)
  call void @llvm.memcpy.p0.p0.i64(ptr %t506, ptr %t504, i64 %t505, i1 false)
  %t507 = insertvalue { i64, ptr } undef, i64 %t503, 0
  %t508 = insertvalue { i64, ptr } %t507, ptr %t506, 1
  %t511 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s19, ptr %t485, { i64, ptr } %t508)
  store i32 %t511, ptr %l143
  %t512 = icmp ne i32 %t511, 0
  br i1 %t512, label %bb96, label %ok.513, !prof !99
ok.513:
  br label %bb95
bb94:
  br label %bb98
bb95:
  br label %bb97
bb96:
  %t514 = load i32, ptr %l143, !tbaa !23
  %t515 = lshr i32 %t514, 16
  %t516 = and i32 %t514, 65535
  %t517 = icmp eq i32 %t515, 1
  %t518 = select i1 %t517, i32 1, i32 0
  %t519 = icmp eq i32 %t514, 0
  %t520 = shl i32 %t518, 16
  %t521 = or i32 %t520, %t516
  %t522 = select i1 %t519, i32 0, i32 %t521
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t524 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t522, 0
  store { i32, %"compiler/bindgen:cx" } %t524, ptr %rv
  br label %ret
bb97:
  call void @__olang_scope_close(ptr %s19)
  br label %bb98
bb98:
  %t525 = load ptr, ptr %l1, !tbaa !29
  store ptr %t525, ptr %l145, !tbaa !29
  %t526 = load ptr, ptr %l145, !tbaa !29
  %t527 = getelementptr %"compiler/bindgen:cparse", ptr %t526, i32 0, i32 2
  %t528 = load i64, ptr %t527, !tbaa !24
  %t530 = add i64 %t528, 1
  %t532 = load ptr, ptr %l145, !tbaa !29
  %t533 = getelementptr %"compiler/bindgen:cparse", ptr %t532, i32 0, i32 2
  store i64 %t530, ptr %t533, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s18, ptr %l7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s18)
  br label %bb100
bb100:
  store ptr %l7, ptr %l149, !tbaa !29
  %t535 = load ptr, ptr %l0, !tbaa !29
  store ptr %t535, ptr %l150, !tbaa !29
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load ptr, ptr %l1, !tbaa !29
  %t540 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t536, ptr %t537)
  %t541 = extractvalue { i32, %"compiler/bindgen:cx" } %t540, 1
  %t542 = extractvalue { i32, %"compiler/bindgen:cx" } %t540, 0
  store i32 %t542, ptr %l155
  %t543 = icmp ne i32 %t542, 0
  br i1 %t543, label %bb102, label %ok.544, !prof !99
ok.544:
  store %"compiler/bindgen:cx" %t541, ptr %l154
  br label %bb101
bb101:
  %t545 = load %"compiler/bindgen:cx", ptr %l154
  store %"compiler/bindgen:cx" %t545, ptr %l151
  br label %bb103
bb102:
  %t546 = load i32, ptr %l155, !tbaa !23
  %t547 = lshr i32 %t546, 16
  %t548 = and i32 %t546, 65535
  %t549 = icmp eq i32 %t547, 1
  %t550 = select i1 %t549, i32 1, i32 0
  %t551 = icmp eq i32 %t546, 0
  %t552 = shl i32 %t550, 16
  %t553 = or i32 %t552, %t548
  %t554 = select i1 %t551, i32 0, i32 %t553
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t556 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t554, 0
  store { i32, %"compiler/bindgen:cx" } %t556, ptr %rv
  br label %ret
bb103:
  %t557 = load ptr, ptr %l150, !tbaa !29
  %t558 = load %"compiler/bindgen:cx", ptr %l151
  %t559 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v0, ptr %v0, ptr %t557, %"compiler/bindgen:cx" %t558)
  store %"compiler/bindgen:cx" %t559, ptr %l157
  br label %bb104
bb104:
  %t560 = getelementptr %"compiler/bindgen:cx", ptr %l157, i32 0, i32 0
  %t561 = load { i64, ptr }, ptr %t560, !tbaa !27
  %t562 = load ptr, ptr %l149, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %v0, ptr %t562, { i64, ptr } %t561)
  br label %bb105
bb105:
  %t564 = load i64, ptr %l8, !tbaa !24
  %t566 = add i64 %t564, 1
  store i64 %t566, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb106
bb106:
  br label %bb83
bb107:
  %t568 = load ptr, ptr %l1, !tbaa !29
  store ptr %t568, ptr %l161, !tbaa !29
  %t569 = load ptr, ptr %l161, !tbaa !29
  %t570 = getelementptr %"compiler/bindgen:cparse", ptr %t569, i32 0, i32 2
  %t571 = load i64, ptr %t570, !tbaa !24
  %t573 = add i64 %t571, 1
  %t575 = load ptr, ptr %l161, !tbaa !29
  %t576 = getelementptr %"compiler/bindgen:cparse", ptr %t575, i32 0, i32 2
  store i64 %t573, ptr %t576, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l7, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb108
bb108:
  %t579 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s13, ptr %v2, ptr %l7)
  store { i64, ptr } %t579, ptr %l166
  br label %bb109
bb109:
  %t580 = load ptr, ptr %lp6
  %t581 = load { i64, ptr }, ptr %t580, !tbaa !27
  %t583 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s13, { i64, ptr } %t581, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t583, ptr %l168
  br label %bb110
bb110:
  %t584 = load i1, ptr %l168, !tbaa !21
  %t585 = xor i1 %t584, true
  br i1 %t585, label %bb111, label %bb112
bb111:
  %t587 = load i64, ptr @G_2ecompiler_2fbindgen_2eKType, !tbaa !24
  store i64 %t587, ptr %l170, !tbaa !24
  br label %bb113
bb112:
  %t589 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  store i64 %t589, ptr %l170, !tbaa !24
  br label %bb113
bb113:
  %t591 = load ptr, ptr %lp6
  %t592 = load { i64, ptr }, ptr %t591, !tbaa !27
  %t593 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t594 = load i64, ptr %l170, !tbaa !24
  %t596 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t593, i64 %t594, i64 -1, { i64, ptr } %t592)
  store %"compiler/bindgen:cx" %t596, ptr %l174
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t597 = load %"compiler/bindgen:cx", ptr %l174
  %t598 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t597, 1
  store { i32, %"compiler/bindgen:cx" } %t598, ptr %rv
  br label %ret
bb115:
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t600 = load ptr, ptr %lp2
  %t601 = load { i64, ptr }, ptr %t600, !tbaa !27
  %t602 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t603 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t605 = extractvalue { i64, ptr } %t601, 1
  %t606 = extractvalue { i64, ptr } %t601, 0
  %t607 = add i64 %t603, %t606
  %t608 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t609 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t610 = add i64 %t607, %t609
  %t611 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t610)
  call void @olang_textcopy(ptr %t611, ptr %t602, i64 %t603)
  %t612 = getelementptr i8, ptr %t611, i64 %t603
  call void @olang_textcopy(ptr %t612, ptr %t605, i64 %t606)
  %t613 = getelementptr i8, ptr %t612, i64 %t606
  call void @olang_textcopy(ptr %t613, ptr %t608, i64 %t609)
  %t614 = insertvalue { i64, ptr } undef, i64 %t610, 0
  %t615 = insertvalue { i64, ptr } %t614, ptr %t611, 1
  %t617 = extractvalue { i64, ptr } %t615, 0
  %t618 = extractvalue { i64, ptr } %t615, 1
  %t619 = mul i64 %t617, 1
  %t620 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t619)
  call void @llvm.memcpy.p0.p0.i64(ptr %t620, ptr %t618, i64 %t619, i1 false)
  %t621 = insertvalue { i64, ptr } undef, i64 %t617, 0
  %t622 = insertvalue { i64, ptr } %t621, ptr %t620, 1
  %t625 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s0, ptr %t599, { i64, ptr } %t622)
  store i32 %t625, ptr %l179
  %t626 = icmp ne i32 %t625, 0
  br i1 %t626, label %bb117, label %ok.627, !prof !99
ok.627:
  br label %bb116
bb116:
  br label %bb118
bb117:
  %t628 = load i32, ptr %l179, !tbaa !23
  %t629 = lshr i32 %t628, 16
  %t630 = and i32 %t628, 65535
  %t631 = icmp eq i32 %t629, 1
  %t632 = select i1 %t631, i32 1, i32 0
  %t633 = icmp eq i32 %t628, 0
  %t634 = shl i32 %t632, 16
  %t635 = or i32 %t634, %t630
  %t636 = select i1 %t633, i32 0, i32 %t635
  call void @__olang_scope_close(ptr %s0)
  %t638 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t636, 0
  store { i32, %"compiler/bindgen:cx" } %t638, ptr %rv
  br label %ret
bb118:
  %t639 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t641 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v2, ptr %v2, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) }, i64 %t639)
  store %"compiler/bindgen:cx" %t641, ptr %l182
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s0)
  %t642 = load %"compiler/bindgen:cx", ptr %l182
  %t643 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t642, 1
  store { i32, %"compiler/bindgen:cx" } %t643, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/bindgen:cx" }, ptr %rv
  ret { i32, %"compiler/bindgen:cx" } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecastType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca i1
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l45 = alloca i64
  %l49 = alloca %"compiler/bindgen:ctype"
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l60 = alloca %"compiler/bindgen:ctype"
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l69 = alloca %"compiler/bindgen:ctype"
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i64, ptr } @compiler_2fbindgen_2ectokens(ptr %v1, ptr %s0, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t11, ptr %l15, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l16, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t25, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t53 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s3, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x { i64, ptr }] }>, ptr @.d56, i32 0, i32 1) }, { i64, ptr } %t49)
  store i1 %t53, ptr %l30
  br label %bb9
bb9:
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb13
bb11:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/bindgen:gen", ptr %t55, i32 0, i32 4
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t61 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %s0, ptr %t57, { i64, ptr } %t58)
  store i1 %t61, ptr %l35
  br label %bb12
bb12:
  %t62 = load i1, ptr %l35, !tbaa !21
  store i1 %t62, ptr %l31, !tbaa !21
  br label %bb13
bb13:
  %t63 = load i1, ptr %l31, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l37, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t66, ptr %l38, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l39, !tbaa !24
  %t69 = load i64, ptr %l39, !tbaa !24
  %t70 = mul i64 %t69, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l40, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l39, !tbaa !24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t80, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t81, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t82 = load i64, ptr %l4, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l4, !tbaa !24
  br label %bb5
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t90 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v1, ptr %t86, { i64, ptr } %t87, i64 0)
  store i64 %t90, ptr %l45
  br label %bb19
bb19:
  %t91 = load i64, ptr %l45, !tbaa !24
  store i64 %t91, ptr %l8, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/bindgen:gen", ptr %t92, i32 0, i32 16
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t94, i64 %t95)
  store %"compiler/bindgen:ctype" %t98, ptr %l49
  br label %bb20
bb20:
  %t99 = getelementptr %"compiler/bindgen:ctype", ptr %l49, i32 0, i32 0
  %t100 = load i32, ptr %t99, !range !{i32 0, i32 7}
  %t102 = trunc i64 1 to i32
  %t103 = icmp eq i32 %t100, %t102
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l53, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t107, ptr %l54, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l55, !tbaa !24
  %t110 = load i64, ptr %l55, !tbaa !24
  %t111 = mul i64 %t110, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t111)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l56, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l55, !tbaa !24
  %t120 = mul i64 %t119, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t116, ptr %t118, i64 %t120, i1 false)
  %t121 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t121, ptr %l54, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t122 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t122, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/bindgen:gen", ptr %t123, i32 0, i32 16
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t125, i64 %t126)
  store %"compiler/bindgen:ctype" %t129, ptr %l60
  br label %bb24
bb24:
  %t130 = getelementptr %"compiler/bindgen:ctype", ptr %l60, i32 0, i32 1
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t133 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t131, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t133, ptr %l62
  br label %bb25
bb25:
  %t134 = load i1, ptr %l62, !tbaa !21
  br i1 %t134, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t135, ptr %l63, !tbaa !27
  br label %bb29
bb27:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/bindgen:gen", ptr %t137, i32 0, i32 16
  %t140 = load i64, ptr %l8, !tbaa !24
  %t143 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t139, i64 %t140)
  store %"compiler/bindgen:ctype" %t143, ptr %l69
  br label %bb28
bb28:
  %t144 = getelementptr %"compiler/bindgen:ctype", ptr %l69, i32 0, i32 1
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = extractvalue { i64, ptr } %t145, 0
  %t149 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t147, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l63, !tbaa !27
  br label %bb29
bb29:
  %t153 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  store i64 %t154, ptr %l72, !tbaa !24
  %t155 = load i64, ptr %l72, !tbaa !24
  %t156 = mul i64 %t155, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l73, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = load i64, ptr %l72, !tbaa !24
  %t165 = mul i64 %t164, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t161, ptr %t163, i64 %t165, i1 false)
  %t166 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t166, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t167 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t167, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edeclarator(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca i1
  %l49 = alloca { i64, ptr }
  %l51 = alloca i1
  %l52 = alloca i1
  %l54 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca i1
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l64 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i1
  %l76 = alloca { i64, ptr }
  %l78 = alloca i1
  %l79 = alloca i1
  %l81 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca i1
  %l86 = alloca { i64, ptr }
  %l88 = alloca i1
  %l100 = alloca { i64, ptr }
  %l102 = alloca i1
  %l106 = alloca { i64, ptr }
  %l108 = alloca i1
  %l113 = alloca ptr
  %l116 = alloca ptr
  %l119 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l121 = alloca { i64, ptr }
  %l123 = alloca i1
  %l124 = alloca ptr
  %l127 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l134 = alloca i1
  %l136 = alloca { i64, ptr }
  %l138 = alloca i1
  %l142 = alloca { i64, ptr }
  %l144 = alloca i1
  %l145 = alloca ptr
  %l151 = alloca i64
  %l155 = alloca %"compiler/bindgen:ctype"
  %l158 = alloca i1
  %l160 = alloca i64
  %l162 = alloca i1
  %l164 = alloca { i64, ptr }
  %l166 = alloca i1
  %l171 = alloca { i64, ptr }
  %l173 = alloca i1
  %l174 = alloca ptr
  %l177 = alloca ptr
  %l182 = alloca i64
  %l184 = alloca i64
  %l186 = alloca i64
  %l191 = alloca i64
  %l197 = alloca ptr
  %l198 = alloca i32
  %l200 = alloca { i64, ptr }
  %l201 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i64
  %l209 = alloca ptr
  %l214 = alloca { i64, ptr }
  %l216 = alloca i1
  %l217 = alloca ptr
  %l221 = alloca { i64, ptr }
  %l223 = alloca i1
  %l225 = alloca i64
  %l227 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l229 = alloca i64
  %l230 = alloca i32
  %l231 = alloca i64
  %l232 = alloca i32
  %l233 = alloca ptr
  %l236 = alloca ptr
  %l242 = alloca i64
  %l246 = alloca i64
  %l249 = alloca i64
  %l267 = alloca ptr
  %l268 = alloca i32
  %l269 = alloca i64
  %l270 = alloca ptr
  %l272 = alloca i64
  %l276 = alloca i64
  %l277 = alloca i64
  %l290 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a2, ptr %l5, !tbaa !24
  store i1 %a3, ptr %l6, !tbaa !21
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s1, ptr %t5, i64 0)
  store { i64, ptr } %t7, ptr %l31
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t14, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t16, ptr %l33
  br label %bb3
bb3:
  %t17 = load i1, ptr %l33, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb34
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i1, ptr %l6, !tbaa !21
  %t27 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t20, i32 3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) }, i64 %t21, i1 %t22, i64 0)
  store i64 %t27, ptr %l39
  br label %bb7
bb7:
  %t28 = load i64, ptr %l39, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l40, !tbaa !29
  %t30 = load ptr, ptr %l40, !tbaa !29
  %t31 = getelementptr %"compiler/bindgen:ctp", ptr %t30, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = add i64 %t32, 1
  %t36 = load ptr, ptr %l40, !tbaa !29
  %t37 = getelementptr %"compiler/bindgen:ctp", ptr %t36, i32 0, i32 1
  store i64 %t34, ptr %t37, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t38, i64 0)
  store { i64, ptr } %t40, ptr %l44
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t47, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t49, ptr %l46
  br label %bb10
bb10:
  %t50 = load i1, ptr %l46, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb15
bb12:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t51, i64 0)
  store { i64, ptr } %t53, ptr %l49
  br label %bb13
bb13:
  %t54 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t60, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t62, ptr %l51
  br label %bb14
bb14:
  %t63 = load i1, ptr %l51, !tbaa !21
  store i1 %t63, ptr %l47, !tbaa !21
  br label %bb15
bb15:
  %t64 = load i1, ptr %l47, !tbaa !21
  br i1 %t64, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb20
bb17:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t65, i64 0)
  store { i64, ptr } %t67, ptr %l54
  br label %bb18
bb18:
  %t68 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t74, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t76, ptr %l56
  br label %bb19
bb19:
  %t77 = load i1, ptr %l56, !tbaa !21
  store i1 %t77, ptr %l52, !tbaa !21
  br label %bb20
bb20:
  %t78 = load i1, ptr %l52, !tbaa !21
  br i1 %t78, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb25
bb22:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t79, i64 0)
  store { i64, ptr } %t81, ptr %l59
  br label %bb23
bb23:
  %t82 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  %t84 = extractvalue { i64, ptr } %t82, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t88, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t90, ptr %l61
  br label %bb24
bb24:
  %t91 = load i1, ptr %l61, !tbaa !21
  store i1 %t91, ptr %l57, !tbaa !21
  br label %bb25
bb25:
  %t92 = load i1, ptr %l57, !tbaa !21
  %t93 = xor i1 %t92, true
  br i1 %t93, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t95, i64 0)
  store { i64, ptr } %t97, ptr %l64
  br label %bb29
bb29:
  %t98 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t104, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d67, i32 0, i32 1) })
  store i1 %t106, ptr %l66
  br label %bb30
bb30:
  %t107 = load i1, ptr %l66, !tbaa !21
  store i1 %t107, ptr %l6, !tbaa !21
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l67, !tbaa !29
  %t109 = load ptr, ptr %l67, !tbaa !29
  %t110 = getelementptr %"compiler/bindgen:ctp", ptr %t109, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  %t113 = add i64 %t111, 1
  %t115 = load ptr, ptr %l67, !tbaa !29
  %t116 = getelementptr %"compiler/bindgen:ctp", ptr %t115, i32 0, i32 1
  store i64 %t113, ptr %t116, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  br label %bb8
bb32:
  call void @__olang_scope_close(ptr %s1)
  br label %bb33
bb33:
  br label %bb1
bb34:
  store i64 -1, ptr %l7, !tbaa !24
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t117, i64 0)
  store { i64, ptr } %t119, ptr %l71
  br label %bb35
bb35:
  %t120 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t126, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store i1 %t128, ptr %l73
  br label %bb36
bb36:
  %t129 = load i1, ptr %l73, !tbaa !21
  br i1 %t129, label %bb37, label %bb38
bb37:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t130, i64 1)
  store { i64, ptr } %t132, ptr %l76
  br label %bb39
bb38:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb51
bb39:
  %t133 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t139, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t141, ptr %l78
  br label %bb40
bb40:
  %t142 = load i1, ptr %l78, !tbaa !21
  br i1 %t142, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb45
bb42:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t143, i64 1)
  store { i64, ptr } %t145, ptr %l81
  br label %bb43
bb43:
  %t146 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t152, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t154, ptr %l83
  br label %bb44
bb44:
  %t155 = load i1, ptr %l83, !tbaa !21
  store i1 %t155, ptr %l79, !tbaa !21
  br label %bb45
bb45:
  %t156 = load i1, ptr %l79, !tbaa !21
  br i1 %t156, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb50
bb47:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t157, i64 1)
  store { i64, ptr } %t159, ptr %l86
  br label %bb48
bb48:
  %t160 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t168 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t166, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t168, ptr %l88
  br label %bb49
bb49:
  %t169 = load i1, ptr %l88, !tbaa !21
  store i1 %t169, ptr %l84, !tbaa !21
  br label %bb50
bb50:
  %t170 = load i1, ptr %l84, !tbaa !21
  store i1 %t170, ptr %l74, !tbaa !21
  br label %bb51
bb51:
  %t171 = load i1, ptr %l74, !tbaa !21
  br i1 %t171, label %bb52, label %bb53
bb52:
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr %"compiler/bindgen:ctp", ptr %t172, i32 0, i32 1
  %t175 = load i64, ptr %t174, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb54
bb53:
  br label %bb73
bb54:
  store %olang.scope zeroinitializer, ptr %s4
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr %"compiler/bindgen:ctp", ptr %t179, i32 0, i32 1
  %t182 = load i64, ptr %t181, !tbaa !24
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/bindgen:ctp", ptr %t183, i32 0, i32 0
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t191 = icmp slt i64 %t182, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s4)
  br label %bb72
bb56:
  br label %bb57
bb57:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s4, ptr %t195, i64 0)
  store { i64, ptr } %t197, ptr %l100
  br label %bb58
bb58:
  %t198 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t200 = extractvalue { i64, ptr } %t198, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  %t206 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t204, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t206, ptr %l102
  br label %bb59
bb59:
  %t207 = load i1, ptr %l102, !tbaa !21
  br i1 %t207, label %bb60, label %bb61
bb60:
  %t208 = load i64, ptr %l8, !tbaa !24
  %t210 = add i64 %t208, 1
  store i64 %t210, ptr %l8, !tbaa !24
  br label %bb62
bb61:
  br label %bb62
bb62:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s4, ptr %t212, i64 0)
  store { i64, ptr } %t214, ptr %l106
  br label %bb63
bb63:
  %t215 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t223 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t221, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i1 %t223, ptr %l108
  br label %bb64
bb64:
  %t224 = load i1, ptr %l108, !tbaa !21
  br i1 %t224, label %bb65, label %bb66
bb65:
  %t225 = load i64, ptr %l8, !tbaa !24
  %t227 = sub i64 %t225, 1
  store i64 %t227, ptr %l8, !tbaa !24
  %t229 = load i64, ptr %l8, !tbaa !24
  %t231 = icmp eq i64 %t229, 0
  br i1 %t231, label %bb67, label %bb68
bb66:
  br label %bb70
bb67:
  call void @__olang_scope_close(ptr %s4)
  br label %bb72
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t233 = load ptr, ptr %l1, !tbaa !29
  store ptr %t233, ptr %l113, !tbaa !29
  %t234 = load ptr, ptr %l113, !tbaa !29
  %t235 = getelementptr %"compiler/bindgen:ctp", ptr %t234, i32 0, i32 1
  %t236 = load i64, ptr %t235, !tbaa !24
  %t238 = add i64 %t236, 1
  %t240 = load ptr, ptr %l113, !tbaa !29
  %t241 = getelementptr %"compiler/bindgen:ctp", ptr %t240, i32 0, i32 1
  store i64 %t238, ptr %t241, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb71
bb71:
  br label %bb54
bb72:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l116, !tbaa !29
  %t243 = load ptr, ptr %l116, !tbaa !29
  %t244 = getelementptr %"compiler/bindgen:ctp", ptr %t243, i32 0, i32 1
  %t245 = load i64, ptr %t244, !tbaa !24
  %t247 = add i64 %t245, 1
  %t249 = load ptr, ptr %l116, !tbaa !29
  %t250 = getelementptr %"compiler/bindgen:ctp", ptr %t249, i32 0, i32 1
  store i64 %t247, ptr %t250, !tbaa !24
  br label %bb73
bb73:
  %t251 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t251, ptr %l119
  br label %bb74
bb74:
  %t252 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l119
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t252, ptr %l9
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s8
  %t253 = load ptr, ptr %l1, !tbaa !29
  %t255 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s8, ptr %t253, i64 0)
  store { i64, ptr } %t255, ptr %l121
  br label %bb76
bb76:
  %t256 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 0
  %t258 = extractvalue { i64, ptr } %t256, 1
  %t259 = mul i64 %t257, 1
  %t260 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t259)
  call void @llvm.memcpy.p0.p0.i64(ptr %t260, ptr %t258, i64 %t259, i1 false)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  %t264 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s8, { i64, ptr } %t262, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t264, ptr %l123
  br label %bb77
bb77:
  %t265 = load i1, ptr %l123, !tbaa !21
  br i1 %t265, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s9
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l124, !tbaa !29
  %t267 = load ptr, ptr %l124, !tbaa !29
  %t268 = getelementptr %"compiler/bindgen:ctp", ptr %t267, i32 0, i32 1
  %t269 = load i64, ptr %t268, !tbaa !24
  %t271 = add i64 %t269, 1
  %t273 = load ptr, ptr %l124, !tbaa !29
  %t274 = getelementptr %"compiler/bindgen:ctp", ptr %t273, i32 0, i32 1
  store i64 %t271, ptr %t274, !tbaa !24
  %t275 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s9, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t275, ptr %l127
  br label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s18
  %t276 = load ptr, ptr %l1, !tbaa !29
  %t278 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s18, ptr %t276, i64 0)
  store { i64, ptr } %t278, ptr %l214
  br label %bb133
bb80:
  %t279 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l127
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t279, ptr %l10
  store i1 false, ptr %l11, !tbaa !21
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s10
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t282 = getelementptr %"compiler/bindgen:ctp", ptr %t280, i32 0, i32 1
  %t283 = load i64, ptr %t282, !tbaa !24
  %t284 = load ptr, ptr %l1, !tbaa !29
  %t286 = getelementptr %"compiler/bindgen:ctp", ptr %t284, i32 0, i32 0
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t292 = icmp slt i64 %t283, %t289
  br i1 %t292, label %bb82, label %bb83
bb82:
  %t294 = load ptr, ptr %l1, !tbaa !29
  %t296 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s10, ptr %t294, i64 0)
  store { i64, ptr } %t296, ptr %l136
  br label %bb84
bb83:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb86
bb84:
  %t297 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 0
  %t299 = extractvalue { i64, ptr } %t297, 1
  %t300 = mul i64 %t298, 1
  %t301 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t300)
  call void @llvm.memcpy.p0.p0.i64(ptr %t301, ptr %t299, i64 %t300, i1 false)
  %t302 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t301, 1
  %t305 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t303, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i1 %t305, ptr %l138
  br label %bb85
bb85:
  %t306 = load i1, ptr %l138, !tbaa !21
  %t307 = xor i1 %t306, true
  store i1 %t307, ptr %l134, !tbaa !21
  br label %bb86
bb86:
  %t309 = load i1, ptr %l134, !tbaa !21
  %t310 = xor i1 %t309, true
  br i1 %t310, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s10)
  br label %bb116
bb88:
  br label %bb89
bb89:
  %t312 = load ptr, ptr %l1, !tbaa !29
  %t314 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s10, ptr %t312, i64 0)
  store { i64, ptr } %t314, ptr %l142
  br label %bb90
bb90:
  %t315 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 0
  %t317 = extractvalue { i64, ptr } %t315, 1
  %t318 = mul i64 %t316, 1
  %t319 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t318)
  call void @llvm.memcpy.p0.p0.i64(ptr %t319, ptr %t317, i64 %t318, i1 false)
  %t320 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  %t323 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t321, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) })
  store i1 %t323, ptr %l144
  br label %bb91
bb91:
  %t324 = load i1, ptr %l144, !tbaa !21
  br i1 %t324, label %bb92, label %bb93
bb92:
  store i1 true, ptr %l11, !tbaa !21
  %t325 = load ptr, ptr %l1, !tbaa !29
  store ptr %t325, ptr %l145, !tbaa !29
  %t326 = load ptr, ptr %l145, !tbaa !29
  %t327 = getelementptr %"compiler/bindgen:ctp", ptr %t326, i32 0, i32 1
  %t328 = load i64, ptr %t327, !tbaa !24
  %t330 = add i64 %t328, 1
  %t332 = load ptr, ptr %l145, !tbaa !29
  %t333 = getelementptr %"compiler/bindgen:ctp", ptr %t332, i32 0, i32 1
  store i64 %t330, ptr %t333, !tbaa !24
  br label %bb109
bb93:
  store %olang.scope zeroinitializer, ptr %s12
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t336 = load i64, ptr %l4, !tbaa !24
  %t340 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etypeName(ptr %v0, ptr %v1, ptr %t334, ptr %t335, i64 %t336)
  store i64 %t340, ptr %l151
  br label %bb94
bb94:
  %t341 = load i64, ptr %l151, !tbaa !24
  store i64 %t341, ptr %l12, !tbaa !24
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/bindgen:gen", ptr %t342, i32 0, i32 16
  %t345 = load i64, ptr %l12, !tbaa !24
  %t348 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s12, ptr %t344, i64 %t345)
  store %"compiler/bindgen:ctype" %t348, ptr %l155
  br label %bb95
bb95:
  %t349 = getelementptr %"compiler/bindgen:ctype", ptr %l155, i32 0, i32 0
  %t350 = load i32, ptr %t349, !range !{i32 0, i32 7}
  %t352 = trunc i64 0 to i32
  %t353 = icmp eq i32 %t350, %t352
  br i1 %t353, label %bb96, label %bb97
bb96:
  %t356 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %l10)
  store i64 %t356, ptr %l160
  br label %bb98
bb97:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb99
bb98:
  %t357 = load i64, ptr %l160, !tbaa !24
  %t358 = icmp eq i64 %t357, 0
  store i1 %t358, ptr %l158, !tbaa !21
  br label %bb99
bb99:
  %t360 = load i1, ptr %l158, !tbaa !21
  br i1 %t360, label %bb100, label %bb101
bb100:
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t363 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s12, ptr %t361, i64 0)
  store { i64, ptr } %t363, ptr %l164
  br label %bb102
bb101:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb104
bb102:
  %t364 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = extractvalue { i64, ptr } %t364, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  %t372 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s12, ptr %s12, { i64, ptr } %t370, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t372, ptr %l166
  br label %bb103
bb103:
  %t373 = load i1, ptr %l166, !tbaa !21
  store i1 %t373, ptr %l162, !tbaa !21
  br label %bb104
bb104:
  %t374 = load i1, ptr %l162, !tbaa !21
  %t375 = xor i1 %t374, true
  br i1 %t375, label %bb105, label %bb106
bb105:
  %t377 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s9, ptr %l10, i64 %t377)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s12)
  br label %bb109
bb109:
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s10, ptr %t380, i64 0)
  store { i64, ptr } %t382, ptr %l171
  br label %bb110
bb110:
  %t383 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 0
  %t385 = extractvalue { i64, ptr } %t383, 1
  %t386 = mul i64 %t384, 1
  %t387 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t386)
  call void @llvm.memcpy.p0.p0.i64(ptr %t387, ptr %t385, i64 %t386, i1 false)
  %t388 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t387, 1
  %t391 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t389, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t391, ptr %l173
  br label %bb111
bb111:
  %t392 = load i1, ptr %l173, !tbaa !21
  br i1 %t392, label %bb112, label %bb113
bb112:
  %t393 = load ptr, ptr %l1, !tbaa !29
  store ptr %t393, ptr %l174, !tbaa !29
  %t394 = load ptr, ptr %l174, !tbaa !29
  %t395 = getelementptr %"compiler/bindgen:ctp", ptr %t394, i32 0, i32 1
  %t396 = load i64, ptr %t395, !tbaa !24
  %t398 = add i64 %t396, 1
  %t400 = load ptr, ptr %l174, !tbaa !29
  %t401 = getelementptr %"compiler/bindgen:ctp", ptr %t400, i32 0, i32 1
  store i64 %t398, ptr %t401, !tbaa !24
  br label %bb114
bb113:
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb115:
  br label %bb81
bb116:
  %t402 = load ptr, ptr %l1, !tbaa !29
  store ptr %t402, ptr %l177, !tbaa !29
  %t403 = load ptr, ptr %l177, !tbaa !29
  %t404 = getelementptr %"compiler/bindgen:ctp", ptr %t403, i32 0, i32 1
  %t405 = load i64, ptr %t404, !tbaa !24
  %t407 = add i64 %t405, 1
  %t409 = load ptr, ptr %l177, !tbaa !29
  %t410 = getelementptr %"compiler/bindgen:ctp", ptr %t409, i32 0, i32 1
  store i64 %t407, ptr %t410, !tbaa !24
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/bindgen:gen", ptr %t411, i32 0, i32 17
  %t415 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t413)
  store i64 %t415, ptr %l182
  br label %bb117
bb117:
  %t416 = load i64, ptr %l182, !tbaa !24
  store i64 %t416, ptr %l13, !tbaa !24
  store ptr %l10, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb118
bb118:
  %t418 = load i64, ptr %l15, !tbaa !24
  store i64 %t418, ptr %l184, !tbaa !24
  %t419 = load ptr, ptr %l14, !tbaa !29
  %t421 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %t419)
  store i64 %t421, ptr %l186
  br label %bb119
bb119:
  %t422 = load i64, ptr %l184, !tbaa !24
  %t423 = load i64, ptr %l186, !tbaa !24
  %t424 = icmp slt i64 %t422, %t423
  %t426 = xor i1 %t424, true
  br i1 %t426, label %bb120, label %bb121
bb120:
  br label %bb126
bb121:
  br label %bb122
bb122:
  %t428 = load ptr, ptr %l14, !tbaa !29
  %t429 = load i64, ptr %l15, !tbaa !24
  %t432 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s9, ptr %t428, i64 %t429)
  store i64 %t432, ptr %l191
  br label %bb123
bb123:
  %t433 = load i64, ptr %l191, !tbaa !24
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/bindgen:gen", ptr %t434, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t436, i64 %t433)
  br label %bb124
bb124:
  br label %bb125
bb125:
  %t440 = load i64, ptr %l15, !tbaa !24
  %t442 = add i64 %t440, 1
  store i64 %t442, ptr %l15, !tbaa !24
  br label %bb118
bb126:
  %t444 = load ptr, ptr %l0, !tbaa !29
  store ptr %t444, ptr %l197, !tbaa !29
  store i32 5, ptr %l198
  %t445 = load i1, ptr %l11, !tbaa !21
  br i1 %t445, label %bb127, label %bb128
bb127:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l200, !tbaa !27
  br label %bb129
bb128:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l200, !tbaa !27
  br label %bb129
bb129:
  %t447 = load i64, ptr %l5, !tbaa !24
  store i64 %t447, ptr %l201, !tbaa !24
  %t449 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %l10)
  store i64 %t449, ptr %l203
  br label %bb130
bb130:
  %t450 = load ptr, ptr %l197, !tbaa !29
  %t451 = load i32, ptr %l198, !range !{i32 0, i32 7}
  %t452 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t453 = load i64, ptr %l201, !tbaa !24
  %t454 = load i64, ptr %l203, !tbaa !24
  %t455 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t450, i32 %t451, { i64, ptr } %t452, i64 %t453, i1 false, i64 %t454)
  store i64 %t455, ptr %l204
  br label %bb131
bb131:
  %t456 = load i64, ptr %l204, !tbaa !24
  store i64 %t456, ptr %l17, !tbaa !24
  %t457 = load i64, ptr %l17, !tbaa !24
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/bindgen:gen", ptr %t459, i32 0, i32 16
  %t465 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eRefMut_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t461, i64 %t457)
  store ptr %t465, ptr %l209
  br label %bb132
bb132:
  %t466 = load ptr, ptr %l209, !tbaa !29
  %t468 = load i64, ptr %l13, !tbaa !24
  %t471 = getelementptr %"compiler/bindgen:ctype", ptr %t466, i32 0, i32 5
  store i64 %t468, ptr %t471, !tbaa !24
  %t472 = load i64, ptr %l17, !tbaa !24
  store i64 %t472, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb151
bb133:
  %t474 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t474, 0
  %t476 = extractvalue { i64, ptr } %t474, 1
  %t477 = mul i64 %t475, 1
  %t478 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t477)
  call void @llvm.memcpy.p0.p0.i64(ptr %t478, ptr %t476, i64 %t477, i1 false)
  %t479 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t478, 1
  %t482 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s18, ptr %s18, { i64, ptr } %t480, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t482, ptr %l216
  br label %bb134
bb134:
  %t483 = load i1, ptr %l216, !tbaa !21
  br i1 %t483, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s19
  %t484 = load ptr, ptr %l1, !tbaa !29
  store ptr %t484, ptr %l217, !tbaa !29
  %t485 = load ptr, ptr %l217, !tbaa !29
  %t486 = getelementptr %"compiler/bindgen:ctp", ptr %t485, i32 0, i32 1
  %t487 = load i64, ptr %t486, !tbaa !24
  %t489 = add i64 %t487, 1
  %t491 = load ptr, ptr %l217, !tbaa !29
  %t492 = getelementptr %"compiler/bindgen:ctp", ptr %t491, i32 0, i32 1
  store i64 %t489, ptr %t492, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t495 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s19, ptr %t493, i64 0)
  store { i64, ptr } %t495, ptr %l221
  br label %bb137
bb136:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s8)
  br label %bb153
bb137:
  %t496 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t496, 0
  %t498 = extractvalue { i64, ptr } %t496, 1
  %t499 = mul i64 %t497, 1
  %t500 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t499)
  call void @llvm.memcpy.p0.p0.i64(ptr %t500, ptr %t498, i64 %t499, i1 false)
  %t501 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t500, 1
  %t504 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s19, ptr %s19, { i64, ptr } %t502, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t504, ptr %l223
  br label %bb138
bb138:
  %t505 = load i1, ptr %l223, !tbaa !21
  %t506 = xor i1 %t505, true
  br i1 %t506, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s20
  %t508 = load ptr, ptr %l1, !tbaa !29
  %t510 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s20, ptr %t508, i64 0)
  store { i64, ptr } %t510, ptr %l227
  br label %bb141
bb140:
  br label %bb148
bb141:
  %t511 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t512 = extractvalue { i64, ptr } %t511, 0
  %t513 = extractvalue { i64, ptr } %t511, 1
  %t514 = mul i64 %t512, 1
  %t515 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t514)
  call void @llvm.memcpy.p0.p0.i64(ptr %t515, ptr %t513, i64 %t514, i1 false)
  %t516 = insertvalue { i64, ptr } undef, i64 %t512, 0
  %t517 = insertvalue { i64, ptr } %t516, ptr %t515, 1
  store { i64, ptr } %t517, ptr %l228, !tbaa !27
  %t518 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s20, i64 10)
  %t519 = extractvalue { i32, i64 } %t518, 1
  %t520 = extractvalue { i32, i64 } %t518, 0
  store i32 %t520, ptr %l230
  %t521 = icmp ne i32 %t520, 0
  br i1 %t521, label %bb143, label %ok.522, !prof !99
ok.522:
  store i64 %t519, ptr %l229
  br label %bb142
bb142:
  %t523 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t524 = load i64, ptr %l229, !tbaa !24
  %t525 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s20, { i64, ptr } %t523, i64 %t524)
  %t526 = extractvalue { i32, i64 } %t525, 1
  %t527 = extractvalue { i32, i64 } %t525, 0
  store i32 %t527, ptr %l232
  %t528 = icmp ne i32 %t527, 0
  br i1 %t528, label %bb146, label %ok.529, !prof !99
ok.529:
  store i64 %t526, ptr %l231
  br label %bb145
bb143:
  br label %bb144
bb144:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l225, !tbaa !24
  br label %bb147
bb145:
  %t530 = load i64, ptr %l231, !tbaa !24
  store i64 %t530, ptr %l225, !tbaa !24
  br label %bb147
bb146:
  br label %bb144
bb147:
  %t531 = load i64, ptr %l225, !tbaa !24
  store i64 %t531, ptr %l20, !tbaa !24
  %t532 = load ptr, ptr %l1, !tbaa !29
  store ptr %t532, ptr %l233, !tbaa !29
  %t533 = load ptr, ptr %l233, !tbaa !29
  %t534 = getelementptr %"compiler/bindgen:ctp", ptr %t533, i32 0, i32 1
  %t535 = load i64, ptr %t534, !tbaa !24
  %t537 = add i64 %t535, 1
  %t539 = load ptr, ptr %l233, !tbaa !29
  %t540 = getelementptr %"compiler/bindgen:ctp", ptr %t539, i32 0, i32 1
  store i64 %t537, ptr %t540, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb148
bb148:
  %t541 = load ptr, ptr %l1, !tbaa !29
  store ptr %t541, ptr %l236, !tbaa !29
  %t542 = load ptr, ptr %l236, !tbaa !29
  %t543 = getelementptr %"compiler/bindgen:ctp", ptr %t542, i32 0, i32 1
  %t544 = load i64, ptr %t543, !tbaa !24
  %t546 = add i64 %t544, 1
  %t548 = load ptr, ptr %l236, !tbaa !29
  %t549 = getelementptr %"compiler/bindgen:ctp", ptr %t548, i32 0, i32 1
  store i64 %t546, ptr %t549, !tbaa !24
  %t550 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t550)
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s19)
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s18)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s8)
  br label %bb152
bb152:
  br label %bb75
bb153:
  store i64 0, ptr %l21, !tbaa !24
  %t554 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l9)
  store i64 %t554, ptr %l242
  br label %bb154
bb154:
  %t555 = load i64, ptr %l242, !tbaa !24
  store i64 %t555, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t556 = load i64, ptr %l22, !tbaa !24
  %t557 = load i64, ptr %l21, !tbaa !24
  %t560 = icmp sgt i64 %t556, %t557
  br i1 %t560, label %bb155, label %bb156
bb155:
  %t562 = load i64, ptr %l23, !tbaa !24
  %t564 = icmp sgt i64 %t562, 0
  br i1 %t564, label %bb157, label %bb158
bb156:
  store i64 0, ptr %l246, !tbaa !24
  br label %bb160
bb157:
  %t566 = load i64, ptr %l22, !tbaa !24
  %t567 = load i64, ptr %l21, !tbaa !24
  %t570 = sub i64 %t566, %t567
  %t571 = load i64, ptr %l23, !tbaa !24
  %t574 = add i64 %t570, %t571
  %t576 = sub i64 %t574, 1
  %t577 = load i64, ptr %l23, !tbaa !24
  %t580 = sdiv i64 %t576, %t577
  store i64 %t580, ptr %l249, !tbaa !24
  br label %bb159
bb158:
  store i64 0, ptr %l249, !tbaa !24
  br label %bb159
bb159:
  %t582 = load i64, ptr %l249, !tbaa !24
  store i64 %t582, ptr %l246, !tbaa !24
  br label %bb160
bb160:
  %t583 = load i64, ptr %l246, !tbaa !24
  store i64 %t583, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb161
bb161:
  %t584 = load i64, ptr %l25, !tbaa !24
  %t585 = load i64, ptr %l24, !tbaa !24
  %t588 = icmp slt i64 %t584, %t585
  %t590 = xor i1 %t588, true
  br i1 %t590, label %bb162, label %bb163
bb162:
  br label %bb169
bb163:
  br label %bb164
bb164:
  %t592 = load i64, ptr %l21, !tbaa !24
  %t593 = load i64, ptr %l25, !tbaa !24
  %t594 = load i64, ptr %l23, !tbaa !24
  %t597 = mul i64 %t593, %t594
  %t600 = add i64 %t592, %t597
  store i64 %t600, ptr %l26, !tbaa !24
  %t602 = load ptr, ptr %l0, !tbaa !29
  store ptr %t602, ptr %l267, !tbaa !29
  store i32 4, ptr %l268
  %t603 = load i64, ptr %l5, !tbaa !24
  store i64 %t603, ptr %l269, !tbaa !24
  store ptr %l9, ptr %l270, !tbaa !29
  %t605 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l9)
  store i64 %t605, ptr %l272
  br label %bb165
bb165:
  %t606 = load i64, ptr %l272, !tbaa !24
  %t607 = sub i64 %t606, 1
  %t608 = load i64, ptr %l26, !tbaa !24
  %t611 = sub i64 %t607, %t608
  %t612 = load ptr, ptr %l270, !tbaa !29
  %t614 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t612, i64 %t611)
  store i64 %t614, ptr %l276
  br label %bb166
bb166:
  %t615 = load ptr, ptr %l267, !tbaa !29
  %t616 = load i32, ptr %l268, !range !{i32 0, i32 7}
  %t617 = load i64, ptr %l269, !tbaa !24
  %t618 = load i64, ptr %l276, !tbaa !24
  %t619 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t615, i32 %t616, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) }, i64 %t617, i1 false, i64 %t618)
  store i64 %t619, ptr %l277
  br label %bb167
bb167:
  %t620 = load i64, ptr %l277, !tbaa !24
  store i64 %t620, ptr %l5, !tbaa !24
  br label %bb168
bb168:
  %t621 = load i64, ptr %l25, !tbaa !24
  %t623 = add i64 %t621, 1
  store i64 %t623, ptr %l25, !tbaa !24
  br label %bb161
bb169:
  %t625 = load i64, ptr %l7, !tbaa !24
  %t627 = icmp sge i64 %t625, 0
  br i1 %t627, label %bb170, label %bb171
bb170:
  %t629 = load ptr, ptr %l1, !tbaa !29
  %t631 = getelementptr %"compiler/bindgen:ctp", ptr %t629, i32 0, i32 1
  %t632 = load i64, ptr %t631, !tbaa !24
  store i64 %t632, ptr %l27, !tbaa !24
  %t634 = load ptr, ptr %l1, !tbaa !29
  %t635 = load i64, ptr %l7, !tbaa !24
  %t638 = getelementptr %"compiler/bindgen:ctp", ptr %t634, i32 0, i32 1
  store i64 %t635, ptr %t638, !tbaa !24
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t640 = load ptr, ptr %l1, !tbaa !29
  %t641 = load i64, ptr %l5, !tbaa !24
  %t642 = load i64, ptr %l4, !tbaa !24
  %t647 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edeclarator(ptr %v0, ptr %v1, ptr %t639, ptr %t640, i64 %t641, i1 false, i64 %t642)
  store i64 %t647, ptr %l290
  br label %bb172
bb171:
  br label %bb173
bb172:
  %t648 = load i64, ptr %l290, !tbaa !24
  store i64 %t648, ptr %l5, !tbaa !24
  %t649 = load ptr, ptr %l1, !tbaa !29
  %t650 = load i64, ptr %l27, !tbaa !24
  %t653 = getelementptr %"compiler/bindgen:ctp", ptr %t649, i32 0, i32 1
  store i64 %t650, ptr %t653, !tbaa !24
  br label %bb173
bb173:
  %t654 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t654, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eopaque(ptr %v0, ptr %t7, i64 %t8)
  store i1 %t11, ptr %l8
  br label %bb4
bb4:
  %t12 = load i1, ptr %l8, !tbaa !21
  store i1 %t12, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l5, !tbaa !21
  store i1 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emacroFns(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/bindgen:cMacro"
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca %"compiler/bindgen:cMacro"
  %l17 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l28 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l46 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 12
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/bindgen:cMacro" %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load %"compiler/bindgen:cMacro", ptr %l15
  store %"compiler/bindgen:cMacro" %t20, ptr %l3
  %t21 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t22, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t24, ptr %l17
  br label %bb7
bb7:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t26 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 1
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  %t32 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 4
  %t33 = load i1, ptr %t32, !tbaa !21
  %t35 = xor i1 %t33, true
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l21, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb17
bb15:
  %t38 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t39)
  store i1 %t41, ptr %l26
  br label %bb16
bb16:
  %t42 = load i1, ptr %l26, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb21
bb19:
  %t46 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/bindgen:gen", ptr %t49, i32 0, i32 21
  %t55 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t51, { i64, ptr } %t47)
  store i1 %t55, ptr %l33
  br label %bb20
bb20:
  %t56 = load i1, ptr %l33, !tbaa !21
  store i1 %t56, ptr %l28, !tbaa !21
  br label %bb21
bb21:
  %t57 = load i1, ptr %l28, !tbaa !21
  br i1 %t57, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb25
bb23:
  %t58 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = call i1 @compiler_2fbindgen_2epreludeName(ptr %v0, { i64, ptr } %t59)
  store i1 %t61, ptr %l36
  br label %bb24
bb24:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l34, !tbaa !21
  br label %bb25
bb25:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t64 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 5
  %t65 = load i1, ptr %t64, !tbaa !21
  br i1 %t65, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %s4, ptr %t67, { i64, ptr } %t69, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d85, i32 0, i32 1) })
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb32:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emacroFn(ptr %v0, ptr %s2, ptr %s2, ptr %t72, ptr %l3)
  %t76 = extractvalue { i32, { i64, ptr } } %t75, 1
  %t77 = extractvalue { i32, { i64, ptr } } %t75, 0
  store i32 %t77, ptr %l44
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb34, label %ok.79, !prof !99
ok.79:
  store { i64, ptr } %t76, ptr %l43
  br label %bb33
bb33:
  %t80 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t80, ptr %l40, !tbaa !27
  br label %bb37
bb34:
  %t81 = load i32, ptr %l44, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  store i1 %t84, ptr %l46, !tbaa !21
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/bindgen:gen", ptr %t88, i32 0, i32 25
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %v0, ptr %t85, { i64, ptr } %t87, { i64, ptr } %t91)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb37:
  %t95 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/bindgen:gen", ptr %t96, i32 0, i32 14
  %t101 = extractvalue { i64, ptr } %t95, 1
  %t102 = extractvalue { i64, ptr } %t95, 0
  %t103 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t101, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t108 = extractvalue { i64, ptr } %t105, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t98, { i64, ptr } %t112)
  br label %bb38
bb38:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/bindgen:gen", ptr %t115, i32 0, i32 21
  %t118 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = extractvalue { i64, ptr } %t119, 0
  %t123 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t121, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t117, { i64, ptr } %t132, i64 0)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t135 = load i64, ptr %l2, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l2, !tbaa !24
  br label %bb1
bb41:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca %"compiler/bindgen:record"
  %l7 = alloca %"compiler/bindgen:record"
  %rv = alloca { i64, ptr }
  %t5 = alloca %"compiler/bindgen:record", align 8
  %t8 = alloca %"compiler/bindgen:record", align 8
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %t5, i64 176, i1 false)
  br label %bb1
bb1:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t8, ptr %v0, ptr %l5)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t8, i64 176, i1 false)
  br label %bb2
bb2:
  %t10 = getelementptr %"compiler/bindgen:record", ptr %l7, i32 0, i32 7
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = extractvalue { i64, ptr } %t11, 0
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t13, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecords(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l27 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l51 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l79 = alloca %"compiler/bindgen:record"
  %l81 = alloca %"compiler/bindgen:record"
  %l83 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l92 = alloca %"compiler/bindgen:record"
  %l94 = alloca %"compiler/bindgen:record"
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t149 = alloca %"compiler/bindgen:record", align 8
  %t152 = alloca %"compiler/bindgen:record", align 8
  %t168 = alloca %"compiler/bindgen:record", align 8
  %t171 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 4
  %t5 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd80cb4cbc6ceb8a13686fbc19b8451b4(ptr %v0, ptr %v0, ptr %t3)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l13
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t6, ptr %l1
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H116ed76223103781f5a7340c80f3d0f3(ptr %v0, ptr %v0, ptr %l1)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l17
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l16
  br label %bb3
bb3:
  %t13 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t13, ptr %l14, !tbaa !27
  br label %bb6
bb4:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb6:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/bindgen:gen", ptr %t19, i32 0, i32 4
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v0, ptr %v0, ptr %t21, { i64, ptr } %t22)
  %t26 = extractvalue { i32, { i64, ptr } } %t25, 1
  %t27 = extractvalue { i32, { i64, ptr } } %t25, 0
  store i32 %t27, ptr %l25
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb8, label %ok.29, !prof !99
ok.29:
  store { i64, ptr } %t26, ptr %l24
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t30, ptr %l20, !tbaa !27
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb10
bb10:
  %t31 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t31, ptr %l3, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t32, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i1 %t34, ptr %l27
  br label %bb11
bb11:
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb15
bb13:
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t36, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i1 %t38, ptr %l30
  br label %bb14
bb14:
  %t39 = load i1, ptr %l30, !tbaa !21
  store i1 %t39, ptr %l28, !tbaa !21
  br label %bb15
bb15:
  %t40 = load i1, ptr %l28, !tbaa !21
  br i1 %t40, label %bb16, label %bb17
bb16:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/bindgen:gen", ptr %t43, i32 0, i32 22
  %t49 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v0, ptr %t45, { i64, ptr } %t41)
  store i1 %t49, ptr %l36
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t50 = load i1, ptr %l36, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t56 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t54)
  store i1 %t56, ptr %l40
  br label %bb22
bb21:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb23
bb22:
  %t57 = load i1, ptr %l40, !tbaa !21
  store i1 %t57, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t58 = load i1, ptr %l38, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/bindgen:gen", ptr %t59, i32 0, i32 22
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = extractvalue { i64, ptr } %t62, 0
  %t66 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t64, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 1
  %t79 = extractvalue { i64, ptr } %t76, 0
  %t80 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t78, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } %t82, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t61, { i64, ptr } %t75, { i64, ptr } %t89)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  br label %bb2
bb29:
  store i64 0, ptr %l5, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/bindgen:gen", ptr %t93, i32 0, i32 5
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l51
  br label %bb30
bb30:
  %t98 = load i64, ptr %l51, !tbaa !24
  store i64 %t98, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t100 = load i64, ptr %l5, !tbaa !24
  %t103 = icmp sgt i64 %t99, %t100
  br i1 %t103, label %bb31, label %bb32
bb31:
  %t105 = load i64, ptr %l7, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb36
bb33:
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l5, !tbaa !24
  %t113 = sub i64 %t109, %t110
  %t114 = load i64, ptr %l7, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = sub i64 %t117, 1
  %t120 = load i64, ptr %l7, !tbaa !24
  %t123 = sdiv i64 %t119, %t120
  store i64 %t123, ptr %l58, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb35
bb35:
  %t125 = load i64, ptr %l58, !tbaa !24
  store i64 %t125, ptr %l55, !tbaa !24
  br label %bb36
bb36:
  %t126 = load i64, ptr %l55, !tbaa !24
  store i64 %t126, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t127 = load i64, ptr %l9, !tbaa !24
  %t128 = load i64, ptr %l8, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb39:
  br label %bb40
bb40:
  %t135 = load i64, ptr %l5, !tbaa !24
  %t136 = load i64, ptr %l9, !tbaa !24
  %t137 = load i64, ptr %l7, !tbaa !24
  %t140 = mul i64 %t136, %t137
  %t143 = add i64 %t135, %t140
  store i64 %t143, ptr %l10, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/bindgen:gen", ptr %t145, i32 0, i32 5
  %t148 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t149, ptr %v0, ptr %v0, ptr %t147, i64 %t148)
  call void @llvm.memmove.p0.p0.i64(ptr %l79, ptr %t149, i64 176, i1 false)
  br label %bb41
bb41:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t152, ptr %v0, ptr %l79)
  call void @llvm.memmove.p0.p0.i64(ptr %l81, ptr %t152, i64 176, i1 false)
  br label %bb42
bb42:
  %t154 = getelementptr %"compiler/bindgen:record", ptr %l81, i32 0, i32 0
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  %t157 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t155, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t157, ptr %l83
  br label %bb43
bb43:
  %t158 = load i1, ptr %l83, !tbaa !21
  br i1 %t158, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb54
bb45:
  br label %bb46
bb46:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l84, !tbaa !29
  %t160 = load i64, ptr %l10, !tbaa !24
  store i64 %t160, ptr %l85, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/bindgen:gen", ptr %t161, i32 0, i32 22
  store ptr %t163, ptr %l88, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/bindgen:gen", ptr %t164, i32 0, i32 5
  %t167 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t168, ptr %v0, ptr %v0, ptr %t166, i64 %t167)
  call void @llvm.memmove.p0.p0.i64(ptr %l92, ptr %t168, i64 176, i1 false)
  br label %bb47
bb47:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t171, ptr %v0, ptr %l92)
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr %t171, i64 176, i1 false)
  br label %bb48
bb48:
  %t173 = getelementptr %"compiler/bindgen:record", ptr %l94, i32 0, i32 0
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t175 = load ptr, ptr %l88, !tbaa !29
  %t177 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v0, ptr %v0, ptr %t175, { i64, ptr } %t174)
  %t178 = extractvalue { i32, { i64, ptr } } %t177, 1
  %t179 = extractvalue { i32, { i64, ptr } } %t177, 0
  store i32 %t179, ptr %l97
  %t180 = icmp ne i32 %t179, 0
  br i1 %t180, label %bb50, label %ok.181, !prof !99
ok.181:
  store { i64, ptr } %t178, ptr %l96
  br label %bb49
bb49:
  %t182 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t182, ptr %l86, !tbaa !27
  br label %bb52
bb50:
  br label %bb51
bb51:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb52
bb52:
  %t183 = load ptr, ptr %l84, !tbaa !29
  %t184 = load i64, ptr %l85, !tbaa !24
  %t185 = load { i64, ptr }, ptr %l86, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecord(ptr %v0, ptr %v0, ptr %t183, i64 %t184, { i64, ptr } %t185)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s7)
  br label %bb54
bb54:
  %t186 = load i64, ptr %l9, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l9, !tbaa !24
  br label %bb37
bb55:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/bindgen:gen", ptr %t190, i32 0, i32 23
  store i1 true, ptr %t192, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eopaque(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:record", ptr %t9, i32 0, i32 2
  %t12 = load i1, ptr %t11, !tbaa !21
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/bindgen:record", ptr %t16, i32 0, i32 10
  %t19 = load i1, ptr %t18, !tbaa !21
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb8
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t26, ptr %l16
  br label %bb7
bb7:
  %t27 = load i1, ptr %l16, !tbaa !21
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/bindgen:record", ptr %t30, i32 0, i32 13
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/bindgen:record", ptr %t37, i32 0, i32 14
  %t40 = load i64, ptr %t39, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  store i1 %t42, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l21, !tbaa !21
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/bindgen:record", ptr %t45, i32 0, i32 14
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = icmp sle i64 %t48, 8
  store i1 %t50, ptr %l25, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb17
bb17:
  %t52 = load i1, ptr %l25, !tbaa !21
  br i1 %t52, label %bb18, label %bb19
bb18:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/bindgen:record", ptr %t53, i32 0, i32 13
  %t56 = load i64, ptr %t55, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/bindgen:record", ptr %t57, i32 0, i32 14
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = srem i64 %t56, %t60
  %t65 = icmp eq i64 %t63, 0
  store i1 %t65, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l29, !tbaa !21
  store i1 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamType(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/bindgen:ctype"
  %l3 = alloca i64
  %l7 = alloca %"compiler/bindgen:ctype"
  %l12 = alloca i64
  %l16 = alloca %"compiler/bindgen:record"
  %l18 = alloca %"compiler/bindgen:record"
  %l20 = alloca i1
  %l24 = alloca %"compiler/bindgen:record"
  %l26 = alloca %"compiler/bindgen:record"
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca %"compiler/bindgen:record"
  %l38 = alloca %"compiler/bindgen:record"
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i32
  %l47 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i32
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i32
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t26 = alloca %"compiler/bindgen:record", align 8
  %t29 = alloca %"compiler/bindgen:record", align 8
  %t38 = alloca %"compiler/bindgen:record", align 8
  %t41 = alloca %"compiler/bindgen:record", align 8
  %t56 = alloca %"compiler/bindgen:record", align 8
  %t59 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 16
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/bindgen:ctype" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l7
  store %"compiler/bindgen:ctype" %t8, ptr %l2
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 0
  %t10 = load i32, ptr %t9, !range !{i32 0, i32 7}
  %t12 = trunc i64 2 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t20 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v0, ptr %t15, { i64, ptr } %t17)
  store i64 %t20, ptr %l12
  br label %bb4
bb3:
  br label %bb23
bb4:
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/bindgen:gen", ptr %t22, i32 0, i32 5
  %t25 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t26, ptr %v0, ptr %s1, ptr %t24, i64 %t25)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t26, i64 176, i1 false)
  br label %bb5
bb5:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t29, ptr %s1, ptr %l16)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t29, i64 176, i1 false)
  br label %bb6
bb6:
  %t31 = getelementptr %"compiler/bindgen:record", ptr %l18, i32 0, i32 12
  %t32 = load i1, ptr %t31, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/bindgen:gen", ptr %t34, i32 0, i32 5
  %t37 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t38, ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t38, i64 176, i1 false)
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb9:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t41, ptr %v0, ptr %l24)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t41, i64 176, i1 false)
  br label %bb10
bb10:
  %t43 = getelementptr %"compiler/bindgen:record", ptr %l26, i32 0, i32 5
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l28
  br label %bb11
bb11:
  %t46 = load i64, ptr %l28, !tbaa !24
  %t47 = icmp sgt i64 %t46, 0
  store i1 %t47, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t49 = load i1, ptr %l20, !tbaa !21
  br i1 %t49, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l31, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l32, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/bindgen:gen", ptr %t52, i32 0, i32 5
  %t55 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t56, ptr %v0, ptr %v0, ptr %t54, i64 %t55)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t56, i64 176, i1 false)
  br label %bb15
bb14:
  br label %bb22
bb15:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t59, ptr %v0, ptr %l36)
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t59, i64 176, i1 false)
  br label %bb16
bb16:
  %t61 = getelementptr %"compiler/bindgen:record", ptr %l38, i32 0, i32 5
  %t63 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s2, ptr %t61, i64 0)
  store { i64, ptr } %t63, ptr %l40
  br label %bb17
bb17:
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t66 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s2, ptr %t64, { i64, ptr } %t65, i64 0)
  store i64 %t66, ptr %l41
  br label %bb18
bb18:
  %t67 = load ptr, ptr %l31, !tbaa !29
  %t68 = load i64, ptr %l41, !tbaa !24
  %t69 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamType(ptr %v0, ptr %v1, ptr %t67, i64 %t68)
  %t70 = extractvalue { i32, { i64, ptr } } %t69, 1
  %t71 = extractvalue { i32, { i64, ptr } } %t69, 0
  store i32 %t71, ptr %l43
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb20, label %ok.73, !prof !99
ok.73:
  store { i64, ptr } %t70, ptr %l42
  br label %bb19
bb19:
  %t74 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t74, ptr %l30, !tbaa !27
  br label %bb21
bb20:
  %t75 = load i32, ptr %l43, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t85 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t83, 0
  store { i32, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t86 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t87 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t86, 1
  store { i32, { i64, ptr } } %t87, ptr %rv
  br label %ret
bb22:
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb23:
  %t88 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 0
  %t89 = load i32, ptr %t88, !range !{i32 0, i32 7}
  %t91 = trunc i64 3 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb24, label %bb25
bb24:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 3
  %t98 = load i1, ptr %t97, !tbaa !21
  %t102 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epointerParam(ptr %v0, ptr %v1, ptr %t94, i64 %t96, i1 %t98)
  %t103 = extractvalue { i32, { i64, ptr } } %t102, 1
  %t104 = extractvalue { i32, { i64, ptr } } %t102, 0
  store i32 %t104, ptr %l52
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb27, label %ok.106, !prof !99
ok.106:
  store { i64, ptr } %t103, ptr %l51
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t107 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t107, ptr %l47, !tbaa !27
  br label %bb28
bb27:
  %t108 = load i32, ptr %l52, !tbaa !23
  %t109 = lshr i32 %t108, 16
  %t110 = and i32 %t108, 65535
  %t111 = icmp eq i32 %t109, 1
  %t112 = select i1 %t111, i32 1, i32 0
  %t113 = icmp eq i32 %t108, 0
  %t114 = shl i32 %t112, 16
  %t115 = or i32 %t114, %t110
  %t116 = select i1 %t113, i32 0, i32 %t115
  %t118 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t116, 0
  store { i32, { i64, ptr } } %t118, ptr %rv
  br label %ret
bb28:
  %t119 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t120 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t119, 1
  store { i32, { i64, ptr } } %t120, ptr %rv
  br label %ret
bb29:
  %t121 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 0
  %t122 = load i32, ptr %t121, !range !{i32 0, i32 7}
  %t124 = trunc i64 4 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t129 = load i64, ptr %t128, !tbaa !24
  %t132 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epointerParam(ptr %v0, ptr %v1, ptr %t127, i64 %t129, i1 false)
  %t133 = extractvalue { i32, { i64, ptr } } %t132, 1
  %t134 = extractvalue { i32, { i64, ptr } } %t132, 0
  store i32 %t134, ptr %l60
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb33, label %ok.136, !prof !99
ok.136:
  store { i64, ptr } %t133, ptr %l59
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t137 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t137, ptr %l56, !tbaa !27
  br label %bb34
bb33:
  %t138 = load i32, ptr %l60, !tbaa !23
  %t139 = lshr i32 %t138, 16
  %t140 = and i32 %t138, 65535
  %t141 = icmp eq i32 %t139, 1
  %t142 = select i1 %t141, i32 1, i32 0
  %t143 = icmp eq i32 %t138, 0
  %t144 = shl i32 %t142, 16
  %t145 = or i32 %t144, %t140
  %t146 = select i1 %t143, i32 0, i32 %t145
  %t148 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t146, 0
  store { i32, { i64, ptr } } %t148, ptr %rv
  br label %ret
bb34:
  %t149 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t150 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t149, 1
  store { i32, { i64, ptr } } %t150, ptr %rv
  br label %ret
bb35:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l1, !tbaa !24
  %t155 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %v1, ptr %t151, i64 %t152, i1 false)
  %t156 = extractvalue { i32, { i64, ptr } } %t155, 1
  %t157 = extractvalue { i32, { i64, ptr } } %t155, 0
  store i32 %t157, ptr %l66
  %t158 = icmp ne i32 %t157, 0
  br i1 %t158, label %bb37, label %ok.159, !prof !99
ok.159:
  store { i64, ptr } %t156, ptr %l65
  br label %bb36
bb36:
  %t160 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t160, ptr %l62, !tbaa !27
  br label %bb38
bb37:
  %t161 = load i32, ptr %l66, !tbaa !23
  %t162 = lshr i32 %t161, 16
  %t163 = and i32 %t161, 65535
  %t164 = icmp eq i32 %t162, 1
  %t165 = select i1 %t164, i32 1, i32 0
  %t166 = icmp eq i32 %t161, 0
  %t167 = shl i32 %t165, 16
  %t168 = or i32 %t167, %t163
  %t169 = select i1 %t166, i32 0, i32 %t168
  %t171 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t169, 0
  store { i32, { i64, ptr } } %t171, ptr %rv
  br label %ret
bb38:
  %t172 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t173 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t172, 1
  store { i32, { i64, ptr } } %t173, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca %"compiler/bindgen:ctp"
  %l4 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l12 = alloca %"compiler/bindgen:ctp"
  %l16 = alloca i64
  %l25 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t5, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store i64 %t7, ptr %l8
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
bb4:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = call { i64, ptr } @compiler_2fbindgen_2ectokens(ptr %v1, ptr %s0, { i64, ptr } %t9)
  store { i64, ptr } %t11, ptr %l10
  br label %bb5
bb5:
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 16
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t20 = call %"compiler/bindgen:ctp" @compiler_2fbindgen_3actp_2ector(ptr %s0, ptr %s0, { i64, ptr } %t18)
  store %"compiler/bindgen:ctp" %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load %"compiler/bindgen:ctp", ptr %l12
  store %"compiler/bindgen:ctp" %t21, ptr %l3
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  %t27 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etypeName(ptr %v0, ptr %s0, ptr %t22, ptr %l3, i64 %t23)
  store i64 %t27, ptr %l16
  br label %bb7
bb7:
  %t28 = load i64, ptr %l16, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  %t29 = getelementptr %"compiler/bindgen:ctp", ptr %l3, i32 0, i32 1
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = getelementptr %"compiler/bindgen:ctp", ptr %l3, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t37 = icmp slt i64 %t30, %t34
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t44 = extractvalue { i64, ptr } %t40, 1
  %t45 = extractvalue { i64, ptr } %t40, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = getelementptr i8, ptr %t51, i64 %t45
  call void @olang_textcopy(ptr %t52, ptr %t47, i64 %t48)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t50, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t64 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t39, { i64, ptr } %t61)
  store i64 %t64, ptr %l25
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t65 = load i64, ptr %l25, !tbaa !24
  store i64 %t65, ptr %rv
  br label %ret
bb11:
  %t66 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ereadMacros(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca %"std/prelude/text:LineIter"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l38 = alloca %"std/prelude/text:LineIter"
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l44 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i32
  %l62 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i32
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca { i64, ptr }
  %l103 = alloca i1
  %l114 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l120 = alloca i1
  %l121 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca i64
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i32
  %l143 = alloca ptr
  %l147 = alloca i1
  %l149 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca i64
  %l162 = alloca i1
  %l163 = alloca { i64, ptr }
  %l166 = alloca i1
  %l167 = alloca i1
  %l168 = alloca { i64, ptr }
  %l171 = alloca i1
  %l172 = alloca i1
  %l173 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l183 = alloca i64
  %l184 = alloca i64
  %l193 = alloca i1
  %l194 = alloca { i64, ptr }
  %l198 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l200 = alloca { i64, ptr }
  %l201 = alloca i64
  %l204 = alloca i64
  %l205 = alloca i64
  %l211 = alloca i64
  %l214 = alloca i64
  %l215 = alloca i32
  %l218 = alloca { i64, ptr }
  %l220 = alloca i64
  %l221 = alloca i64
  %l222 = alloca i64
  %l227 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l240 = alloca i1
  %l241 = alloca i1
  %l243 = alloca i1
  %l245 = alloca i1
  %l253 = alloca { i64, ptr }
  %l255 = alloca i64
  %l258 = alloca i64
  %l259 = alloca i64
  %l266 = alloca { i64, ptr }
  %l267 = alloca i1
  %l269 = alloca { i64, ptr }
  %l271 = alloca ptr
  %l272 = alloca { i64, ptr }
  %l275 = alloca i1
  %l276 = alloca i1
  %l278 = alloca i1
  %l279 = alloca %"compiler/bindgen:cMacro"
  %l283 = alloca i64
  %l287 = alloca i64
  %l288 = alloca i32
  %l301 = alloca ptr
  %l304 = alloca { i64, ptr }
  %l307 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t1, ptr %l33, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l34, !tbaa !24
  %t4 = load i64, ptr %l34, !tbaa !24
  %t5 = mul i64 %t4, 1
  %t6 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l35, !tbaa !27
  %t9 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = load i64, ptr %l34, !tbaa !24
  %t14 = mul i64 %t13, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t10, ptr %t12, i64 %t14, i1 false)
  %t15 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %l36
  br label %bb1
bb1:
  %t17 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t17, ptr %l6
  %t20 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %a1)
  store %"std/prelude/text:LineIter" %t20, ptr %l38
  br label %bb2
bb2:
  %t21 = load %"std/prelude/text:LineIter", ptr %l38
  store %"std/prelude/text:LineIter" %t21, ptr %l7
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l7)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l42
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb5, label %ok.27, !prof !99
ok.27:
  store { i64, ptr } %t24, ptr %l41
  br label %bb4
bb4:
  %t28 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t28, ptr %l39, !tbaa !27
  br label %bb7
bb5:
  %t29 = load i32, ptr %l42, !tbaa !23
  %t30 = ashr i32 %t29, 16
  %t32 = icmp eq i32 %t30, 1
  store i1 %t32, ptr %l44, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb194
bb7:
  %t33 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t34, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d95, i32 0, i32 1) })
  store i1 %t36, ptr %l46
  br label %bb8
bb8:
  %t37 = load i1, ptr %l46, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t42 = icmp sgt i64 %t40, 2
  store i1 %t42, ptr %l47, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l47, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t45 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t45, ptr %l52, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i8, ptr %t47, i64 2
  %t49 = load i8, ptr %t48, !tbaa !32
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t49)
  store i1 %t51, ptr %l54
  br label %bb14
bb13:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb15
bb14:
  %t52 = load i1, ptr %l54, !tbaa !21
  store i1 %t52, ptr %l51, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l51, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t57 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t54, i8 34)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l59
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb19, label %ok.61, !prof !99
ok.61:
  store i64 %t58, ptr %l58
  br label %bb18
bb17:
  br label %bb56
bb18:
  %t62 = load i64, ptr %l58, !tbaa !24
  store i64 %t62, ptr %l55, !tbaa !24
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l55, !tbaa !24
  br label %bb21
bb21:
  %t63 = load i64, ptr %l55, !tbaa !24
  store i64 %t63, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  %t66 = icmp slt i64 %t64, 0
  br i1 %t66, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb193
bb23:
  br label %bb24
bb24:
  %t68 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t70 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v1, ptr %s3, { i64, ptr } %t68, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) })
  %t71 = extractvalue { i32, i64 } %t70, 1
  %t72 = extractvalue { i32, i64 } %t70, 0
  store i32 %t72, ptr %l65
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb26, label %ok.74, !prof !99
ok.74:
  store i64 %t71, ptr %l64
  br label %bb25
bb25:
  %t75 = load i64, ptr %l64, !tbaa !24
  store i64 %t75, ptr %l62, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l62, !tbaa !24
  br label %bb28
bb28:
  %t76 = load i64, ptr %l62, !tbaa !24
  store i64 %t76, ptr %l10, !tbaa !24
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t81 = icmp sle i64 %t77, %t78
  br i1 %t81, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb193
bb30:
  br label %bb31
bb31:
  %t83 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t83, ptr %l69, !tbaa !27
  %t84 = load i64, ptr %l9, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l71, !tbaa !24
  %t87 = load i64, ptr %l10, !tbaa !24
  store i64 %t87, ptr %l72, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  store i64 %t89, ptr %l73, !tbaa !24
  %t90 = load i64, ptr %l71, !tbaa !24
  %t91 = icmp sge i64 %t90, 0
  br i1 %t91, label %bb32, label %bb33
bb32:
  %t93 = load i64, ptr %l71, !tbaa !24
  %t94 = load i64, ptr %l72, !tbaa !24
  %t95 = icmp sle i64 %t93, %t94
  br i1 %t95, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_beacd36cd332827c_e461632e30adb8c0)
  unreachable
bb34:
  %t97 = load i64, ptr %l72, !tbaa !24
  %t98 = load i64, ptr %l73, !tbaa !24
  %t99 = icmp sle i64 %t97, %t98
  br i1 %t99, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_beacd36cd332827c_e461632e30adb8c0)
  unreachable
bb36:
  %t101 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l71, !tbaa !24
  %t104 = load i64, ptr %l72, !tbaa !24
  %t105 = getelementptr i8, ptr %t102, i64 %t103
  %t106 = sub i64 %t104, %t103
  %t107 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t105, 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l79, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l80, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t113 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t108, { i64, ptr } %t111, { i64, ptr } %t112)
  store { i64, ptr } %t113, ptr %l81
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_beacd36cd332827c_e461632e30adb8c0)
  unreachable
bb38:
  %t114 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l82, !tbaa !24
  %t116 = load i64, ptr %l82, !tbaa !24
  %t117 = mul i64 %t116, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t117)
  %t119 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  store { i64, ptr } %t120, ptr %l83, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l82, !tbaa !24
  %t126 = mul i64 %t125, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t122, ptr %t124, i64 %t126, i1 false)
  %t127 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t129, i64 %t130)
  %t132 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  store { i64, ptr } %t133, ptr %l85, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 0
  %t136 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l87, !tbaa !24
  %t139 = load i64, ptr %l87, !tbaa !24
  %t140 = icmp eq i64 %t135, %t139
  br i1 %t140, label %bb39, label %bb40
bb39:
  %t142 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l87, !tbaa !24
  %t147 = mul i64 %t146, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t143, ptr %t145, i64 %t147, i1 false)
  br label %bb41
bb40:
  %t148 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t148, ptr %l5, !tbaa !27
  br label %bb41
bb41:
  %t149 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t151 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s3, { i64, ptr } %t149, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t151, ptr %l90
  br label %bb42
bb42:
  %t152 = load i1, ptr %l90, !tbaa !21
  %t153 = xor i1 %t152, true
  br i1 %t153, label %bb43, label %bb44
bb43:
  %t155 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t159 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v2, { i64, ptr } %t155, { i64, ptr } %t156)
  store i1 %t159, ptr %l95
  br label %bb45
bb44:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb46
bb45:
  %t160 = load i1, ptr %l95, !tbaa !21
  %t161 = xor i1 %t160, true
  store i1 %t161, ptr %l92, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l92, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t164, ptr %l98, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 0
  store i64 %t166, ptr %l99, !tbaa !24
  %t167 = load i64, ptr %l99, !tbaa !24
  %t168 = mul i64 %t167, 1
  %t169 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t168)
  %t170 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l100, !tbaa !27
  %t172 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = load i64, ptr %l99, !tbaa !24
  %t177 = mul i64 %t176, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t173, ptr %t175, i64 %t177, i1 false)
  %t178 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t182 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s0, ptr %s3, ptr %l6, { i64, ptr } %t178)
  store i1 %t182, ptr %l103
  br label %bb49
bb48:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb50
bb49:
  %t183 = load i1, ptr %l103, !tbaa !21
  %t184 = xor i1 %t183, true
  store i1 %t184, ptr %l97, !tbaa !21
  br label %bb50
bb50:
  %t186 = load i1, ptr %l97, !tbaa !21
  br i1 %t186, label %bb51, label %bb52
bb51:
  %t187 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 1
  %t190 = extractvalue { i64, ptr } %t187, 0
  %t191 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t189, i64 %t190)
  %t192 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = extractvalue { i64, ptr } %t193, 1
  %t197 = mul i64 %t195, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t197)
  call void @llvm.memcpy.p0.p0.i64(ptr %t198, ptr %t196, i64 %t197, i1 false)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t200, i1 true)
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t204 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 1
  %t207 = extractvalue { i64, ptr } %t204, 0
  %t208 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t206, i64 %t207)
  %t209 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = extractvalue { i64, ptr } %t210, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %a4, { i64, ptr } %t217)
  br label %bb54
bb54:
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb193
bb56:
  %t220 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s2, { i64, ptr } %t220, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t222, ptr %l114
  br label %bb57
bb57:
  %t223 = load i1, ptr %l114, !tbaa !21
  br i1 %t223, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb61
bb59:
  %t224 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t228 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v2, { i64, ptr } %t224, { i64, ptr } %t225)
  store i1 %t228, ptr %l118
  br label %bb60
bb60:
  %t229 = load i1, ptr %l118, !tbaa !21
  store i1 %t229, ptr %l115, !tbaa !21
  br label %bb61
bb61:
  %t230 = load i1, ptr %l115, !tbaa !21
  br i1 %t230, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s2)
  br label %bb193
bb63:
  br label %bb64
bb64:
  %t231 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t233 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t231, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t233, ptr %l120
  br label %bb65
bb65:
  %t234 = load i1, ptr %l120, !tbaa !21
  br i1 %t234, label %bb66, label %bb67
bb66:
  %t235 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t235, ptr %l121, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t236, 0
  store i64 %t239, ptr %l124, !tbaa !24
  %t240 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t240, 0
  store i64 %t241, ptr %l125, !tbaa !24
  %t242 = icmp sge i64 7, 0
  br i1 %t242, label %bb68, label %bb69
bb67:
  br label %bb83
bb68:
  %t244 = load i64, ptr %l124, !tbaa !24
  %t245 = icmp sle i64 7, %t244
  br i1 %t245, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_88bbbdba37ecb069_7556c3a5c9bf841d)
  unreachable
bb70:
  %t247 = load i64, ptr %l124, !tbaa !24
  %t248 = load i64, ptr %l125, !tbaa !24
  %t249 = icmp sle i64 %t247, %t248
  br i1 %t249, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_88bbbdba37ecb069_7556c3a5c9bf841d)
  unreachable
bb72:
  %t251 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = load i64, ptr %l124, !tbaa !24
  %t254 = getelementptr i8, ptr %t252, i64 7
  %t255 = sub i64 %t253, 7
  %t256 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t254, 1
  %t259 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, ptr %v1, { i64, ptr } %t257)
  store { i64, ptr } %t259, ptr %l130
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_88bbbdba37ecb069_7556c3a5c9bf841d)
  unreachable
bb74:
  %t260 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/bindgen:gen", ptr %t261, i32 0, i32 13
  %t267 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t263, { i64, ptr } %t260)
  %t268 = extractvalue { i32, i64 } %t267, 1
  %t269 = extractvalue { i32, i64 } %t267, 0
  store i32 %t269, ptr %l136
  %t270 = icmp ne i32 %t269, 0
  br i1 %t270, label %bb76, label %ok.271, !prof !99
ok.271:
  store i64 %t268, ptr %l135
  br label %bb75
bb75:
  %t272 = load i64, ptr %l135, !tbaa !24
  store i64 %t272, ptr %l131, !tbaa !24
  br label %bb78
bb76:
  br label %bb77
bb77:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l131, !tbaa !24
  br label %bb78
bb78:
  %t273 = load i64, ptr %l131, !tbaa !24
  store i64 %t273, ptr %l13, !tbaa !24
  %t274 = load i64, ptr %l13, !tbaa !24
  %t276 = icmp sge i64 %t274, 0
  br i1 %t276, label %bb79, label %bb80
bb79:
  %t278 = load i64, ptr %l13, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d102, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/bindgen:gen", ptr %t280, i32 0, i32 12
  %t286 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eRefMu_H9d4ce036ca8f6276b6798968f53e8eb9(ptr %v0, ptr %v0, ptr %t282, i64 %t278)
  store ptr %t286, ptr %l143
  br label %bb81
bb80:
  br label %bb82
bb81:
  %t287 = load ptr, ptr %l143, !tbaa !29
  %t289 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t292 = getelementptr %"compiler/bindgen:cMacro", ptr %t287, i32 0, i32 0
  store { i64, ptr } %t289, ptr %t292, !tbaa !27
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s2)
  br label %bb193
bb83:
  %t293 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t295 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t293, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store i1 %t295, ptr %l147
  br label %bb84
bb84:
  %t296 = load i1, ptr %l147, !tbaa !21
  %t297 = xor i1 %t296, true
  br i1 %t297, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s2)
  br label %bb193
bb86:
  br label %bb87
bb87:
  %t299 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t299, ptr %l149, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t300, 0
  store i64 %t303, ptr %l152, !tbaa !24
  %t304 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 0
  store i64 %t305, ptr %l153, !tbaa !24
  %t306 = icmp sge i64 8, 0
  br i1 %t306, label %bb88, label %bb89
bb88:
  %t308 = load i64, ptr %l152, !tbaa !24
  %t309 = icmp sle i64 8, %t308
  br i1 %t309, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_a6c60cdff876254a_2c918d2d7b99843e)
  unreachable
bb90:
  %t311 = load i64, ptr %l152, !tbaa !24
  %t312 = load i64, ptr %l153, !tbaa !24
  %t313 = icmp sle i64 %t311, %t312
  br i1 %t313, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @olang_loc_a6c60cdff876254a_2c918d2d7b99843e)
  unreachable
bb92:
  %t315 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = load i64, ptr %l152, !tbaa !24
  %t318 = getelementptr i8, ptr %t316, i64 8
  %t319 = sub i64 %t317, 8
  %t320 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t318, 1
  store { i64, ptr } %t321, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_a6c60cdff876254a_2c918d2d7b99843e)
  unreachable
bb94:
  %t323 = load i64, ptr %l18, !tbaa !24
  %t324 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t329 = icmp slt i64 %t323, %t326
  br i1 %t329, label %bb95, label %bb96
bb95:
  %t331 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t331, ptr %l163, !tbaa !27
  %t332 = load i64, ptr %l18, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i8, ptr %t335, i64 %t332
  %t337 = load i8, ptr %t336, !tbaa !32
  %t339 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t337)
  store i1 %t339, ptr %l166
  br label %bb97
bb96:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb105
bb97:
  %t340 = load i1, ptr %l166, !tbaa !21
  br i1 %t340, label %bb98, label %bb99
bb98:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb101
bb99:
  %t341 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t341, ptr %l168, !tbaa !27
  %t342 = load i64, ptr %l18, !tbaa !24
  %t344 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = getelementptr i8, ptr %t345, i64 %t342
  %t347 = load i8, ptr %t346, !tbaa !32
  %t349 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t347)
  store i1 %t349, ptr %l171
  br label %bb100
bb100:
  %t350 = load i1, ptr %l171, !tbaa !21
  store i1 %t350, ptr %l167, !tbaa !21
  br label %bb101
bb101:
  %t351 = load i1, ptr %l167, !tbaa !21
  br i1 %t351, label %bb102, label %bb103
bb102:
  store i1 true, ptr %l172, !tbaa !21
  br label %bb104
bb103:
  %t352 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t352, ptr %l173, !tbaa !27
  %t353 = load i64, ptr %l18, !tbaa !24
  %t355 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !27
  %t357 = getelementptr i8, ptr %t356, i64 %t353
  %t358 = load i8, ptr %t357, !tbaa !32
  %t360 = icmp eq i8 %t358, 95
  store i1 %t360, ptr %l172, !tbaa !21
  br label %bb104
bb104:
  %t362 = load i1, ptr %l172, !tbaa !21
  store i1 %t362, ptr %l162, !tbaa !21
  br label %bb105
bb105:
  %t363 = load i1, ptr %l162, !tbaa !21
  %t364 = xor i1 %t363, true
  br i1 %t364, label %bb106, label %bb107
bb106:
  br label %bb110
bb107:
  br label %bb108
bb108:
  %t366 = load i64, ptr %l18, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l18, !tbaa !24
  br label %bb109
bb109:
  br label %bb94
bb110:
  %t370 = load i64, ptr %l18, !tbaa !24
  %t372 = icmp eq i64 %t370, 0
  br i1 %t372, label %bb111, label %bb112
bb111:
  call void @__olang_scope_close(ptr %s2)
  br label %bb193
bb112:
  br label %bb113
bb113:
  %t374 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t374, ptr %l182, !tbaa !27
  %t375 = load i64, ptr %l18, !tbaa !24
  store i64 %t375, ptr %l183, !tbaa !24
  %t376 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 0
  store i64 %t377, ptr %l184, !tbaa !24
  %t378 = icmp sge i64 0, 0
  br i1 %t378, label %bb114, label %bb115
bb114:
  %t380 = load i64, ptr %l183, !tbaa !24
  %t381 = icmp sle i64 0, %t380
  br i1 %t381, label %bb116, label %bb117
bb115:
  call void @__olang_check_failed(ptr @olang_loc_5755e6dd02fca827_178a482bfa1e95bb)
  unreachable
bb116:
  %t383 = load i64, ptr %l183, !tbaa !24
  %t384 = load i64, ptr %l184, !tbaa !24
  %t385 = icmp sle i64 %t383, %t384
  br i1 %t385, label %bb118, label %bb119
bb117:
  call void @__olang_check_failed(ptr @olang_loc_5755e6dd02fca827_178a482bfa1e95bb)
  unreachable
bb118:
  %t387 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = load i64, ptr %l183, !tbaa !24
  %t390 = getelementptr i8, ptr %t388, i64 0
  %t391 = sub i64 %t389, 0
  %t392 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t390, 1
  store { i64, ptr } %t393, ptr %l19, !tbaa !27
  %t395 = load i64, ptr %l18, !tbaa !24
  %t396 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t396, 0
  %t401 = icmp slt i64 %t395, %t398
  br i1 %t401, label %bb120, label %bb121
bb119:
  call void @__olang_check_failed(ptr @olang_loc_5755e6dd02fca827_178a482bfa1e95bb)
  unreachable
bb120:
  %t403 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t403, ptr %l194, !tbaa !27
  %t404 = load i64, ptr %l18, !tbaa !24
  %t406 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !27
  %t408 = getelementptr i8, ptr %t407, i64 %t404
  %t409 = load i8, ptr %t408, !tbaa !32
  %t411 = icmp eq i8 %t409, 40
  store i1 %t411, ptr %l193, !tbaa !21
  br label %bb122
bb121:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb122
bb122:
  %t413 = load i1, ptr %l193, !tbaa !21
  store i1 %t413, ptr %l20, !tbaa !21
  %t414 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t414, ptr %l198
  br label %bb123
bb123:
  %t415 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l198
  %t416 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t415, ptr %t416
  store ptr %t416, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t418 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t418, ptr %l200, !tbaa !27
  %t419 = load i64, ptr %l18, !tbaa !24
  store i64 %t419, ptr %l201, !tbaa !24
  %t420 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t423 = extractvalue { i64, ptr } %t420, 0
  store i64 %t423, ptr %l204, !tbaa !24
  %t424 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 0
  store i64 %t425, ptr %l205, !tbaa !24
  %t426 = load i64, ptr %l201, !tbaa !24
  %t427 = icmp sge i64 %t426, 0
  br i1 %t427, label %bb124, label %bb125
bb124:
  %t429 = load i64, ptr %l201, !tbaa !24
  %t430 = load i64, ptr %l204, !tbaa !24
  %t431 = icmp sle i64 %t429, %t430
  br i1 %t431, label %bb126, label %bb127
bb125:
  call void @__olang_check_failed(ptr @olang_loc_4153d023000ff8e8_6b17d300a1e811b4)
  unreachable
bb126:
  %t433 = load i64, ptr %l204, !tbaa !24
  %t434 = load i64, ptr %l205, !tbaa !24
  %t435 = icmp sle i64 %t433, %t434
  br i1 %t435, label %bb128, label %bb129
bb127:
  call void @__olang_check_failed(ptr @olang_loc_4153d023000ff8e8_6b17d300a1e811b4)
  unreachable
bb128:
  %t437 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = load i64, ptr %l201, !tbaa !24
  %t440 = load i64, ptr %l204, !tbaa !24
  %t441 = getelementptr i8, ptr %t438, i64 %t439
  %t442 = sub i64 %t440, %t439
  %t443 = insertvalue { i64, ptr } undef, i64 %t442, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t441, 1
  store { i64, ptr } %t444, ptr %l23, !tbaa !27
  %t446 = load i1, ptr %l20, !tbaa !21
  br i1 %t446, label %bb130, label %bb131
bb129:
  call void @__olang_check_failed(ptr @olang_loc_4153d023000ff8e8_6b17d300a1e811b4)
  unreachable
bb130:
  %t448 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t451 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t448, i8 41)
  %t452 = extractvalue { i32, i64 } %t451, 1
  %t453 = extractvalue { i32, i64 } %t451, 0
  store i32 %t453, ptr %l215
  %t454 = icmp ne i32 %t453, 0
  br i1 %t454, label %bb133, label %ok.455, !prof !99
ok.455:
  store i64 %t452, ptr %l214
  br label %bb132
bb131:
  br label %bb172
bb132:
  %t456 = load i64, ptr %l214, !tbaa !24
  store i64 %t456, ptr %l211, !tbaa !24
  br label %bb135
bb133:
  br label %bb134
bb134:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l211, !tbaa !24
  br label %bb135
bb135:
  %t457 = load i64, ptr %l211, !tbaa !24
  store i64 %t457, ptr %l24, !tbaa !24
  %t458 = load i64, ptr %l24, !tbaa !24
  %t460 = icmp slt i64 %t458, 0
  br i1 %t460, label %bb136, label %bb137
bb136:
  call void @__olang_scope_close(ptr %s2)
  br label %bb193
bb137:
  br label %bb138
bb138:
  store %olang.scope zeroinitializer, ptr %s18
  %t462 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t462, ptr %l218, !tbaa !27
  %t463 = load i64, ptr %l18, !tbaa !24
  %t465 = add i64 %t463, 1
  store i64 %t465, ptr %l220, !tbaa !24
  %t466 = load i64, ptr %l24, !tbaa !24
  store i64 %t466, ptr %l221, !tbaa !24
  %t467 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t468 = extractvalue { i64, ptr } %t467, 0
  store i64 %t468, ptr %l222, !tbaa !24
  %t469 = load i64, ptr %l220, !tbaa !24
  %t470 = icmp sge i64 %t469, 0
  br i1 %t470, label %bb139, label %bb140
bb139:
  %t472 = load i64, ptr %l220, !tbaa !24
  %t473 = load i64, ptr %l221, !tbaa !24
  %t474 = icmp sle i64 %t472, %t473
  br i1 %t474, label %bb141, label %bb142
bb140:
  call void @__olang_check_failed(ptr @olang_loc_ec020a578bdf64c5_799d4029e88195a1)
  unreachable
bb141:
  %t476 = load i64, ptr %l221, !tbaa !24
  %t477 = load i64, ptr %l222, !tbaa !24
  %t478 = icmp sle i64 %t476, %t477
  br i1 %t478, label %bb143, label %bb144
bb142:
  call void @__olang_check_failed(ptr @olang_loc_ec020a578bdf64c5_799d4029e88195a1)
  unreachable
bb143:
  %t480 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = load i64, ptr %l220, !tbaa !24
  %t483 = load i64, ptr %l221, !tbaa !24
  %t484 = getelementptr i8, ptr %t481, i64 %t482
  %t485 = sub i64 %t483, %t482
  %t486 = insertvalue { i64, ptr } undef, i64 %t485, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t484, 1
  %t489 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s18, ptr %s18, { i64, ptr } %t487, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) })
  store { i64, ptr } %t489, ptr %l227
  br label %bb145
bb144:
  call void @__olang_check_failed(ptr @olang_loc_ec020a578bdf64c5_799d4029e88195a1)
  unreachable
bb145:
  %t490 = load { i64, ptr }, ptr %l227, !tbaa !27
  store { i64, ptr } %t490, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 0
  store i64 %t493, ptr %l27, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s19
  %t495 = load i64, ptr %l26, !tbaa !24
  %t496 = load i64, ptr %l27, !tbaa !24
  %t499 = icmp slt i64 %t495, %t496
  %t501 = xor i1 %t499, true
  br i1 %t501, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s19)
  br label %bb165
bb148:
  br label %bb149
bb149:
  %t503 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t503, ptr %l234, !tbaa !27
  %t504 = load i64, ptr %l26, !tbaa !24
  %t506 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr { i64, ptr }, ptr %t507, i64 %t504
  %t509 = load { i64, ptr }, ptr %t508, !tbaa !37
  %t513 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s18, ptr %s18, { i64, ptr } %t509)
  store { i64, ptr } %t513, ptr %l238
  br label %bb150
bb150:
  %t514 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t514, ptr %l29, !tbaa !27
  %t515 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t517 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s18, ptr %s19, { i64, ptr } %t515, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d105, i32 0, i32 1) })
  store i1 %t517, ptr %l240
  br label %bb151
bb151:
  %t518 = load i1, ptr %l240, !tbaa !21
  br i1 %t518, label %bb152, label %bb153
bb152:
  store i1 true, ptr %l241, !tbaa !21
  br label %bb155
bb153:
  %t519 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t521 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s18, ptr %s19, { i64, ptr } %t519, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d106, i32 0, i32 1) })
  store i1 %t521, ptr %l243
  br label %bb154
bb154:
  %t522 = load i1, ptr %l243, !tbaa !21
  store i1 %t522, ptr %l241, !tbaa !21
  br label %bb155
bb155:
  %t523 = load i1, ptr %l241, !tbaa !21
  br i1 %t523, label %bb156, label %bb157
bb156:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb163
bb157:
  store %olang.scope zeroinitializer, ptr %s21
  %t524 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t526 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s18, ptr %s21, { i64, ptr } %t524, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d107, i32 0, i32 1) })
  store i1 %t526, ptr %l245
  br label %bb158
bb158:
  %t527 = load i1, ptr %l245, !tbaa !21
  %t528 = xor i1 %t527, true
  br i1 %t528, label %bb159, label %bb160
bb159:
  %t530 = load ptr, ptr %l21, !tbaa !29
  %t531 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t531, 1
  %t534 = extractvalue { i64, ptr } %t531, 0
  %t535 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t534)
  call void @olang_textcopy(ptr %t535, ptr %t533, i64 %t534)
  %t536 = insertvalue { i64, ptr } undef, i64 %t534, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t535, 1
  %t539 = extractvalue { i64, ptr } %t537, 0
  %t540 = extractvalue { i64, ptr } %t537, 1
  %t541 = mul i64 %t539, 1
  %t542 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t541)
  call void @llvm.memcpy.p0.p0.i64(ptr %t542, ptr %t540, i64 %t541, i1 false)
  %t543 = insertvalue { i64, ptr } undef, i64 %t539, 0
  %t544 = insertvalue { i64, ptr } %t543, ptr %t542, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t530, { i64, ptr } %t544)
  br label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s21)
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s19)
  br label %bb164
bb164:
  %t547 = load i64, ptr %l26, !tbaa !24
  %t549 = add i64 %t547, 1
  store i64 %t549, ptr %l26, !tbaa !24
  br label %bb146
bb165:
  call void @__olang_scope_close(ptr %s18)
  %t551 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t551, ptr %l253, !tbaa !27
  %t552 = load i64, ptr %l24, !tbaa !24
  %t554 = add i64 %t552, 1
  store i64 %t554, ptr %l255, !tbaa !24
  %t555 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t558 = extractvalue { i64, ptr } %t555, 0
  store i64 %t558, ptr %l258, !tbaa !24
  %t559 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t560 = extractvalue { i64, ptr } %t559, 0
  store i64 %t560, ptr %l259, !tbaa !24
  %t561 = load i64, ptr %l255, !tbaa !24
  %t562 = icmp sge i64 %t561, 0
  br i1 %t562, label %bb166, label %bb167
bb166:
  %t564 = load i64, ptr %l255, !tbaa !24
  %t565 = load i64, ptr %l258, !tbaa !24
  %t566 = icmp sle i64 %t564, %t565
  br i1 %t566, label %bb168, label %bb169
bb167:
  call void @__olang_check_failed(ptr @olang_loc_642a74ef72af54a6_43680c0161c24f22)
  unreachable
bb168:
  %t568 = load i64, ptr %l258, !tbaa !24
  %t569 = load i64, ptr %l259, !tbaa !24
  %t570 = icmp sle i64 %t568, %t569
  br i1 %t570, label %bb170, label %bb171
bb169:
  call void @__olang_check_failed(ptr @olang_loc_642a74ef72af54a6_43680c0161c24f22)
  unreachable
bb170:
  %t572 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = load i64, ptr %l255, !tbaa !24
  %t575 = load i64, ptr %l258, !tbaa !24
  %t576 = getelementptr i8, ptr %t573, i64 %t574
  %t577 = sub i64 %t575, %t574
  %t578 = insertvalue { i64, ptr } undef, i64 %t577, 0
  %t579 = insertvalue { i64, ptr } %t578, ptr %t576, 1
  store { i64, ptr } %t579, ptr %l23, !tbaa !27
  br label %bb172
bb171:
  call void @__olang_check_failed(ptr @olang_loc_642a74ef72af54a6_43680c0161c24f22)
  unreachable
bb172:
  %t581 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t583 = extractvalue { i64, ptr } %t581, 1
  %t584 = extractvalue { i64, ptr } %t581, 0
  %t585 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t584)
  call void @olang_textcopy(ptr %t585, ptr %t583, i64 %t584)
  %t586 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t585, 1
  %t589 = extractvalue { i64, ptr } %t587, 0
  %t590 = extractvalue { i64, ptr } %t587, 1
  %t591 = mul i64 %t589, 1
  %t592 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t591)
  call void @llvm.memcpy.p0.p0.i64(ptr %t592, ptr %t590, i64 %t591, i1 false)
  %t593 = insertvalue { i64, ptr } undef, i64 %t589, 0
  %t594 = insertvalue { i64, ptr } %t593, ptr %t592, 1
  store { i64, ptr } %t594, ptr %l266, !tbaa !27
  %t595 = load i1, ptr %l20, !tbaa !21
  store i1 %t595, ptr %l267, !tbaa !21
  %t596 = load ptr, ptr %l21, !tbaa !29
  %t598 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %t596)
  store { i64, ptr } %t598, ptr %l269
  br label %bb173
bb173:
  %t599 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t601 = call ptr @compiler_2fbindgen_2ecLex(ptr %v1, ptr %v1, { i64, ptr } %t599)
  store ptr %t601, ptr %l271
  br label %bb174
bb174:
  %t602 = load ptr, ptr %l271, !tbaa !29
  %t603 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t602)
  store { i64, ptr } %t603, ptr %l272
  br label %bb175
bb175:
  %t604 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t605 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t608 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v3, { i64, ptr } %t604, { i64, ptr } %t605)
  store i1 %t608, ptr %l275
  br label %bb176
bb176:
  %t609 = load i1, ptr %l275, !tbaa !21
  br i1 %t609, label %bb177, label %bb178
bb177:
  store i1 true, ptr %l276, !tbaa !21
  br label %bb180
bb178:
  %t610 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t612 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s2, { i64, ptr } %t610, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d108, i32 0, i32 1) })
  store i1 %t612, ptr %l278
  br label %bb179
bb179:
  %t613 = load i1, ptr %l278, !tbaa !21
  store i1 %t613, ptr %l276, !tbaa !21
  br label %bb180
bb180:
  %t614 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t615 = load i1, ptr %l267, !tbaa !21
  %t616 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t617 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t618 = load i1, ptr %l276, !tbaa !21
  %t619 = call %"compiler/bindgen:cMacro" @compiler_2fbindgen_3acMacro_2ector(ptr %v0, ptr %v0, ptr %v1, ptr %v0, { i64, ptr } %t614, i1 %t615, { i64, ptr } %t616, { i64, ptr } %t617, i1 %t618)
  store %"compiler/bindgen:cMacro" %t619, ptr %l279
  br label %bb181
bb181:
  %t620 = load %"compiler/bindgen:cMacro", ptr %l279
  %t621 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/bindgen:cMacro" %t620, ptr %t621
  store ptr %t621, ptr %l30, !tbaa !29
  %t623 = load ptr, ptr %l30, !tbaa !29
  %t624 = load i1, ptr %l22, !tbaa !21
  %t627 = getelementptr %"compiler/bindgen:cMacro", ptr %t623, i32 0, i32 5
  store i1 %t624, ptr %t627, !tbaa !21
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/bindgen:gen", ptr %t628, i32 0, i32 13
  %t631 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t634 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t630, { i64, ptr } %t631)
  %t635 = extractvalue { i32, i64 } %t634, 1
  %t636 = extractvalue { i32, i64 } %t634, 0
  store i32 %t636, ptr %l288
  %t637 = icmp ne i32 %t636, 0
  br i1 %t637, label %bb183, label %ok.638, !prof !99
ok.638:
  store i64 %t635, ptr %l287
  br label %bb182
bb182:
  %t639 = load i64, ptr %l287, !tbaa !24
  store i64 %t639, ptr %l283, !tbaa !24
  br label %bb185
bb183:
  br label %bb184
bb184:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l283, !tbaa !24
  br label %bb185
bb185:
  %t640 = load i64, ptr %l283, !tbaa !24
  store i64 %t640, ptr %l31, !tbaa !24
  %t641 = load i64, ptr %l31, !tbaa !24
  %t643 = icmp sge i64 %t641, 0
  br i1 %t643, label %bb186, label %bb187
bb186:
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t647 = getelementptr %"compiler/bindgen:gen", ptr %t645, i32 0, i32 12
  %t648 = load i64, ptr %l31, !tbaa !24
  %t649 = load ptr, ptr %l30, !tbaa !29
  %t651 = load %"compiler/bindgen:cMacro", ptr %t649
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eSetAt_H7935c3ba4e105e8cc692de439d360efe(ptr %v0, ptr %v0, ptr %t647, i64 %t648, %"compiler/bindgen:cMacro" %t651)
  br label %bb188
bb187:
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t657 = getelementptr %"compiler/bindgen:gen", ptr %t655, i32 0, i32 12
  %t658 = load ptr, ptr %l30, !tbaa !29
  %t660 = load %"compiler/bindgen:cMacro", ptr %t658
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2ePush_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v0, ptr %t657, %"compiler/bindgen:cMacro" %t660)
  br label %bb189
bb188:
  br label %bb192
bb189:
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t665 = getelementptr %"compiler/bindgen:gen", ptr %t663, i32 0, i32 13
  store ptr %t665, ptr %l301, !tbaa !29
  %t666 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t668 = extractvalue { i64, ptr } %t666, 1
  %t669 = extractvalue { i64, ptr } %t666, 0
  %t670 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t669)
  call void @olang_textcopy(ptr %t670, ptr %t668, i64 %t669)
  %t671 = insertvalue { i64, ptr } undef, i64 %t669, 0
  %t672 = insertvalue { i64, ptr } %t671, ptr %t670, 1
  %t674 = extractvalue { i64, ptr } %t672, 0
  %t675 = extractvalue { i64, ptr } %t672, 1
  %t676 = mul i64 %t674, 1
  %t677 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t676)
  call void @llvm.memcpy.p0.p0.i64(ptr %t677, ptr %t675, i64 %t676, i1 false)
  %t678 = insertvalue { i64, ptr } undef, i64 %t674, 0
  %t679 = insertvalue { i64, ptr } %t678, ptr %t677, 1
  store { i64, ptr } %t679, ptr %l304, !tbaa !27
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t682 = getelementptr %"compiler/bindgen:gen", ptr %t680, i32 0, i32 12
  %t684 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %t682)
  store i64 %t684, ptr %l307
  br label %bb190
bb190:
  %t685 = load i64, ptr %l307, !tbaa !24
  %t686 = sub i64 %t685, 1
  %t687 = load ptr, ptr %l301, !tbaa !29
  %t688 = load { i64, ptr }, ptr %l304, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t687, { i64, ptr } %t688, i64 %t686)
  br label %bb191
bb191:
  br label %bb192
bb192:
  call void @__olang_scope_close(ptr %s2)
  br label %bb193
bb193:
  br label %bb3
bb194:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i64
  %l13 = alloca ptr
  %l18 = alloca i1
  %l22 = alloca %"compiler/bindgen:record"
  %l24 = alloca %"compiler/bindgen:record"
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t31 = alloca %"compiler/bindgen:record", align 8
  %t34 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  store i1 true, ptr %l4, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:gen", ptr %t9, i32 0, i32 5
  %t15 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t11, i64 %t7)
  store ptr %t15, ptr %l13
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t18 = load i1, ptr %l4, !tbaa !21
  %t21 = getelementptr %"compiler/bindgen:record", ptr %t16, i32 0, i32 8
  store i1 %t18, ptr %t21, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/bindgen:gen", ptr %t22, i32 0, i32 23
  %t25 = load i1, ptr %t24, !tbaa !21
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/bindgen:gen", ptr %t27, i32 0, i32 5
  %t30 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t31, ptr %v0, ptr %v0, ptr %t29, i64 %t30)
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t31, i64 176, i1 false)
  br label %bb5
bb4:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb8
bb5:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t34, ptr %v0, ptr %l22)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t34, i64 176, i1 false)
  br label %bb6
bb6:
  %t36 = getelementptr %"compiler/bindgen:record", ptr %l24, i32 0, i32 7
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t37, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d109, i32 0, i32 1) })
  store i1 %t39, ptr %l26
  br label %bb7
bb7:
  %t40 = load i1, ptr %l26, !tbaa !21
  store i1 %t40, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l27, !tbaa !29
  %t43 = load i64, ptr %l2, !tbaa !24
  store i64 %t43, ptr %l28, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/bindgen:gen", ptr %t44, i32 0, i32 22
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t50 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v0, ptr %t46, { i64, ptr } %t47)
  %t51 = extractvalue { i32, { i64, ptr } } %t50, 1
  %t52 = extractvalue { i32, { i64, ptr } } %t50, 0
  store i32 %t52, ptr %l34
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb12, label %ok.54, !prof !99
ok.54:
  store { i64, ptr } %t51, ptr %l33
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t55 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d110, i32 0, i32 1) }, ptr %l29, !tbaa !27
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l27, !tbaa !29
  %t57 = load i64, ptr %l28, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l29, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecord(ptr %v0, ptr %v0, ptr %t56, i64 %t57, { i64, ptr } %t58)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t59 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l9 = alloca i1
  %l12 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca %"compiler/bindgen:record"
  %l36 = alloca i64
  %l39 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l50 = alloca i64
  %l55 = alloca ptr
  %l63 = alloca ptr
  %l67 = alloca i1
  %l69 = alloca i1
  %l73 = alloca %"compiler/bindgen:record"
  %l75 = alloca %"compiler/bindgen:record"
  %l81 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l99 = alloca i1
  %l104 = alloca ptr
  %l108 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l116 = alloca i1
  %l119 = alloca i1
  %l124 = alloca ptr
  %l130 = alloca ptr
  %l132 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l141 = alloca ptr
  %l143 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t21 = alloca %"compiler/bindgen:record", align 8
  %t26 = alloca %"compiler/bindgen:record", align 8
  %t117 = alloca %"compiler/bindgen:record", align 8
  %t120 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %v1, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d111, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d112, i32 0, i32 1) })
  store i1 %t12, ptr %l28
  br label %bb2
bb2:
  %t13 = load i1, ptr %l28, !tbaa !21
  store i1 %t13, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d113, i32 0, i32 1) })
  store i1 %t16, ptr %l30
  br label %bb3
bb3:
  %t17 = load i1, ptr %l30, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/bindgen:gen", ptr %t18, i32 0, i32 5
  store ptr %t20, ptr %l32, !tbaa !29
  call void @compiler_2fbindgen_3arecord_2ector(ptr %t21, ptr %v0, ptr %v0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d114, i32 0, i32 1) })
  call void @llvm.memmove.p0.p0.i64(ptr %l33, ptr %t21, i64 176, i1 false)
  br label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l44, !tbaa !29
  %t23 = load i1, ptr %l4, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb6:
  %t25 = load ptr, ptr %l32, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t26, ptr %l33, i64 176, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ePush_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t25, ptr %t26)
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/bindgen:gen", ptr %t27, i32 0, i32 5
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l36
  br label %bb8
bb8:
  %t32 = load i64, ptr %l36, !tbaa !24
  %t33 = sub i64 %t32, 1
  store i64 %t33, ptr %l5, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/bindgen:gen", ptr %t35, i32 0, i32 7
  store ptr %t37, ptr %l39, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %v1, ptr %v0, ptr %v0, ptr %t38, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d115, i32 0, i32 1) })
  store { i64, ptr } %t40, ptr %l41
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t49, { i64, ptr } %t47, i64 %t48)
  br label %bb10
bb10:
  br label %bb15
bb11:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) }, ptr %l46, !tbaa !27
  br label %bb13
bb12:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d117, i32 0, i32 1) }, ptr %l46, !tbaa !27
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = extractvalue { i64, ptr } %t52, 1
  %t58 = extractvalue { i64, ptr } %t52, 0
  %t59 = add i64 %t55, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t54, i64 %t55)
  %t61 = getelementptr i8, ptr %t60, i64 %t55
  call void @olang_textcopy(ptr %t61, ptr %t57, i64 %t58)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } %t63, 1
  %t67 = mul i64 %t65, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t67)
  call void @llvm.memcpy.p0.p0.i64(ptr %t68, ptr %t66, i64 %t67, i1 false)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t71 = load ptr, ptr %l44, !tbaa !29
  %t73 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %s2, ptr %t71, { i64, ptr } %t70)
  store i64 %t73, ptr %l50
  br label %bb14
bb14:
  %t74 = load i64, ptr %l50, !tbaa !24
  store i64 %t74, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/bindgen:gen", ptr %t77, i32 0, i32 5
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t79, i64 %t75)
  store ptr %t83, ptr %l55
  br label %bb16
bb16:
  %t84 = load ptr, ptr %l55, !tbaa !29
  %t86 = load i1, ptr %l4, !tbaa !21
  %t89 = getelementptr %"compiler/bindgen:record", ptr %t84, i32 0, i32 1
  store i1 %t86, ptr %t89, !tbaa !21
  %t90 = load i1, ptr %l3, !tbaa !21
  br i1 %t90, label %bb17, label %bb18
bb17:
  %t92 = load i64, ptr %l5, !tbaa !24
  store i1 true, ptr %l9, !tbaa !21
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/bindgen:gen", ptr %t94, i32 0, i32 5
  %t100 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t96, i64 %t92)
  store ptr %t100, ptr %l63
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t101 = load ptr, ptr %l63, !tbaa !29
  %t103 = load i1, ptr %l9, !tbaa !21
  %t106 = getelementptr %"compiler/bindgen:record", ptr %t101, i32 0, i32 6
  store i1 %t103, ptr %t106, !tbaa !21
  br label %bb20
bb20:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = call i1 @compiler_2fbindgen_2eflag(ptr %v1, ptr %s0, ptr %t107, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d118, i32 0, i32 1) })
  store i1 %t109, ptr %l67
  br label %bb21
bb21:
  %t110 = load i1, ptr %l67, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb26
bb23:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/bindgen:gen", ptr %t113, i32 0, i32 5
  %t116 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t117, ptr %v0, ptr %s0, ptr %t115, i64 %t116)
  call void @llvm.memmove.p0.p0.i64(ptr %l73, ptr %t117, i64 176, i1 false)
  br label %bb24
bb24:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t120, ptr %s0, ptr %l73)
  call void @llvm.memmove.p0.p0.i64(ptr %l75, ptr %t120, i64 176, i1 false)
  br label %bb25
bb25:
  %t122 = getelementptr %"compiler/bindgen:record", ptr %l75, i32 0, i32 2
  %t123 = load i1, ptr %t122, !tbaa !21
  store i1 %t123, ptr %l69, !tbaa !21
  br label %bb26
bb26:
  %t125 = load i1, ptr %l69, !tbaa !21
  br i1 %t125, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb28:
  br label %bb29
bb29:
  %t126 = load i64, ptr %l5, !tbaa !24
  store i1 true, ptr %l12, !tbaa !21
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/bindgen:gen", ptr %t128, i32 0, i32 5
  %t134 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t130, i64 %t126)
  store ptr %t134, ptr %l81
  br label %bb30
bb30:
  %t135 = load ptr, ptr %l81, !tbaa !29
  %t137 = load i1, ptr %l12, !tbaa !21
  %t140 = getelementptr %"compiler/bindgen:record", ptr %t135, i32 0, i32 2
  store i1 %t137, ptr %t140, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %v1, ptr %s6, ptr %t141)
  store { i64, ptr } %t143, ptr %l85
  br label %bb31
bb31:
  %t144 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  %t146 = extractvalue { i64, ptr } %t144, 1
  %t147 = mul i64 %t145, 8
  %t148 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 0
  store i64 %t154, ptr %l16, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t156 = load i64, ptr %l15, !tbaa !24
  %t157 = load i64, ptr %l16, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb34:
  br label %bb35
bb35:
  %t164 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t164, ptr %l93, !tbaa !27
  %t165 = load i64, ptr %l15, !tbaa !24
  %t167 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr ptr, ptr %t168, i64 %t165
  %t170 = load ptr, ptr %t169, !tbaa !39
  store ptr %t170, ptr %l17, !tbaa !29
  %t172 = load ptr, ptr %l17, !tbaa !29
  %t174 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s6, ptr %s7, ptr %s7, ptr %t172, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d119, i32 0, i32 1) })
  store { i64, ptr } %t174, ptr %l97
  br label %bb36
bb36:
  %t175 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t175, ptr %l18, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t178 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t176, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d120, i32 0, i32 1) })
  store i1 %t178, ptr %l99
  br label %bb37
bb37:
  %t179 = load i1, ptr %l99, !tbaa !21
  br i1 %t179, label %bb38, label %bb39
bb38:
  %t180 = load i64, ptr %l5, !tbaa !24
  store i1 true, ptr %l20, !tbaa !21
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/bindgen:gen", ptr %t182, i32 0, i32 5
  %t188 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t184, i64 %t180)
  store ptr %t188, ptr %l104
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t189 = load ptr, ptr %l104, !tbaa !29
  %t191 = load i1, ptr %l20, !tbaa !21
  %t194 = getelementptr %"compiler/bindgen:record", ptr %t189, i32 0, i32 12
  store i1 %t191, ptr %t194, !tbaa !21
  br label %bb41
bb41:
  %t195 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t197 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t195, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d121, i32 0, i32 1) })
  store i1 %t197, ptr %l108
  br label %bb42
bb42:
  %t198 = load i1, ptr %l108, !tbaa !21
  br i1 %t198, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l109, !tbaa !29
  %t200 = load ptr, ptr %l17, !tbaa !29
  store ptr %t200, ptr %l110, !tbaa !29
  %t201 = load ptr, ptr %l17, !tbaa !29
  %t203 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s6, ptr %s9, ptr %s9, ptr %t201, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store { i64, ptr } %t203, ptr %l112
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t204 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 0
  %t206 = extractvalue { i64, ptr } %t204, 1
  %t207 = mul i64 %t205, 1
  %t208 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t207)
  call void @llvm.memcpy.p0.p0.i64(ptr %t208, ptr %t206, i64 %t207, i1 false)
  %t209 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t211 = load i1, ptr %l3, !tbaa !21
  %t212 = load ptr, ptr %l109, !tbaa !29
  %t213 = load ptr, ptr %l110, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordDecl(ptr %v0, ptr %s6, ptr %s9, ptr %t212, ptr %t213, { i64, ptr } %t210, i1 %t211)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb47
bb47:
  %t216 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t218 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t216, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d123, i32 0, i32 1) })
  store i1 %t218, ptr %l116
  br label %bb48
bb48:
  %t219 = load i1, ptr %l116, !tbaa !21
  %t220 = xor i1 %t219, true
  br i1 %t220, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb50:
  br label %bb51
bb51:
  %t222 = load ptr, ptr %l17, !tbaa !29
  %t224 = call i1 @compiler_2fbindgen_2eflag(ptr %s6, ptr %s7, ptr %t222, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d124, i32 0, i32 1) })
  store i1 %t224, ptr %l119
  br label %bb52
bb52:
  %t225 = load i1, ptr %l119, !tbaa !21
  br i1 %t225, label %bb53, label %bb54
bb53:
  %t226 = load i64, ptr %l5, !tbaa !24
  store i1 true, ptr %l23, !tbaa !21
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/bindgen:gen", ptr %t228, i32 0, i32 5
  %t234 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t230, i64 %t226)
  store ptr %t234, ptr %l124
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t235 = load ptr, ptr %l124, !tbaa !29
  %t237 = load i1, ptr %l23, !tbaa !21
  %t240 = getelementptr %"compiler/bindgen:record", ptr %t235, i32 0, i32 3
  store i1 %t237, ptr %t240, !tbaa !21
  br label %bb56
bb56:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/bindgen:gen", ptr %t241, i32 0, i32 5
  %t244 = load i64, ptr %l5, !tbaa !24
  %t247 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t243, i64 %t244)
  store ptr %t247, ptr %l130
  br label %bb57
bb57:
  %t248 = load ptr, ptr %l130, !tbaa !29
  %t250 = getelementptr %"compiler/bindgen:record", ptr %t248, i32 0, i32 4
  store ptr %t250, ptr %l132, !tbaa !29
  %t251 = load ptr, ptr %l17, !tbaa !29
  %t253 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s6, ptr %v0, ptr %v0, ptr %t251, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d125, i32 0, i32 1) })
  store { i64, ptr } %t253, ptr %l134
  br label %bb58
bb58:
  %t254 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  %t256 = extractvalue { i64, ptr } %t254, 1
  %t257 = mul i64 %t255, 1
  %t258 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t257)
  call void @llvm.memcpy.p0.p0.i64(ptr %t258, ptr %t256, i64 %t257, i1 false)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  %t261 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t261, { i64, ptr } %t260)
  br label %bb59
bb59:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/bindgen:gen", ptr %t263, i32 0, i32 5
  %t266 = load i64, ptr %l5, !tbaa !24
  %t269 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t265, i64 %t266)
  store ptr %t269, ptr %l139
  br label %bb60
bb60:
  %t270 = load ptr, ptr %l139, !tbaa !29
  %t272 = getelementptr %"compiler/bindgen:record", ptr %t270, i32 0, i32 5
  store ptr %t272, ptr %l141, !tbaa !29
  %t273 = load ptr, ptr %l17, !tbaa !29
  %t275 = call { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %s6, ptr %v0, ptr %t273)
  store { i64, ptr } %t275, ptr %l143
  br label %bb61
bb61:
  %t276 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 0
  %t278 = extractvalue { i64, ptr } %t276, 1
  %t279 = mul i64 %t277, 1
  %t280 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t279)
  call void @llvm.memcpy.p0.p0.i64(ptr %t280, ptr %t278, i64 %t279, i1 false)
  %t281 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  %t283 = load ptr, ptr %l141, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t283, { i64, ptr } %t282)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb63:
  %t285 = load i64, ptr %l15, !tbaa !24
  %t287 = add i64 %t285, 1
  store i64 %t287, ptr %l15, !tbaa !24
  br label %bb32
bb64:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a1, 1
  %t5 = extractvalue { i64, ptr } %a1, 0
  %t6 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t5)
  call void @olang_textcopy(ptr %t6, ptr %t4, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = extractvalue { i64, ptr } %t8, 1
  %t12 = mul i64 %t10, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @llvm.memcpy.p0.p0.i64(ptr %t13, ptr %t11, i64 %t12, i1 false)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t18 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 25
  store { i64, ptr } %t15, ptr %t18, !tbaa !27
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2estructDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca ptr
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca ptr
  %l28 = alloca i1
  %l33 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l84 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l101 = alloca %"compiler/bindgen:ctype"
  %l104 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l109 = alloca %"compiler/bindgen:ctype"
  %l111 = alloca { i64, ptr }
  %l112 = alloca i32
  %l114 = alloca i1
  %l115 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l125 = alloca %"compiler/bindgen:ctype"
  %l129 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l133 = alloca i32
  %l135 = alloca i1
  %l136 = alloca { i64, ptr }
  %l138 = alloca i64
  %l139 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/bindgen:gen", ptr %t3, i32 0, i32 5
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t9, ptr %l20
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l20, !tbaa !29
  store ptr %t10, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/bindgen:record", ptr %t11, i32 0, i32 7
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t15 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t18 = extractvalue { i64, ptr } %t14, 1
  %t19 = extractvalue { i64, ptr } %t14, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t15, i64 %t16)
  %t25 = getelementptr i8, ptr %t24, i64 %t16
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = getelementptr i8, ptr %t25, i64 %t19
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t24, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t35)
  br label %bb3
bb3:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t38, i64 %t39)
  store i1 %t42, ptr %l28
  br label %bb4
bb4:
  %t43 = load i1, ptr %l28, !tbaa !21
  %t44 = xor i1 %t43, true
  br i1 %t44, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/bindgen:record", ptr %t46, i32 0, i32 14
  %t49 = load i64, ptr %t48, !tbaa !24
  %t51 = icmp eq i64 %t49, 8
  br i1 %t51, label %bb7, label %bb8
bb6:
  br label %bb18
bb7:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb15
bb8:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/bindgen:record", ptr %t53, i32 0, i32 14
  %t56 = load i64, ptr %t55, !tbaa !24
  %t58 = icmp eq i64 %t56, 4
  br i1 %t58, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d129, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb14
bb10:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/bindgen:record", ptr %t60, i32 0, i32 14
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = icmp eq i64 %t63, 2
  br i1 %t65, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d130, i32 0, i32 1) }, ptr %l41, !tbaa !27
  br label %bb13
bb12:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d131, i32 0, i32 1) }, ptr %l41, !tbaa !27
  br label %bb13
bb13:
  %t67 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t67, ptr %l37, !tbaa !27
  br label %bb14
bb14:
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l33, !tbaa !27
  br label %bb15
bb15:
  %t69 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = getelementptr %"compiler/bindgen:record", ptr %t71, i32 0, i32 13
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/bindgen:record", ptr %t75, i32 0, i32 14
  %t78 = load i64, ptr %t77, !tbaa !24
  %t81 = sdiv i64 %t74, %t78
  %t82 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t85 = extractvalue { i64, ptr } %t69, 1
  %t86 = extractvalue { i64, ptr } %t69, 0
  %t87 = add i64 %t83, %t86
  %t88 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t92 = call i64 @__olang_fmt_i64(ptr null, i64 %t81)
  %t93 = add i64 %t90, %t92
  %t94 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t82, i64 %t83)
  %t98 = getelementptr i8, ptr %t97, i64 %t83
  call void @olang_textcopy(ptr %t98, ptr %t85, i64 %t86)
  %t99 = getelementptr i8, ptr %t98, i64 %t86
  call void @olang_textcopy(ptr %t99, ptr %t88, i64 %t89)
  %t100 = getelementptr i8, ptr %t99, i64 %t89
  %t101 = call i64 @__olang_fmt_i64(ptr %t100, i64 %t81)
  %t102 = getelementptr i8, ptr %t100, i64 %t92
  call void @olang_textcopy(ptr %t102, ptr %t94, i64 %t95)
  %t103 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t97, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t111)
  br label %bb16
bb16:
  %t115 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t115, ptr %l52
  br label %bb17
bb17:
  %t116 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t116, ptr %l53, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l54, !tbaa !24
  %t119 = load i64, ptr %l54, !tbaa !24
  %t120 = mul i64 %t119, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l55, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l54, !tbaa !24
  %t129 = mul i64 %t128, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t130, ptr %l53, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t131 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t131, ptr %rv
  br label %ret
bb18:
  %t132 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t132, ptr %l56
  br label %bb19
bb19:
  %t133 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l56
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t133, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t134 = load ptr, ptr %l3, !tbaa !29
  %t136 = getelementptr %"compiler/bindgen:record", ptr %t134, i32 0, i32 4
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t136)
  store i64 %t138, ptr %l59
  br label %bb20
bb20:
  %t139 = load i64, ptr %l59, !tbaa !24
  store i64 %t139, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t140 = load i64, ptr %l7, !tbaa !24
  %t141 = load i64, ptr %l6, !tbaa !24
  %t144 = icmp sgt i64 %t140, %t141
  br i1 %t144, label %bb21, label %bb22
bb21:
  %t146 = load i64, ptr %l8, !tbaa !24
  %t148 = icmp sgt i64 %t146, 0
  br i1 %t148, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb26
bb23:
  %t150 = load i64, ptr %l7, !tbaa !24
  %t151 = load i64, ptr %l6, !tbaa !24
  %t154 = sub i64 %t150, %t151
  %t155 = load i64, ptr %l8, !tbaa !24
  %t158 = add i64 %t154, %t155
  %t160 = sub i64 %t158, 1
  %t161 = load i64, ptr %l8, !tbaa !24
  %t164 = sdiv i64 %t160, %t161
  store i64 %t164, ptr %l66, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb25
bb25:
  %t166 = load i64, ptr %l66, !tbaa !24
  store i64 %t166, ptr %l63, !tbaa !24
  br label %bb26
bb26:
  %t167 = load i64, ptr %l63, !tbaa !24
  store i64 %t167, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t168 = load i64, ptr %l10, !tbaa !24
  %t169 = load i64, ptr %l9, !tbaa !24
  %t172 = icmp slt i64 %t168, %t169
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb29:
  br label %bb30
bb30:
  %t176 = load i64, ptr %l6, !tbaa !24
  %t177 = load i64, ptr %l10, !tbaa !24
  %t178 = load i64, ptr %l8, !tbaa !24
  %t181 = mul i64 %t177, %t178
  %t184 = add i64 %t176, %t181
  store i64 %t184, ptr %l11, !tbaa !24
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l84, !tbaa !29
  %t187 = load ptr, ptr %l3, !tbaa !29
  %t189 = getelementptr %"compiler/bindgen:record", ptr %t187, i32 0, i32 4
  %t190 = load i64, ptr %l11, !tbaa !24
  %t193 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t189, i64 %t190)
  store { i64, ptr } %t193, ptr %l88
  br label %bb31
bb31:
  %t194 = load i64, ptr %l11, !tbaa !24
  %t195 = load ptr, ptr %l84, !tbaa !29
  %t196 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t199 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v0, ptr %s0, ptr %s5, ptr %t195, { i64, ptr } %t196, i64 %t194, ptr %l5)
  store { i64, ptr } %t199, ptr %l91
  br label %bb32
bb32:
  %t200 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t200, ptr %l12, !tbaa !27
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l92, !tbaa !29
  %t202 = load ptr, ptr %l3, !tbaa !29
  %t204 = getelementptr %"compiler/bindgen:record", ptr %t202, i32 0, i32 5
  %t205 = load i64, ptr %l11, !tbaa !24
  %t208 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t204, i64 %t205)
  store { i64, ptr } %t208, ptr %l96
  br label %bb33
bb33:
  %t209 = load ptr, ptr %l92, !tbaa !29
  %t210 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t211 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v0, ptr %t209, { i64, ptr } %t210, i64 0)
  store i64 %t211, ptr %l97
  br label %bb34
bb34:
  %t212 = load i64, ptr %l97, !tbaa !24
  store i64 %t212, ptr %l13, !tbaa !24
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/bindgen:gen", ptr %t213, i32 0, i32 16
  %t216 = load i64, ptr %l13, !tbaa !24
  %t219 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s5, ptr %t215, i64 %t216)
  store %"compiler/bindgen:ctype" %t219, ptr %l101
  br label %bb35
bb35:
  %t220 = getelementptr %"compiler/bindgen:ctype", ptr %l101, i32 0, i32 0
  %t221 = load i32, ptr %t220, !range !{i32 0, i32 7}
  %t223 = trunc i64 4 to i32
  %t224 = icmp eq i32 %t221, %t223
  br i1 %t224, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l105, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/bindgen:gen", ptr %t227, i32 0, i32 16
  %t230 = load i64, ptr %l13, !tbaa !24
  %t233 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s6, ptr %t229, i64 %t230)
  store %"compiler/bindgen:ctype" %t233, ptr %l109
  br label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i64, ptr %l13, !tbaa !24
  %t238 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %s8, ptr %t234, i64 %t235)
  %t239 = extractvalue { i32, { i64, ptr } } %t238, 1
  %t240 = extractvalue { i32, { i64, ptr } } %t238, 0
  store i32 %t240, ptr %l133
  %t241 = icmp ne i32 %t240, 0
  br i1 %t241, label %bb46, label %ok.242, !prof !99
ok.242:
  store { i64, ptr } %t239, ptr %l132
  br label %bb45
bb38:
  %t243 = getelementptr %"compiler/bindgen:ctype", ptr %l109, i32 0, i32 2
  %t244 = load i64, ptr %t243, !tbaa !24
  %t245 = load ptr, ptr %l105, !tbaa !29
  %t247 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %s6, ptr %t245, i64 %t244)
  %t248 = extractvalue { i32, { i64, ptr } } %t247, 1
  %t249 = extractvalue { i32, { i64, ptr } } %t247, 0
  store i32 %t249, ptr %l112
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb40, label %ok.251, !prof !99
ok.251:
  store { i64, ptr } %t248, ptr %l111
  br label %bb39
bb39:
  %t252 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t252, ptr %l104, !tbaa !27
  br label %bb42
bb40:
  %t253 = load i32, ptr %l112, !tbaa !23
  %t254 = ashr i32 %t253, 16
  %t256 = icmp eq i32 %t254, 1
  store i1 %t256, ptr %l114, !tbaa !21
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d135, i32 0, i32 1) }, ptr %l115, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t257, ptr %l104, !tbaa !27
  br label %bb42
bb42:
  %t259 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 0
  store i64 %t260, ptr %l117, !tbaa !24
  %t261 = load i64, ptr %l117, !tbaa !24
  %t262 = mul i64 %t261, 1
  %t263 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t262)
  %t264 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  store { i64, ptr } %t265, ptr %l118, !tbaa !27
  %t266 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = load i64, ptr %l117, !tbaa !24
  %t271 = mul i64 %t270, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t267, ptr %t269, i64 %t271, i1 false)
  %t272 = load { i64, ptr }, ptr %l118, !tbaa !27
  store ptr %l2, ptr %l119, !tbaa !29
  %t273 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t273, ptr %l120, !tbaa !27
  store { i64, ptr } %t272, ptr %l121, !tbaa !27
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/bindgen:gen", ptr %t275, i32 0, i32 16
  %t278 = load i64, ptr %l13, !tbaa !24
  %t281 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s6, ptr %t277, i64 %t278)
  store %"compiler/bindgen:ctype" %t281, ptr %l125
  br label %bb43
bb43:
  %t282 = getelementptr %"compiler/bindgen:ctype", ptr %l125, i32 0, i32 4
  %t283 = load i64, ptr %t282, !tbaa !24
  %t284 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t285 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t286 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = add i64 %t285, %t288
  %t290 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t291 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t292 = add i64 %t289, %t291
  %t293 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t293, 1
  %t295 = extractvalue { i64, ptr } %t293, 0
  %t296 = add i64 %t292, %t295
  %t297 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t298 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t299 = add i64 %t296, %t298
  %t301 = call i64 @__olang_fmt_i64(ptr null, i64 %t283)
  %t302 = add i64 %t299, %t301
  %t303 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t305 = add i64 %t302, %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t284, i64 %t285)
  %t307 = getelementptr i8, ptr %t306, i64 %t285
  call void @olang_textcopy(ptr %t307, ptr %t287, i64 %t288)
  %t308 = getelementptr i8, ptr %t307, i64 %t288
  call void @olang_textcopy(ptr %t308, ptr %t290, i64 %t291)
  %t309 = getelementptr i8, ptr %t308, i64 %t291
  call void @olang_textcopy(ptr %t309, ptr %t294, i64 %t295)
  %t310 = getelementptr i8, ptr %t309, i64 %t295
  call void @olang_textcopy(ptr %t310, ptr %t297, i64 %t298)
  %t311 = getelementptr i8, ptr %t310, i64 %t298
  %t312 = call i64 @__olang_fmt_i64(ptr %t311, i64 %t283)
  %t313 = getelementptr i8, ptr %t311, i64 %t301
  call void @olang_textcopy(ptr %t313, ptr %t303, i64 %t304)
  %t314 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t306, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = extractvalue { i64, ptr } %t315, 1
  %t319 = mul i64 %t317, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t319)
  call void @llvm.memcpy.p0.p0.i64(ptr %t320, ptr %t318, i64 %t319, i1 false)
  %t321 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  %t323 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t323, { i64, ptr } %t322)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb45:
  %t325 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t325, ptr %l129, !tbaa !27
  br label %bb48
bb46:
  %t326 = load i32, ptr %l133, !tbaa !23
  %t327 = ashr i32 %t326, 16
  %t329 = icmp eq i32 %t327, 1
  store i1 %t329, ptr %l135, !tbaa !21
  br label %bb47
bb47:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d140, i32 0, i32 1) }, ptr %l136, !tbaa !27
  %t330 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t330, ptr %l129, !tbaa !27
  br label %bb48
bb48:
  %t332 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 0
  store i64 %t333, ptr %l138, !tbaa !24
  %t334 = load i64, ptr %l138, !tbaa !24
  %t335 = mul i64 %t334, 1
  %t336 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t335)
  %t337 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t336, 1
  store { i64, ptr } %t338, ptr %l139, !tbaa !27
  %t339 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = load i64, ptr %l138, !tbaa !24
  %t344 = mul i64 %t343, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t340, ptr %t342, i64 %t344, i1 false)
  %t345 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t346 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t348 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t349 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t351 = extractvalue { i64, ptr } %t346, 1
  %t352 = extractvalue { i64, ptr } %t346, 0
  %t353 = add i64 %t349, %t352
  %t354 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t355 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t356 = add i64 %t353, %t355
  %t358 = extractvalue { i64, ptr } %t345, 1
  %t359 = extractvalue { i64, ptr } %t345, 0
  %t360 = add i64 %t356, %t359
  %t361 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t362 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t363 = add i64 %t360, %t362
  %t364 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t363)
  call void @olang_textcopy(ptr %t364, ptr %t348, i64 %t349)
  %t365 = getelementptr i8, ptr %t364, i64 %t349
  call void @olang_textcopy(ptr %t365, ptr %t351, i64 %t352)
  %t366 = getelementptr i8, ptr %t365, i64 %t352
  call void @olang_textcopy(ptr %t366, ptr %t354, i64 %t355)
  %t367 = getelementptr i8, ptr %t366, i64 %t355
  call void @olang_textcopy(ptr %t367, ptr %t358, i64 %t359)
  %t368 = getelementptr i8, ptr %t367, i64 %t359
  call void @olang_textcopy(ptr %t368, ptr %t361, i64 %t362)
  %t369 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t364, 1
  %t372 = extractvalue { i64, ptr } %t370, 0
  %t373 = extractvalue { i64, ptr } %t370, 1
  %t374 = mul i64 %t372, 1
  %t375 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t374)
  call void @llvm.memcpy.p0.p0.i64(ptr %t375, ptr %t373, i64 %t374, i1 false)
  %t376 = insertvalue { i64, ptr } undef, i64 %t372, 0
  %t377 = insertvalue { i64, ptr } %t376, ptr %t375, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l2, { i64, ptr } %t377)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb51:
  %t380 = load i64, ptr %l10, !tbaa !24
  %t382 = add i64 %t380, 1
  store i64 %t382, ptr %l10, !tbaa !24
  br label %bb27
bb52:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d144, i32 0, i32 1) })
  br label %bb53
bb53:
  %t386 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t386, ptr %l149
  br label %bb54
bb54:
  %t387 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t387, ptr %l150, !tbaa !27
  %t388 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t388, 0
  store i64 %t389, ptr %l151, !tbaa !24
  %t390 = load i64, ptr %l151, !tbaa !24
  %t391 = mul i64 %t390, 1
  %t392 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t391)
  %t393 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t392, 1
  store { i64, ptr } %t394, ptr %l152, !tbaa !27
  %t395 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !27
  %t397 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t398 = load ptr, ptr %t397, !tbaa !27
  %t399 = load i64, ptr %l151, !tbaa !24
  %t400 = mul i64 %t399, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t396, ptr %t398, i64 %t400, i1 false)
  %t401 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t401, ptr %l150, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t402 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t402, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l50 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca i1
  %l59 = alloca { i64, ptr }
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l73 = alloca i1
  %l74 = alloca i64
  %l77 = alloca i1
  %l78 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i1
  %l97 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb47
bb5:
  store i64 0, ptr %l4, !tbaa !24
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v1, ptr %t16)
  store i64 %t18, ptr %l24
  br label %bb6
bb6:
  %t19 = load i64, ptr %l24, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb12
bb9:
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l31, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb11
bb11:
  %t46 = load i64, ptr %l31, !tbaa !24
  store i64 %t46, ptr %l28, !tbaa !24
  br label %bb12
bb12:
  %t47 = load i64, ptr %l28, !tbaa !24
  store i64 %t47, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb15:
  br label %bb16
bb16:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l9, !tbaa !24
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"std/json:Object", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l50, !tbaa !27
  %t70 = load i64, ptr %l9, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l10, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = getelementptr %"std/json:Object", ptr %t77, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l54, !tbaa !27
  %t81 = load i64, ptr %l9, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %t84, i64 %t81
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !37
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t86, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d145, i32 0, i32 1) })
  store i1 %t88, ptr %l57
  br label %bb17
bb17:
  %t89 = load i1, ptr %l57, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb19:
  br label %bb20
bb20:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr %"std/json:Object", ptr %t90, i32 0, i32 0
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l59, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %t97, i64 %t94
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !37
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t99, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d146, i32 0, i32 1) })
  store i1 %t101, ptr %l62
  br label %bb21
bb21:
  %t102 = load i1, ptr %l62, !tbaa !21
  br i1 %t102, label %bb22, label %bb23
bb22:
  %t103 = load ptr, ptr %l10, !tbaa !29
  store ptr %t103, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t104 = load ptr, ptr %l63, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb24, label %bb25
bb23:
  br label %bb43
bb24:
  %t107 = load ptr, ptr %l63, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 8}
  %t110 = icmp eq i64 %t108, 5
  store i1 %t110, ptr %l64, !tbaa !21
  br label %bb25
bb25:
  %t111 = load i1, ptr %l64, !tbaa !21
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t112 = load ptr, ptr %l10, !tbaa !29
  %t114 = getelementptr { i64, [2 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { { i64, ptr } }, ptr %t114, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115
  store { i64, ptr } %t116, ptr %l11, !tbaa !27
  br label %bb28
bb27:
  br label %bb37
bb28:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l69, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/bindgen:gen", ptr %t120, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %v0, { i64, ptr } %t119, { i64, ptr } %t123)
  store i1 %t126, ptr %l73
  br label %bb29
bb29:
  %t127 = load i1, ptr %l73, !tbaa !21
  br i1 %t127, label %bb30, label %bb31
bb30:
  store i64 1, ptr %l74, !tbaa !24
  br label %bb36
bb31:
  %t128 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %v2, { i64, ptr } %t128, { i64, ptr } %t129)
  store i1 %t132, ptr %l77
  br label %bb32
bb32:
  %t133 = load i1, ptr %l77, !tbaa !21
  br i1 %t133, label %bb33, label %bb34
bb33:
  store i64 2, ptr %l78, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb35
bb35:
  %t134 = load i64, ptr %l78, !tbaa !24
  store i64 %t134, ptr %l74, !tbaa !24
  br label %bb36
bb36:
  %t135 = load i64, ptr %l74, !tbaa !24
  %t136 = load ptr, ptr %l69, !tbaa !29
  %t137 = getelementptr %"compiler/bindgen:gen", ptr %t136, i32 0, i32 26
  store i64 %t135, ptr %t137, !tbaa !24
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_c54e19abcb0a74ad_a74456fc2d527de1)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb43:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l10, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %v1, ptr %v2, ptr %t138, ptr %t139, { i64, ptr } %t140)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb45:
  %t144 = load i64, ptr %l8, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l8, !tbaa !24
  br label %bb13
bb46:
  br label %bb65
bb47:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t149 = load ptr, ptr %l84, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb48, label %bb49
bb48:
  %t152 = load ptr, ptr %l84, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 8}
  %t155 = icmp eq i64 %t153, 6
  store i1 %t155, ptr %l85, !tbaa !21
  br label %bb49
bb49:
  %t156 = load i1, ptr %l85, !tbaa !21
  br i1 %t156, label %bb50, label %bb51
bb50:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [2 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { { i64, ptr } }, ptr %t159, i32 0, i32 0
  %t161 = load { i64, ptr }, ptr %t160
  store { i64, ptr } %t161, ptr %l12, !tbaa !27
  br label %bb52
bb51:
  br label %bb60
bb52:
  %t163 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t163, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l15, !tbaa !24
  br label %bb53
bb53:
  %t169 = load i64, ptr %l14, !tbaa !24
  %t170 = load i64, ptr %l15, !tbaa !24
  %t173 = icmp slt i64 %t169, %t170
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb54, label %bb55
bb54:
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t177 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t177, ptr %l97, !tbaa !27
  %t178 = load i64, ptr %l14, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr ptr, ptr %t181, i64 %t178
  %t183 = load ptr, ptr %t182, !tbaa !39
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %v1, ptr %v2, ptr %t185, ptr %t183, { i64, ptr } %t187)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t191 = load i64, ptr %l14, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l14, !tbaa !24
  br label %bb53
bb59:
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_302d290203cc94fc_f1ac1451fbe7e850)
  unreachable
bb65:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etypeName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l62 = alloca { i64, ptr }
  %l64 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l71 = alloca i1
  %l73 = alloca i1
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l79 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l85 = alloca i64
  %l88 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l94 = alloca i1
  %l95 = alloca i1
  %l98 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i1
  %l112 = alloca { i64, ptr }
  %l114 = alloca i64
  %l116 = alloca ptr
  %l120 = alloca i1
  %l123 = alloca i64
  %l125 = alloca i1
  %l128 = alloca i1
  %l130 = alloca i1
  %l140 = alloca i64
  %l142 = alloca i1
  %l143 = alloca i1
  %l145 = alloca i1
  %l150 = alloca i64
  %l157 = alloca i64
  %l159 = alloca i1
  %l161 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l166 = alloca i32
  %l168 = alloca i1
  %l173 = alloca i64
  %l178 = alloca i64
  %l183 = alloca i64
  %l189 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d147, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t1, ptr %l14, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l15, !tbaa !24
  %t4 = load i64, ptr %l15, !tbaa !24
  %t5 = mul i64 %t4, 1
  %t6 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l16, !tbaa !27
  %t9 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = mul i64 %t13, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t10, ptr %t12, i64 %t14, i1 false)
  %t15 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  store i1 false, ptr %l6, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d148, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t16, ptr %l18, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l19, !tbaa !24
  %t19 = load i64, ptr %l19, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t30, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d149, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = mul i64 %t34, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l24, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l23, !tbaa !24
  %t44 = mul i64 %t43, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %t42, i64 %t44, i1 false)
  %t45 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t45, ptr %l8, !tbaa !27
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/bindgen:ctp", ptr %t46, i32 0, i32 1
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/bindgen:ctp", ptr %t50, i32 0, i32 0
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t58 = icmp slt i64 %t49, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb100
bb3:
  br label %bb4
bb4:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s1, ptr %t62, i64 0)
  store { i64, ptr } %t64, ptr %l33
  br label %bb5
bb5:
  %t65 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t65, ptr %l9, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t66, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d150, i32 0, i32 1) })
  store i1 %t68, ptr %l35
  br label %bb6
bb6:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb98
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t70 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s3, { i64, ptr } %t70, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store i1 %t72, ptr %l37
  br label %bb9
bb9:
  %t73 = load i1, ptr %l37, !tbaa !21
  br i1 %t73, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb13
bb11:
  %t74 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s3, { i64, ptr } %t74, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d152, i32 0, i32 1) })
  store i1 %t76, ptr %l40
  br label %bb12
bb12:
  %t77 = load i1, ptr %l40, !tbaa !21
  store i1 %t77, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  %t78 = load i1, ptr %l38, !tbaa !21
  br i1 %t78, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb17
bb15:
  %t79 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t81 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s3, { i64, ptr } %t79, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d153, i32 0, i32 1) })
  store i1 %t81, ptr %l43
  br label %bb16
bb16:
  %t82 = load i1, ptr %l43, !tbaa !21
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t83 = load i1, ptr %l41, !tbaa !21
  br i1 %t83, label %bb18, label %bb19
bb18:
  br label %bb97
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s5, { i64, ptr } %t84, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d154, i32 0, i32 1) })
  store i1 %t86, ptr %l45
  br label %bb20
bb20:
  %t87 = load i1, ptr %l45, !tbaa !21
  br i1 %t87, label %bb21, label %bb22
bb21:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb96
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t88 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s7, { i64, ptr } %t88, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d155, i32 0, i32 1) })
  store i1 %t90, ptr %l47
  br label %bb23
bb23:
  %t91 = load i1, ptr %l47, !tbaa !21
  br i1 %t91, label %bb24, label %bb25
bb24:
  store i64 2, ptr %l3, !tbaa !24
  br label %bb95
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t92 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t94 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s9, { i64, ptr } %t92, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d156, i32 0, i32 1) })
  store i1 %t94, ptr %l49
  br label %bb26
bb26:
  %t95 = load i1, ptr %l49, !tbaa !21
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l4, !tbaa !24
  br label %bb94
bb28:
  store %olang.scope zeroinitializer, ptr %s11
  %t100 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t104 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s11, ptr %s11, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x { i64, ptr }] }>, ptr @.d157, i32 0, i32 1) }, { i64, ptr } %t100)
  store i1 %t104, ptr %l54
  br label %bb29
bb29:
  %t105 = load i1, ptr %l54, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s12
  %t106 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t108 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s12, { i64, ptr } %t106, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d158, i32 0, i32 1) })
  store i1 %t108, ptr %l56
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s15
  %t109 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s15, { i64, ptr } %t109, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t111, ptr %l67
  br label %bb43
bb32:
  %t112 = load i1, ptr %l56, !tbaa !21
  %t113 = xor i1 %t112, true
  br i1 %t113, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb36
bb34:
  %t115 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s12, { i64, ptr } %t115, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d160, i32 0, i32 1) })
  store i1 %t117, ptr %l60
  br label %bb35
bb35:
  %t118 = load i1, ptr %l60, !tbaa !21
  store i1 %t118, ptr %l58, !tbaa !21
  br label %bb36
bb36:
  %t119 = load i1, ptr %l58, !tbaa !21
  br i1 %t119, label %bb37, label %bb38
bb37:
  %t120 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = extractvalue { i64, ptr } %t120, 0
  %t124 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t123)
  call void @olang_textcopy(ptr %t124, ptr %t122, i64 %t123)
  %t125 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  store { i64, ptr } %t126, ptr %l62, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  store i64 %t130, ptr %l64, !tbaa !24
  %t132 = load i64, ptr %l64, !tbaa !24
  %t133 = icmp eq i64 %t128, %t132
  br i1 %t133, label %bb39, label %bb40
bb38:
  br label %bb42
bb39:
  %t135 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = load i64, ptr %l64, !tbaa !24
  %t140 = mul i64 %t139, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t136, ptr %t138, i64 %t140, i1 false)
  br label %bb41
bb40:
  %t141 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t141, ptr %l5, !tbaa !27
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb43:
  %t142 = load i1, ptr %l67, !tbaa !21
  br i1 %t142, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb47
bb45:
  %t143 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t145 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s15, { i64, ptr } %t143, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d161, i32 0, i32 1) })
  store i1 %t145, ptr %l70
  br label %bb46
bb46:
  %t146 = load i1, ptr %l70, !tbaa !21
  store i1 %t146, ptr %l68, !tbaa !21
  br label %bb47
bb47:
  %t147 = load i1, ptr %l68, !tbaa !21
  br i1 %t147, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb51
bb49:
  %t148 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t150 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s15, { i64, ptr } %t148, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d162, i32 0, i32 1) })
  store i1 %t150, ptr %l73
  br label %bb50
bb50:
  %t151 = load i1, ptr %l73, !tbaa !21
  store i1 %t151, ptr %l71, !tbaa !21
  br label %bb51
bb51:
  %t152 = load i1, ptr %l71, !tbaa !21
  br i1 %t152, label %bb52, label %bb53
bb52:
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = extractvalue { i64, ptr } %t153, 0
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t155, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l75, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l77, !tbaa !24
  %t165 = load i64, ptr %l77, !tbaa !24
  %t166 = icmp eq i64 %t161, %t165
  br i1 %t166, label %bb54, label %bb55
bb53:
  store %olang.scope zeroinitializer, ptr %s18
  %t168 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t170 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s18, { i64, ptr } %t168, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d163, i32 0, i32 1) })
  store i1 %t170, ptr %l88
  br label %bb61
bb54:
  %t171 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = load i64, ptr %l77, !tbaa !24
  %t176 = mul i64 %t175, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t172, ptr %t174, i64 %t176, i1 false)
  br label %bb56
bb55:
  %t177 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t177, ptr %l7, !tbaa !27
  br label %bb56
bb56:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l79, !tbaa !29
  %t179 = load ptr, ptr %l79, !tbaa !29
  %t180 = getelementptr %"compiler/bindgen:ctp", ptr %t179, i32 0, i32 1
  %t181 = load i64, ptr %t180, !tbaa !24
  %t183 = add i64 %t181, 1
  %t185 = load ptr, ptr %l79, !tbaa !29
  %t186 = getelementptr %"compiler/bindgen:ctp", ptr %t185, i32 0, i32 1
  store i64 %t183, ptr %t186, !tbaa !24
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t187, i64 0)
  store { i64, ptr } %t189, ptr %l83
  br label %bb57
bb57:
  %t190 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t192 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l85, !tbaa !24
  %t195 = load i64, ptr %l85, !tbaa !24
  %t196 = icmp eq i64 %t191, %t195
  br i1 %t196, label %bb58, label %bb59
bb58:
  %t198 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l85, !tbaa !24
  %t203 = mul i64 %t202, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t199, ptr %t201, i64 %t203, i1 false)
  br label %bb60
bb59:
  %t204 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t204, ptr %l8, !tbaa !27
  br label %bb60
bb60:
  br label %bb92
bb61:
  %t205 = load i1, ptr %l88, !tbaa !21
  br i1 %t205, label %bb62, label %bb63
bb62:
  %t206 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t208 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s18, { i64, ptr } %t206, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d164, i32 0, i32 1) })
  store i1 %t208, ptr %l91
  br label %bb64
bb63:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb65
bb64:
  %t209 = load i1, ptr %l91, !tbaa !21
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb65
bb65:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb66, label %bb67
bb66:
  %t211 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t213 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s18, { i64, ptr } %t211, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d165, i32 0, i32 1) })
  store i1 %t213, ptr %l94
  br label %bb68
bb67:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb69
bb68:
  %t214 = load i1, ptr %l94, !tbaa !21
  store i1 %t214, ptr %l92, !tbaa !21
  br label %bb69
bb69:
  %t215 = load i1, ptr %l92, !tbaa !21
  br i1 %t215, label %bb70, label %bb71
bb70:
  %t216 = load i64, ptr %l3, !tbaa !24
  %t218 = icmp eq i64 %t216, 0
  store i1 %t218, ptr %l95, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb72
bb72:
  %t220 = load i1, ptr %l95, !tbaa !21
  br i1 %t220, label %bb73, label %bb74
bb73:
  %t221 = load i64, ptr %l4, !tbaa !24
  %t223 = icmp eq i64 %t221, 0
  store i1 %t223, ptr %l98, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb75
bb75:
  %t225 = load i1, ptr %l98, !tbaa !21
  br i1 %t225, label %bb76, label %bb77
bb76:
  %t226 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t230 = icmp sgt i64 %t228, 0
  store i1 %t230, ptr %l101, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb78
bb78:
  %t232 = load i1, ptr %l101, !tbaa !21
  br i1 %t232, label %bb79, label %bb80
bb79:
  %t233 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i8, ptr %t234, i64 0
  %t236 = load i8, ptr %t235, !tbaa !32
  %t238 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t236)
  store i1 %t238, ptr %l107
  br label %bb81
bb80:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb85
bb81:
  %t239 = load i1, ptr %l107, !tbaa !21
  br i1 %t239, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb84
bb83:
  %t240 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr i8, ptr %t241, i64 0
  %t243 = load i8, ptr %t242, !tbaa !32
  %t245 = icmp eq i8 %t243, 95
  store i1 %t245, ptr %l108, !tbaa !21
  br label %bb84
bb84:
  %t247 = load i1, ptr %l108, !tbaa !21
  store i1 %t247, ptr %l105, !tbaa !21
  br label %bb85
bb85:
  %t248 = load i1, ptr %l105, !tbaa !21
  br i1 %t248, label %bb86, label %bb87
bb86:
  %t249 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t249, 1
  %t252 = extractvalue { i64, ptr } %t249, 0
  %t253 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t252)
  call void @olang_textcopy(ptr %t253, ptr %t251, i64 %t252)
  %t254 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  store { i64, ptr } %t255, ptr %l112, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 0
  %t258 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 0
  store i64 %t259, ptr %l114, !tbaa !24
  %t261 = load i64, ptr %l114, !tbaa !24
  %t262 = icmp eq i64 %t257, %t261
  br i1 %t262, label %bb88, label %bb89
bb87:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  br label %bb100
bb88:
  %t264 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = load i64, ptr %l114, !tbaa !24
  %t269 = mul i64 %t268, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t265, ptr %t267, i64 %t269, i1 false)
  br label %bb90
bb89:
  %t270 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t270, ptr %l8, !tbaa !27
  br label %bb90
bb90:
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s18)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s15)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s11)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s9)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s7)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s5)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s3)
  br label %bb98
bb98:
  %t271 = load ptr, ptr %l1, !tbaa !29
  store ptr %t271, ptr %l116, !tbaa !29
  %t272 = load ptr, ptr %l116, !tbaa !29
  %t273 = getelementptr %"compiler/bindgen:ctp", ptr %t272, i32 0, i32 1
  %t274 = load i64, ptr %t273, !tbaa !24
  %t276 = add i64 %t274, 1
  %t278 = load ptr, ptr %l116, !tbaa !29
  %t279 = getelementptr %"compiler/bindgen:ctp", ptr %t278, i32 0, i32 1
  store i64 %t276, ptr %t279, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb99
bb99:
  br label %bb1
bb100:
  store i64 0, ptr %l11, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t282 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t280, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d166, i32 0, i32 1) })
  store i1 %t282, ptr %l120
  br label %bb101
bb101:
  %t283 = load i1, ptr %l120, !tbaa !21
  br i1 %t283, label %bb102, label %bb103
bb102:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t287 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t284, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d167, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t287, ptr %l123
  br label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s23
  %t288 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t290 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s23, { i64, ptr } %t288, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d168, i32 0, i32 1) })
  store i1 %t290, ptr %l125
  br label %bb105
bb104:
  %t291 = load i64, ptr %l123, !tbaa !24
  store i64 %t291, ptr %l11, !tbaa !24
  br label %bb142
bb105:
  %t292 = load i1, ptr %l125, !tbaa !21
  %t293 = xor i1 %t292, true
  br i1 %t293, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s24
  %t295 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t297 = call i1 @compiler_2fbindgen_2eusable(ptr %s0, { i64, ptr } %t295)
  store i1 %t297, ptr %l128
  br label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s30
  %t298 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t300 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s30, { i64, ptr } %t298, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d169, i32 0, i32 1) })
  store i1 %t300, ptr %l159
  br label %bb126
bb108:
  %t301 = load i1, ptr %l128, !tbaa !21
  %t302 = xor i1 %t301, true
  br i1 %t302, label %bb109, label %bb110
bb109:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/bindgen:gen", ptr %t304, i32 0, i32 1
  %t307 = load i1, ptr %t306, !tbaa !21
  %t309 = xor i1 %t307, true
  store i1 %t309, ptr %l130, !tbaa !21
  br label %bb111
bb110:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb111
bb111:
  %t311 = load i1, ptr %l130, !tbaa !21
  br i1 %t311, label %bb112, label %bb113
bb112:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t314 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t316 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t319 = extractvalue { i64, ptr } %t313, 1
  %t320 = extractvalue { i64, ptr } %t313, 0
  %t321 = add i64 %t317, %t320
  %t322 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t324 = add i64 %t321, %t323
  %t326 = extractvalue { i64, ptr } %t314, 1
  %t327 = extractvalue { i64, ptr } %t314, 0
  %t328 = add i64 %t324, %t327
  %t329 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t330 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t331 = add i64 %t328, %t330
  %t333 = extractvalue { i64, ptr } %t315, 1
  %t334 = extractvalue { i64, ptr } %t315, 0
  %t335 = add i64 %t331, %t334
  %t336 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t337 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t338 = add i64 %t335, %t337
  %t339 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t338)
  call void @olang_textcopy(ptr %t339, ptr %t316, i64 %t317)
  %t340 = getelementptr i8, ptr %t339, i64 %t317
  call void @olang_textcopy(ptr %t340, ptr %t319, i64 %t320)
  %t341 = getelementptr i8, ptr %t340, i64 %t320
  call void @olang_textcopy(ptr %t341, ptr %t322, i64 %t323)
  %t342 = getelementptr i8, ptr %t341, i64 %t323
  call void @olang_textcopy(ptr %t342, ptr %t326, i64 %t327)
  %t343 = getelementptr i8, ptr %t342, i64 %t327
  call void @olang_textcopy(ptr %t343, ptr %t329, i64 %t330)
  %t344 = getelementptr i8, ptr %t343, i64 %t330
  call void @olang_textcopy(ptr %t344, ptr %t333, i64 %t334)
  %t345 = getelementptr i8, ptr %t344, i64 %t334
  call void @olang_textcopy(ptr %t345, ptr %t336, i64 %t337)
  %t346 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t339, 1
  %t349 = extractvalue { i64, ptr } %t347, 0
  %t350 = extractvalue { i64, ptr } %t347, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t357 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t312, { i64, ptr } %t354)
  store i64 %t357, ptr %l140
  br label %bb114
bb113:
  br label %bb115
bb114:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t358 = load i64, ptr %l140, !tbaa !24
  store i64 %t358, ptr %rv
  br label %ret
bb115:
  %t359 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t361 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s24, { i64, ptr } %t359, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) })
  store i1 %t361, ptr %l142
  br label %bb116
bb116:
  %t362 = load i1, ptr %l142, !tbaa !21
  br i1 %t362, label %bb117, label %bb118
bb117:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb120
bb118:
  %t363 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t365 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s24, { i64, ptr } %t363, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) })
  store i1 %t365, ptr %l145
  br label %bb119
bb119:
  %t366 = load i1, ptr %l145, !tbaa !21
  store i1 %t366, ptr %l143, !tbaa !21
  br label %bb120
bb120:
  %t367 = load i1, ptr %l143, !tbaa !21
  br i1 %t367, label %bb121, label %bb122
bb121:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t370 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t373 = extractvalue { i64, ptr } %t369, 1
  %t374 = extractvalue { i64, ptr } %t369, 0
  %t375 = add i64 %t371, %t374
  %t376 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t377 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t378 = add i64 %t375, %t377
  %t379 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t378)
  call void @olang_textcopy(ptr %t379, ptr %t370, i64 %t371)
  %t380 = getelementptr i8, ptr %t379, i64 %t371
  call void @olang_textcopy(ptr %t380, ptr %t373, i64 %t374)
  %t381 = getelementptr i8, ptr %t380, i64 %t374
  call void @olang_textcopy(ptr %t381, ptr %t376, i64 %t377)
  %t382 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr %t379, 1
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t386 = extractvalue { i64, ptr } %t383, 1
  %t387 = mul i64 %t385, 1
  %t388 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t387)
  call void @llvm.memcpy.p0.p0.i64(ptr %t388, ptr %t386, i64 %t387, i1 false)
  %t389 = insertvalue { i64, ptr } undef, i64 %t385, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t388, 1
  %t393 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t368, { i64, ptr } %t390)
  store i64 %t393, ptr %l150
  br label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t394 = load i64, ptr %l150, !tbaa !24
  store i64 %t394, ptr %rv
  br label %ret
bb124:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t397 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t399 = extractvalue { i64, ptr } %t396, 1
  %t400 = extractvalue { i64, ptr } %t396, 0
  %t401 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t402 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t403 = add i64 %t400, %t402
  %t405 = extractvalue { i64, ptr } %t397, 1
  %t406 = extractvalue { i64, ptr } %t397, 0
  %t407 = add i64 %t403, %t406
  %t408 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t407)
  call void @olang_textcopy(ptr %t408, ptr %t399, i64 %t400)
  %t409 = getelementptr i8, ptr %t408, i64 %t400
  call void @olang_textcopy(ptr %t409, ptr %t401, i64 %t402)
  %t410 = getelementptr i8, ptr %t409, i64 %t402
  call void @olang_textcopy(ptr %t410, ptr %t405, i64 %t406)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t408, 1
  %t414 = extractvalue { i64, ptr } %t412, 0
  %t415 = extractvalue { i64, ptr } %t412, 1
  %t416 = mul i64 %t414, 1
  %t417 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t416)
  call void @llvm.memcpy.p0.p0.i64(ptr %t417, ptr %t415, i64 %t416, i1 false)
  %t418 = insertvalue { i64, ptr } undef, i64 %t414, 0
  %t419 = insertvalue { i64, ptr } %t418, ptr %t417, 1
  %t423 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t395, i32 2, { i64, ptr } %t419, i64 -1, i1 false, i64 0)
  store i64 %t423, ptr %l157
  br label %bb125
bb125:
  %t424 = load i64, ptr %l157, !tbaa !24
  store i64 %t424, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb141
bb126:
  %t425 = load i1, ptr %l159, !tbaa !21
  %t426 = xor i1 %t425, true
  br i1 %t426, label %bb127, label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s31
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/bindgen:gen", ptr %t428, i32 0, i32 4
  %t431 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t434 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %s0, ptr %v0, ptr %t430, { i64, ptr } %t431)
  %t435 = extractvalue { i32, { i64, ptr } } %t434, 1
  %t436 = extractvalue { i32, { i64, ptr } } %t434, 0
  store i32 %t436, ptr %l166
  %t437 = icmp ne i32 %t436, 0
  br i1 %t437, label %bb130, label %ok.438, !prof !99
ok.438:
  store { i64, ptr } %t435, ptr %l165
  br label %bb129
bb128:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t441 = load i64, ptr %l3, !tbaa !24
  %t442 = load i64, ptr %l4, !tbaa !24
  %t447 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enumType(ptr %v0, ptr %s0, ptr %t439, { i64, ptr } %t440, i64 %t441, i64 %t442)
  store i64 %t447, ptr %l183
  br label %bb139
bb129:
  %t448 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t448, ptr %l161, !tbaa !27
  br label %bb132
bb130:
  br label %bb131
bb131:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) }, ptr %l161, !tbaa !27
  br label %bb132
bb132:
  %t449 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t449, ptr %l12, !tbaa !27
  %t450 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t452 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s31, { i64, ptr } %t450, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d180, i32 0, i32 1) })
  store i1 %t452, ptr %l168
  br label %bb133
bb133:
  %t453 = load i1, ptr %l168, !tbaa !21
  br i1 %t453, label %bb134, label %bb135
bb134:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t456 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t457 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t459 = extractvalue { i64, ptr } %t455, 1
  %t460 = extractvalue { i64, ptr } %t455, 0
  %t461 = add i64 %t457, %t460
  %t462 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t463 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t464 = add i64 %t461, %t463
  %t465 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t464)
  call void @olang_textcopy(ptr %t465, ptr %t456, i64 %t457)
  %t466 = getelementptr i8, ptr %t465, i64 %t457
  call void @olang_textcopy(ptr %t466, ptr %t459, i64 %t460)
  %t467 = getelementptr i8, ptr %t466, i64 %t460
  call void @olang_textcopy(ptr %t467, ptr %t462, i64 %t463)
  %t468 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t469 = insertvalue { i64, ptr } %t468, ptr %t465, 1
  %t471 = extractvalue { i64, ptr } %t469, 0
  %t472 = extractvalue { i64, ptr } %t469, 1
  %t473 = mul i64 %t471, 1
  %t474 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t473)
  call void @llvm.memcpy.p0.p0.i64(ptr %t474, ptr %t472, i64 %t473, i1 false)
  %t475 = insertvalue { i64, ptr } undef, i64 %t471, 0
  %t476 = insertvalue { i64, ptr } %t475, ptr %t474, 1
  %t479 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t454, { i64, ptr } %t476)
  store i64 %t479, ptr %l173
  br label %bb136
bb135:
  br label %bb137
bb136:
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t480 = load i64, ptr %l173, !tbaa !24
  store i64 %t480, ptr %rv
  br label %ret
bb137:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t483 = load i64, ptr %l2, !tbaa !24
  %t485 = add i64 %t483, 1
  %t489 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v0, ptr %t481, { i64, ptr } %t482, i64 %t485)
  store i64 %t489, ptr %l178
  br label %bb138
bb138:
  %t490 = load i64, ptr %l178, !tbaa !24
  store i64 %t490, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s31)
  br label %bb140
bb139:
  %t491 = load i64, ptr %l183, !tbaa !24
  store i64 %t491, ptr %l11, !tbaa !24
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s30)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s23)
  br label %bb142
bb142:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t494 = load i64, ptr %l11, !tbaa !24
  %t495 = load i1, ptr %l6, !tbaa !21
  %t496 = load i64, ptr %l2, !tbaa !24
  %t502 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edeclarator(ptr %v0, ptr %v1, ptr %t492, ptr %t493, i64 %t494, i1 %t495, i64 %t496)
  store i64 %t502, ptr %l189
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s0)
  %t503 = load i64, ptr %l189, !tbaa !24
  store i64 %t503, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/bindgen:ctype"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/bindgen:ctype"
  %l7 = alloca i64
  %l11 = alloca %"compiler/bindgen:ctype"
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l28 = alloca i64
  %l31 = alloca i1
  %l34 = alloca i32
  %l38 = alloca { i64, ptr }
  %l44 = alloca %"compiler/bindgen:ctype"
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i1
  %l63 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l78 = alloca i32
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l88 = alloca i32
  %l91 = alloca i32
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 16
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/bindgen:ctype" %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l11
  store %"compiler/bindgen:ctype" %t8, ptr %l3
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 0
  %t10 = load i32, ptr %t9, !range !{i32 0, i32 7}
  store i32 %t10, ptr %l4
  %t12 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb9
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d183, i32 0, i32 1) })
  store i1 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load i1, ptr %l16, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d184, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l17, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l22, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l23, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l22, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t46, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t47 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t48 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t47, 1
  store { i32, { i64, ptr } } %t48, ptr %rv
  br label %ret
bb9:
  %t49 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t51 = trunc i64 2 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t59 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t54, { i64, ptr } %t56)
  store i64 %t59, ptr %l28
  br label %bb13
bb13:
  %t60 = load i64, ptr %l28, !tbaa !24
  store i64 %t60, ptr %l5, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t61, i64 %t62)
  store i1 %t65, ptr %l31
  br label %bb14
bb14:
  %t66 = load i1, ptr %l31, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s4, ptr %t69, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d185, i32 0, i32 1) })
  store i32 %t71, ptr %l34
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb18, label %ok.73, !prof !99
ok.73:
  br label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb19
bb18:
  %t74 = load i32, ptr %l34, !tbaa !23
  %t75 = lshr i32 %t74, 16
  %t76 = and i32 %t74, 65535
  %t77 = icmp eq i32 %t75, 1
  %t78 = select i1 %t77, i32 1, i32 0
  %t79 = icmp eq i32 %t74, 0
  %t80 = shl i32 %t78, 16
  %t81 = or i32 %t80, %t76
  %t82 = select i1 %t79, i32 0, i32 %t81
  call void @__olang_scope_close(ptr %s4)
  %t84 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t82, 0
  store { i32, { i64, ptr } } %t84, ptr %rv
  br label %ret
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %v1, ptr %t85, i64 %t86)
  store { i64, ptr } %t89, ptr %l38
  br label %bb21
bb21:
  %t90 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
bb22:
  %t92 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t94 = trunc i64 3 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb51
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/bindgen:gen", ptr %t97, i32 0, i32 16
  %t100 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  %t104 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t99, i64 %t101)
  store %"compiler/bindgen:ctype" %t104, ptr %l44
  br label %bb26
bb26:
  %t105 = load %"compiler/bindgen:ctype", ptr %l44
  store %"compiler/bindgen:ctype" %t105, ptr %l6
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t108 = load i64, ptr %t107, !tbaa !24
  %t111 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisByte(ptr %v0, ptr %t106, i64 %t108)
  store i1 %t111, ptr %l47
  br label %bb27
bb27:
  %t112 = load i1, ptr %l47, !tbaa !21
  br i1 %t112, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d186, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t113, ptr %l49, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l50, !tbaa !24
  %t116 = load i64, ptr %l50, !tbaa !24
  %t117 = mul i64 %t116, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t117)
  %t119 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  store { i64, ptr } %t120, ptr %l51, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l50, !tbaa !24
  %t126 = mul i64 %t125, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t122, ptr %t124, i64 %t126, i1 false)
  %t127 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t127, ptr %l49, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t129 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t128, 1
  store { i32, { i64, ptr } } %t129, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t130 = getelementptr %"compiler/bindgen:ctype", ptr %l6, i32 0, i32 0
  %t131 = load i32, ptr %t130, !range !{i32 0, i32 7}
  %t133 = trunc i64 2 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/bindgen:ctype", ptr %l6, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t141 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t136, { i64, ptr } %t138)
  store i64 %t141, ptr %l56
  br label %bb33
bb32:
  br label %bb50
bb33:
  %t142 = load i64, ptr %l56, !tbaa !24
  store i64 %t142, ptr %l7, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i64, ptr %l7, !tbaa !24
  %t147 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t143, i64 %t144)
  store i1 %t147, ptr %l59
  br label %bb34
bb34:
  %t148 = load i1, ptr %l59, !tbaa !21
  %t149 = xor i1 %t148, true
  br i1 %t149, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l7, !tbaa !24
  %t155 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s8, ptr %t151, i64 %t152)
  store { i64, ptr } %t155, ptr %l63
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t156 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t157, i64 %t158)
  %t163 = getelementptr i8, ptr %t162, i64 %t158
  call void @olang_textcopy(ptr %t163, ptr %t159, i64 %t160)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t162, 1
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  %t167 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t165, 1
  store { i32, { i64, ptr } } %t167, ptr %rv
  br label %ret
bb38:
  br i1 %a2, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  %t170 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 3
  %t171 = load i1, ptr %t170, !tbaa !21
  br i1 %t171, label %bb41, label %bb42
bb40:
  br label %bb45
bb41:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d188, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb43
bb42:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d189, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb43
bb43:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l7, !tbaa !24
  %t177 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s10, ptr %t173, i64 %t174)
  store { i64, ptr } %t177, ptr %l70
  br label %bb44
bb44:
  %t178 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = add i64 %t180, %t183
  %t185 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t187 = add i64 %t184, %t186
  %t188 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t187)
  call void @olang_textcopy(ptr %t188, ptr %t179, i64 %t180)
  %t189 = getelementptr i8, ptr %t188, i64 %t180
  call void @olang_textcopy(ptr %t189, ptr %t182, i64 %t183)
  %t190 = getelementptr i8, ptr %t189, i64 %t183
  call void @olang_textcopy(ptr %t190, ptr %t185, i64 %t186)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t188, 1
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s7)
  %t194 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t192, 1
  store { i32, { i64, ptr } } %t194, ptr %rv
  br label %ret
bb45:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l72, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i64, ptr %l7, !tbaa !24
  %t200 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s7, ptr %t196, i64 %t197)
  store { i64, ptr } %t200, ptr %l75
  br label %bb46
bb46:
  %t201 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t203 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = add i64 %t202, %t205
  %t207 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t209 = add i64 %t206, %t208
  %t210 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t209)
  call void @olang_textcopy(ptr %t210, ptr %t201, i64 %t202)
  %t211 = getelementptr i8, ptr %t210, i64 %t202
  call void @olang_textcopy(ptr %t211, ptr %t204, i64 %t205)
  %t212 = getelementptr i8, ptr %t211, i64 %t205
  call void @olang_textcopy(ptr %t212, ptr %t207, i64 %t208)
  %t213 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t210, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = extractvalue { i64, ptr } %t214, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t222 = load ptr, ptr %l72, !tbaa !29
  %t224 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s7, ptr %t222, { i64, ptr } %t221)
  store i32 %t224, ptr %l78
  %t225 = icmp ne i32 %t224, 0
  br i1 %t225, label %bb48, label %ok.226, !prof !99
ok.226:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t227 = load i32, ptr %l78, !tbaa !23
  %t228 = lshr i32 %t227, 16
  %t229 = and i32 %t227, 65535
  %t230 = icmp eq i32 %t228, 1
  %t231 = select i1 %t230, i32 1, i32 0
  %t232 = icmp eq i32 %t227, 0
  %t233 = shl i32 %t231, 16
  %t234 = or i32 %t233, %t229
  %t235 = select i1 %t232, i32 0, i32 %t234
  call void @__olang_scope_close(ptr %s7)
  %t237 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t235, 0
  store { i32, { i64, ptr } } %t237, ptr %rv
  br label %ret
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb50:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d193, i32 0, i32 1) }, ptr %l80, !tbaa !27
  %t238 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t238, ptr %l81, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  store i64 %t240, ptr %l82, !tbaa !24
  %t241 = load i64, ptr %l82, !tbaa !24
  %t242 = mul i64 %t241, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t242)
  %t244 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  store { i64, ptr } %t245, ptr %l83, !tbaa !27
  %t246 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = load i64, ptr %l82, !tbaa !24
  %t251 = mul i64 %t250, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t247, ptr %t249, i64 %t251, i1 false)
  %t252 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t252, ptr %l81, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t254 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t253, 1
  store { i32, { i64, ptr } } %t254, ptr %rv
  br label %ret
bb51:
  %t255 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t257 = trunc i64 6 to i32
  %t258 = icmp eq i32 %t255, %t257
  br i1 %t258, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb58
bb54:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t265 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t260, { i64, ptr } %t262)
  store i32 %t265, ptr %l88
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb56, label %ok.267, !prof !99
ok.267:
  br label %bb55
bb55:
  br label %bb57
bb56:
  %t268 = load i32, ptr %l88, !tbaa !23
  %t269 = lshr i32 %t268, 16
  %t270 = and i32 %t268, 65535
  %t271 = icmp eq i32 %t269, 1
  %t272 = select i1 %t271, i32 1, i32 0
  %t273 = icmp eq i32 %t268, 0
  %t274 = shl i32 %t272, 16
  %t275 = or i32 %t274, %t270
  %t276 = select i1 %t273, i32 0, i32 %t275
  %t278 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t276, 0
  store { i32, { i64, ptr } } %t278, ptr %rv
  br label %ret
bb57:
  br label %bb66
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb65
bb61:
  store %olang.scope zeroinitializer, ptr %s14
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s14, ptr %t279, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d194, i32 0, i32 1) })
  store i32 %t281, ptr %l91
  %t282 = icmp ne i32 %t281, 0
  br i1 %t282, label %bb63, label %ok.283, !prof !99
ok.283:
  br label %bb62
bb62:
  br label %bb64
bb63:
  %t284 = load i32, ptr %l91, !tbaa !23
  %t285 = lshr i32 %t284, 16
  %t286 = and i32 %t284, 65535
  %t287 = icmp eq i32 %t285, 1
  %t288 = select i1 %t287, i32 1, i32 0
  %t289 = icmp eq i32 %t284, 0
  %t290 = shl i32 %t288, 16
  %t291 = or i32 %t290, %t286
  %t292 = select i1 %t289, i32 0, i32 %t291
  call void @__olang_scope_close(ptr %s14)
  %t294 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t292, 0
  store { i32, { i64, ptr } } %t294, ptr %rv
  br label %ret
bb64:
  call void @__olang_scope_close(ptr %s14)
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_383dad6bbc51ebc3_b2d1cf432887049f)
  unreachable
bb66:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d195, i32 0, i32 1) }, ptr %l93, !tbaa !27
  %t295 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t295, ptr %l94, !tbaa !27
  %t296 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 0
  store i64 %t297, ptr %l95, !tbaa !24
  %t298 = load i64, ptr %l95, !tbaa !24
  %t299 = mul i64 %t298, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t299)
  %t301 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l96, !tbaa !27
  %t303 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = load i64, ptr %l95, !tbaa !24
  %t308 = mul i64 %t307, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t304, ptr %t306, i64 %t308, i1 false)
  %t309 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t309, ptr %l94, !tbaa !27
  %t310 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t311 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t310, 1
  store { i32, { i64, ptr } } %t311, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewantRecord(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l15 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 5
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:record", ptr %t9, i32 0, i32 8
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/bindgen:gen", ptr %t15, i32 0, i32 1
  %t18 = load i1, ptr %t17, !tbaa !21
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/bindgen:record", ptr %t22, i32 0, i32 6
  %t25 = load i1, ptr %t24, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb6:
  br label %bb10
bb7:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/bindgen:record", ptr %t27, i32 0, i32 2
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i1, ptr %l15, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
bb10:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/bindgen:record", ptr %t33, i32 0, i32 2
  %t36 = load i1, ptr %t35, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/bindgen:record", ptr %t38, i32 0, i32 7
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t41, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d196, i32 0, i32 1) })
  store i1 %t43, ptr %l23
  br label %bb13
bb12:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb13:
  %t44 = load i1, ptr %l23, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load i1, ptr %l20, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewanted(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %rv = alloca i1
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb6
bb2:
  %t7 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 1
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l4, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrapper(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %l23 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca i1
  %l30 = alloca i32
  %l58 = alloca { i64, ptr }
  %l76 = alloca i1
  %l92 = alloca i64
  %l95 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:cFunc", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v1, ptr %s0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l18
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d197, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t11 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t8, { i64, ptr } %t10)
  store i1 %t11, ptr %l21
  br label %bb2
bb2:
  %t12 = load i1, ptr %l21, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s1, ptr %t13, { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d198, i32 0, i32 1) })
  store i32 %t15, ptr %l23
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb6, label %ok.17, !prof !99
ok.17:
  br label %bb5
bb4:
  br label %bb8
bb5:
  br label %bb7
bb6:
  %t18 = load i32, ptr %l23, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t28 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t26, 0
  store { i32, { i64, ptr } } %t28, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = call { i64, ptr } @compiler_2fbindgen_2eresultText(ptr %s0, ptr %s0, { i64, ptr } %t29)
  store { i64, ptr } %t31, ptr %l26
  br label %bb9
bb9:
  %t32 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d199, i32 0, i32 1) })
  store i1 %t35, ptr %l28
  br label %bb10
bb10:
  %t36 = load i1, ptr %l28, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s2, ptr %t37, { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d200, i32 0, i32 1) })
  store i32 %t39, ptr %l30
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb14, label %ok.41, !prof !99
ok.41:
  br label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb15
bb14:
  %t42 = load i32, ptr %l30, !tbaa !23
  %t43 = lshr i32 %t42, 16
  %t44 = and i32 %t42, 65535
  %t45 = icmp eq i32 %t43, 1
  %t46 = select i1 %t45, i32 1, i32 0
  %t47 = icmp eq i32 %t42, 0
  %t48 = shl i32 %t46, 16
  %t49 = or i32 %t48, %t44
  %t50 = select i1 %t47, i32 0, i32 %t49
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t52 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t50, 0
  store { i32, { i64, ptr } } %t52, ptr %rv
  br label %ret
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/bindgen:gen", ptr %t53, i32 0, i32 2
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/bindgen:cFunc", ptr %t57, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t61 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t64 = extractvalue { i64, ptr } %t56, 1
  %t65 = extractvalue { i64, ptr } %t56, 0
  %t66 = add i64 %t62, %t65
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t69 = add i64 %t66, %t68
  %t71 = extractvalue { i64, ptr } %t60, 1
  %t72 = extractvalue { i64, ptr } %t60, 0
  %t73 = add i64 %t69, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t61, i64 %t62)
  %t75 = getelementptr i8, ptr %t74, i64 %t62
  call void @olang_textcopy(ptr %t75, ptr %t64, i64 %t65)
  %t76 = getelementptr i8, ptr %t75, i64 %t65
  call void @olang_textcopy(ptr %t76, ptr %t67, i64 %t68)
  %t77 = getelementptr i8, ptr %t76, i64 %t68
  call void @olang_textcopy(ptr %t77, ptr %t71, i64 %t72)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t74, 1
  %t80 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t80, ptr %lp4
  %t82 = load ptr, ptr %lp4
  store { i64, ptr } %t79, ptr %t82, !tbaa !27
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/bindgen:gen", ptr %t83, i32 0, i32 20
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = load ptr, ptr %lp4
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t86, 1
  %t91 = extractvalue { i64, ptr } %t86, 0
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t94 = add i64 %t91, %t93
  %t96 = extractvalue { i64, ptr } %t88, 1
  %t97 = extractvalue { i64, ptr } %t88, 0
  %t98 = add i64 %t94, %t97
  %t99 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t101 = add i64 %t98, %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t90, i64 %t91)
  %t103 = getelementptr i8, ptr %t102, i64 %t91
  call void @olang_textcopy(ptr %t103, ptr %t92, i64 %t93)
  %t104 = getelementptr i8, ptr %t103, i64 %t93
  call void @olang_textcopy(ptr %t104, ptr %t96, i64 %t97)
  %t105 = getelementptr i8, ptr %t104, i64 %t97
  call void @olang_textcopy(ptr %t105, ptr %t99, i64 %t100)
  %t106 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t102, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = extractvalue { i64, ptr } %t107, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t85, { i64, ptr } %t114)
  br label %bb17
bb17:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/bindgen:cFunc", ptr %t117, i32 0, i32 3
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t124 = icmp eq i64 %t122, 0
  br i1 %t124, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/bindgen:gen", ptr %t126, i32 0, i32 20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t128, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d205, i32 0, i32 1) })
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb21:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr %"compiler/bindgen:cFunc", ptr %t130, i32 0, i32 3
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l7, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t139 = load i64, ptr %l6, !tbaa !24
  %t140 = load i64, ptr %l7, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s7)
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t147 = load i64, ptr %l6, !tbaa !24
  store i64 %t147, ptr %l8, !tbaa !24
  %t149 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t149, ptr %l58, !tbaa !27
  %t150 = load i64, ptr %l6, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %t153, i64 %t150
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !37
  store { i64, ptr } %t155, ptr %l9, !tbaa !27
  %t157 = load i64, ptr %l8, !tbaa !24
  %t159 = icmp sgt i64 %t157, 0
  br i1 %t159, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/bindgen:gen", ptr %t161, i32 0, i32 20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t163, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s8)
  br label %bb29
bb29:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/bindgen:gen", ptr %t165, i32 0, i32 20
  %t168 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t169 = load i64, ptr %l8, !tbaa !24
  %t170 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t173 = extractvalue { i64, ptr } %t168, 1
  %t174 = extractvalue { i64, ptr } %t168, 0
  %t175 = add i64 %t171, %t174
  %t176 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t178 = add i64 %t175, %t177
  %t180 = call i64 @__olang_fmt_i64(ptr null, i64 %t169)
  %t181 = add i64 %t178, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t170, i64 %t171)
  %t183 = getelementptr i8, ptr %t182, i64 %t171
  call void @olang_textcopy(ptr %t183, ptr %t173, i64 %t174)
  %t184 = getelementptr i8, ptr %t183, i64 %t174
  call void @olang_textcopy(ptr %t184, ptr %t176, i64 %t177)
  %t185 = getelementptr i8, ptr %t184, i64 %t177
  %t186 = call i64 @__olang_fmt_i64(ptr %t185, i64 %t169)
  %t187 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t182, 1
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = extractvalue { i64, ptr } %t188, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t167, { i64, ptr } %t195)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb31:
  %t198 = load i64, ptr %l6, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l6, !tbaa !24
  br label %bb22
bb32:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/bindgen:gen", ptr %t202, i32 0, i32 20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t204, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d209, i32 0, i32 1) })
  br label %bb33
bb33:
  %t206 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t208 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t206, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d210, i32 0, i32 1) })
  store i1 %t208, ptr %l76
  br label %bb34
bb34:
  %t209 = load i1, ptr %l76, !tbaa !21
  %t210 = xor i1 %t209, true
  br i1 %t210, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s11
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/bindgen:gen", ptr %t212, i32 0, i32 20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s11, ptr %t214, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d211, i32 0, i32 1) })
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s11)
  br label %bb38
bb38:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/bindgen:gen", ptr %t216, i32 0, i32 20
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = getelementptr %"compiler/bindgen:cFunc", ptr %t219, i32 0, i32 0
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = extractvalue { i64, ptr } %t222, 0
  %t226 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t228 = add i64 %t225, %t227
  %t229 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t228)
  call void @olang_textcopy(ptr %t229, ptr %t224, i64 %t225)
  %t230 = getelementptr i8, ptr %t229, i64 %t225
  call void @olang_textcopy(ptr %t230, ptr %t226, i64 %t227)
  %t231 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t229, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = extractvalue { i64, ptr } %t232, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t218, { i64, ptr } %t239)
  br label %bb39
bb39:
  store i64 0, ptr %l10, !tbaa !24
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr %"compiler/bindgen:cFunc", ptr %t242, i32 0, i32 3
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t245, 0
  store i64 %t247, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t249 = load i64, ptr %l11, !tbaa !24
  %t250 = load i64, ptr %l10, !tbaa !24
  %t253 = icmp sgt i64 %t249, %t250
  br i1 %t253, label %bb40, label %bb41
bb40:
  %t255 = load i64, ptr %l12, !tbaa !24
  %t257 = icmp sgt i64 %t255, 0
  br i1 %t257, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb45
bb42:
  %t259 = load i64, ptr %l11, !tbaa !24
  %t260 = load i64, ptr %l10, !tbaa !24
  %t263 = sub i64 %t259, %t260
  %t264 = load i64, ptr %l12, !tbaa !24
  %t267 = add i64 %t263, %t264
  %t269 = sub i64 %t267, 1
  %t270 = load i64, ptr %l12, !tbaa !24
  %t273 = sdiv i64 %t269, %t270
  store i64 %t273, ptr %l95, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb44
bb44:
  %t275 = load i64, ptr %l95, !tbaa !24
  store i64 %t275, ptr %l92, !tbaa !24
  br label %bb45
bb45:
  %t276 = load i64, ptr %l92, !tbaa !24
  store i64 %t276, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s14
  %t277 = load i64, ptr %l14, !tbaa !24
  %t278 = load i64, ptr %l13, !tbaa !24
  %t281 = icmp slt i64 %t277, %t278
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s14)
  br label %bb56
bb48:
  br label %bb49
bb49:
  %t285 = load i64, ptr %l10, !tbaa !24
  %t286 = load i64, ptr %l14, !tbaa !24
  %t287 = load i64, ptr %l12, !tbaa !24
  %t290 = mul i64 %t286, %t287
  %t293 = add i64 %t285, %t290
  store i64 %t293, ptr %l15, !tbaa !24
  %t295 = load i64, ptr %l15, !tbaa !24
  %t297 = icmp sgt i64 %t295, 0
  br i1 %t297, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s15
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/bindgen:gen", ptr %t299, i32 0, i32 20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s15, ptr %t301, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d213, i32 0, i32 1) })
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s15)
  br label %bb53
bb53:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/bindgen:gen", ptr %t303, i32 0, i32 20
  %t306 = load i64, ptr %l15, !tbaa !24
  %t307 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t308 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t310 = call i64 @__olang_fmt_i64(ptr null, i64 %t306)
  %t311 = add i64 %t308, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t307, i64 %t308)
  %t313 = getelementptr i8, ptr %t312, i64 %t308
  %t314 = call i64 @__olang_fmt_i64(ptr %t313, i64 %t306)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t312, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = extractvalue { i64, ptr } %t316, 1
  %t320 = mul i64 %t318, 1
  %t321 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t319, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s14, ptr %t305, { i64, ptr } %t323)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s14)
  br label %bb55
bb55:
  %t326 = load i64, ptr %l14, !tbaa !24
  %t328 = add i64 %t326, 1
  store i64 %t328, ptr %l14, !tbaa !24
  br label %bb46
bb56:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/bindgen:gen", ptr %t330, i32 0, i32 20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t332, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb57
bb57:
  %t334 = load ptr, ptr %lp4
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t337 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t335, 1
  store { i32, { i64, ptr } } %t337, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/bindgen:cFunc"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/bindgen:cFunc"
  %l9 = alloca i64
  %l10 = alloca %"compiler/bindgen:ctype"
  %l12 = alloca i1
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca %"compiler/bindgen:cFunc"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca i64
  %l46 = alloca i64
  %l48 = alloca i64
  %l53 = alloca %"compiler/bindgen:cFunc"
  %l63 = alloca i64
  %l65 = alloca i64
  %l70 = alloca %"compiler/bindgen:cFunc"
  %l72 = alloca { i64, ptr }
  %l75 = alloca i64
  %l79 = alloca %"compiler/bindgen:ctype"
  %l84 = alloca ptr
  %l88 = alloca %"compiler/bindgen:ctype"
  %l90 = alloca %"compiler/bindgen:ctype"
  %l93 = alloca i1
  %l97 = alloca %"compiler/bindgen:ctype"
  %l100 = alloca ptr
  %l104 = alloca %"compiler/bindgen:ctype"
  %l106 = alloca i64
  %l110 = alloca ptr
  %l116 = alloca %"std/prelude/text:StringBuilder"
  %l117 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l120 = alloca i64
  %l122 = alloca i64
  %l127 = alloca %"compiler/bindgen:cFunc"
  %l131 = alloca i1
  %l137 = alloca i1
  %l148 = alloca i1
  %l155 = alloca i1
  %l165 = alloca i1
  %l169 = alloca i1
  %l175 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca i32
  %l181 = alloca i1
  %l191 = alloca i1
  %l193 = alloca i1
  %l195 = alloca i1
  %l199 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca i32
  %l205 = alloca i1
  %l227 = alloca %"std/prelude/text:StringBuilder"
  %l232 = alloca i64
  %l234 = alloca i64
  %l239 = alloca { i64, ptr }
  %l246 = alloca %"std/prelude/text:StringBuilder"
  %l247 = alloca %"std/prelude/text:StringBuilder"
  %l250 = alloca i64
  %l254 = alloca i64
  %l257 = alloca i64
  %l278 = alloca ptr
  %l281 = alloca i1
  %l282 = alloca i1
  %l285 = alloca i1
  %l289 = alloca i1
  %l290 = alloca ptr
  %l293 = alloca { i64, ptr }
  %l304 = alloca i64
  %l306 = alloca i1
  %l308 = alloca i64
  %l310 = alloca ptr
  %l312 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l317 = alloca ptr
  %l319 = alloca { i64, ptr }
  %l322 = alloca i64
  %l327 = alloca i64
  %l329 = alloca i64
  %l334 = alloca { i64, ptr }
  %l343 = alloca i64
  %l348 = alloca i64
  %l350 = alloca i64
  %l355 = alloca { i64, ptr }
  %l364 = alloca i64
  %l369 = alloca i64
  %l371 = alloca i64
  %l376 = alloca { i64, ptr }
  %l384 = alloca { i64, ptr }
  %l385 = alloca { i64, ptr }
  %l386 = alloca i64
  %l387 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s58 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l46, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l48
  br label %bb2
bb2:
  %t9 = load i64, ptr %l46, !tbaa !24
  %t10 = load i64, ptr %l48, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/bindgen:cFunc" %t19, ptr %l53
  br label %bb6
bb6:
  %t20 = load %"compiler/bindgen:cFunc", ptr %l53
  store %"compiler/bindgen:cFunc" %t20, ptr %l4
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/bindgen:gen", ptr %t21, i32 0, i32 21
  %t24 = getelementptr %"compiler/bindgen:cFunc", ptr %l4, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t23, { i64, ptr } %t38, i64 0)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb1
bb9:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/bindgen:gen", ptr %t45, i32 0, i32 8
  store ptr %t47, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s6
  %t49 = load i64, ptr %l6, !tbaa !24
  store i64 %t49, ptr %l63, !tbaa !24
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l65
  br label %bb11
bb11:
  %t53 = load i64, ptr %l63, !tbaa !24
  %t54 = load i64, ptr %l65, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = call %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store %"compiler/bindgen:cFunc" %t63, ptr %l70
  br label %bb15
bb15:
  %t64 = load %"compiler/bindgen:cFunc", ptr %l70
  store %"compiler/bindgen:cFunc" %t64, ptr %l7
  %t65 = getelementptr %"compiler/bindgen:cFunc", ptr %l7, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t68 = call { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v0, ptr %s6, { i64, ptr } %t66)
  store { i64, ptr } %t68, ptr %l72
  br label %bb16
bb16:
  %t69 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t74 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s6, ptr %t70, { i64, ptr } %t69, i64 0)
  store i64 %t74, ptr %l75
  br label %bb17
bb17:
  %t75 = load i64, ptr %l75, !tbaa !24
  store i64 %t75, ptr %l9, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/bindgen:gen", ptr %t76, i32 0, i32 16
  %t79 = load i64, ptr %l9, !tbaa !24
  %t82 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s6, ptr %t78, i64 %t79)
  store %"compiler/bindgen:ctype" %t82, ptr %l79
  br label %bb18
bb18:
  %t83 = getelementptr %"compiler/bindgen:ctype", ptr %l79, i32 0, i32 0
  %t84 = load i32, ptr %t83, !range !{i32 0, i32 7}
  %t86 = trunc i64 5 to i32
  %t87 = icmp eq i32 %t84, %t86
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb20:
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/bindgen:gen", ptr %t91, i32 0, i32 16
  store ptr %t93, ptr %l84, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/bindgen:gen", ptr %t94, i32 0, i32 16
  %t97 = load i64, ptr %l9, !tbaa !24
  %t100 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s6, ptr %t96, i64 %t97)
  store %"compiler/bindgen:ctype" %t100, ptr %l88
  br label %bb22
bb22:
  %t101 = getelementptr %"compiler/bindgen:ctype", ptr %l88, i32 0, i32 2
  %t102 = load i64, ptr %t101, !tbaa !24
  %t103 = load ptr, ptr %l84, !tbaa !29
  %t105 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t103, i64 %t102)
  store %"compiler/bindgen:ctype" %t105, ptr %l90
  br label %bb23
bb23:
  %t106 = load %"compiler/bindgen:ctype", ptr %l90
  store %"compiler/bindgen:ctype" %t106, ptr %l10
  %t107 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 0
  %t108 = load i32, ptr %t107, !range !{i32 0, i32 7}
  %t110 = trunc i64 3 to i32
  %t111 = icmp eq i32 %t108, %t110
  br i1 %t111, label %bb24, label %bb25
bb24:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/bindgen:gen", ptr %t113, i32 0, i32 16
  %t116 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 2
  %t117 = load i64, ptr %t116, !tbaa !24
  %t120 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s6, ptr %t115, i64 %t117)
  store %"compiler/bindgen:ctype" %t120, ptr %l97
  br label %bb26
bb25:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb27
bb26:
  %t121 = getelementptr %"compiler/bindgen:ctype", ptr %l97, i32 0, i32 0
  %t122 = load i32, ptr %t121, !range !{i32 0, i32 7}
  %t124 = trunc i64 2 to i32
  %t125 = icmp eq i32 %t122, %t124
  store i1 %t125, ptr %l93, !tbaa !21
  br label %bb27
bb27:
  %t127 = load i1, ptr %l93, !tbaa !21
  br i1 %t127, label %bb28, label %bb29
bb28:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l100, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/bindgen:gen", ptr %t129, i32 0, i32 16
  %t132 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 2
  %t133 = load i64, ptr %t132, !tbaa !24
  %t136 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t131, i64 %t133)
  store %"compiler/bindgen:ctype" %t136, ptr %l104
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t137 = getelementptr %"compiler/bindgen:ctype", ptr %l104, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t139 = load ptr, ptr %l100, !tbaa !29
  %t141 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v0, ptr %t139, { i64, ptr } %t138)
  store i64 %t141, ptr %l106
  br label %bb31
bb31:
  %t142 = load i64, ptr %l106, !tbaa !24
  store i1 true, ptr %l12, !tbaa !21
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/bindgen:gen", ptr %t143, i32 0, i32 5
  %t149 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t145, i64 %t142)
  store ptr %t149, ptr %l110
  br label %bb32
bb32:
  %t150 = load ptr, ptr %l110, !tbaa !29
  %t152 = load i1, ptr %l12, !tbaa !21
  %t155 = getelementptr %"compiler/bindgen:record", ptr %t150, i32 0, i32 10
  store i1 %t152, ptr %t155, !tbaa !21
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  %t156 = load i64, ptr %l6, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l6, !tbaa !24
  br label %bb10
bb35:
  %t160 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecords(ptr %v0, ptr %t160)
  br label %bb36
bb36:
  %t162 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t162, ptr %l116
  br label %bb37
bb37:
  %t163 = load %"std/prelude/text:StringBuilder", ptr %l116
  store %"std/prelude/text:StringBuilder" %t163, ptr %l14
  %t164 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t164, ptr %l117
  br label %bb38
bb38:
  %t165 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l117
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t165, ptr %l15
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/bindgen:gen", ptr %t166, i32 0, i32 8
  store ptr %t168, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t170 = load i64, ptr %l17, !tbaa !24
  store i64 %t170, ptr %l120, !tbaa !24
  %t171 = load ptr, ptr %l16, !tbaa !29
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %t171)
  store i64 %t173, ptr %l122
  br label %bb40
bb40:
  %t174 = load i64, ptr %l120, !tbaa !24
  %t175 = load i64, ptr %l122, !tbaa !24
  %t176 = icmp slt i64 %t174, %t175
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s11)
  br label %bb104
bb42:
  br label %bb43
bb43:
  %t180 = load ptr, ptr %l16, !tbaa !29
  %t181 = load i64, ptr %l17, !tbaa !24
  %t184 = call %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t180, i64 %t181)
  store %"compiler/bindgen:cFunc" %t184, ptr %l127
  br label %bb44
bb44:
  %t185 = load %"compiler/bindgen:cFunc", ptr %l127
  store %"compiler/bindgen:cFunc" %t185, ptr %l18
  %t186 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  %t192 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %s0, ptr %v0, ptr %l15, { i64, ptr } %t187)
  store i1 %t192, ptr %l131
  br label %bb45
bb45:
  %t193 = load i1, ptr %l131, !tbaa !21
  br i1 %t193, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb47:
  br label %bb48
bb48:
  %t194 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 1
  %t198 = extractvalue { i64, ptr } %t195, 0
  %t199 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t198)
  call void @olang_textcopy(ptr %t199, ptr %t197, i64 %t198)
  %t200 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } %t201, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } %t208, i64 0)
  br label %bb49
bb49:
  %t211 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  %t214 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t212)
  store i1 %t214, ptr %l137
  br label %bb50
bb50:
  %t215 = load i1, ptr %l137, !tbaa !21
  %t216 = xor i1 %t215, true
  br i1 %t216, label %bb51, label %bb52
bb51:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/bindgen:gen", ptr %t218, i32 0, i32 1
  %t221 = load i1, ptr %t220, !tbaa !21
  %t223 = xor i1 %t221, true
  br i1 %t223, label %bb53, label %bb54
bb52:
  br label %bb57
bb53:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/bindgen:gen", ptr %t225, i32 0, i32 18
  %t228 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 1
  %t232 = extractvalue { i64, ptr } %t229, 0
  %t233 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t235 = add i64 %t232, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t231, i64 %t232)
  %t237 = getelementptr i8, ptr %t236, i64 %t232
  call void @olang_textcopy(ptr %t237, ptr %t233, i64 %t234)
  %t238 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t236, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = extractvalue { i64, ptr } %t239, 1
  %t243 = mul i64 %t241, 1
  %t244 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t243)
  call void @llvm.memcpy.p0.p0.i64(ptr %t244, ptr %t242, i64 %t243, i1 false)
  %t245 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t227, { i64, ptr } %t246)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb57:
  %t249 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  %t252 = call i1 @compiler_2fbindgen_2epreludeName(ptr %v0, { i64, ptr } %t250)
  store i1 %t252, ptr %l148
  br label %bb58
bb58:
  %t253 = load i1, ptr %l148, !tbaa !21
  br i1 %t253, label %bb59, label %bb60
bb59:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/bindgen:gen", ptr %t254, i32 0, i32 18
  %t257 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 1
  %t261 = extractvalue { i64, ptr } %t258, 0
  %t262 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t264 = add i64 %t261, %t263
  %t265 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t264)
  call void @olang_textcopy(ptr %t265, ptr %t260, i64 %t261)
  %t266 = getelementptr i8, ptr %t265, i64 %t261
  call void @olang_textcopy(ptr %t266, ptr %t262, i64 %t263)
  %t267 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t265, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = extractvalue { i64, ptr } %t268, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t256, { i64, ptr } %t275)
  br label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb62:
  %t278 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 4
  %t279 = load i1, ptr %t278, !tbaa !21
  br i1 %t279, label %bb63, label %bb64
bb63:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/bindgen:gen", ptr %t281, i32 0, i32 1
  %t284 = load i1, ptr %t283, !tbaa !21
  %t286 = xor i1 %t284, true
  store i1 %t286, ptr %l155, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb65
bb65:
  %t288 = load i1, ptr %l155, !tbaa !21
  br i1 %t288, label %bb66, label %bb67
bb66:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/bindgen:gen", ptr %t289, i32 0, i32 18
  %t292 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t293, 1
  %t296 = extractvalue { i64, ptr } %t293, 0
  %t297 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t298 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t299 = add i64 %t296, %t298
  %t300 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t299)
  call void @olang_textcopy(ptr %t300, ptr %t295, i64 %t296)
  %t301 = getelementptr i8, ptr %t300, i64 %t296
  call void @olang_textcopy(ptr %t301, ptr %t297, i64 %t298)
  %t302 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t300, 1
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t306 = extractvalue { i64, ptr } %t303, 1
  %t307 = mul i64 %t305, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t307)
  call void @llvm.memcpy.p0.p0.i64(ptr %t308, ptr %t306, i64 %t307, i1 false)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t291, { i64, ptr } %t310)
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb69:
  %t313 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 4
  %t314 = load i1, ptr %t313, !tbaa !21
  br i1 %t314, label %bb70, label %bb71
bb70:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/bindgen:gen", ptr %t316, i32 0, i32 24
  %t319 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t320 = load { i64, ptr }, ptr %t319, !tbaa !27
  %t323 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t318, { i64, ptr } %t320)
  store i1 %t323, ptr %l169
  br label %bb72
bb71:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb73
bb72:
  %t324 = load i1, ptr %l169, !tbaa !21
  store i1 %t324, ptr %l165, !tbaa !21
  br label %bb73
bb73:
  %t325 = load i1, ptr %l165, !tbaa !21
  br i1 %t325, label %bb74, label %bb75
bb74:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/bindgen:gen", ptr %t326, i32 0, i32 18
  %t329 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t330 = load { i64, ptr }, ptr %t329, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t330, 1
  %t333 = extractvalue { i64, ptr } %t330, 0
  %t334 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t335 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t336 = add i64 %t333, %t335
  %t337 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t336)
  call void @olang_textcopy(ptr %t337, ptr %t332, i64 %t333)
  %t338 = getelementptr i8, ptr %t337, i64 %t333
  call void @olang_textcopy(ptr %t338, ptr %t334, i64 %t335)
  %t339 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t337, 1
  %t342 = extractvalue { i64, ptr } %t340, 0
  %t343 = extractvalue { i64, ptr } %t340, 1
  %t344 = mul i64 %t342, 1
  %t345 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t344)
  call void @llvm.memcpy.p0.p0.i64(ptr %t345, ptr %t343, i64 %t344, i1 false)
  %t346 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t345, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t328, { i64, ptr } %t347)
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb77:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t353 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efunction(ptr %v0, ptr %s11, ptr %s11, ptr %t350, ptr %l18)
  %t354 = extractvalue { i32, { i64, ptr } } %t353, 1
  %t355 = extractvalue { i32, { i64, ptr } } %t353, 0
  store i32 %t355, ptr %l179
  %t356 = icmp ne i32 %t355, 0
  br i1 %t356, label %bb79, label %ok.357, !prof !99
ok.357:
  store { i64, ptr } %t354, ptr %l178
  br label %bb78
bb78:
  %t358 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t358, ptr %l175, !tbaa !27
  br label %bb82
bb79:
  %t359 = load i32, ptr %l179, !tbaa !23
  %t360 = ashr i32 %t359, 16
  %t362 = icmp eq i32 %t360, 1
  store i1 %t362, ptr %l181, !tbaa !21
  br label %bb80
bb80:
  call void @__olang_ert_req_clear()
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/bindgen:gen", ptr %t363, i32 0, i32 18
  %t366 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t367 = load { i64, ptr }, ptr %t366, !tbaa !27
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/bindgen:gen", ptr %t368, i32 0, i32 25
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t367, 1
  %t374 = extractvalue { i64, ptr } %t367, 0
  %t375 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t376 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t377 = add i64 %t374, %t376
  %t379 = extractvalue { i64, ptr } %t371, 1
  %t380 = extractvalue { i64, ptr } %t371, 0
  %t381 = add i64 %t377, %t380
  %t382 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t381)
  call void @olang_textcopy(ptr %t382, ptr %t373, i64 %t374)
  %t383 = getelementptr i8, ptr %t382, i64 %t374
  call void @olang_textcopy(ptr %t383, ptr %t375, i64 %t376)
  %t384 = getelementptr i8, ptr %t383, i64 %t376
  call void @olang_textcopy(ptr %t384, ptr %t379, i64 %t380)
  %t385 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t382, 1
  %t388 = extractvalue { i64, ptr } %t386, 0
  %t389 = extractvalue { i64, ptr } %t386, 1
  %t390 = mul i64 %t388, 1
  %t391 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t390)
  call void @llvm.memcpy.p0.p0.i64(ptr %t391, ptr %t389, i64 %t390, i1 false)
  %t392 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t391, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t365, { i64, ptr } %t393)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb82:
  %t396 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t396, ptr %l20, !tbaa !27
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/bindgen:gen", ptr %t397, i32 0, i32 1
  %t400 = load i1, ptr %t399, !tbaa !21
  br i1 %t400, label %bb83, label %bb84
bb83:
  %t402 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 4
  %t403 = load i1, ptr %t402, !tbaa !21
  br i1 %t403, label %bb85, label %bb86
bb84:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb89
bb85:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb88
bb86:
  %t405 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 5
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  %t408 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s11, { i64, ptr } %t406, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d221, i32 0, i32 1) })
  store i1 %t408, ptr %l195
  br label %bb87
bb87:
  %t409 = load i1, ptr %l195, !tbaa !21
  %t410 = xor i1 %t409, true
  store i1 %t410, ptr %l193, !tbaa !21
  br label %bb88
bb88:
  %t412 = load i1, ptr %l193, !tbaa !21
  store i1 %t412, ptr %l191, !tbaa !21
  br label %bb89
bb89:
  %t413 = load i1, ptr %l191, !tbaa !21
  br i1 %t413, label %bb90, label %bb91
bb90:
  %t414 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 5
  %t415 = load { i64, ptr }, ptr %t414, !tbaa !27
  store { i64, ptr } %t415, ptr %l21, !tbaa !27
  %t417 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 4
  %t418 = load i1, ptr %t417, !tbaa !21
  br i1 %t418, label %bb92, label %bb93
bb91:
  br label %bb101
bb92:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t423 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrapper(ptr %v0, ptr %s11, ptr %v0, ptr %t420, ptr %l18)
  %t424 = extractvalue { i32, { i64, ptr } } %t423, 1
  %t425 = extractvalue { i32, { i64, ptr } } %t423, 0
  store i32 %t425, ptr %l203
  %t426 = icmp ne i32 %t425, 0
  br i1 %t426, label %bb95, label %ok.427, !prof !99
ok.427:
  store { i64, ptr } %t424, ptr %l202
  br label %bb94
bb93:
  br label %bb99
bb94:
  %t428 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t428, ptr %l199, !tbaa !27
  br label %bb98
bb95:
  %t429 = load i32, ptr %l203, !tbaa !23
  %t430 = ashr i32 %t429, 16
  %t432 = icmp eq i32 %t430, 1
  store i1 %t432, ptr %l205, !tbaa !21
  br label %bb96
bb96:
  call void @__olang_ert_req_clear()
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/bindgen:gen", ptr %t433, i32 0, i32 18
  %t436 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t437 = load { i64, ptr }, ptr %t436, !tbaa !27
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/bindgen:gen", ptr %t438, i32 0, i32 25
  %t441 = load { i64, ptr }, ptr %t440, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t437, 1
  %t444 = extractvalue { i64, ptr } %t437, 0
  %t445 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t447 = add i64 %t444, %t446
  %t449 = extractvalue { i64, ptr } %t441, 1
  %t450 = extractvalue { i64, ptr } %t441, 0
  %t451 = add i64 %t447, %t450
  %t452 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t451)
  call void @olang_textcopy(ptr %t452, ptr %t443, i64 %t444)
  %t453 = getelementptr i8, ptr %t452, i64 %t444
  call void @olang_textcopy(ptr %t453, ptr %t445, i64 %t446)
  %t454 = getelementptr i8, ptr %t453, i64 %t446
  call void @olang_textcopy(ptr %t454, ptr %t449, i64 %t450)
  %t455 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t456 = insertvalue { i64, ptr } %t455, ptr %t452, 1
  %t458 = extractvalue { i64, ptr } %t456, 0
  %t459 = extractvalue { i64, ptr } %t456, 1
  %t460 = mul i64 %t458, 1
  %t461 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t460)
  call void @llvm.memcpy.p0.p0.i64(ptr %t461, ptr %t459, i64 %t460, i1 false)
  %t462 = insertvalue { i64, ptr } undef, i64 %t458, 0
  %t463 = insertvalue { i64, ptr } %t462, ptr %t461, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t435, { i64, ptr } %t463)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb98:
  %t466 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 0
  %t468 = extractvalue { i64, ptr } %t466, 1
  %t469 = mul i64 %t467, 1
  %t470 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t469)
  call void @llvm.memcpy.p0.p0.i64(ptr %t470, ptr %t468, i64 %t469, i1 false)
  %t471 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t470, 1
  store { i64, ptr } %t472, ptr %l21, !tbaa !27
  br label %bb99
bb99:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t476 = getelementptr %"compiler/bindgen:gen", ptr %t474, i32 0, i32 19
  %t477 = getelementptr %"compiler/bindgen:cFunc", ptr %l18, i32 0, i32 0
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  %t479 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t478, 1
  %t482 = extractvalue { i64, ptr } %t478, 0
  %t483 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t484 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t485 = add i64 %t482, %t484
  %t487 = extractvalue { i64, ptr } %t479, 1
  %t488 = extractvalue { i64, ptr } %t479, 0
  %t489 = add i64 %t485, %t488
  %t490 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t489)
  call void @olang_textcopy(ptr %t490, ptr %t481, i64 %t482)
  %t491 = getelementptr i8, ptr %t490, i64 %t482
  call void @olang_textcopy(ptr %t491, ptr %t483, i64 %t484)
  %t492 = getelementptr i8, ptr %t491, i64 %t484
  call void @olang_textcopy(ptr %t492, ptr %t487, i64 %t488)
  %t493 = insertvalue { i64, ptr } undef, i64 %t489, 0
  %t494 = insertvalue { i64, ptr } %t493, ptr %t490, 1
  %t496 = extractvalue { i64, ptr } %t494, 0
  %t497 = extractvalue { i64, ptr } %t494, 1
  %t498 = mul i64 %t496, 1
  %t499 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t498)
  call void @llvm.memcpy.p0.p0.i64(ptr %t499, ptr %t497, i64 %t498, i1 false)
  %t500 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t499, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t476, { i64, ptr } %t501)
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t504 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t505 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t506 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t508 = extractvalue { i64, ptr } %t504, 1
  %t509 = extractvalue { i64, ptr } %t504, 0
  %t510 = add i64 %t506, %t509
  %t511 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t512 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t513 = add i64 %t510, %t512
  %t514 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t513)
  call void @olang_textcopy(ptr %t514, ptr %t505, i64 %t506)
  %t515 = getelementptr i8, ptr %t514, i64 %t506
  call void @olang_textcopy(ptr %t515, ptr %t508, i64 %t509)
  %t516 = getelementptr i8, ptr %t515, i64 %t509
  call void @olang_textcopy(ptr %t516, ptr %t511, i64 %t512)
  %t517 = insertvalue { i64, ptr } undef, i64 %t513, 0
  %t518 = insertvalue { i64, ptr } %t517, ptr %t514, 1
  %t520 = extractvalue { i64, ptr } %t518, 0
  %t521 = extractvalue { i64, ptr } %t518, 1
  %t522 = mul i64 %t520, 1
  %t523 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t522)
  call void @llvm.memcpy.p0.p0.i64(ptr %t523, ptr %t521, i64 %t522, i1 false)
  %t524 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t525 = insertvalue { i64, ptr } %t524, ptr %t523, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %l14, { i64, ptr } %t525)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb103:
  %t528 = load i64, ptr %l17, !tbaa !24
  %t530 = add i64 %t528, 1
  store i64 %t530, ptr %l17, !tbaa !24
  br label %bb39
bb104:
  %t532 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emacroFns(ptr %v0, ptr %t532)
  br label %bb105
bb105:
  %t534 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t534, ptr %l227
  br label %bb106
bb106:
  %t535 = load %"std/prelude/text:StringBuilder", ptr %l227
  store %"std/prelude/text:StringBuilder" %t535, ptr %l22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %l22, { i64, ptr } %a1)
  br label %bb107
bb107:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t541 = getelementptr %"compiler/bindgen:gen", ptr %t539, i32 0, i32 19
  store ptr %t541, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb108
bb108:
  store %olang.scope zeroinitializer, ptr %s33
  %t543 = load i64, ptr %l24, !tbaa !24
  store i64 %t543, ptr %l232, !tbaa !24
  %t544 = load ptr, ptr %l23, !tbaa !29
  %t546 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t544)
  store i64 %t546, ptr %l234
  br label %bb109
bb109:
  %t547 = load i64, ptr %l232, !tbaa !24
  %t548 = load i64, ptr %l234, !tbaa !24
  %t549 = icmp slt i64 %t547, %t548
  %t551 = xor i1 %t549, true
  br i1 %t551, label %bb110, label %bb111
bb110:
  call void @__olang_scope_close(ptr %s33)
  br label %bb116
bb111:
  br label %bb112
bb112:
  %t553 = load ptr, ptr %l23, !tbaa !29
  %t554 = load i64, ptr %l24, !tbaa !24
  %t557 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t553, i64 %t554)
  store { i64, ptr } %t557, ptr %l239
  br label %bb113
bb113:
  %t558 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t560 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t561 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t563 = extractvalue { i64, ptr } %t558, 1
  %t564 = extractvalue { i64, ptr } %t558, 0
  %t565 = add i64 %t561, %t564
  %t566 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t567 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t568 = add i64 %t565, %t567
  %t569 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t568)
  call void @olang_textcopy(ptr %t569, ptr %t560, i64 %t561)
  %t570 = getelementptr i8, ptr %t569, i64 %t561
  call void @olang_textcopy(ptr %t570, ptr %t563, i64 %t564)
  %t571 = getelementptr i8, ptr %t570, i64 %t564
  call void @olang_textcopy(ptr %t571, ptr %t566, i64 %t567)
  %t572 = insertvalue { i64, ptr } undef, i64 %t568, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t569, 1
  %t575 = extractvalue { i64, ptr } %t573, 0
  %t576 = extractvalue { i64, ptr } %t573, 1
  %t577 = mul i64 %t575, 1
  %t578 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t577)
  call void @llvm.memcpy.p0.p0.i64(ptr %t578, ptr %t576, i64 %t577, i1 false)
  %t579 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t578, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s33, ptr %l22, { i64, ptr } %t580)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s33)
  br label %bb115
bb115:
  %t583 = load i64, ptr %l24, !tbaa !24
  %t585 = add i64 %t583, 1
  store i64 %t585, ptr %l24, !tbaa !24
  br label %bb108
bb116:
  %t587 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t587, ptr %l246
  br label %bb117
bb117:
  %t588 = load %"std/prelude/text:StringBuilder", ptr %l246
  store %"std/prelude/text:StringBuilder" %t588, ptr %l26
  %t589 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t589, ptr %l247
  br label %bb118
bb118:
  %t590 = load %"std/prelude/text:StringBuilder", ptr %l247
  store %"std/prelude/text:StringBuilder" %t590, ptr %l27
  store i64 0, ptr %l28, !tbaa !24
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t593 = getelementptr %"compiler/bindgen:gen", ptr %t591, i32 0, i32 5
  %t595 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t593)
  store i64 %t595, ptr %l250
  br label %bb119
bb119:
  %t596 = load i64, ptr %l250, !tbaa !24
  store i64 %t596, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t597 = load i64, ptr %l29, !tbaa !24
  %t598 = load i64, ptr %l28, !tbaa !24
  %t601 = icmp sgt i64 %t597, %t598
  br i1 %t601, label %bb120, label %bb121
bb120:
  %t603 = load i64, ptr %l30, !tbaa !24
  %t605 = icmp sgt i64 %t603, 0
  br i1 %t605, label %bb122, label %bb123
bb121:
  store i64 0, ptr %l254, !tbaa !24
  br label %bb125
bb122:
  %t607 = load i64, ptr %l29, !tbaa !24
  %t608 = load i64, ptr %l28, !tbaa !24
  %t611 = sub i64 %t607, %t608
  %t612 = load i64, ptr %l30, !tbaa !24
  %t615 = add i64 %t611, %t612
  %t617 = sub i64 %t615, 1
  %t618 = load i64, ptr %l30, !tbaa !24
  %t621 = sdiv i64 %t617, %t618
  store i64 %t621, ptr %l257, !tbaa !24
  br label %bb124
bb123:
  store i64 0, ptr %l257, !tbaa !24
  br label %bb124
bb124:
  %t623 = load i64, ptr %l257, !tbaa !24
  store i64 %t623, ptr %l254, !tbaa !24
  br label %bb125
bb125:
  %t624 = load i64, ptr %l254, !tbaa !24
  store i64 %t624, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb126
bb126:
  store %olang.scope zeroinitializer, ptr %s37
  %t625 = load i64, ptr %l32, !tbaa !24
  %t626 = load i64, ptr %l31, !tbaa !24
  %t629 = icmp slt i64 %t625, %t626
  %t631 = xor i1 %t629, true
  br i1 %t631, label %bb127, label %bb128
bb127:
  call void @__olang_scope_close(ptr %s37)
  br label %bb147
bb128:
  br label %bb129
bb129:
  %t633 = load i64, ptr %l28, !tbaa !24
  %t634 = load i64, ptr %l32, !tbaa !24
  %t635 = load i64, ptr %l30, !tbaa !24
  %t638 = mul i64 %t634, %t635
  %t641 = add i64 %t633, %t638
  store i64 %t641, ptr %l33, !tbaa !24
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t645 = getelementptr %"compiler/bindgen:gen", ptr %t643, i32 0, i32 5
  %t646 = load i64, ptr %l33, !tbaa !24
  %t649 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t645, i64 %t646)
  store ptr %t649, ptr %l278
  br label %bb130
bb130:
  %t650 = load ptr, ptr %l278, !tbaa !29
  store ptr %t650, ptr %l34, !tbaa !29
  %t651 = load ptr, ptr %l34, !tbaa !29
  %t653 = getelementptr %"compiler/bindgen:record", ptr %t651, i32 0, i32 7
  %t654 = load { i64, ptr }, ptr %t653, !tbaa !27
  %t656 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s37, { i64, ptr } %t654, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d228, i32 0, i32 1) })
  store i1 %t656, ptr %l281
  br label %bb131
bb131:
  %t657 = load i1, ptr %l281, !tbaa !21
  br i1 %t657, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l282, !tbaa !21
  br label %bb135
bb133:
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t659 = load i64, ptr %l33, !tbaa !24
  %t662 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewantRecord(ptr %v0, ptr %t658, i64 %t659)
  store i1 %t662, ptr %l285
  br label %bb134
bb134:
  %t663 = load i1, ptr %l285, !tbaa !21
  %t664 = xor i1 %t663, true
  store i1 %t664, ptr %l282, !tbaa !21
  br label %bb135
bb135:
  %t666 = load i1, ptr %l282, !tbaa !21
  br i1 %t666, label %bb136, label %bb137
bb136:
  call void @__olang_scope_close(ptr %s37)
  br label %bb146
bb137:
  br label %bb138
bb138:
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t668 = load i64, ptr %l33, !tbaa !24
  %t671 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t667, i64 %t668)
  store i1 %t671, ptr %l289
  br label %bb139
bb139:
  %t672 = load i1, ptr %l289, !tbaa !21
  br i1 %t672, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s39
  store ptr %l27, ptr %l290, !tbaa !29
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t674 = load i64, ptr %l33, !tbaa !24
  %t677 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2estructDecl(ptr %v0, ptr %s39, ptr %t673, i64 %t674)
  store { i64, ptr } %t677, ptr %l293
  br label %bb142
bb141:
  store %olang.scope zeroinitializer, ptr %s41
  %t678 = load ptr, ptr %l34, !tbaa !29
  %t680 = getelementptr %"compiler/bindgen:record", ptr %t678, i32 0, i32 7
  %t681 = load { i64, ptr }, ptr %t680, !tbaa !27
  %t682 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t683 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t685 = extractvalue { i64, ptr } %t681, 1
  %t686 = extractvalue { i64, ptr } %t681, 0
  %t687 = add i64 %t683, %t686
  %t688 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t689 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t690 = add i64 %t687, %t689
  %t691 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t690)
  call void @olang_textcopy(ptr %t691, ptr %t682, i64 %t683)
  %t692 = getelementptr i8, ptr %t691, i64 %t683
  call void @olang_textcopy(ptr %t692, ptr %t685, i64 %t686)
  %t693 = getelementptr i8, ptr %t692, i64 %t686
  call void @olang_textcopy(ptr %t693, ptr %t688, i64 %t689)
  %t694 = insertvalue { i64, ptr } undef, i64 %t690, 0
  %t695 = insertvalue { i64, ptr } %t694, ptr %t691, 1
  %t697 = extractvalue { i64, ptr } %t695, 0
  %t698 = extractvalue { i64, ptr } %t695, 1
  %t699 = mul i64 %t697, 1
  %t700 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t699)
  call void @llvm.memcpy.p0.p0.i64(ptr %t700, ptr %t698, i64 %t699, i1 false)
  %t701 = insertvalue { i64, ptr } undef, i64 %t697, 0
  %t702 = insertvalue { i64, ptr } %t701, ptr %t700, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s41, ptr %l26, { i64, ptr } %t702)
  br label %bb144
bb142:
  %t705 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t706 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t707 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t708 = extractvalue { i64, ptr } %t707, 1
  %t709 = extractvalue { i64, ptr } %t707, 0
  %t710 = add i64 %t706, %t709
  %t711 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t710)
  call void @olang_textcopy(ptr %t711, ptr %t705, i64 %t706)
  %t712 = getelementptr i8, ptr %t711, i64 %t706
  call void @olang_textcopy(ptr %t712, ptr %t708, i64 %t709)
  %t713 = insertvalue { i64, ptr } undef, i64 %t710, 0
  %t714 = insertvalue { i64, ptr } %t713, ptr %t711, 1
  %t716 = extractvalue { i64, ptr } %t714, 0
  %t717 = extractvalue { i64, ptr } %t714, 1
  %t718 = mul i64 %t716, 1
  %t719 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t718)
  call void @llvm.memcpy.p0.p0.i64(ptr %t719, ptr %t717, i64 %t718, i1 false)
  %t720 = insertvalue { i64, ptr } undef, i64 %t716, 0
  %t721 = insertvalue { i64, ptr } %t720, ptr %t719, 1
  %t722 = load ptr, ptr %l290, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %t722, { i64, ptr } %t721)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s39)
  br label %bb145
bb144:
  call void @__olang_scope_close(ptr %s41)
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s37)
  br label %bb146
bb146:
  %t724 = load i64, ptr %l32, !tbaa !24
  %t726 = add i64 %t724, 1
  store i64 %t726, ptr %l32, !tbaa !24
  br label %bb126
bb147:
  %t729 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l26)
  store i64 %t729, ptr %l304
  br label %bb148
bb148:
  %t730 = load i64, ptr %l304, !tbaa !24
  %t731 = icmp sgt i64 %t730, 0
  br i1 %t731, label %bb149, label %bb150
bb149:
  store i1 true, ptr %l306, !tbaa !21
  br label %bb152
bb150:
  %t734 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l14)
  store i64 %t734, ptr %l308
  br label %bb151
bb151:
  %t735 = load i64, ptr %l308, !tbaa !24
  %t736 = icmp sgt i64 %t735, 0
  store i1 %t736, ptr %l306, !tbaa !21
  br label %bb152
bb152:
  %t738 = load i1, ptr %l306, !tbaa !21
  br i1 %t738, label %bb153, label %bb154
bb153:
  store %olang.scope zeroinitializer, ptr %s44
  store ptr %l22, ptr %l310, !tbaa !29
  %t740 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s44, ptr %l26)
  store { i64, ptr } %t740, ptr %l312
  br label %bb155
bb154:
  br label %bb158
bb155:
  %t742 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s44, ptr %l14)
  store { i64, ptr } %t742, ptr %l314
  br label %bb156
bb156:
  %t743 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t744 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t745 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t746 = extractvalue { i64, ptr } %t745, 1
  %t747 = extractvalue { i64, ptr } %t745, 0
  %t748 = add i64 %t744, %t747
  %t749 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t750 = extractvalue { i64, ptr } %t749, 1
  %t751 = extractvalue { i64, ptr } %t749, 0
  %t752 = add i64 %t748, %t751
  %t753 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t754 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t755 = add i64 %t752, %t754
  %t756 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t755)
  call void @olang_textcopy(ptr %t756, ptr %t743, i64 %t744)
  %t757 = getelementptr i8, ptr %t756, i64 %t744
  call void @olang_textcopy(ptr %t757, ptr %t746, i64 %t747)
  %t758 = getelementptr i8, ptr %t757, i64 %t747
  call void @olang_textcopy(ptr %t758, ptr %t750, i64 %t751)
  %t759 = getelementptr i8, ptr %t758, i64 %t751
  call void @olang_textcopy(ptr %t759, ptr %t753, i64 %t754)
  %t760 = insertvalue { i64, ptr } undef, i64 %t755, 0
  %t761 = insertvalue { i64, ptr } %t760, ptr %t756, 1
  %t763 = extractvalue { i64, ptr } %t761, 0
  %t764 = extractvalue { i64, ptr } %t761, 1
  %t765 = mul i64 %t763, 1
  %t766 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t765)
  call void @llvm.memcpy.p0.p0.i64(ptr %t766, ptr %t764, i64 %t765, i1 false)
  %t767 = insertvalue { i64, ptr } undef, i64 %t763, 0
  %t768 = insertvalue { i64, ptr } %t767, ptr %t766, 1
  %t769 = load ptr, ptr %l310, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s44, ptr %t769, { i64, ptr } %t768)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s44)
  br label %bb158
bb158:
  store ptr %l22, ptr %l317, !tbaa !29
  %t772 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l27)
  store { i64, ptr } %t772, ptr %l319
  br label %bb159
bb159:
  %t773 = load ptr, ptr %l317, !tbaa !29
  %t774 = load { i64, ptr }, ptr %l319, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t773, { i64, ptr } %t774)
  br label %bb160
bb160:
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t777 = getelementptr %"compiler/bindgen:gen", ptr %t775, i32 0, i32 9
  %t779 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t777)
  store i64 %t779, ptr %l322
  br label %bb161
bb161:
  %t780 = load i64, ptr %l322, !tbaa !24
  %t781 = icmp sgt i64 %t780, 0
  br i1 %t781, label %bb162, label %bb163
bb162:
  store %olang.scope zeroinitializer, ptr %s46
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s46, ptr %l22, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d234, i32 0, i32 1) })
  br label %bb164
bb163:
  br label %bb174
bb164:
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t786 = getelementptr %"compiler/bindgen:gen", ptr %t784, i32 0, i32 9
  store ptr %t786, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb165
bb165:
  store %olang.scope zeroinitializer, ptr %s48
  %t788 = load i64, ptr %l36, !tbaa !24
  store i64 %t788, ptr %l327, !tbaa !24
  %t789 = load ptr, ptr %l35, !tbaa !29
  %t791 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t789)
  store i64 %t791, ptr %l329
  br label %bb166
bb166:
  %t792 = load i64, ptr %l327, !tbaa !24
  %t793 = load i64, ptr %l329, !tbaa !24
  %t794 = icmp slt i64 %t792, %t793
  %t796 = xor i1 %t794, true
  br i1 %t796, label %bb167, label %bb168
bb167:
  call void @__olang_scope_close(ptr %s48)
  br label %bb173
bb168:
  br label %bb169
bb169:
  %t798 = load ptr, ptr %l35, !tbaa !29
  %t799 = load i64, ptr %l36, !tbaa !24
  %t802 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t798, i64 %t799)
  store { i64, ptr } %t802, ptr %l334
  br label %bb170
bb170:
  %t803 = load { i64, ptr }, ptr %l334, !tbaa !27
  %t806 = extractvalue { i64, ptr } %t803, 1
  %t807 = extractvalue { i64, ptr } %t803, 0
  %t808 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t809 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t810 = add i64 %t807, %t809
  %t811 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t810)
  call void @olang_textcopy(ptr %t811, ptr %t806, i64 %t807)
  %t812 = getelementptr i8, ptr %t811, i64 %t807
  call void @olang_textcopy(ptr %t812, ptr %t808, i64 %t809)
  %t813 = insertvalue { i64, ptr } undef, i64 %t810, 0
  %t814 = insertvalue { i64, ptr } %t813, ptr %t811, 1
  %t816 = extractvalue { i64, ptr } %t814, 0
  %t817 = extractvalue { i64, ptr } %t814, 1
  %t818 = mul i64 %t816, 1
  %t819 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t818)
  call void @llvm.memcpy.p0.p0.i64(ptr %t819, ptr %t817, i64 %t818, i1 false)
  %t820 = insertvalue { i64, ptr } undef, i64 %t816, 0
  %t821 = insertvalue { i64, ptr } %t820, ptr %t819, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s48, ptr %l22, { i64, ptr } %t821)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s48)
  br label %bb172
bb172:
  %t824 = load i64, ptr %l36, !tbaa !24
  %t826 = add i64 %t824, 1
  store i64 %t826, ptr %l36, !tbaa !24
  br label %bb165
bb173:
  call void @__olang_scope_close(ptr %s46)
  br label %bb174
bb174:
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t830 = getelementptr %"compiler/bindgen:gen", ptr %t828, i32 0, i32 14
  %t832 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t830)
  store i64 %t832, ptr %l343
  br label %bb175
bb175:
  %t833 = load i64, ptr %l343, !tbaa !24
  %t834 = icmp sgt i64 %t833, 0
  br i1 %t834, label %bb176, label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s51
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s51, ptr %l22, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d236, i32 0, i32 1) })
  br label %bb178
bb177:
  br label %bb188
bb178:
  %t837 = load ptr, ptr %l0, !tbaa !29
  %t839 = getelementptr %"compiler/bindgen:gen", ptr %t837, i32 0, i32 14
  store ptr %t839, ptr %l38, !tbaa !29
  store i64 0, ptr %l39, !tbaa !24
  br label %bb179
bb179:
  store %olang.scope zeroinitializer, ptr %s53
  %t841 = load i64, ptr %l39, !tbaa !24
  store i64 %t841, ptr %l348, !tbaa !24
  %t842 = load ptr, ptr %l38, !tbaa !29
  %t844 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t842)
  store i64 %t844, ptr %l350
  br label %bb180
bb180:
  %t845 = load i64, ptr %l348, !tbaa !24
  %t846 = load i64, ptr %l350, !tbaa !24
  %t847 = icmp slt i64 %t845, %t846
  %t849 = xor i1 %t847, true
  br i1 %t849, label %bb181, label %bb182
bb181:
  call void @__olang_scope_close(ptr %s53)
  br label %bb187
bb182:
  br label %bb183
bb183:
  %t851 = load ptr, ptr %l38, !tbaa !29
  %t852 = load i64, ptr %l39, !tbaa !24
  %t855 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t851, i64 %t852)
  store { i64, ptr } %t855, ptr %l355
  br label %bb184
bb184:
  %t856 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t859 = extractvalue { i64, ptr } %t856, 1
  %t860 = extractvalue { i64, ptr } %t856, 0
  %t861 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t862 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t863 = add i64 %t860, %t862
  %t864 = call ptr @__olang_scope_alloc(ptr %s53, i64 %t863)
  call void @olang_textcopy(ptr %t864, ptr %t859, i64 %t860)
  %t865 = getelementptr i8, ptr %t864, i64 %t860
  call void @olang_textcopy(ptr %t865, ptr %t861, i64 %t862)
  %t866 = insertvalue { i64, ptr } undef, i64 %t863, 0
  %t867 = insertvalue { i64, ptr } %t866, ptr %t864, 1
  %t869 = extractvalue { i64, ptr } %t867, 0
  %t870 = extractvalue { i64, ptr } %t867, 1
  %t871 = mul i64 %t869, 1
  %t872 = call ptr @__olang_scope_alloc(ptr %s53, i64 %t871)
  call void @llvm.memcpy.p0.p0.i64(ptr %t872, ptr %t870, i64 %t871, i1 false)
  %t873 = insertvalue { i64, ptr } undef, i64 %t869, 0
  %t874 = insertvalue { i64, ptr } %t873, ptr %t872, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s53, ptr %l22, { i64, ptr } %t874)
  br label %bb185
bb185:
  call void @__olang_scope_close(ptr %s53)
  br label %bb186
bb186:
  %t877 = load i64, ptr %l39, !tbaa !24
  %t879 = add i64 %t877, 1
  store i64 %t879, ptr %l39, !tbaa !24
  br label %bb179
bb187:
  call void @__olang_scope_close(ptr %s51)
  br label %bb188
bb188:
  %t881 = load ptr, ptr %l0, !tbaa !29
  %t883 = getelementptr %"compiler/bindgen:gen", ptr %t881, i32 0, i32 18
  %t885 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t883)
  store i64 %t885, ptr %l364
  br label %bb189
bb189:
  %t886 = load i64, ptr %l364, !tbaa !24
  %t887 = icmp sgt i64 %t886, 0
  br i1 %t887, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s56
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s56, ptr %l22, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d238, i32 0, i32 1) })
  br label %bb192
bb191:
  br label %bb202
bb192:
  %t890 = load ptr, ptr %l0, !tbaa !29
  %t892 = getelementptr %"compiler/bindgen:gen", ptr %t890, i32 0, i32 18
  store ptr %t892, ptr %l41, !tbaa !29
  store i64 0, ptr %l42, !tbaa !24
  br label %bb193
bb193:
  store %olang.scope zeroinitializer, ptr %s58
  %t894 = load i64, ptr %l42, !tbaa !24
  store i64 %t894, ptr %l369, !tbaa !24
  %t895 = load ptr, ptr %l41, !tbaa !29
  %t897 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t895)
  store i64 %t897, ptr %l371
  br label %bb194
bb194:
  %t898 = load i64, ptr %l369, !tbaa !24
  %t899 = load i64, ptr %l371, !tbaa !24
  %t900 = icmp slt i64 %t898, %t899
  %t902 = xor i1 %t900, true
  br i1 %t902, label %bb195, label %bb196
bb195:
  call void @__olang_scope_close(ptr %s58)
  br label %bb201
bb196:
  br label %bb197
bb197:
  %t904 = load ptr, ptr %l41, !tbaa !29
  %t905 = load i64, ptr %l42, !tbaa !24
  %t908 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t904, i64 %t905)
  store { i64, ptr } %t908, ptr %l376
  br label %bb198
bb198:
  %t909 = load { i64, ptr }, ptr %l376, !tbaa !27
  %t911 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t912 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t914 = extractvalue { i64, ptr } %t909, 1
  %t915 = extractvalue { i64, ptr } %t909, 0
  %t916 = add i64 %t912, %t915
  %t917 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t918 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t919 = add i64 %t916, %t918
  %t920 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t919)
  call void @olang_textcopy(ptr %t920, ptr %t911, i64 %t912)
  %t921 = getelementptr i8, ptr %t920, i64 %t912
  call void @olang_textcopy(ptr %t921, ptr %t914, i64 %t915)
  %t922 = getelementptr i8, ptr %t921, i64 %t915
  call void @olang_textcopy(ptr %t922, ptr %t917, i64 %t918)
  %t923 = insertvalue { i64, ptr } undef, i64 %t919, 0
  %t924 = insertvalue { i64, ptr } %t923, ptr %t920, 1
  %t926 = extractvalue { i64, ptr } %t924, 0
  %t927 = extractvalue { i64, ptr } %t924, 1
  %t928 = mul i64 %t926, 1
  %t929 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t928)
  call void @llvm.memcpy.p0.p0.i64(ptr %t929, ptr %t927, i64 %t928, i1 false)
  %t930 = insertvalue { i64, ptr } undef, i64 %t926, 0
  %t931 = insertvalue { i64, ptr } %t930, ptr %t929, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s58, ptr %l22, { i64, ptr } %t931)
  br label %bb199
bb199:
  call void @__olang_scope_close(ptr %s58)
  br label %bb200
bb200:
  %t934 = load i64, ptr %l42, !tbaa !24
  %t936 = add i64 %t934, 1
  store i64 %t936, ptr %l42, !tbaa !24
  br label %bb193
bb201:
  call void @__olang_scope_close(ptr %s56)
  br label %bb202
bb202:
  %t939 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l22)
  store { i64, ptr } %t939, ptr %l384
  br label %bb203
bb203:
  %t940 = load { i64, ptr }, ptr %l384, !tbaa !27
  store { i64, ptr } %t940, ptr %l385, !tbaa !27
  %t941 = load { i64, ptr }, ptr %l385, !tbaa !27
  %t942 = extractvalue { i64, ptr } %t941, 0
  store i64 %t942, ptr %l386, !tbaa !24
  %t943 = load i64, ptr %l386, !tbaa !24
  %t944 = mul i64 %t943, 1
  %t945 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t944)
  %t946 = insertvalue { i64, ptr } undef, i64 %t943, 0
  %t947 = insertvalue { i64, ptr } %t946, ptr %t945, 1
  store { i64, ptr } %t947, ptr %l387, !tbaa !27
  %t948 = getelementptr { i64, ptr }, ptr %l387, i32 0, i32 1
  %t949 = load ptr, ptr %t948, !tbaa !27
  %t950 = getelementptr { i64, ptr }, ptr %l385, i32 0, i32 1
  %t951 = load ptr, ptr %t950, !tbaa !27
  %t952 = load i64, ptr %l386, !tbaa !24
  %t953 = mul i64 %t952, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t949, ptr %t951, i64 %t953, i1 false)
  %t954 = load { i64, ptr }, ptr %l387, !tbaa !27
  store { i64, ptr } %t954, ptr %l385, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t955 = load { i64, ptr }, ptr %l385, !tbaa !27
  store { i64, ptr } %t955, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ectokens(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store i64 0, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t11 = icmp slt i64 %t5, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb57
bb4:
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l3, !tbaa !22
  %t23 = load i8, ptr %l3, !tbaa !22
  %t25 = icmp eq i8 %t23, 32
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb56
bb7:
  br label %bb8
bb8:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l4, !tbaa !24
  %t35 = load i8, ptr %l3, !tbaa !22
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t35)
  store i1 %t37, ptr %l21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb13
bb11:
  %t39 = load i8, ptr %l3, !tbaa !22
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t39)
  store i1 %t41, ptr %l24
  br label %bb12
bb12:
  %t42 = load i1, ptr %l24, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb16
bb15:
  %t44 = load i8, ptr %l3, !tbaa !22
  %t46 = icmp eq i8 %t44, 95
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  %t49 = load i8, ptr %l3, !tbaa !22
  %t51 = icmp eq i8 %t49, 46
  br i1 %t51, label %bb36, label %bb37
bb19:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t59 = icmp slt i64 %t53, %t56
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  %t62 = load i64, ptr %l4, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i8, ptr %t65, i64 %t62
  %t67 = load i8, ptr %t66, !tbaa !32
  %t69 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t67)
  store i1 %t69, ptr %l36
  br label %bb22
bb21:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb30
bb22:
  %t70 = load i1, ptr %l36, !tbaa !21
  br i1 %t70, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb26
bb24:
  %t71 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t71, ptr %l38, !tbaa !27
  %t72 = load i64, ptr %l4, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i8, ptr %t75, i64 %t72
  %t77 = load i8, ptr %t76, !tbaa !32
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t77)
  store i1 %t79, ptr %l41
  br label %bb25
bb25:
  %t80 = load i1, ptr %l41, !tbaa !21
  store i1 %t80, ptr %l37, !tbaa !21
  br label %bb26
bb26:
  %t81 = load i1, ptr %l37, !tbaa !21
  br i1 %t81, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb29
bb28:
  %t82 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t82, ptr %l43, !tbaa !27
  %t83 = load i64, ptr %l4, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i8, ptr %t86, i64 %t83
  %t88 = load i8, ptr %t87, !tbaa !32
  %t90 = icmp eq i8 %t88, 95
  store i1 %t90, ptr %l42, !tbaa !21
  br label %bb29
bb29:
  %t92 = load i1, ptr %l42, !tbaa !21
  store i1 %t92, ptr %l32, !tbaa !21
  br label %bb30
bb30:
  %t93 = load i1, ptr %l32, !tbaa !21
  %t94 = xor i1 %t93, true
  br i1 %t94, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l4, !tbaa !24
  br label %bb34
bb34:
  br label %bb19
bb35:
  br label %bb48
bb36:
  br label %bb38
bb37:
  br label %bb47
bb38:
  %t100 = load i64, ptr %l4, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t106 = icmp slt i64 %t100, %t103
  br i1 %t106, label %bb39, label %bb40
bb39:
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t108, ptr %l57, !tbaa !27
  %t109 = load i64, ptr %l4, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 %t109
  %t114 = load i8, ptr %t113, !tbaa !32
  %t116 = icmp eq i8 %t114, 46
  store i1 %t116, ptr %l56, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb41
bb41:
  %t118 = load i1, ptr %l56, !tbaa !21
  %t119 = xor i1 %t118, true
  br i1 %t119, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb44
bb44:
  %t121 = load i64, ptr %l4, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l4, !tbaa !24
  br label %bb45
bb45:
  br label %bb38
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t125 = load ptr, ptr %lp1
  store ptr %t125, ptr %l64, !tbaa !29
  %t126 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t126, ptr %l65, !tbaa !27
  %t127 = load i64, ptr %l2, !tbaa !24
  store i64 %t127, ptr %l66, !tbaa !24
  %t128 = load i64, ptr %l4, !tbaa !24
  store i64 %t128, ptr %l67, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  store i64 %t130, ptr %l68, !tbaa !24
  %t131 = load i64, ptr %l66, !tbaa !24
  %t132 = icmp sge i64 %t131, 0
  br i1 %t132, label %bb49, label %bb50
bb49:
  %t134 = load i64, ptr %l66, !tbaa !24
  %t135 = load i64, ptr %l67, !tbaa !24
  %t136 = icmp sle i64 %t134, %t135
  br i1 %t136, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2)
  unreachable
bb51:
  %t138 = load i64, ptr %l67, !tbaa !24
  %t139 = load i64, ptr %l68, !tbaa !24
  %t140 = icmp sle i64 %t138, %t139
  br i1 %t140, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2)
  unreachable
bb53:
  %t142 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l66, !tbaa !24
  %t145 = load i64, ptr %l67, !tbaa !24
  %t146 = getelementptr i8, ptr %t143, i64 %t144
  %t147 = sub i64 %t145, %t144
  %t148 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t146, 1
  %t151 = extractvalue { i64, ptr } %t149, 1
  %t152 = extractvalue { i64, ptr } %t149, 0
  %t153 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t151, i64 %t152)
  %t154 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t163, { i64, ptr } %t162)
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2)
  unreachable
bb55:
  %t165 = load i64, ptr %l4, !tbaa !24
  store i64 %t165, ptr %l2, !tbaa !24
  br label %bb56
bb56:
  br label %bb2
bb57:
  %t167 = load ptr, ptr %lp1
  %t169 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t167)
  store { i64, ptr } %t169, ptr %l77
  br label %bb58
bb58:
  %t170 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t170, ptr %l78, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  store i64 %t172, ptr %l79, !tbaa !24
  %t173 = load i64, ptr %l79, !tbaa !24
  %t174 = mul i64 %t173, 16
  %t175 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t174)
  %t176 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  store { i64, ptr } %t177, ptr %l80, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = load i64, ptr %l79, !tbaa !24
  %t183 = mul i64 %t182, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t179, ptr %t181, i64 %t183, i1 false)
  %t184 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t184, ptr %l78, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t185, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l4 = alloca %"compiler/bindgen:cx"
  %rv = alloca %"compiler/bindgen:cx"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v0, ptr %v1, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 -1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d241, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load %"compiler/bindgen:cx", ptr %l4
  store %"compiler/bindgen:cx" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cx", ptr %rv
  ret %"compiler/bindgen:cx" %rr
}

define dso_local i32 @compiler_2fbindgen_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/bindgen:gen"
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/os:Output"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca i1
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l43 = alloca i1
  %l51 = alloca i1
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l63 = alloca i1
  %l65 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/bindgen:gen"
  %l81 = alloca i32
  %l83 = alloca i1
  %l89 = alloca i32
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca %"std/os:Output"
  %l97 = alloca { i64, ptr }
  %l98 = alloca %"std/os:Output"
  %l99 = alloca i32
  %l101 = alloca i1
  %l103 = alloca { i64, ptr }
  %l104 = alloca i32
  %l106 = alloca i32
  %l108 = alloca i1
  %l117 = alloca i32
  %l119 = alloca i32
  %l121 = alloca i1
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l129 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l130 = alloca %"std/prelude/text:StringBuilder"
  %l136 = alloca i64
  %l138 = alloca i64
  %l144 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca i64
  %l147 = alloca i64
  %l150 = alloca %"compiler/bindgen:cMacro"
  %l156 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l160 = alloca i32
  %l162 = alloca i1
  %l168 = alloca i32
  %l170 = alloca i32
  %l172 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l180 = alloca ptr
  %l181 = alloca i32
  %l183 = alloca i1
  %l190 = alloca i32
  %l192 = alloca i32
  %l194 = alloca i1
  %l199 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l215 = alloca i1
  %l217 = alloca i1
  %l219 = alloca i1
  %l221 = alloca i64
  %l223 = alloca i64
  %l224 = alloca i64
  %l228 = alloca { i64, ptr }
  %l229 = alloca i64
  %l230 = alloca i32
  %l231 = alloca i64
  %l232 = alloca i32
  %l235 = alloca i1
  %l236 = alloca i64
  %l238 = alloca i64
  %l241 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l255 = alloca i1
  %l256 = alloca i64
  %l257 = alloca { i64, ptr }
  %l258 = alloca i64
  %l259 = alloca i32
  %l260 = alloca i64
  %l261 = alloca i32
  %l262 = alloca ptr
  %l263 = alloca ptr
  %l266 = alloca i64
  %l267 = alloca %"compiler/bindgen:cMacro"
  %l275 = alloca ptr
  %l276 = alloca { i64, ptr }
  %l282 = alloca i32
  %l284 = alloca i1
  %l291 = alloca i32
  %l293 = alloca i32
  %l295 = alloca i1
  %l300 = alloca { i64, ptr }
  %l302 = alloca i1
  %l304 = alloca i32
  %l306 = alloca i1
  %l307 = alloca i32
  %l309 = alloca i32
  %l311 = alloca i1
  %l312 = alloca i32
  %l314 = alloca i32
  %l316 = alloca i1
  %l319 = alloca i32
  %l321 = alloca i1
  %l327 = alloca i32
  %l329 = alloca i32
  %l331 = alloca i1
  %l332 = alloca i32
  %l334 = alloca i32
  %l336 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %rv = alloca i32
  %t109 = alloca %"compiler/bindgen:gen", align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d242, i32 0, i32 1) })
  store i1 %t3, ptr %l34
  br label %bb1
bb1:
  %t4 = load i1, ptr %l34, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d243, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s1, ptr %t5, { i64, ptr } %t7)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb5:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t9)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l41
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb7, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l40
  br label %bb6
bb6:
  %t16 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t16, ptr %l38, !tbaa !27
  br label %bb10
bb7:
  %t17 = load i32, ptr %l41, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  store i1 %t20, ptr %l43, !tbaa !21
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t26 = extractvalue { i64, ptr } %t22, 1
  %t27 = extractvalue { i64, ptr } %t22, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t23, i64 %t24)
  %t33 = getelementptr i8, ptr %t32, i64 %t24
  call void @olang_textcopy(ptr %t33, ptr %t26, i64 %t27)
  %t34 = getelementptr i8, ptr %t33, i64 %t27
  call void @olang_textcopy(ptr %t34, ptr %t29, i64 %t30)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t32, 1
  %t39 = extractvalue { i64, ptr } %t36, 0
  %t40 = extractvalue { i64, ptr } %t36, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s2, ptr %t21, { i64, ptr } %t44)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb10:
  %t48 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t48, ptr %l4, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t51 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t49)
  store i1 %t51, ptr %l51
  br label %bb11
bb11:
  %t52 = load i1, ptr %l51, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t60 = extractvalue { i64, ptr } %t56, 1
  %t61 = extractvalue { i64, ptr } %t56, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t57, i64 %t58)
  %t67 = getelementptr i8, ptr %t66, i64 %t58
  call void @olang_textcopy(ptr %t67, ptr %t60, i64 %t61)
  %t68 = getelementptr i8, ptr %t67, i64 %t61
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t66, 1
  %t73 = extractvalue { i64, ptr } %t70, 0
  %t74 = extractvalue { i64, ptr } %t70, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s4, ptr %t55, { i64, ptr } %t78)
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb15:
  %t82 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d248, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d249, i32 0, i32 1) })
  %t83 = extractvalue { i32, { i64, ptr } } %t82, 1
  %t84 = extractvalue { i32, { i64, ptr } } %t82, 0
  store i32 %t84, ptr %l61
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb17, label %ok.86, !prof !99
ok.86:
  store { i64, ptr } %t83, ptr %l60
  br label %bb16
bb16:
  %t87 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t87, ptr %l59, !tbaa !27
  br label %bb20
bb17:
  %t88 = load i32, ptr %l61, !tbaa !23
  %t89 = ashr i32 %t88, 16
  %t91 = icmp eq i32 %t89, 1
  store i1 %t91, ptr %l63, !tbaa !21
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s6
  %t92 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d250, i32 0, i32 1) }, ptr %l65, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l65, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s6, ptr %t92, { i64, ptr } %t94)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb20:
  %t96 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t96, ptr %l5, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t97, 0
  %t100 = insertvalue [2 x { i64, ptr }] %t99, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t100, ptr %l6
  %t103 = insertvalue { i64, ptr } undef, i64 2, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %l6, 1
  %t106 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t104)
  store { i64, ptr } %t106, ptr %l71
  br label %bb21
bb21:
  %t107 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fbindgen_3agen_2ector(ptr %t109, ptr %s0, ptr %s0, { i64, ptr } %t108)
  call void @llvm.memmove.p0.p0.i64(ptr %l73, ptr %t109, i64 1128, i1 false)
  br label %bb22
bb22:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l73, i64 1128, i1 false)
  %t111 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t112 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t115 = extractvalue { i64, ptr } %t111, 1
  %t116 = extractvalue { i64, ptr } %t111, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t112, i64 %t113)
  %t122 = getelementptr i8, ptr %t121, i64 %t113
  call void @olang_textcopy(ptr %t122, ptr %t115, i64 %t116)
  %t123 = getelementptr i8, ptr %t122, i64 %t116
  call void @olang_textcopy(ptr %t123, ptr %t118, i64 %t119)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t121, 1
  store { i64, ptr } %t125, ptr %l9, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = extractvalue { i64, ptr } %t128, 0
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t130, i64 %t131)
  %t136 = getelementptr i8, ptr %t135, i64 %t131
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  %t141 = extractvalue { i64, ptr } %t138, 0
  %t142 = extractvalue { i64, ptr } %t138, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  %t149 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t127, { i64, ptr } %t146)
  store i32 %t149, ptr %l81
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb24, label %ok.151, !prof !99
ok.151:
  br label %bb23
bb23:
  br label %bb31
bb24:
  %t152 = load i32, ptr %l81, !tbaa !23
  %t153 = ashr i32 %t152, 16
  %t155 = icmp eq i32 %t153, 1
  store i1 %t155, ptr %l83, !tbaa !21
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s9
  %t156 = load ptr, ptr %l3, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t158 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t161 = extractvalue { i64, ptr } %t157, 1
  %t162 = extractvalue { i64, ptr } %t157, 0
  %t163 = add i64 %t159, %t162
  %t164 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t158, i64 %t159)
  %t168 = getelementptr i8, ptr %t167, i64 %t159
  call void @olang_textcopy(ptr %t168, ptr %t161, i64 %t162)
  %t169 = getelementptr i8, ptr %t168, i64 %t162
  call void @olang_textcopy(ptr %t169, ptr %t164, i64 %t165)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t167, 1
  %t174 = extractvalue { i64, ptr } %t171, 0
  %t175 = extractvalue { i64, ptr } %t171, 1
  %t176 = mul i64 %t174, 1
  %t177 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t176)
  call void @llvm.memcpy.p0.p0.i64(ptr %t177, ptr %t175, i64 %t176, i1 false)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s9, ptr %t156, { i64, ptr } %t179)
  br label %bb26
bb26:
  store i32 2, ptr %l89, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  %t182 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t184 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t182)
  store i32 %t184, ptr %l91
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb28, label %ok.186, !prof !99
ok.186:
  br label %bb27
bb27:
  br label %bb30
bb28:
  %t187 = load i32, ptr %l91, !tbaa !23
  %t188 = ashr i32 %t187, 16
  %t190 = icmp eq i32 %t188, 1
  store i1 %t190, ptr %l93, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t191 = load i32, ptr %l89, !tbaa !23
  store i32 %t191, ptr %rv
  br label %ret
bb31:
  %t192 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t194 = mul i64 7, 16
  %t195 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t194)
  %t196 = insertvalue { i64, ptr } undef, i64 7, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  store { i64, ptr } %t197, ptr %l97, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %t200, i64 0
  store { i64, ptr } %t192, ptr %t201, !tbaa !37
  %t202 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %t203, i64 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d257, i32 0, i32 1) }, ptr %t204, !tbaa !37
  %t205 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %t206, i64 2
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d258, i32 0, i32 1) }, ptr %t207, !tbaa !37
  %t208 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, ptr }, ptr %t209, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d259, i32 0, i32 1) }, ptr %t210, !tbaa !37
  %t211 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr { i64, ptr }, ptr %t212, i64 4
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d260, i32 0, i32 1) }, ptr %t213, !tbaa !37
  %t214 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %t215, i64 5
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d261, i32 0, i32 1) }, ptr %t216, !tbaa !37
  %t218 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %t219, i64 6
  store { i64, ptr } %t193, ptr %t220, !tbaa !37
  %t221 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t222 = call { i32, %"std/os:Output" } @compiler_2fbindgen_2eclangSays(ptr %s0, ptr %s0, { i64, ptr } %t221)
  %t223 = extractvalue { i32, %"std/os:Output" } %t222, 1
  %t224 = extractvalue { i32, %"std/os:Output" } %t222, 0
  store i32 %t224, ptr %l99
  %t225 = icmp ne i32 %t224, 0
  br i1 %t225, label %bb33, label %ok.226, !prof !99
ok.226:
  store %"std/os:Output" %t223, ptr %l98
  br label %bb32
bb32:
  %t227 = load %"std/os:Output", ptr %l98
  store %"std/os:Output" %t227, ptr %l94
  br label %bb40
bb33:
  %t228 = load i32, ptr %l99, !tbaa !23
  %t229 = ashr i32 %t228, 16
  %t231 = icmp eq i32 %t229, 1
  store i1 %t231, ptr %l101, !tbaa !21
  br label %bb34
bb34:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s14
  %t232 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d262, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l103, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s14, ptr %t232, { i64, ptr } %t234)
  br label %bb35
bb35:
  store i32 2, ptr %l104, !tbaa !23
  call void @__olang_scope_close(ptr %s14)
  %t235 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t237 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t235)
  store i32 %t237, ptr %l106
  %t238 = icmp ne i32 %t237, 0
  br i1 %t238, label %bb37, label %ok.239, !prof !99
ok.239:
  br label %bb36
bb36:
  br label %bb39
bb37:
  %t240 = load i32, ptr %l106, !tbaa !23
  %t241 = ashr i32 %t240, 16
  %t243 = icmp eq i32 %t241, 1
  store i1 %t243, ptr %l108, !tbaa !21
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t244 = load i32, ptr %l104, !tbaa !23
  store i32 %t244, ptr %rv
  br label %ret
bb40:
  %t245 = load %"std/os:Output", ptr %l94
  store %"std/os:Output" %t245, ptr %l10
  %t246 = getelementptr %"std/os:Output", ptr %l10, i32 0, i32 0
  %t247 = load i32, ptr %t246, !tbaa !23
  %t249 = icmp ne i32 %t247, 0
  br i1 %t249, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s18
  %t251 = load ptr, ptr %l3, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t253 = getelementptr %"std/os:Output", ptr %l10, i32 0, i32 2
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  %t255 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t258 = extractvalue { i64, ptr } %t252, 1
  %t259 = extractvalue { i64, ptr } %t252, 0
  %t260 = add i64 %t256, %t259
  %t261 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t265 = extractvalue { i64, ptr } %t254, 1
  %t266 = extractvalue { i64, ptr } %t254, 0
  %t267 = add i64 %t263, %t266
  %t268 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t267)
  call void @olang_textcopy(ptr %t268, ptr %t255, i64 %t256)
  %t269 = getelementptr i8, ptr %t268, i64 %t256
  call void @olang_textcopy(ptr %t269, ptr %t258, i64 %t259)
  %t270 = getelementptr i8, ptr %t269, i64 %t259
  call void @olang_textcopy(ptr %t270, ptr %t261, i64 %t262)
  %t271 = getelementptr i8, ptr %t270, i64 %t262
  call void @olang_textcopy(ptr %t271, ptr %t265, i64 %t266)
  %t272 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t268, 1
  %t276 = extractvalue { i64, ptr } %t273, 0
  %t277 = extractvalue { i64, ptr } %t273, 1
  %t278 = mul i64 %t276, 1
  %t279 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t278)
  call void @llvm.memcpy.p0.p0.i64(ptr %t279, ptr %t277, i64 %t278, i1 false)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s18, ptr %t251, { i64, ptr } %t281)
  br label %bb43
bb42:
  br label %bb48
bb43:
  store i32 1, ptr %l117, !tbaa !23
  call void @__olang_scope_close(ptr %s18)
  %t284 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t286 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t284)
  store i32 %t286, ptr %l119
  %t287 = icmp ne i32 %t286, 0
  br i1 %t287, label %bb45, label %ok.288, !prof !99
ok.288:
  br label %bb44
bb44:
  br label %bb47
bb45:
  %t289 = load i32, ptr %l119, !tbaa !23
  %t290 = ashr i32 %t289, 16
  %t292 = icmp eq i32 %t290, 1
  store i1 %t292, ptr %l121, !tbaa !21
  br label %bb46
bb46:
  call void @__olang_ert_req_clear()
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  %t293 = load i32, ptr %l117, !tbaa !23
  store i32 %t293, ptr %rv
  br label %ret
bb48:
  %t294 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t294, ptr %l122
  br label %bb49
bb49:
  %t295 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t295, ptr %l11
  %t296 = getelementptr %"std/os:Output", ptr %l10, i32 0, i32 1
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ereadMacros(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l8, { i64, ptr } %t297, { i64, ptr } %t298, { i64, ptr } %t299, ptr %l11)
  br label %bb50
bb50:
  %t306 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eintMacros(ptr %s0, ptr %s0, ptr %l8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t306, ptr %l129
  br label %bb51
bb51:
  %t307 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t307, ptr %l12
  %t308 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t308, ptr %l130
  br label %bb52
bb52:
  %t309 = load %"std/prelude/text:StringBuilder", ptr %l130
  store %"std/prelude/text:StringBuilder" %t309, ptr %l13
  %t310 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 1
  %t313 = extractvalue { i64, ptr } %t310, 0
  %t314 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t315 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t316 = add i64 %t313, %t315
  %t317 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t316)
  call void @olang_textcopy(ptr %t317, ptr %t312, i64 %t313)
  %t318 = getelementptr i8, ptr %t317, i64 %t313
  call void @olang_textcopy(ptr %t318, ptr %t314, i64 %t315)
  %t319 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t317, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l13, { i64, ptr } %t327)
  br label %bb53
bb53:
  store ptr %l12, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s25
  %t331 = load i64, ptr %l15, !tbaa !24
  store i64 %t331, ptr %l136, !tbaa !24
  %t332 = load ptr, ptr %l14, !tbaa !29
  %t334 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t332)
  store i64 %t334, ptr %l138
  br label %bb55
bb55:
  %t335 = load i64, ptr %l136, !tbaa !24
  %t336 = load i64, ptr %l138, !tbaa !24
  %t337 = icmp slt i64 %t335, %t336
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s25)
  br label %bb63
bb57:
  br label %bb58
bb58:
  %t341 = load i64, ptr %l15, !tbaa !24
  store i64 %t341, ptr %l16, !tbaa !24
  %t343 = load ptr, ptr %l14, !tbaa !29
  %t344 = load i64, ptr %l15, !tbaa !24
  %t347 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t343, i64 %t344)
  store i64 %t347, ptr %l144
  br label %bb59
bb59:
  %t348 = load i64, ptr %l144, !tbaa !24
  store ptr %l13, ptr %l145, !tbaa !29
  %t349 = load i64, ptr %l16, !tbaa !24
  store i64 %t349, ptr %l146, !tbaa !24
  %t350 = load i64, ptr %l16, !tbaa !24
  store i64 %t350, ptr %l147, !tbaa !24
  %t351 = getelementptr %"compiler/bindgen:gen", ptr %l8, i32 0, i32 12
  %t355 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %s0, ptr %s0, ptr %t351, i64 %t348)
  store %"compiler/bindgen:cMacro" %t355, ptr %l150
  br label %bb60
bb60:
  %t356 = getelementptr %"compiler/bindgen:cMacro", ptr %l150, i32 0, i32 0
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  %t358 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t359 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t360 = load i64, ptr %l146, !tbaa !24
  %t361 = call i64 @__olang_fmt_i64(ptr null, i64 %t360)
  %t362 = add i64 %t359, %t361
  %t363 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t365 = add i64 %t362, %t364
  %t366 = load i64, ptr %l147, !tbaa !24
  %t367 = call i64 @__olang_fmt_i64(ptr null, i64 %t366)
  %t368 = add i64 %t365, %t367
  %t369 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t373 = extractvalue { i64, ptr } %t357, 1
  %t374 = extractvalue { i64, ptr } %t357, 0
  %t375 = add i64 %t371, %t374
  %t376 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t377 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t378 = add i64 %t375, %t377
  %t379 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t378)
  call void @olang_textcopy(ptr %t379, ptr %t358, i64 %t359)
  %t380 = getelementptr i8, ptr %t379, i64 %t359
  %t381 = call i64 @__olang_fmt_i64(ptr %t380, i64 %t360)
  %t382 = getelementptr i8, ptr %t380, i64 %t361
  call void @olang_textcopy(ptr %t382, ptr %t363, i64 %t364)
  %t383 = getelementptr i8, ptr %t382, i64 %t364
  %t384 = call i64 @__olang_fmt_i64(ptr %t383, i64 %t366)
  %t385 = getelementptr i8, ptr %t383, i64 %t367
  call void @olang_textcopy(ptr %t385, ptr %t369, i64 %t370)
  %t386 = getelementptr i8, ptr %t385, i64 %t370
  call void @olang_textcopy(ptr %t386, ptr %t373, i64 %t374)
  %t387 = getelementptr i8, ptr %t386, i64 %t374
  call void @olang_textcopy(ptr %t387, ptr %t376, i64 %t377)
  %t388 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t379, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = extractvalue { i64, ptr } %t389, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  %t397 = load ptr, ptr %l145, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s25, ptr %t397, { i64, ptr } %t396)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s25)
  br label %bb62
bb62:
  %t399 = load i64, ptr %l15, !tbaa !24
  %t401 = add i64 %t399, 1
  store i64 %t401, ptr %l15, !tbaa !24
  br label %bb54
bb63:
  %t403 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t403, ptr %l156, !tbaa !27
  %t405 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l13)
  store { i64, ptr } %t405, ptr %l158
  br label %bb64
bb64:
  %t406 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t407 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t409 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t407, { i64, ptr } %t406)
  store i32 %t409, ptr %l160
  %t410 = icmp ne i32 %t409, 0
  br i1 %t410, label %bb66, label %ok.411, !prof !99
ok.411:
  br label %bb65
bb65:
  br label %bb73
bb66:
  %t412 = load i32, ptr %l160, !tbaa !23
  %t413 = ashr i32 %t412, 16
  %t415 = icmp eq i32 %t413, 1
  store i1 %t415, ptr %l162, !tbaa !21
  br label %bb67
bb67:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s28
  %t416 = load ptr, ptr %l3, !tbaa !29
  %t417 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t418 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t421 = extractvalue { i64, ptr } %t417, 1
  %t422 = extractvalue { i64, ptr } %t417, 0
  %t423 = add i64 %t419, %t422
  %t424 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t425 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t426 = add i64 %t423, %t425
  %t427 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t426)
  call void @olang_textcopy(ptr %t427, ptr %t418, i64 %t419)
  %t428 = getelementptr i8, ptr %t427, i64 %t419
  call void @olang_textcopy(ptr %t428, ptr %t421, i64 %t422)
  %t429 = getelementptr i8, ptr %t428, i64 %t422
  call void @olang_textcopy(ptr %t429, ptr %t424, i64 %t425)
  %t430 = insertvalue { i64, ptr } undef, i64 %t426, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t427, 1
  %t434 = extractvalue { i64, ptr } %t431, 0
  %t435 = extractvalue { i64, ptr } %t431, 1
  %t436 = mul i64 %t434, 1
  %t437 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t436)
  call void @llvm.memcpy.p0.p0.i64(ptr %t437, ptr %t435, i64 %t436, i1 false)
  %t438 = insertvalue { i64, ptr } undef, i64 %t434, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t437, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s28, ptr %t416, { i64, ptr } %t439)
  br label %bb68
bb68:
  store i32 2, ptr %l168, !tbaa !23
  call void @__olang_scope_close(ptr %s28)
  %t442 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t444 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t442)
  store i32 %t444, ptr %l170
  %t445 = icmp ne i32 %t444, 0
  br i1 %t445, label %bb70, label %ok.446, !prof !99
ok.446:
  br label %bb69
bb69:
  br label %bb72
bb70:
  %t447 = load i32, ptr %l170, !tbaa !23
  %t448 = ashr i32 %t447, 16
  %t450 = icmp eq i32 %t448, 1
  store i1 %t450, ptr %l172, !tbaa !21
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t451 = load i32, ptr %l168, !tbaa !23
  store i32 %t451, ptr %rv
  br label %ret
bb73:
  store ptr %l8, ptr %l174, !tbaa !29
  %t452 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t452, ptr %l175, !tbaa !27
  %t453 = icmp sge i64 0, 0
  br i1 %t453, label %bb74, label %bb75
bb74:
  %t455 = icmp sle i64 0, 576460752303423487
  br i1 %t455, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_2d25c1a9d7803e60_587b957d3d0d6154)
  unreachable
bb76:
  %t457 = mul i64 0, 16
  %t458 = insertvalue { i64, ptr } undef, i64 0, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t460 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t461 = load ptr, ptr %l174, !tbaa !29
  %t462 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t465 = call { i32, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edump(ptr %s0, ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %t461, { i64, ptr } %t462, { i64, ptr } %t459, { i64, ptr } %t460)
  %t466 = extractvalue { i32, ptr } %t465, 1
  %t467 = extractvalue { i32, ptr } %t465, 0
  store i32 %t467, ptr %l181
  %t468 = icmp ne i32 %t467, 0
  br i1 %t468, label %bb79, label %ok.469, !prof !99
ok.469:
  store ptr %t466, ptr %l180
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_2d25c1a9d7803e60_587b957d3d0d6154)
  unreachable
bb78:
  %t470 = load ptr, ptr %l180, !tbaa !29
  store ptr %t470, ptr %l173, !tbaa !29
  br label %bb86
bb79:
  %t471 = load i32, ptr %l181, !tbaa !23
  %t472 = ashr i32 %t471, 16
  %t474 = icmp eq i32 %t472, 1
  store i1 %t474, ptr %l183, !tbaa !21
  br label %bb80
bb80:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s33
  %t475 = load ptr, ptr %l3, !tbaa !29
  %t476 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t477 = getelementptr %"compiler/bindgen:gen", ptr %l8, i32 0, i32 25
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  %t479 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t480 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  %t482 = extractvalue { i64, ptr } %t476, 1
  %t483 = extractvalue { i64, ptr } %t476, 0
  %t484 = add i64 %t480, %t483
  %t485 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t486 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  %t487 = add i64 %t484, %t486
  %t489 = extractvalue { i64, ptr } %t478, 1
  %t490 = extractvalue { i64, ptr } %t478, 0
  %t491 = add i64 %t487, %t490
  %t492 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t493 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t494 = add i64 %t491, %t493
  %t495 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t494)
  call void @olang_textcopy(ptr %t495, ptr %t479, i64 %t480)
  %t496 = getelementptr i8, ptr %t495, i64 %t480
  call void @olang_textcopy(ptr %t496, ptr %t482, i64 %t483)
  %t497 = getelementptr i8, ptr %t496, i64 %t483
  call void @olang_textcopy(ptr %t497, ptr %t485, i64 %t486)
  %t498 = getelementptr i8, ptr %t497, i64 %t486
  call void @olang_textcopy(ptr %t498, ptr %t489, i64 %t490)
  %t499 = getelementptr i8, ptr %t498, i64 %t490
  call void @olang_textcopy(ptr %t499, ptr %t492, i64 %t493)
  %t500 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t495, 1
  %t504 = extractvalue { i64, ptr } %t501, 0
  %t505 = extractvalue { i64, ptr } %t501, 1
  %t506 = mul i64 %t504, 1
  %t507 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t506)
  call void @llvm.memcpy.p0.p0.i64(ptr %t507, ptr %t505, i64 %t506, i1 false)
  %t508 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t509 = insertvalue { i64, ptr } %t508, ptr %t507, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s33, ptr %t475, { i64, ptr } %t509)
  br label %bb81
bb81:
  store i32 1, ptr %l190, !tbaa !23
  call void @__olang_scope_close(ptr %s33)
  %t512 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t514 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t512)
  store i32 %t514, ptr %l192
  %t515 = icmp ne i32 %t514, 0
  br i1 %t515, label %bb83, label %ok.516, !prof !99
ok.516:
  br label %bb82
bb82:
  br label %bb85
bb83:
  %t517 = load i32, ptr %l192, !tbaa !23
  %t518 = ashr i32 %t517, 16
  %t520 = icmp eq i32 %t518, 1
  store i1 %t520, ptr %l194, !tbaa !21
  br label %bb84
bb84:
  call void @__olang_ert_req_clear()
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t521 = load i32, ptr %l190, !tbaa !23
  store i32 %t521, ptr %rv
  br label %ret
bb86:
  %t522 = load ptr, ptr %l173, !tbaa !29
  store ptr %t522, ptr %l18, !tbaa !29
  %t523 = load ptr, ptr %l18, !tbaa !29
  %t524 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eread(ptr %s0, ptr %s0, ptr %s0, ptr %l8, ptr %t523, { i64, ptr } %t524)
  br label %bb87
bb87:
  %t528 = getelementptr %"compiler/bindgen:gen", ptr %l8, i32 0, i32 26
  store i64 0, ptr %t528, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s38
  %t529 = load ptr, ptr %l18, !tbaa !29
  %t531 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s0, ptr %s38, ptr %t529)
  store { i64, ptr } %t531, ptr %l199
  br label %bb88
bb88:
  %t532 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t532, 0
  %t534 = extractvalue { i64, ptr } %t532, 1
  %t535 = mul i64 %t533, 8
  %t536 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t535)
  call void @llvm.memcpy.p0.p0.i64(ptr %t536, ptr %t534, i64 %t535, i1 false)
  %t537 = insertvalue { i64, ptr } undef, i64 %t533, 0
  %t538 = insertvalue { i64, ptr } %t537, ptr %t536, 1
  store { i64, ptr } %t538, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t540, 0
  store i64 %t542, ptr %l21, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s39
  %t544 = load i64, ptr %l20, !tbaa !24
  %t545 = load i64, ptr %l21, !tbaa !24
  %t548 = icmp slt i64 %t544, %t545
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s39)
  br label %bb144
bb91:
  br label %bb92
bb92:
  %t552 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t552, ptr %l207, !tbaa !27
  %t553 = load i64, ptr %l20, !tbaa !24
  %t555 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr ptr, ptr %t556, i64 %t553
  %t558 = load ptr, ptr %t557, !tbaa !39
  store ptr %t558, ptr %l22, !tbaa !29
  %t560 = load ptr, ptr %l22, !tbaa !29
  %t562 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s38, ptr %s39, ptr %s39, ptr %t560, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d275, i32 0, i32 1) })
  store { i64, ptr } %t562, ptr %l211
  br label %bb93
bb93:
  %t563 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t563, ptr %l23, !tbaa !27
  %t564 = load ptr, ptr %l22, !tbaa !29
  %t566 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s38, ptr %s39, ptr %s39, ptr %t564, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d276, i32 0, i32 1) })
  store { i64, ptr } %t566, ptr %l213
  br label %bb94
bb94:
  %t567 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t568 = extractvalue { i64, ptr } %t567, 0
  %t569 = extractvalue { i64, ptr } %t567, 1
  %t570 = mul i64 %t568, 1
  %t571 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t570)
  call void @llvm.memcpy.p0.p0.i64(ptr %t571, ptr %t569, i64 %t570, i1 false)
  %t572 = insertvalue { i64, ptr } undef, i64 %t568, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t571, 1
  %t575 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s39, ptr %s39, { i64, ptr } %t573, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d277, i32 0, i32 1) })
  store i1 %t575, ptr %l215
  br label %bb95
bb95:
  %t576 = load i1, ptr %l215, !tbaa !21
  %t577 = xor i1 %t576, true
  br i1 %t577, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb99
bb97:
  %t579 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t581 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s39, ptr %s39, { i64, ptr } %t579, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d278, i32 0, i32 1) })
  store i1 %t581, ptr %l219
  br label %bb98
bb98:
  %t582 = load i1, ptr %l219, !tbaa !21
  %t583 = xor i1 %t582, true
  store i1 %t583, ptr %l217, !tbaa !21
  br label %bb99
bb99:
  %t585 = load i1, ptr %l217, !tbaa !21
  br i1 %t585, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s39)
  br label %bb143
bb101:
  br label %bb102
bb102:
  %t586 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t588 = extractvalue { i64, ptr } %t586, 0
  store i64 %t588, ptr %l223, !tbaa !24
  %t589 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t590 = extractvalue { i64, ptr } %t589, 0
  store i64 %t590, ptr %l224, !tbaa !24
  %t591 = icmp sge i64 9, 0
  br i1 %t591, label %bb103, label %bb104
bb103:
  %t593 = load i64, ptr %l223, !tbaa !24
  %t594 = icmp sle i64 9, %t593
  br i1 %t594, label %bb105, label %bb106
bb104:
  call void @__olang_check_failed(ptr @olang_loc_6d7a361a7a168fed_fbeb1a267b83d779)
  unreachable
bb105:
  %t596 = load i64, ptr %l223, !tbaa !24
  %t597 = load i64, ptr %l224, !tbaa !24
  %t598 = icmp sle i64 %t596, %t597
  br i1 %t598, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @olang_loc_6d7a361a7a168fed_fbeb1a267b83d779)
  unreachable
bb107:
  %t600 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t601 = load ptr, ptr %t600, !tbaa !27
  %t602 = load i64, ptr %l223, !tbaa !24
  %t603 = getelementptr i8, ptr %t601, i64 9
  %t604 = sub i64 %t602, 9
  %t605 = insertvalue { i64, ptr } undef, i64 %t604, 0
  %t606 = insertvalue { i64, ptr } %t605, ptr %t603, 1
  store { i64, ptr } %t606, ptr %l228, !tbaa !27
  %t607 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s39, i64 10)
  %t608 = extractvalue { i32, i64 } %t607, 1
  %t609 = extractvalue { i32, i64 } %t607, 0
  store i32 %t609, ptr %l230
  %t610 = icmp ne i32 %t609, 0
  br i1 %t610, label %bb110, label %ok.611, !prof !99
ok.611:
  store i64 %t608, ptr %l229
  br label %bb109
bb108:
  call void @__olang_check_failed(ptr @olang_loc_6d7a361a7a168fed_fbeb1a267b83d779)
  unreachable
bb109:
  %t612 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t613 = load i64, ptr %l229, !tbaa !24
  %t614 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s39, { i64, ptr } %t612, i64 %t613)
  %t615 = extractvalue { i32, i64 } %t614, 1
  %t616 = extractvalue { i32, i64 } %t614, 0
  store i32 %t616, ptr %l232
  %t617 = icmp ne i32 %t616, 0
  br i1 %t617, label %bb113, label %ok.618, !prof !99
ok.618:
  store i64 %t615, ptr %l231
  br label %bb112
bb110:
  br label %bb111
bb111:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l221, !tbaa !24
  br label %bb114
bb112:
  %t619 = load i64, ptr %l231, !tbaa !24
  store i64 %t619, ptr %l221, !tbaa !24
  br label %bb114
bb113:
  br label %bb111
bb114:
  %t620 = load i64, ptr %l221, !tbaa !24
  store i64 %t620, ptr %l24, !tbaa !24
  %t621 = load i64, ptr %l24, !tbaa !24
  %t623 = icmp slt i64 %t621, 0
  br i1 %t623, label %bb115, label %bb116
bb115:
  store i1 true, ptr %l235, !tbaa !21
  br label %bb118
bb116:
  %t625 = load i64, ptr %l24, !tbaa !24
  store i64 %t625, ptr %l236, !tbaa !24
  %t627 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l12)
  store i64 %t627, ptr %l238
  br label %bb117
bb117:
  %t628 = load i64, ptr %l236, !tbaa !24
  %t629 = load i64, ptr %l238, !tbaa !24
  %t630 = icmp sge i64 %t628, %t629
  store i1 %t630, ptr %l235, !tbaa !21
  br label %bb118
bb118:
  %t632 = load i1, ptr %l235, !tbaa !21
  br i1 %t632, label %bb119, label %bb120
bb119:
  call void @__olang_scope_close(ptr %s39)
  br label %bb143
bb120:
  br label %bb121
bb121:
  store %olang.scope zeroinitializer, ptr %s42
  %t633 = load ptr, ptr %l22, !tbaa !29
  %t635 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s38, ptr %s42, ptr %t633)
  store { i64, ptr } %t635, ptr %l241
  br label %bb122
bb122:
  %t636 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t637 = extractvalue { i64, ptr } %t636, 0
  %t638 = extractvalue { i64, ptr } %t636, 1
  %t639 = mul i64 %t637, 8
  %t640 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t639)
  call void @llvm.memcpy.p0.p0.i64(ptr %t640, ptr %t638, i64 %t639, i1 false)
  %t641 = insertvalue { i64, ptr } undef, i64 %t637, 0
  %t642 = insertvalue { i64, ptr } %t641, ptr %t640, 1
  store { i64, ptr } %t642, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t644 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t646 = extractvalue { i64, ptr } %t644, 0
  store i64 %t646, ptr %l27, !tbaa !24
  br label %bb123
bb123:
  store %olang.scope zeroinitializer, ptr %s43
  %t648 = load i64, ptr %l26, !tbaa !24
  %t649 = load i64, ptr %l27, !tbaa !24
  %t652 = icmp slt i64 %t648, %t649
  %t654 = xor i1 %t652, true
  br i1 %t654, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s43)
  br label %bb142
bb125:
  br label %bb126
bb126:
  %t656 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t656, ptr %l249, !tbaa !27
  %t657 = load i64, ptr %l26, !tbaa !24
  %t659 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t660 = load ptr, ptr %t659, !tbaa !27
  %t661 = getelementptr ptr, ptr %t660, i64 %t657
  %t662 = load ptr, ptr %t661, !tbaa !39
  %t666 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s42, ptr %s43, ptr %t662)
  store { i64, ptr } %t666, ptr %l253
  br label %bb127
bb127:
  %t667 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t667, ptr %l29, !tbaa !27
  %t668 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t670 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s43, ptr %s43, { i64, ptr } %t668, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d279, i32 0, i32 1) })
  store i1 %t670, ptr %l255
  br label %bb128
bb128:
  %t671 = load i1, ptr %l255, !tbaa !21
  br i1 %t671, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s43)
  br label %bb141
bb130:
  br label %bb131
bb131:
  %t672 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t672, ptr %l257, !tbaa !27
  %t673 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s43, i64 10)
  %t674 = extractvalue { i32, i64 } %t673, 1
  %t675 = extractvalue { i32, i64 } %t673, 0
  store i32 %t675, ptr %l259
  %t676 = icmp ne i32 %t675, 0
  br i1 %t676, label %bb133, label %ok.677, !prof !99
ok.677:
  store i64 %t674, ptr %l258
  br label %bb132
bb132:
  %t678 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t679 = load i64, ptr %l258, !tbaa !24
  %t680 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s43, { i64, ptr } %t678, i64 %t679)
  %t681 = extractvalue { i32, i64 } %t680, 1
  %t682 = extractvalue { i32, i64 } %t680, 0
  store i32 %t682, ptr %l261
  %t683 = icmp ne i32 %t682, 0
  br i1 %t683, label %bb136, label %ok.684, !prof !99
ok.684:
  store i64 %t681, ptr %l260
  br label %bb135
bb133:
  br label %bb134
bb134:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s43)
  br label %bb141
bb135:
  %t685 = load i64, ptr %l260, !tbaa !24
  store i64 %t685, ptr %l256, !tbaa !24
  br label %bb137
bb136:
  br label %bb134
bb137:
  %t686 = load i64, ptr %l256, !tbaa !24
  store i64 %t686, ptr %l30, !tbaa !24
  store ptr %l8, ptr %l262, !tbaa !29
  %t687 = getelementptr %"compiler/bindgen:gen", ptr %l8, i32 0, i32 12
  store ptr %t687, ptr %l263, !tbaa !29
  %t688 = load i64, ptr %l24, !tbaa !24
  %t691 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l12, i64 %t688)
  store i64 %t691, ptr %l266
  br label %bb138
bb138:
  %t692 = load ptr, ptr %l263, !tbaa !29
  %t693 = load i64, ptr %l266, !tbaa !24
  %t694 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %s0, ptr %s0, ptr %t692, i64 %t693)
  store %"compiler/bindgen:cMacro" %t694, ptr %l267
  br label %bb139
bb139:
  %t695 = getelementptr %"compiler/bindgen:cMacro", ptr %l267, i32 0, i32 0
  %t696 = load { i64, ptr }, ptr %t695, !tbaa !27
  %t697 = load i64, ptr %l30, !tbaa !24
  %t698 = load ptr, ptr %l262, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %s0, ptr %s0, ptr %t698, { i64, ptr } %t696, i64 %t697)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s43)
  br label %bb141
bb141:
  %t701 = load i64, ptr %l26, !tbaa !24
  %t703 = add i64 %t701, 1
  store i64 %t703, ptr %l26, !tbaa !24
  br label %bb123
bb142:
  call void @__olang_scope_close(ptr %s42)
  call void @__olang_scope_close(ptr %s39)
  br label %bb143
bb143:
  %t705 = load i64, ptr %l20, !tbaa !24
  %t707 = add i64 %t705, 1
  store i64 %t707, ptr %l20, !tbaa !24
  br label %bb89
bb144:
  call void @__olang_scope_close(ptr %s38)
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eotherConsts(ptr %s0, ptr %l8)
  br label %bb145
bb145:
  store ptr %l8, ptr %l275, !tbaa !29
  %t710 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t710, ptr %l276, !tbaa !27
  %t711 = icmp sge i64 0, 0
  br i1 %t711, label %bb146, label %bb147
bb146:
  %t713 = icmp sle i64 0, 576460752303423487
  br i1 %t713, label %bb148, label %bb149
bb147:
  call void @__olang_check_failed(ptr @olang_loc_3c31d34710cd488e_9478fba938690442)
  unreachable
bb148:
  %t715 = mul i64 0, 16
  %t716 = insertvalue { i64, ptr } undef, i64 0, 0
  %t717 = insertvalue { i64, ptr } %t716, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t718 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t719 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t720 = load ptr, ptr %l275, !tbaa !29
  %t721 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t725 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2esizes(ptr %s0, ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %t720, { i64, ptr } %t721, { i64, ptr } %t717, { i64, ptr } %t718, { i64, ptr } %t719)
  store i32 %t725, ptr %l282
  %t726 = icmp ne i32 %t725, 0
  br i1 %t726, label %bb151, label %ok.727, !prof !99
ok.727:
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_3c31d34710cd488e_9478fba938690442)
  unreachable
bb150:
  br label %bb158
bb151:
  %t728 = load i32, ptr %l282, !tbaa !23
  %t729 = ashr i32 %t728, 16
  %t731 = icmp eq i32 %t729, 1
  store i1 %t731, ptr %l284, !tbaa !21
  br label %bb152
bb152:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s48
  %t732 = load ptr, ptr %l3, !tbaa !29
  %t733 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t734 = getelementptr %"compiler/bindgen:gen", ptr %l8, i32 0, i32 25
  %t735 = load { i64, ptr }, ptr %t734, !tbaa !27
  %t736 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t737 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  %t739 = extractvalue { i64, ptr } %t733, 1
  %t740 = extractvalue { i64, ptr } %t733, 0
  %t741 = add i64 %t737, %t740
  %t742 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t743 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t744 = add i64 %t741, %t743
  %t746 = extractvalue { i64, ptr } %t735, 1
  %t747 = extractvalue { i64, ptr } %t735, 0
  %t748 = add i64 %t744, %t747
  %t749 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t750 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t751 = add i64 %t748, %t750
  %t752 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t751)
  call void @olang_textcopy(ptr %t752, ptr %t736, i64 %t737)
  %t753 = getelementptr i8, ptr %t752, i64 %t737
  call void @olang_textcopy(ptr %t753, ptr %t739, i64 %t740)
  %t754 = getelementptr i8, ptr %t753, i64 %t740
  call void @olang_textcopy(ptr %t754, ptr %t742, i64 %t743)
  %t755 = getelementptr i8, ptr %t754, i64 %t743
  call void @olang_textcopy(ptr %t755, ptr %t746, i64 %t747)
  %t756 = getelementptr i8, ptr %t755, i64 %t747
  call void @olang_textcopy(ptr %t756, ptr %t749, i64 %t750)
  %t757 = insertvalue { i64, ptr } undef, i64 %t751, 0
  %t758 = insertvalue { i64, ptr } %t757, ptr %t752, 1
  %t761 = extractvalue { i64, ptr } %t758, 0
  %t762 = extractvalue { i64, ptr } %t758, 1
  %t763 = mul i64 %t761, 1
  %t764 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t763)
  call void @llvm.memcpy.p0.p0.i64(ptr %t764, ptr %t762, i64 %t763, i1 false)
  %t765 = insertvalue { i64, ptr } undef, i64 %t761, 0
  %t766 = insertvalue { i64, ptr } %t765, ptr %t764, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s48, ptr %t732, { i64, ptr } %t766)
  br label %bb153
bb153:
  store i32 1, ptr %l291, !tbaa !23
  call void @__olang_scope_close(ptr %s48)
  %t769 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t771 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t769)
  store i32 %t771, ptr %l293
  %t772 = icmp ne i32 %t771, 0
  br i1 %t772, label %bb155, label %ok.773, !prof !99
ok.773:
  br label %bb154
bb154:
  br label %bb157
bb155:
  %t774 = load i32, ptr %l293, !tbaa !23
  %t775 = ashr i32 %t774, 16
  %t777 = icmp eq i32 %t775, 1
  store i1 %t777, ptr %l295, !tbaa !21
  br label %bb156
bb156:
  call void @__olang_ert_req_clear()
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s0)
  %t778 = load i32, ptr %l291, !tbaa !23
  store i32 %t778, ptr %rv
  br label %ret
bb158:
  %t779 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t780 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t781 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t783 = extractvalue { i64, ptr } %t779, 1
  %t784 = extractvalue { i64, ptr } %t779, 0
  %t785 = add i64 %t781, %t784
  %t786 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t787 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  %t788 = add i64 %t785, %t787
  %t789 = extractvalue { i64, ptr } { i64 104, ptr getelementptr inbounds (<{ i64, [104 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t790 = extractvalue { i64, ptr } { i64 104, ptr getelementptr inbounds (<{ i64, [104 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t791 = add i64 %t788, %t790
  %t792 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t793 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t794 = add i64 %t791, %t793
  %t795 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t794)
  call void @olang_textcopy(ptr %t795, ptr %t780, i64 %t781)
  %t796 = getelementptr i8, ptr %t795, i64 %t781
  call void @olang_textcopy(ptr %t796, ptr %t783, i64 %t784)
  %t797 = getelementptr i8, ptr %t796, i64 %t784
  call void @olang_textcopy(ptr %t797, ptr %t786, i64 %t787)
  %t798 = getelementptr i8, ptr %t797, i64 %t787
  call void @olang_textcopy(ptr %t798, ptr %t789, i64 %t790)
  %t799 = getelementptr i8, ptr %t798, i64 %t790
  call void @olang_textcopy(ptr %t799, ptr %t792, i64 %t793)
  %t800 = insertvalue { i64, ptr } undef, i64 %t794, 0
  %t801 = insertvalue { i64, ptr } %t800, ptr %t795, 1
  %t806 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrite(ptr %s0, ptr %s0, ptr %s0, ptr %l8, { i64, ptr } %t801)
  store { i64, ptr } %t806, ptr %l300
  br label %bb159
bb159:
  %t807 = load { i64, ptr }, ptr %l300, !tbaa !27
  store { i64, ptr } %t807, ptr %l32, !tbaa !27
  %t808 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t810 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t808, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d287, i32 0, i32 1) })
  store i1 %t810, ptr %l302
  br label %bb160
bb160:
  %t811 = load i1, ptr %l302, !tbaa !21
  br i1 %t811, label %bb161, label %bb162
bb161:
  %t812 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t814 = call i32 @std_2fio_2ePrint(ptr %s0, { i64, ptr } %t812)
  store i32 %t814, ptr %l304
  %t815 = icmp ne i32 %t814, 0
  br i1 %t815, label %bb164, label %ok.816, !prof !99
ok.816:
  br label %bb163
bb162:
  br label %bb175
bb163:
  br label %bb170
bb164:
  %t817 = load i32, ptr %l304, !tbaa !23
  %t818 = ashr i32 %t817, 16
  %t820 = icmp eq i32 %t818, 1
  store i1 %t820, ptr %l306, !tbaa !21
  br label %bb165
bb165:
  call void @__olang_ert_req_clear()
  store i32 1, ptr %l307, !tbaa !23
  %t821 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t823 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t821)
  store i32 %t823, ptr %l309
  %t824 = icmp ne i32 %t823, 0
  br i1 %t824, label %bb167, label %ok.825, !prof !99
ok.825:
  br label %bb166
bb166:
  br label %bb169
bb167:
  %t826 = load i32, ptr %l309, !tbaa !23
  %t827 = ashr i32 %t826, 16
  %t829 = icmp eq i32 %t827, 1
  store i1 %t829, ptr %l311, !tbaa !21
  br label %bb168
bb168:
  call void @__olang_ert_req_clear()
  br label %bb169
bb169:
  call void @__olang_scope_close(ptr %s0)
  %t830 = load i32, ptr %l307, !tbaa !23
  store i32 %t830, ptr %rv
  br label %ret
bb170:
  store i32 0, ptr %l312, !tbaa !23
  %t831 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t833 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t831)
  store i32 %t833, ptr %l314
  %t834 = icmp ne i32 %t833, 0
  br i1 %t834, label %bb172, label %ok.835, !prof !99
ok.835:
  br label %bb171
bb171:
  br label %bb174
bb172:
  %t836 = load i32, ptr %l314, !tbaa !23
  %t837 = ashr i32 %t836, 16
  %t839 = icmp eq i32 %t837, 1
  store i1 %t839, ptr %l316, !tbaa !21
  br label %bb173
bb173:
  call void @__olang_ert_req_clear()
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s0)
  %t840 = load i32, ptr %l312, !tbaa !23
  store i32 %t840, ptr %rv
  br label %ret
bb175:
  %t841 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t842 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t845 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s0, { i64, ptr } %t841, { i64, ptr } %t842)
  store i32 %t845, ptr %l319
  %t846 = icmp ne i32 %t845, 0
  br i1 %t846, label %bb177, label %ok.847, !prof !99
ok.847:
  br label %bb176
bb176:
  br label %bb184
bb177:
  %t848 = load i32, ptr %l319, !tbaa !23
  %t849 = ashr i32 %t848, 16
  %t851 = icmp eq i32 %t849, 1
  store i1 %t851, ptr %l321, !tbaa !21
  br label %bb178
bb178:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s62
  %t852 = load ptr, ptr %l3, !tbaa !29
  %t853 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t854 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t855 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  %t857 = extractvalue { i64, ptr } %t853, 1
  %t858 = extractvalue { i64, ptr } %t853, 0
  %t859 = add i64 %t855, %t858
  %t860 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t861 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  %t862 = add i64 %t859, %t861
  %t863 = call ptr @__olang_scope_alloc(ptr %s62, i64 %t862)
  call void @olang_textcopy(ptr %t863, ptr %t854, i64 %t855)
  %t864 = getelementptr i8, ptr %t863, i64 %t855
  call void @olang_textcopy(ptr %t864, ptr %t857, i64 %t858)
  %t865 = getelementptr i8, ptr %t864, i64 %t858
  call void @olang_textcopy(ptr %t865, ptr %t860, i64 %t861)
  %t866 = insertvalue { i64, ptr } undef, i64 %t862, 0
  %t867 = insertvalue { i64, ptr } %t866, ptr %t863, 1
  %t870 = extractvalue { i64, ptr } %t867, 0
  %t871 = extractvalue { i64, ptr } %t867, 1
  %t872 = mul i64 %t870, 1
  %t873 = call ptr @__olang_scope_alloc(ptr %s62, i64 %t872)
  call void @llvm.memcpy.p0.p0.i64(ptr %t873, ptr %t871, i64 %t872, i1 false)
  %t874 = insertvalue { i64, ptr } undef, i64 %t870, 0
  %t875 = insertvalue { i64, ptr } %t874, ptr %t873, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s62, ptr %t852, { i64, ptr } %t875)
  br label %bb179
bb179:
  store i32 2, ptr %l327, !tbaa !23
  call void @__olang_scope_close(ptr %s62)
  %t878 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t880 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t878)
  store i32 %t880, ptr %l329
  %t881 = icmp ne i32 %t880, 0
  br i1 %t881, label %bb181, label %ok.882, !prof !99
ok.882:
  br label %bb180
bb180:
  br label %bb183
bb181:
  %t883 = load i32, ptr %l329, !tbaa !23
  %t884 = ashr i32 %t883, 16
  %t886 = icmp eq i32 %t884, 1
  store i1 %t886, ptr %l331, !tbaa !21
  br label %bb182
bb182:
  call void @__olang_ert_req_clear()
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s0)
  %t887 = load i32, ptr %l327, !tbaa !23
  store i32 %t887, ptr %rv
  br label %ret
bb184:
  store i32 0, ptr %l332, !tbaa !23
  %t888 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t890 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t888)
  store i32 %t890, ptr %l334
  %t891 = icmp ne i32 %t890, 0
  br i1 %t891, label %bb186, label %ok.892, !prof !99
ok.892:
  br label %bb185
bb185:
  br label %bb188
bb186:
  %t893 = load i32, ptr %l334, !tbaa !23
  %t894 = ashr i32 %t893, 16
  %t896 = icmp eq i32 %t894, 1
  store i1 %t896, ptr %l336, !tbaa !21
  br label %bb187
bb187:
  call void @__olang_ert_req_clear()
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s0)
  %t897 = load i32, ptr %l332, !tbaa !23
  store i32 %t897, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2etext(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %v1, ptr %v0, ptr %a0, { i64, ptr } %a1)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d290, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l11, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t28 = load ptr, ptr %l13, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l13, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 8}
  %t34 = icmp eq i64 %t32, 5
  store i1 %t34, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t35 = load i1, ptr %l14, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { { i64, ptr } }, ptr %t38, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = extractvalue { i64, ptr } %t42, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d291, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t50, ptr %l22, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l23, !tbaa !24
  %t53 = load i64, ptr %l23, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l24, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l23, !tbaa !24
  %t63 = mul i64 %t62, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %t61, i64 %t63, i1 false)
  %t64 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t64, ptr %l22, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_433ff8d12b25a21d_ce9dc62322af2169)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %v0, ptr %v0, ptr %a0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d292, i32 0, i32 1) })
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d293, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %v0, ptr %v1, ptr %v1, ptr %t25, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d294, i32 0, i32 1) })
  store { i64, ptr } %t27, ptr %l11
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2evoidRef(ptr %v0, i1 %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a0, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d295, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t3, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d296, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t5, ptr %l2, !tbaa !27
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/bindgen:cparse" @compiler_2fbindgen_3acparse_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/bindgen:cparse"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/bindgen:cparse" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/bindgen:cparse" %t6, { i64, ptr } %a1, 1
  %t10 = insertvalue %"compiler/bindgen:cparse" %t8, i64 0, 2
  store %"compiler/bindgen:cparse" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cparse", ptr %rv
  ret %"compiler/bindgen:cparse" %rr
}

define dso_local void @compiler_2fbindgen_3agen_2ector(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l23 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l24 = alloca i1
  %l26 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/text:StringBuilder"
  %l46 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l47 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l48 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l49 = alloca %"compiler/bindgen:gen"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i1 false, ptr %l2, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d297, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d298, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l29
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l29
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l5
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l30
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l6
  %t7 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t7, ptr %l31
  br label %bb3
bb3:
  %t8 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l31
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t8, ptr %l7
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l32
  br label %bb4
bb4:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l8
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l33
  br label %bb5
bb5:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l9
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l34
  br label %bb6
bb6:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l10
  %t15 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t15, ptr %l35
  br label %bb7
bb7:
  %t16 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %l11
  %t17 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t17, ptr %l36
  br label %bb8
bb8:
  %t18 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t18, ptr %l12
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l37
  br label %bb9
bb9:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l13
  %t21 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t21, ptr %l38
  br label %bb10
bb10:
  %t22 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l38
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t22, ptr %l14
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l39
  br label %bb11
bb11:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l15
  %t25 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %l40
  br label %bb12
bb12:
  %t26 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t26, ptr %l16
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l41
  br label %bb13
bb13:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l17
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l42
  br label %bb14
bb14:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l18
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l43
  br label %bb15
bb15:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l19
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l44
  br label %bb16
bb16:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l20
  %t35 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v1)
  store %"std/prelude/text:StringBuilder" %t35, ptr %l45
  br label %bb17
bb17:
  %t36 = load %"std/prelude/text:StringBuilder", ptr %l45
  store %"std/prelude/text:StringBuilder" %t36, ptr %l21
  %t37 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t37, ptr %l46
  br label %bb18
bb18:
  %t38 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l46
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t38, ptr %l22
  %t39 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t39, ptr %l47
  br label %bb19
bb19:
  %t40 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t40, ptr %l23
  store i1 false, ptr %l24, !tbaa !21
  %t41 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t41, ptr %l48
  br label %bb20
bb20:
  %t42 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l48
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d299, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t43 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 0
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t44, ptr %t43, !tbaa !27
  %t45 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 1
  %t46 = load i1, ptr %l2, !tbaa !21
  store i1 %t46, ptr %t45, !tbaa !21
  %t47 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 2
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t48, ptr %t47, !tbaa !27
  %t49 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 3
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t50, ptr %t49, !tbaa !27
  %t51 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 4
  %t52 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t52, ptr %t51
  %t53 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 5
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %t53
  %t55 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 6
  %t56 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t56, ptr %t55
  %t57 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 7
  %t58 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t58, ptr %t57
  %t59 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 8
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t59
  %t61 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 9
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %t61
  %t63 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 10
  %t64 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t64, ptr %t63
  %t65 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 11
  %t66 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t66, ptr %t65
  %t67 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 12
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %t67
  %t69 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 13
  %t70 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t70, ptr %t69
  %t71 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 14
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %t71
  %t73 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 15
  %t74 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t74, ptr %t73
  %t75 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 16
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %t75
  %t77 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 17
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %t77
  %t79 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 18
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %t79
  %t81 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 19
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %t81
  %t83 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 20
  %t84 = load %"std/prelude/text:StringBuilder", ptr %l21
  store %"std/prelude/text:StringBuilder" %t84, ptr %t83
  %t85 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 21
  %t86 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l22
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t86, ptr %t85
  %t87 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 22
  %t88 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l23
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t88, ptr %t87
  %t89 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 23
  %t90 = load i1, ptr %l24, !tbaa !21
  store i1 %t90, ptr %t89, !tbaa !21
  %t91 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t42, ptr %t91
  %t93 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 25
  %t94 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t94, ptr %t93, !tbaa !27
  %t95 = getelementptr %"compiler/bindgen:gen", ptr %l49, i32 0, i32 26
  store i64 0, ptr %t95, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l49, i64 1128, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"||" }>, align 8
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&&" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"^" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"==" }>, align 8
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!=" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"<=" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">=" }>, align 8
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"<<" }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">>" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"+" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d22 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" != 0)" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(1 if " }>, align 8
@.d27 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" else 0)" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"its body is empty where an expression is wanted" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d32 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a ( with no )" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d33 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"it holds text where an expression is wanted" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_34(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %vc0, { i64, ptr } %a0, { i64, ptr } %cv0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"it calls " }>, align 8
@.d43 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c", which is no function of numbers here" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d47 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"its call of " }>, align 8
@.d48 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" is not read" }>, align 8
@.d49 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d51 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d52 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"it names " }>, align 8
@.d53 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", which has no value here" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [11 x { i64, ptr }] }> <{ i64 0, [11 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d300, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d301, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d302, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d303, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d304, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d305, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d306, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d307, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d308, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d309, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d310, i32 0, i32 1) }] }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d60 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"const" }>, align 8
@.d64 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"volatile" }>, align 8
@.d65 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"restrict" }>, align 8
@.d66 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"__restrict" }>, align 8
@.d67 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"const" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d76 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d79 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d85 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"it takes a variable number of arguments" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/bindgen:record"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 176, i1 false)
  %t2 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 4
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

@.d86 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d87 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct " }>, align 8
@.d88 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"union " }>, align 8
@.d89 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"a typedef that names itself" }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d93 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"', which is no C type read here" }>, align 8
@.d94 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d95 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"# " }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d97 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5C\5C" }>, align 8
@.d98 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\5C" }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d101 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"#undef " }>, align 8
@.d102 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d103 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"#define " }>, align 8
@.d104 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d105 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d106 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d107 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d108 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d109 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d110 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d111 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"tagUsed" }>, align 8
@.d112 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"union" }>, align 8
@.d113 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d114 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d115 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"id" }>, align 8
@.d116 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"union " }>, align 8
@.d117 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct " }>, align 8
@.d118 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"completeDefinition" }>, align 8
@.d119 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d120 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"TransparentUnionAttr" }>, align 8
@.d121 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"RecordDecl" }>, align 8
@.d122 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d123 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"FieldDecl" }>, align 8
@.d124 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"isBitfield" }>, align 8
@.d125 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d126 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d127 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" struct() {\0A" }>, align 8
@.d128 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d129 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d130 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d131 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d132 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"    bytes := Array<" }>, align 8
@.d133 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">(" }>, align 8
@.d134 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c")\0A}\0A" }>, align 8
@.d135 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d136 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d137 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" := Array<" }>, align 8
@.d138 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">(" }>, align 8
@.d139 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d140 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d141 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d142 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d143 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d144 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d145 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"includedFrom" }>, align 8
@.d146 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"file" }>, align 8
@.d147 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d148 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d149 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d150 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"const" }>, align 8
@.d151 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"volatile" }>, align 8
@.d152 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"restrict" }>, align 8
@.d153 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"__restrict" }>, align 8
@.d154 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"signed" }>, align 8
@.d155 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"unsigned" }>, align 8
@.d156 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"long" }>, align 8
@.d157 = private constant <{ i64, [11 x { i64, ptr }] }> <{ i64 0, [11 x { i64, ptr }] [{ i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d304, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d300, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d305, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d306, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d307, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d311, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d308, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d312, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d313, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d314, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d315, i32 0, i32 1) }] }>, align 8
@.d158 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"int" }>, align 8
@.d159 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"struct" }>, align 8
@.d160 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d161 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"union" }>, align 8
@.d162 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"enum" }>, align 8
@.d163 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d164 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d165 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d166 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"enum" }>, align 8
@.d167 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d168 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d169 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d170 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d171 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d172 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"', a " }>, align 8
@.d173 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c" with no name of its own, or the C compiler's" }>, align 8
@.d174 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d175 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d176 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d177 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" with no name" }>, align 8
@.d178 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d179 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d180 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d181 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d182 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"', a type no declaration names" }>, align 8
@.d183 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d184 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d185 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a struct by value that is not plain data (X11)" }>, align 8
@.d186 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"CStr?&" }>, align 8
@.d187 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d188 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d189 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d190 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d191 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"a pointer to plain-data struct " }>, align 8
@.d192 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c" as a result - an extern gives only an extern type's reference (X2)" }>, align 8
@.d193 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"CVoid?&" }>, align 8
@.d194 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a value of this type, which has no olang form" }>, align 8
@.d195 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d196 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c_" }>, align 8
@.d197 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d198 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c"static or inline, and taking a variable number of arguments" }>, align 8
@.d199 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d200 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"static or inline, its result's type no olang form wraps" }>, align 8
@.d201 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"olang_ci_" }>, align 8
@.d202 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d203 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d204 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d205 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d206 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d207 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__typeof__(" }>, align 8
@.d208 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c") olang_a" }>, align 8
@.d209 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c") { " }>, align 8
@.d210 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d211 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"return " }>, align 8
@.d212 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d213 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d214 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang_a" }>, align 8
@.d215 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"); }\0A" }>, align 8
@.d216 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c": a name olang cannot declare (a keyword, or beginning with '_')" }>, align 8
@.d217 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c": a name every olang module has already" }>, align 8
@.d218 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c": static or inline in the header - no symbol to link" }>, align 8
@.d219 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c": static in its file - C's own to that file" }>, align 8
@.d220 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d221 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d222 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d223 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d224 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d225 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d226 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"# symbol " }>, align 8
@.d227 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d228 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d229 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"    type " }>, align 8
@.d230 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d231 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d232 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\0Aextern {\0A" }>, align 8
@.d233 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d234 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d235 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d236 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d237 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d238 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"\0A# not declared:\0A" }>, align 8
@.d239 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"#   " }>, align 8
@.d240 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d241 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d242 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d243 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"olang: bindgen needs clang, which is not on the PATH\0A" }>, align 8
@.d244 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d245 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c": no such file\0A" }>, align 8
@.d246 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d247 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c": no such file\0A" }>, align 8
@.d248 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d249 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang-bindgen" }>, align 8
@.d250 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"olang: bindgen: cannot make a temporary directory\0A" }>, align 8
@.d251 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"probe.c" }>, align 8
@.d252 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"#include \22" }>, align 8
@.d253 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d254 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d255 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"olang: bindgen: cannot write " }>, align 8
@.d256 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d257 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-E" }>, align 8
@.d258 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-dD" }>, align 8
@.d259 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d260 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d261 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-w" }>, align 8
@.d262 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"olang: bindgen: clang could not be run\0A" }>, align 8
@.d263 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"olang: bindgen: clang could not read " }>, align 8
@.d264 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d265 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d266 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"enum __olang_m" }>, align 8
@.d267 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" : long long { __olang_v" }>, align 8
@.d268 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" = (" }>, align 8
@.d269 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c") };\0A" }>, align 8
@.d270 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"olang: bindgen: cannot write " }>, align 8
@.d271 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d272 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"olang: bindgen: clang could not read " }>, align 8
@.d273 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d274 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d275 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d276 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d277 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d278 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"__olang_m" }>, align 8
@.d279 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d280 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"olang: bindgen: clang could not read " }>, align 8
@.d281 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d282 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d283 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"# Generated by olang bindgen from " }>, align 8
@.d284 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d285 = private constant <{ i64, [104 x i8] }> <{ i64 0, [104 x i8] c"# its C declarations as olang declares them (X1-X21) - write the library they are in after \22extern\22, as\0A" }>, align 8
@.d286 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"# 'extern link \22NAME\22 {' (X9), or import the header itself (X17).\0A" }>, align 8
@.d287 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d288 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d289 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d290 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d291 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d292 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"type" }>, align 8
@.d293 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d294 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"qualType" }>, align 8
@.d295 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"CVoid?&" }>, align 8
@.d296 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"mut CVoid?&" }>, align 8
@.d297 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d298 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d299 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d300 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"int" }>, align 8
@.d301 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"unsigned" }>, align 8
@.d302 = private unnamed_addr constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"signed" }>, align 8
@.d303 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"long" }>, align 8
@.d304 = private unnamed_addr constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"short" }>, align 8
@.d305 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d306 = private unnamed_addr constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d307 = private unnamed_addr constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d308 = private unnamed_addr constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_Bool" }>, align 8
@.d309 = private unnamed_addr constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"const" }>, align 8
@.d310 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"volatile" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d311 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d312 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bool" }>, align 8
@.d313 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_Float16" }>, align 8
@.d314 = private unnamed_addr constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"__bf16" }>, align 8
@.d315 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__int128" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_760c7c7ac1a62521_16c6052ca99c0395 = external constant [0 x i8]
@olang_loc_e777242b492df290_2cbbd43a2df6cacc = external constant [0 x i8]
@olang_loc_aa3527431bc6906d_d98aa20bf76f5ef9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_5d1582c4176ede0e_4f5ef5c07175765a = external constant [0 x i8]
@olang_loc_c1a7519d080599a4_d00fb28b8b3fdec0 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, i1 %a4, i64 %a5)
@G_2ecompiler_2fbindgen_2eKBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
@G_2ecompiler_2fbindgen_2eKVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbindgen_2eKType = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbindgen_2eKFloat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbindgen_2eKInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNumber(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eFindIndex_3cstd_2f_H0cdaf28864c9da4990596b1986b376a0(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eRefMut_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %a0)
declare %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fbindgen_2epreludeName(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emacroFn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd80cb4cbc6ceb8a13686fbc19b8451b4(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H116ed76223103781f5a7340c80f3d0f3(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %a0)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecord(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epointerParam(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2)
declare %"compiler/bindgen:ctp" @compiler_2fbindgen_3actp_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_beacd36cd332827c_e461632e30adb8c0 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
@olang_loc_88bbbdba37ecb069_7556c3a5c9bf841d = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eRefMu_H9d4ce036ca8f6276b6798968f53e8eb9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_a6c60cdff876254a_2c918d2d7b99843e = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
@olang_loc_5755e6dd02fca827_178a482bfa1e95bb = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_4153d023000ff8e8_6b17d300a1e811b4 = external constant [0 x i8]
@olang_loc_ec020a578bdf64c5_799d4029e88195a1 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_642a74ef72af54a6_43680c0161c24f22 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fbindgen_2ecLex(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/bindgen:cMacro" @compiler_2fbindgen_3acMacro_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, i1 %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eSetAt_H7935c3ba4e105e8cc692de439d360efe(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/bindgen:cMacro" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2ePush_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:cMacro" %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fbindgen_3arecord_2ector(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ePush_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fbindgen_2eflag(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbindgen_2einner(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %a0)
@olang_loc_c54e19abcb0a74ad_a74456fc2d527de1 = external constant [0 x i8]
@olang_loc_302d290203cc94fc_f1ac1451fbe7e850 = external constant [0 x i8]
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enumType(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisByte(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_383dad6bbc51ebc3_b2d1cf432887049f = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbindgen_2eresultText(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %a0)
declare %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efunction(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
@olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2 = external constant [0 x i8]
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eintMacros(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_2d25c1a9d7803e60_587b957d3d0d6154 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edump(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
@olang_loc_6d7a361a7a168fed_fbeb1a267b83d779 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eotherConsts(ptr %v0, ptr %a0)
@olang_loc_3c31d34710cd488e_9478fba938690442 = external constant [0 x i8]
declare i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2esizes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_433ff8d12b25a21d_ce9dc62322af2169 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
