; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/map:MapEntry.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" = type { { i64, ptr }, i64, ptr }
%"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8" = type { %"std/prelude/map:MapEntry.d0636885f2b44490dbc61e56fa468a20", ptr }
%"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425" = type { %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0", ptr }
%"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" = type { { i64, [2 x i64] }, i1 }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/lower:collectCtx" = type { i32, i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/lower:level" = type { i32, i32, i32 }
%"compiler/lower:loopCtx" = type { i32, i64, i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:pl" = type { { i64, [2 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:tryCtx" = type { i64, { i64, ptr }, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
define dso_local { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_H1e3bc46345ebb5614acbe688055fe55f(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__Hbe724e949204db7f54e3bca969c5f391(ptr %v0, ptr %a0, i64 %a1)
  ret { i32, i32 } %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_H6363fee5e3f1c076b4ec00933ab48c6c(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__H7ddd7dd10a6733ce5265405d8e7c8faa(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
  ret void
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_Hf0fb0e232c68e27195d0770621b0035a(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l24 = alloca %"std/prelude/map:MapEntry.d0636885f2b44490dbc61e56fa468a20"
  %l28 = alloca { i64, ptr }
  %l41 = alloca ptr
  %rv = alloca i1
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %t6, i64 %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store ptr null, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.d0636885f2b44490dbc61e56fa468a20", ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = icmp eq i64 %t35, %t36
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = getelementptr %"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8", ptr %t41, i32 0, i32 0
  %t44 = load %"std/prelude/map:MapEntry.d0636885f2b44490dbc61e56fa468a20", ptr %t43
  store %"std/prelude/map:MapEntry.d0636885f2b44490dbc61e56fa468a20" %t44, ptr %l24
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb8, label %bb9
bb7:
  br label %bb11
bb8:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t49, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l28, !tbaa !27
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t56 = getelementptr %"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t60 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t53
  store ptr %t57, ptr %t62, !tbaa !39
  br label %bb10
bb9:
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t70 = getelementptr %"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8", ptr %t63, i32 0, i32 1
  store ptr %t67, ptr %t70, !tbaa !29
  br label %bb10
bb10:
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t72, i32 0, i32 2
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8", ptr %t71, i32 0, i32 1
  store ptr %t75, ptr %t78, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t79, i32 0, i32 2
  store ptr %t80, ptr %t84, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  store ptr %t85, ptr %l41, !tbaa !29
  %t86 = load ptr, ptr %l41, !tbaa !29
  %t87 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t86, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = sub i64 %t88, 1
  %t92 = load ptr, ptr %l41, !tbaa !29
  %t93 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t92, i32 0, i32 1
  store i64 %t90, ptr %t93, !tbaa !24
  store i1 true, ptr %rv
  br label %ret
bb11:
  %t95 = load ptr, ptr %l5, !tbaa !29
  store ptr %t95, ptr %l4, !tbaa !29
  br label %bb12
bb12:
  %t98 = load ptr, ptr %l5, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l5, !tbaa !29
  br label %bb2
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l20 = alloca { i64, [2 x i64] }
  %l22 = alloca { i64, [2 x i64] }
  %l24 = alloca i1
  store { i64, [2 x i64] } %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load { i64, [2 x i64] }, ptr %l1
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fmir_3aFnKey_2c_20Bool__Hfa6865c8834dc33557c583d1505071de(ptr %v0, ptr %t6, { i64, [2 x i64] } %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0", ptr %t33, i32 0, i32 0
  %t35 = load { i64, [2 x i64] }, ptr %t34
  store { i64, [2 x i64] } %t35, ptr %l20
  %t36 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t36, ptr %l22
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aFnKey(ptr %l20, ptr %l22)
  store i1 %t39, ptr %l24
  br label %bb6
bb6:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i1, ptr %l2, !tbaa !21
  %t45 = getelementptr %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0", ptr %t45, i32 0, i32 1
  store i1 %t42, ptr %t46, !tbaa !21
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb11:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load { i64, [2 x i64] }, ptr %l1
  %t55 = load i1, ptr %l2, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fmir_3aFnKey_2c_20Bool__H015927b51aa0b85b95ba68dbcd62667c(ptr %v0, ptr %t52, i64 %t53, { i64, [2 x i64] } %t54, i1 %t55)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca { i64, [2 x i64] }
  %l19 = alloca { i64, [2 x i64] }
  %l21 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load { i64, [2 x i64] }, ptr %l1
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fmir_3aFnKey_2c_20Bool__Hfa6865c8834dc33557c583d1505071de(ptr %v0, ptr %t10, { i64, [2 x i64] } %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0", ptr %t31, i32 0, i32 0
  %t33 = load { i64, [2 x i64] }, ptr %t32
  store { i64, [2 x i64] } %t33, ptr %l17
  %t34 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t34, ptr %l19
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aFnKey(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2fmir_3aLocalId_H8044eb1bb41240dd17411380d1d5f7b5(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aDeclI_H4c1de9fecd9c99d5a63a8f7c9df161c3(ptr %v0, ptr %a0)
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2fmir_3aLocalId_Hd0ceeedbd415848d3f017da866743547(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2fmir_3aLocalId_He97200f31d77c66301812135164be449(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aDeclI_H9f3979565f0fefdf5266a328cdc0c138(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3)
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fmir_3aFnKey_2c_20Bool__H015927b51aa0b85b95ba68dbcd62667c(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i1
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load { i64, [2 x i64] }, ptr %l2
  %t16 = load i1, ptr %l3, !tbaa !21
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0, ptr %v0, { i64, [2 x i64] } %t15, i1 %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425" %t30, ptr %l18
  br label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load { i64, [2 x i64] }, ptr %l2
  %t41 = load i1, ptr %l3, !tbaa !21
  %t44 = call %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %s2, { i64, [2 x i64] } %t40, i1 %t41)
  store %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  call void @__olang_scope_close(ptr %s2)
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fmir_3aFnKey_2c_20Bool__H621975be5d2deed5608f24e85d225094(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fmir_3aFnKey_2c_20Bool__H621975be5d2deed5608f24e85d225094(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_cfd59561ea775d8d_fb7a12cd355158c1)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_cfd59561ea775d8d_fb7a12cd355158c1)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0", ptr %t100, i32 0, i32 0
  %t102 = load { i64, [2 x i64] }, ptr %t101
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fmir_3aFnKey_2c_20Bool__Hfa6865c8834dc33557c583d1505071de(ptr %v0, ptr %t97, { i64, [2 x i64] } %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  br label %bb20
bb20:
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fmir_3aFnKey_2c_20Bool__Hfa6865c8834dc33557c583d1505071de(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l2 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } %a1, ptr %l2
  %t3 = call i64 @olang_2eHelperKind_2eHash_2ecompiler_2fmir_3aFnKey(ptr %l2)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %a0, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = sub i64 %t9, 1
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = and i64 %t12, %t11
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/map:MapEntry.d0636885f2b44490dbc61e56fa468a20" @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2ector(ptr %v0, i64 %a0, i32 %a1) #0 {
entry:
  %r = tail call %"std/prelude/map:MapEntry.d0636885f2b44490dbc61e56fa468a20" @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0, i64 %a0, i32 %a1)
  ret %"std/prelude/map:MapEntry.d0636885f2b44490dbc61e56fa468a20" %r
}

define dso_local %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0, { i64, [2 x i64] } %a0, i1 %a1) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" undef, { i64, [2 x i64] } %a0, 0
  %t8 = insertvalue %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" %t6, i1 %a1, 1
  store %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0", ptr %rv
  ret %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" %rr
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8" @std_2fprelude_2fmap_3amapSlot_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, ptr %a2) #0 {
entry:
  %r = tail call %"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8" @std_2fprelude_2fmap_3amapSlot_3cI64_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, ptr %a2)
  ret %"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8" %r
}

define dso_local %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0, ptr %v1, { i64, [2 x i64] } %a0, i1 %a1, ptr %a2) #0 {
entry:
  %l7 = alloca %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0"
  %rv = alloca %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v1, { i64, [2 x i64] } %a0, i1 %a1)
  store %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0", ptr %l7
  %t10 = insertvalue %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425" undef, %"std/prelude/map:MapEntry.033938f0d277fb4f29f5816905973be0" %t6, 0
  %t12 = insertvalue %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425" %t10, ptr %a2, 1
  store %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425", ptr %rv
  ret %"std/prelude/map:mapSlot.f0b8b34b4e30bc2389eabed4b3924425" %rr
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/free:leaf", ptr %t11, i64 %a1
  %t13 = load %"compiler/free:leaf", ptr %t12
  store %"compiler/free:leaf" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local %"compiler/lower:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2eAt_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/lower:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/lower:Gap", ptr %t11, i64 %a1
  %t13 = load %"compiler/lower:Gap", ptr %t12
  store %"compiler/lower:Gap" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:Gap", ptr %rv
  ret %"compiler/lower:Gap" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:Gap" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3aGap_3e_2eroom_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/lower:Gap", ptr %t41, i64 %t36
  store %"compiler/lower:Gap" %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:collectCtx" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2eAt__Hce97d3b6a95327627873f207e844a422(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/lower:collectCtx"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/lower:collectCtx", ptr %t11, i64 %a1
  %t13 = load %"compiler/lower:collectCtx", ptr %t12
  store %"compiler/lower:collectCtx" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:collectCtx", ptr %rv
  ret %"compiler/lower:collectCtx" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2eLen_H6eade83fd48a7a0e84be67fdfc468e69(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, %"compiler/lower:collectCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2ePop_He1200c0c51a1e2029459d9d8221d233c(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca { i64, ptr }
  %rv = alloca { i32, %"compiler/lower:collectCtx" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, %"compiler/lower:collectCtx" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/lower:collectCtx" } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = sub i64 %t18, 1
  %t22 = load ptr, ptr %l8, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i32 0, i32 1
  store i64 %t20, ptr %t23, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/lower:collectCtx", ptr %t34, i64 %t31
  %t36 = load %"compiler/lower:collectCtx", ptr %t35
  %t38 = insertvalue { i32, %"compiler/lower:collectCtx" } zeroinitializer, %"compiler/lower:collectCtx" %t36, 1
  store { i32, %"compiler/lower:collectCtx" } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/lower:collectCtx" }, ptr %rv
  ret { i32, %"compiler/lower:collectCtx" } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2ePus_Hd0ab7b9373bf150d973fdf7c33c4c364(ptr %v0, ptr %a0, %"compiler/lower:collectCtx" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3acollectCtx_3e__H2adadccb07957b4d41eff88c331d3add(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/lower:collectCtx", ptr %t41, i64 %t36
  store %"compiler/lower:collectCtx" %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/lower:level"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/lower:level", ptr %t11, i64 %a1
  %t13 = load %"compiler/lower:level", ptr %t12
  store %"compiler/lower:level" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:level", ptr %rv
  ret %"compiler/lower:level" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, %"compiler/lower:level" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca { i64, ptr }
  %rv = alloca { i32, %"compiler/lower:level" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, %"compiler/lower:level" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/lower:level" } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = sub i64 %t18, 1
  %t22 = load ptr, ptr %l8, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i32 0, i32 1
  store i64 %t20, ptr %t23, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/lower:level", ptr %t34, i64 %t31
  %t36 = load %"compiler/lower:level", ptr %t35
  %t38 = insertvalue { i32, %"compiler/lower:level" } zeroinitializer, %"compiler/lower:level" %t36, 1
  store { i32, %"compiler/lower:level" } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/lower:level" }, ptr %rv
  ret { i32, %"compiler/lower:level" } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, %"compiler/lower:level" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3alevel_3e_2eroom_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/lower:level", ptr %t41, i64 %t36
  store %"compiler/lower:level" %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:loopCtx" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eAt_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/lower:loopCtx"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/lower:loopCtx", ptr %t11, i64 %a1
  %t13 = load %"compiler/lower:loopCtx", ptr %t12
  store %"compiler/lower:loopCtx" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:loopCtx", ptr %rv
  ret %"compiler/lower:loopCtx" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, %"compiler/lower:loopCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ePop_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca { i64, ptr }
  %rv = alloca { i32, %"compiler/lower:loopCtx" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, %"compiler/lower:loopCtx" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/lower:loopCtx" } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = sub i64 %t18, 1
  %t22 = load ptr, ptr %l8, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i32 0, i32 1
  store i64 %t20, ptr %t23, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/lower:loopCtx", ptr %t34, i64 %t31
  %t36 = load %"compiler/lower:loopCtx", ptr %t35
  %t38 = insertvalue { i32, %"compiler/lower:loopCtx" } zeroinitializer, %"compiler/lower:loopCtx" %t36, 1
  store { i32, %"compiler/lower:loopCtx" } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/lower:loopCtx" }, ptr %rv
  ret { i32, %"compiler/lower:loopCtx" } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ePush_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:loopCtx" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3aloopCtx_3e_2er_H8f4f43bca9544e6f1438d2167a8759b4(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/lower:loopCtx", ptr %t41, i64 %t36
  store %"compiler/lower:loopCtx" %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:pl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2eAt_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/lower:pl"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/lower:pl", ptr %t11, i64 %a1
  %t13 = load %"compiler/lower:pl", ptr %t12
  store %"compiler/lower:pl" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2eLen_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, %"compiler/lower:pl" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2ePop_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca { i64, ptr }
  %rv = alloca { i32, %"compiler/lower:pl" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, %"compiler/lower:pl" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/lower:pl" } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = sub i64 %t18, 1
  %t22 = load ptr, ptr %l8, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i32 0, i32 1
  store i64 %t20, ptr %t23, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/lower:pl", ptr %t34, i64 %t31
  %t36 = load %"compiler/lower:pl", ptr %t35
  %t38 = insertvalue { i32, %"compiler/lower:pl" } zeroinitializer, %"compiler/lower:pl" %t36, 1
  store { i32, %"compiler/lower:pl" } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/lower:pl" }, ptr %rv
  ret { i32, %"compiler/lower:pl" } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2ePush_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3apl_3e_2eroom_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/lower:pl", ptr %t41, i64 %t36
  store %"compiler/lower:pl" %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:tryCtx" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/lower:tryCtx"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/lower:tryCtx", ptr %t11, i64 %a1
  %t13 = load %"compiler/lower:tryCtx", ptr %t12
  store %"compiler/lower:tryCtx" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:tryCtx", ptr %rv
  ret %"compiler/lower:tryCtx" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca { i64, ptr }
  %rv = alloca { i32, %"compiler/lower:tryCtx" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, %"compiler/lower:tryCtx" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/lower:tryCtx" } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = sub i64 %t18, 1
  %t22 = load ptr, ptr %l8, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i32 0, i32 1
  store i64 %t20, ptr %t23, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/lower:tryCtx", ptr %t34, i64 %t31
  %t36 = load %"compiler/lower:tryCtx", ptr %t35
  %t38 = insertvalue { i32, %"compiler/lower:tryCtx" } zeroinitializer, %"compiler/lower:tryCtx" %t36, 1
  store { i32, %"compiler/lower:tryCtx" } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/lower:tryCtx" }, ptr %rv
  ret { i32, %"compiler/lower:tryCtx" } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:tryCtx" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3atryCtx_3e_2ero_Hbc88604c94321611a4366a5a0246a5c5(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/lower:tryCtx", ptr %t41, i64 %t36
  store %"compiler/lower:tryCtx" %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
  ret i32 %r
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eSetAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
  ret void
}

define dso_local { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, [2 x i64] } %r
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
  ret void
}

define dso_local i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
  ret i32 %r
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
  ret void
}

define dso_local %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/mir:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/mir:Local", ptr %t11, i64 %a1
  %t13 = load %"compiler/mir:Local", ptr %t12
  store %"compiler/mir:Local" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Local", ptr %rv
  ret %"compiler/mir:Local" %rr
}

define dso_local { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, [4 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t11, i64 %a1
  %t13 = load { i64, [4 x i64] }, ptr %t12
  store { i64, [4 x i64] } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aOperand_3e_2eroom_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i64 %t36
  store { i64, [4 x i64] } %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eToArray_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, [4 x i64] }
  %l31 = alloca i64
  %l34 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t48 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t13 = icmp sle i64 0, 230584300921369395
  br i1 %t13, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e830083477ac3acf_e07c8e26dbb2717b)
  unreachable
bb5:
  %t15 = mul i64 0, 40
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e830083477ac3acf_e07c8e26dbb2717b)
  unreachable
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l20, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t35, i64 0
  %t37 = load { i64, [4 x i64] }, ptr %t36
  store { i64, [4 x i64] } %t37, ptr %l21
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t41, 230584300921369395
  br i1 %t42, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_3e36132a3052637a_18572711d0b9c0e6)
  unreachable
bb10:
  %t44 = load i64, ptr %l17, !tbaa !24
  %t45 = mul i64 %t44, 40
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = load { i64, [4 x i64] }, ptr %l21
  store i64 0, ptr %t48
  br label %fill.49
fill.49:
  %t52 = load i64, ptr %t48
  %t53 = icmp slt i64 %t52, %t44
  br i1 %t53, label %fillb.50, label %filld.51
fillb.50:
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t46, i64 %t52
  store { i64, [4 x i64] } %t47, ptr %t54
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %t48
  br label %fill.49
filld.51:
  %t56 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t46, 1
  store { i64, ptr } %t57, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_3e36132a3052637a_18572711d0b9c0e6)
  unreachable
bb12:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb17
bb14:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l34, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb16
bb16:
  %t93 = load i64, ptr %l34, !tbaa !24
  store i64 %t93, ptr %l31, !tbaa !24
  br label %bb17
bb17:
  %t94 = load i64, ptr %l31, !tbaa !24
  store i64 %t94, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t103 = load i64, ptr %l2, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  store i64 %t111, ptr %l7, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t118, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l56, !tbaa !27
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t125, i64 %t122
  %t127 = load { i64, [4 x i64] }, ptr %t126
  %t130 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t131, i64 %t114
  store { i64, [4 x i64] } %t127, ptr %t132
  br label %bb22
bb22:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb18
bb23:
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, [1 x i64] } %r
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eToArray_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eToArray_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %v1, ptr %a0)
  ret { i64, ptr } %r
}

define dso_local i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
  ret i32 %r
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
  ret { i32, i32 } %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
  ret void
}

define dso_local %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/mir:ScopeInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/mir:ScopeInfo", ptr %t11, i64 %a1
  %t13 = load %"compiler/mir:ScopeInfo", ptr %t12
  store %"compiler/mir:ScopeInfo" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:ScopeInfo", ptr %rv
  ret %"compiler/mir:ScopeInfo" %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ePush_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eToArray_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eToArray_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %v1, ptr %a0)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
  ret void
}

define dso_local ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2eAt_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  ret ptr %r
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eLen_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2ePop_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %r = tail call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H30b952b85dc190b6cd5306b9d98a7749(ptr %v0, ptr %v1, ptr %a0)
  ret { i32, ptr } %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2ePush_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/typed:Plan"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/typed:Plan", ptr %t11, i64 %a1
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t12, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l6, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3aGap_3e_2eroom_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e3b1df08dc6ab325_9af88a564d3137f9)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e3b1df08dc6ab325_9af88a564d3137f9)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/lower:Gap", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 32
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e3b1df08dc6ab325_9af88a564d3137f9)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/lower:Gap", ptr %t105, i64 %t102
  %t107 = load %"compiler/lower:Gap", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/lower:Gap", ptr %t111, i64 %t109
  store %"compiler/lower:Gap" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3acollectCtx_3e__H2adadccb07957b4d41eff88c331d3add(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_64c57e6f11dc5da7_aea7c02f240fa33b)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_64c57e6f11dc5da7_aea7c02f240fa33b)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/lower:collectCtx", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 40
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_64c57e6f11dc5da7_aea7c02f240fa33b)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/lower:collectCtx", ptr %t105, i64 %t102
  %t107 = load %"compiler/lower:collectCtx", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/lower:collectCtx", ptr %t111, i64 %t109
  store %"compiler/lower:collectCtx" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3alevel_3e_2eroom_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_445704ad4e625289_659f29daaa5cb46d)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_445704ad4e625289_659f29daaa5cb46d)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/lower:level", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 12
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_445704ad4e625289_659f29daaa5cb46d)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/lower:level", ptr %t105, i64 %t102
  %t107 = load %"compiler/lower:level", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/lower:level", ptr %t111, i64 %t109
  store %"compiler/lower:level" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3aloopCtx_3e_2er_H8f4f43bca9544e6f1438d2167a8759b4(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_ca5757a0a1611cb6_cb63e742dbeb9b6a)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_ca5757a0a1611cb6_cb63e742dbeb9b6a)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/lower:loopCtx", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 40
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_ca5757a0a1611cb6_cb63e742dbeb9b6a)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/lower:loopCtx", ptr %t105, i64 %t102
  %t107 = load %"compiler/lower:loopCtx", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/lower:loopCtx", ptr %t111, i64 %t109
  store %"compiler/lower:loopCtx" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3apl_3e_2eroom_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_5ad199e3f58ced57_5212be7b307f348b)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_5ad199e3f58ced57_5212be7b307f348b)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/lower:pl", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 32
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_5ad199e3f58ced57_5212be7b307f348b)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/lower:pl", ptr %t105, i64 %t102
  %t107 = load %"compiler/lower:pl", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/lower:pl", ptr %t111, i64 %t109
  store %"compiler/lower:pl" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2flower_3atryCtx_3e_2ero_Hbc88604c94321611a4366a5a0246a5c5(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_bdfa7a258d24c5b6_82d0626f7d148f5a)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_bdfa7a258d24c5b6_82d0626f7d148f5a)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/lower:tryCtx", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 40
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_bdfa7a258d24c5b6_82d0626f7d148f5a)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/lower:tryCtx", ptr %t105, i64 %t102
  %t107 = load %"compiler/lower:tryCtx", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/lower:tryCtx", ptr %t111, i64 %t109
  store %"compiler/lower:tryCtx" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aBlockId_3e_2eroom_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cI32_3e_2eroom_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aFnKey_3e_2eroom_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aTerm_3e_2eroom_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aLocalId_3e_2eroom_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cI32_3e_2eroom_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aOperand_3e_2eroom_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_54f6e289da4d1929_d301f3d774aac6ed)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_54f6e289da4d1929_d301f3d774aac6ed)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 40
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_54f6e289da4d1929_d301f3d774aac6ed)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t105, i64 %t102
  %t107 = load { i64, [4 x i64] }, ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t111, i64 %t109
  store { i64, [4 x i64] } %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aProj_3e_2eroom_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aScope_3e_2eroom_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aScopeId_3e_2eroom_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cI32_3e_2eroom_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aScopeRef_3e_2ero_H3ba9d6eb1a75e385a33b18dabe328c43(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aScope_3e_2eroom_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aVarKind_3e_2eroom_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aScope_3e_2eroom_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aBlock_26_3e_2e_Hbce976282962e801a2b868b6a862ed61(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcond_3aGlobal_26_3e_2e_Hb4cb47390ad0ef69ab85fecf589dd168(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aLocalId_3e_2er_Hde4562f0ad8b582b9e091f421cd1fafc(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cI32_3e_2eroom_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2flower_3aGap_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2flower_3acollectCtx_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2flower_3alevel_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2flower_3aloopCtx_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2flower_3apl_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2flower_3atryCtx_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aBlock_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aFnKey(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb17
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 0, label %bb4 i64 1, label %bb5 i64 2, label %bb6 i64 3, label %bb7 i64 4, label %bb8 ]
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb9, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i32, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i32 }, ptr %t27, i32 0, i32 0
  %t29 = load i32, ptr %t28
  %t32 = icmp eq i32 %t25, %t29
  br i1 %t32, label %bb10, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32, i32 }, ptr %t35, i32 0, i32 0
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 1
  %t39 = getelementptr { i32, i32 }, ptr %t38, i32 0, i32 0
  %t42 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aHelperKind(ptr %t36, ptr %t39)
  store i1 %t42, ptr %l14
  br label %bb11
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr { i64, [2 x i64] }, ptr %t43, i32 0, i32 1
  %t45 = getelementptr { i64 }, ptr %t44, i32 0, i32 0
  %t46 = load i64, ptr %t45
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 1
  %t49 = getelementptr { i64 }, ptr %t48, i32 0, i32 0
  %t50 = load i64, ptr %t49
  %t53 = icmp eq i64 %t46, %t50
  br i1 %t53, label %bb14, label %bb1
bb8:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr { i64, [2 x i64] }, ptr %t55, i32 0, i32 1
  %t57 = getelementptr { i64, i1 }, ptr %t56, i32 0, i32 0
  %t58 = load i64, ptr %t57
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [2 x i64] }, ptr %t59, i32 0, i32 1
  %t61 = getelementptr { i64, i1 }, ptr %t60, i32 0, i32 0
  %t62 = load i64, ptr %t61
  %t65 = icmp eq i64 %t58, %t62
  br i1 %t65, label %bb15, label %bb1
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  %t67 = load i1, ptr %l14, !tbaa !21
  br i1 %t67, label %bb12, label %bb1
bb12:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [2 x i64] }, ptr %t68, i32 0, i32 1
  %t70 = getelementptr { i32, i32 }, ptr %t69, i32 0, i32 1
  %t71 = load i32, ptr %t70
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [2 x i64] }, ptr %t72, i32 0, i32 1
  %t74 = getelementptr { i32, i32 }, ptr %t73, i32 0, i32 1
  %t75 = load i32, ptr %t74
  %t78 = icmp eq i32 %t71, %t75
  br i1 %t78, label %bb13, label %bb1
bb13:
  br label %bb3
bb14:
  br label %bb3
bb15:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr { i64, [2 x i64] }, ptr %t80, i32 0, i32 1
  %t82 = getelementptr { i64, i1 }, ptr %t81, i32 0, i32 1
  %t83 = load i1, ptr %t82
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [2 x i64] }, ptr %t84, i32 0, i32 1
  %t86 = getelementptr { i64, i1 }, ptr %t85, i32 0, i32 1
  %t87 = load i1, ptr %t86
  %t90 = icmp eq i1 %t83, %t87
  br i1 %t90, label %bb16, label %bb1
bb16:
  br label %bb3
bb17:
  %t92 = load i1, ptr %l2, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define linkonce_odr i64 @olang_2eHelperKind_2eHash_2ecompiler_2fmir_3aFnKey(ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = mul i64 %t3, -7046029254386353131
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = ashr i64 %t5, 29
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = xor i64 %t7, %t6
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = mul i64 %t10, 1099511628211
  %t14 = add i64 %t11, %t9
  store i64 %t14, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  switch i64 %t15, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 ]
bb1:
  %t16 = load i64, ptr %l1, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [2 x i64] }, ptr %t17, i32 0, i32 1
  %t19 = getelementptr { i32 }, ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t22 = call i64 @std_2fprelude_2fhash_2eI32_2eHash(i32 %t20)
  store i64 %t22, ptr %l8
  br label %bb7
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 1
  %t25 = getelementptr { i32 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  %t28 = call i64 @std_2fprelude_2fhash_2eI32_2eHash(i32 %t26)
  store i64 %t28, ptr %l11
  br label %bb8
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t29, i32 0, i32 1
  %t31 = getelementptr { i32, i32 }, ptr %t30, i32 0, i32 0
  %t33 = call i64 @olang_2eHelperKind_2eHash_2ecompiler_2fmir_3aHelperKind(ptr %t31)
  store i64 %t33, ptr %l14
  br label %bb9
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t39 = mul i64 %t37, -7046029254386353131
  store i64 %t39, ptr %l20, !tbaa !24
  %t40 = load i64, ptr %l20, !tbaa !24
  %t41 = ashr i64 %t40, 29
  %t42 = load i64, ptr %l20, !tbaa !24
  %t44 = xor i64 %t42, %t41
  %t45 = load i64, ptr %l1, !tbaa !24
  %t46 = mul i64 %t45, 1099511628211
  %t49 = add i64 %t46, %t44
  store i64 %t49, ptr %l1, !tbaa !24
  br label %bb1
bb6:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64, i1 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t55 = mul i64 %t53, -7046029254386353131
  store i64 %t55, ptr %l25, !tbaa !24
  %t56 = load i64, ptr %l25, !tbaa !24
  %t57 = ashr i64 %t56, 29
  %t58 = load i64, ptr %l25, !tbaa !24
  %t60 = xor i64 %t58, %t57
  %t61 = load i64, ptr %l1, !tbaa !24
  %t62 = mul i64 %t61, 1099511628211
  %t65 = add i64 %t62, %t60
  store i64 %t65, ptr %l1, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [2 x i64] }, ptr %t66, i32 0, i32 1
  %t68 = getelementptr { i64, i1 }, ptr %t67, i32 0, i32 1
  %t69 = load i1, ptr %t68
  %t71 = zext i1 %t69 to i64
  %t73 = mul i64 %t71, -7046029254386353131
  store i64 %t73, ptr %l31, !tbaa !24
  %t74 = load i64, ptr %l31, !tbaa !24
  %t75 = ashr i64 %t74, 29
  %t76 = load i64, ptr %l31, !tbaa !24
  %t78 = xor i64 %t76, %t75
  %t79 = load i64, ptr %l1, !tbaa !24
  %t80 = mul i64 %t79, 1099511628211
  %t83 = add i64 %t80, %t78
  store i64 %t83, ptr %l1, !tbaa !24
  br label %bb1
bb7:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = mul i64 %t84, 1099511628211
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t85, %t87
  store i64 %t88, ptr %l1, !tbaa !24
  br label %bb1
bb8:
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = mul i64 %t89, 1099511628211
  %t92 = load i64, ptr %l11, !tbaa !24
  %t93 = add i64 %t90, %t92
  store i64 %t93, ptr %l1, !tbaa !24
  br label %bb1
bb9:
  %t94 = load i64, ptr %l1, !tbaa !24
  %t95 = mul i64 %t94, 1099511628211
  %t97 = load i64, ptr %l14, !tbaa !24
  %t98 = add i64 %t95, %t97
  store i64 %t98, ptr %l1, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 1
  %t101 = getelementptr { i32, i32 }, ptr %t100, i32 0, i32 1
  %t102 = load i32, ptr %t101
  %t104 = call i64 @std_2fprelude_2fhash_2eI32_2eHash(i32 %t102)
  store i64 %t104, ptr %l17
  br label %bb10
bb10:
  %t105 = load i64, ptr %l1, !tbaa !24
  %t106 = mul i64 %t105, 1099511628211
  %t108 = load i64, ptr %l17, !tbaa !24
  %t109 = add i64 %t106, %t108
  store i64 %t109, ptr %l1, !tbaa !24
  br label %bb1
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aHelperKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr i64 @olang_2eHelperKind_2eHash_2ecompiler_2fmir_3aHelperKind(ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = mul i64 %t3, -7046029254386353131
  store i64 %t5, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = ashr i64 %t6, 29
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = xor i64 %t8, %t7
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = mul i64 %t11, 1099511628211
  %t15 = add i64 %t12, %t10
  store i64 %t15, ptr %l1, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__Hbe724e949204db7f54e3bca969c5f391(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__H7ddd7dd10a6733ce5265405d8e7c8faa(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aDeclI_H4c1de9fecd9c99d5a63a8f7c9df161c3(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aDeclI_H9f3979565f0fefdf5266a328cdc0c138(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3)
@olang_loc_cfd59561ea775d8d_fb7a12cd355158c1 = external constant [0 x i8]
declare %"std/prelude/map:MapEntry.d0636885f2b44490dbc61e56fa468a20" @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0, i64 %a0, i32 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/map:mapSlot.7dd09a11cac0bbedaa528ad5b8d8f0f8" @std_2fprelude_2fmap_3amapSlot_3cI64_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, ptr %a2)
declare %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_e830083477ac3acf_e07c8e26dbb2717b = external constant [0 x i8]
@olang_loc_3e36132a3052637a_18572711d0b9c0e6 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eToArray_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2eAt_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H30b952b85dc190b6cd5306b9d98a7749(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e3b1df08dc6ab325_9af88a564d3137f9 = external constant [0 x i8]
@olang_loc_64c57e6f11dc5da7_aea7c02f240fa33b = external constant [0 x i8]
@olang_loc_445704ad4e625289_659f29daaa5cb46d = external constant [0 x i8]
@olang_loc_ca5757a0a1611cb6_cb63e742dbeb9b6a = external constant [0 x i8]
@olang_loc_5ad199e3f58ced57_5212be7b307f348b = external constant [0 x i8]
@olang_loc_bdfa7a258d24c5b6_82d0626f7d148f5a = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cI32_3e_2eroom_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aTerm_3e_2eroom_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_54f6e289da4d1929_d301f3d774aac6ed = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aScope_3e_2eroom_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcond_3aGlobal_26_3e_2e_Hb4cb47390ad0ef69ab85fecf589dd168(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fhash_2eI32_2eHash(i32 %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
