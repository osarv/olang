; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"<sys/utsname.h>:utsname" = type { [65 x i8], [65 x i8], [65 x i8], [65 x i8], [65 x i8], [65 x i8] }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"std/os:FileInfo" = type { i32, i64, i64 }
@G_2ecompiler_2ftarget_2eArchCpuFlags = constant <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eArchCpuFlags.k1, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eArchCpuFlags.k2 }>, align 32
@G_2ecompiler_2ftarget_2eArchCpuFlags.k1 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\6D\61\72\63\68\3D" }>, align 8
@G_2ecompiler_2ftarget_2eArchCpuFlags.k2 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\6D\63\70\75\3D" }>, align 8
@G_2ecompiler_2ftarget_2eArchDefaultCpus = constant <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eArchDefaultCpus.k1, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eArchDefaultCpus.k2 }>, align 32
@G_2ecompiler_2ftarget_2eArchDefaultCpus.k1 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\78\38\36\2D\36\34" }>, align 8
@G_2ecompiler_2ftarget_2eArchDefaultCpus.k2 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\67\65\6E\65\72\69\63" }>, align 8
@G_2ecompiler_2ftarget_2eArchs = constant <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eArchs.k1, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eArchs.k2 }>, align 32
@G_2ecompiler_2ftarget_2eArchs.k1 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\78\38\36\5F\36\34" }>, align 8
@G_2ecompiler_2ftarget_2eArchs.k2 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\61\61\72\63\68\36\34" }>, align 8
@G_2ecompiler_2ftarget_2eClangs = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eClangs.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eClangs.k2, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eClangs.k3, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eClangs.k4 }>, align 64
@G_2ecompiler_2ftarget_2eClangs.k1 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6C\61\6E\67\2D\32\30" }>, align 8
@G_2ecompiler_2ftarget_2eClangs.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6C\61\6E\67\2D\31\39" }>, align 8
@G_2ecompiler_2ftarget_2eClangs.k3 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6C\61\6E\67\2D\31\38" }>, align 8
@G_2ecompiler_2ftarget_2eClangs.k4 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\63\6C\61\6E\67" }>, align 8
@G_2ecompiler_2ftarget_2eIeeeUnsafe = constant <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eIeeeUnsafe.k1, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eIeeeUnsafe.k2 }>, align 32
@G_2ecompiler_2ftarget_2eIeeeUnsafe.k1 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\61\76\78\35\31\32\62\66\31\36" }>, align 8
@G_2ecompiler_2ftarget_2eIeeeUnsafe.k2 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\61\76\78\6E\65\63\6F\6E\76\65\72\74" }>, align 8
@G_2ecompiler_2ftarget_2eLevelFlags = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\27\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eLevelFlags.k1, [8 x i8] c"\2B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eLevelFlags.k2, [8 x i8] c"\2B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eLevelFlags.k3 }>, align 32
@G_2ecompiler_2ftarget_2eLevelFlags.k1 = internal constant <{ [39 x i8] }> <{ [39 x i8] c"\63\78\31\36\20\6C\61\68\66\5F\6C\6D\20\70\6F\70\63\6E\74\20\73\73\65\34\5F\31\20\73\73\65\34\5F\32\20\73\73\73\65\33" }>, align 32
@G_2ecompiler_2ftarget_2eLevelFlags.k2 = internal constant <{ [43 x i8] }> <{ [43 x i8] c"\61\76\78\20\61\76\78\32\20\62\6D\69\31\20\62\6D\69\32\20\66\31\36\63\20\66\6D\61\20\61\62\6D\20\6D\6F\76\62\65\20\78\73\61\76\65" }>, align 32
@G_2ecompiler_2ftarget_2eLevelFlags.k3 = internal constant <{ [43 x i8] }> <{ [43 x i8] c"\61\76\78\35\31\32\66\20\61\76\78\35\31\32\62\77\20\61\76\78\35\31\32\63\64\20\61\76\78\35\31\32\64\71\20\61\76\78\35\31\32\76\6C" }>, align 32
@G_2ecompiler_2ftarget_2eSkylakeProbe = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\2C\01\00\00\00\00\00\00", ptr @G_2ecompiler_2ftarget_2eSkylakeProbe.k1 }>, align 8
@G_2ecompiler_2ftarget_2eSkylakeProbe.k1 = internal global <{ [300 x i8] }> <{ [300 x i8] c"\74\61\72\67\65\74\20\64\61\74\61\6C\61\79\6F\75\74\20\3D\20\22\65\2D\6D\3A\65\2D\70\32\37\30\3A\33\32\3A\33\32\2D\70\32\37\31\3A\33\32\3A\33\32\2D\70\32\37\32\3A\36\34\3A\36\34\2D\69\36\34\3A\36\34\2D\69\31\32\38\3A\31\32\38\2D\66\38\30\3A\31\32\38\2D\6E\38\3A\31\36\3A\33\32\3A\36\34\2D\53\31\32\38\22\0A\74\61\72\67\65\74\20\74\72\69\70\6C\65\20\3D\20\22\78\38\36\5F\36\34\2D\70\63\2D\6C\69\6E\75\78\2D\67\6E\75\22\0A\61\74\74\72\69\62\75\74\65\73\20\23\30\20\3D\20\7B\20\6E\6F\69\6E\6C\69\6E\65\20\6E\6F\75\6E\77\69\6E\64\20\22\74\61\72\67\65\74\2D\63\70\75\22\3D\22\73\6B\79\6C\61\6B\65\2D\61\76\78\35\31\32\22\20\22\74\61\72\67\65\74\2D\66\65\61\74\75\72\65\73\22\3D\22\2B\61\76\78\2C\2B\61\76\78\35\31\32\62\66\31\36\2C\2B\61\76\78\35\31\32\66\2C\2B\66\6D\61\2C\2D\61\76\78\6E\65\63\6F\6E\76\65\72\74\2C\2B\73\73\65\32\22\20\22\74\75\6E\65\2D\63\70\75\22\3D\22\67\65\6E\65\72\69\63\22\20\7D\0A" }>, align 64
define dso_local void @compiler_2ftarget_2eArchCpuFlags_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t2 = insertvalue [2 x { i64, ptr }] %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t2, ptr @G_2ecompiler_2ftarget_2eArchCpuFlags
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftarget_2eArchDefaultCpus_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t2 = insertvalue [2 x { i64, ptr }] %t1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t2, ptr @G_2ecompiler_2ftarget_2eArchDefaultCpus
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftarget_2eArchs_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t2 = insertvalue [2 x { i64, ptr }] %t1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t2, ptr @G_2ecompiler_2ftarget_2eArchs
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l39 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l45 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l56 = alloca %"std/os:Output"
  %l57 = alloca %"std/os:Output"
  %l61 = alloca %"std/os:Output"
  %l62 = alloca i32
  %l66 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca { i64, ptr }
  %l74 = alloca i32
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %l88 = alloca i32
  %l95 = alloca i32
  %l100 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2ftarget_2eprobeKey(ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t2)
  store { i64, ptr } %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = call { i64, ptr } @compiler_2ftarget_2eprobeDir(ptr %s0)
  store { i64, ptr } %t13, ptr %l15
  br label %bb5
bb4:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb10
bb5:
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s0, { i64, ptr } %t14)
  store i64 %t16, ptr %l17
  br label %bb6
bb6:
  %t17 = load i64, ptr %l17, !tbaa !24
  store i64 %t17, ptr %l18, !tbaa !65
  %t18 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l20
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb8, label %ok.22
ok.22:
  store i64 %t19, ptr %l19
  br label %bb7
bb7:
  %t23 = load i64, ptr %l18, !tbaa !65
  %t24 = load i64, ptr %l19, !tbaa !24
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s0, i64 %t23, i64 %t24)
  store { i64, ptr } %t25, ptr %l21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_def72623566706b3_6d1f4e2e8af6f867)
  unreachable
bb9:
  %t26 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = add i64 %t31, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  call void @olang_textcopy(ptr %t37, ptr %t29, i64 %t30)
  %t38 = getelementptr i8, ptr %t37, i64 %t30
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t36, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l14, !tbaa !27
  br label %bb10
bb10:
  %t49 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t49, ptr %l4, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t52, ptr %l25
  br label %bb11
bb11:
  %t53 = load i1, ptr %l25, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t58 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s2, { i64, ptr } %t56)
  %t59 = extractvalue { i32, { i64, ptr } } %t58, 1
  %t60 = extractvalue { i32, { i64, ptr } } %t58, 0
  store i32 %t60, ptr %l30
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb15, label %ok.62
ok.62:
  store { i64, ptr } %t59, ptr %l29
  br label %bb14
bb13:
  br label %bb32
bb14:
  %t63 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t63, ptr %l27, !tbaa !27
  br label %bb17
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = extractvalue { i64, ptr } %t64, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l27, !tbaa !27
  br label %bb17
bb17:
  %t73 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t73, ptr %l5, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t82 = icmp sgt i64 %t76, %t79
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s0, { i64, ptr } %t84, { i64, ptr } %t85)
  store i1 %t88, ptr %l42
  br label %bb20
bb19:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb21
bb20:
  %t89 = load i1, ptr %l42, !tbaa !21
  store i1 %t89, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t90 = load i1, ptr %l39, !tbaa !21
  br i1 %t90, label %bb22, label %bb23
bb22:
  %t91 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t91, ptr %l43, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l45, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t95, 0
  store i64 %t98, ptr %l48, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l49, !tbaa !24
  %t101 = load i64, ptr %l45, !tbaa !24
  %t102 = icmp sge i64 %t101, 0
  br i1 %t102, label %bb24, label %bb25
bb23:
  br label %bb31
bb24:
  %t104 = load i64, ptr %l45, !tbaa !24
  %t105 = load i64, ptr %l48, !tbaa !24
  %t106 = icmp sle i64 %t104, %t105
  br i1 %t106, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_47a0ad7bede37e81_52b343d343663485)
  unreachable
bb26:
  %t108 = load i64, ptr %l48, !tbaa !24
  %t109 = load i64, ptr %l49, !tbaa !24
  %t110 = icmp sle i64 %t108, %t109
  br i1 %t110, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_47a0ad7bede37e81_52b343d343663485)
  unreachable
bb28:
  %t112 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l45, !tbaa !24
  %t115 = load i64, ptr %l48, !tbaa !24
  %t116 = getelementptr i8, ptr %t113, i64 %t114
  %t117 = sub i64 %t115, %t114
  %t118 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t116, 1
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = extractvalue { i64, ptr } %t119, 0
  %t123 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t121, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  %t134 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v2, ptr %v2, ptr %v2, i32 0, { i64, ptr } %t132, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store %"std/os:Output" %t134, ptr %l56
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_47a0ad7bede37e81_52b343d343663485)
  unreachable
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t135 = load %"std/os:Output", ptr %l56
  %t136 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t135, 1
  store { i32, %"std/os:Output" } %t136, ptr %rv
  br label %ret
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t137 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t142 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v2, { i64, ptr } %t137, { i64, ptr } %t138, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  %t143 = extractvalue { i32, %"std/os:Output" } %t142, 1
  %t144 = extractvalue { i32, %"std/os:Output" } %t142, 0
  store i32 %t144, ptr %l62
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb34, label %ok.146
ok.146:
  store %"std/os:Output" %t143, ptr %l61
  br label %bb33
bb33:
  %t147 = load %"std/os:Output", ptr %l61
  store %"std/os:Output" %t147, ptr %l57
  br label %bb35
bb34:
  %t148 = load i32, ptr %l62, !tbaa !23
  %t149 = lshr i32 %t148, 16
  %t150 = and i32 %t148, 65535
  %t151 = icmp eq i32 %t149, 1
  %t152 = select i1 %t151, i32 1, i32 0
  %t153 = icmp eq i32 %t148, 0
  %t154 = shl i32 %t152, 16
  %t155 = or i32 %t154, %t150
  %t156 = select i1 %t153, i32 0, i32 %t155
  call void @__olang_scope_close(ptr %s0)
  %t158 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t156, 0
  store { i32, %"std/os:Output" } %t158, ptr %rv
  br label %ret
bb35:
  %t159 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store ptr %t159, ptr %lp6
  %t160 = load %"std/os:Output", ptr %l57
  %t161 = load ptr, ptr %lp6
  store %"std/os:Output" %t160, ptr %t161
  %t162 = load ptr, ptr %lp6
  %t163 = getelementptr %"std/os:Output", ptr %t162, i32 0, i32 0
  %t164 = load i32, ptr %t163, !tbaa !23
  %t166 = icmp eq i32 %t164, 0
  br i1 %t166, label %bb36, label %bb37
bb36:
  %t168 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t170 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t168, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t170, ptr %l68
  br label %bb38
bb37:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb39
bb38:
  %t171 = load i1, ptr %l68, !tbaa !21
  %t172 = xor i1 %t171, true
  store i1 %t172, ptr %l66, !tbaa !21
  br label %bb39
bb39:
  %t174 = load i1, ptr %l66, !tbaa !21
  br i1 %t174, label %bb40, label %bb41
bb40:
  store i1 %a2, ptr %l70, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb42
bb42:
  %t177 = load i1, ptr %l70, !tbaa !21
  br i1 %t177, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t178 = call { i64, ptr } @compiler_2ftarget_2eprobeDir(ptr %s5)
  store { i64, ptr } %t178, ptr %l72
  br label %bb45
bb44:
  br label %bb71
bb45:
  %t179 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  %t181 = extractvalue { i64, ptr } %t179, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t187 = call i32 @std_2fos_2eMkDirAll(ptr %s5, { i64, ptr } %t185)
  store i32 %t187, ptr %l74
  %t188 = icmp ne i32 %t187, 0
  br i1 %t188, label %bb47, label %ok.189
ok.189:
  br label %bb46
bb46:
  br label %bb51
bb47:
  %t190 = load i32, ptr %l74, !tbaa !23
  %t191 = ashr i32 %t190, 16
  %t193 = icmp eq i32 %t191, 1
  br i1 %t193, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  %t195 = load i32, ptr %l74, !tbaa !23
  %t196 = lshr i32 %t195, 16
  %t197 = and i32 %t195, 65535
  %t198 = icmp eq i32 %t196, 1
  %t199 = select i1 %t198, i32 1, i32 0
  %t200 = icmp eq i32 %t195, 0
  %t201 = shl i32 %t199, 16
  %t202 = or i32 %t201, %t197
  %t203 = select i1 %t200, i32 0, i32 %t202
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t205 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t203, 0
  store { i32, %"std/os:Output" } %t205, ptr %rv
  br label %ret
bb50:
  call void @__olang_ert_req_clear()
  %t206 = load ptr, ptr %lp6
  %t207 = load %"std/os:Output", ptr %t206
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t209 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t207, 1
  store { i32, %"std/os:Output" } %t209, ptr %rv
  br label %ret
bb51:
  %t210 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t210, ptr %l79, !tbaa !27
  %t211 = call i32 @getpid()
  store i32 %t211, ptr %l80
  br label %bb52
bb52:
  %t212 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t217 = add i64 %t214, %t216
  %t218 = load i32, ptr %l80, !tbaa !23
  %t219 = sext i32 %t218 to i64
  %t220 = call i64 @__olang_fmt_i64(ptr null, i64 %t219)
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t213, i64 %t214)
  %t226 = getelementptr i8, ptr %t225, i64 %t214
  call void @olang_textcopy(ptr %t226, ptr %t215, i64 %t216)
  %t227 = getelementptr i8, ptr %t226, i64 %t216
  %t228 = call i64 @__olang_fmt_i64(ptr %t227, i64 %t219)
  %t229 = getelementptr i8, ptr %t227, i64 %t220
  call void @olang_textcopy(ptr %t229, ptr %t222, i64 %t223)
  %t230 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t225, 1
  store { i64, ptr } %t231, ptr %l7, !tbaa !27
  %t233 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t235 = load ptr, ptr %lp6
  %t236 = getelementptr %"std/os:Output", ptr %t235, i32 0, i32 1
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t234, 1
  %t240 = extractvalue { i64, ptr } %t234, 0
  %t242 = extractvalue { i64, ptr } %t237, 1
  %t243 = extractvalue { i64, ptr } %t237, 0
  %t244 = add i64 %t240, %t243
  %t245 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t244)
  call void @olang_textcopy(ptr %t245, ptr %t239, i64 %t240)
  %t246 = getelementptr i8, ptr %t245, i64 %t240
  call void @olang_textcopy(ptr %t246, ptr %t242, i64 %t243)
  %t247 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t245, 1
  %t251 = extractvalue { i64, ptr } %t248, 0
  %t252 = extractvalue { i64, ptr } %t248, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t259 = call i32 @std_2fos_2eWriteFile(ptr %s5, ptr %s5, { i64, ptr } %t233, { i64, ptr } %t256)
  store i32 %t259, ptr %l88
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb54, label %ok.261
ok.261:
  br label %bb53
bb53:
  br label %bb58
bb54:
  %t262 = load i32, ptr %l88, !tbaa !23
  %t263 = ashr i32 %t262, 16
  %t265 = icmp eq i32 %t263, 1
  br i1 %t265, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  %t267 = load i32, ptr %l88, !tbaa !23
  %t268 = lshr i32 %t267, 16
  %t269 = and i32 %t267, 65535
  %t270 = icmp eq i32 %t268, 1
  %t271 = select i1 %t270, i32 1, i32 0
  %t272 = icmp eq i32 %t267, 0
  %t273 = shl i32 %t271, 16
  %t274 = or i32 %t273, %t269
  %t275 = select i1 %t272, i32 0, i32 %t274
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t277 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t275, 0
  store { i32, %"std/os:Output" } %t277, ptr %rv
  br label %ret
bb57:
  call void @__olang_ert_req_clear()
  %t278 = load ptr, ptr %lp6
  %t279 = load %"std/os:Output", ptr %t278
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t281 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t279, 1
  store { i32, %"std/os:Output" } %t281, ptr %rv
  br label %ret
bb58:
  %t282 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t286 = call i32 @std_2fos_2eRename(ptr %s5, ptr %s0, { i64, ptr } %t282, { i64, ptr } %t283)
  store i32 %t286, ptr %l95
  %t287 = icmp ne i32 %t286, 0
  br i1 %t287, label %bb60, label %ok.288
ok.288:
  br label %bb59
bb59:
  br label %bb70
bb60:
  %t289 = load i32, ptr %l95, !tbaa !23
  %t290 = ashr i32 %t289, 16
  %t292 = icmp eq i32 %t290, 1
  br i1 %t292, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  %t294 = load i32, ptr %l95, !tbaa !23
  %t295 = lshr i32 %t294, 16
  %t296 = and i32 %t294, 65535
  %t297 = icmp eq i32 %t295, 1
  %t298 = select i1 %t297, i32 1, i32 0
  %t299 = icmp eq i32 %t294, 0
  %t300 = shl i32 %t298, 16
  %t301 = or i32 %t300, %t296
  %t302 = select i1 %t299, i32 0, i32 %t301
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t304 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t302, 0
  store { i32, %"std/os:Output" } %t304, ptr %rv
  br label %ret
bb63:
  call void @__olang_ert_req_clear()
  %t305 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t307 = call i32 @std_2fos_2eRemove(ptr %s5, { i64, ptr } %t305)
  store i32 %t307, ptr %l100
  %t308 = icmp ne i32 %t307, 0
  br i1 %t308, label %bb65, label %ok.309
ok.309:
  br label %bb64
bb64:
  br label %bb69
bb65:
  %t310 = load i32, ptr %l100, !tbaa !23
  %t311 = ashr i32 %t310, 16
  %t313 = icmp eq i32 %t311, 1
  br i1 %t313, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  %t315 = load i32, ptr %l100, !tbaa !23
  %t316 = lshr i32 %t315, 16
  %t317 = and i32 %t315, 65535
  %t318 = icmp eq i32 %t316, 1
  %t319 = select i1 %t318, i32 1, i32 0
  %t320 = icmp eq i32 %t315, 0
  %t321 = shl i32 %t319, 16
  %t322 = or i32 %t321, %t317
  %t323 = select i1 %t320, i32 0, i32 %t322
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t325 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t323, 0
  store { i32, %"std/os:Output" } %t325, ptr %rv
  br label %ret
bb68:
  call void @__olang_ert_req_clear()
  br label %bb69
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s5)
  br label %bb71
bb71:
  %t326 = load ptr, ptr %lp6
  %t327 = load %"std/os:Output", ptr %t326
  call void @__olang_scope_close(ptr %s0)
  %t329 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t327, 1
  store { i32, %"std/os:Output" } %t329, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local void @compiler_2ftarget_2eClangs_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [4 x { i64, ptr }] undef, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t2 = insertvalue [4 x { i64, ptr }] %t1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t3 = insertvalue [4 x { i64, ptr }] %t2, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d18, i32 0, i32 1) }, 2
  %t4 = insertvalue [4 x { i64, ptr }] %t3, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d19, i32 0, i32 1) }, 3
  store [4 x { i64, ptr }] %t4, ptr @G_2ecompiler_2ftarget_2eClangs
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l15 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l32 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i32
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l50 = alloca i32
  %l64 = alloca i1
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d20, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l10
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l8, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t16, ptr %l0, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t19, ptr %l15
  br label %bb5
bb5:
  %t20 = load i1, ptr %l15, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = call i1 @compiler_2ftarget_2eexecutable(ptr %s0, { i64, ptr } %t23)
  store i1 %t25, ptr %l18
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = extractvalue { i64, ptr } %t27, 0
  %t31 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t29, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l19, !tbaa !27
  br label %bb11
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t35, ptr %l19, !tbaa !27
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l24, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l25, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = mul i64 %t48, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t50, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t51 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
bb12:
  %t52 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d24, i32 0, i32 1) })
  %t53 = extractvalue { i32, { i64, ptr } } %t52, 1
  %t54 = extractvalue { i32, { i64, ptr } } %t52, 0
  store i32 %t54, ptr %l28
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb14, label %ok.56
ok.56:
  store { i64, ptr } %t53, ptr %l27
  br label %bb13
bb13:
  %t57 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t57, ptr %l26, !tbaa !27
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l26, !tbaa !27
  br label %bb16
bb16:
  %t67 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t67, ptr %l1, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t70 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s0, ptr %s0, { i64, ptr } %t68, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) })
  %t71 = extractvalue { i32, i64 } %t70, 1
  %t72 = extractvalue { i32, i64 } %t70, 0
  store i32 %t72, ptr %l35
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb18, label %ok.74
ok.74:
  store i64 %t71, ptr %l34
  br label %bb17
bb17:
  %t75 = load i64, ptr %l34, !tbaa !24
  store i64 %t75, ptr %l32, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l32, !tbaa !24
  br label %bb20
bb20:
  %t76 = load i64, ptr %l32, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  %t77 = load i64, ptr %l2, !tbaa !24
  %t79 = icmp sge i64 %t77, 0
  br i1 %t79, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t81, ptr %l38, !tbaa !27
  %t82 = load i64, ptr %l2, !tbaa !24
  store i64 %t82, ptr %l39, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l40, !tbaa !24
  %t85 = icmp sge i64 0, 0
  br i1 %t85, label %bb23, label %bb24
bb22:
  br label %bb33
bb23:
  %t87 = load i64, ptr %l39, !tbaa !24
  %t88 = icmp sle i64 0, %t87
  br i1 %t88, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_5d60638bbee689af_7a012b3f353868cb)
  unreachable
bb25:
  %t90 = load i64, ptr %l39, !tbaa !24
  %t91 = load i64, ptr %l40, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_5d60638bbee689af_7a012b3f353868cb)
  unreachable
bb27:
  %t94 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l39, !tbaa !24
  %t97 = getelementptr i8, ptr %t95, i64 0
  %t98 = sub i64 %t96, 0
  %t99 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = extractvalue { i64, ptr } %t100, 0
  %t104 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t102, i64 %t103)
  %t108 = getelementptr i8, ptr %t107, i64 %t103
  call void @olang_textcopy(ptr %t108, ptr %t104, i64 %t105)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t107, 1
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t111, ptr %lp3
  %t113 = load ptr, ptr %lp3
  store { i64, ptr } %t110, ptr %t113, !tbaa !27
  %t114 = load ptr, ptr %lp3
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 1
  %t118 = extractvalue { i64, ptr } %t115, 0
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t121 = add i64 %t118, %t120
  %t122 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t117, i64 %t118)
  %t123 = getelementptr i8, ptr %t122, i64 %t118
  call void @olang_textcopy(ptr %t123, ptr %t119, i64 %t120)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t122, 1
  %t127 = load i32, ptr @G_2e_3cunistd_2eh_3e_2eX__OK, !tbaa !23
  %t129 = extractvalue { i64, ptr } %t125, 1
  %t130 = extractvalue { i64, ptr } %t125, 0
  %t132 = call i32 @access(ptr %t129, i32 %t127)
  store i32 %t132, ptr %l50
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_5d60638bbee689af_7a012b3f353868cb)
  unreachable
bb29:
  %t133 = load i32, ptr %l50, !tbaa !23
  %t134 = icmp eq i32 %t133, 0
  br i1 %t134, label %bb30, label %bb31
bb30:
  %t136 = load ptr, ptr %lp3
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t137, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb33:
  store ptr @G_2ecompiler_2ftarget_2eClangs, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t140 = load ptr, ptr %l4
  store i64 4, ptr %l6, !tbaa !24
  br label %bb34
bb34:
  %t143 = load i64, ptr %l5, !tbaa !24
  %t144 = load i64, ptr %l6, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t151 = load ptr, ptr %l4
  %t152 = load i64, ptr %l5, !tbaa !24
  %t155 = getelementptr [4 x { i64, ptr }], ptr %t151, i64 0, i64 %t152
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !37
  store { i64, ptr } %t156, ptr %l7, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t159 = load ptr, ptr @__olang_prog_scope
  %t161 = call i1 @compiler_2ftarget_2eexecutable(ptr %t159, { i64, ptr } %t158)
  store i1 %t161, ptr %l64
  br label %bb38
bb38:
  %t162 = load i1, ptr %l64, !tbaa !21
  br i1 %t162, label %bb39, label %bb40
bb39:
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 1
  %t166 = extractvalue { i64, ptr } %t163, 0
  %t167 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t165, i64 %t166)
  %t168 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t169, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t171 = load i64, ptr %l5, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l5, !tbaa !24
  br label %bb34
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l69, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t175, ptr %l70, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 0
  store i64 %t177, ptr %l71, !tbaa !24
  %t178 = load i64, ptr %l71, !tbaa !24
  %t179 = mul i64 %t178, 1
  %t180 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l72, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = load i64, ptr %l71, !tbaa !24
  %t188 = mul i64 %t187, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t184, ptr %t186, i64 %t188, i1 false)
  %t189 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t189, ptr %l70, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t190 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t190, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftarget_2eHasFeature(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l38 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s1, { i64, ptr } %a0, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb23
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = add i64 %t30, 1
  %t35 = icmp eq i64 %t27, %t32
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 0
  %t41 = load i8, ptr %t40, !tbaa !32
  %t43 = icmp eq i8 %t41, 43
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t46, ptr %l28, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t47, 0
  store i64 %t50, ptr %l31, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l32, !tbaa !24
  %t53 = icmp sge i64 1, 0
  br i1 %t53, label %bb11, label %bb12
bb10:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb18
bb11:
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = icmp sle i64 1, %t55
  br i1 %t56, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_7d2dbc1a64f072ad_c547ba7f55386c9)
  unreachable
bb13:
  %t58 = load i64, ptr %l31, !tbaa !24
  %t59 = load i64, ptr %l32, !tbaa !24
  %t60 = icmp sle i64 %t58, %t59
  br i1 %t60, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_7d2dbc1a64f072ad_c547ba7f55386c9)
  unreachable
bb15:
  %t62 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l31, !tbaa !24
  %t65 = getelementptr i8, ptr %t63, i64 1
  %t66 = sub i64 %t64, 1
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t68, { i64, ptr } %t69)
  store i1 %t72, ptr %l38
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7d2dbc1a64f072ad_c547ba7f55386c9)
  unreachable
bb17:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t74 = load i1, ptr %l27, !tbaa !21
  br i1 %t74, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t76 = load i64, ptr %l3, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l3, !tbaa !24
  br label %bb2
bb23:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2ftarget_2eHost(ptr %v0) #0 {
entry:
  %l0 = alloca %"<sys/utsname.h>:utsname"
  %l1 = alloca %"<sys/utsname.h>:utsname"
  %l3 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca { { i64, ptr }, { i64, ptr } }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  %t1 = alloca %"<sys/utsname.h>:utsname", align 1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @olang_2eHelperKind_2eZero_2e_3csys_2futsname_2eh_3e_3autsname(ptr %t1)
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %t1, i64 390, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %l1, i64 390, i1 false)
  %t3 = call i32 @uname(ptr %l0)
  store i32 %t3, ptr %l3
  br label %bb2
bb2:
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = icmp ne i32 %t4, 0
  br i1 %t5, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t7, 0
  %t12 = insertvalue { { i64, ptr }, { i64, ptr } } %t10, { i64, ptr } %t8, 1
  store { { i64, ptr }, { i64, ptr } } %t12, ptr %l9
  %t13 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l9, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = mul i64 %t26, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t29 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l9, i32 0, i32 0
  store { i64, ptr } %t28, ptr %t29, !tbaa !27
  %t30 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l9, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l13, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l14, !tbaa !24
  %t34 = load i64, ptr %l14, !tbaa !24
  %t35 = mul i64 %t34, 1
  %t36 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l15, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l14, !tbaa !24
  %t44 = mul i64 %t43, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %t42, i64 %t44, i1 false)
  %t45 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t46 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l9, i32 0, i32 1
  store { i64, ptr } %t45, ptr %t46, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { { i64, ptr }, { i64, ptr } }, ptr %l9
  store { { i64, ptr }, { i64, ptr } } %t47, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t48 = getelementptr %"<sys/utsname.h>:utsname", ptr %l0, i32 0, i32 0
  %t50 = insertvalue { i64, ptr } undef, i64 65, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t53 = call { i64, ptr } @compiler_2ftarget_2ecField(ptr %s0, ptr %v0, { i64, ptr } %t51)
  store { i64, ptr } %t53, ptr %l18
  br label %bb6
bb6:
  %t54 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t62 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v0, { i64, ptr } %t60)
  store { i64, ptr } %t62, ptr %l20
  br label %bb7
bb7:
  %t63 = getelementptr %"<sys/utsname.h>:utsname", ptr %l0, i32 0, i32 4
  %t65 = insertvalue { i64, ptr } undef, i64 65, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t68 = call { i64, ptr } @compiler_2ftarget_2ecField(ptr %s0, ptr %v0, { i64, ptr } %t66)
  store { i64, ptr } %t68, ptr %l23
  br label %bb8
bb8:
  %t69 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t70 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t69, 0
  %t71 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t72 = insertvalue { { i64, ptr }, { i64, ptr } } %t70, { i64, ptr } %t71, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, { i64, ptr } } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2ftarget_2eIeeeUnsafe_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t2 = insertvalue [2 x { i64, ptr }] %t1, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t2, ptr @G_2ecompiler_2ftarget_2eIeeeUnsafe
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftarget_2eLevelFlags_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t2 = insertvalue [3 x { i64, ptr }] %t1, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t3 = insertvalue [3 x { i64, ptr }] %t2, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d37, i32 0, i32 1) }, 2
  store [3 x { i64, ptr }] %t3, ptr @G_2ecompiler_2ftarget_2eLevelFlags
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftarget_2ePid() #0 {
entry:
  %l0 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i32 @getpid()
  store i32 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i32, ptr %l0, !tbaa !23
  store i32 %t2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, ptr %a3) #0 {
entry:
  %l4 = alloca { { i64, ptr }, { i64, ptr } }
  %l7 = alloca { { i64, ptr }, { i64, ptr } }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"compiler/target:Target"
  %l21 = alloca %"compiler/target:Target"
  %l22 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/target:Target" }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { { i64, ptr }, { i64, ptr } } @compiler_2ftarget_2eHost(ptr %s0)
  store { { i64, ptr }, { i64, ptr } } %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load { { i64, ptr }, { i64, ptr } }, ptr %l7
  store { { i64, ptr }, { i64, ptr } } %t2, ptr %l4
  %t3 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l4, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l9, !tbaa !24
  %t7 = load i64, ptr %l9, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l9, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t19 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l4, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l11, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l12, !tbaa !24
  %t23 = load i64, ptr %l12, !tbaa !24
  %t24 = mul i64 %t23, 1
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l13, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l12, !tbaa !24
  %t33 = mul i64 %t32, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = call { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolveOn(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %t18, { i64, ptr } %t34, ptr %a3)
  %t48 = extractvalue { i32, %"compiler/target:Target" } %t47, 1
  %t49 = extractvalue { i32, %"compiler/target:Target" } %t47, 0
  store i32 %t49, ptr %l22
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb3, label %ok.51
ok.51:
  store %"compiler/target:Target" %t48, ptr %l21
  br label %bb2
bb2:
  %t52 = load %"compiler/target:Target", ptr %l21
  store %"compiler/target:Target" %t52, ptr %l14
  br label %bb4
bb3:
  %t53 = load i32, ptr %l22, !tbaa !23
  %t54 = lshr i32 %t53, 16
  %t55 = and i32 %t53, 65535
  %t56 = icmp eq i32 %t54, 1
  %t57 = select i1 %t56, i32 1, i32 0
  %t58 = icmp eq i32 %t53, 0
  %t59 = shl i32 %t57, 16
  %t60 = or i32 %t59, %t55
  %t61 = select i1 %t58, i32 0, i32 %t60
  call void @__olang_scope_close(ptr %s0)
  %t63 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t61, 0
  store { i32, %"compiler/target:Target" } %t63, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load %"compiler/target:Target", ptr %l14
  %t65 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, %"compiler/target:Target" %t64, 1
  store { i32, %"compiler/target:Target" } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/target:Target" }, ptr %rv
  ret { i32, %"compiler/target:Target" } %rr
}

define dso_local { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolveOn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca %"std/os:Output"
  %l19 = alloca %"compiler/target:Target"
  %l26 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i32
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l84 = alloca i1
  %l86 = alloca i1
  %l88 = alloca ptr
  %l90 = alloca %"compiler/msgs:Msg"
  %l91 = alloca i32
  %l94 = alloca i1
  %l96 = alloca i1
  %l97 = alloca i1
  %l100 = alloca { i64, ptr }
  %l101 = alloca i1
  %l102 = alloca ptr
  %l104 = alloca %"compiler/msgs:Msg"
  %l105 = alloca i32
  %l109 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca i1
  %l114 = alloca { i64, ptr }
  %l115 = alloca i1
  %l116 = alloca i1
  %l119 = alloca { i64, ptr }
  %l120 = alloca i1
  %l121 = alloca ptr
  %l123 = alloca %"compiler/msgs:Msg"
  %l124 = alloca i32
  %l128 = alloca { i64, ptr }
  %l129 = alloca i1
  %l130 = alloca i1
  %l132 = alloca i1
  %l133 = alloca ptr
  %l135 = alloca %"compiler/msgs:Msg"
  %l136 = alloca i32
  %l139 = alloca i64
  %l142 = alloca ptr
  %l144 = alloca %"compiler/msgs:Msg"
  %l145 = alloca i32
  %l154 = alloca i1
  %l156 = alloca i1
  %l158 = alloca i1
  %l161 = alloca i1
  %l163 = alloca i1
  %l173 = alloca i1
  %l175 = alloca i1
  %l176 = alloca i1
  %l178 = alloca ptr
  %l180 = alloca %"compiler/msgs:Msg"
  %l181 = alloca i32
  %l184 = alloca i1
  %l186 = alloca ptr
  %l188 = alloca %"compiler/msgs:Msg"
  %l189 = alloca i32
  %l192 = alloca i1
  %l195 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l200 = alloca i1
  %l202 = alloca ptr
  %l204 = alloca %"compiler/msgs:Msg"
  %l205 = alloca i32
  %l208 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l214 = alloca i1
  %l242 = alloca %"std/os:Output"
  %l244 = alloca { i64, ptr }
  %l247 = alloca %"std/os:Output"
  %l248 = alloca i32
  %l252 = alloca ptr
  %l254 = alloca %"compiler/msgs:Msg"
  %l255 = alloca i32
  %l259 = alloca ptr
  %l261 = alloca %"compiler/msgs:Msg"
  %l262 = alloca i32
  %l266 = alloca i32
  %l270 = alloca ptr
  %l272 = alloca %"compiler/msgs:Msg"
  %l273 = alloca i32
  %l275 = alloca ptr
  %l277 = alloca %"compiler/msgs:Msg"
  %l278 = alloca i32
  %l281 = alloca i1
  %l284 = alloca i1
  %l286 = alloca ptr
  %l288 = alloca %"compiler/msgs:Msg"
  %l289 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/target:Target" }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v5)
  store %"compiler/target:Target" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 128, i64 8)
  store ptr %t2, ptr %lp6
  %t3 = load %"compiler/target:Target", ptr %l19
  %t4 = load ptr, ptr %lp6
  store %"compiler/target:Target" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t7, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t20 = load ptr, ptr %lp6
  %t21 = getelementptr %"compiler/target:Target", ptr %t20, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t21, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 1
  %t25 = extractvalue { i64, ptr } %t22, 0
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t24, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l8, !tbaa !27
  store i1 true, ptr %l9, !tbaa !21
  store i64 -1, ptr %l10, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t40 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t37, i8 45)
  %t41 = extractvalue { i32, i64 } %t40, 1
  %t42 = extractvalue { i32, i64 } %t40, 0
  store i32 %t42, ptr %l30
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb3, label %ok.44
ok.44:
  store i64 %t41, ptr %l29
  br label %bb2
bb2:
  %t45 = load i64, ptr %l29, !tbaa !24
  store i64 %t45, ptr %l26, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l26, !tbaa !24
  br label %bb5
bb5:
  %t46 = load i64, ptr %l26, !tbaa !24
  store i64 %t46, ptr %l11, !tbaa !24
  %t47 = load i64, ptr %l11, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  br i1 %t49, label %bb6, label %bb7
bb6:
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l11, !tbaa !24
  store i64 %t52, ptr %l34, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l35, !tbaa !24
  %t55 = icmp sge i64 0, 0
  br i1 %t55, label %bb8, label %bb9
bb7:
  br label %bb15
bb8:
  %t57 = load i64, ptr %l34, !tbaa !24
  %t58 = icmp sle i64 0, %t57
  br i1 %t58, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ee9182f5b79fed14_a04856bc4b77fa08)
  unreachable
bb10:
  %t60 = load i64, ptr %l34, !tbaa !24
  %t61 = load i64, ptr %l35, !tbaa !24
  %t62 = icmp sle i64 %t60, %t61
  br i1 %t62, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ee9182f5b79fed14_a04856bc4b77fa08)
  unreachable
bb12:
  %t64 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l34, !tbaa !24
  %t67 = getelementptr i8, ptr %t65, i64 0
  %t68 = sub i64 %t66, 0
  %t69 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t67, 1
  %t72 = call i64 @compiler_2ftarget_2earchIndex(ptr %v0, { i64, ptr } %t70)
  store i64 %t72, ptr %l40
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ee9182f5b79fed14_a04856bc4b77fa08)
  unreachable
bb14:
  %t73 = load i64, ptr %l40, !tbaa !24
  store i64 %t73, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  %t74 = load i64, ptr %l10, !tbaa !24
  %t76 = icmp sge i64 %t74, 0
  br i1 %t76, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t81 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t78, i8 58)
  %t82 = extractvalue { i32, i64 } %t81, 1
  %t83 = extractvalue { i32, i64 } %t81, 0
  store i32 %t83, ptr %l47
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb19, label %ok.85
ok.85:
  store i64 %t82, ptr %l46
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s10
  %t86 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l109, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t90 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s10, { i64, ptr } %t86, { i64, ptr } %t89)
  store i1 %t90, ptr %l110
  br label %bb66
bb18:
  %t91 = load i64, ptr %l46, !tbaa !24
  store i64 %t91, ptr %l43, !tbaa !24
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l43, !tbaa !24
  br label %bb21
bb21:
  %t92 = load i64, ptr %l43, !tbaa !24
  store i64 %t92, ptr %l12, !tbaa !24
  %t93 = load i64, ptr %l12, !tbaa !24
  %t95 = icmp sge i64 %t93, 0
  br i1 %t95, label %bb22, label %bb23
bb22:
  %t97 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t97, ptr %l51, !tbaa !27
  %t98 = load i64, ptr %l12, !tbaa !24
  store i64 %t98, ptr %l52, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l53, !tbaa !24
  %t101 = icmp sge i64 0, 0
  br i1 %t101, label %bb24, label %bb25
bb23:
  %t103 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 1
  %t106 = extractvalue { i64, ptr } %t103, 0
  %t107 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t105, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = extractvalue { i64, ptr } %t109, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l50, !tbaa !27
  br label %bb30
bb24:
  %t118 = load i64, ptr %l52, !tbaa !24
  %t119 = icmp sle i64 0, %t118
  br i1 %t119, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_177ba209f42fea81_ef02637a921a8065)
  unreachable
bb26:
  %t121 = load i64, ptr %l52, !tbaa !24
  %t122 = load i64, ptr %l53, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_177ba209f42fea81_ef02637a921a8065)
  unreachable
bb28:
  %t125 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = load i64, ptr %l52, !tbaa !24
  %t128 = getelementptr i8, ptr %t126, i64 0
  %t129 = sub i64 %t127, 0
  %t130 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t128, 1
  %t133 = extractvalue { i64, ptr } %t131, 1
  %t134 = extractvalue { i64, ptr } %t131, 0
  %t135 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t133, i64 %t134)
  %t136 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = extractvalue { i64, ptr } %t137, 1
  %t141 = mul i64 %t139, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t141)
  call void @llvm.memcpy.p0.p0.i64(ptr %t142, ptr %t140, i64 %t141, i1 false)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l50, !tbaa !27
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_177ba209f42fea81_ef02637a921a8065)
  unreachable
bb30:
  %t146 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t146, ptr %l7, !tbaa !27
  %t147 = load i64, ptr %l12, !tbaa !24
  %t149 = icmp sge i64 %t147, 0
  store i1 %t149, ptr %l9, !tbaa !21
  %t151 = load i64, ptr %l12, !tbaa !24
  %t153 = icmp sge i64 %t151, 0
  br i1 %t153, label %bb31, label %bb32
bb31:
  %t155 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t155, ptr %l68, !tbaa !27
  %t156 = load i64, ptr %l12, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l70, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t159, 0
  store i64 %t162, ptr %l73, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l74, !tbaa !24
  %t165 = load i64, ptr %l70, !tbaa !24
  %t166 = icmp sge i64 %t165, 0
  br i1 %t166, label %bb33, label %bb34
bb32:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb39
bb33:
  %t168 = load i64, ptr %l70, !tbaa !24
  %t169 = load i64, ptr %l73, !tbaa !24
  %t170 = icmp sle i64 %t168, %t169
  br i1 %t170, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_68a839c97e351482_b46245551e337746)
  unreachable
bb35:
  %t172 = load i64, ptr %l73, !tbaa !24
  %t173 = load i64, ptr %l74, !tbaa !24
  %t174 = icmp sle i64 %t172, %t173
  br i1 %t174, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_68a839c97e351482_b46245551e337746)
  unreachable
bb37:
  %t176 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = load i64, ptr %l70, !tbaa !24
  %t179 = load i64, ptr %l73, !tbaa !24
  %t180 = getelementptr i8, ptr %t177, i64 %t178
  %t181 = sub i64 %t179, %t178
  %t182 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t180, 1
  %t185 = extractvalue { i64, ptr } %t183, 1
  %t186 = extractvalue { i64, ptr } %t183, 0
  %t187 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t186)
  call void @olang_textcopy(ptr %t187, ptr %t185, i64 %t186)
  %t188 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = extractvalue { i64, ptr } %t189, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  store { i64, ptr } %t196, ptr %l67, !tbaa !27
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_68a839c97e351482_b46245551e337746)
  unreachable
bb39:
  %t198 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t198, ptr %l8, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t203 = icmp sgt i64 %t201, 10
  br i1 %t203, label %bb40, label %bb41
bb40:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t207 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s4, { i64, ptr } %t205, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t207, ptr %l86
  br label %bb42
bb41:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb43
bb42:
  %t208 = load i1, ptr %l86, !tbaa !21
  store i1 %t208, ptr %l84, !tbaa !21
  br label %bb43
bb43:
  %t209 = load i1, ptr %l84, !tbaa !21
  %t210 = xor i1 %t209, true
  br i1 %t210, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t212 = load ptr, ptr %l5, !tbaa !29
  store ptr %t212, ptr %l88, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t215 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %s8, { i64, ptr } %t213)
  store %"compiler/msgs:Msg" %t215, ptr %l90
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t216 = load ptr, ptr %l88, !tbaa !29
  %t217 = load %"compiler/msgs:Msg", ptr %l90
  %t218 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s8, ptr %t216, %"compiler/msgs:Msg" %t217)
  store i32 %t218, ptr %l91
  %t219 = icmp ne i32 %t218, 0
  br i1 %t219, label %bb48, label %ok.220
ok.220:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t221 = load i32, ptr %l91, !tbaa !23
  %t222 = lshr i32 %t221, 16
  %t223 = and i32 %t221, 65535
  %t224 = icmp eq i32 %t222, 1
  %t225 = select i1 %t224, i32 1, i32 0
  %t226 = icmp eq i32 %t221, 0
  %t227 = shl i32 %t225, 16
  %t228 = or i32 %t227, %t223
  %t229 = select i1 %t226, i32 0, i32 %t228
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t231 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t229, 0
  store { i32, %"compiler/target:Target" } %t231, ptr %rv
  br label %ret
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  %t232 = load i1, ptr %l9, !tbaa !21
  br i1 %t232, label %bb51, label %bb52
bb51:
  %t234 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t236 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t234, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t236, ptr %l96
  br label %bb53
bb52:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb58
bb53:
  %t237 = load i1, ptr %l96, !tbaa !21
  br i1 %t237, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb57
bb55:
  %t238 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l100, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t242 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s4, { i64, ptr } %t238, { i64, ptr } %t241)
  store i1 %t242, ptr %l101
  br label %bb56
bb56:
  %t243 = load i1, ptr %l101, !tbaa !21
  store i1 %t243, ptr %l97, !tbaa !21
  br label %bb57
bb57:
  %t244 = load i1, ptr %l97, !tbaa !21
  store i1 %t244, ptr %l94, !tbaa !21
  br label %bb58
bb58:
  %t245 = load i1, ptr %l94, !tbaa !21
  br i1 %t245, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s9
  %t246 = load ptr, ptr %l5, !tbaa !29
  store ptr %t246, ptr %l102, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t249 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %s9, { i64, ptr } %t247)
  store %"compiler/msgs:Msg" %t249, ptr %l104
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t250 = load ptr, ptr %l102, !tbaa !29
  %t251 = load %"compiler/msgs:Msg", ptr %l104
  %t252 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s9, ptr %t250, %"compiler/msgs:Msg" %t251)
  store i32 %t252, ptr %l105
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb63, label %ok.254
ok.254:
  br label %bb62
bb62:
  br label %bb64
bb63:
  %t255 = load i32, ptr %l105, !tbaa !23
  %t256 = lshr i32 %t255, 16
  %t257 = and i32 %t255, 65535
  %t258 = icmp eq i32 %t256, 1
  %t259 = select i1 %t258, i32 1, i32 0
  %t260 = icmp eq i32 %t255, 0
  %t261 = shl i32 %t259, 16
  %t262 = or i32 %t261, %t257
  %t263 = select i1 %t260, i32 0, i32 %t262
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t265 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t263, 0
  store { i32, %"compiler/target:Target" } %t265, ptr %rv
  br label %ret
bb64:
  call void @__olang_scope_close(ptr %s9)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s4)
  br label %bb102
bb66:
  %t266 = load i1, ptr %l110, !tbaa !21
  br i1 %t266, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb70
bb68:
  %t267 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l114, !tbaa !27
  %t270 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t271 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s10, { i64, ptr } %t267, { i64, ptr } %t270)
  store i1 %t271, ptr %l115
  br label %bb69
bb69:
  %t272 = load i1, ptr %l115, !tbaa !21
  store i1 %t272, ptr %l111, !tbaa !21
  br label %bb70
bb70:
  %t273 = load i1, ptr %l111, !tbaa !21
  br i1 %t273, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb74
bb72:
  %t274 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l119, !tbaa !27
  %t277 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t278 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s10, { i64, ptr } %t274, { i64, ptr } %t277)
  store i1 %t278, ptr %l120
  br label %bb73
bb73:
  %t279 = load i1, ptr %l120, !tbaa !21
  store i1 %t279, ptr %l116, !tbaa !21
  br label %bb74
bb74:
  %t280 = load i1, ptr %l116, !tbaa !21
  br i1 %t280, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s11
  %t281 = load ptr, ptr %l5, !tbaa !29
  store ptr %t281, ptr %l121, !tbaa !29
  %t282 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t284 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %s11, { i64, ptr } %t282)
  store %"compiler/msgs:Msg" %t284, ptr %l123
  br label %bb77
bb76:
  br label %bb81
bb77:
  %t285 = load ptr, ptr %l121, !tbaa !29
  %t286 = load %"compiler/msgs:Msg", ptr %l123
  %t287 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s11, ptr %t285, %"compiler/msgs:Msg" %t286)
  store i32 %t287, ptr %l124
  %t288 = icmp ne i32 %t287, 0
  br i1 %t288, label %bb79, label %ok.289
ok.289:
  br label %bb78
bb78:
  br label %bb80
bb79:
  %t290 = load i32, ptr %l124, !tbaa !23
  %t291 = lshr i32 %t290, 16
  %t292 = and i32 %t290, 65535
  %t293 = icmp eq i32 %t291, 1
  %t294 = select i1 %t293, i32 1, i32 0
  %t295 = icmp eq i32 %t290, 0
  %t296 = shl i32 %t294, 16
  %t297 = or i32 %t296, %t292
  %t298 = select i1 %t295, i32 0, i32 %t297
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t300 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t298, 0
  store { i32, %"compiler/target:Target" } %t300, ptr %rv
  br label %ret
bb80:
  call void @__olang_scope_close(ptr %s11)
  br label %bb81
bb81:
  %t301 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l128, !tbaa !27
  %t304 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t305 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s10, { i64, ptr } %t301, { i64, ptr } %t304)
  store i1 %t305, ptr %l129
  br label %bb82
bb82:
  %t306 = load i1, ptr %l129, !tbaa !21
  br i1 %t306, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb86
bb84:
  %t307 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t309 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s10, { i64, ptr } %t307, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t309, ptr %l132
  br label %bb85
bb85:
  %t310 = load i1, ptr %l132, !tbaa !21
  store i1 %t310, ptr %l130, !tbaa !21
  br label %bb86
bb86:
  %t311 = load i1, ptr %l130, !tbaa !21
  br i1 %t311, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s12
  %t312 = load ptr, ptr %l5, !tbaa !29
  store ptr %t312, ptr %l133, !tbaa !29
  %t313 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t315 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %s12, { i64, ptr } %t313)
  store %"compiler/msgs:Msg" %t315, ptr %l135
  br label %bb89
bb88:
  br label %bb93
bb89:
  %t316 = load ptr, ptr %l133, !tbaa !29
  %t317 = load %"compiler/msgs:Msg", ptr %l135
  %t318 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s12, ptr %t316, %"compiler/msgs:Msg" %t317)
  store i32 %t318, ptr %l136
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb91, label %ok.320
ok.320:
  br label %bb90
bb90:
  br label %bb92
bb91:
  %t321 = load i32, ptr %l136, !tbaa !23
  %t322 = lshr i32 %t321, 16
  %t323 = and i32 %t321, 65535
  %t324 = icmp eq i32 %t322, 1
  %t325 = select i1 %t324, i32 1, i32 0
  %t326 = icmp eq i32 %t321, 0
  %t327 = shl i32 %t325, 16
  %t328 = or i32 %t327, %t323
  %t329 = select i1 %t326, i32 0, i32 %t328
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t331 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t329, 0
  store { i32, %"compiler/target:Target" } %t331, ptr %rv
  br label %ret
bb92:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb93:
  %t332 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t334 = call i64 @compiler_2ftarget_2earchIndex(ptr %v3, { i64, ptr } %t332)
  store i64 %t334, ptr %l139
  br label %bb94
bb94:
  %t335 = load i64, ptr %l139, !tbaa !24
  store i64 %t335, ptr %l10, !tbaa !24
  %t336 = load i64, ptr %l10, !tbaa !24
  %t338 = icmp slt i64 %t336, 0
  br i1 %t338, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s13
  %t340 = load ptr, ptr %l5, !tbaa !29
  store ptr %t340, ptr %l142, !tbaa !29
  %t341 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t343 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v3, ptr %s13, { i64, ptr } %t341)
  store %"compiler/msgs:Msg" %t343, ptr %l144
  br label %bb97
bb96:
  br label %bb101
bb97:
  %t344 = load ptr, ptr %l142, !tbaa !29
  %t345 = load %"compiler/msgs:Msg", ptr %l144
  %t346 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s13, ptr %t344, %"compiler/msgs:Msg" %t345)
  store i32 %t346, ptr %l145
  %t347 = icmp ne i32 %t346, 0
  br i1 %t347, label %bb99, label %ok.348
ok.348:
  br label %bb98
bb98:
  br label %bb100
bb99:
  %t349 = load i32, ptr %l145, !tbaa !23
  %t350 = lshr i32 %t349, 16
  %t351 = and i32 %t349, 65535
  %t352 = icmp eq i32 %t350, 1
  %t353 = select i1 %t352, i32 1, i32 0
  %t354 = icmp eq i32 %t349, 0
  %t355 = shl i32 %t353, 16
  %t356 = or i32 %t355, %t351
  %t357 = select i1 %t354, i32 0, i32 %t356
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t359 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t357, 0
  store { i32, %"compiler/target:Target" } %t359, ptr %rv
  br label %ret
bb100:
  call void @__olang_scope_close(ptr %s13)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s10)
  br label %bb102
bb102:
  %t360 = load i64, ptr %l10, !tbaa !24
  %t362 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchs, i64 0, i64 %t360
  %t363 = load { i64, ptr }, ptr %t362, !tbaa !37
  %t365 = extractvalue { i64, ptr } %t363, 1
  %t366 = extractvalue { i64, ptr } %t363, 0
  %t367 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t366)
  call void @olang_textcopy(ptr %t367, ptr %t365, i64 %t366)
  %t368 = insertvalue { i64, ptr } undef, i64 %t366, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t367, 1
  %t371 = extractvalue { i64, ptr } %t369, 0
  %t372 = extractvalue { i64, ptr } %t369, 1
  %t373 = mul i64 %t371, 1
  %t374 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t374, ptr %t372, i64 %t373, i1 false)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  %t378 = load ptr, ptr %lp6
  %t379 = getelementptr %"compiler/target:Target", ptr %t378, i32 0, i32 2
  store { i64, ptr } %t376, ptr %t379, !tbaa !27
  %t380 = load i64, ptr %l10, !tbaa !24
  %t382 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchs, i64 0, i64 %t380
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !37
  %t384 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t385 = load ptr, ptr @__olang_prog_scope
  %t388 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t385, ptr %v3, { i64, ptr } %t383, { i64, ptr } %t384)
  store i1 %t388, ptr %l154
  br label %bb103
bb103:
  %t389 = load i1, ptr %l154, !tbaa !21
  %t390 = xor i1 %t389, true
  br i1 %t390, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb107
bb105:
  %t394 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %a3, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t394, ptr %l158
  br label %bb106
bb106:
  %t395 = load i1, ptr %l158, !tbaa !21
  %t396 = xor i1 %t395, true
  store i1 %t396, ptr %l156, !tbaa !21
  br label %bb107
bb107:
  %t398 = load i1, ptr %l156, !tbaa !21
  %t399 = load ptr, ptr %lp6
  %t400 = getelementptr %"compiler/target:Target", ptr %t399, i32 0, i32 9
  store i1 %t398, ptr %t400, !tbaa !21
  %t401 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t403 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t401, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t403, ptr %l161
  br label %bb108
bb108:
  %t404 = load i1, ptr %l161, !tbaa !21
  %t405 = xor i1 %t404, true
  br i1 %t405, label %bb109, label %bb110
bb109:
  %t407 = load ptr, ptr %lp6
  %t408 = getelementptr %"compiler/target:Target", ptr %t407, i32 0, i32 9
  %t409 = load i1, ptr %t408, !tbaa !21
  %t411 = xor i1 %t409, true
  store i1 %t411, ptr %l163, !tbaa !21
  br label %bb111
bb110:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb111
bb111:
  %t413 = load i1, ptr %l163, !tbaa !21
  br i1 %t413, label %bb112, label %bb113
bb112:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t414 = load i1, ptr %l9, !tbaa !21
  %t416 = xor i1 %t414, true
  br i1 %t416, label %bb114, label %bb115
bb113:
  br label %bb117
bb114:
  %t418 = load i64, ptr %l10, !tbaa !24
  %t420 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchDefaultCpus, i64 0, i64 %t418
  %t421 = load { i64, ptr }, ptr %t420, !tbaa !37
  %t423 = extractvalue { i64, ptr } %t421, 1
  %t424 = extractvalue { i64, ptr } %t421, 0
  %t425 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t424)
  call void @olang_textcopy(ptr %t425, ptr %t423, i64 %t424)
  %t426 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  %t429 = extractvalue { i64, ptr } %t427, 0
  %t430 = extractvalue { i64, ptr } %t427, 1
  %t431 = mul i64 %t429, 1
  %t432 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t431)
  call void @llvm.memcpy.p0.p0.i64(ptr %t432, ptr %t430, i64 %t431, i1 false)
  %t433 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t434 = insertvalue { i64, ptr } %t433, ptr %t432, 1
  store { i64, ptr } %t434, ptr %l8, !tbaa !27
  store i1 true, ptr %l9, !tbaa !21
  br label %bb116
bb115:
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t436 = load i1, ptr %l9, !tbaa !21
  br i1 %t436, label %bb118, label %bb119
bb118:
  %t438 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t440 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t438, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t440, ptr %l175
  br label %bb120
bb119:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb121
bb120:
  %t441 = load i1, ptr %l175, !tbaa !21
  store i1 %t441, ptr %l173, !tbaa !21
  br label %bb121
bb121:
  %t442 = load i1, ptr %l173, !tbaa !21
  br i1 %t442, label %bb122, label %bb123
bb122:
  %t443 = load ptr, ptr %lp6
  %t444 = getelementptr %"compiler/target:Target", ptr %t443, i32 0, i32 9
  %t445 = load i1, ptr %t444, !tbaa !21
  store i1 %t445, ptr %l176, !tbaa !21
  br label %bb124
bb123:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb124
bb124:
  %t447 = load i1, ptr %l176, !tbaa !21
  br i1 %t447, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s18
  %t448 = load ptr, ptr %l5, !tbaa !29
  store ptr %t448, ptr %l178, !tbaa !29
  %t449 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t451 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNativeForeign(ptr %v0, ptr %s18, { i64, ptr } %t449)
  store %"compiler/msgs:Msg" %t451, ptr %l180
  br label %bb127
bb126:
  br label %bb131
bb127:
  %t452 = load ptr, ptr %l178, !tbaa !29
  %t453 = load %"compiler/msgs:Msg", ptr %l180
  %t454 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s18, ptr %t452, %"compiler/msgs:Msg" %t453)
  store i32 %t454, ptr %l181
  %t455 = icmp ne i32 %t454, 0
  br i1 %t455, label %bb129, label %ok.456
ok.456:
  br label %bb128
bb128:
  br label %bb130
bb129:
  %t457 = load i32, ptr %l181, !tbaa !23
  %t458 = lshr i32 %t457, 16
  %t459 = and i32 %t457, 65535
  %t460 = icmp eq i32 %t458, 1
  %t461 = select i1 %t460, i32 1, i32 0
  %t462 = icmp eq i32 %t457, 0
  %t463 = shl i32 %t461, 16
  %t464 = or i32 %t463, %t459
  %t465 = select i1 %t462, i32 0, i32 %t464
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t467 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t465, 0
  store { i32, %"compiler/target:Target" } %t467, ptr %rv
  br label %ret
bb130:
  call void @__olang_scope_close(ptr %s18)
  br label %bb131
bb131:
  %t468 = load ptr, ptr %lp6
  %t469 = getelementptr %"compiler/target:Target", ptr %t468, i32 0, i32 9
  %t470 = load i1, ptr %t469, !tbaa !21
  br i1 %t470, label %bb132, label %bb133
bb132:
  %t472 = load i1, ptr %l2, !tbaa !21
  store i1 %t472, ptr %l184, !tbaa !21
  br label %bb134
bb133:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb134
bb134:
  %t474 = load i1, ptr %l184, !tbaa !21
  br i1 %t474, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s19
  %t475 = load ptr, ptr %l5, !tbaa !29
  store ptr %t475, ptr %l186, !tbaa !29
  %t476 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t478 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %s19, ptr %v0, ptr %s19, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d52, i32 0, i32 1) }, { i64, ptr } %t476)
  store %"compiler/msgs:Msg" %t478, ptr %l188
  br label %bb137
bb136:
  br label %bb141
bb137:
  %t479 = load ptr, ptr %l186, !tbaa !29
  %t480 = load %"compiler/msgs:Msg", ptr %l188
  %t481 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s19, ptr %t479, %"compiler/msgs:Msg" %t480)
  store i32 %t481, ptr %l189
  %t482 = icmp ne i32 %t481, 0
  br i1 %t482, label %bb139, label %ok.483
ok.483:
  br label %bb138
bb138:
  br label %bb140
bb139:
  %t484 = load i32, ptr %l189, !tbaa !23
  %t485 = lshr i32 %t484, 16
  %t486 = and i32 %t484, 65535
  %t487 = icmp eq i32 %t485, 1
  %t488 = select i1 %t487, i32 1, i32 0
  %t489 = icmp eq i32 %t484, 0
  %t490 = shl i32 %t488, 16
  %t491 = or i32 %t490, %t486
  %t492 = select i1 %t489, i32 0, i32 %t491
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t494 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t492, 0
  store { i32, %"compiler/target:Target" } %t494, ptr %rv
  br label %ret
bb140:
  call void @__olang_scope_close(ptr %s19)
  br label %bb141
bb141:
  %t495 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t497 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t495, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t497, ptr %l192
  br label %bb142
bb142:
  %t498 = load i1, ptr %l192, !tbaa !21
  br i1 %t498, label %bb143, label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s20
  %t499 = load i1, ptr %l2, !tbaa !21
  %t501 = xor i1 %t499, true
  br i1 %t501, label %bb145, label %bb146
bb144:
  br label %bb157
bb145:
  store i1 true, ptr %l195, !tbaa !21
  br label %bb149
bb146:
  %t503 = load ptr, ptr %lp6
  store ptr %t503, ptr %l196, !tbaa !29
  %t504 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t504, ptr %l197, !tbaa !27
  %t505 = call { i64, ptr } @compiler_2ftarget_2ecpuFlags(ptr %s20)
  store { i64, ptr } %t505, ptr %l198
  br label %bb147
bb147:
  %t506 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t507 = extractvalue { i64, ptr } %t506, 0
  %t508 = extractvalue { i64, ptr } %t506, 1
  %t509 = mul i64 %t507, 1
  %t510 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t509)
  call void @llvm.memcpy.p0.p0.i64(ptr %t510, ptr %t508, i64 %t509, i1 false)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t510, 1
  %t513 = load ptr, ptr %l196, !tbaa !29
  %t514 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t516 = call i1 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2ewithoutClang(ptr %v5, ptr %s0, ptr %s20, ptr %t513, { i64, ptr } %t514, { i64, ptr } %t512)
  store i1 %t516, ptr %l200
  br label %bb148
bb148:
  %t517 = load i1, ptr %l200, !tbaa !21
  %t518 = xor i1 %t517, true
  store i1 %t518, ptr %l195, !tbaa !21
  br label %bb149
bb149:
  %t520 = load i1, ptr %l195, !tbaa !21
  br i1 %t520, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s21
  %t521 = load ptr, ptr %l5, !tbaa !29
  store ptr %t521, ptr %l202, !tbaa !29
  %t522 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t524 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoClang(ptr %v0, ptr %s21, { i64, ptr } %t522)
  store %"compiler/msgs:Msg" %t524, ptr %l204
  br label %bb152
bb151:
  br label %bb156
bb152:
  %t525 = load ptr, ptr %l202, !tbaa !29
  %t526 = load %"compiler/msgs:Msg", ptr %l204
  %t527 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s21, ptr %t525, %"compiler/msgs:Msg" %t526)
  store i32 %t527, ptr %l205
  %t528 = icmp ne i32 %t527, 0
  br i1 %t528, label %bb154, label %ok.529
ok.529:
  br label %bb153
bb153:
  br label %bb155
bb154:
  %t530 = load i32, ptr %l205, !tbaa !23
  %t531 = lshr i32 %t530, 16
  %t532 = and i32 %t530, 65535
  %t533 = icmp eq i32 %t531, 1
  %t534 = select i1 %t533, i32 1, i32 0
  %t535 = icmp eq i32 %t530, 0
  %t536 = shl i32 %t534, 16
  %t537 = or i32 %t536, %t532
  %t538 = select i1 %t535, i32 0, i32 %t537
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  %t540 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t538, 0
  store { i32, %"compiler/target:Target" } %t540, ptr %rv
  br label %ret
bb155:
  call void @__olang_scope_close(ptr %s21)
  br label %bb156
bb156:
  %t541 = load ptr, ptr %lp6
  %t542 = load %"compiler/target:Target", ptr %t541
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  %t544 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, %"compiler/target:Target" %t542, 1
  store { i32, %"compiler/target:Target" } %t544, ptr %rv
  br label %ret
bb157:
  %t545 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t545, ptr %l208
  br label %bb158
bb158:
  %t546 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l208
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t546, ptr %l13
  %t547 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t547, 1
  %t550 = extractvalue { i64, ptr } %t547, 0
  %t551 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t550)
  call void @olang_textcopy(ptr %t551, ptr %t549, i64 %t550)
  %t552 = insertvalue { i64, ptr } undef, i64 %t550, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t551, 1
  %t555 = extractvalue { i64, ptr } %t553, 0
  %t556 = extractvalue { i64, ptr } %t553, 1
  %t557 = mul i64 %t555, 1
  %t558 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t557)
  call void @llvm.memcpy.p0.p0.i64(ptr %t558, ptr %t556, i64 %t557, i1 false)
  %t559 = insertvalue { i64, ptr } undef, i64 %t555, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %t558, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l13, { i64, ptr } %t560)
  br label %bb159
bb159:
  %t563 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t565 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t563, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t565, ptr %l214
  br label %bb160
bb160:
  %t566 = load i1, ptr %l214, !tbaa !21
  %t567 = xor i1 %t566, true
  br i1 %t567, label %bb161, label %bb162
bb161:
  %t569 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t570 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t571 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t573 = extractvalue { i64, ptr } %t569, 1
  %t574 = extractvalue { i64, ptr } %t569, 0
  %t575 = add i64 %t571, %t574
  %t576 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t575)
  call void @olang_textcopy(ptr %t576, ptr %t570, i64 %t571)
  %t577 = getelementptr i8, ptr %t576, i64 %t571
  call void @olang_textcopy(ptr %t577, ptr %t573, i64 %t574)
  %t578 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t579 = insertvalue { i64, ptr } %t578, ptr %t576, 1
  %t581 = extractvalue { i64, ptr } %t579, 0
  %t582 = extractvalue { i64, ptr } %t579, 1
  %t583 = mul i64 %t581, 1
  %t584 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t583)
  call void @llvm.memcpy.p0.p0.i64(ptr %t584, ptr %t582, i64 %t583, i1 false)
  %t585 = insertvalue { i64, ptr } undef, i64 %t581, 0
  %t586 = insertvalue { i64, ptr } %t585, ptr %t584, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l13, { i64, ptr } %t586)
  br label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb164
bb164:
  %t589 = load i1, ptr %l9, !tbaa !21
  br i1 %t589, label %bb165, label %bb166
bb165:
  %t591 = load i64, ptr %l10, !tbaa !24
  %t593 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchCpuFlags, i64 0, i64 %t591
  %t594 = load { i64, ptr }, ptr %t593, !tbaa !37
  %t595 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t597 = extractvalue { i64, ptr } %t594, 1
  %t598 = extractvalue { i64, ptr } %t594, 0
  %t600 = extractvalue { i64, ptr } %t595, 1
  %t601 = extractvalue { i64, ptr } %t595, 0
  %t602 = add i64 %t598, %t601
  %t603 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t602)
  call void @olang_textcopy(ptr %t603, ptr %t597, i64 %t598)
  %t604 = getelementptr i8, ptr %t603, i64 %t598
  call void @olang_textcopy(ptr %t604, ptr %t600, i64 %t601)
  %t605 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t606 = insertvalue { i64, ptr } %t605, ptr %t603, 1
  %t608 = extractvalue { i64, ptr } %t606, 0
  %t609 = extractvalue { i64, ptr } %t606, 1
  %t610 = mul i64 %t608, 1
  %t611 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t610)
  call void @llvm.memcpy.p0.p0.i64(ptr %t611, ptr %t609, i64 %t610, i1 false)
  %t612 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t611, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l13, { i64, ptr } %t613)
  br label %bb167
bb166:
  br label %bb168
bb167:
  br label %bb168
bb168:
  store %olang.scope zeroinitializer, ptr %s27
  %t616 = insertvalue [7 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t617 = insertvalue [7 x { i64, ptr }] %t616, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t618 = insertvalue [7 x { i64, ptr }] %t617, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) }, 2
  %t619 = insertvalue [7 x { i64, ptr }] %t618, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 3
  %t620 = insertvalue [7 x { i64, ptr }] %t619, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) }, 4
  %t621 = insertvalue [7 x { i64, ptr }] %t620, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 5
  %t622 = insertvalue [7 x { i64, ptr }] %t621, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 6
  %t624 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 112, i64 8)
  store [7 x { i64, ptr }] %t622, ptr %t624
  store ptr %t624, ptr %l14
  store i64 0, ptr %l15, !tbaa !24
  %t626 = load ptr, ptr %l14
  store i64 7, ptr %l16, !tbaa !24
  br label %bb169
bb169:
  %t629 = load i64, ptr %l15, !tbaa !24
  %t630 = load i64, ptr %l16, !tbaa !24
  %t633 = icmp slt i64 %t629, %t630
  %t635 = xor i1 %t633, true
  br i1 %t635, label %bb170, label %bb171
bb170:
  br label %bb175
bb171:
  br label %bb172
bb172:
  %t637 = load ptr, ptr %l14
  %t638 = load i64, ptr %l15, !tbaa !24
  %t641 = getelementptr [7 x { i64, ptr }], ptr %t637, i64 0, i64 %t638
  %t642 = load { i64, ptr }, ptr %t641, !tbaa !37
  %t645 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %t645, ptr %l13, { i64, ptr } %t642)
  br label %bb173
bb173:
  br label %bb174
bb174:
  %t648 = load i64, ptr %l15, !tbaa !24
  %t650 = add i64 %t648, 1
  store i64 %t650, ptr %l15, !tbaa !24
  br label %bb169
bb175:
  call void @__olang_scope_close(ptr %s27)
  %t653 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l13)
  store { i64, ptr } %t653, ptr %l244
  br label %bb176
bb176:
  %t654 = load i1, ptr %l2, !tbaa !21
  %t656 = xor i1 %t654, true
  %t657 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t659 = call { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t657, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d63, i32 0, i32 1) }, i1 %t656)
  %t660 = extractvalue { i32, %"std/os:Output" } %t659, 1
  %t661 = extractvalue { i32, %"std/os:Output" } %t659, 0
  store i32 %t661, ptr %l248
  %t662 = icmp ne i32 %t661, 0
  br i1 %t662, label %bb178, label %ok.663
ok.663:
  store %"std/os:Output" %t660, ptr %l247
  br label %bb177
bb177:
  %t664 = load %"std/os:Output", ptr %l247
  store %"std/os:Output" %t664, ptr %l242
  br label %bb186
bb178:
  %t665 = load i32, ptr %l248, !tbaa !23
  %t666 = ashr i32 %t665, 16
  %t668 = icmp eq i32 %t666, 1
  br i1 %t668, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  %t670 = load i32, ptr %l248, !tbaa !23
  %t671 = lshr i32 %t670, 16
  %t672 = and i32 %t670, 65535
  %t673 = icmp eq i32 %t671, 1
  %t674 = select i1 %t673, i32 0, i32 0
  %t675 = icmp eq i32 %t670, 0
  %t676 = shl i32 %t674, 16
  %t677 = or i32 %t676, %t672
  %t678 = select i1 %t675, i32 0, i32 %t677
  call void @__olang_scope_close(ptr %s0)
  %t680 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t678, 0
  store { i32, %"compiler/target:Target" } %t680, ptr %rv
  br label %ret
bb181:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s30
  %t681 = load ptr, ptr %l5, !tbaa !29
  store ptr %t681, ptr %l252, !tbaa !29
  %t682 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t684 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %s30, { i64, ptr } %t682)
  store %"compiler/msgs:Msg" %t684, ptr %l254
  br label %bb182
bb182:
  %t685 = load ptr, ptr %l252, !tbaa !29
  %t686 = load %"compiler/msgs:Msg", ptr %l254
  %t687 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s30, ptr %t685, %"compiler/msgs:Msg" %t686)
  store i32 %t687, ptr %l255
  %t688 = icmp ne i32 %t687, 0
  br i1 %t688, label %bb184, label %ok.689
ok.689:
  br label %bb183
bb183:
  br label %bb185
bb184:
  %t690 = load i32, ptr %l255, !tbaa !23
  %t691 = lshr i32 %t690, 16
  %t692 = and i32 %t690, 65535
  %t693 = icmp eq i32 %t691, 1
  %t694 = select i1 %t693, i32 1, i32 0
  %t695 = icmp eq i32 %t690, 0
  %t696 = shl i32 %t694, 16
  %t697 = or i32 %t696, %t692
  %t698 = select i1 %t695, i32 0, i32 %t697
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  %t700 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t698, 0
  store { i32, %"compiler/target:Target" } %t700, ptr %rv
  br label %ret
bb185:
  call void @__olang_check_failed(ptr @olang_loc_fea0ada6e42eab98_8ecdc26bfdef2ecc)
  unreachable
bb186:
  %t701 = load %"std/os:Output", ptr %l242
  store %"std/os:Output" %t701, ptr %l18
  %t702 = getelementptr %"std/os:Output", ptr %l18, i32 0, i32 0
  %t703 = load i32, ptr %t702, !tbaa !23
  %t705 = icmp ne i32 %t703, 0
  br i1 %t705, label %bb187, label %bb188
bb187:
  store %olang.scope zeroinitializer, ptr %s31
  %t707 = load ptr, ptr %l5, !tbaa !29
  store ptr %t707, ptr %l259, !tbaa !29
  %t708 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t710 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %s31, { i64, ptr } %t708)
  store %"compiler/msgs:Msg" %t710, ptr %l261
  br label %bb189
bb188:
  br label %bb193
bb189:
  %t711 = load ptr, ptr %l259, !tbaa !29
  %t712 = load %"compiler/msgs:Msg", ptr %l261
  %t713 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s31, ptr %t711, %"compiler/msgs:Msg" %t712)
  store i32 %t713, ptr %l262
  %t714 = icmp ne i32 %t713, 0
  br i1 %t714, label %bb191, label %ok.715
ok.715:
  br label %bb190
bb190:
  br label %bb192
bb191:
  %t716 = load i32, ptr %l262, !tbaa !23
  %t717 = lshr i32 %t716, 16
  %t718 = and i32 %t716, 65535
  %t719 = icmp eq i32 %t717, 1
  %t720 = select i1 %t719, i32 1, i32 0
  %t721 = icmp eq i32 %t716, 0
  %t722 = shl i32 %t720, 16
  %t723 = or i32 %t722, %t718
  %t724 = select i1 %t721, i32 0, i32 %t723
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s0)
  %t726 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t724, 0
  store { i32, %"compiler/target:Target" } %t726, ptr %rv
  br label %ret
bb192:
  call void @__olang_scope_close(ptr %s31)
  br label %bb193
bb193:
  %t727 = load ptr, ptr %lp6
  %t728 = getelementptr %"std/os:Output", ptr %l18, i32 0, i32 1
  %t729 = load { i64, ptr }, ptr %t728, !tbaa !27
  %t732 = call i32 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eFromProbe(ptr %v5, ptr %s0, ptr %t727, { i64, ptr } %t729)
  store i32 %t732, ptr %l266
  %t733 = icmp ne i32 %t732, 0
  br i1 %t733, label %bb195, label %ok.734
ok.734:
  br label %bb194
bb194:
  br label %bb210
bb195:
  %t735 = load i32, ptr %l266, !tbaa !23
  %t736 = icmp eq i32 %t735, 65536
  br i1 %t736, label %bb196, label %bb197
bb196:
  br label %bb198
bb197:
  %t738 = load i32, ptr %l266, !tbaa !23
  %t739 = icmp eq i32 %t738, 65537
  br i1 %t739, label %bb199, label %bb200
bb198:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s32
  %t741 = load ptr, ptr %l5, !tbaa !29
  store ptr %t741, ptr %l270, !tbaa !29
  %t742 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t744 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %s32, { i64, ptr } %t742)
  store %"compiler/msgs:Msg" %t744, ptr %l272
  br label %bb202
bb199:
  br label %bb201
bb200:
  %t745 = load i32, ptr %l266, !tbaa !23
  %t746 = lshr i32 %t745, 16
  %t747 = and i32 %t745, 65535
  %t748 = icmp eq i32 %t746, 1
  %t749 = select i1 %t748, i32 0, i32 0
  %t750 = icmp eq i32 %t745, 0
  %t751 = shl i32 %t749, 16
  %t752 = or i32 %t751, %t747
  %t753 = select i1 %t750, i32 0, i32 %t752
  call void @__olang_scope_close(ptr %s0)
  %t755 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t753, 0
  store { i32, %"compiler/target:Target" } %t755, ptr %rv
  br label %ret
bb201:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s33
  %t756 = load ptr, ptr %l5, !tbaa !29
  store ptr %t756, ptr %l275, !tbaa !29
  %t757 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t759 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %s33, { i64, ptr } %t757)
  store %"compiler/msgs:Msg" %t759, ptr %l277
  br label %bb206
bb202:
  %t760 = load ptr, ptr %l270, !tbaa !29
  %t761 = load %"compiler/msgs:Msg", ptr %l272
  %t762 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s32, ptr %t760, %"compiler/msgs:Msg" %t761)
  store i32 %t762, ptr %l273
  %t763 = icmp ne i32 %t762, 0
  br i1 %t763, label %bb204, label %ok.764
ok.764:
  br label %bb203
bb203:
  br label %bb205
bb204:
  %t765 = load i32, ptr %l273, !tbaa !23
  %t766 = lshr i32 %t765, 16
  %t767 = and i32 %t765, 65535
  %t768 = icmp eq i32 %t766, 1
  %t769 = select i1 %t768, i32 1, i32 0
  %t770 = icmp eq i32 %t765, 0
  %t771 = shl i32 %t769, 16
  %t772 = or i32 %t771, %t767
  %t773 = select i1 %t770, i32 0, i32 %t772
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s0)
  %t775 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t773, 0
  store { i32, %"compiler/target:Target" } %t775, ptr %rv
  br label %ret
bb205:
  call void @__olang_scope_close(ptr %s32)
  br label %bb210
bb206:
  %t776 = load ptr, ptr %l275, !tbaa !29
  %t777 = load %"compiler/msgs:Msg", ptr %l277
  %t778 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s33, ptr %t776, %"compiler/msgs:Msg" %t777)
  store i32 %t778, ptr %l278
  %t779 = icmp ne i32 %t778, 0
  br i1 %t779, label %bb208, label %ok.780
ok.780:
  br label %bb207
bb207:
  br label %bb209
bb208:
  %t781 = load i32, ptr %l278, !tbaa !23
  %t782 = lshr i32 %t781, 16
  %t783 = and i32 %t781, 65535
  %t784 = icmp eq i32 %t782, 1
  %t785 = select i1 %t784, i32 1, i32 0
  %t786 = icmp eq i32 %t781, 0
  %t787 = shl i32 %t785, 16
  %t788 = or i32 %t787, %t783
  %t789 = select i1 %t786, i32 0, i32 %t788
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s0)
  %t791 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t789, 0
  store { i32, %"compiler/target:Target" } %t791, ptr %rv
  br label %ret
bb209:
  call void @__olang_scope_close(ptr %s33)
  br label %bb210
bb210:
  %t792 = load ptr, ptr %lp6
  %t793 = getelementptr %"compiler/target:Target", ptr %t792, i32 0, i32 9
  %t794 = load i1, ptr %t793, !tbaa !21
  br i1 %t794, label %bb211, label %bb212
bb211:
  %t796 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t797 = load ptr, ptr %lp6
  %t798 = getelementptr %"compiler/target:Target", ptr %t797, i32 0, i32 1
  %t799 = load { i64, ptr }, ptr %t798, !tbaa !27
  %t802 = call i1 @compiler_2ftarget_2ecanCompileBf16(ptr %v1, ptr %v5, { i64, ptr } %t796, { i64, ptr } %t799)
  store i1 %t802, ptr %l284
  br label %bb213
bb212:
  store i1 false, ptr %l281, !tbaa !21
  br label %bb214
bb213:
  %t803 = load i1, ptr %l284, !tbaa !21
  %t804 = xor i1 %t803, true
  store i1 %t804, ptr %l281, !tbaa !21
  br label %bb214
bb214:
  %t806 = load i1, ptr %l281, !tbaa !21
  br i1 %t806, label %bb215, label %bb216
bb215:
  store %olang.scope zeroinitializer, ptr %s34
  %t807 = load ptr, ptr %l5, !tbaa !29
  store ptr %t807, ptr %l286, !tbaa !29
  %t808 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t810 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoBackend(ptr %v0, ptr %s34, { i64, ptr } %t808)
  store %"compiler/msgs:Msg" %t810, ptr %l288
  br label %bb217
bb216:
  br label %bb221
bb217:
  %t811 = load ptr, ptr %l286, !tbaa !29
  %t812 = load %"compiler/msgs:Msg", ptr %l288
  %t813 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s34, ptr %t811, %"compiler/msgs:Msg" %t812)
  store i32 %t813, ptr %l289
  %t814 = icmp ne i32 %t813, 0
  br i1 %t814, label %bb219, label %ok.815
ok.815:
  br label %bb218
bb218:
  br label %bb220
bb219:
  %t816 = load i32, ptr %l289, !tbaa !23
  %t817 = lshr i32 %t816, 16
  %t818 = and i32 %t816, 65535
  %t819 = icmp eq i32 %t817, 1
  %t820 = select i1 %t819, i32 1, i32 0
  %t821 = icmp eq i32 %t816, 0
  %t822 = shl i32 %t820, 16
  %t823 = or i32 %t822, %t818
  %t824 = select i1 %t821, i32 0, i32 %t823
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  %t826 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t824, 0
  store { i32, %"compiler/target:Target" } %t826, ptr %rv
  br label %ret
bb220:
  call void @__olang_scope_close(ptr %s34)
  br label %bb221
bb221:
  %t827 = load i64, ptr %l10, !tbaa !24
  %t829 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchCpuFlags, i64 0, i64 %t827
  %t830 = load { i64, ptr }, ptr %t829, !tbaa !37
  %t831 = load ptr, ptr %lp6
  %t832 = getelementptr %"compiler/target:Target", ptr %t831, i32 0, i32 4
  %t833 = load { i64, ptr }, ptr %t832, !tbaa !27
  %t835 = extractvalue { i64, ptr } %t830, 1
  %t836 = extractvalue { i64, ptr } %t830, 0
  %t838 = extractvalue { i64, ptr } %t833, 1
  %t839 = extractvalue { i64, ptr } %t833, 0
  %t840 = add i64 %t836, %t839
  %t841 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t840)
  call void @olang_textcopy(ptr %t841, ptr %t835, i64 %t836)
  %t842 = getelementptr i8, ptr %t841, i64 %t836
  call void @olang_textcopy(ptr %t842, ptr %t838, i64 %t839)
  %t843 = insertvalue { i64, ptr } undef, i64 %t840, 0
  %t844 = insertvalue { i64, ptr } %t843, ptr %t841, 1
  %t846 = extractvalue { i64, ptr } %t844, 0
  %t847 = extractvalue { i64, ptr } %t844, 1
  %t848 = mul i64 %t846, 1
  %t849 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t848)
  call void @llvm.memcpy.p0.p0.i64(ptr %t849, ptr %t847, i64 %t848, i1 false)
  %t850 = insertvalue { i64, ptr } undef, i64 %t846, 0
  %t851 = insertvalue { i64, ptr } %t850, ptr %t849, 1
  %t853 = load ptr, ptr %lp6
  %t854 = getelementptr %"compiler/target:Target", ptr %t853, i32 0, i32 6
  store { i64, ptr } %t851, ptr %t854, !tbaa !27
  %t855 = load ptr, ptr %lp6
  %t856 = load %"compiler/target:Target", ptr %t855
  call void @__olang_scope_close(ptr %s0)
  %t858 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, %"compiler/target:Target" %t856, 1
  store { i32, %"compiler/target:Target" } %t858, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/target:Target" }, ptr %rv
  ret { i32, %"compiler/target:Target" } %rr
}

define dso_local void @compiler_2ftarget_2eSkylakeProbe_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t3 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t5 = add i64 %t2, %t4
  %t6 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call ptr @__olang_scope_alloc(ptr %t12, i64 %t11)
  call void @olang_textcopy(ptr %t13, ptr %t1, i64 %t2)
  %t14 = getelementptr i8, ptr %t13, i64 %t2
  call void @olang_textcopy(ptr %t14, ptr %t3, i64 %t4)
  %t15 = getelementptr i8, ptr %t14, i64 %t4
  call void @olang_textcopy(ptr %t15, ptr %t6, i64 %t7)
  %t16 = getelementptr i8, ptr %t15, i64 %t7
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t13, 1
  store { i64, ptr } %t18, ptr %l0, !tbaa !27
  %t19 = load { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eSkylakeProbe, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l2, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = icmp eq i64 %t20, %t24
  br i1 %t25, label %bb1, label %bb2
bb1:
  %t27 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eSkylakeProbe, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = mul i64 %t31, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %t30, i64 %t32, i1 false)
  br label %bb3
bb2:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t33, ptr @G_2ecompiler_2ftarget_2eSkylakeProbe, !tbaa !27
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftarget_2eStripUnsafe(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l51 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t5, ptr %l12, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l13, !tbaa !24
  %t8 = load i64, ptr %l13, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l14, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l13, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t19, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load %"std/prelude/text:StringBuilder", ptr %l15
  store %"std/prelude/text:StringBuilder" %t22, ptr %l1
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s2, { i64, ptr } %t23, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store { i64, ptr } %t25, ptr %l17
  br label %bb6
bb6:
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t26, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l4, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb41
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t51 = icmp sgt i64 %t39, 0
  br i1 %t51, label %bb11, label %bb12
bb11:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 44)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = icmp sgt i64 %t56, 1
  br i1 %t58, label %bb15, label %bb16
bb15:
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t60, ptr %l35, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 0
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 43
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t68 = load i1, ptr %l34, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l39, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t70, 0
  store i64 %t73, ptr %l42, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l43, !tbaa !24
  %t76 = icmp sge i64 1, 0
  br i1 %t76, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb27
bb20:
  %t78 = load i64, ptr %l42, !tbaa !24
  %t79 = icmp sle i64 1, %t78
  br i1 %t79, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4b3e93141bb855fb_750a01d3487f499f)
  unreachable
bb22:
  %t81 = load i64, ptr %l42, !tbaa !24
  %t82 = load i64, ptr %l43, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  br i1 %t83, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4b3e93141bb855fb_750a01d3487f499f)
  unreachable
bb24:
  %t85 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l42, !tbaa !24
  %t88 = getelementptr i8, ptr %t86, i64 1
  %t89 = sub i64 %t87, 1
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  %t94 = insertvalue { i64, ptr } undef, i64 2, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr @G_2ecompiler_2ftarget_2eIeeeUnsafe, 1
  %t97 = load ptr, ptr @__olang_prog_scope
  %t100 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t97, ptr %v0, { i64, ptr } %t95, { i64, ptr } %t91)
  store i1 %t100, ptr %l51
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_4b3e93141bb855fb_750a01d3487f499f)
  unreachable
bb26:
  %t101 = load i1, ptr %l51, !tbaa !21
  store i1 %t101, ptr %l38, !tbaa !21
  br label %bb27
bb27:
  %t102 = load i1, ptr %l38, !tbaa !21
  br i1 %t102, label %bb28, label %bb29
bb28:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 45)
  br label %bb30
bb29:
  %t106 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t106)
  br label %bb38
bb30:
  store ptr %l1, ptr %l54, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t109, ptr %l55, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t110, 0
  store i64 %t113, ptr %l58, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l59, !tbaa !24
  %t116 = icmp sge i64 1, 0
  br i1 %t116, label %bb31, label %bb32
bb31:
  %t118 = load i64, ptr %l58, !tbaa !24
  %t119 = icmp sle i64 1, %t118
  br i1 %t119, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_a61f3cd56da1d37e_58843bed9934bc22)
  unreachable
bb33:
  %t121 = load i64, ptr %l58, !tbaa !24
  %t122 = load i64, ptr %l59, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_a61f3cd56da1d37e_58843bed9934bc22)
  unreachable
bb35:
  %t125 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = load i64, ptr %l58, !tbaa !24
  %t128 = getelementptr i8, ptr %t126, i64 1
  %t129 = sub i64 %t127, 1
  %t130 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t128, 1
  %t132 = load ptr, ptr %l54, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t132, { i64, ptr } %t131)
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_a61f3cd56da1d37e_58843bed9934bc22)
  unreachable
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t134 = load i64, ptr %l3, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l3, !tbaa !24
  br label %bb7
bb41:
  call void @__olang_scope_close(ptr %s2)
  %t139 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t139, ptr %l69
  br label %bb42
bb42:
  %t140 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t140, ptr %l70, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l71, !tbaa !24
  %t143 = load i64, ptr %l71, !tbaa !24
  %t144 = mul i64 %t143, 1
  %t145 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l72, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = load i64, ptr %l71, !tbaa !24
  %t153 = mul i64 %t152, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t149, ptr %t151, i64 %t153, i1 false)
  %t154 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t154, ptr %l70, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t155 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t155, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v0, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d71, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l1
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t6, ptr %l0, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l0, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l7, !tbaa !24
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t30, ptr %l6, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %v0, ptr %v1, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t4, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftarget_2eX86Level(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l23 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l39 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l1, !tbaa !24
  store ptr @G_2ecompiler_2ftarget_2eLevelFlags, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t2 = load ptr, ptr %l2
  store i64 3, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb17
bb3:
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l2
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = getelementptr [3 x { i64, ptr }], ptr %t15, i64 0, i64 %t16
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !37
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load ptr, ptr @__olang_prog_scope
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %t23, ptr %s3, { i64, ptr } %t20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store { i64, ptr } %t25, ptr %l23
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l9, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t39 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t39, ptr %l30, !tbaa !27
  %t40 = load i64, ptr %l8, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %t43, i64 %t40
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !37
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t53 = extractvalue { i64, ptr } %t45, 1
  %t54 = extractvalue { i64, ptr } %t45, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t50, i64 %t51)
  %t60 = getelementptr i8, ptr %t59, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = getelementptr i8, ptr %t60, i64 %t54
  call void @olang_textcopy(ptr %t61, ptr %t56, i64 %t57)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = extractvalue { i64, ptr } %t63, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t74 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s4, { i64, ptr } %a0, { i64, ptr } %t71)
  store i1 %t74, ptr %l39
  br label %bb10
bb10:
  %t75 = load i1, ptr %l39, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb11, label %bb12
bb11:
  %t78 = load i64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i64 %t78, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l8, !tbaa !24
  br label %bb6
bb15:
  call void @__olang_scope_close(ptr %s3)
  %t84 = load i64, ptr %l5, !tbaa !24
  %t86 = add i64 %t84, 2
  store i64 %t86, ptr %l1, !tbaa !24
  br label %bb16
bb16:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l3, !tbaa !24
  br label %bb1
bb17:
  %t92 = load i64, ptr %l1, !tbaa !24
  store i64 %t92, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftarget_2earchIndex(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l19 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store ptr @G_2ecompiler_2ftarget_2eArchs, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t2 = load ptr, ptr %l1
  store i64 2, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t15 = load ptr, ptr %l1
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = getelementptr [2 x { i64, ptr }], ptr %t15, i64 0, i64 %t16
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !37
  %t24 = load ptr, ptr @__olang_prog_scope
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t24, ptr %v0, { i64, ptr } %t20, { i64, ptr } %a0)
  store i1 %t27, ptr %l19
  br label %bb5
bb5:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l4, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t26 = call { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t23)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l8
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb2, label %ok.30
ok.30:
  store { i64, ptr } %t27, ptr %l7
  br label %bb1
bb1:
  %t31 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t31, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 1, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  call void @__olang_scope_close(ptr %s0)
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t40, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t44 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t43, 1
  store { i32, { i64, ptr } } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2ecField(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l35, !tbaa !27
  %t54 = load i64, ptr %l7, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i8, ptr %t57, i64 %t54
  %t59 = load i8, ptr %t58, !tbaa !32
  %t61 = icmp eq i8 %t59, 0
  br i1 %t61, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t63, ptr %l40, !tbaa !27
  %t64 = load i64, ptr %l7, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i8, ptr %t67, i64 %t64
  %t69 = load i8, ptr %t68, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t69)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  %t78 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t78, ptr %l47
  br label %bb18
bb18:
  %t79 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t79, ptr %l48, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  store i64 %t81, ptr %l49, !tbaa !24
  %t82 = load i64, ptr %l49, !tbaa !24
  %t83 = mul i64 %t82, 1
  %t84 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l50, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = load i64, ptr %l49, !tbaa !24
  %t92 = mul i64 %t91, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t88, ptr %t90, i64 %t92, i1 false)
  %t93 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t93, ptr %l48, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t94 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t94, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftarget_2ecanCompileBf16(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l3 = alloca [9 x { i64, ptr }]
  %l4 = alloca %"std/os:Output"
  %l12 = alloca [9 x { i64, ptr }]
  %l13 = alloca %"std/os:Output"
  %l17 = alloca %"std/os:Output"
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t3 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t5 = add i64 %t2, %t4
  %t6 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t5)
  call void @olang_textcopy(ptr %t6, ptr %t1, i64 %t2)
  %t7 = getelementptr i8, ptr %t6, i64 %t2
  call void @olang_textcopy(ptr %t7, ptr %t3, i64 %t4)
  %t8 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t6, 1
  %t13 = extractvalue { i64, ptr } %a0, 1
  %t14 = extractvalue { i64, ptr } %a0, 0
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t13, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t26 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t29 = extractvalue { i64, ptr } %a1, 1
  %t30 = extractvalue { i64, ptr } %a1, 0
  %t31 = add i64 %t27, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t26, i64 %t27)
  %t33 = getelementptr i8, ptr %t32, i64 %t27
  call void @olang_textcopy(ptr %t33, ptr %t29, i64 %t30)
  %t34 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t43 = getelementptr [9 x { i64, ptr }], ptr %l12, i64 0, i64 0
  store { i64, ptr } %t24, ptr %t43, !tbaa !37
  %t45 = getelementptr [9 x { i64, ptr }], ptr %l12, i64 0, i64 1
  store { i64, ptr } %t42, ptr %t45, !tbaa !37
  %t47 = getelementptr [9 x { i64, ptr }], ptr %l12, i64 0, i64 2
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %t47, !tbaa !37
  %t48 = getelementptr [9 x { i64, ptr }], ptr %l12, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %t48, !tbaa !37
  %t49 = getelementptr [9 x { i64, ptr }], ptr %l12, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %t49, !tbaa !37
  %t50 = getelementptr [9 x { i64, ptr }], ptr %l12, i64 0, i64 5
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %t50, !tbaa !37
  %t51 = getelementptr [9 x { i64, ptr }], ptr %l12, i64 0, i64 6
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %t51, !tbaa !37
  %t52 = getelementptr [9 x { i64, ptr }], ptr %l12, i64 0, i64 7
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %t52, !tbaa !37
  %t53 = getelementptr [9 x { i64, ptr }], ptr %l12, i64 0, i64 8
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %t53, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l12, i64 144, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 9, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %l3, 1
  %t60 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t56, { i64, ptr } %t9, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  %t61 = extractvalue { i32, %"std/os:Output" } %t60, 1
  %t62 = extractvalue { i32, %"std/os:Output" } %t60, 0
  store i32 %t62, ptr %l18
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb2, label %ok.64
ok.64:
  store %"std/os:Output" %t61, ptr %l17
  br label %bb1
bb1:
  %t65 = load %"std/os:Output", ptr %l17
  store %"std/os:Output" %t65, ptr %l13
  br label %bb6
bb2:
  %t66 = load i32, ptr %l18, !tbaa !23
  %t67 = ashr i32 %t66, 16
  %t69 = icmp eq i32 %t67, 1
  br i1 %t69, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_df777aa861912ce0_9be626e5398fb1ec)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t72 = load %"std/os:Output", ptr %l13
  store %"std/os:Output" %t72, ptr %l4
  %t73 = getelementptr %"std/os:Output", ptr %l4, i32 0, i32 0
  %t74 = load i32, ptr %t73, !tbaa !23
  %t76 = icmp eq i32 %t74, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t76, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eFromProbe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l24 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i32
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i32
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l60 = alloca i1
  %l61 = alloca { i64, ptr }
  %l64 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca i1
  %l69 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i32
  %l87 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l94 = alloca i1
  %l95 = alloca ptr
  %l97 = alloca i1
  %l98 = alloca i64
  %l100 = alloca ptr
  %l102 = alloca i1
  %l103 = alloca i64
  %l105 = alloca i1
  %l106 = alloca i64
  %l107 = alloca ptr
  %l109 = alloca i1
  %l110 = alloca i1
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l116 = alloca i32
  %l118 = alloca i1
  %l120 = alloca { i64, ptr }
  %l124 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i32
  %l130 = alloca i64
  %l131 = alloca { i64, ptr }
  %l132 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i32
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l162 = alloca i64
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d88, i32 0, i32 1) })
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l17
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l16
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t8, ptr %l14, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb4:
  %t10 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = call { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v1, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d89, i32 0, i32 1) })
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l22
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb6, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l21
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb8:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d90, i32 0, i32 1) })
  %t24 = extractvalue { i32, i64 } %t23, 1
  %t25 = extractvalue { i32, i64 } %t23, 0
  store i32 %t25, ptr %l27
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb10, label %ok.27
ok.27:
  store i64 %t24, ptr %l26
  br label %bb9
bb9:
  %t28 = load i64, ptr %l26, !tbaa !24
  store i64 %t28, ptr %l24, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb12:
  %t30 = load i64, ptr %l24, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t31, ptr %l30, !tbaa !27
  %t32 = load i64, ptr %l4, !tbaa !24
  store i64 %t32, ptr %l31, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t33, 0
  store i64 %t36, ptr %l34, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l35, !tbaa !24
  %t39 = load i64, ptr %l31, !tbaa !24
  %t40 = icmp sge i64 %t39, 0
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = load i64, ptr %l34, !tbaa !24
  %t44 = icmp sle i64 %t42, %t43
  br i1 %t44, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_2b3d593c994025a_f25bcfc8e3895e8e)
  unreachable
bb15:
  %t46 = load i64, ptr %l34, !tbaa !24
  %t47 = load i64, ptr %l35, !tbaa !24
  %t48 = icmp sle i64 %t46, %t47
  br i1 %t48, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_2b3d593c994025a_f25bcfc8e3895e8e)
  unreachable
bb17:
  %t50 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = load i64, ptr %l34, !tbaa !24
  %t54 = getelementptr i8, ptr %t51, i64 %t52
  %t55 = sub i64 %t53, %t52
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t60 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t57, i8 10)
  %t61 = extractvalue { i32, i64 } %t60, 1
  %t62 = extractvalue { i32, i64 } %t60, 0
  store i32 %t62, ptr %l42
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb20, label %ok.64
ok.64:
  store i64 %t61, ptr %l41
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_2b3d593c994025a_f25bcfc8e3895e8e)
  unreachable
bb19:
  %t65 = load i64, ptr %l41, !tbaa !24
  store i64 %t65, ptr %l29, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  call void @__olang_ert_req_clear()
  %t66 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = sub i64 %t68, %t69
  store i64 %t72, ptr %l29, !tbaa !24
  br label %bb22
bb22:
  %t74 = load i64, ptr %l29, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t75, ptr %l47, !tbaa !27
  %t76 = load i64, ptr %l4, !tbaa !24
  store i64 %t76, ptr %l48, !tbaa !24
  %t77 = load i64, ptr %l4, !tbaa !24
  %t81 = add i64 %t77, %t74
  store i64 %t81, ptr %l51, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l52, !tbaa !24
  %t84 = load i64, ptr %l48, !tbaa !24
  %t85 = icmp sge i64 %t84, 0
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = load i64, ptr %l51, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_41dcdde6fea423b7_7dcc0ffa4d83aa8b)
  unreachable
bb25:
  %t91 = load i64, ptr %l51, !tbaa !24
  %t92 = load i64, ptr %l52, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  br i1 %t93, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_41dcdde6fea423b7_7dcc0ffa4d83aa8b)
  unreachable
bb27:
  %t95 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l48, !tbaa !24
  %t98 = load i64, ptr %l51, !tbaa !24
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l6, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = icmp eq i64 %t106, 0
  br i1 %t108, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_41dcdde6fea423b7_7dcc0ffa4d83aa8b)
  unreachable
bb29:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb31
bb30:
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t110, ptr %l61, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 0
  %t114 = load i8, ptr %t113, !tbaa !32
  %t116 = icmp ne i8 %t114, 101
  store i1 %t116, ptr %l60, !tbaa !21
  br label %bb31
bb31:
  %t118 = load i1, ptr %l60, !tbaa !21
  br i1 %t118, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb35
bb33:
  %t119 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t123 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t119, { i64, ptr } %t122)
  store i1 %t123, ptr %l68
  br label %bb34
bb34:
  %t124 = load i1, ptr %l68, !tbaa !21
  store i1 %t124, ptr %l64, !tbaa !21
  br label %bb35
bb35:
  %t125 = load i1, ptr %l64, !tbaa !21
  br i1 %t125, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb39
bb37:
  %t126 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l72, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t130 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t126, { i64, ptr } %t129)
  store i1 %t130, ptr %l73
  br label %bb38
bb38:
  %t131 = load i1, ptr %l73, !tbaa !21
  store i1 %t131, ptr %l69, !tbaa !21
  br label %bb39
bb39:
  %t132 = load i1, ptr %l69, !tbaa !21
  br i1 %t132, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = extractvalue { i64, ptr } %t135, 0
  %t139 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t137, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } %t141, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t151 = getelementptr %"compiler/target:Target", ptr %t134, i32 0, i32 1
  store { i64, ptr } %t148, ptr %t151, !tbaa !27
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l79, !tbaa !29
  %t153 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t155 = call { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v1, ptr %s0, { i64, ptr } %t153, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d93, i32 0, i32 1) })
  %t156 = extractvalue { i32, { i64, ptr } } %t155, 1
  %t157 = extractvalue { i32, { i64, ptr } } %t155, 0
  store i32 %t157, ptr %l83
  %t158 = icmp ne i32 %t157, 0
  br i1 %t158, label %bb44, label %ok.159
ok.159:
  store { i64, ptr } %t156, ptr %l82
  br label %bb43
bb43:
  %t160 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t160, ptr %l80, !tbaa !27
  br label %bb46
bb44:
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb46:
  %t162 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 1
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t165 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t164)
  call void @olang_textcopy(ptr %t165, ptr %t163, i64 %t164)
  %t166 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = extractvalue { i64, ptr } %t167, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t176 = load ptr, ptr %l79, !tbaa !29
  %t177 = getelementptr %"compiler/target:Target", ptr %t176, i32 0, i32 4
  store { i64, ptr } %t174, ptr %t177, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t180 = call { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v1, ptr %s0, { i64, ptr } %t178, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d94, i32 0, i32 1) })
  %t181 = extractvalue { i32, { i64, ptr } } %t180, 1
  %t182 = extractvalue { i32, { i64, ptr } } %t180, 0
  store i32 %t182, ptr %l90
  %t183 = icmp ne i32 %t182, 0
  br i1 %t183, label %bb48, label %ok.184
ok.184:
  store { i64, ptr } %t181, ptr %l89
  br label %bb47
bb47:
  %t185 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t185, ptr %l87, !tbaa !27
  br label %bb50
bb48:
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb50
bb50:
  %t186 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t187 = call { i64, ptr } @compiler_2ftarget_2eStripUnsafe(ptr %v1, ptr %s0, { i64, ptr } %t186)
  store { i64, ptr } %t187, ptr %l91
  br label %bb51
bb51:
  %t188 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t188, ptr %l7, !tbaa !27
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/target:Target", ptr %t189, i32 0, i32 2
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  %t194 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t192, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t194, ptr %l94
  br label %bb52
bb52:
  %t195 = load i1, ptr %l94, !tbaa !21
  br i1 %t195, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s8
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l95, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t199 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s8, { i64, ptr } %t197, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store i1 %t199, ptr %l97
  br label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l100, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t203 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s9, { i64, ptr } %t201, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t203, ptr %l102
  br label %bb59
bb55:
  %t204 = load i1, ptr %l97, !tbaa !21
  br i1 %t204, label %bb56, label %bb57
bb56:
  store i64 128, ptr %l98, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb58
bb58:
  %t205 = load i64, ptr %l98, !tbaa !24
  %t206 = load ptr, ptr %l95, !tbaa !29
  %t207 = getelementptr %"compiler/target:Target", ptr %t206, i32 0, i32 7
  store i64 %t205, ptr %t207, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/target:Target", ptr %t208, i32 0, i32 8
  store i1 true, ptr %t210, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb72
bb59:
  %t211 = load i1, ptr %l102, !tbaa !21
  br i1 %t211, label %bb60, label %bb61
bb60:
  store i64 512, ptr %l103, !tbaa !24
  br label %bb66
bb61:
  %t212 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t214 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s9, { i64, ptr } %t212, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t214, ptr %l105
  br label %bb62
bb62:
  %t215 = load i1, ptr %l105, !tbaa !21
  br i1 %t215, label %bb63, label %bb64
bb63:
  store i64 256, ptr %l106, !tbaa !24
  br label %bb65
bb64:
  store i64 128, ptr %l106, !tbaa !24
  br label %bb65
bb65:
  %t216 = load i64, ptr %l106, !tbaa !24
  store i64 %t216, ptr %l103, !tbaa !24
  br label %bb66
bb66:
  %t217 = load i64, ptr %l103, !tbaa !24
  %t218 = load ptr, ptr %l100, !tbaa !29
  %t219 = getelementptr %"compiler/target:Target", ptr %t218, i32 0, i32 7
  store i64 %t217, ptr %t219, !tbaa !24
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l107, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t223 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s9, { i64, ptr } %t221, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t223, ptr %l109
  br label %bb67
bb67:
  %t224 = load i1, ptr %l109, !tbaa !21
  br i1 %t224, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb71
bb69:
  %t225 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t227 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s9, { i64, ptr } %t225, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t227, ptr %l112
  br label %bb70
bb70:
  %t228 = load i1, ptr %l112, !tbaa !21
  store i1 %t228, ptr %l110, !tbaa !21
  br label %bb71
bb71:
  %t229 = load i1, ptr %l110, !tbaa !21
  %t230 = load ptr, ptr %l107, !tbaa !29
  %t231 = getelementptr %"compiler/target:Target", ptr %t230, i32 0, i32 8
  store i1 %t229, ptr %t231, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb72:
  %t232 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t234 = call { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v1, ptr %s0, { i64, ptr } %t232, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d102, i32 0, i32 1) })
  %t235 = extractvalue { i32, { i64, ptr } } %t234, 1
  %t236 = extractvalue { i32, { i64, ptr } } %t234, 0
  store i32 %t236, ptr %l116
  %t237 = icmp ne i32 %t236, 0
  br i1 %t237, label %bb74, label %ok.238
ok.238:
  store { i64, ptr } %t235, ptr %l115
  br label %bb73
bb73:
  %t239 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t239, ptr %l113, !tbaa !27
  br label %bb76
bb74:
  br label %bb75
bb75:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d103, i32 0, i32 1) }, ptr %l113, !tbaa !27
  br label %bb76
bb76:
  %t240 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t240, ptr %l8, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t243 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t241, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d104, i32 0, i32 1) })
  store i1 %t243, ptr %l118
  br label %bb77
bb77:
  %t244 = load i1, ptr %l118, !tbaa !21
  %t245 = xor i1 %t244, true
  br i1 %t245, label %bb78, label %bb79
bb78:
  %t247 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t248 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t251 = extractvalue { i64, ptr } %t247, 1
  %t252 = extractvalue { i64, ptr } %t247, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l120, !tbaa !27
  br label %bb80
bb79:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d107, i32 0, i32 1) }, ptr %l120, !tbaa !27
  br label %bb80
bb80:
  %t270 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t270, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d108, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t273 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t271, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d109, i32 0, i32 1) })
  %t274 = extractvalue { i32, i64 } %t273, 1
  %t275 = extractvalue { i32, i64 } %t273, 0
  store i32 %t275, ptr %l127
  %t276 = icmp ne i32 %t275, 0
  br i1 %t276, label %bb82, label %ok.277
ok.277:
  store i64 %t274, ptr %l126
  br label %bb81
bb81:
  %t278 = load i64, ptr %l126, !tbaa !24
  store i64 %t278, ptr %l124, !tbaa !24
  br label %bb84
bb82:
  br label %bb83
bb83:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l124, !tbaa !24
  br label %bb84
bb84:
  %t279 = load i64, ptr %l124, !tbaa !24
  store i64 %t279, ptr %l11, !tbaa !24
  %t280 = load i64, ptr %l11, !tbaa !24
  %t282 = icmp sge i64 %t280, 0
  br i1 %t282, label %bb85, label %bb86
bb85:
  %t284 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t284, ptr %l131, !tbaa !27
  %t285 = load i64, ptr %l11, !tbaa !24
  store i64 %t285, ptr %l132, !tbaa !24
  %t286 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t289 = extractvalue { i64, ptr } %t286, 0
  store i64 %t289, ptr %l135, !tbaa !24
  %t290 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 0
  store i64 %t291, ptr %l136, !tbaa !24
  %t292 = load i64, ptr %l132, !tbaa !24
  %t293 = icmp sge i64 %t292, 0
  br i1 %t293, label %bb87, label %bb88
bb86:
  br label %bb106
bb87:
  %t295 = load i64, ptr %l132, !tbaa !24
  %t296 = load i64, ptr %l135, !tbaa !24
  %t297 = icmp sle i64 %t295, %t296
  br i1 %t297, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @olang_loc_e010b40d861556cc_7cbd713015487310)
  unreachable
bb89:
  %t299 = load i64, ptr %l135, !tbaa !24
  %t300 = load i64, ptr %l136, !tbaa !24
  %t301 = icmp sle i64 %t299, %t300
  br i1 %t301, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_e010b40d861556cc_7cbd713015487310)
  unreachable
bb91:
  %t303 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = load i64, ptr %l132, !tbaa !24
  %t306 = load i64, ptr %l135, !tbaa !24
  %t307 = getelementptr i8, ptr %t304, i64 %t305
  %t308 = sub i64 %t306, %t305
  %t309 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t307, 1
  %t313 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t310, i8 41)
  %t314 = extractvalue { i32, i64 } %t313, 1
  %t315 = extractvalue { i32, i64 } %t313, 0
  store i32 %t315, ptr %l143
  %t316 = icmp ne i32 %t315, 0
  br i1 %t316, label %bb94, label %ok.317
ok.317:
  store i64 %t314, ptr %l142
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_e010b40d861556cc_7cbd713015487310)
  unreachable
bb93:
  %t318 = load i64, ptr %l142, !tbaa !24
  store i64 %t318, ptr %l130, !tbaa !24
  br label %bb96
bb94:
  br label %bb95
bb95:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l130, !tbaa !24
  br label %bb96
bb96:
  %t319 = load i64, ptr %l130, !tbaa !24
  store i64 %t319, ptr %l12, !tbaa !24
  %t320 = load i64, ptr %l12, !tbaa !24
  %t322 = icmp sge i64 %t320, 0
  br i1 %t322, label %bb97, label %bb98
bb97:
  %t324 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t324, ptr %l146, !tbaa !27
  %t325 = load i64, ptr %l11, !tbaa !24
  store i64 %t325, ptr %l147, !tbaa !24
  %t326 = load i64, ptr %l11, !tbaa !24
  %t327 = load i64, ptr %l12, !tbaa !24
  %t330 = add i64 %t326, %t327
  %t332 = add i64 %t330, 1
  store i64 %t332, ptr %l151, !tbaa !24
  %t333 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t333, 0
  store i64 %t334, ptr %l152, !tbaa !24
  %t335 = load i64, ptr %l147, !tbaa !24
  %t336 = icmp sge i64 %t335, 0
  br i1 %t336, label %bb99, label %bb100
bb98:
  br label %bb105
bb99:
  %t338 = load i64, ptr %l147, !tbaa !24
  %t339 = load i64, ptr %l151, !tbaa !24
  %t340 = icmp sle i64 %t338, %t339
  br i1 %t340, label %bb101, label %bb102
bb100:
  call void @__olang_check_failed(ptr @olang_loc_8cdf81df4f8deaf9_3f7b7447e7e110ed)
  unreachable
bb101:
  %t342 = load i64, ptr %l151, !tbaa !24
  %t343 = load i64, ptr %l152, !tbaa !24
  %t344 = icmp sle i64 %t342, %t343
  br i1 %t344, label %bb103, label %bb104
bb102:
  call void @__olang_check_failed(ptr @olang_loc_8cdf81df4f8deaf9_3f7b7447e7e110ed)
  unreachable
bb103:
  %t346 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = load i64, ptr %l147, !tbaa !24
  %t349 = load i64, ptr %l151, !tbaa !24
  %t350 = getelementptr i8, ptr %t347, i64 %t348
  %t351 = sub i64 %t349, %t348
  %t352 = insertvalue { i64, ptr } undef, i64 %t351, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t350, 1
  %t354 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t355 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t357 = extractvalue { i64, ptr } %t353, 1
  %t358 = extractvalue { i64, ptr } %t353, 0
  %t359 = add i64 %t355, %t358
  %t360 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t359)
  call void @olang_textcopy(ptr %t360, ptr %t354, i64 %t355)
  %t361 = getelementptr i8, ptr %t360, i64 %t355
  call void @olang_textcopy(ptr %t361, ptr %t357, i64 %t358)
  %t362 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t360, 1
  %t365 = extractvalue { i64, ptr } %t363, 0
  %t366 = extractvalue { i64, ptr } %t363, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  store { i64, ptr } %t370, ptr %l10, !tbaa !27
  br label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_8cdf81df4f8deaf9_3f7b7447e7e110ed)
  unreachable
bb105:
  br label %bb106
bb106:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/target:Target", ptr %t372, i32 0, i32 7
  %t375 = load i64, ptr %t374, !tbaa !24
  %t377 = icmp sgt i64 %t375, 0
  br i1 %t377, label %bb107, label %bb108
bb107:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/target:Target", ptr %t379, i32 0, i32 7
  %t382 = load i64, ptr %t381, !tbaa !24
  store i64 %t382, ptr %l162, !tbaa !24
  br label %bb109
bb108:
  store i64 128, ptr %l162, !tbaa !24
  br label %bb109
bb109:
  %t384 = load i64, ptr %l162, !tbaa !24
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/target:Target", ptr %t386, i32 0, i32 4
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  %t390 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t391 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t392 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t394 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t395 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t397 = extractvalue { i64, ptr } %t389, 1
  %t398 = extractvalue { i64, ptr } %t389, 0
  %t399 = add i64 %t395, %t398
  %t400 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t401 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t402 = add i64 %t399, %t401
  %t404 = extractvalue { i64, ptr } %t390, 1
  %t405 = extractvalue { i64, ptr } %t390, 0
  %t406 = add i64 %t402, %t405
  %t407 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t408 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t409 = add i64 %t406, %t408
  %t411 = extractvalue { i64, ptr } %t391, 1
  %t412 = extractvalue { i64, ptr } %t391, 0
  %t413 = add i64 %t409, %t412
  %t415 = extractvalue { i64, ptr } %t392, 1
  %t416 = extractvalue { i64, ptr } %t392, 0
  %t417 = add i64 %t413, %t416
  %t418 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t420 = add i64 %t417, %t419
  %t422 = call i64 @__olang_fmt_i64(ptr null, i64 %t384)
  %t423 = add i64 %t420, %t422
  %t424 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t425 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t426 = add i64 %t423, %t425
  %t427 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t426)
  call void @olang_textcopy(ptr %t427, ptr %t394, i64 %t395)
  %t428 = getelementptr i8, ptr %t427, i64 %t395
  call void @olang_textcopy(ptr %t428, ptr %t397, i64 %t398)
  %t429 = getelementptr i8, ptr %t428, i64 %t398
  call void @olang_textcopy(ptr %t429, ptr %t400, i64 %t401)
  %t430 = getelementptr i8, ptr %t429, i64 %t401
  call void @olang_textcopy(ptr %t430, ptr %t404, i64 %t405)
  %t431 = getelementptr i8, ptr %t430, i64 %t405
  call void @olang_textcopy(ptr %t431, ptr %t407, i64 %t408)
  %t432 = getelementptr i8, ptr %t431, i64 %t408
  call void @olang_textcopy(ptr %t432, ptr %t411, i64 %t412)
  %t433 = getelementptr i8, ptr %t432, i64 %t412
  call void @olang_textcopy(ptr %t433, ptr %t415, i64 %t416)
  %t434 = getelementptr i8, ptr %t433, i64 %t416
  call void @olang_textcopy(ptr %t434, ptr %t418, i64 %t419)
  %t435 = getelementptr i8, ptr %t434, i64 %t419
  %t436 = call i64 @__olang_fmt_i64(ptr %t435, i64 %t384)
  %t437 = getelementptr i8, ptr %t435, i64 %t422
  call void @olang_textcopy(ptr %t437, ptr %t424, i64 %t425)
  %t438 = insertvalue { i64, ptr } undef, i64 %t426, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t427, 1
  %t441 = extractvalue { i64, ptr } %t439, 0
  %t442 = extractvalue { i64, ptr } %t439, 1
  %t443 = mul i64 %t441, 1
  %t444 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t443)
  call void @llvm.memcpy.p0.p0.i64(ptr %t444, ptr %t442, i64 %t443, i1 false)
  %t445 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr %t444, 1
  %t449 = getelementptr %"compiler/target:Target", ptr %t385, i32 0, i32 5
  store { i64, ptr } %t446, ptr %t449, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eRunner(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l32 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l43 = alloca i1
  %l52 = alloca i64
  %l54 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca i1
  %l60 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l92 = alloca i1
  %l97 = alloca { i64, ptr }
  %l99 = alloca i1
  %l100 = alloca i1
  %l105 = alloca i1
  %l108 = alloca { i64, ptr }
  %l110 = alloca i64
  %l113 = alloca i1
  %l121 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l123 = alloca i64
  %l124 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/target:Target", ptr %t5, i32 0, i32 9
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp1
  %t14 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t12)
  store { i64, ptr } %t14, ptr %l18
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t15 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t15, ptr %l19, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l20, !tbaa !24
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = mul i64 %t18, 16
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l21, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l20, !tbaa !24
  %t28 = mul i64 %t27, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t30, 1
  store { i32, { i64, ptr } } %t31, ptr %rv
  br label %ret
bb5:
  %t32 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d115, i32 0, i32 1) })
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l24
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb7, label %ok.36
ok.36:
  store { i64, ptr } %t33, ptr %l23
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t37, ptr %l22, !tbaa !27
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d116, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l22, !tbaa !27
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t47, ptr %l2, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t48, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d117, i32 0, i32 1) })
  store i1 %t50, ptr %l29
  br label %bb10
bb10:
  %t51 = load i1, ptr %l29, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t56 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s3, { i64, ptr } %t54, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) })
  store { i64, ptr } %t56, ptr %l32
  br label %bb13
bb12:
  br label %bb38
bb13:
  %t57 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t57, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t62 = load i64, ptr %l4, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb16:
  br label %bb17
bb17:
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l39, !tbaa !27
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %t74, i64 %t71
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !37
  store { i64, ptr } %t76, ptr %l6, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t78, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d119, i32 0, i32 1) })
  store i1 %t80, ptr %l43
  br label %bb18
bb18:
  %t81 = load i1, ptr %l43, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb19, label %bb20
bb19:
  %t84 = load ptr, ptr %lp1
  %t85 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = extractvalue { i64, ptr } %t85, 0
  %t89 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t87, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t84, { i64, ptr } %t98)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t101 = load i64, ptr %l4, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l4, !tbaa !24
  br label %bb14
bb24:
  call void @__olang_scope_close(ptr %s3)
  %t105 = load ptr, ptr %lp1
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t105)
  store i64 %t107, ptr %l52
  br label %bb25
bb25:
  %t108 = load i64, ptr %l52, !tbaa !24
  %t109 = icmp eq i64 %t108, 0
  br i1 %t109, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb30
bb27:
  %t111 = load ptr, ptr %lp1
  %t113 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t111, i64 0)
  store { i64, ptr } %t113, ptr %l56
  br label %bb28
bb28:
  %t114 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t115 = call i1 @compiler_2ftarget_2eexecutable(ptr %v1, { i64, ptr } %t114)
  store i1 %t115, ptr %l57
  br label %bb29
bb29:
  %t116 = load i1, ptr %l57, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l54, !tbaa !21
  br label %bb30
bb30:
  %t119 = load i1, ptr %l54, !tbaa !21
  br i1 %t119, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t121 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t121, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t122 = load ptr, ptr %lp1
  store ptr %t122, ptr %l60, !tbaa !29
  %t123 = load ptr, ptr %lp1
  %t125 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t123, i64 0)
  store { i64, ptr } %t125, ptr %l62
  br label %bb34
bb34:
  %t126 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t127 = call { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %v1, ptr %v1, { i64, ptr } %t126)
  store { i64, ptr } %t127, ptr %l63
  br label %bb35
bb35:
  %t128 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t135 = load ptr, ptr %l60, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v1, ptr %v1, ptr %t135, i64 0, { i64, ptr } %t134)
  br label %bb36
bb36:
  %t137 = load ptr, ptr %lp1
  %t139 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t137)
  store { i64, ptr } %t139, ptr %l66
  br label %bb37
bb37:
  %t140 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t140, ptr %l67, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l68, !tbaa !24
  %t143 = load i64, ptr %l68, !tbaa !24
  %t144 = mul i64 %t143, 16
  %t145 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l69, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = load i64, ptr %l68, !tbaa !24
  %t153 = mul i64 %t152, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t149, ptr %t151, i64 %t153, i1 false)
  %t154 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t154, ptr %l67, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t155 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t156 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t155, 1
  store { i32, { i64, ptr } } %t156, ptr %rv
  br label %ret
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/target:Target", ptr %t157, i32 0, i32 2
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t161 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t164 = extractvalue { i64, ptr } %t160, 1
  %t165 = extractvalue { i64, ptr } %t160, 0
  %t166 = add i64 %t162, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t161, i64 %t162)
  %t168 = getelementptr i8, ptr %t167, i64 %t162
  call void @olang_textcopy(ptr %t168, ptr %t164, i64 %t165)
  %t169 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t167, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = extractvalue { i64, ptr } %t170, 1
  %t174 = mul i64 %t172, 1
  %t175 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t174)
  call void @llvm.memcpy.p0.p0.i64(ptr %t175, ptr %t173, i64 %t174, i1 false)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/target:Target", ptr %t178, i32 0, i32 2
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  %t182 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t185 = extractvalue { i64, ptr } %t181, 1
  %t186 = extractvalue { i64, ptr } %t181, 0
  %t187 = add i64 %t183, %t186
  %t188 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t189 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t190 = add i64 %t187, %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t182, i64 %t183)
  %t192 = getelementptr i8, ptr %t191, i64 %t183
  call void @olang_textcopy(ptr %t192, ptr %t185, i64 %t186)
  %t193 = getelementptr i8, ptr %t192, i64 %t186
  call void @olang_textcopy(ptr %t193, ptr %t188, i64 %t189)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t191, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } %t195, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  %t204 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t177, 0
  %t206 = insertvalue [2 x { i64, ptr }] %t204, { i64, ptr } %t202, 1
  %t208 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 32, i64 8)
  store [2 x { i64, ptr }] %t206, ptr %t208
  store ptr %t208, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t210 = load ptr, ptr %l7
  store i64 2, ptr %l9, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s12
  %t213 = load i64, ptr %l8, !tbaa !24
  %t214 = load i64, ptr %l9, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s12)
  br label %bb69
bb41:
  br label %bb42
bb42:
  %t221 = load ptr, ptr %l7
  %t222 = load i64, ptr %l8, !tbaa !24
  %t225 = getelementptr [2 x { i64, ptr }], ptr %t221, i64 0, i64 %t222
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !37
  %t230 = call { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %s9, ptr %s12, { i64, ptr } %t226)
  store { i64, ptr } %t230, ptr %l90
  br label %bb43
bb43:
  %t231 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t231, ptr %l11, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t234 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s12, ptr %s12, { i64, ptr } %t232, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d123, i32 0, i32 1) })
  store i1 %t234, ptr %l92
  br label %bb44
bb44:
  %t235 = load i1, ptr %l92, !tbaa !21
  br i1 %t235, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s12)
  br label %bb68
bb46:
  br label %bb47
bb47:
  %t236 = load ptr, ptr %lp1
  %t237 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t237, 1
  %t240 = extractvalue { i64, ptr } %t237, 0
  %t241 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t239, i64 %t240)
  %t242 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t236, { i64, ptr } %t250)
  br label %bb48
bb48:
  %t253 = call { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %s12)
  store { i64, ptr } %t253, ptr %l97
  br label %bb49
bb49:
  %t254 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t254, ptr %l12, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t257 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s12, ptr %s12, { i64, ptr } %t255, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d124, i32 0, i32 1) })
  store i1 %t257, ptr %l99
  br label %bb50
bb50:
  %t258 = load i1, ptr %l99, !tbaa !21
  br i1 %t258, label %bb51, label %bb52
bb51:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/target:Target", ptr %t259, i32 0, i32 2
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t263 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t266 = extractvalue { i64, ptr } %t262, 1
  %t267 = extractvalue { i64, ptr } %t262, 0
  %t268 = add i64 %t264, %t267
  %t269 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t270 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t271 = add i64 %t268, %t270
  %t272 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t271)
  call void @olang_textcopy(ptr %t272, ptr %t263, i64 %t264)
  %t273 = getelementptr i8, ptr %t272, i64 %t264
  call void @olang_textcopy(ptr %t273, ptr %t266, i64 %t267)
  %t274 = getelementptr i8, ptr %t273, i64 %t267
  call void @olang_textcopy(ptr %t274, ptr %t269, i64 %t270)
  %t275 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t272, 1
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t279 = extractvalue { i64, ptr } %t276, 1
  %t280 = mul i64 %t278, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t279, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  %t285 = call i1 @std_2fos_2eIsDir(ptr %s12, { i64, ptr } %t283)
  store i1 %t285, ptr %l105
  br label %bb53
bb52:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb54
bb53:
  %t286 = load i1, ptr %l105, !tbaa !21
  store i1 %t286, ptr %l100, !tbaa !21
  br label %bb54
bb54:
  %t287 = load i1, ptr %l100, !tbaa !21
  br i1 %t287, label %bb55, label %bb56
bb55:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/target:Target", ptr %t288, i32 0, i32 2
  %t291 = load { i64, ptr }, ptr %t290, !tbaa !27
  %t292 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t293 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t295 = extractvalue { i64, ptr } %t291, 1
  %t296 = extractvalue { i64, ptr } %t291, 0
  %t297 = add i64 %t293, %t296
  %t298 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t300 = add i64 %t297, %t299
  %t301 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t300)
  call void @olang_textcopy(ptr %t301, ptr %t292, i64 %t293)
  %t302 = getelementptr i8, ptr %t301, i64 %t293
  call void @olang_textcopy(ptr %t302, ptr %t295, i64 %t296)
  %t303 = getelementptr i8, ptr %t302, i64 %t296
  call void @olang_textcopy(ptr %t303, ptr %t298, i64 %t299)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t301, 1
  store { i64, ptr } %t305, ptr %l108, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 0
  %t308 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  store i64 %t309, ptr %l110, !tbaa !24
  %t311 = load i64, ptr %l110, !tbaa !24
  %t312 = icmp eq i64 %t307, %t311
  br i1 %t312, label %bb57, label %bb58
bb56:
  br label %bb60
bb57:
  %t314 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = load i64, ptr %l110, !tbaa !24
  %t319 = mul i64 %t318, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t315, ptr %t317, i64 %t319, i1 false)
  br label %bb59
bb58:
  %t320 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t320, ptr %l12, !tbaa !27
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t321 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t323 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s12, ptr %s12, { i64, ptr } %t321, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d129, i32 0, i32 1) })
  store i1 %t323, ptr %l113
  br label %bb61
bb61:
  %t324 = load i1, ptr %l113, !tbaa !21
  %t325 = xor i1 %t324, true
  br i1 %t325, label %bb62, label %bb63
bb62:
  %t327 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t327, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d130, i32 0, i32 1) })
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t329 = load ptr, ptr %lp1
  %t330 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t330, 1
  %t333 = extractvalue { i64, ptr } %t330, 0
  %t334 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t333)
  call void @olang_textcopy(ptr %t334, ptr %t332, i64 %t333)
  %t335 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t334, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = extractvalue { i64, ptr } %t336, 1
  %t340 = mul i64 %t338, 1
  %t341 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t340)
  call void @llvm.memcpy.p0.p0.i64(ptr %t341, ptr %t339, i64 %t340, i1 false)
  %t342 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t341, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t329, { i64, ptr } %t343)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t346 = load ptr, ptr %lp1
  %t348 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t346)
  store { i64, ptr } %t348, ptr %l121
  br label %bb67
bb67:
  %t349 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t349, ptr %l122, !tbaa !27
  %t350 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 0
  store i64 %t351, ptr %l123, !tbaa !24
  %t352 = load i64, ptr %l123, !tbaa !24
  %t353 = mul i64 %t352, 16
  %t354 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t353)
  %t355 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t354, 1
  store { i64, ptr } %t356, ptr %l124, !tbaa !27
  %t357 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !27
  %t361 = load i64, ptr %l123, !tbaa !24
  %t362 = mul i64 %t361, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t358, ptr %t360, i64 %t362, i1 false)
  %t363 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t363, ptr %l122, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t364 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t365 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t364, 1
  store { i32, { i64, ptr } } %t365, ptr %rv
  br label %ret
bb68:
  %t366 = load i64, ptr %l8, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l8, !tbaa !24
  br label %bb39
bb69:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t371 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t371, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2ewithoutClang(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l11 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l24 = alloca i64
  %l26 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i64
  %l40 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l50 = alloca i64
  %l53 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/target:Target", ptr %t2, i32 0, i32 2
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t7, i64 %t8)
  %t13 = getelementptr i8, ptr %t12, i64 %t8
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = getelementptr %"compiler/target:Target", ptr %t1, i32 0, i32 1
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/target:Target", ptr %t26, i32 0, i32 2
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d132, i32 0, i32 1) })
  store i1 %t31, ptr %l11
  br label %bb1
bb1:
  %t32 = load i1, ptr %l11, !tbaa !21
  br i1 %t32, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d133, i32 0, i32 1) })
  store i1 %t35, ptr %l13
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t36 = load i1, ptr %l13, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t39, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d134, i32 0, i32 1) })
  store i1 %t41, ptr %l17
  br label %bb7
bb6:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  %t42 = load i1, ptr %l17, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l15, !tbaa !21
  br i1 %t45, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/target:Target", ptr %t47, i32 0, i32 4
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d135, i32 0, i32 1) }, ptr %t49, !tbaa !27
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/target:Target", ptr %t50, i32 0, i32 7
  store i64 128, ptr %t52, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/target:Target", ptr %t53, i32 0, i32 8
  store i1 true, ptr %t55, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb12:
  %t57 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t57, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d136, i32 0, i32 1) })
  store i1 %t59, ptr %l26
  br label %bb13
bb13:
  %t60 = load i1, ptr %l26, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i64 1, ptr %l24, !tbaa !24
  br label %bb43
bb17:
  %t61 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d137, i32 0, i32 1) })
  store i1 %t63, ptr %l28
  br label %bb18
bb18:
  %t64 = load i1, ptr %l28, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i64 2, ptr %l24, !tbaa !24
  br label %bb43
bb22:
  %t65 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d138, i32 0, i32 1) })
  store i1 %t67, ptr %l30
  br label %bb23
bb23:
  %t68 = load i1, ptr %l30, !tbaa !21
  br i1 %t68, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i64 3, ptr %l24, !tbaa !24
  br label %bb43
bb27:
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d139, i32 0, i32 1) })
  store i1 %t71, ptr %l32
  br label %bb28
bb28:
  %t72 = load i1, ptr %l32, !tbaa !21
  br i1 %t72, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i64 4, ptr %l24, !tbaa !24
  br label %bb43
bb32:
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d140, i32 0, i32 1) })
  store i1 %t75, ptr %l34
  br label %bb33
bb33:
  %t76 = load i1, ptr %l34, !tbaa !21
  br i1 %t76, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t79 = call i64 @compiler_2ftarget_2eX86Level(ptr %v2, { i64, ptr } %a2)
  store i64 %t79, ptr %l36
  br label %bb37
bb37:
  %t80 = load i64, ptr %l36, !tbaa !24
  store i64 %t80, ptr %l24, !tbaa !24
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_85332b5eb98b88c2_ab57175d397d1606)
  unreachable
bb43:
  %t81 = load i64, ptr %l24, !tbaa !24
  store i64 %t81, ptr %l3, !tbaa !24
  %t82 = load i64, ptr %l3, !tbaa !24
  %t84 = icmp eq i64 %t82, 0
  br i1 %t84, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l40, !tbaa !29
  %t88 = load i64, ptr %l3, !tbaa !24
  %t90 = icmp eq i64 %t88, 1
  br i1 %t90, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d141, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb49
bb48:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t93 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t96 = call i64 @__olang_fmt_i64(ptr null, i64 %t92)
  %t97 = add i64 %t94, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t93, i64 %t94)
  %t99 = getelementptr i8, ptr %t98, i64 %t94
  %t100 = call i64 @__olang_fmt_i64(ptr %t99, i64 %t92)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t98, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t105 = extractvalue { i64, ptr } %t102, 1
  %t106 = mul i64 %t104, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t106)
  call void @llvm.memcpy.p0.p0.i64(ptr %t107, ptr %t105, i64 %t106, i1 false)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l43, !tbaa !27
  br label %bb49
bb49:
  %t111 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t112 = load ptr, ptr %l40, !tbaa !29
  %t113 = getelementptr %"compiler/target:Target", ptr %t112, i32 0, i32 4
  store { i64, ptr } %t111, ptr %t113, !tbaa !27
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l47, !tbaa !29
  %t115 = load i64, ptr %l3, !tbaa !24
  %t117 = icmp eq i64 %t115, 4
  br i1 %t117, label %bb50, label %bb51
bb50:
  store i64 512, ptr %l50, !tbaa !24
  br label %bb55
bb51:
  %t119 = load i64, ptr %l3, !tbaa !24
  %t121 = icmp eq i64 %t119, 3
  br i1 %t121, label %bb52, label %bb53
bb52:
  store i64 256, ptr %l53, !tbaa !24
  br label %bb54
bb53:
  store i64 128, ptr %l53, !tbaa !24
  br label %bb54
bb54:
  %t123 = load i64, ptr %l53, !tbaa !24
  store i64 %t123, ptr %l50, !tbaa !24
  br label %bb55
bb55:
  %t124 = load i64, ptr %l50, !tbaa !24
  %t125 = load ptr, ptr %l47, !tbaa !29
  %t126 = getelementptr %"compiler/target:Target", ptr %t125, i32 0, i32 7
  store i64 %t124, ptr %t126, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l3, !tbaa !24
  %t130 = icmp sge i64 %t128, 3
  %t133 = getelementptr %"compiler/target:Target", ptr %t127, i32 0, i32 8
  store i1 %t130, ptr %t133, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2ecpuFlags(ptr %v0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:LineIter"
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d143, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l6
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l6, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_76ff016df127c4d3_50e3c4f0063661b7)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d144, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t12, ptr %l10, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load i64, ptr %l11, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l12, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l11, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t26, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t27 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb6:
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t28)
  store %"std/prelude/text:LineIter" %t31, ptr %l14
  br label %bb7
bb7:
  %t32 = load %"std/prelude/text:LineIter", ptr %l14
  store %"std/prelude/text:LineIter" %t32, ptr %l1
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %l1)
  %t35 = extractvalue { i32, { i64, ptr } } %t34, 1
  %t36 = extractvalue { i32, { i64, ptr } } %t34, 0
  store i32 %t36, ptr %l18
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38
ok.38:
  store { i64, ptr } %t35, ptr %l17
  br label %bb9
bb9:
  %t39 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t39, ptr %l15, !tbaa !27
  br label %bb14
bb10:
  %t40 = load i32, ptr %l18, !tbaa !23
  %t41 = ashr i32 %t40, 16
  %t43 = icmp eq i32 %t41, 1
  br i1 %t43, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_894ce1aaf95d40d2_41321e55c77fd296)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb14:
  %t45 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t45, ptr %l2, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s3, { i64, ptr } %t46, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d145, i32 0, i32 1) })
  store i1 %t48, ptr %l22
  br label %bb15
bb15:
  %t49 = load i1, ptr %l22, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t53 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %s0, { i64, ptr } %t50, i8 58)
  %t54 = extractvalue { i32, i64 } %t53, 1
  %t55 = extractvalue { i32, i64 } %t53, 0
  store i32 %t55, ptr %l27
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb19, label %ok.57
ok.57:
  store i64 %t54, ptr %l26
  br label %bb18
bb17:
  br label %bb29
bb18:
  %t58 = load i64, ptr %l26, !tbaa !24
  store i64 %t58, ptr %l23, !tbaa !24
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d146, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l30, !tbaa !24
  %t62 = load i64, ptr %l30, !tbaa !24
  %t63 = mul i64 %t62, 1
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l31, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l30, !tbaa !24
  %t72 = mul i64 %t71, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t68, ptr %t70, i64 %t72, i1 false)
  %t73 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t73, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t74, ptr %rv
  br label %ret
bb21:
  %t75 = load i64, ptr %l23, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t76, ptr %l32, !tbaa !27
  %t79 = add i64 %t75, 1
  store i64 %t79, ptr %l34, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t80, 0
  store i64 %t83, ptr %l37, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l38, !tbaa !24
  %t86 = load i64, ptr %l34, !tbaa !24
  %t87 = icmp sge i64 %t86, 0
  br i1 %t87, label %bb22, label %bb23
bb22:
  %t89 = load i64, ptr %l34, !tbaa !24
  %t90 = load i64, ptr %l37, !tbaa !24
  %t91 = icmp sle i64 %t89, %t90
  br i1 %t91, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_5e2dfc7662e61c22_c1572e0f91c88016)
  unreachable
bb24:
  %t93 = load i64, ptr %l37, !tbaa !24
  %t94 = load i64, ptr %l38, !tbaa !24
  %t95 = icmp sle i64 %t93, %t94
  br i1 %t95, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_5e2dfc7662e61c22_c1572e0f91c88016)
  unreachable
bb26:
  %t97 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = load i64, ptr %l34, !tbaa !24
  %t100 = load i64, ptr %l37, !tbaa !24
  %t101 = getelementptr i8, ptr %t98, i64 %t99
  %t102 = sub i64 %t100, %t99
  %t103 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t101, 1
  %t106 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t104)
  store { i64, ptr } %t106, ptr %l43
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_5e2dfc7662e61c22_c1572e0f91c88016)
  unreachable
bb28:
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t109 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = add i64 %t108, %t111
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t115 = add i64 %t112, %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t115)
  call void @olang_textcopy(ptr %t116, ptr %t107, i64 %t108)
  %t117 = getelementptr i8, ptr %t116, i64 %t108
  call void @olang_textcopy(ptr %t117, ptr %t110, i64 %t111)
  %t118 = getelementptr i8, ptr %t117, i64 %t111
  call void @olang_textcopy(ptr %t118, ptr %t113, i64 %t114)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t116, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t120, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  br label %bb8
bb31:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d149, i32 0, i32 1) }, ptr %l45, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t122, ptr %l46, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l47, !tbaa !24
  %t125 = load i64, ptr %l47, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l48, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l47, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t136, ptr %l46, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2ecpuModel(ptr %v0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:LineIter"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/text:LineIter"
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l21 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d150, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l5
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6a809c42d90c2601_8916f15013bc8fd5)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d151, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l10, !tbaa !24
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l11, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l10, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t26, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t27 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb6:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t28)
  store %"std/prelude/text:LineIter" %t31, ptr %l13
  br label %bb7
bb7:
  %t32 = load %"std/prelude/text:LineIter", ptr %l13
  store %"std/prelude/text:LineIter" %t32, ptr %l1
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %l1)
  %t35 = extractvalue { i32, { i64, ptr } } %t34, 1
  %t36 = extractvalue { i32, { i64, ptr } } %t34, 0
  store i32 %t36, ptr %l17
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38
ok.38:
  store { i64, ptr } %t35, ptr %l16
  br label %bb9
bb9:
  %t39 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t39, ptr %l14, !tbaa !27
  br label %bb14
bb10:
  %t40 = load i32, ptr %l17, !tbaa !23
  %t41 = ashr i32 %t40, 16
  %t43 = icmp eq i32 %t41, 1
  br i1 %t43, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_6c6ddea72e608270_44564397e7d275e4)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb14:
  %t45 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t45, ptr %l2, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s3, { i64, ptr } %t46, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d152, i32 0, i32 1) })
  store i1 %t48, ptr %l21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l21, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 1
  %t53 = extractvalue { i64, ptr } %t50, 0
  %t54 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t52, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  br label %bb8
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d153, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t58, ptr %l25, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l26, !tbaa !24
  %t61 = load i64, ptr %l26, !tbaa !24
  %t62 = mul i64 %t61, 1
  %t63 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l27, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l26, !tbaa !24
  %t71 = mul i64 %t70, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t67, ptr %t69, i64 %t71, i1 false)
  %t72 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t72, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t73 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftarget_2eexecutable(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d154, i32 0, i32 1) })
  store i1 %t12, ptr %l4
  br label %bb2
bb2:
  %t13 = load i1, ptr %l4, !tbaa !21
  %t14 = xor i1 %t13, true
  call void @__olang_scope_close(ptr %s0)
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %t1, { i64, ptr } %t2)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l9
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store i64 %t6, ptr %l8
  br label %bb1
bb1:
  %t10 = load i64, ptr %l8, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t19, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t29 = add i64 %t22, %t26
  store i64 %t29, ptr %l3, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t31, ptr %l16, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  store i64 %t32, ptr %l17, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t33, 0
  store i64 %t36, ptr %l20, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l21, !tbaa !24
  %t39 = load i64, ptr %l17, !tbaa !24
  %t40 = icmp sge i64 %t39, 0
  br i1 %t40, label %bb4, label %bb5
bb4:
  %t42 = load i64, ptr %l17, !tbaa !24
  %t43 = load i64, ptr %l20, !tbaa !24
  %t44 = icmp sle i64 %t42, %t43
  br i1 %t44, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1252e266118faa7_9a8543fc9009ce13)
  unreachable
bb6:
  %t46 = load i64, ptr %l20, !tbaa !24
  %t47 = load i64, ptr %l21, !tbaa !24
  %t48 = icmp sle i64 %t46, %t47
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1252e266118faa7_9a8543fc9009ce13)
  unreachable
bb8:
  %t50 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l17, !tbaa !24
  %t53 = load i64, ptr %l20, !tbaa !24
  %t54 = getelementptr i8, ptr %t51, i64 %t52
  %t55 = sub i64 %t53, %t52
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t60 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t57, i8 34)
  %t61 = extractvalue { i32, i64 } %t60, 1
  %t62 = extractvalue { i32, i64 } %t60, 0
  store i32 %t62, ptr %l28
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb11, label %ok.64
ok.64:
  store i64 %t61, ptr %l27
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1252e266118faa7_9a8543fc9009ce13)
  unreachable
bb10:
  %t65 = load i64, ptr %l27, !tbaa !24
  store i64 %t65, ptr %l15, !tbaa !24
  br label %bb12
bb11:
  %t66 = load i32, ptr %l28, !tbaa !23
  %t67 = lshr i32 %t66, 16
  %t68 = and i32 %t66, 65535
  %t69 = icmp eq i32 %t67, 1
  %t70 = select i1 %t69, i32 1, i32 0
  %t71 = icmp eq i32 %t66, 0
  %t72 = shl i32 %t70, 16
  %t73 = or i32 %t72, %t68
  %t74 = select i1 %t71, i32 0, i32 %t73
  %t76 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t74, 0
  store { i32, { i64, ptr } } %t76, ptr %rv
  br label %ret
bb12:
  %t77 = load i64, ptr %l15, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t78, ptr %l30, !tbaa !27
  %t79 = load i64, ptr %l3, !tbaa !24
  store i64 %t79, ptr %l31, !tbaa !24
  %t80 = load i64, ptr %l3, !tbaa !24
  %t84 = add i64 %t80, %t77
  store i64 %t84, ptr %l34, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l35, !tbaa !24
  %t87 = load i64, ptr %l31, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb13, label %bb14
bb13:
  %t90 = load i64, ptr %l31, !tbaa !24
  %t91 = load i64, ptr %l34, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_50955429569277ca_9a744de1378669b6)
  unreachable
bb15:
  %t94 = load i64, ptr %l34, !tbaa !24
  %t95 = load i64, ptr %l35, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_50955429569277ca_9a744de1378669b6)
  unreachable
bb17:
  %t98 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l31, !tbaa !24
  %t101 = load i64, ptr %l34, !tbaa !24
  %t102 = getelementptr i8, ptr %t99, i64 %t100
  %t103 = sub i64 %t101, %t100
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  %t107 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t105, 1
  store { i32, { i64, ptr } } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_50955429569277ca_9a744de1378669b6)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2emistake(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l5 = alloca %"compiler/diag:Diagnostics"
  %l6 = alloca %"compiler/diag:Diagnostics"
  %l7 = alloca %"compiler/target:Target"
  %l14 = alloca %"compiler/target:Target"
  %l15 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t1 = alloca %"compiler/diag:Diagnostics", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2ftarget_2equiet(ptr %t1, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t1, i64 200, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l6, i64 200, i1 false)
  %t13 = call { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolveOn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %l5)
  %t14 = extractvalue { i32, %"compiler/target:Target" } %t13, 1
  %t15 = extractvalue { i32, %"compiler/target:Target" } %t13, 0
  store i32 %t15, ptr %l15
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb3, label %ok.17
ok.17:
  store %"compiler/target:Target" %t14, ptr %l14
  br label %bb2
bb2:
  %t18 = load %"compiler/target:Target", ptr %l14
  store %"compiler/target:Target" %t18, ptr %l7
  br label %bb8
bb3:
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_cf193683b9c37874_fee9705bb3109728)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  %t25 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s0, ptr %v4, ptr %l5)
  store { i64, ptr } %t25, ptr %l19
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d155, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l22, !tbaa !24
  %t30 = load i64, ptr %l22, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l23, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l22, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t42 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2eprobeDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d156, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d157, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l0, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d158, i32 0, i32 1) })
  store i1 %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t25, i64 %t26)
  %t31 = getelementptr i8, ptr %t30, i64 %t26
  call void @olang_textcopy(ptr %t31, ptr %t27, i64 %t28)
  %t32 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t35 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d160, i32 0, i32 1) })
  %t36 = extractvalue { i32, { i64, ptr } } %t35, 1
  %t37 = extractvalue { i32, { i64, ptr } } %t35, 0
  store i32 %t37, ptr %l15
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb10, label %ok.39
ok.39:
  store { i64, ptr } %t36, ptr %l14
  br label %bb9
bb9:
  %t40 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t40, ptr %l13, !tbaa !27
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d161, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l13, !tbaa !27
  br label %bb12
bb12:
  %t50 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = extractvalue { i64, ptr } %t50, 0
  %t55 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t53, i64 %t54)
  %t59 = getelementptr i8, ptr %t58, i64 %t54
  call void @olang_textcopy(ptr %t59, ptr %t55, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t58, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2eprobeKey(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca %"std/os:FileInfo"
  %l35 = alloca %"std/os:FileInfo"
  %l36 = alloca i32
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"std/prelude/text:StringBuilder"
  %l50 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l65 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d163, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t7, ptr %l14, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l16, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %t25, i64 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !37
  %t29 = call { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %v0, ptr %s0, { i64, ptr } %t27)
  store { i64, ptr } %t29, ptr %l19
  br label %bb4
bb4:
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t30, ptr %l2, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d164, i32 0, i32 1) })
  store i1 %t33, ptr %l21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l21, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d165, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t35, ptr %l23, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l24, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l25, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l24, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t49, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t53 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %s0, { i64, ptr } %t51)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l29
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb10, label %ok.57
ok.57:
  store { i64, ptr } %t54, ptr %l28
  br label %bb9
bb9:
  %t58 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t58, ptr %l26, !tbaa !27
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d166, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = extractvalue { i64, ptr } %t59, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l26, !tbaa !27
  br label %bb12
bb12:
  %t68 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t68, ptr %l3, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t71 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %s0, { i64, ptr } %t69)
  %t72 = extractvalue { i32, %"std/os:FileInfo" } %t71, 1
  %t73 = extractvalue { i32, %"std/os:FileInfo" } %t71, 0
  store i32 %t73, ptr %l36
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb14, label %ok.75
ok.75:
  store %"std/os:FileInfo" %t72, ptr %l35
  br label %bb13
bb13:
  %t76 = load %"std/os:FileInfo", ptr %l35
  store %"std/os:FileInfo" %t76, ptr %l33
  br label %bb18
bb14:
  %t77 = load i32, ptr %l36, !tbaa !23
  %t78 = ashr i32 %t77, 16
  %t80 = icmp eq i32 %t78, 1
  br i1 %t80, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_9bdef6346a5683b7_c34c780a7d2031d3)
  unreachable
bb17:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d167, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t82, ptr %l40, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l41, !tbaa !24
  %t85 = load i64, ptr %l41, !tbaa !24
  %t86 = mul i64 %t85, 1
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l42, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l41, !tbaa !24
  %t95 = mul i64 %t94, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %t93, i64 %t95, i1 false)
  %t96 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t96, ptr %l40, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t97 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t97, ptr %rv
  br label %ret
bb18:
  %t98 = load %"std/os:FileInfo", ptr %l33
  store %"std/os:FileInfo" %t98, ptr %l4
  %t99 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t99, ptr %l43
  br label %bb19
bb19:
  %t100 = load %"std/prelude/text:StringBuilder", ptr %l43
  store %"std/prelude/text:StringBuilder" %t100, ptr %l5
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t102 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 2
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t109 = extractvalue { i64, ptr } %t101, 1
  %t110 = extractvalue { i64, ptr } %t101, 0
  %t111 = add i64 %t107, %t110
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t114 = add i64 %t111, %t113
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t103)
  %t117 = add i64 %t114, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t122 = call i64 @__olang_fmt_i64(ptr null, i64 %t105)
  %t123 = add i64 %t120, %t122
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @olang_textcopy(ptr %t127, ptr %t106, i64 %t107)
  %t128 = getelementptr i8, ptr %t127, i64 %t107
  call void @olang_textcopy(ptr %t128, ptr %t109, i64 %t110)
  %t129 = getelementptr i8, ptr %t128, i64 %t110
  call void @olang_textcopy(ptr %t129, ptr %t112, i64 %t113)
  %t130 = getelementptr i8, ptr %t129, i64 %t113
  %t131 = call i64 @__olang_fmt_i64(ptr %t130, i64 %t103)
  %t132 = getelementptr i8, ptr %t130, i64 %t116
  call void @olang_textcopy(ptr %t132, ptr %t118, i64 %t119)
  %t133 = getelementptr i8, ptr %t132, i64 %t119
  %t134 = call i64 @__olang_fmt_i64(ptr %t133, i64 %t105)
  %t135 = getelementptr i8, ptr %t133, i64 %t122
  call void @olang_textcopy(ptr %t135, ptr %t124, i64 %t125)
  %t136 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t127, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = extractvalue { i64, ptr } %t137, 1
  %t141 = mul i64 %t139, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t141)
  call void @llvm.memcpy.p0.p0.i64(ptr %t142, ptr %t140, i64 %t141, i1 false)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t144)
  br label %bb20
bb20:
  %t147 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t147, ptr %l50, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t148, 0
  store i64 %t151, ptr %l53, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  store i64 %t153, ptr %l54, !tbaa !24
  %t154 = icmp sge i64 1, 0
  br i1 %t154, label %bb21, label %bb22
bb21:
  %t156 = load i64, ptr %l53, !tbaa !24
  %t157 = icmp sle i64 1, %t156
  br i1 %t157, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_1bde5d5b212fb8f5_516db983d543a7a1)
  unreachable
bb23:
  %t159 = load i64, ptr %l53, !tbaa !24
  %t160 = load i64, ptr %l54, !tbaa !24
  %t161 = icmp sle i64 %t159, %t160
  br i1 %t161, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_1bde5d5b212fb8f5_516db983d543a7a1)
  unreachable
bb25:
  %t163 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l53, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %t164, i64 1
  %t167 = sub i64 %t165, 1
  %t168 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t166, 1
  store { i64, ptr } %t169, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  store i64 %t173, ptr %l8, !tbaa !24
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_1bde5d5b212fb8f5_516db983d543a7a1)
  unreachable
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t175 = load i64, ptr %l7, !tbaa !24
  %t176 = load i64, ptr %l8, !tbaa !24
  %t179 = icmp slt i64 %t175, %t176
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t183 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t183, ptr %l65, !tbaa !27
  %t184 = load i64, ptr %l7, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %t187, i64 %t184
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !37
  %t193 = extractvalue { i64, ptr } %t189, 1
  %t194 = extractvalue { i64, ptr } %t189, 0
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t197 = add i64 %t194, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t193, i64 %t194)
  %t199 = getelementptr i8, ptr %t198, i64 %t194
  call void @olang_textcopy(ptr %t199, ptr %t195, i64 %t196)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } %t201, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l5, { i64, ptr } %t208)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t211 = load i64, ptr %l7, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l7, !tbaa !24
  br label %bb27
bb33:
  store ptr %l5, ptr %l74, !tbaa !29
  %t215 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t215, 0
  store i64 %t217, ptr %l76, !tbaa !24
  %t218 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t218, ptr %l77, !tbaa !27
  %t219 = call { i64, ptr } @compiler_2ftarget_2ecpuModel(ptr %s0)
  store { i64, ptr } %t219, ptr %l78
  br label %bb34
bb34:
  %t220 = call { i64, ptr } @compiler_2ftarget_2ecpuFlags(ptr %s0)
  store { i64, ptr } %t220, ptr %l79
  br label %bb35
bb35:
  %t221 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t223 = load i64, ptr %l76, !tbaa !24
  %t224 = call i64 @__olang_fmt_i64(ptr null, i64 %t223)
  %t225 = add i64 %t222, %t224
  %t226 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t228 = add i64 %t225, %t227
  %t229 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = add i64 %t228, %t231
  %t233 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t235 = add i64 %t232, %t234
  %t236 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = add i64 %t235, %t238
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t241 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t242 = add i64 %t239, %t241
  %t243 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t243, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = add i64 %t242, %t245
  %t247 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t249 = add i64 %t246, %t248
  %t250 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t249)
  call void @olang_textcopy(ptr %t250, ptr %t221, i64 %t222)
  %t251 = getelementptr i8, ptr %t250, i64 %t222
  %t252 = call i64 @__olang_fmt_i64(ptr %t251, i64 %t223)
  %t253 = getelementptr i8, ptr %t251, i64 %t224
  call void @olang_textcopy(ptr %t253, ptr %t226, i64 %t227)
  %t254 = getelementptr i8, ptr %t253, i64 %t227
  call void @olang_textcopy(ptr %t254, ptr %t230, i64 %t231)
  %t255 = getelementptr i8, ptr %t254, i64 %t231
  call void @olang_textcopy(ptr %t255, ptr %t233, i64 %t234)
  %t256 = getelementptr i8, ptr %t255, i64 %t234
  call void @olang_textcopy(ptr %t256, ptr %t237, i64 %t238)
  %t257 = getelementptr i8, ptr %t256, i64 %t238
  call void @olang_textcopy(ptr %t257, ptr %t240, i64 %t241)
  %t258 = getelementptr i8, ptr %t257, i64 %t241
  call void @olang_textcopy(ptr %t258, ptr %t244, i64 %t245)
  %t259 = getelementptr i8, ptr %t258, i64 %t245
  call void @olang_textcopy(ptr %t259, ptr %t247, i64 %t248)
  %t260 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t250, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t269 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t269, { i64, ptr } %t268)
  br label %bb36
bb36:
  %t272 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l5)
  store { i64, ptr } %t272, ptr %l83
  br label %bb37
bb37:
  %t273 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t273, ptr %l84, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  store i64 %t275, ptr %l85, !tbaa !24
  %t276 = load i64, ptr %l85, !tbaa !24
  %t277 = mul i64 %t276, 1
  %t278 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t277)
  %t279 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  store { i64, ptr } %t280, ptr %l86, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = load i64, ptr %l85, !tbaa !24
  %t286 = mul i64 %t285, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t282, ptr %t284, i64 %t286, i1 false)
  %t287 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t287, ptr %l84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t288 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t288, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2eprobeOutcome(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/target:Target"
  %l2 = alloca %"compiler/target:Target"
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %s0)
  store %"compiler/target:Target" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/target:Target", ptr %l2
  store %"compiler/target:Target" %t2, ptr %l1
  %t3 = getelementptr %"compiler/target:Target", ptr %l1, i32 0, i32 2
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d175, i32 0, i32 1) }, ptr %t3, !tbaa !27
  %t7 = call i32 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eFromProbe(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %a0)
  store i32 %t7, ptr %l5
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  br label %bb2
bb2:
  br label %bb10
bb3:
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = icmp eq i32 %t10, 65536
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t13 = load i32, ptr %l5, !tbaa !23
  %t14 = icmp eq i32 %t13, 65537
  br i1 %t14, label %bb7, label %bb8
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d176, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l10, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l11, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l10, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t30, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_e8b72cfc84d5e9e6_628031fabfe49ea)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d177, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t32, ptr %l13, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l14, !tbaa !24
  %t35 = load i64, ptr %l14, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l15, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l14, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t46, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb10:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d178, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t48, ptr %l17, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l18, !tbaa !24
  %t51 = load i64, ptr %l18, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l19, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l18, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t62, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t63 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t63, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftarget_2equiet(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"compiler/diag:Diagnostics"
  %t1 = alloca %"compiler/diag:Diagnostics", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t1, ptr %v0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %t1, i64 200, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l0, i64 200, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftarget_2erefuse(ptr %v0, ptr %v1, ptr %a0, %"compiler/msgs:Msg" %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i32
  %t2 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [3 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [3 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [3 x i64] }, ptr %t2
  %t9 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %t4, %"compiler/msgs:Msg" %a1)
  store i64 %t9, ptr %l5
  br label %bb1
bb1:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %lp7 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l16 = alloca i32
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l60 = alloca i32
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d179, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t4)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = getelementptr i8, ptr %t14, i64 %t10
  call void @olang_textcopy(ptr %t15, ptr %t11, i64 %t12)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t14, 1
  %t19 = load i32, ptr @G_2e_3cunistd_2eh_3e_2eX__OK, !tbaa !23
  %t21 = extractvalue { i64, ptr } %t17, 1
  %t22 = extractvalue { i64, ptr } %t17, 0
  %t24 = call i32 @access(ptr %t21, i32 %t19)
  store i32 %t24, ptr %l16
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t25 = load i32, ptr %l16, !tbaa !23
  %t26 = icmp eq i32 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = extractvalue { i64, ptr } %t28, 0
  %t32 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t30, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l18, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d181, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t36, ptr %l18, !tbaa !27
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l23, !tbaa !24
  %t40 = load i64, ptr %l23, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l23, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t51, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb8:
  %t53 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d182, i32 0, i32 1) })
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l27
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb10, label %ok.57
ok.57:
  store { i64, ptr } %t54, ptr %l26
  br label %bb9
bb9:
  %t58 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t58, ptr %l25, !tbaa !27
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d183, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = extractvalue { i64, ptr } %t59, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l25, !tbaa !27
  br label %bb12
bb12:
  %t68 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t68, ptr %l1, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d184, i32 0, i32 1) })
  store i1 %t71, ptr %l32
  br label %bb13
bb13:
  %t72 = load i1, ptr %l32, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t75, ptr %l34, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d185, i32 0, i32 1) }, ptr %l34, !tbaa !27
  br label %bb16
bb16:
  %t77 = load { i64, ptr }, ptr %l34, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s4, { i64, ptr } %t77, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d186, i32 0, i32 1) })
  store { i64, ptr } %t80, ptr %l37
  br label %bb17
bb17:
  %t81 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t81, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l5, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i64, ptr %l5, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb20:
  br label %bb21
bb21:
  %t94 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t94, ptr %l44, !tbaa !27
  %t95 = load i64, ptr %l4, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %t98, i64 %t95
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !37
  store { i64, ptr } %t100, ptr %l6, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t104 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s5, { i64, ptr } %t102, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d187, i32 0, i32 1) })
  store i1 %t104, ptr %l48
  br label %bb22
bb22:
  %t105 = load i1, ptr %l48, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb23, label %bb24
bb23:
  %t108 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t108, 1
  %t112 = extractvalue { i64, ptr } %t108, 0
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t115 = add i64 %t112, %t114
  %t117 = extractvalue { i64, ptr } %t109, 1
  %t118 = extractvalue { i64, ptr } %t109, 0
  %t119 = add i64 %t115, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t111, i64 %t112)
  %t121 = getelementptr i8, ptr %t120, i64 %t112
  call void @olang_textcopy(ptr %t121, ptr %t113, i64 %t114)
  %t122 = getelementptr i8, ptr %t121, i64 %t114
  call void @olang_textcopy(ptr %t122, ptr %t117, i64 %t118)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t120, 1
  store { i64, ptr } %t124, ptr %l50, !tbaa !27
  br label %bb25
bb24:
  %t126 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 1
  %t129 = extractvalue { i64, ptr } %t126, 0
  %t130 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t128, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l50, !tbaa !27
  br label %bb25
bb25:
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t134, ptr %lp7
  %t135 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t136 = load ptr, ptr %lp7
  store { i64, ptr } %t135, ptr %t136, !tbaa !27
  %t137 = load ptr, ptr %lp7
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 1
  %t141 = extractvalue { i64, ptr } %t138, 0
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t145 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t140, i64 %t141)
  %t146 = getelementptr i8, ptr %t145, i64 %t141
  call void @olang_textcopy(ptr %t146, ptr %t142, i64 %t143)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t145, 1
  %t150 = load i32, ptr @G_2e_3cunistd_2eh_3e_2eX__OK, !tbaa !23
  %t152 = extractvalue { i64, ptr } %t148, 1
  %t153 = extractvalue { i64, ptr } %t148, 0
  %t155 = call i32 @access(ptr %t152, i32 %t150)
  store i32 %t155, ptr %l60
  br label %bb26
bb26:
  %t156 = load i32, ptr %l60, !tbaa !23
  %t157 = icmp eq i32 %t156, 0
  br i1 %t157, label %bb27, label %bb28
bb27:
  %t159 = load ptr, ptr %lp7
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t160, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  %t162 = load i64, ptr %l4, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l4, !tbaa !24
  br label %bb18
bb31:
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d190, i32 0, i32 1) }, ptr %l65, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t166, ptr %l66, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  store i64 %t168, ptr %l67, !tbaa !24
  %t169 = load i64, ptr %l67, !tbaa !24
  %t170 = mul i64 %t169, 1
  %t171 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t170)
  %t172 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  store { i64, ptr } %t173, ptr %l68, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = load i64, ptr %l67, !tbaa !24
  %t179 = mul i64 %t178, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t175, ptr %t177, i64 %t179, i1 false)
  %t180 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t180, ptr %l66, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t181 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t181, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %rv = alloca %"compiler/target:Target"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d191, i32 0, i32 1) }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d192, i32 0, i32 1) }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d193, i32 0, i32 1) }, ptr %l2, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d194, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d195, i32 0, i32 1) }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d196, i32 0, i32 1) }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d197, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = insertvalue %"compiler/target:Target" undef, { i64, ptr } %t1, 0
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = insertvalue %"compiler/target:Target" %t2, { i64, ptr } %t3, 1
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = insertvalue %"compiler/target:Target" %t4, { i64, ptr } %t5, 2
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = insertvalue %"compiler/target:Target" %t6, { i64, ptr } %t7, 3
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t10 = insertvalue %"compiler/target:Target" %t8, { i64, ptr } %t9, 4
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t12 = insertvalue %"compiler/target:Target" %t10, { i64, ptr } %t11, 5
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = insertvalue %"compiler/target:Target" %t12, { i64, ptr } %t13, 6
  %t16 = insertvalue %"compiler/target:Target" %t14, i64 0, 7
  %t18 = insertvalue %"compiler/target:Target" %t16, i1 false, 8
  %t20 = insertvalue %"compiler/target:Target" %t18, i1 false, 9
  store %"compiler/target:Target" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/target:Target", ptr %rv
  ret %"compiler/target:Target" %rr
}

define dso_local void @olang_2einit_2ecompiler_2ftarget() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ftarget_2eArchs_2einit()
  br label %bb1
bb1:
  call void @compiler_2ftarget_2eArchCpuFlags_2einit()
  br label %bb2
bb2:
  call void @compiler_2ftarget_2eArchDefaultCpus_2einit()
  br label %bb3
bb3:
  call void @compiler_2ftarget_2eIeeeUnsafe_2einit()
  br label %bb4
bb4:
  call void @compiler_2ftarget_2eClangs_2einit()
  br label %bb5
bb5:
  call void @compiler_2ftarget_2eLevelFlags_2einit()
  br label %bb6
bb6:
  call void @compiler_2ftarget_2eSkylakeProbe_2einit()
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-march=" }>, align 8
@.d1 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-mcpu=" }>, align 8
@.d2 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86-64" }>, align 8
@.d3 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"generic" }>, align 8
@.d4 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aarch64" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed(ptr)
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_ert_req_clear()
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i32 @getpid()
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d16 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"clang-20" }>, align 8
@.d17 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"clang-19" }>, align 8
@.d18 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"clang-18" }>, align 8
@.d19 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"clang" }>, align 8
@.d20 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_CLANG" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d24 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d27 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"/../llvm/bin/clang" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @access(ptr, i32)
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eZero_2e_3csys_2futsname_2eh_3e_3autsname(ptr %out) #0 {
entry:
  %l0 = alloca %"<sys/utsname.h>:utsname"
  %t1 = alloca %"<sys/utsname.h>:utsname", align 1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr @__olang_prog_scope
  call void @_3csys_2futsname_2eh_3e_3autsname_2ector(ptr %t1, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %t1, i64 390, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l0, i64 390, i1 false)
  br label %ret
ret:
  ret void
}

declare i32 @uname(ptr)
@.d31 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"unknown" }>, align 8
@.d32 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"unknown" }>, align 8
@.d33 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"avx512bf16" }>, align 8
@.d34 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"avxneconvert" }>, align 8
@.d35 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"cx16 lahf_lm popcnt sse4_1 sse4_2 ssse3" }>, align 8
@.d36 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"avx avx2 bmi1 bmi2 f16c fma abm movbe xsave" }>, align 8
@.d37 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"avx512f avx512bw avx512cd avx512dq avx512vl" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-linux" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-linux-gnu" }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d44 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-apple" }>, align 8
@.d45 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-windows" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"native" }>, align 8
@.d52 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"interpret" }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d56 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-S" }>, align 8
@.d57 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-emit-llvm" }>, align 8
@.d58 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d60 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d63 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"void olang_target_probe(void) { }\0A" }>, align 8
@.d64 = private constant <{ i64, [102 x i8] }> <{ i64 0, [102 x i8] c"target datalayout = \22e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128\22\0A" }>, align 8
@.d65 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"target triple = \22x86_64-pc-linux-gnu\22\0A" }>, align 8
@.d66 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"attributes #0 = { noinline nounwind \22target-cpu\22=\22skylake-avx512\22 " }>, align 8
@.d67 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"\22target-features\22=\22+avx,+avx512bf16,+avx512f,+fma,-avxneconvert,+sse2\22 \22tune-cpu\22=\22generic\22 }\0A" }>, align 8
@.d68 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d71 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"OLANG_SYSROOT" }>, align 8
@.d72 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d76 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d77 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\22=\22" }>, align 8
@.d78 = private constant <{ i64, [88 x i8] }> <{ i64 0, [88 x i8] c"define float @f(float %x) {\0A  %b = fptrunc float %x to bfloat\0A  %c = fadd bfloat %b, %b\0A" }>, align 8
@.d79 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"  %r = fpext bfloat %c to float\0A  ret float %r\0A}\0A" }>, align 8
@.d80 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d81 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"-fno-crash-diagnostics" }>, align 8
@.d82 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-c" }>, align 8
@.d83 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d84 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ir" }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d86 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d87 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/dev/null" }>, align 8
@.d88 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"target triple = \22" }>, align 8
@.d89 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"target datalayout = \22" }>, align 8
@.d90 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"attributes #0 = {" }>, align 8
@.d91 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-p:32" }>, align 8
@.d92 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-p:16" }>, align 8
@.d93 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"target-cpu" }>, align 8
@.d94 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"target-features" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aarch64" }>, align 8
@.d97 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"neon" }>, align 8
@.d98 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"avx512f" }>, align 8
@.d99 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"avx" }>, align 8
@.d100 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fma" }>, align 8
@.d101 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fma4" }>, align 8
@.d102 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"tune-cpu" }>, align 8
@.d103 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d104 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d105 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" \22tune-cpu\22=\22" }>, align 8
@.d106 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d107 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d108 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d109 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"vscale_range(" }>, align 8
@.d110 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d111 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22target-cpu\22=\22" }>, align 8
@.d112 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"\22 \22target-features\22=\22" }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d114 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" \22prefer-vector-width\22=\22" }>, align 8
@.d115 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_EMULATOR" }>, align 8
@.d116 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d117 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d119 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d120 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"qemu-" }>, align 8
@.d121 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"qemu-" }>, align 8
@.d122 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-static" }>, align 8
@.d123 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d124 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d125 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/usr/" }>, align 8
@.d126 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-linux-gnu" }>, align 8
@.d127 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/usr/" }>, align 8
@.d128 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-linux-gnu" }>, align 8
@.d129 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d130 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-L" }>, align 8
@.d131 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"-unknown-linux-gnu" }>, align 8
@.d132 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aarch64" }>, align 8
@.d133 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"native" }>, align 8
@.d134 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"generic" }>, align 8
@.d135 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"generic" }>, align 8
@.d136 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86-64" }>, align 8
@.d137 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"x86-64-v2" }>, align 8
@.d138 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"x86-64-v3" }>, align 8
@.d139 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"x86-64-v4" }>, align 8
@.d140 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"native" }>, align 8
@.d141 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86-64" }>, align 8
@.d142 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"x86-64-v" }>, align 8
@.d143 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"/proc/cpuinfo" }>, align 8
@.d144 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d145 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"flags" }>, align 8
@.d146 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d147 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d148 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d149 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d150 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"/proc/cpuinfo" }>, align 8
@.d151 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d152 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"model name" }>, align 8
@.d153 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d154 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d155 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d156 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_CACHE" }>, align 8
@.d157 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d158 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d159 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/probe" }>, align 8
@.d160 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"HOME" }>, align 8
@.d161 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d162 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"/.cache/olang/probe" }>, align 8
@.d163 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d164 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d165 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d166 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d167 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d168 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olang probe 1\0A" }>, align 8
@.d169 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d170 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d171 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d172 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"input " }>, align 8
@.d173 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d174 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"\0A=====\0A" }>, align 8
@.d175 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d176 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"unknown" }>, align 8
@.d177 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unsupported" }>, align 8
@.d178 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ok" }>, align 8
@.d179 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d180 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d181 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d182 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"PATH" }>, align 8
@.d183 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d184 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d185 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"/usr/local/bin:/usr/bin:/bin" }>, align 8
@.d186 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d187 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d188 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d189 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d190 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d191 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"native" }>, align 8
@.d192 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d193 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d194 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d195 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d196 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d197 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_def72623566706b3_6d1f4e2e8af6f867 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_47a0ad7bede37e81_52b343d343663485 = external constant [0 x i8]
declare %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_5d60638bbee689af_7a012b3f353868cb = external constant [0 x i8]
@G_2e_3cunistd_2eh_3e_2eX__OK = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7d2dbc1a64f072ad_c547ba7f55386c9 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_ee9182f5b79fed14_a04856bc4b77fa08 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_177ba209f42fea81_ef02637a921a8065 = external constant [0 x i8]
@olang_loc_68a839c97e351482_b46245551e337746 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNativeForeign(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_fea0ada6e42eab98_8ecdc26bfdef2ecc = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoBackend(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_4b3e93141bb855fb_750a01d3487f499f = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a61f3cd56da1d37e_58843bed9934bc22 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_df777aa861912ce0_9be626e5398fb1ec = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2b3d593c994025a_f25bcfc8e3895e8e = external constant [0 x i8]
@olang_loc_41dcdde6fea423b7_7dcc0ffa4d83aa8b = external constant [0 x i8]
@olang_loc_e010b40d861556cc_7cbd713015487310 = external constant [0 x i8]
@olang_loc_8cdf81df4f8deaf9_3f7b7447e7e110ed = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
@olang_loc_85332b5eb98b88c2_ab57175d397d1606 = external constant [0 x i8]
@olang_loc_76ff016df127c4d3_50e3c4f0063661b7 = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_894ce1aaf95d40d2_41321e55c77fd296 = external constant [0 x i8]
@olang_loc_5e2dfc7662e61c22_c1572e0f91c88016 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
@olang_loc_6a809c42d90c2601_8916f15013bc8fd5 = external constant [0 x i8]
@olang_loc_6c6ddea72e608270_44564397e7d275e4 = external constant [0 x i8]
@olang_loc_1252e266118faa7_9a8543fc9009ce13 = external constant [0 x i8]
@olang_loc_50955429569277ca_9a744de1378669b6 = external constant [0 x i8]
@olang_loc_cf193683b9c37874_fee9705bb3109728 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_9bdef6346a5683b7_c34c780a7d2031d3 = external constant [0 x i8]
@olang_loc_1bde5d5b212fb8f5_516db983d543a7a1 = external constant [0 x i8]
@olang_loc_e8b72cfc84d5e9e6_628031fabfe49ea = external constant [0 x i8]
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare void @_3csys_2futsname_2eh_3e_3autsname_2ector(ptr %out, ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
