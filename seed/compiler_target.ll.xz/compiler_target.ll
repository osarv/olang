; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2ftarget_2eArchCpuFlags = global { i64, ptr } zeroinitializer
@G_2ecompiler_2ftarget_2eArchDefaultCpus = global { i64, ptr } zeroinitializer
@G_2ecompiler_2ftarget_2eArchs = global { i64, ptr } zeroinitializer
@G_2ecompiler_2ftarget_2eIeeeUnsafe = global { i64, ptr } zeroinitializer
@G_2ecompiler_2ftarget_2eLevelFlags = global { i64, ptr } zeroinitializer
@G_2ecompiler_2ftarget_2eSkylakeProbe = global { i64, ptr } zeroinitializer
define dso_local void @compiler_2ftarget_2eArchCpuFlags_2einit() #0 {
entry:
  %l0 = alloca [2 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 7, ptr @.d0 }, 0
  %t2 = insertvalue [2 x { i64, ptr }] %t1, { i64, ptr } { i64 6, ptr @.d1 }, 1
  store [2 x { i64, ptr }] %t2, ptr %l0
  %t3 = load [2 x { i64, ptr }], ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call ptr @__olang_scope_alloc(ptr %t4, i64 32)
  store [2 x { i64, ptr }] %t3, ptr %t5
  %t6 = insertvalue { i64, ptr } undef, i64 2, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l1
  %t8 = load { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchCpuFlags
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l2
  %t10 = load { i64, ptr }, ptr %l1
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l3
  %t12 = load i64, ptr %l2
  %t13 = load i64, ptr %l3
  %t14 = icmp eq i64 %t12, %t13
  store i1 %t14, ptr %l4
  %t15 = load i1, ptr %l4
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t16 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchCpuFlags, i32 0, i32 1
  %t17 = load ptr, ptr %t16
  %t18 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  %t20 = load i64, ptr %l3
  %t21 = mul i64 %t20, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  br label %bb3
bb2:
  %t22 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t22, ptr @G_2ecompiler_2ftarget_2eArchCpuFlags
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftarget_2eArchDefaultCpus_2einit() #0 {
entry:
  %l0 = alloca [2 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 6, ptr @.d2 }, 0
  %t2 = insertvalue [2 x { i64, ptr }] %t1, { i64, ptr } { i64 7, ptr @.d3 }, 1
  store [2 x { i64, ptr }] %t2, ptr %l0
  %t3 = load [2 x { i64, ptr }], ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call ptr @__olang_scope_alloc(ptr %t4, i64 32)
  store [2 x { i64, ptr }] %t3, ptr %t5
  %t6 = insertvalue { i64, ptr } undef, i64 2, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l1
  %t8 = load { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchDefaultCpus
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l2
  %t10 = load { i64, ptr }, ptr %l1
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l3
  %t12 = load i64, ptr %l2
  %t13 = load i64, ptr %l3
  %t14 = icmp eq i64 %t12, %t13
  store i1 %t14, ptr %l4
  %t15 = load i1, ptr %l4
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t16 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchDefaultCpus, i32 0, i32 1
  %t17 = load ptr, ptr %t16
  %t18 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  %t20 = load i64, ptr %l3
  %t21 = mul i64 %t20, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  br label %bb3
bb2:
  %t22 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t22, ptr @G_2ecompiler_2ftarget_2eArchDefaultCpus
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftarget_2eArchs_2einit() #0 {
entry:
  %l0 = alloca [2 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 6, ptr @.d4 }, 0
  %t2 = insertvalue [2 x { i64, ptr }] %t1, { i64, ptr } { i64 7, ptr @.d5 }, 1
  store [2 x { i64, ptr }] %t2, ptr %l0
  %t3 = load [2 x { i64, ptr }], ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call ptr @__olang_scope_alloc(ptr %t4, i64 32)
  store [2 x { i64, ptr }] %t3, ptr %t5
  %t6 = insertvalue { i64, ptr } undef, i64 2, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l1
  %t8 = load { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchs
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l2
  %t10 = load { i64, ptr }, ptr %l1
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l3
  %t12 = load i64, ptr %l2
  %t13 = load i64, ptr %l3
  %t14 = icmp eq i64 %t12, %t13
  store i1 %t14, ptr %l4
  %t15 = load i1, ptr %l4
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t16 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchs, i32 0, i32 1
  %t17 = load ptr, ptr %t16
  %t18 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  %t20 = load i64, ptr %l3
  %t21 = mul i64 %t20, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  br label %bb3
bb2:
  %t22 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t22, ptr @G_2ecompiler_2ftarget_2eArchs
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca [2 x { i64, ptr }]
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr @.d6 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l13
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t6, ptr %l11
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d7 }, ptr %l14
  %t7 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t7, ptr %l15
  %t8 = load { i64, ptr }, ptr %l15
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l16
  %t15 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t15, ptr %l11
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t16, ptr %l0
  %t17 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t17, ptr %l17
  %t18 = load { i64, ptr }, ptr %l17
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 0, ptr @.d8 })
  store i1 %t19, ptr %l18
  br label %bb5
bb5:
  %t20 = load i1, ptr %l18
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l19
  %t22 = load i1, ptr %l19
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t23, ptr %l21
  %t24 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t24, ptr %l20
  br label %bb8
bb7:
  store { i64, ptr } { i64 28, ptr @.d9 }, ptr %l20
  br label %bb8
bb8:
  %t25 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t25, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 8, ptr @.d10 }, 0
  %t27 = insertvalue [2 x { i64, ptr }] %t26, { i64, ptr } { i64 5, ptr @.d11 }, 1
  store [2 x { i64, ptr }] %t27, ptr %l22
  %t28 = load [2 x { i64, ptr }], ptr %l22
  %t29 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t28, ptr %t29
  store ptr %t29, ptr %l23
  %t30 = load ptr, ptr %l23
  store ptr %t30, ptr %l2
  store i64 0, ptr %l3
  %t31 = load ptr, ptr %l2
  store ptr %t31, ptr %l24
  %t32 = load ptr, ptr %l24
  store i64 2, ptr %l25
  %t33 = load i64, ptr %l25
  store i64 %t33, ptr %l4
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i64, ptr %l3
  store i64 %t34, ptr %l26
  %t35 = load i64, ptr %l4
  store i64 %t35, ptr %l27
  %t36 = load i64, ptr %l26
  %t37 = load i64, ptr %l27
  %t38 = icmp slt i64 %t36, %t37
  store i1 %t38, ptr %l28
  %t39 = load i1, ptr %l28
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l29
  %t41 = load i1, ptr %l29
  br i1 %t41, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l2
  store ptr %t42, ptr %l30
  %t43 = load i64, ptr %l3
  store i64 %t43, ptr %l31
  %t44 = load ptr, ptr %l30
  %t45 = load i64, ptr %l31
  %t46 = getelementptr [2 x { i64, ptr }], ptr %t44, i64 0, i64 %t45
  %t47 = load { i64, ptr }, ptr %t46
  store { i64, ptr } %t47, ptr %l32
  %t48 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t48, ptr %l5
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t49, ptr %l33
  %t50 = load { i64, ptr }, ptr %l33
  %t51 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s3, { i64, ptr } %t50, { i64, ptr } { i64 1, ptr @.d12 })
  store { i64, ptr } %t51, ptr %l34
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l34
  store { i64, ptr } %t52, ptr %l6
  store i64 0, ptr %l7
  %t53 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t53, ptr %l35
  %t54 = load { i64, ptr }, ptr %l35
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l36
  %t56 = load i64, ptr %l36
  store i64 %t56, ptr %l8
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t57 = load i64, ptr %l7
  store i64 %t57, ptr %l37
  %t58 = load i64, ptr %l8
  store i64 %t58, ptr %l38
  %t59 = load i64, ptr %l37
  %t60 = load i64, ptr %l38
  %t61 = icmp slt i64 %t59, %t60
  store i1 %t61, ptr %l39
  %t62 = load i1, ptr %l39
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l40
  %t64 = load i1, ptr %l40
  br i1 %t64, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb16:
  br label %bb17
bb17:
  %t65 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t65, ptr %l41
  %t66 = load i64, ptr %l7
  store i64 %t66, ptr %l42
  %t67 = load i64, ptr %l42
  %t68 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t69 = load ptr, ptr %t68
  %t70 = getelementptr { i64, ptr }, ptr %t69, i64 %t67
  %t71 = load { i64, ptr }, ptr %t70
  store { i64, ptr } %t71, ptr %l43
  %t72 = load { i64, ptr }, ptr %l43
  store { i64, ptr } %t72, ptr %l9
  %t73 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t73, ptr %l44
  %t74 = load { i64, ptr }, ptr %l44
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t74, { i64, ptr } { i64 0, ptr @.d13 })
  store i1 %t75, ptr %l45
  br label %bb18
bb18:
  %t76 = load i1, ptr %l45
  %t77 = xor i1 %t76, true
  store i1 %t77, ptr %l46
  %t78 = load i1, ptr %l46
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t79 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t79, ptr %l48
  %t80 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t80, ptr %l49
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t81 = load { i64, ptr }, ptr %l48
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  call void @__olang_sb_put(ptr %s5, ptr %t82, i64 %t83)
  %t84 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 1
  %t85 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t84, i64 %t85)
  %t86 = load { i64, ptr }, ptr %l49
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  call void @__olang_sb_put(ptr %s5, ptr %t87, i64 %t88)
  %t89 = load ptr, ptr %s5
  %t90 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t91 = load i64, ptr %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t89, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l50
  call void @__olang_sb_done(ptr %s5)
  %t95 = load { i64, ptr }, ptr %l50
  store { i64, ptr } %t95, ptr %l47
  br label %bb21
bb20:
  %t96 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t96, ptr %l51
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t97 = load { i64, ptr }, ptr %l51
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  call void @__olang_sb_put(ptr %s6, ptr %t98, i64 %t99)
  %t100 = load ptr, ptr %s6
  %t101 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t102 = load i64, ptr %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t100, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l52
  call void @__olang_sb_done(ptr %s6)
  %t106 = load { i64, ptr }, ptr %l52
  store { i64, ptr } %t106, ptr %l47
  br label %bb21
bb21:
  %t107 = load { i64, ptr }, ptr %l47
  store { i64, ptr } %t107, ptr %l10
  %t108 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t108, ptr %l53
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t109 = load { i64, ptr }, ptr %l53
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  call void @__olang_sb_put(ptr %s7, ptr %t110, i64 %t111)
  %t112 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t112, i64 %t113)
  %t114 = load ptr, ptr %s7
  %t115 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t116 = load i64, ptr %t115
  %t117 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t114, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l54
  call void @__olang_sb_done(ptr %s7)
  %t120 = load { i64, ptr }, ptr %l54
  store { i64, ptr } %t120, ptr %l55
  %t121 = load { i64, ptr }, ptr %l55
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = call i32 @access(ptr %t122, i32 1)
  store i32 %t124, ptr %l56
  br label %bb22
bb22:
  %t125 = load i32, ptr %l56
  %t126 = icmp eq i32 %t125, 0
  store i1 %t126, ptr %l57
  %t127 = load i1, ptr %l57
  br i1 %t127, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s8
  %t128 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t128, ptr %l58
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t129 = load { i64, ptr }, ptr %l58
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  call void @__olang_sb_put(ptr %s9, ptr %t130, i64 %t131)
  %t132 = load ptr, ptr %s9
  %t133 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t134 = load i64, ptr %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t132, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l59
  call void @__olang_sb_done(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t138 = load { i64, ptr }, ptr %l59
  store { i64, ptr } %t138, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s10
  %t139 = load i64, ptr %l7
  store i64 %t139, ptr %l60
  %t140 = load i64, ptr %l60
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l61
  %t142 = load i64, ptr %l61
  store i64 %t142, ptr %l7
  call void @__olang_scope_close(ptr %s10)
  br label %bb14
bb27:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s11
  %t143 = load i64, ptr %l3
  store i64 %t143, ptr %l62
  %t144 = load i64, ptr %l62
  %t145 = add i64 %t144, 1
  store i64 %t145, ptr %l63
  %t146 = load i64, ptr %l63
  store i64 %t146, ptr %l3
  call void @__olang_scope_close(ptr %s11)
  br label %bb9
bb29:
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } { i64 0, ptr @.d16 }, ptr %l64
  %t147 = load { i64, ptr }, ptr %l64
  store { i64, ptr } %t147, ptr %l65
  %t148 = load { i64, ptr }, ptr %l65
  %t149 = extractvalue { i64, ptr } %t148, 0
  store i64 %t149, ptr %l66
  %t150 = load i64, ptr %l66
  %t151 = mul i64 %t150, 1
  %t152 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t151)
  %t153 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  store { i64, ptr } %t154, ptr %l67
  %t155 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t156 = load ptr, ptr %t155
  %t157 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t158 = load ptr, ptr %t157
  %t159 = load i64, ptr %l66
  %t160 = mul i64 %t159, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t156, ptr %t158, i64 %t160, i1 false)
  %t161 = load { i64, ptr }, ptr %l67
  store { i64, ptr } %t161, ptr %l65
  call void @__olang_scope_close(ptr %s0)
  %t162 = load { i64, ptr }, ptr %l65
  store { i64, ptr } %t162, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftarget_2eHasFeature(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i8
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l6
  %t2 = load { i64, ptr }, ptr %l6
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s1, { i64, ptr } %t2, { i64, ptr } { i64 1, ptr @.d17 })
  store { i64, ptr } %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t4, ptr %l2
  store i64 0, ptr %l3
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l8
  %t6 = load { i64, ptr }, ptr %l8
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l9
  %t8 = load i64, ptr %l9
  store i64 %t8, ptr %l4
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3
  store i64 %t9, ptr %l10
  %t10 = load i64, ptr %l4
  store i64 %t10, ptr %l11
  %t11 = load i64, ptr %l10
  %t12 = load i64, ptr %l11
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l12
  %t14 = load i1, ptr %l12
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l13
  %t16 = load i1, ptr %l13
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t17, ptr %l14
  %t18 = load i64, ptr %l3
  store i64 %t18, ptr %l15
  %t19 = load i64, ptr %l15
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t19
  %t23 = load { i64, ptr }, ptr %t22
  store { i64, ptr } %t23, ptr %l16
  %t24 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t24, ptr %l5
  %t25 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t25, ptr %l17
  %t26 = load { i64, ptr }, ptr %l17
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l18
  %t28 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t28, ptr %l19
  %t29 = load { i64, ptr }, ptr %l19
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l20
  %t31 = load i64, ptr %l20
  %t32 = add i64 %t31, 1
  store i64 %t32, ptr %l21
  %t33 = load i64, ptr %l18
  %t34 = load i64, ptr %l21
  %t35 = icmp eq i64 %t33, %t34
  store i1 %t35, ptr %l22
  %t36 = load i1, ptr %l22
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t37 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t37, ptr %l24
  %t38 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t39 = load ptr, ptr %t38
  %t40 = getelementptr i8, ptr %t39, i64 0
  %t41 = load i8, ptr %t40
  store i8 %t41, ptr %l25
  %t42 = load i8, ptr %l25
  %t43 = icmp eq i8 %t42, 43
  store i1 %t43, ptr %l26
  %t44 = load i1, ptr %l26
  store i1 %t44, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l23
  br label %bb8
bb8:
  %t45 = load i1, ptr %l23
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t46 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t46, ptr %l28
  %t47 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t47, ptr %l29
  %t48 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t48, ptr %l30
  %t49 = load { i64, ptr }, ptr %l30
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l31
  %t51 = load { i64, ptr }, ptr %l28
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l32
  %t53 = icmp sge i64 1, 0
  store i1 %t53, ptr %l33
  %t54 = load i1, ptr %l33
  br i1 %t54, label %bb11, label %bb12
bb10:
  store i1 false, ptr %l27
  br label %bb18
bb11:
  %t55 = load i64, ptr %l31
  %t56 = icmp sle i64 1, %t55
  store i1 %t56, ptr %l34
  %t57 = load i1, ptr %l34
  br i1 %t57, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb13:
  %t58 = load i64, ptr %l31
  %t59 = load i64, ptr %l32
  %t60 = icmp sle i64 %t58, %t59
  store i1 %t60, ptr %l35
  %t61 = load i1, ptr %l35
  br i1 %t61, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb15:
  %t62 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  %t64 = load i64, ptr %l31
  %t65 = getelementptr i8, ptr %t63, i64 1
  %t66 = sub i64 %t64, 1
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  store { i64, ptr } %t68, ptr %l36
  %t69 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t69, ptr %l37
  %t70 = load { i64, ptr }, ptr %l36
  %t71 = load { i64, ptr }, ptr %l37
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t70, { i64, ptr } %t71)
  store i1 %t72, ptr %l38
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb17:
  %t73 = load i1, ptr %l38
  store i1 %t73, ptr %l27
  br label %bb18
bb18:
  %t74 = load i1, ptr %l27
  br i1 %t74, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 true, ptr %l39
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t75 = load i1, ptr %l39
  store i1 %t75, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t76 = load i64, ptr %l3
  store i64 %t76, ptr %l40
  %t77 = load i64, ptr %l40
  %t78 = add i64 %t77, 1
  store i64 %t78, ptr %l41
  %t79 = load i64, ptr %l41
  store i64 %t79, ptr %l3
  call void @__olang_scope_close(ptr %s4)
  br label %bb2
bb23:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %l42
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i1, ptr %l42
  store i1 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2ftarget_2eHost(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { { i64, ptr }, { i64, ptr } }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { { i64, ptr }, { i64, ptr } }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = icmp sge i64 390, 0
  store i1 %t1, ptr %l1
  %t2 = load i1, ptr %l1
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t3 = mul i64 390, 1
  %t4 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t3)
  %t5 = insertvalue { i64, ptr } undef, i64 390, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t4, 1
  store { i64, ptr } %t6, ptr %l2
  %t7 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t7, ptr %l0
  %t8 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t8, ptr %l3
  %t9 = load { i64, ptr }, ptr %l3
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = call i32 @uname(ptr %t10)
  store i32 %t12, ptr %l4
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb3:
  %t13 = load i32, ptr %l4
  %t14 = icmp ne i32 %t13, 0
  store i1 %t14, ptr %l5
  %t15 = load i1, ptr %l5
  br i1 %t15, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 7, ptr @.d20 }, ptr %l6
  %t16 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t16, ptr %l7
  store { i64, ptr } { i64 7, ptr @.d21 }, ptr %l8
  %t17 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t17, ptr %l9
  %t18 = load { i64, ptr }, ptr %l7
  %t19 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t18, 0
  %t20 = load { i64, ptr }, ptr %l9
  %t21 = insertvalue { { i64, ptr }, { i64, ptr } } %t19, { i64, ptr } %t20, 1
  store { { i64, ptr }, { i64, ptr } } %t21, ptr %l10
  %t22 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l10, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22
  store { i64, ptr } %t23, ptr %l11
  %t24 = load { i64, ptr }, ptr %l11
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l12
  %t26 = load i64, ptr %l12
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l13
  %t31 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t32 = load ptr, ptr %t31
  %t33 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t34 = load ptr, ptr %t33
  %t35 = load i64, ptr %l12
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l13
  %t38 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l10, i32 0, i32 0
  store { i64, ptr } %t37, ptr %t38
  %t39 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l10, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39
  store { i64, ptr } %t40, ptr %l14
  %t41 = load { i64, ptr }, ptr %l14
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l15
  %t43 = load i64, ptr %l15
  %t44 = mul i64 %t43, 1
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l16
  %t48 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  %t50 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  %t52 = load i64, ptr %l15
  %t53 = mul i64 %t52, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %t51, i64 %t53, i1 false)
  %t54 = load { i64, ptr }, ptr %l16
  %t55 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l10, i32 0, i32 1
  store { i64, ptr } %t54, ptr %t55
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { { i64, ptr }, { i64, ptr } }, ptr %l10
  store { { i64, ptr }, { i64, ptr } } %t56, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t57 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t57, ptr %l17
  %t58 = load { i64, ptr }, ptr %l17
  %t59 = call { i64, ptr } @compiler_2ftarget_2ecField(ptr %s0, ptr %v0, { i64, ptr } %t58, i64 0)
  store { i64, ptr } %t59, ptr %l18
  br label %bb7
bb7:
  %t60 = load { i64, ptr }, ptr %l18
  %t61 = extractvalue { i64, ptr } %t60, 0
  %t62 = extractvalue { i64, ptr } %t60, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l19
  %t67 = load { i64, ptr }, ptr %l19
  %t68 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v0, { i64, ptr } %t67)
  store { i64, ptr } %t68, ptr %l20
  br label %bb8
bb8:
  %t69 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t69, ptr %l21
  %t70 = load { i64, ptr }, ptr %l21
  %t71 = call { i64, ptr } @compiler_2ftarget_2ecField(ptr %s0, ptr %v0, { i64, ptr } %t70, i64 260)
  store { i64, ptr } %t71, ptr %l22
  br label %bb9
bb9:
  %t72 = load { i64, ptr }, ptr %l20
  %t73 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t72, 0
  %t74 = load { i64, ptr }, ptr %l22
  %t75 = insertvalue { { i64, ptr }, { i64, ptr } } %t73, { i64, ptr } %t74, 1
  store { { i64, ptr }, { i64, ptr } } %t75, ptr %l23
  call void @__olang_scope_close(ptr %s0)
  %t76 = load { { i64, ptr }, { i64, ptr } }, ptr %l23
  store { { i64, ptr }, { i64, ptr } } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2ftarget_2eIeeeUnsafe_2einit() #0 {
entry:
  %l0 = alloca [2 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 10, ptr @.d22 }, 0
  %t2 = insertvalue [2 x { i64, ptr }] %t1, { i64, ptr } { i64 12, ptr @.d23 }, 1
  store [2 x { i64, ptr }] %t2, ptr %l0
  %t3 = load [2 x { i64, ptr }], ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call ptr @__olang_scope_alloc(ptr %t4, i64 32)
  store [2 x { i64, ptr }] %t3, ptr %t5
  %t6 = insertvalue { i64, ptr } undef, i64 2, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l1
  %t8 = load { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eIeeeUnsafe
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l2
  %t10 = load { i64, ptr }, ptr %l1
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l3
  %t12 = load i64, ptr %l2
  %t13 = load i64, ptr %l3
  %t14 = icmp eq i64 %t12, %t13
  store i1 %t14, ptr %l4
  %t15 = load i1, ptr %l4
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t16 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eIeeeUnsafe, i32 0, i32 1
  %t17 = load ptr, ptr %t16
  %t18 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  %t20 = load i64, ptr %l3
  %t21 = mul i64 %t20, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  br label %bb3
bb2:
  %t22 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t22, ptr @G_2ecompiler_2ftarget_2eIeeeUnsafe
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftarget_2eLevelFlags_2einit() #0 {
entry:
  %l0 = alloca [3 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 39, ptr @.d24 }, 0
  %t2 = insertvalue [3 x { i64, ptr }] %t1, { i64, ptr } { i64 43, ptr @.d25 }, 1
  %t3 = insertvalue [3 x { i64, ptr }] %t2, { i64, ptr } { i64 43, ptr @.d26 }, 2
  store [3 x { i64, ptr }] %t3, ptr %l0
  %t4 = load [3 x { i64, ptr }], ptr %l0
  %t5 = load ptr, ptr @__olang_prog_scope
  %t6 = call ptr @__olang_scope_alloc(ptr %t5, i64 48)
  store [3 x { i64, ptr }] %t4, ptr %t6
  %t7 = insertvalue { i64, ptr } undef, i64 3, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l1
  %t9 = load { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eLevelFlags
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l2
  %t11 = load { i64, ptr }, ptr %l1
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l3
  %t13 = load i64, ptr %l2
  %t14 = load i64, ptr %l3
  %t15 = icmp eq i64 %t13, %t14
  store i1 %t15, ptr %l4
  %t16 = load i1, ptr %l4
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t17 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eLevelFlags, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  %t21 = load i64, ptr %l3
  %t22 = mul i64 %t21, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  br label %bb3
bb2:
  %t23 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t23, ptr @G_2ecompiler_2ftarget_2eLevelFlags
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca { { i64, ptr }, { i64, ptr } }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { { i64, ptr }, { i64, ptr } }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"compiler/target:Target"
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca %"compiler/target:Target"
  %l22 = alloca i32
  %l23 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/target:Target" }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { { i64, ptr }, { i64, ptr } } @compiler_2ftarget_2eHost(ptr %s0)
  store { { i64, ptr }, { i64, ptr } } %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load { { i64, ptr }, { i64, ptr } }, ptr %l7
  store { { i64, ptr }, { i64, ptr } } %t2, ptr %l4
  %t3 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l4, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3
  store { i64, ptr } %t4, ptr %l8
  %t5 = load { i64, ptr }, ptr %l8
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l9
  %t7 = load i64, ptr %l9
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l10
  %t12 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t13 = load ptr, ptr %t12
  %t14 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t15 = load ptr, ptr %t14
  %t16 = load i64, ptr %l9
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t18, ptr %l5
  %t19 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l4, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l11
  %t21 = load { i64, ptr }, ptr %l11
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l12
  %t23 = load i64, ptr %l12
  %t24 = mul i64 %t23, 1
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l13
  %t28 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  %t30 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t31 = load ptr, ptr %t30
  %t32 = load i64, ptr %l12
  %t33 = mul i64 %t32, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  %t34 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t34, ptr %l6
  %t35 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t35, ptr %l15
  %t36 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t36, ptr %l16
  %t37 = load i1, ptr %l2
  store i1 %t37, ptr %l17
  %t38 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t38, ptr %l18
  %t39 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t39, ptr %l19
  %t40 = load ptr, ptr %l3
  store ptr %t40, ptr %l20
  %t41 = load { i64, ptr }, ptr %l15
  %t42 = load { i64, ptr }, ptr %l16
  %t43 = load i1, ptr %l17
  %t44 = load { i64, ptr }, ptr %l18
  %t45 = load { i64, ptr }, ptr %l19
  %t46 = load ptr, ptr %l20
  %t47 = call { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolveOn(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %v2, ptr %v3, { i64, ptr } %t41, { i64, ptr } %t42, i1 %t43, { i64, ptr } %t44, { i64, ptr } %t45, ptr %t46)
  %t48 = extractvalue { i32, %"compiler/target:Target" } %t47, 1
  %t49 = extractvalue { i32, %"compiler/target:Target" } %t47, 0
  store i32 %t49, ptr %l22
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb3, label %ok.51
ok.51:
  store %"compiler/target:Target" %t48, ptr %l21
  br label %bb2
bb2:
  %t52 = load %"compiler/target:Target", ptr %l21
  store %"compiler/target:Target" %t52, ptr %l14
  br label %bb4
bb3:
  %t53 = load i32, ptr %l22
  %t54 = lshr i32 %t53, 16
  %t55 = and i32 %t53, 65535
  %t56 = icmp eq i32 %t54, 1
  %t57 = select i1 %t56, i32 1, i32 0
  %t58 = icmp eq i32 %t53, 0
  %t59 = shl i32 %t57, 16
  %t60 = or i32 %t59, %t55
  %t61 = select i1 %t58, i32 0, i32 %t60
  store i32 %t61, ptr %l23
  call void @__olang_scope_close(ptr %s0)
  %t62 = load i32, ptr %l23
  %t63 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t62, 0
  store { i32, %"compiler/target:Target" } %t63, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load %"compiler/target:Target", ptr %l14
  %t65 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, %"compiler/target:Target" %t64, 1
  store { i32, %"compiler/target:Target" } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/target:Target" }, ptr %rv
  ret { i32, %"compiler/target:Target" } %rr
}

define dso_local { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolveOn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"std/os:Output"
  %l19 = alloca %"compiler/target:Target"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i8
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i8
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i1
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l90 = alloca %"compiler/msgs:Msg"
  %l91 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i1
  %l94 = alloca i1
  %l95 = alloca { i64, ptr }
  %l96 = alloca i1
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l104 = alloca %"compiler/msgs:Msg"
  %l105 = alloca i32
  %l106 = alloca i32
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i1
  %l116 = alloca i1
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l123 = alloca %"compiler/msgs:Msg"
  %l124 = alloca i32
  %l125 = alloca i32
  %l126 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i1
  %l130 = alloca i1
  %l131 = alloca { i64, ptr }
  %l132 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l135 = alloca %"compiler/msgs:Msg"
  %l136 = alloca i32
  %l137 = alloca i32
  %l138 = alloca { i64, ptr }
  %l139 = alloca i64
  %l140 = alloca i64
  %l141 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l144 = alloca %"compiler/msgs:Msg"
  %l145 = alloca i32
  %l146 = alloca i32
  %l147 = alloca i64
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l154 = alloca i1
  %l155 = alloca i1
  %l156 = alloca i1
  %l157 = alloca { i64, ptr }
  %l158 = alloca i1
  %l159 = alloca i1
  %l160 = alloca { i64, ptr }
  %l161 = alloca i1
  %l162 = alloca i1
  %l163 = alloca i1
  %l164 = alloca i1
  %l165 = alloca i1
  %l166 = alloca i1
  %l167 = alloca i1
  %l168 = alloca i64
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l172 = alloca i1
  %l173 = alloca i1
  %l174 = alloca { i64, ptr }
  %l175 = alloca i1
  %l176 = alloca i1
  %l177 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca { i64, ptr }
  %l180 = alloca %"compiler/msgs:Msg"
  %l181 = alloca i32
  %l182 = alloca i32
  %l183 = alloca i1
  %l184 = alloca i1
  %l185 = alloca i1
  %l186 = alloca ptr
  %l187 = alloca { i64, ptr }
  %l188 = alloca %"compiler/msgs:Msg"
  %l189 = alloca i32
  %l190 = alloca i32
  %l191 = alloca { i64, ptr }
  %l192 = alloca i1
  %l193 = alloca i1
  %l194 = alloca i1
  %l195 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l200 = alloca i1
  %l201 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l204 = alloca %"compiler/msgs:Msg"
  %l205 = alloca i32
  %l206 = alloca i32
  %l207 = alloca %"compiler/target:Target"
  %l208 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l209 = alloca ptr
  %l210 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l214 = alloca i1
  %l215 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca { i64, ptr }
  %l218 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l220 = alloca i1
  %l221 = alloca ptr
  %l222 = alloca i64
  %l223 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l227 = alloca [7 x { i64, ptr }]
  %l228 = alloca ptr
  %l229 = alloca ptr
  %l230 = alloca i64
  %l231 = alloca i64
  %l232 = alloca i64
  %l233 = alloca i1
  %l234 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i64
  %l237 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l239 = alloca { i64, ptr }
  %l240 = alloca i64
  %l241 = alloca i64
  %l242 = alloca %"std/os:Output"
  %l243 = alloca ptr
  %l244 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l246 = alloca %"std/os:Output"
  %l247 = alloca i32
  %l248 = alloca i32
  %l249 = alloca i1
  %l250 = alloca i32
  %l251 = alloca ptr
  %l252 = alloca { i64, ptr }
  %l253 = alloca %"compiler/msgs:Msg"
  %l254 = alloca i32
  %l255 = alloca i32
  %l256 = alloca i32
  %l257 = alloca i1
  %l258 = alloca ptr
  %l259 = alloca { i64, ptr }
  %l260 = alloca %"compiler/msgs:Msg"
  %l261 = alloca i32
  %l262 = alloca i32
  %l263 = alloca ptr
  %l264 = alloca { i64, ptr }
  %l265 = alloca i32
  %l266 = alloca i1
  %l267 = alloca i1
  %l268 = alloca i32
  %l269 = alloca ptr
  %l270 = alloca { i64, ptr }
  %l271 = alloca %"compiler/msgs:Msg"
  %l272 = alloca i32
  %l273 = alloca i32
  %l274 = alloca ptr
  %l275 = alloca { i64, ptr }
  %l276 = alloca %"compiler/msgs:Msg"
  %l277 = alloca i32
  %l278 = alloca i32
  %l279 = alloca i1
  %l280 = alloca i1
  %l281 = alloca { i64, ptr }
  %l282 = alloca { i64, ptr }
  %l283 = alloca i1
  %l284 = alloca i1
  %l285 = alloca ptr
  %l286 = alloca { i64, ptr }
  %l287 = alloca %"compiler/msgs:Msg"
  %l288 = alloca i32
  %l289 = alloca i32
  %l290 = alloca i64
  %l291 = alloca { i64, ptr }
  %l292 = alloca { i64, ptr }
  %l293 = alloca { i64, ptr }
  %l294 = alloca { i64, ptr }
  %l295 = alloca %"compiler/target:Target"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.builder
  %s17room = alloca [64 x i8], align 8
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.builder
  %s22room = alloca [64 x i8], align 8
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.builder
  %s26room = alloca [64 x i8], align 8
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.builder
  %s35room = alloca [64 x i8], align 8
  %rv = alloca { i32, %"compiler/target:Target" }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v5)
  store %"compiler/target:Target" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 128, i64 8)
  store ptr %t2, ptr %lp6
  %t3 = load %"compiler/target:Target", ptr %l19
  %t4 = load ptr, ptr %lp6
  store %"compiler/target:Target" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t5, ptr %l20
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t6 = load { i64, ptr }, ptr %l20
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l21
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l21
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l22
  %t22 = load { i64, ptr }, ptr %l22
  %t23 = load ptr, ptr %lp6
  %t24 = getelementptr %"compiler/target:Target", ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  store { i64, ptr } { i64 0, ptr @.d27 }, ptr %l7
  %t25 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t25, ptr %l23
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t26 = load { i64, ptr }, ptr %l23
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  call void @__olang_sb_put(ptr %s2, ptr %t27, i64 %t28)
  %t29 = load ptr, ptr %s2
  %t30 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t31 = load i64, ptr %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t29, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l24
  call void @__olang_sb_done(ptr %s2)
  %t35 = load { i64, ptr }, ptr %l24
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l25
  %t42 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t42, ptr %l8
  store i1 true, ptr %l9
  store i64 -1, ptr %l10
  %t43 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t43, ptr %l27
  store i8 45, ptr %l28
  %t44 = load { i64, ptr }, ptr %l27
  %t45 = load i8, ptr %l28
  %t46 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t44, i8 %t45)
  %t47 = extractvalue { i32, i64 } %t46, 1
  %t48 = extractvalue { i32, i64 } %t46, 0
  store i32 %t48, ptr %l30
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb3, label %ok.50
ok.50:
  store i64 %t47, ptr %l29
  br label %bb2
bb2:
  %t51 = load i64, ptr %l29
  store i64 %t51, ptr %l26
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l26
  br label %bb5
bb5:
  %t52 = load i64, ptr %l26
  store i64 %t52, ptr %l11
  %t53 = load i64, ptr %l11
  store i64 %t53, ptr %l31
  %t54 = load i64, ptr %l31
  %t55 = icmp sge i64 %t54, 0
  store i1 %t55, ptr %l32
  %t56 = load i1, ptr %l32
  br i1 %t56, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t57, ptr %l33
  %t58 = load i64, ptr %l11
  store i64 %t58, ptr %l34
  %t59 = load { i64, ptr }, ptr %l33
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l35
  %t61 = icmp sge i64 0, 0
  store i1 %t61, ptr %l36
  %t62 = load i1, ptr %l36
  br i1 %t62, label %bb8, label %bb9
bb7:
  br label %bb15
bb8:
  %t63 = load i64, ptr %l34
  %t64 = icmp sle i64 0, %t63
  store i1 %t64, ptr %l37
  %t65 = load i1, ptr %l37
  br i1 %t65, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb10:
  %t66 = load i64, ptr %l34
  %t67 = load i64, ptr %l35
  %t68 = icmp sle i64 %t66, %t67
  store i1 %t68, ptr %l38
  %t69 = load i1, ptr %l38
  br i1 %t69, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb12:
  %t70 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t71 = load ptr, ptr %t70
  %t72 = load i64, ptr %l34
  %t73 = getelementptr i8, ptr %t71, i64 0
  %t74 = sub i64 %t72, 0
  %t75 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t73, 1
  store { i64, ptr } %t76, ptr %l39
  %t77 = load { i64, ptr }, ptr %l39
  %t78 = call i64 @compiler_2ftarget_2earchIndex(ptr %v0, { i64, ptr } %t77)
  store i64 %t78, ptr %l40
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb14:
  %t79 = load i64, ptr %l40
  store i64 %t79, ptr %l10
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t80 = load i64, ptr %l10
  store i64 %t80, ptr %l41
  %t81 = load i64, ptr %l41
  %t82 = icmp sge i64 %t81, 0
  store i1 %t82, ptr %l42
  %t83 = load i1, ptr %l42
  br i1 %t83, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t84 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t84, ptr %l44
  store i8 58, ptr %l45
  %t85 = load { i64, ptr }, ptr %l44
  %t86 = load i8, ptr %l45
  %t87 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t85, i8 %t86)
  %t88 = extractvalue { i32, i64 } %t87, 1
  %t89 = extractvalue { i32, i64 } %t87, 0
  store i32 %t89, ptr %l47
  %t90 = icmp ne i32 %t89, 0
  br i1 %t90, label %bb19, label %ok.91
ok.91:
  store i64 %t88, ptr %l46
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s10
  %t92 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t92, ptr %l107
  %t93 = load { i64, ptr }, ptr %l107
  store { i64, ptr } %t93, ptr %l108
  store { i64, ptr } { i64 6, ptr @.d29 }, ptr %l109
  %t94 = load { i64, ptr }, ptr %l108
  %t95 = load { i64, ptr }, ptr %l109
  %t96 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s10, { i64, ptr } %t94, { i64, ptr } %t95)
  store i1 %t96, ptr %l110
  br label %bb66
bb18:
  %t97 = load i64, ptr %l46
  store i64 %t97, ptr %l43
  br label %bb21
bb19:
  br label %bb20
bb20:
  store i64 -1, ptr %l43
  br label %bb21
bb21:
  %t98 = load i64, ptr %l43
  store i64 %t98, ptr %l12
  %t99 = load i64, ptr %l12
  store i64 %t99, ptr %l48
  %t100 = load i64, ptr %l48
  %t101 = icmp sge i64 %t100, 0
  store i1 %t101, ptr %l49
  %t102 = load i1, ptr %l49
  br i1 %t102, label %bb22, label %bb23
bb22:
  %t103 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t103, ptr %l51
  %t104 = load i64, ptr %l12
  store i64 %t104, ptr %l52
  %t105 = load { i64, ptr }, ptr %l51
  %t106 = extractvalue { i64, ptr } %t105, 0
  store i64 %t106, ptr %l53
  %t107 = icmp sge i64 0, 0
  store i1 %t107, ptr %l54
  %t108 = load i1, ptr %l54
  br i1 %t108, label %bb24, label %bb25
bb23:
  %t109 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t109, ptr %l60
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t110 = load { i64, ptr }, ptr %l60
  %t111 = extractvalue { i64, ptr } %t110, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  call void @__olang_sb_put(ptr %s6, ptr %t111, i64 %t112)
  %t113 = load ptr, ptr %s6
  %t114 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t115 = load i64, ptr %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t113, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l61
  call void @__olang_sb_done(ptr %s6)
  %t119 = load { i64, ptr }, ptr %l61
  %t120 = extractvalue { i64, ptr } %t119, 0
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l62
  %t126 = load { i64, ptr }, ptr %l62
  store { i64, ptr } %t126, ptr %l50
  br label %bb30
bb24:
  %t127 = load i64, ptr %l52
  %t128 = icmp sle i64 0, %t127
  store i1 %t128, ptr %l55
  %t129 = load i1, ptr %l55
  br i1 %t129, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb26:
  %t130 = load i64, ptr %l52
  %t131 = load i64, ptr %l53
  %t132 = icmp sle i64 %t130, %t131
  store i1 %t132, ptr %l56
  %t133 = load i1, ptr %l56
  br i1 %t133, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb28:
  %t134 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t135 = load ptr, ptr %t134
  %t136 = load i64, ptr %l52
  %t137 = getelementptr i8, ptr %t135, i64 0
  %t138 = sub i64 %t136, 0
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l57
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t141 = load { i64, ptr }, ptr %l57
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  call void @__olang_sb_put(ptr %s5, ptr %t142, i64 %t143)
  %t144 = load ptr, ptr %s5
  %t145 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t146 = load i64, ptr %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t144, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  store { i64, ptr } %t149, ptr %l58
  call void @__olang_sb_done(ptr %s5)
  %t150 = load { i64, ptr }, ptr %l58
  %t151 = extractvalue { i64, ptr } %t150, 0
  %t152 = extractvalue { i64, ptr } %t150, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  store { i64, ptr } %t156, ptr %l59
  %t157 = load { i64, ptr }, ptr %l59
  store { i64, ptr } %t157, ptr %l50
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb30:
  %t158 = load { i64, ptr }, ptr %l50
  store { i64, ptr } %t158, ptr %l7
  %t159 = load i64, ptr %l12
  store i64 %t159, ptr %l63
  %t160 = load i64, ptr %l63
  %t161 = icmp sge i64 %t160, 0
  store i1 %t161, ptr %l64
  %t162 = load i1, ptr %l64
  store i1 %t162, ptr %l9
  %t163 = load i64, ptr %l12
  store i64 %t163, ptr %l65
  %t164 = load i64, ptr %l65
  %t165 = icmp sge i64 %t164, 0
  store i1 %t165, ptr %l66
  %t166 = load i1, ptr %l66
  br i1 %t166, label %bb31, label %bb32
bb31:
  %t167 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t167, ptr %l68
  %t168 = load i64, ptr %l12
  store i64 %t168, ptr %l69
  %t169 = load i64, ptr %l69
  %t170 = add i64 %t169, 1
  store i64 %t170, ptr %l70
  %t171 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t171, ptr %l71
  %t172 = load { i64, ptr }, ptr %l71
  store { i64, ptr } %t172, ptr %l72
  %t173 = load { i64, ptr }, ptr %l72
  %t174 = extractvalue { i64, ptr } %t173, 0
  store i64 %t174, ptr %l73
  %t175 = load { i64, ptr }, ptr %l68
  %t176 = extractvalue { i64, ptr } %t175, 0
  store i64 %t176, ptr %l74
  %t177 = load i64, ptr %l70
  %t178 = icmp sge i64 %t177, 0
  store i1 %t178, ptr %l75
  %t179 = load i1, ptr %l75
  br i1 %t179, label %bb33, label %bb34
bb32:
  store { i64, ptr } { i64 0, ptr @.d31 }, ptr %l67
  br label %bb39
bb33:
  %t180 = load i64, ptr %l70
  %t181 = load i64, ptr %l73
  %t182 = icmp sle i64 %t180, %t181
  store i1 %t182, ptr %l76
  %t183 = load i1, ptr %l76
  br i1 %t183, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @.c32)
  unreachable
bb35:
  %t184 = load i64, ptr %l73
  %t185 = load i64, ptr %l74
  %t186 = icmp sle i64 %t184, %t185
  store i1 %t186, ptr %l77
  %t187 = load i1, ptr %l77
  br i1 %t187, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @.c32)
  unreachable
bb37:
  %t188 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t189 = load ptr, ptr %t188
  %t190 = load i64, ptr %l70
  %t191 = load i64, ptr %l73
  %t192 = getelementptr i8, ptr %t189, i64 %t190
  %t193 = sub i64 %t191, %t190
  %t194 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t192, 1
  store { i64, ptr } %t195, ptr %l78
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t196 = load { i64, ptr }, ptr %l78
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = extractvalue { i64, ptr } %t196, 0
  call void @__olang_sb_put(ptr %s7, ptr %t197, i64 %t198)
  %t199 = load ptr, ptr %s7
  %t200 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t201 = load i64, ptr %t200
  %t202 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t199, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  store { i64, ptr } %t204, ptr %l79
  call void @__olang_sb_done(ptr %s7)
  %t205 = load { i64, ptr }, ptr %l79
  %t206 = extractvalue { i64, ptr } %t205, 0
  %t207 = extractvalue { i64, ptr } %t205, 1
  %t208 = mul i64 %t206, 1
  %t209 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t208)
  call void @llvm.memcpy.p0.p0.i64(ptr %t209, ptr %t207, i64 %t208, i1 false)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  store { i64, ptr } %t211, ptr %l80
  %t212 = load { i64, ptr }, ptr %l80
  store { i64, ptr } %t212, ptr %l67
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @.c32)
  unreachable
bb39:
  %t213 = load { i64, ptr }, ptr %l67
  store { i64, ptr } %t213, ptr %l8
  %t214 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t214, ptr %l81
  %t215 = load { i64, ptr }, ptr %l81
  %t216 = extractvalue { i64, ptr } %t215, 0
  store i64 %t216, ptr %l82
  %t217 = load i64, ptr %l82
  %t218 = icmp sgt i64 %t217, 10
  store i1 %t218, ptr %l83
  %t219 = load i1, ptr %l83
  br i1 %t219, label %bb40, label %bb41
bb40:
  %t220 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t220, ptr %l85
  %t221 = load { i64, ptr }, ptr %l85
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s4, { i64, ptr } %t221, { i64, ptr } { i64 10, ptr @.d33 })
  store i1 %t222, ptr %l86
  br label %bb42
bb41:
  store i1 false, ptr %l84
  br label %bb43
bb42:
  %t223 = load i1, ptr %l86
  store i1 %t223, ptr %l84
  br label %bb43
bb43:
  %t224 = load i1, ptr %l84
  %t225 = xor i1 %t224, true
  store i1 %t225, ptr %l87
  %t226 = load i1, ptr %l87
  br i1 %t226, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t227 = load ptr, ptr %l5
  store ptr %t227, ptr %l88
  %t228 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t228, ptr %l89
  %t229 = load { i64, ptr }, ptr %l89
  %t230 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %s8, { i64, ptr } %t229)
  store %"compiler/msgs:Msg" %t230, ptr %l90
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t231 = load ptr, ptr %l88
  %t232 = load %"compiler/msgs:Msg", ptr %l90
  %t233 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s8, ptr %t231, %"compiler/msgs:Msg" %t232)
  store i32 %t233, ptr %l91
  %t234 = icmp ne i32 %t233, 0
  br i1 %t234, label %bb48, label %ok.235
ok.235:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t236 = load i32, ptr %l91
  %t237 = lshr i32 %t236, 16
  %t238 = and i32 %t236, 65535
  %t239 = icmp eq i32 %t237, 1
  %t240 = select i1 %t239, i32 1, i32 0
  %t241 = icmp eq i32 %t236, 0
  %t242 = shl i32 %t240, 16
  %t243 = or i32 %t242, %t238
  %t244 = select i1 %t241, i32 0, i32 %t243
  store i32 %t244, ptr %l92
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t245 = load i32, ptr %l92
  %t246 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t245, 0
  store { i32, %"compiler/target:Target" } %t246, ptr %rv
  br label %ret
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  %t247 = load i1, ptr %l9
  store i1 %t247, ptr %l93
  %t248 = load i1, ptr %l93
  br i1 %t248, label %bb51, label %bb52
bb51:
  %t249 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t249, ptr %l95
  %t250 = load { i64, ptr }, ptr %l95
  %t251 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t250, { i64, ptr } { i64 0, ptr @.d34 })
  store i1 %t251, ptr %l96
  br label %bb53
bb52:
  store i1 false, ptr %l94
  br label %bb58
bb53:
  %t252 = load i1, ptr %l96
  br i1 %t252, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l97
  br label %bb57
bb55:
  %t253 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t253, ptr %l98
  %t254 = load { i64, ptr }, ptr %l98
  store { i64, ptr } %t254, ptr %l99
  store { i64, ptr } { i64 1, ptr @.d35 }, ptr %l100
  %t255 = load { i64, ptr }, ptr %l99
  %t256 = load { i64, ptr }, ptr %l100
  %t257 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s4, { i64, ptr } %t255, { i64, ptr } %t256)
  store i1 %t257, ptr %l101
  br label %bb56
bb56:
  %t258 = load i1, ptr %l101
  store i1 %t258, ptr %l97
  br label %bb57
bb57:
  %t259 = load i1, ptr %l97
  store i1 %t259, ptr %l94
  br label %bb58
bb58:
  %t260 = load i1, ptr %l94
  br i1 %t260, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s9
  %t261 = load ptr, ptr %l5
  store ptr %t261, ptr %l102
  %t262 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t262, ptr %l103
  %t263 = load { i64, ptr }, ptr %l103
  %t264 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %s9, { i64, ptr } %t263)
  store %"compiler/msgs:Msg" %t264, ptr %l104
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t265 = load ptr, ptr %l102
  %t266 = load %"compiler/msgs:Msg", ptr %l104
  %t267 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s9, ptr %t265, %"compiler/msgs:Msg" %t266)
  store i32 %t267, ptr %l105
  %t268 = icmp ne i32 %t267, 0
  br i1 %t268, label %bb63, label %ok.269
ok.269:
  br label %bb62
bb62:
  br label %bb64
bb63:
  %t270 = load i32, ptr %l105
  %t271 = lshr i32 %t270, 16
  %t272 = and i32 %t270, 65535
  %t273 = icmp eq i32 %t271, 1
  %t274 = select i1 %t273, i32 1, i32 0
  %t275 = icmp eq i32 %t270, 0
  %t276 = shl i32 %t274, 16
  %t277 = or i32 %t276, %t272
  %t278 = select i1 %t275, i32 0, i32 %t277
  store i32 %t278, ptr %l106
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t279 = load i32, ptr %l106
  %t280 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t279, 0
  store { i32, %"compiler/target:Target" } %t280, ptr %rv
  br label %ret
bb64:
  call void @__olang_scope_close(ptr %s9)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s4)
  br label %bb102
bb66:
  %t281 = load i1, ptr %l110
  br i1 %t281, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l111
  br label %bb70
bb68:
  %t282 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t282, ptr %l112
  %t283 = load { i64, ptr }, ptr %l112
  store { i64, ptr } %t283, ptr %l113
  store { i64, ptr } { i64 6, ptr @.d36 }, ptr %l114
  %t284 = load { i64, ptr }, ptr %l113
  %t285 = load { i64, ptr }, ptr %l114
  %t286 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s10, { i64, ptr } %t284, { i64, ptr } %t285)
  store i1 %t286, ptr %l115
  br label %bb69
bb69:
  %t287 = load i1, ptr %l115
  store i1 %t287, ptr %l111
  br label %bb70
bb70:
  %t288 = load i1, ptr %l111
  br i1 %t288, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l116
  br label %bb74
bb72:
  %t289 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t289, ptr %l117
  %t290 = load { i64, ptr }, ptr %l117
  store { i64, ptr } %t290, ptr %l118
  store { i64, ptr } { i64 8, ptr @.d37 }, ptr %l119
  %t291 = load { i64, ptr }, ptr %l118
  %t292 = load { i64, ptr }, ptr %l119
  %t293 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s10, { i64, ptr } %t291, { i64, ptr } %t292)
  store i1 %t293, ptr %l120
  br label %bb73
bb73:
  %t294 = load i1, ptr %l120
  store i1 %t294, ptr %l116
  br label %bb74
bb74:
  %t295 = load i1, ptr %l116
  br i1 %t295, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s11
  %t296 = load ptr, ptr %l5
  store ptr %t296, ptr %l121
  %t297 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t297, ptr %l122
  %t298 = load { i64, ptr }, ptr %l122
  %t299 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %s11, { i64, ptr } %t298)
  store %"compiler/msgs:Msg" %t299, ptr %l123
  br label %bb77
bb76:
  br label %bb81
bb77:
  %t300 = load ptr, ptr %l121
  %t301 = load %"compiler/msgs:Msg", ptr %l123
  %t302 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s11, ptr %t300, %"compiler/msgs:Msg" %t301)
  store i32 %t302, ptr %l124
  %t303 = icmp ne i32 %t302, 0
  br i1 %t303, label %bb79, label %ok.304
ok.304:
  br label %bb78
bb78:
  br label %bb80
bb79:
  %t305 = load i32, ptr %l124
  %t306 = lshr i32 %t305, 16
  %t307 = and i32 %t305, 65535
  %t308 = icmp eq i32 %t306, 1
  %t309 = select i1 %t308, i32 1, i32 0
  %t310 = icmp eq i32 %t305, 0
  %t311 = shl i32 %t309, 16
  %t312 = or i32 %t311, %t307
  %t313 = select i1 %t310, i32 0, i32 %t312
  store i32 %t313, ptr %l125
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t314 = load i32, ptr %l125
  %t315 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t314, 0
  store { i32, %"compiler/target:Target" } %t315, ptr %rv
  br label %ret
bb80:
  call void @__olang_scope_close(ptr %s11)
  br label %bb81
bb81:
  %t316 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t316, ptr %l126
  %t317 = load { i64, ptr }, ptr %l126
  store { i64, ptr } %t317, ptr %l127
  store { i64, ptr } { i64 1, ptr @.d38 }, ptr %l128
  %t318 = load { i64, ptr }, ptr %l127
  %t319 = load { i64, ptr }, ptr %l128
  %t320 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s10, { i64, ptr } %t318, { i64, ptr } %t319)
  store i1 %t320, ptr %l129
  br label %bb82
bb82:
  %t321 = load i1, ptr %l129
  br i1 %t321, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l130
  br label %bb86
bb84:
  %t322 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t322, ptr %l131
  %t323 = load { i64, ptr }, ptr %l131
  %t324 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s10, { i64, ptr } %t323, { i64, ptr } { i64 0, ptr @.d39 })
  store i1 %t324, ptr %l132
  br label %bb85
bb85:
  %t325 = load i1, ptr %l132
  store i1 %t325, ptr %l130
  br label %bb86
bb86:
  %t326 = load i1, ptr %l130
  br i1 %t326, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s12
  %t327 = load ptr, ptr %l5
  store ptr %t327, ptr %l133
  %t328 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t328, ptr %l134
  %t329 = load { i64, ptr }, ptr %l134
  %t330 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %s12, { i64, ptr } %t329)
  store %"compiler/msgs:Msg" %t330, ptr %l135
  br label %bb89
bb88:
  br label %bb93
bb89:
  %t331 = load ptr, ptr %l133
  %t332 = load %"compiler/msgs:Msg", ptr %l135
  %t333 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s12, ptr %t331, %"compiler/msgs:Msg" %t332)
  store i32 %t333, ptr %l136
  %t334 = icmp ne i32 %t333, 0
  br i1 %t334, label %bb91, label %ok.335
ok.335:
  br label %bb90
bb90:
  br label %bb92
bb91:
  %t336 = load i32, ptr %l136
  %t337 = lshr i32 %t336, 16
  %t338 = and i32 %t336, 65535
  %t339 = icmp eq i32 %t337, 1
  %t340 = select i1 %t339, i32 1, i32 0
  %t341 = icmp eq i32 %t336, 0
  %t342 = shl i32 %t340, 16
  %t343 = or i32 %t342, %t338
  %t344 = select i1 %t341, i32 0, i32 %t343
  store i32 %t344, ptr %l137
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t345 = load i32, ptr %l137
  %t346 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t345, 0
  store { i32, %"compiler/target:Target" } %t346, ptr %rv
  br label %ret
bb92:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb93:
  %t347 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t347, ptr %l138
  %t348 = load { i64, ptr }, ptr %l138
  %t349 = call i64 @compiler_2ftarget_2earchIndex(ptr %v3, { i64, ptr } %t348)
  store i64 %t349, ptr %l139
  br label %bb94
bb94:
  %t350 = load i64, ptr %l139
  store i64 %t350, ptr %l10
  %t351 = load i64, ptr %l10
  store i64 %t351, ptr %l140
  %t352 = load i64, ptr %l140
  %t353 = icmp slt i64 %t352, 0
  store i1 %t353, ptr %l141
  %t354 = load i1, ptr %l141
  br i1 %t354, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s13
  %t355 = load ptr, ptr %l5
  store ptr %t355, ptr %l142
  %t356 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t356, ptr %l143
  %t357 = load { i64, ptr }, ptr %l143
  %t358 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v3, ptr %s13, { i64, ptr } %t357)
  store %"compiler/msgs:Msg" %t358, ptr %l144
  br label %bb97
bb96:
  br label %bb101
bb97:
  %t359 = load ptr, ptr %l142
  %t360 = load %"compiler/msgs:Msg", ptr %l144
  %t361 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s13, ptr %t359, %"compiler/msgs:Msg" %t360)
  store i32 %t361, ptr %l145
  %t362 = icmp ne i32 %t361, 0
  br i1 %t362, label %bb99, label %ok.363
ok.363:
  br label %bb98
bb98:
  br label %bb100
bb99:
  %t364 = load i32, ptr %l145
  %t365 = lshr i32 %t364, 16
  %t366 = and i32 %t364, 65535
  %t367 = icmp eq i32 %t365, 1
  %t368 = select i1 %t367, i32 1, i32 0
  %t369 = icmp eq i32 %t364, 0
  %t370 = shl i32 %t368, 16
  %t371 = or i32 %t370, %t366
  %t372 = select i1 %t369, i32 0, i32 %t371
  store i32 %t372, ptr %l146
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t373 = load i32, ptr %l146
  %t374 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t373, 0
  store { i32, %"compiler/target:Target" } %t374, ptr %rv
  br label %ret
bb100:
  call void @__olang_scope_close(ptr %s13)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s10)
  br label %bb102
bb102:
  %t375 = load i64, ptr %l10
  store i64 %t375, ptr %l147
  %t376 = load i64, ptr %l147
  %t377 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchs, i32 0, i32 1
  %t378 = load ptr, ptr %t377
  %t379 = getelementptr { i64, ptr }, ptr %t378, i64 %t376
  %t380 = load { i64, ptr }, ptr %t379
  store { i64, ptr } %t380, ptr %l148
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t381 = load { i64, ptr }, ptr %l148
  %t382 = extractvalue { i64, ptr } %t381, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  call void @__olang_sb_put(ptr %s14, ptr %t382, i64 %t383)
  %t384 = load ptr, ptr %s14
  %t385 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t386 = load i64, ptr %t385
  %t387 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t386)
  call void @llvm.memcpy.p0.p0.i64(ptr %t387, ptr %t384, i64 %t386, i1 false)
  %t388 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t387, 1
  store { i64, ptr } %t389, ptr %l149
  call void @__olang_sb_done(ptr %s14)
  %t390 = load { i64, ptr }, ptr %l149
  %t391 = extractvalue { i64, ptr } %t390, 0
  %t392 = extractvalue { i64, ptr } %t390, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  store { i64, ptr } %t396, ptr %l150
  %t397 = load { i64, ptr }, ptr %l150
  %t398 = load ptr, ptr %lp6
  %t399 = getelementptr %"compiler/target:Target", ptr %t398, i32 0, i32 2
  store { i64, ptr } %t397, ptr %t399
  %t400 = load i64, ptr %l10
  store i64 %t400, ptr %l151
  %t401 = load i64, ptr %l151
  %t402 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchs, i32 0, i32 1
  %t403 = load ptr, ptr %t402
  %t404 = getelementptr { i64, ptr }, ptr %t403, i64 %t401
  %t405 = load { i64, ptr }, ptr %t404
  store { i64, ptr } %t405, ptr %l152
  %t406 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t406, ptr %l153
  %t407 = load ptr, ptr @__olang_prog_scope
  %t408 = load { i64, ptr }, ptr %l152
  %t409 = load { i64, ptr }, ptr %l153
  %t410 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t407, ptr %v3, { i64, ptr } %t408, { i64, ptr } %t409)
  store i1 %t410, ptr %l154
  br label %bb103
bb103:
  %t411 = load i1, ptr %l154
  %t412 = xor i1 %t411, true
  store i1 %t412, ptr %l155
  %t413 = load i1, ptr %l155
  br i1 %t413, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l156
  br label %bb107
bb105:
  %t414 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t414, ptr %l157
  %t415 = load { i64, ptr }, ptr %l157
  %t416 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t415, { i64, ptr } { i64 5, ptr @.d40 })
  store i1 %t416, ptr %l158
  br label %bb106
bb106:
  %t417 = load i1, ptr %l158
  %t418 = xor i1 %t417, true
  store i1 %t418, ptr %l159
  %t419 = load i1, ptr %l159
  store i1 %t419, ptr %l156
  br label %bb107
bb107:
  %t420 = load i1, ptr %l156
  %t421 = load ptr, ptr %lp6
  %t422 = getelementptr %"compiler/target:Target", ptr %t421, i32 0, i32 9
  store i1 %t420, ptr %t422
  %t423 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t423, ptr %l160
  %t424 = load { i64, ptr }, ptr %l160
  %t425 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t424, { i64, ptr } { i64 0, ptr @.d41 })
  store i1 %t425, ptr %l161
  br label %bb108
bb108:
  %t426 = load i1, ptr %l161
  %t427 = xor i1 %t426, true
  store i1 %t427, ptr %l162
  %t428 = load i1, ptr %l162
  br i1 %t428, label %bb109, label %bb110
bb109:
  %t429 = load ptr, ptr %lp6
  %t430 = getelementptr %"compiler/target:Target", ptr %t429, i32 0, i32 9
  %t431 = load i1, ptr %t430
  store i1 %t431, ptr %l164
  %t432 = load i1, ptr %l164
  %t433 = xor i1 %t432, true
  store i1 %t433, ptr %l165
  %t434 = load i1, ptr %l165
  store i1 %t434, ptr %l163
  br label %bb111
bb110:
  store i1 false, ptr %l163
  br label %bb111
bb111:
  %t435 = load i1, ptr %l163
  br i1 %t435, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s15
  store { i64, ptr } { i64 0, ptr @.d42 }, ptr %l7
  %t436 = load i1, ptr %l9
  store i1 %t436, ptr %l166
  %t437 = load i1, ptr %l166
  %t438 = xor i1 %t437, true
  store i1 %t438, ptr %l167
  %t439 = load i1, ptr %l167
  br i1 %t439, label %bb114, label %bb115
bb113:
  br label %bb117
bb114:
  store %olang.scope zeroinitializer, ptr %s16
  %t440 = load i64, ptr %l10
  store i64 %t440, ptr %l168
  %t441 = load i64, ptr %l168
  %t442 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchDefaultCpus, i32 0, i32 1
  %t443 = load ptr, ptr %t442
  %t444 = getelementptr { i64, ptr }, ptr %t443, i64 %t441
  %t445 = load { i64, ptr }, ptr %t444
  store { i64, ptr } %t445, ptr %l169
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s17
  store ptr %s17room, ptr %s17
  %t446 = load { i64, ptr }, ptr %l169
  %t447 = extractvalue { i64, ptr } %t446, 1
  %t448 = extractvalue { i64, ptr } %t446, 0
  call void @__olang_sb_put(ptr %s17, ptr %t447, i64 %t448)
  %t449 = load ptr, ptr %s17
  %t450 = getelementptr %olang.builder, ptr %s17, i32 0, i32 1
  %t451 = load i64, ptr %t450
  %t452 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t451)
  call void @llvm.memcpy.p0.p0.i64(ptr %t452, ptr %t449, i64 %t451, i1 false)
  %t453 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t452, 1
  store { i64, ptr } %t454, ptr %l170
  call void @__olang_sb_done(ptr %s17)
  %t455 = load { i64, ptr }, ptr %l170
  %t456 = extractvalue { i64, ptr } %t455, 0
  %t457 = extractvalue { i64, ptr } %t455, 1
  %t458 = mul i64 %t456, 1
  %t459 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t458)
  call void @llvm.memcpy.p0.p0.i64(ptr %t459, ptr %t457, i64 %t458, i1 false)
  %t460 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t459, 1
  store { i64, ptr } %t461, ptr %l171
  %t462 = load { i64, ptr }, ptr %l171
  store { i64, ptr } %t462, ptr %l8
  store i1 true, ptr %l9
  call void @__olang_scope_close(ptr %s16)
  br label %bb116
bb115:
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s15)
  br label %bb117
bb117:
  %t463 = load i1, ptr %l9
  store i1 %t463, ptr %l172
  %t464 = load i1, ptr %l172
  br i1 %t464, label %bb118, label %bb119
bb118:
  %t465 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t465, ptr %l174
  %t466 = load { i64, ptr }, ptr %l174
  %t467 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t466, { i64, ptr } { i64 6, ptr @.d43 })
  store i1 %t467, ptr %l175
  br label %bb120
bb119:
  store i1 false, ptr %l173
  br label %bb121
bb120:
  %t468 = load i1, ptr %l175
  store i1 %t468, ptr %l173
  br label %bb121
bb121:
  %t469 = load i1, ptr %l173
  br i1 %t469, label %bb122, label %bb123
bb122:
  %t470 = load ptr, ptr %lp6
  %t471 = getelementptr %"compiler/target:Target", ptr %t470, i32 0, i32 9
  %t472 = load i1, ptr %t471
  store i1 %t472, ptr %l177
  %t473 = load i1, ptr %l177
  store i1 %t473, ptr %l176
  br label %bb124
bb123:
  store i1 false, ptr %l176
  br label %bb124
bb124:
  %t474 = load i1, ptr %l176
  br i1 %t474, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s18
  %t475 = load ptr, ptr %l5
  store ptr %t475, ptr %l178
  %t476 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t476, ptr %l179
  %t477 = load { i64, ptr }, ptr %l179
  %t478 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNativeForeign(ptr %v0, ptr %s18, { i64, ptr } %t477)
  store %"compiler/msgs:Msg" %t478, ptr %l180
  br label %bb127
bb126:
  br label %bb131
bb127:
  %t479 = load ptr, ptr %l178
  %t480 = load %"compiler/msgs:Msg", ptr %l180
  %t481 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s18, ptr %t479, %"compiler/msgs:Msg" %t480)
  store i32 %t481, ptr %l181
  %t482 = icmp ne i32 %t481, 0
  br i1 %t482, label %bb129, label %ok.483
ok.483:
  br label %bb128
bb128:
  br label %bb130
bb129:
  %t484 = load i32, ptr %l181
  %t485 = lshr i32 %t484, 16
  %t486 = and i32 %t484, 65535
  %t487 = icmp eq i32 %t485, 1
  %t488 = select i1 %t487, i32 1, i32 0
  %t489 = icmp eq i32 %t484, 0
  %t490 = shl i32 %t488, 16
  %t491 = or i32 %t490, %t486
  %t492 = select i1 %t489, i32 0, i32 %t491
  store i32 %t492, ptr %l182
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t493 = load i32, ptr %l182
  %t494 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t493, 0
  store { i32, %"compiler/target:Target" } %t494, ptr %rv
  br label %ret
bb130:
  call void @__olang_scope_close(ptr %s18)
  br label %bb131
bb131:
  %t495 = load ptr, ptr %lp6
  %t496 = getelementptr %"compiler/target:Target", ptr %t495, i32 0, i32 9
  %t497 = load i1, ptr %t496
  store i1 %t497, ptr %l183
  %t498 = load i1, ptr %l183
  br i1 %t498, label %bb132, label %bb133
bb132:
  %t499 = load i1, ptr %l2
  store i1 %t499, ptr %l185
  %t500 = load i1, ptr %l185
  store i1 %t500, ptr %l184
  br label %bb134
bb133:
  store i1 false, ptr %l184
  br label %bb134
bb134:
  %t501 = load i1, ptr %l184
  br i1 %t501, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s19
  %t502 = load ptr, ptr %l5
  store ptr %t502, ptr %l186
  %t503 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t503, ptr %l187
  %t504 = load { i64, ptr }, ptr %l187
  %t505 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %s19, ptr %v0, ptr %s19, { i64, ptr } { i64 9, ptr @.d44 }, { i64, ptr } %t504)
  store %"compiler/msgs:Msg" %t505, ptr %l188
  br label %bb137
bb136:
  br label %bb141
bb137:
  %t506 = load ptr, ptr %l186
  %t507 = load %"compiler/msgs:Msg", ptr %l188
  %t508 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s19, ptr %t506, %"compiler/msgs:Msg" %t507)
  store i32 %t508, ptr %l189
  %t509 = icmp ne i32 %t508, 0
  br i1 %t509, label %bb139, label %ok.510
ok.510:
  br label %bb138
bb138:
  br label %bb140
bb139:
  %t511 = load i32, ptr %l189
  %t512 = lshr i32 %t511, 16
  %t513 = and i32 %t511, 65535
  %t514 = icmp eq i32 %t512, 1
  %t515 = select i1 %t514, i32 1, i32 0
  %t516 = icmp eq i32 %t511, 0
  %t517 = shl i32 %t515, 16
  %t518 = or i32 %t517, %t513
  %t519 = select i1 %t516, i32 0, i32 %t518
  store i32 %t519, ptr %l190
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t520 = load i32, ptr %l190
  %t521 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t520, 0
  store { i32, %"compiler/target:Target" } %t521, ptr %rv
  br label %ret
bb140:
  call void @__olang_scope_close(ptr %s19)
  br label %bb141
bb141:
  %t522 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t522, ptr %l191
  %t523 = load { i64, ptr }, ptr %l191
  %t524 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t523, { i64, ptr } { i64 0, ptr @.d45 })
  store i1 %t524, ptr %l192
  br label %bb142
bb142:
  %t525 = load i1, ptr %l192
  br i1 %t525, label %bb143, label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s20
  %t526 = load i1, ptr %l2
  store i1 %t526, ptr %l193
  %t527 = load i1, ptr %l193
  %t528 = xor i1 %t527, true
  store i1 %t528, ptr %l194
  %t529 = load i1, ptr %l194
  br i1 %t529, label %bb145, label %bb146
bb144:
  br label %bb157
bb145:
  store i1 true, ptr %l195
  br label %bb149
bb146:
  %t530 = load ptr, ptr %lp6
  store ptr %t530, ptr %l196
  %t531 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t531, ptr %l197
  %t532 = call { i64, ptr } @compiler_2ftarget_2ecpuFlags(ptr %s20)
  store { i64, ptr } %t532, ptr %l198
  br label %bb147
bb147:
  %t533 = load { i64, ptr }, ptr %l198
  %t534 = extractvalue { i64, ptr } %t533, 0
  %t535 = extractvalue { i64, ptr } %t533, 1
  %t536 = mul i64 %t534, 1
  %t537 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t536)
  call void @llvm.memcpy.p0.p0.i64(ptr %t537, ptr %t535, i64 %t536, i1 false)
  %t538 = insertvalue { i64, ptr } undef, i64 %t534, 0
  %t539 = insertvalue { i64, ptr } %t538, ptr %t537, 1
  store { i64, ptr } %t539, ptr %l199
  %t540 = load ptr, ptr %l196
  %t541 = load { i64, ptr }, ptr %l197
  %t542 = load { i64, ptr }, ptr %l199
  %t543 = call i1 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2ewithoutClang(ptr %v5, ptr %s0, ptr %s20, ptr %t540, { i64, ptr } %t541, { i64, ptr } %t542)
  store i1 %t543, ptr %l200
  br label %bb148
bb148:
  %t544 = load i1, ptr %l200
  %t545 = xor i1 %t544, true
  store i1 %t545, ptr %l201
  %t546 = load i1, ptr %l201
  store i1 %t546, ptr %l195
  br label %bb149
bb149:
  %t547 = load i1, ptr %l195
  br i1 %t547, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s21
  %t548 = load ptr, ptr %l5
  store ptr %t548, ptr %l202
  %t549 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t549, ptr %l203
  %t550 = load { i64, ptr }, ptr %l203
  %t551 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoClang(ptr %v0, ptr %s21, { i64, ptr } %t550)
  store %"compiler/msgs:Msg" %t551, ptr %l204
  br label %bb152
bb151:
  br label %bb156
bb152:
  %t552 = load ptr, ptr %l202
  %t553 = load %"compiler/msgs:Msg", ptr %l204
  %t554 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s21, ptr %t552, %"compiler/msgs:Msg" %t553)
  store i32 %t554, ptr %l205
  %t555 = icmp ne i32 %t554, 0
  br i1 %t555, label %bb154, label %ok.556
ok.556:
  br label %bb153
bb153:
  br label %bb155
bb154:
  %t557 = load i32, ptr %l205
  %t558 = lshr i32 %t557, 16
  %t559 = and i32 %t557, 65535
  %t560 = icmp eq i32 %t558, 1
  %t561 = select i1 %t560, i32 1, i32 0
  %t562 = icmp eq i32 %t557, 0
  %t563 = shl i32 %t561, 16
  %t564 = or i32 %t563, %t559
  %t565 = select i1 %t562, i32 0, i32 %t564
  store i32 %t565, ptr %l206
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  %t566 = load i32, ptr %l206
  %t567 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t566, 0
  store { i32, %"compiler/target:Target" } %t567, ptr %rv
  br label %ret
bb155:
  call void @__olang_scope_close(ptr %s21)
  br label %bb156
bb156:
  %t568 = load ptr, ptr %lp6
  %t569 = load %"compiler/target:Target", ptr %t568
  store %"compiler/target:Target" %t569, ptr %l207
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  %t570 = load %"compiler/target:Target", ptr %l207
  %t571 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, %"compiler/target:Target" %t570, 1
  store { i32, %"compiler/target:Target" } %t571, ptr %rv
  br label %ret
bb157:
  %t572 = load ptr, ptr @__olang_prog_scope
  %t573 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t572)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t573, ptr %l208
  br label %bb158
bb158:
  %t574 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l208
  store %"std/prelude/list:List<std/prelude/text:String&>" %t574, ptr %l13
  store ptr %l13, ptr %l209
  %t575 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t575, ptr %l210
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s22
  store ptr %s22room, ptr %s22
  %t576 = load { i64, ptr }, ptr %l210
  %t577 = extractvalue { i64, ptr } %t576, 1
  %t578 = extractvalue { i64, ptr } %t576, 0
  call void @__olang_sb_put(ptr %s22, ptr %t577, i64 %t578)
  %t579 = load ptr, ptr %s22
  %t580 = getelementptr %olang.builder, ptr %s22, i32 0, i32 1
  %t581 = load i64, ptr %t580
  %t582 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t581)
  call void @llvm.memcpy.p0.p0.i64(ptr %t582, ptr %t579, i64 %t581, i1 false)
  %t583 = insertvalue { i64, ptr } undef, i64 %t581, 0
  %t584 = insertvalue { i64, ptr } %t583, ptr %t582, 1
  store { i64, ptr } %t584, ptr %l211
  call void @__olang_sb_done(ptr %s22)
  %t585 = load { i64, ptr }, ptr %l211
  %t586 = extractvalue { i64, ptr } %t585, 0
  %t587 = extractvalue { i64, ptr } %t585, 1
  %t588 = mul i64 %t586, 1
  %t589 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t588)
  call void @llvm.memcpy.p0.p0.i64(ptr %t589, ptr %t587, i64 %t588, i1 false)
  %t590 = insertvalue { i64, ptr } undef, i64 %t586, 0
  %t591 = insertvalue { i64, ptr } %t590, ptr %t589, 1
  store { i64, ptr } %t591, ptr %l212
  %t592 = load ptr, ptr %l209
  %t593 = load { i64, ptr }, ptr %l212
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t592, { i64, ptr } %t593)
  br label %bb159
bb159:
  %t594 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t594, ptr %l213
  %t595 = load { i64, ptr }, ptr %l213
  %t596 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t595, { i64, ptr } { i64 0, ptr @.d46 })
  store i1 %t596, ptr %l214
  br label %bb160
bb160:
  %t597 = load i1, ptr %l214
  %t598 = xor i1 %t597, true
  store i1 %t598, ptr %l215
  %t599 = load i1, ptr %l215
  br i1 %t599, label %bb161, label %bb162
bb161:
  store %olang.scope zeroinitializer, ptr %s23
  store ptr %l13, ptr %l216
  %t600 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t600, ptr %l217
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  %t601 = extractvalue { i64, ptr } { i64 9, ptr @.d47 }, 1
  %t602 = extractvalue { i64, ptr } { i64 9, ptr @.d47 }, 0
  call void @__olang_sb_put(ptr %s24, ptr %t601, i64 %t602)
  %t603 = load { i64, ptr }, ptr %l217
  %t604 = extractvalue { i64, ptr } %t603, 1
  %t605 = extractvalue { i64, ptr } %t603, 0
  call void @__olang_sb_put(ptr %s24, ptr %t604, i64 %t605)
  %t606 = load ptr, ptr %s24
  %t607 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t608 = load i64, ptr %t607
  %t609 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t608)
  call void @llvm.memcpy.p0.p0.i64(ptr %t609, ptr %t606, i64 %t608, i1 false)
  %t610 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t611 = insertvalue { i64, ptr } %t610, ptr %t609, 1
  store { i64, ptr } %t611, ptr %l218
  call void @__olang_sb_done(ptr %s24)
  %t612 = load { i64, ptr }, ptr %l218
  %t613 = extractvalue { i64, ptr } %t612, 0
  %t614 = extractvalue { i64, ptr } %t612, 1
  %t615 = mul i64 %t613, 1
  %t616 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t615)
  call void @llvm.memcpy.p0.p0.i64(ptr %t616, ptr %t614, i64 %t615, i1 false)
  %t617 = insertvalue { i64, ptr } undef, i64 %t613, 0
  %t618 = insertvalue { i64, ptr } %t617, ptr %t616, 1
  store { i64, ptr } %t618, ptr %l219
  %t619 = load ptr, ptr %l216
  %t620 = load { i64, ptr }, ptr %l219
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t619, { i64, ptr } %t620)
  br label %bb163
bb162:
  br label %bb164
bb163:
  call void @__olang_scope_close(ptr %s23)
  br label %bb164
bb164:
  %t621 = load i1, ptr %l9
  store i1 %t621, ptr %l220
  %t622 = load i1, ptr %l220
  br i1 %t622, label %bb165, label %bb166
bb165:
  store %olang.scope zeroinitializer, ptr %s25
  store ptr %l13, ptr %l221
  %t623 = load i64, ptr %l10
  store i64 %t623, ptr %l222
  %t624 = load i64, ptr %l222
  %t625 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchCpuFlags, i32 0, i32 1
  %t626 = load ptr, ptr %t625
  %t627 = getelementptr { i64, ptr }, ptr %t626, i64 %t624
  %t628 = load { i64, ptr }, ptr %t627
  store { i64, ptr } %t628, ptr %l223
  %t629 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t629, ptr %l224
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s26
  store ptr %s26room, ptr %s26
  %t630 = load { i64, ptr }, ptr %l223
  %t631 = extractvalue { i64, ptr } %t630, 1
  %t632 = extractvalue { i64, ptr } %t630, 0
  call void @__olang_sb_put(ptr %s26, ptr %t631, i64 %t632)
  %t633 = load { i64, ptr }, ptr %l224
  %t634 = extractvalue { i64, ptr } %t633, 1
  %t635 = extractvalue { i64, ptr } %t633, 0
  call void @__olang_sb_put(ptr %s26, ptr %t634, i64 %t635)
  %t636 = load ptr, ptr %s26
  %t637 = getelementptr %olang.builder, ptr %s26, i32 0, i32 1
  %t638 = load i64, ptr %t637
  %t639 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t638)
  call void @llvm.memcpy.p0.p0.i64(ptr %t639, ptr %t636, i64 %t638, i1 false)
  %t640 = insertvalue { i64, ptr } undef, i64 %t638, 0
  %t641 = insertvalue { i64, ptr } %t640, ptr %t639, 1
  store { i64, ptr } %t641, ptr %l225
  call void @__olang_sb_done(ptr %s26)
  %t642 = load { i64, ptr }, ptr %l225
  %t643 = extractvalue { i64, ptr } %t642, 0
  %t644 = extractvalue { i64, ptr } %t642, 1
  %t645 = mul i64 %t643, 1
  %t646 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t645)
  call void @llvm.memcpy.p0.p0.i64(ptr %t646, ptr %t644, i64 %t645, i1 false)
  %t647 = insertvalue { i64, ptr } undef, i64 %t643, 0
  %t648 = insertvalue { i64, ptr } %t647, ptr %t646, 1
  store { i64, ptr } %t648, ptr %l226
  %t649 = load ptr, ptr %l221
  %t650 = load { i64, ptr }, ptr %l226
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t649, { i64, ptr } %t650)
  br label %bb167
bb166:
  br label %bb168
bb167:
  call void @__olang_scope_close(ptr %s25)
  br label %bb168
bb168:
  store %olang.scope zeroinitializer, ptr %s27
  %t651 = insertvalue [7 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr @.d48 }, 0
  %t652 = insertvalue [7 x { i64, ptr }] %t651, { i64, ptr } { i64 10, ptr @.d49 }, 1
  %t653 = insertvalue [7 x { i64, ptr }] %t652, { i64, ptr } { i64 2, ptr @.d50 }, 2
  %t654 = insertvalue [7 x { i64, ptr }] %t653, { i64, ptr } { i64 1, ptr @.d51 }, 3
  %t655 = insertvalue [7 x { i64, ptr }] %t654, { i64, ptr } { i64 2, ptr @.d52 }, 4
  %t656 = insertvalue [7 x { i64, ptr }] %t655, { i64, ptr } { i64 1, ptr @.d53 }, 5
  %t657 = insertvalue [7 x { i64, ptr }] %t656, { i64, ptr } { i64 1, ptr @.d54 }, 6
  store [7 x { i64, ptr }] %t657, ptr %l227
  %t658 = load [7 x { i64, ptr }], ptr %l227
  %t659 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 112, i64 8)
  store [7 x { i64, ptr }] %t658, ptr %t659
  store ptr %t659, ptr %l228
  %t660 = load ptr, ptr %l228
  store ptr %t660, ptr %l14
  store i64 0, ptr %l15
  %t661 = load ptr, ptr %l14
  store ptr %t661, ptr %l229
  %t662 = load ptr, ptr %l229
  store i64 7, ptr %l230
  %t663 = load i64, ptr %l230
  store i64 %t663, ptr %l16
  br label %bb169
bb169:
  store %olang.scope zeroinitializer, ptr %s28
  %t664 = load i64, ptr %l15
  store i64 %t664, ptr %l231
  %t665 = load i64, ptr %l16
  store i64 %t665, ptr %l232
  %t666 = load i64, ptr %l231
  %t667 = load i64, ptr %l232
  %t668 = icmp slt i64 %t666, %t667
  store i1 %t668, ptr %l233
  %t669 = load i1, ptr %l233
  %t670 = xor i1 %t669, true
  store i1 %t670, ptr %l234
  %t671 = load i1, ptr %l234
  br i1 %t671, label %bb170, label %bb171
bb170:
  call void @__olang_scope_close(ptr %s28)
  br label %bb175
bb171:
  br label %bb172
bb172:
  %t672 = load ptr, ptr %l14
  store ptr %t672, ptr %l235
  %t673 = load i64, ptr %l15
  store i64 %t673, ptr %l236
  %t674 = load ptr, ptr %l235
  %t675 = load i64, ptr %l236
  %t676 = getelementptr [7 x { i64, ptr }], ptr %t674, i64 0, i64 %t675
  %t677 = load { i64, ptr }, ptr %t676
  store { i64, ptr } %t677, ptr %l237
  %t678 = load { i64, ptr }, ptr %l237
  store { i64, ptr } %t678, ptr %l17
  store ptr %l13, ptr %l238
  %t679 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t679, ptr %l239
  %t680 = load ptr, ptr @__olang_prog_scope
  %t681 = load ptr, ptr %l238
  %t682 = load { i64, ptr }, ptr %l239
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %t680, ptr %t681, { i64, ptr } %t682)
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s28)
  br label %bb174
bb174:
  store %olang.scope zeroinitializer, ptr %s29
  %t683 = load i64, ptr %l15
  store i64 %t683, ptr %l240
  %t684 = load i64, ptr %l240
  %t685 = add i64 %t684, 1
  store i64 %t685, ptr %l241
  %t686 = load i64, ptr %l241
  store i64 %t686, ptr %l15
  call void @__olang_scope_close(ptr %s29)
  br label %bb169
bb175:
  call void @__olang_scope_close(ptr %s27)
  store ptr %l13, ptr %l243
  %t687 = load ptr, ptr %l243
  %t688 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %s0, ptr %s0, ptr %t687)
  store { i64, ptr } %t688, ptr %l244
  br label %bb176
bb176:
  store { i64, ptr } { i64 34, ptr @.d55 }, ptr %l245
  %t689 = load { i64, ptr }, ptr %l244
  %t690 = load { i64, ptr }, ptr %l245
  %t691 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t689, { i64, ptr } %t690, i1 true, { i64, ptr } { i64 0, ptr @.d56 })
  %t692 = extractvalue { i32, %"std/os:Output" } %t691, 1
  %t693 = extractvalue { i32, %"std/os:Output" } %t691, 0
  store i32 %t693, ptr %l247
  %t694 = icmp ne i32 %t693, 0
  br i1 %t694, label %bb178, label %ok.695
ok.695:
  store %"std/os:Output" %t692, ptr %l246
  br label %bb177
bb177:
  %t696 = load %"std/os:Output", ptr %l246
  store %"std/os:Output" %t696, ptr %l242
  br label %bb186
bb178:
  %t697 = load i32, ptr %l247
  %t698 = ashr i32 %t697, 16
  store i32 %t698, ptr %l248
  %t699 = load i32, ptr %l248
  %t700 = icmp eq i32 %t699, 1
  store i1 %t700, ptr %l249
  %t701 = load i1, ptr %l249
  br i1 %t701, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  %t702 = load i32, ptr %l247
  %t703 = lshr i32 %t702, 16
  %t704 = and i32 %t702, 65535
  %t705 = icmp eq i32 %t703, 1
  %t706 = select i1 %t705, i32 0, i32 0
  %t707 = icmp eq i32 %t702, 0
  %t708 = shl i32 %t706, 16
  %t709 = or i32 %t708, %t704
  %t710 = select i1 %t707, i32 0, i32 %t709
  store i32 %t710, ptr %l250
  call void @__olang_scope_close(ptr %s0)
  %t711 = load i32, ptr %l250
  %t712 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t711, 0
  store { i32, %"compiler/target:Target" } %t712, ptr %rv
  br label %ret
bb181:
  store %olang.scope zeroinitializer, ptr %s30
  %t713 = load ptr, ptr %l5
  store ptr %t713, ptr %l251
  %t714 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t714, ptr %l252
  %t715 = load { i64, ptr }, ptr %l252
  %t716 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %s30, { i64, ptr } %t715)
  store %"compiler/msgs:Msg" %t716, ptr %l253
  br label %bb182
bb182:
  %t717 = load ptr, ptr %l251
  %t718 = load %"compiler/msgs:Msg", ptr %l253
  %t719 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s30, ptr %t717, %"compiler/msgs:Msg" %t718)
  store i32 %t719, ptr %l254
  %t720 = icmp ne i32 %t719, 0
  br i1 %t720, label %bb184, label %ok.721
ok.721:
  br label %bb183
bb183:
  br label %bb185
bb184:
  %t722 = load i32, ptr %l254
  %t723 = lshr i32 %t722, 16
  %t724 = and i32 %t722, 65535
  %t725 = icmp eq i32 %t723, 1
  %t726 = select i1 %t725, i32 1, i32 0
  %t727 = icmp eq i32 %t722, 0
  %t728 = shl i32 %t726, 16
  %t729 = or i32 %t728, %t724
  %t730 = select i1 %t727, i32 0, i32 %t729
  store i32 %t730, ptr %l255
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  %t731 = load i32, ptr %l255
  %t732 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t731, 0
  store { i32, %"compiler/target:Target" } %t732, ptr %rv
  br label %ret
bb185:
  call void @__olang_check_failed(ptr @.c57)
  unreachable
bb186:
  %t733 = load %"std/os:Output", ptr %l242
  store %"std/os:Output" %t733, ptr %l18
  %t734 = getelementptr %"std/os:Output", ptr %l18, i32 0, i32 0
  %t735 = load i32, ptr %t734
  store i32 %t735, ptr %l256
  %t736 = load i32, ptr %l256
  %t737 = icmp ne i32 %t736, 0
  store i1 %t737, ptr %l257
  %t738 = load i1, ptr %l257
  br i1 %t738, label %bb187, label %bb188
bb187:
  store %olang.scope zeroinitializer, ptr %s31
  %t739 = load ptr, ptr %l5
  store ptr %t739, ptr %l258
  %t740 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t740, ptr %l259
  %t741 = load { i64, ptr }, ptr %l259
  %t742 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %s31, { i64, ptr } %t741)
  store %"compiler/msgs:Msg" %t742, ptr %l260
  br label %bb189
bb188:
  br label %bb193
bb189:
  %t743 = load ptr, ptr %l258
  %t744 = load %"compiler/msgs:Msg", ptr %l260
  %t745 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s31, ptr %t743, %"compiler/msgs:Msg" %t744)
  store i32 %t745, ptr %l261
  %t746 = icmp ne i32 %t745, 0
  br i1 %t746, label %bb191, label %ok.747
ok.747:
  br label %bb190
bb190:
  br label %bb192
bb191:
  %t748 = load i32, ptr %l261
  %t749 = lshr i32 %t748, 16
  %t750 = and i32 %t748, 65535
  %t751 = icmp eq i32 %t749, 1
  %t752 = select i1 %t751, i32 1, i32 0
  %t753 = icmp eq i32 %t748, 0
  %t754 = shl i32 %t752, 16
  %t755 = or i32 %t754, %t750
  %t756 = select i1 %t753, i32 0, i32 %t755
  store i32 %t756, ptr %l262
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s0)
  %t757 = load i32, ptr %l262
  %t758 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t757, 0
  store { i32, %"compiler/target:Target" } %t758, ptr %rv
  br label %ret
bb192:
  call void @__olang_scope_close(ptr %s31)
  br label %bb193
bb193:
  %t759 = load ptr, ptr %lp6
  store ptr %t759, ptr %l263
  %t760 = getelementptr %"std/os:Output", ptr %l18, i32 0, i32 1
  %t761 = load { i64, ptr }, ptr %t760
  store { i64, ptr } %t761, ptr %l264
  %t762 = load ptr, ptr %l263
  %t763 = load { i64, ptr }, ptr %l264
  %t764 = call i32 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eFromProbe(ptr %v5, ptr %s0, ptr %t762, { i64, ptr } %t763)
  store i32 %t764, ptr %l265
  %t765 = icmp ne i32 %t764, 0
  br i1 %t765, label %bb195, label %ok.766
ok.766:
  br label %bb194
bb194:
  br label %bb210
bb195:
  %t767 = load i32, ptr %l265
  %t768 = icmp eq i32 %t767, 65536
  store i1 %t768, ptr %l266
  %t769 = load i1, ptr %l266
  br i1 %t769, label %bb196, label %bb197
bb196:
  br label %bb198
bb197:
  %t770 = load i32, ptr %l265
  %t771 = icmp eq i32 %t770, 65537
  store i1 %t771, ptr %l267
  %t772 = load i1, ptr %l267
  br i1 %t772, label %bb199, label %bb200
bb198:
  store %olang.scope zeroinitializer, ptr %s32
  %t773 = load ptr, ptr %l5
  store ptr %t773, ptr %l269
  %t774 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t774, ptr %l270
  %t775 = load { i64, ptr }, ptr %l270
  %t776 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %s32, { i64, ptr } %t775)
  store %"compiler/msgs:Msg" %t776, ptr %l271
  br label %bb202
bb199:
  br label %bb201
bb200:
  %t777 = load i32, ptr %l265
  %t778 = lshr i32 %t777, 16
  %t779 = and i32 %t777, 65535
  %t780 = icmp eq i32 %t778, 1
  %t781 = select i1 %t780, i32 0, i32 0
  %t782 = icmp eq i32 %t777, 0
  %t783 = shl i32 %t781, 16
  %t784 = or i32 %t783, %t779
  %t785 = select i1 %t782, i32 0, i32 %t784
  store i32 %t785, ptr %l268
  call void @__olang_scope_close(ptr %s0)
  %t786 = load i32, ptr %l268
  %t787 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t786, 0
  store { i32, %"compiler/target:Target" } %t787, ptr %rv
  br label %ret
bb201:
  store %olang.scope zeroinitializer, ptr %s33
  %t788 = load ptr, ptr %l5
  store ptr %t788, ptr %l274
  %t789 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t789, ptr %l275
  %t790 = load { i64, ptr }, ptr %l275
  %t791 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %s33, { i64, ptr } %t790)
  store %"compiler/msgs:Msg" %t791, ptr %l276
  br label %bb206
bb202:
  %t792 = load ptr, ptr %l269
  %t793 = load %"compiler/msgs:Msg", ptr %l271
  %t794 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s32, ptr %t792, %"compiler/msgs:Msg" %t793)
  store i32 %t794, ptr %l272
  %t795 = icmp ne i32 %t794, 0
  br i1 %t795, label %bb204, label %ok.796
ok.796:
  br label %bb203
bb203:
  br label %bb205
bb204:
  %t797 = load i32, ptr %l272
  %t798 = lshr i32 %t797, 16
  %t799 = and i32 %t797, 65535
  %t800 = icmp eq i32 %t798, 1
  %t801 = select i1 %t800, i32 1, i32 0
  %t802 = icmp eq i32 %t797, 0
  %t803 = shl i32 %t801, 16
  %t804 = or i32 %t803, %t799
  %t805 = select i1 %t802, i32 0, i32 %t804
  store i32 %t805, ptr %l273
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s0)
  %t806 = load i32, ptr %l273
  %t807 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t806, 0
  store { i32, %"compiler/target:Target" } %t807, ptr %rv
  br label %ret
bb205:
  call void @__olang_scope_close(ptr %s32)
  br label %bb210
bb206:
  %t808 = load ptr, ptr %l274
  %t809 = load %"compiler/msgs:Msg", ptr %l276
  %t810 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s33, ptr %t808, %"compiler/msgs:Msg" %t809)
  store i32 %t810, ptr %l277
  %t811 = icmp ne i32 %t810, 0
  br i1 %t811, label %bb208, label %ok.812
ok.812:
  br label %bb207
bb207:
  br label %bb209
bb208:
  %t813 = load i32, ptr %l277
  %t814 = lshr i32 %t813, 16
  %t815 = and i32 %t813, 65535
  %t816 = icmp eq i32 %t814, 1
  %t817 = select i1 %t816, i32 1, i32 0
  %t818 = icmp eq i32 %t813, 0
  %t819 = shl i32 %t817, 16
  %t820 = or i32 %t819, %t815
  %t821 = select i1 %t818, i32 0, i32 %t820
  store i32 %t821, ptr %l278
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s0)
  %t822 = load i32, ptr %l278
  %t823 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t822, 0
  store { i32, %"compiler/target:Target" } %t823, ptr %rv
  br label %ret
bb209:
  call void @__olang_scope_close(ptr %s33)
  br label %bb210
bb210:
  %t824 = load ptr, ptr %lp6
  %t825 = getelementptr %"compiler/target:Target", ptr %t824, i32 0, i32 9
  %t826 = load i1, ptr %t825
  store i1 %t826, ptr %l279
  %t827 = load i1, ptr %l279
  br i1 %t827, label %bb211, label %bb212
bb211:
  %t828 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t828, ptr %l281
  %t829 = load ptr, ptr %lp6
  %t830 = getelementptr %"compiler/target:Target", ptr %t829, i32 0, i32 1
  %t831 = load { i64, ptr }, ptr %t830
  store { i64, ptr } %t831, ptr %l282
  %t832 = load { i64, ptr }, ptr %l281
  %t833 = load { i64, ptr }, ptr %l282
  %t834 = call i1 @compiler_2ftarget_2ecanCompileBf16(ptr %v1, ptr %v5, { i64, ptr } %t832, { i64, ptr } %t833)
  store i1 %t834, ptr %l283
  br label %bb213
bb212:
  store i1 false, ptr %l280
  br label %bb214
bb213:
  %t835 = load i1, ptr %l283
  %t836 = xor i1 %t835, true
  store i1 %t836, ptr %l284
  %t837 = load i1, ptr %l284
  store i1 %t837, ptr %l280
  br label %bb214
bb214:
  %t838 = load i1, ptr %l280
  br i1 %t838, label %bb215, label %bb216
bb215:
  store %olang.scope zeroinitializer, ptr %s34
  %t839 = load ptr, ptr %l5
  store ptr %t839, ptr %l285
  %t840 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t840, ptr %l286
  %t841 = load { i64, ptr }, ptr %l286
  %t842 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoBackend(ptr %v0, ptr %s34, { i64, ptr } %t841)
  store %"compiler/msgs:Msg" %t842, ptr %l287
  br label %bb217
bb216:
  br label %bb221
bb217:
  %t843 = load ptr, ptr %l285
  %t844 = load %"compiler/msgs:Msg", ptr %l287
  %t845 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %s34, ptr %t843, %"compiler/msgs:Msg" %t844)
  store i32 %t845, ptr %l288
  %t846 = icmp ne i32 %t845, 0
  br i1 %t846, label %bb219, label %ok.847
ok.847:
  br label %bb218
bb218:
  br label %bb220
bb219:
  %t848 = load i32, ptr %l288
  %t849 = lshr i32 %t848, 16
  %t850 = and i32 %t848, 65535
  %t851 = icmp eq i32 %t849, 1
  %t852 = select i1 %t851, i32 1, i32 0
  %t853 = icmp eq i32 %t848, 0
  %t854 = shl i32 %t852, 16
  %t855 = or i32 %t854, %t850
  %t856 = select i1 %t853, i32 0, i32 %t855
  store i32 %t856, ptr %l289
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  %t857 = load i32, ptr %l289
  %t858 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, i32 %t857, 0
  store { i32, %"compiler/target:Target" } %t858, ptr %rv
  br label %ret
bb220:
  call void @__olang_scope_close(ptr %s34)
  br label %bb221
bb221:
  %t859 = load i64, ptr %l10
  store i64 %t859, ptr %l290
  %t860 = load i64, ptr %l290
  %t861 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchCpuFlags, i32 0, i32 1
  %t862 = load ptr, ptr %t861
  %t863 = getelementptr { i64, ptr }, ptr %t862, i64 %t860
  %t864 = load { i64, ptr }, ptr %t863
  store { i64, ptr } %t864, ptr %l291
  %t865 = load ptr, ptr %lp6
  %t866 = getelementptr %"compiler/target:Target", ptr %t865, i32 0, i32 4
  %t867 = load { i64, ptr }, ptr %t866
  store { i64, ptr } %t867, ptr %l292
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s35
  store ptr %s35room, ptr %s35
  %t868 = load { i64, ptr }, ptr %l291
  %t869 = extractvalue { i64, ptr } %t868, 1
  %t870 = extractvalue { i64, ptr } %t868, 0
  call void @__olang_sb_put(ptr %s35, ptr %t869, i64 %t870)
  %t871 = load { i64, ptr }, ptr %l292
  %t872 = extractvalue { i64, ptr } %t871, 1
  %t873 = extractvalue { i64, ptr } %t871, 0
  call void @__olang_sb_put(ptr %s35, ptr %t872, i64 %t873)
  %t874 = load ptr, ptr %s35
  %t875 = getelementptr %olang.builder, ptr %s35, i32 0, i32 1
  %t876 = load i64, ptr %t875
  %t877 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t876)
  call void @llvm.memcpy.p0.p0.i64(ptr %t877, ptr %t874, i64 %t876, i1 false)
  %t878 = insertvalue { i64, ptr } undef, i64 %t876, 0
  %t879 = insertvalue { i64, ptr } %t878, ptr %t877, 1
  store { i64, ptr } %t879, ptr %l293
  call void @__olang_sb_done(ptr %s35)
  %t880 = load { i64, ptr }, ptr %l293
  %t881 = extractvalue { i64, ptr } %t880, 0
  %t882 = extractvalue { i64, ptr } %t880, 1
  %t883 = mul i64 %t881, 1
  %t884 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t883)
  call void @llvm.memcpy.p0.p0.i64(ptr %t884, ptr %t882, i64 %t883, i1 false)
  %t885 = insertvalue { i64, ptr } undef, i64 %t881, 0
  %t886 = insertvalue { i64, ptr } %t885, ptr %t884, 1
  store { i64, ptr } %t886, ptr %l294
  %t887 = load { i64, ptr }, ptr %l294
  %t888 = load ptr, ptr %lp6
  %t889 = getelementptr %"compiler/target:Target", ptr %t888, i32 0, i32 6
  store { i64, ptr } %t887, ptr %t889
  %t890 = load ptr, ptr %lp6
  %t891 = load %"compiler/target:Target", ptr %t890
  store %"compiler/target:Target" %t891, ptr %l295
  call void @__olang_scope_close(ptr %s0)
  %t892 = load %"compiler/target:Target", ptr %l295
  %t893 = insertvalue { i32, %"compiler/target:Target" } zeroinitializer, %"compiler/target:Target" %t892, 1
  store { i32, %"compiler/target:Target" } %t893, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/target:Target" }, ptr %rv
  ret { i32, %"compiler/target:Target" } %rr
}

define dso_local void @compiler_2ftarget_2eSkylakeProbe_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t1 = extractvalue { i64, ptr } { i64 102, ptr @.d58 }, 1
  %t2 = extractvalue { i64, ptr } { i64 102, ptr @.d58 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t1, i64 %t2)
  %t3 = extractvalue { i64, ptr } { i64 38, ptr @.d59 }, 1
  %t4 = extractvalue { i64, ptr } { i64 38, ptr @.d59 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 66, ptr @.d60 }, 1
  %t6 = extractvalue { i64, ptr } { i64 66, ptr @.d60 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 94, ptr @.d61 }, 1
  %t8 = extractvalue { i64, ptr } { i64 94, ptr @.d61 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call ptr @__olang_scope_alloc(ptr %t12, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t13, ptr %t9, i64 %t11, i1 false)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l0
  call void @__olang_sb_done(ptr %s1)
  %t16 = load { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eSkylakeProbe
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l1
  %t18 = load { i64, ptr }, ptr %l0
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l2
  %t20 = load i64, ptr %l1
  %t21 = load i64, ptr %l2
  %t22 = icmp eq i64 %t20, %t21
  store i1 %t22, ptr %l3
  %t23 = load i1, ptr %l3
  br i1 %t23, label %bb1, label %bb2
bb1:
  %t24 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eSkylakeProbe, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  %t26 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t27 = load ptr, ptr %t26
  %t28 = load i64, ptr %l2
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  br label %bb3
bb2:
  %t30 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t30, ptr @G_2ecompiler_2ftarget_2eSkylakeProbe
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftarget_2eStripUnsafe(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca i8
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l9
  %t2 = load { i64, ptr }, ptr %l9
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 0, ptr @.d62 })
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr @.d63 }, ptr %l11
  %t5 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t5, ptr %l12
  %t6 = load { i64, ptr }, ptr %l12
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l13
  %t8 = load i64, ptr %l13
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l14
  %t13 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  %t15 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t16 = load ptr, ptr %t15
  %t17 = load i64, ptr %l13
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t19, ptr %l12
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load %"std/prelude/text:StringBuilder", ptr %l15
  store %"std/prelude/text:StringBuilder" %t22, ptr %l1
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t23, ptr %l16
  %t24 = load { i64, ptr }, ptr %l16
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s2, { i64, ptr } %t24, { i64, ptr } { i64 1, ptr @.d64 })
  store { i64, ptr } %t25, ptr %l17
  br label %bb6
bb6:
  %t26 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t26, ptr %l2
  store i64 0, ptr %l3
  %t27 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t27, ptr %l18
  %t28 = load { i64, ptr }, ptr %l18
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l19
  %t30 = load i64, ptr %l19
  store i64 %t30, ptr %l4
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l3
  store i64 %t31, ptr %l20
  %t32 = load i64, ptr %l4
  store i64 %t32, ptr %l21
  %t33 = load i64, ptr %l20
  %t34 = load i64, ptr %l21
  %t35 = icmp slt i64 %t33, %t34
  store i1 %t35, ptr %l22
  %t36 = load i1, ptr %l22
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l23
  %t38 = load i1, ptr %l23
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3
  store i64 %t39, ptr %l24
  %t40 = load i64, ptr %l24
  store i64 %t40, ptr %l5
  %t41 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t41, ptr %l25
  %t42 = load i64, ptr %l3
  store i64 %t42, ptr %l26
  %t43 = load i64, ptr %l26
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t43
  %t47 = load { i64, ptr }, ptr %t46
  store { i64, ptr } %t47, ptr %l27
  %t48 = load { i64, ptr }, ptr %l27
  store { i64, ptr } %t48, ptr %l6
  %t49 = load i64, ptr %l5
  store i64 %t49, ptr %l28
  %t50 = load i64, ptr %l28
  %t51 = icmp sgt i64 %t50, 0
  store i1 %t51, ptr %l29
  %t52 = load i1, ptr %l29
  br i1 %t52, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l1, ptr %l30
  %t53 = load ptr, ptr %l30
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t53, i8 44)
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  %t54 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t54, ptr %l31
  %t55 = load { i64, ptr }, ptr %l31
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l32
  %t57 = load i64, ptr %l32
  %t58 = icmp sgt i64 %t57, 1
  store i1 %t58, ptr %l33
  %t59 = load i1, ptr %l33
  br i1 %t59, label %bb15, label %bb16
bb15:
  %t60 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t60, ptr %l35
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  %t63 = getelementptr i8, ptr %t62, i64 0
  %t64 = load i8, ptr %t63
  store i8 %t64, ptr %l36
  %t65 = load i8, ptr %l36
  %t66 = icmp eq i8 %t65, 43
  store i1 %t66, ptr %l37
  %t67 = load i1, ptr %l37
  store i1 %t67, ptr %l34
  br label %bb17
bb16:
  store i1 false, ptr %l34
  br label %bb17
bb17:
  %t68 = load i1, ptr %l34
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t69 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t69, ptr %l39
  %t70 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t70, ptr %l40
  %t71 = load { i64, ptr }, ptr %l40
  store { i64, ptr } %t71, ptr %l41
  %t72 = load { i64, ptr }, ptr %l41
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l42
  %t74 = load { i64, ptr }, ptr %l39
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l43
  %t76 = icmp sge i64 1, 0
  store i1 %t76, ptr %l44
  %t77 = load i1, ptr %l44
  br i1 %t77, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l38
  br label %bb27
bb20:
  %t78 = load i64, ptr %l42
  %t79 = icmp sle i64 1, %t78
  store i1 %t79, ptr %l45
  %t80 = load i1, ptr %l45
  br i1 %t80, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @.c65)
  unreachable
bb22:
  %t81 = load i64, ptr %l42
  %t82 = load i64, ptr %l43
  %t83 = icmp sle i64 %t81, %t82
  store i1 %t83, ptr %l46
  %t84 = load i1, ptr %l46
  br i1 %t84, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c65)
  unreachable
bb24:
  %t85 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t86 = load ptr, ptr %t85
  %t87 = load i64, ptr %l42
  %t88 = getelementptr i8, ptr %t86, i64 1
  %t89 = sub i64 %t87, 1
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  store { i64, ptr } %t91, ptr %l47
  %t92 = load { i64, ptr }, ptr %l47
  store { i64, ptr } %t92, ptr %l7
  %t93 = load { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eIeeeUnsafe
  store { i64, ptr } %t93, ptr %l48
  %t94 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t94, ptr %l49
  %t95 = load ptr, ptr @__olang_prog_scope
  %t96 = load { i64, ptr }, ptr %l48
  %t97 = load { i64, ptr }, ptr %l49
  %t98 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t95, ptr %v0, { i64, ptr } %t96, { i64, ptr } %t97)
  store i1 %t98, ptr %l50
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @.c65)
  unreachable
bb26:
  %t99 = load i1, ptr %l50
  store i1 %t99, ptr %l38
  br label %bb27
bb27:
  %t100 = load i1, ptr %l38
  store i1 %t100, ptr %l8
  %t101 = load i1, ptr %l8
  store i1 %t101, ptr %l51
  %t102 = load i1, ptr %l51
  br i1 %t102, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l1, ptr %l52
  %t103 = load ptr, ptr %l52
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t103, i8 45)
  br label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l1, ptr %l63
  %t104 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t104, ptr %l64
  %t105 = load ptr, ptr %l63
  %t106 = load { i64, ptr }, ptr %l64
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t105, { i64, ptr } %t106)
  br label %bb38
bb30:
  store ptr %l1, ptr %l53
  %t107 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t107, ptr %l54
  %t108 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t108, ptr %l55
  %t109 = load { i64, ptr }, ptr %l55
  store { i64, ptr } %t109, ptr %l56
  %t110 = load { i64, ptr }, ptr %l56
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %l57
  %t112 = load { i64, ptr }, ptr %l54
  %t113 = extractvalue { i64, ptr } %t112, 0
  store i64 %t113, ptr %l58
  %t114 = icmp sge i64 1, 0
  store i1 %t114, ptr %l59
  %t115 = load i1, ptr %l59
  br i1 %t115, label %bb31, label %bb32
bb31:
  %t116 = load i64, ptr %l57
  %t117 = icmp sle i64 1, %t116
  store i1 %t117, ptr %l60
  %t118 = load i1, ptr %l60
  br i1 %t118, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb33:
  %t119 = load i64, ptr %l57
  %t120 = load i64, ptr %l58
  %t121 = icmp sle i64 %t119, %t120
  store i1 %t121, ptr %l61
  %t122 = load i1, ptr %l61
  br i1 %t122, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb35:
  %t123 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t124 = load ptr, ptr %t123
  %t125 = load i64, ptr %l57
  %t126 = getelementptr i8, ptr %t124, i64 1
  %t127 = sub i64 %t125, 1
  %t128 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t126, 1
  store { i64, ptr } %t129, ptr %l62
  %t130 = load ptr, ptr %l53
  %t131 = load { i64, ptr }, ptr %l62
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t130, { i64, ptr } %t131)
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load i64, ptr %l3
  store i64 %t132, ptr %l65
  %t133 = load i64, ptr %l65
  %t134 = add i64 %t133, 1
  store i64 %t134, ptr %l66
  %t135 = load i64, ptr %l66
  store i64 %t135, ptr %l3
  call void @__olang_scope_close(ptr %s7)
  br label %bb7
bb41:
  call void @__olang_scope_close(ptr %s2)
  store ptr %l1, ptr %l67
  %t136 = load ptr, ptr %l67
  %t137 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t136)
  store { i64, ptr } %t137, ptr %l68
  br label %bb42
bb42:
  %t138 = load { i64, ptr }, ptr %l68
  store { i64, ptr } %t138, ptr %l69
  %t139 = load { i64, ptr }, ptr %l69
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l70
  %t141 = load i64, ptr %l70
  %t142 = mul i64 %t141, 1
  %t143 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  store { i64, ptr } %t145, ptr %l71
  %t146 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t147 = load ptr, ptr %t146
  %t148 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t149 = load ptr, ptr %t148
  %t150 = load i64, ptr %l70
  %t151 = mul i64 %t150, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t147, ptr %t149, i64 %t151, i1 false)
  %t152 = load { i64, ptr }, ptr %l71
  store { i64, ptr } %t152, ptr %l69
  call void @__olang_scope_close(ptr %s0)
  %t153 = load { i64, ptr }, ptr %l69
  store { i64, ptr } %t153, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftarget_2eX86Level(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 1, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eLevelFlags
  store { i64, ptr } %t1, ptr %l11
  %t2 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t2, ptr %l2
  store i64 0, ptr %l3
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l12
  %t4 = load { i64, ptr }, ptr %l12
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l13
  %t6 = load i64, ptr %l13
  store i64 %t6, ptr %l4
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3
  store i64 %t7, ptr %l14
  %t8 = load i64, ptr %l4
  store i64 %t8, ptr %l15
  %t9 = load i64, ptr %l14
  %t10 = load i64, ptr %l15
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l16
  %t12 = load i1, ptr %l16
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l17
  %t14 = load i1, ptr %l17
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3
  store i64 %t15, ptr %l18
  %t16 = load i64, ptr %l18
  store i64 %t16, ptr %l5
  %t17 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t17, ptr %l19
  %t18 = load i64, ptr %l3
  store i64 %t18, ptr %l20
  %t19 = load i64, ptr %l20
  %t20 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t21 = load ptr, ptr %t20
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t19
  %t23 = load { i64, ptr }, ptr %t22
  store { i64, ptr } %t23, ptr %l21
  %t24 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t24, ptr %l6
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t25, ptr %l22
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = load { i64, ptr }, ptr %l22
  %t28 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %t26, ptr %s3, { i64, ptr } %t27, { i64, ptr } { i64 1, ptr @.d67 })
  store { i64, ptr } %t28, ptr %l23
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t29, ptr %l7
  store i64 0, ptr %l8
  %t30 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t30, ptr %l24
  %t31 = load { i64, ptr }, ptr %l24
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25
  %t33 = load i64, ptr %l25
  store i64 %t33, ptr %l9
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load i64, ptr %l8
  store i64 %t34, ptr %l26
  %t35 = load i64, ptr %l9
  store i64 %t35, ptr %l27
  %t36 = load i64, ptr %l26
  %t37 = load i64, ptr %l27
  %t38 = icmp slt i64 %t36, %t37
  store i1 %t38, ptr %l28
  %t39 = load i1, ptr %l28
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l29
  %t41 = load i1, ptr %l29
  br i1 %t41, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t42 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t42, ptr %l30
  %t43 = load i64, ptr %l8
  store i64 %t43, ptr %l31
  %t44 = load i64, ptr %l31
  %t45 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t46 = load ptr, ptr %t45
  %t47 = getelementptr { i64, ptr }, ptr %t46, i64 %t44
  %t48 = load { i64, ptr }, ptr %t47
  store { i64, ptr } %t48, ptr %l32
  %t49 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t49, ptr %l10
  %t50 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t50, ptr %l33
  %t51 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t51, ptr %l34
  %t52 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t52, ptr %l35
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t53 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 1
  %t54 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t53, i64 %t54)
  %t55 = load { i64, ptr }, ptr %l35
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  call void @__olang_sb_put(ptr %s5, ptr %t56, i64 %t57)
  %t58 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t58, i64 %t59)
  %t60 = load ptr, ptr %s5
  %t61 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t62 = load i64, ptr %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t60, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l36
  call void @__olang_sb_done(ptr %s5)
  %t66 = load { i64, ptr }, ptr %l36
  store { i64, ptr } %t66, ptr %l37
  %t67 = load { i64, ptr }, ptr %l37
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t69 = extractvalue { i64, ptr } %t67, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l38
  %t74 = load { i64, ptr }, ptr %l34
  %t75 = load { i64, ptr }, ptr %l38
  %t76 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s4, { i64, ptr } %t74, { i64, ptr } %t75)
  store i1 %t76, ptr %l39
  br label %bb10
bb10:
  %t77 = load i1, ptr %l39
  %t78 = xor i1 %t77, true
  store i1 %t78, ptr %l40
  %t79 = load i1, ptr %l40
  br i1 %t79, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s6
  %t80 = load i64, ptr %l1
  store i64 %t80, ptr %l41
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i64, ptr %l41
  store i64 %t81, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s7
  %t82 = load i64, ptr %l8
  store i64 %t82, ptr %l42
  %t83 = load i64, ptr %l42
  %t84 = add i64 %t83, 1
  store i64 %t84, ptr %l43
  %t85 = load i64, ptr %l43
  store i64 %t85, ptr %l8
  call void @__olang_scope_close(ptr %s7)
  br label %bb6
bb15:
  call void @__olang_scope_close(ptr %s3)
  %t86 = load i64, ptr %l5
  store i64 %t86, ptr %l44
  %t87 = load i64, ptr %l44
  %t88 = add i64 %t87, 2
  store i64 %t88, ptr %l45
  %t89 = load i64, ptr %l45
  store i64 %t89, ptr %l1
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s8
  %t90 = load i64, ptr %l3
  store i64 %t90, ptr %l46
  %t91 = load i64, ptr %l46
  %t92 = add i64 %t91, 1
  store i64 %t92, ptr %l47
  %t93 = load i64, ptr %l47
  store i64 %t93, ptr %l3
  call void @__olang_scope_close(ptr %s8)
  br label %bb1
bb17:
  call void @__olang_scope_close(ptr %s1)
  %t94 = load i64, ptr %l1
  store i64 %t94, ptr %l48
  call void @__olang_scope_close(ptr %s0)
  %t95 = load i64, ptr %l48
  store i64 %t95, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftarget_2earchIndex(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eArchs
  store { i64, ptr } %t1, ptr %l6
  %t2 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t2, ptr %l1
  store i64 0, ptr %l2
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l7
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l8
  %t6 = load i64, ptr %l8
  store i64 %t6, ptr %l3
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l2
  store i64 %t7, ptr %l9
  %t8 = load i64, ptr %l3
  store i64 %t8, ptr %l10
  %t9 = load i64, ptr %l9
  %t10 = load i64, ptr %l10
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l11
  %t12 = load i1, ptr %l11
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l12
  %t14 = load i1, ptr %l12
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l2
  store i64 %t15, ptr %l13
  %t16 = load i64, ptr %l13
  store i64 %t16, ptr %l4
  %t17 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t17, ptr %l14
  %t18 = load i64, ptr %l2
  store i64 %t18, ptr %l15
  %t19 = load i64, ptr %l15
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t19
  %t23 = load { i64, ptr }, ptr %t22
  store { i64, ptr } %t23, ptr %l16
  %t24 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t24, ptr %l5
  %t25 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t25, ptr %l17
  %t26 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t26, ptr %l18
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = load { i64, ptr }, ptr %l17
  %t29 = load { i64, ptr }, ptr %l18
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t27, ptr %v0, { i64, ptr } %t28, { i64, ptr } %t29)
  store i1 %t30, ptr %l19
  br label %bb5
bb5:
  %t31 = load i1, ptr %l19
  br i1 %t31, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l4
  store i64 %t32, ptr %l20
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i64, ptr %l20
  store i64 %t33, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load i64, ptr %l2
  store i64 %t34, ptr %l21
  %t35 = load i64, ptr %l21
  %t36 = add i64 %t35, 1
  store i64 %t36, ptr %l22
  %t37 = load i64, ptr %l22
  store i64 %t37, ptr %l2
  call void @__olang_scope_close(ptr %s4)
  br label %bb1
bb10:
  call void @__olang_scope_close(ptr %s1)
  store i64 -1, ptr %l23
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i64, ptr %l23
  store i64 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l4
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 3, ptr @.d71 }, 1
  %t9 = extractvalue { i64, ptr } { i64 3, ptr @.d71 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load ptr, ptr %s1
  %t11 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t12 = load i64, ptr %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @llvm.memcpy.p0.p0.i64(ptr %t13, ptr %t10, i64 %t12, i1 false)
  %t14 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t16 = load { i64, ptr }, ptr %l5
  %t17 = extractvalue { i64, ptr } %t16, 0
  %t18 = extractvalue { i64, ptr } %t16, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l6
  %t23 = load { i64, ptr }, ptr %l3
  %t24 = load { i64, ptr }, ptr %l6
  %t25 = call { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v0, ptr %s0, { i64, ptr } %t23, { i64, ptr } %t24)
  %t26 = extractvalue { i32, { i64, ptr } } %t25, 1
  %t27 = extractvalue { i32, { i64, ptr } } %t25, 0
  store i32 %t27, ptr %l8
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb2, label %ok.29
ok.29:
  store { i64, ptr } %t26, ptr %l7
  br label %bb1
bb1:
  %t30 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t30, ptr %l2
  br label %bb3
bb2:
  %t31 = load i32, ptr %l8
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 1, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  store i32 %t39, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i32, ptr %l9
  %t41 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t40, 0
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load { i64, ptr }, ptr %l2
  %t43 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t42, 1
  store { i32, { i64, ptr } } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2ecField(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i8
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i8
  %l45 = alloca i8
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load i64, ptr %l1
  store i64 %t3, ptr %l10
  %t4 = load i64, ptr %l10
  store i64 %t4, ptr %l3
  %t5 = load i64, ptr %l1
  store i64 %t5, ptr %l11
  %t6 = load i64, ptr %l11
  %t7 = add i64 %t6, 65
  store i64 %t7, ptr %l12
  %t8 = load i64, ptr %l12
  store i64 %t8, ptr %l4
  store i64 1, ptr %l5
  %t9 = load i64, ptr %l4
  store i64 %t9, ptr %l13
  %t10 = load i64, ptr %l3
  store i64 %t10, ptr %l14
  %t11 = load i64, ptr %l13
  %t12 = load i64, ptr %l14
  %t13 = icmp sgt i64 %t11, %t12
  store i1 %t13, ptr %l15
  %t14 = load i1, ptr %l15
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l5
  store i64 %t15, ptr %l17
  %t16 = load i64, ptr %l17
  %t17 = icmp sgt i64 %t16, 0
  store i1 %t17, ptr %l18
  %t18 = load i1, ptr %l18
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16
  br label %bb7
bb4:
  %t19 = load i64, ptr %l4
  store i64 %t19, ptr %l20
  %t20 = load i64, ptr %l3
  store i64 %t20, ptr %l21
  %t21 = load i64, ptr %l20
  %t22 = load i64, ptr %l21
  %t23 = sub i64 %t21, %t22
  store i64 %t23, ptr %l22
  %t24 = load i64, ptr %l5
  store i64 %t24, ptr %l23
  %t25 = load i64, ptr %l22
  %t26 = load i64, ptr %l23
  %t27 = add i64 %t25, %t26
  store i64 %t27, ptr %l24
  %t28 = load i64, ptr %l24
  %t29 = sub i64 %t28, 1
  store i64 %t29, ptr %l25
  %t30 = load i64, ptr %l5
  store i64 %t30, ptr %l26
  %t31 = load i64, ptr %l25
  %t32 = load i64, ptr %l26
  %t33 = sdiv i64 %t31, %t32
  store i64 %t33, ptr %l27
  %t34 = load i64, ptr %l27
  store i64 %t34, ptr %l19
  br label %bb6
bb5:
  store i64 0, ptr %l19
  br label %bb6
bb6:
  %t35 = load i64, ptr %l19
  store i64 %t35, ptr %l16
  br label %bb7
bb7:
  %t36 = load i64, ptr %l16
  store i64 %t36, ptr %l6
  store i64 0, ptr %l7
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l7
  store i64 %t37, ptr %l28
  %t38 = load i64, ptr %l6
  store i64 %t38, ptr %l29
  %t39 = load i64, ptr %l28
  %t40 = load i64, ptr %l29
  %t41 = icmp slt i64 %t39, %t40
  store i1 %t41, ptr %l30
  %t42 = load i1, ptr %l30
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l31
  %t44 = load i1, ptr %l31
  br i1 %t44, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l3
  store i64 %t45, ptr %l32
  %t46 = load i64, ptr %l7
  store i64 %t46, ptr %l33
  %t47 = load i64, ptr %l5
  store i64 %t47, ptr %l34
  %t48 = load i64, ptr %l33
  %t49 = load i64, ptr %l34
  %t50 = mul i64 %t48, %t49
  store i64 %t50, ptr %l35
  %t51 = load i64, ptr %l32
  %t52 = load i64, ptr %l35
  %t53 = add i64 %t51, %t52
  store i64 %t53, ptr %l36
  %t54 = load i64, ptr %l36
  store i64 %t54, ptr %l8
  %t55 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t55, ptr %l37
  %t56 = load i64, ptr %l8
  store i64 %t56, ptr %l38
  %t57 = load i64, ptr %l38
  %t58 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t59 = load ptr, ptr %t58
  %t60 = getelementptr i8, ptr %t59, i64 %t57
  %t61 = load i8, ptr %t60
  store i8 %t61, ptr %l39
  %t62 = load i8, ptr %l39
  %t63 = icmp eq i8 %t62, 0
  store i1 %t63, ptr %l40
  %t64 = load i1, ptr %l40
  br i1 %t64, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb13:
  br label %bb14
bb14:
  store ptr %l2, ptr %l41
  %t65 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t65, ptr %l42
  %t66 = load i64, ptr %l8
  store i64 %t66, ptr %l43
  %t67 = load i64, ptr %l43
  %t68 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t69 = load ptr, ptr %t68
  %t70 = getelementptr i8, ptr %t69, i64 %t67
  %t71 = load i8, ptr %t70
  store i8 %t71, ptr %l44
  %t72 = load i8, ptr %l44
  store i8 %t72, ptr %l45
  %t73 = load ptr, ptr %l41
  %t74 = load i8, ptr %l45
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t73, i8 %t74)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t75 = load i64, ptr %l7
  store i64 %t75, ptr %l46
  %t76 = load i64, ptr %l46
  %t77 = add i64 %t76, 1
  store i64 %t77, ptr %l47
  %t78 = load i64, ptr %l47
  store i64 %t78, ptr %l7
  call void @__olang_scope_close(ptr %s4)
  br label %bb8
bb17:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l2, ptr %l48
  %t79 = load ptr, ptr %l48
  %t80 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t79)
  store { i64, ptr } %t80, ptr %l49
  br label %bb18
bb18:
  %t81 = load { i64, ptr }, ptr %l49
  store { i64, ptr } %t81, ptr %l50
  %t82 = load { i64, ptr }, ptr %l50
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l51
  %t84 = load i64, ptr %l51
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l52
  %t89 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t90 = load ptr, ptr %t89
  %t91 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t92 = load ptr, ptr %t91
  %t93 = load i64, ptr %l51
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l52
  store { i64, ptr } %t95, ptr %l50
  call void @__olang_scope_close(ptr %s0)
  %t96 = load { i64, ptr }, ptr %l50
  store { i64, ptr } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftarget_2ecanCompileBf16(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:Output"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca [9 x { i64, ptr }]
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/os:Output"
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/os:Output"
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t1 = extractvalue { i64, ptr } { i64 88, ptr @.d72 }, 1
  %t2 = extractvalue { i64, ptr } { i64 88, ptr @.d72 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t1, i64 %t2)
  %t3 = extractvalue { i64, ptr } { i64 49, ptr @.d73 }, 1
  %t4 = extractvalue { i64, ptr } { i64 49, ptr @.d73 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load ptr, ptr %s1
  %t6 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t7 = load i64, ptr %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t5, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t11 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t11, ptr %l2
  %t12 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t12, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t13 = load { i64, ptr }, ptr %l6
  %t14 = extractvalue { i64, ptr } %t13, 1
  %t15 = extractvalue { i64, ptr } %t13, 0
  call void @__olang_sb_put(ptr %s2, ptr %t14, i64 %t15)
  %t16 = load ptr, ptr %s2
  %t17 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t18 = load i64, ptr %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t16, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l7
  call void @__olang_sb_done(ptr %s2)
  %t22 = load { i64, ptr }, ptr %l7
  %t23 = extractvalue { i64, ptr } %t22, 0
  %t24 = extractvalue { i64, ptr } %t22, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l8
  %t29 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t29, ptr %l9
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t30 = extractvalue { i64, ptr } { i64 9, ptr @.d74 }, 1
  %t31 = extractvalue { i64, ptr } { i64 9, ptr @.d74 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t30, i64 %t31)
  %t32 = load { i64, ptr }, ptr %l9
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  call void @__olang_sb_put(ptr %s3, ptr %t33, i64 %t34)
  %t35 = load ptr, ptr %s3
  %t36 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t37 = load i64, ptr %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t35, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l10
  call void @__olang_sb_done(ptr %s3)
  %t41 = load { i64, ptr }, ptr %l10
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l11
  %t48 = load { i64, ptr }, ptr %l8
  %t49 = insertvalue [9 x { i64, ptr }] undef, { i64, ptr } %t48, 0
  %t50 = load { i64, ptr }, ptr %l11
  %t51 = insertvalue [9 x { i64, ptr }] %t49, { i64, ptr } %t50, 1
  %t52 = insertvalue [9 x { i64, ptr }] %t51, { i64, ptr } { i64 22, ptr @.d75 }, 2
  %t53 = insertvalue [9 x { i64, ptr }] %t52, { i64, ptr } { i64 2, ptr @.d76 }, 3
  %t54 = insertvalue [9 x { i64, ptr }] %t53, { i64, ptr } { i64 2, ptr @.d77 }, 4
  %t55 = insertvalue [9 x { i64, ptr }] %t54, { i64, ptr } { i64 2, ptr @.d78 }, 5
  %t56 = insertvalue [9 x { i64, ptr }] %t55, { i64, ptr } { i64 1, ptr @.d79 }, 6
  %t57 = insertvalue [9 x { i64, ptr }] %t56, { i64, ptr } { i64 2, ptr @.d80 }, 7
  %t58 = insertvalue [9 x { i64, ptr }] %t57, { i64, ptr } { i64 9, ptr @.d81 }, 8
  store [9 x { i64, ptr }] %t58, ptr %l12
  %t59 = load [9 x { i64, ptr }], ptr %l12
  %t60 = load ptr, ptr @__olang_prog_scope
  %t61 = call ptr @__olang_scope_alloc(ptr %t60, i64 144)
  store [9 x { i64, ptr }] %t59, ptr %t61
  %t62 = insertvalue { i64, ptr } undef, i64 9, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l13
  %t64 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t64, ptr %l3
  %t65 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t65, ptr %l15
  %t66 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t66, ptr %l16
  %t67 = load { i64, ptr }, ptr %l15
  %t68 = load { i64, ptr }, ptr %l16
  %t69 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t67, { i64, ptr } %t68, i1 true, { i64, ptr } { i64 0, ptr @.d82 })
  %t70 = extractvalue { i32, %"std/os:Output" } %t69, 1
  %t71 = extractvalue { i32, %"std/os:Output" } %t69, 0
  store i32 %t71, ptr %l18
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb2, label %ok.73
ok.73:
  store %"std/os:Output" %t70, ptr %l17
  br label %bb1
bb1:
  %t74 = load %"std/os:Output", ptr %l17
  store %"std/os:Output" %t74, ptr %l14
  br label %bb6
bb2:
  %t75 = load i32, ptr %l18
  %t76 = ashr i32 %t75, 16
  store i32 %t76, ptr %l19
  %t77 = load i32, ptr %l19
  %t78 = icmp eq i32 %t77, 1
  store i1 %t78, ptr %l20
  %t79 = load i1, ptr %l20
  br i1 %t79, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c83)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l21
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i1, ptr %l21
  store i1 %t80, ptr %rv
  br label %ret
bb6:
  %t81 = load %"std/os:Output", ptr %l14
  store %"std/os:Output" %t81, ptr %l4
  %t82 = getelementptr %"std/os:Output", ptr %l4, i32 0, i32 0
  %t83 = load i32, ptr %t82
  store i32 %t83, ptr %l22
  %t84 = load i32, ptr %l22
  %t85 = icmp eq i32 %t84, 0
  store i1 %t85, ptr %l23
  call void @__olang_scope_close(ptr %s0)
  %t86 = load i1, ptr %l23
  store i1 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eFromProbe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i8
  %l41 = alloca i64
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca { i64, ptr }
  %l62 = alloca i8
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i1
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i32
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca i64
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l102 = alloca i1
  %l103 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l109 = alloca i1
  %l110 = alloca i1
  %l111 = alloca { i64, ptr }
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l116 = alloca i32
  %l117 = alloca { i64, ptr }
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca i32
  %l128 = alloca i64
  %l129 = alloca i1
  %l130 = alloca i64
  %l131 = alloca { i64, ptr }
  %l132 = alloca i64
  %l133 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l135 = alloca i64
  %l136 = alloca i64
  %l137 = alloca i1
  %l138 = alloca i1
  %l139 = alloca i1
  %l140 = alloca { i64, ptr }
  %l141 = alloca i8
  %l142 = alloca i64
  %l143 = alloca i32
  %l144 = alloca i64
  %l145 = alloca i1
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l153 = alloca i1
  %l154 = alloca i1
  %l155 = alloca i1
  %l156 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l159 = alloca ptr
  %l160 = alloca i64
  %l161 = alloca i1
  %l162 = alloca i64
  %l163 = alloca ptr
  %l164 = alloca i64
  %l165 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca i64
  %l172 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t1, ptr %l15
  %t2 = load { i64, ptr }, ptr %l15
  %t3 = call { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v1, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 17, ptr @.d84 })
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l17
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l16
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t8, ptr %l14
  br label %bb4
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l18
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l18
  store i32 %t9, ptr %rv
  br label %ret
bb4:
  %t10 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t10, ptr %l2
  %t11 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t11, ptr %l20
  %t12 = load { i64, ptr }, ptr %l20
  %t13 = call { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v1, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 21, ptr @.d85 })
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l22
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb6, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l21
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t18, ptr %l19
  br label %bb8
bb6:
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 65536, ptr %l23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i32, ptr %l23
  store i32 %t19, ptr %rv
  br label %ret
bb8:
  %t20 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t20, ptr %l3
  %t21 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t21, ptr %l25
  %t22 = load { i64, ptr }, ptr %l25
  %t23 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 17, ptr @.d86 })
  %t24 = extractvalue { i32, i64 } %t23, 1
  %t25 = extractvalue { i32, i64 } %t23, 0
  store i32 %t25, ptr %l27
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb10, label %ok.27
ok.27:
  store i64 %t24, ptr %l26
  br label %bb9
bb9:
  %t28 = load i64, ptr %l26
  store i64 %t28, ptr %l24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 65536, ptr %l28
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l28
  store i32 %t29, ptr %rv
  br label %ret
bb12:
  %t30 = load i64, ptr %l24
  store i64 %t30, ptr %l4
  %t31 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t31, ptr %l30
  %t32 = load i64, ptr %l4
  store i64 %t32, ptr %l31
  %t33 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t33, ptr %l32
  %t34 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t34, ptr %l33
  %t35 = load { i64, ptr }, ptr %l33
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l34
  %t37 = load { i64, ptr }, ptr %l30
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l35
  %t39 = load i64, ptr %l31
  %t40 = icmp sge i64 %t39, 0
  store i1 %t40, ptr %l36
  %t41 = load i1, ptr %l36
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t42 = load i64, ptr %l31
  %t43 = load i64, ptr %l34
  %t44 = icmp sle i64 %t42, %t43
  store i1 %t44, ptr %l37
  %t45 = load i1, ptr %l37
  br i1 %t45, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c87)
  unreachable
bb15:
  %t46 = load i64, ptr %l34
  %t47 = load i64, ptr %l35
  %t48 = icmp sle i64 %t46, %t47
  store i1 %t48, ptr %l38
  %t49 = load i1, ptr %l38
  br i1 %t49, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c87)
  unreachable
bb17:
  %t50 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  %t52 = load i64, ptr %l31
  %t53 = load i64, ptr %l34
  %t54 = getelementptr i8, ptr %t51, i64 %t52
  %t55 = sub i64 %t53, %t52
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  store { i64, ptr } %t57, ptr %l39
  store i8 10, ptr %l40
  %t58 = load { i64, ptr }, ptr %l39
  %t59 = load i8, ptr %l40
  %t60 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t58, i8 %t59)
  %t61 = extractvalue { i32, i64 } %t60, 1
  %t62 = extractvalue { i32, i64 } %t60, 0
  store i32 %t62, ptr %l42
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb20, label %ok.64
ok.64:
  store i64 %t61, ptr %l41
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @.c87)
  unreachable
bb19:
  %t65 = load i64, ptr %l41
  store i64 %t65, ptr %l29
  br label %bb22
bb20:
  br label %bb21
bb21:
  %t66 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t66, ptr %l43
  %t67 = load { i64, ptr }, ptr %l43
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l44
  %t69 = load i64, ptr %l4
  store i64 %t69, ptr %l45
  %t70 = load i64, ptr %l44
  %t71 = load i64, ptr %l45
  %t72 = sub i64 %t70, %t71
  store i64 %t72, ptr %l46
  %t73 = load i64, ptr %l46
  store i64 %t73, ptr %l29
  br label %bb22
bb22:
  %t74 = load i64, ptr %l29
  store i64 %t74, ptr %l5
  %t75 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t75, ptr %l47
  %t76 = load i64, ptr %l4
  store i64 %t76, ptr %l48
  %t77 = load i64, ptr %l4
  store i64 %t77, ptr %l49
  %t78 = load i64, ptr %l5
  store i64 %t78, ptr %l50
  %t79 = load i64, ptr %l49
  %t80 = load i64, ptr %l50
  %t81 = add i64 %t79, %t80
  store i64 %t81, ptr %l51
  %t82 = load { i64, ptr }, ptr %l47
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l52
  %t84 = load i64, ptr %l48
  %t85 = icmp sge i64 %t84, 0
  store i1 %t85, ptr %l53
  %t86 = load i1, ptr %l53
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t87 = load i64, ptr %l48
  %t88 = load i64, ptr %l51
  %t89 = icmp sle i64 %t87, %t88
  store i1 %t89, ptr %l54
  %t90 = load i1, ptr %l54
  br i1 %t90, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c88)
  unreachable
bb25:
  %t91 = load i64, ptr %l51
  %t92 = load i64, ptr %l52
  %t93 = icmp sle i64 %t91, %t92
  store i1 %t93, ptr %l55
  %t94 = load i1, ptr %l55
  br i1 %t94, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @.c88)
  unreachable
bb27:
  %t95 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t96 = load ptr, ptr %t95
  %t97 = load i64, ptr %l48
  %t98 = load i64, ptr %l51
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l56
  %t103 = load { i64, ptr }, ptr %l56
  store { i64, ptr } %t103, ptr %l6
  %t104 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t104, ptr %l57
  %t105 = load { i64, ptr }, ptr %l57
  %t106 = extractvalue { i64, ptr } %t105, 0
  store i64 %t106, ptr %l58
  %t107 = load i64, ptr %l58
  %t108 = icmp eq i64 %t107, 0
  store i1 %t108, ptr %l59
  %t109 = load i1, ptr %l59
  br i1 %t109, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @.c88)
  unreachable
bb29:
  store i1 true, ptr %l60
  br label %bb31
bb30:
  %t110 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t110, ptr %l61
  %t111 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t112 = load ptr, ptr %t111
  %t113 = getelementptr i8, ptr %t112, i64 0
  %t114 = load i8, ptr %t113
  store i8 %t114, ptr %l62
  %t115 = load i8, ptr %l62
  %t116 = icmp ne i8 %t115, 101
  store i1 %t116, ptr %l63
  %t117 = load i1, ptr %l63
  store i1 %t117, ptr %l60
  br label %bb31
bb31:
  %t118 = load i1, ptr %l60
  br i1 %t118, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l64
  br label %bb35
bb33:
  %t119 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t119, ptr %l65
  %t120 = load { i64, ptr }, ptr %l65
  store { i64, ptr } %t120, ptr %l66
  store { i64, ptr } { i64 5, ptr @.d89 }, ptr %l67
  %t121 = load { i64, ptr }, ptr %l66
  %t122 = load { i64, ptr }, ptr %l67
  %t123 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t121, { i64, ptr } %t122)
  store i1 %t123, ptr %l68
  br label %bb34
bb34:
  %t124 = load i1, ptr %l68
  store i1 %t124, ptr %l64
  br label %bb35
bb35:
  %t125 = load i1, ptr %l64
  br i1 %t125, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l69
  br label %bb39
bb37:
  %t126 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t126, ptr %l70
  %t127 = load { i64, ptr }, ptr %l70
  store { i64, ptr } %t127, ptr %l71
  store { i64, ptr } { i64 5, ptr @.d90 }, ptr %l72
  %t128 = load { i64, ptr }, ptr %l71
  %t129 = load { i64, ptr }, ptr %l72
  %t130 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t128, { i64, ptr } %t129)
  store i1 %t130, ptr %l73
  br label %bb38
bb38:
  %t131 = load i1, ptr %l73
  store i1 %t131, ptr %l69
  br label %bb39
bb39:
  %t132 = load i1, ptr %l69
  br i1 %t132, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  store i32 65537, ptr %l74
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t133 = load i32, ptr %l74
  store i32 %t133, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t134 = load ptr, ptr %l0
  store ptr %t134, ptr %l75
  %t135 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t135, ptr %l76
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t136 = load { i64, ptr }, ptr %l76
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  call void @__olang_sb_put(ptr %s5, ptr %t137, i64 %t138)
  %t139 = load ptr, ptr %s5
  %t140 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t141 = load i64, ptr %t140
  %t142 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t141)
  call void @llvm.memcpy.p0.p0.i64(ptr %t142, ptr %t139, i64 %t141, i1 false)
  %t143 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l77
  call void @__olang_sb_done(ptr %s5)
  %t145 = load { i64, ptr }, ptr %l77
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l78
  %t152 = load { i64, ptr }, ptr %l78
  %t153 = load ptr, ptr %l75
  %t154 = getelementptr %"compiler/target:Target", ptr %t153, i32 0, i32 1
  store { i64, ptr } %t152, ptr %t154
  %t155 = load ptr, ptr %l0
  store ptr %t155, ptr %l79
  %t156 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t156, ptr %l81
  %t157 = load { i64, ptr }, ptr %l81
  %t158 = call { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v1, ptr %s0, { i64, ptr } %t157, { i64, ptr } { i64 10, ptr @.d91 })
  %t159 = extractvalue { i32, { i64, ptr } } %t158, 1
  %t160 = extractvalue { i32, { i64, ptr } } %t158, 0
  store i32 %t160, ptr %l83
  %t161 = icmp ne i32 %t160, 0
  br i1 %t161, label %bb44, label %ok.162
ok.162:
  store { i64, ptr } %t159, ptr %l82
  br label %bb43
bb43:
  %t163 = load { i64, ptr }, ptr %l82
  store { i64, ptr } %t163, ptr %l80
  br label %bb46
bb44:
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s6
  store i32 65536, ptr %l84
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t164 = load i32, ptr %l84
  store i32 %t164, ptr %rv
  br label %ret
bb46:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t165 = load { i64, ptr }, ptr %l80
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  call void @__olang_sb_put(ptr %s7, ptr %t166, i64 %t167)
  %t168 = load ptr, ptr %s7
  %t169 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t170 = load i64, ptr %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t170)
  call void @llvm.memcpy.p0.p0.i64(ptr %t171, ptr %t168, i64 %t170, i1 false)
  %t172 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  store { i64, ptr } %t173, ptr %l85
  call void @__olang_sb_done(ptr %s7)
  %t174 = load { i64, ptr }, ptr %l85
  %t175 = extractvalue { i64, ptr } %t174, 0
  %t176 = extractvalue { i64, ptr } %t174, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  store { i64, ptr } %t180, ptr %l86
  %t181 = load { i64, ptr }, ptr %l86
  %t182 = load ptr, ptr %l79
  %t183 = getelementptr %"compiler/target:Target", ptr %t182, i32 0, i32 4
  store { i64, ptr } %t181, ptr %t183
  %t184 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t184, ptr %l88
  %t185 = load { i64, ptr }, ptr %l88
  %t186 = call { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v1, ptr %s0, { i64, ptr } %t185, { i64, ptr } { i64 15, ptr @.d92 })
  %t187 = extractvalue { i32, { i64, ptr } } %t186, 1
  %t188 = extractvalue { i32, { i64, ptr } } %t186, 0
  store i32 %t188, ptr %l90
  %t189 = icmp ne i32 %t188, 0
  br i1 %t189, label %bb48, label %ok.190
ok.190:
  store { i64, ptr } %t187, ptr %l89
  br label %bb47
bb47:
  %t191 = load { i64, ptr }, ptr %l89
  store { i64, ptr } %t191, ptr %l87
  br label %bb50
bb48:
  br label %bb49
bb49:
  store { i64, ptr } { i64 0, ptr @.d93 }, ptr %l87
  br label %bb50
bb50:
  %t192 = load { i64, ptr }, ptr %l87
  %t193 = call { i64, ptr } @compiler_2ftarget_2eStripUnsafe(ptr %v1, ptr %s0, { i64, ptr } %t192)
  store { i64, ptr } %t193, ptr %l91
  br label %bb51
bb51:
  %t194 = load { i64, ptr }, ptr %l91
  store { i64, ptr } %t194, ptr %l7
  %t195 = load ptr, ptr %l0
  store ptr %t195, ptr %l92
  %t196 = load ptr, ptr %l92
  %t197 = getelementptr %"compiler/target:Target", ptr %t196, i32 0, i32 2
  %t198 = load { i64, ptr }, ptr %t197
  store { i64, ptr } %t198, ptr %l93
  %t199 = load { i64, ptr }, ptr %l93
  %t200 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t199, { i64, ptr } { i64 7, ptr @.d94 })
  store i1 %t200, ptr %l94
  br label %bb52
bb52:
  %t201 = load i1, ptr %l94
  br i1 %t201, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s8
  %t202 = load ptr, ptr %l0
  store ptr %t202, ptr %l95
  %t203 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t203, ptr %l96
  %t204 = load { i64, ptr }, ptr %l96
  %t205 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s8, { i64, ptr } %t204, { i64, ptr } { i64 4, ptr @.d95 })
  store i1 %t205, ptr %l97
  br label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t206 = load ptr, ptr %l0
  store ptr %t206, ptr %l100
  %t207 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t207, ptr %l101
  %t208 = load { i64, ptr }, ptr %l101
  %t209 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s9, { i64, ptr } %t208, { i64, ptr } { i64 7, ptr @.d96 })
  store i1 %t209, ptr %l102
  br label %bb59
bb55:
  %t210 = load i1, ptr %l97
  br i1 %t210, label %bb56, label %bb57
bb56:
  store i64 128, ptr %l98
  br label %bb58
bb57:
  store i64 0, ptr %l98
  br label %bb58
bb58:
  %t211 = load i64, ptr %l98
  %t212 = load ptr, ptr %l95
  %t213 = getelementptr %"compiler/target:Target", ptr %t212, i32 0, i32 7
  store i64 %t211, ptr %t213
  %t214 = load ptr, ptr %l0
  store ptr %t214, ptr %l99
  %t215 = load ptr, ptr %l99
  %t216 = getelementptr %"compiler/target:Target", ptr %t215, i32 0, i32 8
  store i1 true, ptr %t216
  call void @__olang_scope_close(ptr %s8)
  br label %bb72
bb59:
  %t217 = load i1, ptr %l102
  br i1 %t217, label %bb60, label %bb61
bb60:
  store i64 512, ptr %l103
  br label %bb66
bb61:
  %t218 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t218, ptr %l104
  %t219 = load { i64, ptr }, ptr %l104
  %t220 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s9, { i64, ptr } %t219, { i64, ptr } { i64 3, ptr @.d97 })
  store i1 %t220, ptr %l105
  br label %bb62
bb62:
  %t221 = load i1, ptr %l105
  br i1 %t221, label %bb63, label %bb64
bb63:
  store i64 256, ptr %l106
  br label %bb65
bb64:
  store i64 128, ptr %l106
  br label %bb65
bb65:
  %t222 = load i64, ptr %l106
  store i64 %t222, ptr %l103
  br label %bb66
bb66:
  %t223 = load i64, ptr %l103
  %t224 = load ptr, ptr %l100
  %t225 = getelementptr %"compiler/target:Target", ptr %t224, i32 0, i32 7
  store i64 %t223, ptr %t225
  %t226 = load ptr, ptr %l0
  store ptr %t226, ptr %l107
  %t227 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t227, ptr %l108
  %t228 = load { i64, ptr }, ptr %l108
  %t229 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s9, { i64, ptr } %t228, { i64, ptr } { i64 3, ptr @.d98 })
  store i1 %t229, ptr %l109
  br label %bb67
bb67:
  %t230 = load i1, ptr %l109
  br i1 %t230, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l110
  br label %bb71
bb69:
  %t231 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t231, ptr %l111
  %t232 = load { i64, ptr }, ptr %l111
  %t233 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s9, { i64, ptr } %t232, { i64, ptr } { i64 4, ptr @.d99 })
  store i1 %t233, ptr %l112
  br label %bb70
bb70:
  %t234 = load i1, ptr %l112
  store i1 %t234, ptr %l110
  br label %bb71
bb71:
  %t235 = load i1, ptr %l110
  %t236 = load ptr, ptr %l107
  %t237 = getelementptr %"compiler/target:Target", ptr %t236, i32 0, i32 8
  store i1 %t235, ptr %t237
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb72:
  %t238 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t238, ptr %l114
  %t239 = load { i64, ptr }, ptr %l114
  %t240 = call { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v1, ptr %s0, { i64, ptr } %t239, { i64, ptr } { i64 8, ptr @.d100 })
  %t241 = extractvalue { i32, { i64, ptr } } %t240, 1
  %t242 = extractvalue { i32, { i64, ptr } } %t240, 0
  store i32 %t242, ptr %l116
  %t243 = icmp ne i32 %t242, 0
  br i1 %t243, label %bb74, label %ok.244
ok.244:
  store { i64, ptr } %t241, ptr %l115
  br label %bb73
bb73:
  %t245 = load { i64, ptr }, ptr %l115
  store { i64, ptr } %t245, ptr %l113
  br label %bb76
bb74:
  br label %bb75
bb75:
  store { i64, ptr } { i64 0, ptr @.d101 }, ptr %l113
  br label %bb76
bb76:
  %t246 = load { i64, ptr }, ptr %l113
  store { i64, ptr } %t246, ptr %l8
  %t247 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t247, ptr %l117
  %t248 = load { i64, ptr }, ptr %l117
  %t249 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t248, { i64, ptr } { i64 0, ptr @.d102 })
  store i1 %t249, ptr %l118
  br label %bb77
bb77:
  %t250 = load i1, ptr %l118
  %t251 = xor i1 %t250, true
  store i1 %t251, ptr %l119
  %t252 = load i1, ptr %l119
  br i1 %t252, label %bb78, label %bb79
bb78:
  %t253 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t253, ptr %l121
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t254 = extractvalue { i64, ptr } { i64 13, ptr @.d103 }, 1
  %t255 = extractvalue { i64, ptr } { i64 13, ptr @.d103 }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t254, i64 %t255)
  %t256 = load { i64, ptr }, ptr %l121
  %t257 = extractvalue { i64, ptr } %t256, 1
  %t258 = extractvalue { i64, ptr } %t256, 0
  call void @__olang_sb_put(ptr %s10, ptr %t257, i64 %t258)
  %t259 = extractvalue { i64, ptr } { i64 1, ptr @.d104 }, 1
  %t260 = extractvalue { i64, ptr } { i64 1, ptr @.d104 }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t259, i64 %t260)
  %t261 = load ptr, ptr %s10
  %t262 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t263 = load i64, ptr %t262
  %t264 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t261, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  store { i64, ptr } %t266, ptr %l122
  call void @__olang_sb_done(ptr %s10)
  %t267 = load { i64, ptr }, ptr %l122
  %t268 = extractvalue { i64, ptr } %t267, 0
  %t269 = extractvalue { i64, ptr } %t267, 1
  %t270 = mul i64 %t268, 1
  %t271 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t270)
  call void @llvm.memcpy.p0.p0.i64(ptr %t271, ptr %t269, i64 %t270, i1 false)
  %t272 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  store { i64, ptr } %t273, ptr %l123
  %t274 = load { i64, ptr }, ptr %l123
  store { i64, ptr } %t274, ptr %l120
  br label %bb80
bb79:
  store { i64, ptr } { i64 0, ptr @.d105 }, ptr %l120
  br label %bb80
bb80:
  %t275 = load { i64, ptr }, ptr %l120
  store { i64, ptr } %t275, ptr %l9
  store { i64, ptr } { i64 0, ptr @.d106 }, ptr %l10
  %t276 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t276, ptr %l125
  %t277 = load { i64, ptr }, ptr %l125
  %t278 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t277, { i64, ptr } { i64 13, ptr @.d107 })
  %t279 = extractvalue { i32, i64 } %t278, 1
  %t280 = extractvalue { i32, i64 } %t278, 0
  store i32 %t280, ptr %l127
  %t281 = icmp ne i32 %t280, 0
  br i1 %t281, label %bb82, label %ok.282
ok.282:
  store i64 %t279, ptr %l126
  br label %bb81
bb81:
  %t283 = load i64, ptr %l126
  store i64 %t283, ptr %l124
  br label %bb84
bb82:
  br label %bb83
bb83:
  store i64 -1, ptr %l124
  br label %bb84
bb84:
  %t284 = load i64, ptr %l124
  store i64 %t284, ptr %l11
  %t285 = load i64, ptr %l11
  store i64 %t285, ptr %l128
  %t286 = load i64, ptr %l128
  %t287 = icmp sge i64 %t286, 0
  store i1 %t287, ptr %l129
  %t288 = load i1, ptr %l129
  br i1 %t288, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s11
  %t289 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t289, ptr %l131
  %t290 = load i64, ptr %l11
  store i64 %t290, ptr %l132
  %t291 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t291, ptr %l133
  %t292 = load { i64, ptr }, ptr %l133
  store { i64, ptr } %t292, ptr %l134
  %t293 = load { i64, ptr }, ptr %l134
  %t294 = extractvalue { i64, ptr } %t293, 0
  store i64 %t294, ptr %l135
  %t295 = load { i64, ptr }, ptr %l131
  %t296 = extractvalue { i64, ptr } %t295, 0
  store i64 %t296, ptr %l136
  %t297 = load i64, ptr %l132
  %t298 = icmp sge i64 %t297, 0
  store i1 %t298, ptr %l137
  %t299 = load i1, ptr %l137
  br i1 %t299, label %bb87, label %bb88
bb86:
  br label %bb106
bb87:
  %t300 = load i64, ptr %l132
  %t301 = load i64, ptr %l135
  %t302 = icmp sle i64 %t300, %t301
  store i1 %t302, ptr %l138
  %t303 = load i1, ptr %l138
  br i1 %t303, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @.c108)
  unreachable
bb89:
  %t304 = load i64, ptr %l135
  %t305 = load i64, ptr %l136
  %t306 = icmp sle i64 %t304, %t305
  store i1 %t306, ptr %l139
  %t307 = load i1, ptr %l139
  br i1 %t307, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @.c108)
  unreachable
bb91:
  %t308 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t309 = load ptr, ptr %t308
  %t310 = load i64, ptr %l132
  %t311 = load i64, ptr %l135
  %t312 = getelementptr i8, ptr %t309, i64 %t310
  %t313 = sub i64 %t311, %t310
  %t314 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t312, 1
  store { i64, ptr } %t315, ptr %l140
  store i8 41, ptr %l141
  %t316 = load { i64, ptr }, ptr %l140
  %t317 = load i8, ptr %l141
  %t318 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t316, i8 %t317)
  %t319 = extractvalue { i32, i64 } %t318, 1
  %t320 = extractvalue { i32, i64 } %t318, 0
  store i32 %t320, ptr %l143
  %t321 = icmp ne i32 %t320, 0
  br i1 %t321, label %bb94, label %ok.322
ok.322:
  store i64 %t319, ptr %l142
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @.c108)
  unreachable
bb93:
  %t323 = load i64, ptr %l142
  store i64 %t323, ptr %l130
  br label %bb96
bb94:
  br label %bb95
bb95:
  store i64 -1, ptr %l130
  br label %bb96
bb96:
  %t324 = load i64, ptr %l130
  store i64 %t324, ptr %l12
  %t325 = load i64, ptr %l12
  store i64 %t325, ptr %l144
  %t326 = load i64, ptr %l144
  %t327 = icmp sge i64 %t326, 0
  store i1 %t327, ptr %l145
  %t328 = load i1, ptr %l145
  br i1 %t328, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s12
  %t329 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t329, ptr %l146
  %t330 = load i64, ptr %l11
  store i64 %t330, ptr %l147
  %t331 = load i64, ptr %l11
  store i64 %t331, ptr %l148
  %t332 = load i64, ptr %l12
  store i64 %t332, ptr %l149
  %t333 = load i64, ptr %l148
  %t334 = load i64, ptr %l149
  %t335 = add i64 %t333, %t334
  store i64 %t335, ptr %l150
  %t336 = load i64, ptr %l150
  %t337 = add i64 %t336, 1
  store i64 %t337, ptr %l151
  %t338 = load { i64, ptr }, ptr %l146
  %t339 = extractvalue { i64, ptr } %t338, 0
  store i64 %t339, ptr %l152
  %t340 = load i64, ptr %l147
  %t341 = icmp sge i64 %t340, 0
  store i1 %t341, ptr %l153
  %t342 = load i1, ptr %l153
  br i1 %t342, label %bb99, label %bb100
bb98:
  br label %bb105
bb99:
  %t343 = load i64, ptr %l147
  %t344 = load i64, ptr %l151
  %t345 = icmp sle i64 %t343, %t344
  store i1 %t345, ptr %l154
  %t346 = load i1, ptr %l154
  br i1 %t346, label %bb101, label %bb102
bb100:
  call void @__olang_check_failed(ptr @.c109)
  unreachable
bb101:
  %t347 = load i64, ptr %l151
  %t348 = load i64, ptr %l152
  %t349 = icmp sle i64 %t347, %t348
  store i1 %t349, ptr %l155
  %t350 = load i1, ptr %l155
  br i1 %t350, label %bb103, label %bb104
bb102:
  call void @__olang_check_failed(ptr @.c109)
  unreachable
bb103:
  %t351 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t352 = load ptr, ptr %t351
  %t353 = load i64, ptr %l147
  %t354 = load i64, ptr %l151
  %t355 = getelementptr i8, ptr %t352, i64 %t353
  %t356 = sub i64 %t354, %t353
  %t357 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t355, 1
  store { i64, ptr } %t358, ptr %l156
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t359 = extractvalue { i64, ptr } { i64 1, ptr @.d110 }, 1
  %t360 = extractvalue { i64, ptr } { i64 1, ptr @.d110 }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t359, i64 %t360)
  %t361 = load { i64, ptr }, ptr %l156
  %t362 = extractvalue { i64, ptr } %t361, 1
  %t363 = extractvalue { i64, ptr } %t361, 0
  call void @__olang_sb_put(ptr %s13, ptr %t362, i64 %t363)
  %t364 = load ptr, ptr %s13
  %t365 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t366 = load i64, ptr %t365
  %t367 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t366)
  call void @llvm.memcpy.p0.p0.i64(ptr %t367, ptr %t364, i64 %t366, i1 false)
  %t368 = insertvalue { i64, ptr } undef, i64 %t366, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t367, 1
  store { i64, ptr } %t369, ptr %l157
  call void @__olang_sb_done(ptr %s13)
  %t370 = load { i64, ptr }, ptr %l157
  %t371 = extractvalue { i64, ptr } %t370, 0
  %t372 = extractvalue { i64, ptr } %t370, 1
  %t373 = mul i64 %t371, 1
  %t374 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t374, ptr %t372, i64 %t373, i1 false)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  store { i64, ptr } %t376, ptr %l158
  %t377 = load { i64, ptr }, ptr %l158
  store { i64, ptr } %t377, ptr %l10
  call void @__olang_scope_close(ptr %s12)
  br label %bb105
bb104:
  call void @__olang_check_failed(ptr @.c109)
  unreachable
bb105:
  call void @__olang_scope_close(ptr %s11)
  br label %bb106
bb106:
  %t378 = load ptr, ptr %l0
  store ptr %t378, ptr %l159
  %t379 = load ptr, ptr %l159
  %t380 = getelementptr %"compiler/target:Target", ptr %t379, i32 0, i32 7
  %t381 = load i64, ptr %t380
  store i64 %t381, ptr %l160
  %t382 = load i64, ptr %l160
  %t383 = icmp sgt i64 %t382, 0
  store i1 %t383, ptr %l161
  %t384 = load i1, ptr %l161
  br i1 %t384, label %bb107, label %bb108
bb107:
  %t385 = load ptr, ptr %l0
  store ptr %t385, ptr %l163
  %t386 = load ptr, ptr %l163
  %t387 = getelementptr %"compiler/target:Target", ptr %t386, i32 0, i32 7
  %t388 = load i64, ptr %t387
  store i64 %t388, ptr %l164
  %t389 = load i64, ptr %l164
  store i64 %t389, ptr %l162
  br label %bb109
bb108:
  store i64 128, ptr %l162
  br label %bb109
bb109:
  %t390 = load i64, ptr %l162
  store i64 %t390, ptr %l13
  %t391 = load ptr, ptr %l0
  store ptr %t391, ptr %l165
  %t392 = load ptr, ptr %l0
  store ptr %t392, ptr %l166
  %t393 = load ptr, ptr %l166
  %t394 = getelementptr %"compiler/target:Target", ptr %t393, i32 0, i32 4
  %t395 = load { i64, ptr }, ptr %t394
  store { i64, ptr } %t395, ptr %l167
  %t396 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t396, ptr %l168
  %t397 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t397, ptr %l169
  %t398 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t398, ptr %l170
  %t399 = load i64, ptr %l13
  store i64 %t399, ptr %l171
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t400 = extractvalue { i64, ptr } { i64 14, ptr @.d111 }, 1
  %t401 = extractvalue { i64, ptr } { i64 14, ptr @.d111 }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t400, i64 %t401)
  %t402 = load { i64, ptr }, ptr %l167
  %t403 = extractvalue { i64, ptr } %t402, 1
  %t404 = extractvalue { i64, ptr } %t402, 0
  call void @__olang_sb_put(ptr %s14, ptr %t403, i64 %t404)
  %t405 = extractvalue { i64, ptr } { i64 21, ptr @.d112 }, 1
  %t406 = extractvalue { i64, ptr } { i64 21, ptr @.d112 }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t405, i64 %t406)
  %t407 = load { i64, ptr }, ptr %l168
  %t408 = extractvalue { i64, ptr } %t407, 1
  %t409 = extractvalue { i64, ptr } %t407, 0
  call void @__olang_sb_put(ptr %s14, ptr %t408, i64 %t409)
  %t410 = extractvalue { i64, ptr } { i64 1, ptr @.d113 }, 1
  %t411 = extractvalue { i64, ptr } { i64 1, ptr @.d113 }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t410, i64 %t411)
  %t412 = load { i64, ptr }, ptr %l169
  %t413 = extractvalue { i64, ptr } %t412, 1
  %t414 = extractvalue { i64, ptr } %t412, 0
  call void @__olang_sb_put(ptr %s14, ptr %t413, i64 %t414)
  %t415 = load { i64, ptr }, ptr %l170
  %t416 = extractvalue { i64, ptr } %t415, 1
  %t417 = extractvalue { i64, ptr } %t415, 0
  call void @__olang_sb_put(ptr %s14, ptr %t416, i64 %t417)
  %t418 = extractvalue { i64, ptr } { i64 24, ptr @.d114 }, 1
  %t419 = extractvalue { i64, ptr } { i64 24, ptr @.d114 }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t418, i64 %t419)
  %t420 = load i64, ptr %l171
  %t421 = call ptr @__olang_sb_room(ptr %s14, i64 24)
  %t422 = call i64 @__olang_fmt_i64(ptr %t421, i64 %t420)
  call void @__olang_sb_add(ptr %s14, i64 %t422)
  %t423 = extractvalue { i64, ptr } { i64 1, ptr @.d115 }, 1
  %t424 = extractvalue { i64, ptr } { i64 1, ptr @.d115 }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t423, i64 %t424)
  %t425 = load ptr, ptr %s14
  %t426 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t427 = load i64, ptr %t426
  %t428 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t427)
  call void @llvm.memcpy.p0.p0.i64(ptr %t428, ptr %t425, i64 %t427, i1 false)
  %t429 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  store { i64, ptr } %t430, ptr %l172
  call void @__olang_sb_done(ptr %s14)
  %t431 = load { i64, ptr }, ptr %l172
  %t432 = extractvalue { i64, ptr } %t431, 0
  %t433 = extractvalue { i64, ptr } %t431, 1
  %t434 = mul i64 %t432, 1
  %t435 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t434)
  call void @llvm.memcpy.p0.p0.i64(ptr %t435, ptr %t433, i64 %t434, i1 false)
  %t436 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  store { i64, ptr } %t437, ptr %l173
  %t438 = load { i64, ptr }, ptr %l173
  %t439 = load ptr, ptr %l165
  %t440 = getelementptr %"compiler/target:Target", ptr %t439, i32 0, i32 5
  store { i64, ptr } %t438, ptr %t440
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2ewithoutClang(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i1
  %l57 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l0
  store ptr %t2, ptr %l5
  %t3 = load ptr, ptr %l5
  %t4 = getelementptr %"compiler/target:Target", ptr %t3, i32 0, i32 2
  %t5 = load { i64, ptr }, ptr %t4
  store { i64, ptr } %t5, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t6 = load { i64, ptr }, ptr %l6
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 18, ptr @.d116 }, 1
  %t10 = extractvalue { i64, ptr } { i64 18, ptr @.d116 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l7
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l8
  %t24 = load { i64, ptr }, ptr %l8
  %t25 = load ptr, ptr %l4
  %t26 = getelementptr %"compiler/target:Target", ptr %t25, i32 0, i32 1
  store { i64, ptr } %t24, ptr %t26
  %t27 = load ptr, ptr %l0
  store ptr %t27, ptr %l9
  %t28 = load ptr, ptr %l9
  %t29 = getelementptr %"compiler/target:Target", ptr %t28, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29
  store { i64, ptr } %t30, ptr %l10
  %t31 = load { i64, ptr }, ptr %l10
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 7, ptr @.d117 })
  store i1 %t32, ptr %l11
  br label %bb1
bb1:
  %t33 = load i1, ptr %l11
  br i1 %t33, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t34, ptr %l12
  %t35 = load { i64, ptr }, ptr %l12
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t35, { i64, ptr } { i64 6, ptr @.d118 })
  store i1 %t36, ptr %l13
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t37 = load i1, ptr %l13
  %t38 = xor i1 %t37, true
  store i1 %t38, ptr %l14
  %t39 = load i1, ptr %l14
  br i1 %t39, label %bb5, label %bb6
bb5:
  %t40 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t40, ptr %l16
  %t41 = load { i64, ptr }, ptr %l16
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 7, ptr @.d119 })
  store i1 %t42, ptr %l17
  br label %bb7
bb6:
  store i1 false, ptr %l15
  br label %bb8
bb7:
  %t43 = load i1, ptr %l17
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l18
  %t45 = load i1, ptr %l18
  store i1 %t45, ptr %l15
  br label %bb8
bb8:
  %t46 = load i1, ptr %l15
  br i1 %t46, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 false, ptr %l19
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t47 = load i1, ptr %l19
  store i1 %t47, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t48 = load ptr, ptr %l0
  store ptr %t48, ptr %l20
  %t49 = load ptr, ptr %l20
  %t50 = getelementptr %"compiler/target:Target", ptr %t49, i32 0, i32 4
  store { i64, ptr } { i64 7, ptr @.d120 }, ptr %t50
  %t51 = load ptr, ptr %l0
  store ptr %t51, ptr %l21
  %t52 = load ptr, ptr %l21
  %t53 = getelementptr %"compiler/target:Target", ptr %t52, i32 0, i32 7
  store i64 128, ptr %t53
  %t54 = load ptr, ptr %l0
  store ptr %t54, ptr %l22
  %t55 = load ptr, ptr %l22
  %t56 = getelementptr %"compiler/target:Target", ptr %t55, i32 0, i32 8
  store i1 true, ptr %t56
  store i1 true, ptr %l23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i1, ptr %l23
  store i1 %t57, ptr %rv
  br label %ret
bb12:
  %t58 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t58, ptr %l25
  %t59 = load { i64, ptr }, ptr %l25
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t59, { i64, ptr } { i64 6, ptr @.d121 })
  store i1 %t60, ptr %l26
  br label %bb13
bb13:
  %t61 = load i1, ptr %l26
  br i1 %t61, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  store i64 1, ptr %l24
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb17:
  %t62 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t62, ptr %l27
  %t63 = load { i64, ptr }, ptr %l27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t63, { i64, ptr } { i64 9, ptr @.d122 })
  store i1 %t64, ptr %l28
  br label %bb18
bb18:
  %t65 = load i1, ptr %l28
  br i1 %t65, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  store i64 2, ptr %l24
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb22:
  %t66 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t66, ptr %l29
  %t67 = load { i64, ptr }, ptr %l29
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t67, { i64, ptr } { i64 9, ptr @.d123 })
  store i1 %t68, ptr %l30
  br label %bb23
bb23:
  %t69 = load i1, ptr %l30
  br i1 %t69, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  store i64 3, ptr %l24
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb27:
  %t70 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t70, ptr %l31
  %t71 = load { i64, ptr }, ptr %l31
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t71, { i64, ptr } { i64 9, ptr @.d124 })
  store i1 %t72, ptr %l32
  br label %bb28
bb28:
  %t73 = load i1, ptr %l32
  br i1 %t73, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  store i64 4, ptr %l24
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb32:
  %t74 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t74, ptr %l33
  %t75 = load { i64, ptr }, ptr %l33
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t75, { i64, ptr } { i64 6, ptr @.d125 })
  store i1 %t76, ptr %l34
  br label %bb33
bb33:
  %t77 = load i1, ptr %l34
  br i1 %t77, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb38
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t78 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t78, ptr %l35
  %t79 = load { i64, ptr }, ptr %l35
  %t80 = call i64 @compiler_2ftarget_2eX86Level(ptr %v2, { i64, ptr } %t79)
  store i64 %t80, ptr %l36
  br label %bb37
bb37:
  %t81 = load i64, ptr %l36
  store i64 %t81, ptr %l24
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  store i64 0, ptr %l24
  call void @__olang_scope_close(ptr %s9)
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @.c126)
  unreachable
bb43:
  %t82 = load i64, ptr %l24
  store i64 %t82, ptr %l3
  %t83 = load i64, ptr %l3
  store i64 %t83, ptr %l37
  %t84 = load i64, ptr %l37
  %t85 = icmp eq i64 %t84, 0
  store i1 %t85, ptr %l38
  %t86 = load i1, ptr %l38
  br i1 %t86, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  store i1 false, ptr %l39
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i1, ptr %l39
  store i1 %t87, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t88 = load ptr, ptr %l0
  store ptr %t88, ptr %l40
  %t89 = load i64, ptr %l3
  store i64 %t89, ptr %l41
  %t90 = load i64, ptr %l41
  %t91 = icmp eq i64 %t90, 1
  store i1 %t91, ptr %l42
  %t92 = load i1, ptr %l42
  br i1 %t92, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 6, ptr @.d127 }, ptr %l43
  br label %bb49
bb48:
  %t93 = load i64, ptr %l3
  store i64 %t93, ptr %l44
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  %t94 = extractvalue { i64, ptr } { i64 8, ptr @.d128 }, 1
  %t95 = extractvalue { i64, ptr } { i64 8, ptr @.d128 }, 0
  call void @__olang_sb_put(ptr %s11, ptr %t94, i64 %t95)
  %t96 = load i64, ptr %l44
  %t97 = call ptr @__olang_sb_room(ptr %s11, i64 24)
  %t98 = call i64 @__olang_fmt_i64(ptr %t97, i64 %t96)
  call void @__olang_sb_add(ptr %s11, i64 %t98)
  %t99 = load ptr, ptr %s11
  %t100 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t101 = load i64, ptr %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t99, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l45
  call void @__olang_sb_done(ptr %s11)
  %t105 = load { i64, ptr }, ptr %l45
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l46
  %t112 = load { i64, ptr }, ptr %l46
  store { i64, ptr } %t112, ptr %l43
  br label %bb49
bb49:
  %t113 = load { i64, ptr }, ptr %l43
  %t114 = load ptr, ptr %l40
  %t115 = getelementptr %"compiler/target:Target", ptr %t114, i32 0, i32 4
  store { i64, ptr } %t113, ptr %t115
  %t116 = load ptr, ptr %l0
  store ptr %t116, ptr %l47
  %t117 = load i64, ptr %l3
  store i64 %t117, ptr %l48
  %t118 = load i64, ptr %l48
  %t119 = icmp eq i64 %t118, 4
  store i1 %t119, ptr %l49
  %t120 = load i1, ptr %l49
  br i1 %t120, label %bb50, label %bb51
bb50:
  store i64 512, ptr %l50
  br label %bb55
bb51:
  %t121 = load i64, ptr %l3
  store i64 %t121, ptr %l51
  %t122 = load i64, ptr %l51
  %t123 = icmp eq i64 %t122, 3
  store i1 %t123, ptr %l52
  %t124 = load i1, ptr %l52
  br i1 %t124, label %bb52, label %bb53
bb52:
  store i64 256, ptr %l53
  br label %bb54
bb53:
  store i64 128, ptr %l53
  br label %bb54
bb54:
  %t125 = load i64, ptr %l53
  store i64 %t125, ptr %l50
  br label %bb55
bb55:
  %t126 = load i64, ptr %l50
  %t127 = load ptr, ptr %l47
  %t128 = getelementptr %"compiler/target:Target", ptr %t127, i32 0, i32 7
  store i64 %t126, ptr %t128
  %t129 = load ptr, ptr %l0
  store ptr %t129, ptr %l54
  %t130 = load i64, ptr %l3
  store i64 %t130, ptr %l55
  %t131 = load i64, ptr %l55
  %t132 = icmp sge i64 %t131, 3
  store i1 %t132, ptr %l56
  %t133 = load i1, ptr %l56
  %t134 = load ptr, ptr %l54
  %t135 = getelementptr %"compiler/target:Target", ptr %t134, i32 0, i32 8
  store i1 %t133, ptr %t135
  store i1 true, ptr %l57
  call void @__olang_scope_close(ptr %s0)
  %t136 = load i1, ptr %l57
  store i1 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2ecpuFlags(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:LineIter"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i8
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } { i64 13, ptr @.d129 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l6
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t6, ptr %l4
  br label %bb6
bb2:
  %t7 = load i32, ptr %l6
  %t8 = ashr i32 %t7, 16
  store i32 %t8, ptr %l7
  %t9 = load i32, ptr %l7
  %t10 = icmp eq i32 %t9, 1
  store i1 %t10, ptr %l8
  %t11 = load i1, ptr %l8
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c130)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr @.d131 }, ptr %l9
  %t12 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t12, ptr %l10
  %t13 = load { i64, ptr }, ptr %l10
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l11
  %t15 = load i64, ptr %l11
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l12
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20
  %t22 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t24 = load i64, ptr %l11
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t26, ptr %l10
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t27 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb6:
  %t28 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t28, ptr %l0
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t29, ptr %l13
  %t30 = load { i64, ptr }, ptr %l13
  %t31 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t30)
  store %"std/prelude/text:LineIter" %t31, ptr %l14
  br label %bb7
bb7:
  %t32 = load %"std/prelude/text:LineIter", ptr %l14
  store %"std/prelude/text:LineIter" %t32, ptr %l1
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l1, ptr %l16
  %t33 = load ptr, ptr %l16
  %t34 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %t33)
  %t35 = extractvalue { i32, { i64, ptr } } %t34, 1
  %t36 = extractvalue { i32, { i64, ptr } } %t34, 0
  store i32 %t36, ptr %l18
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38
ok.38:
  store { i64, ptr } %t35, ptr %l17
  br label %bb9
bb9:
  %t39 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t39, ptr %l15
  br label %bb14
bb10:
  %t40 = load i32, ptr %l18
  %t41 = ashr i32 %t40, 16
  store i32 %t41, ptr %l19
  %t42 = load i32, ptr %l19
  %t43 = icmp eq i32 %t42, 1
  store i1 %t43, ptr %l20
  %t44 = load i1, ptr %l20
  br i1 %t44, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @.c132)
  unreachable
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb14:
  %t45 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t45, ptr %l2
  %t46 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t46, ptr %l21
  %t47 = load { i64, ptr }, ptr %l21
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s3, { i64, ptr } %t47, { i64, ptr } { i64 5, ptr @.d133 })
  store i1 %t48, ptr %l22
  br label %bb15
bb15:
  %t49 = load i1, ptr %l22
  br i1 %t49, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t50, ptr %l24
  store i8 58, ptr %l25
  %t51 = load { i64, ptr }, ptr %l24
  %t52 = load i8, ptr %l25
  %t53 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %s0, { i64, ptr } %t51, i8 %t52)
  %t54 = extractvalue { i32, i64 } %t53, 1
  %t55 = extractvalue { i32, i64 } %t53, 0
  store i32 %t55, ptr %l27
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb19, label %ok.57
ok.57:
  store i64 %t54, ptr %l26
  br label %bb18
bb17:
  br label %bb29
bb18:
  %t58 = load i64, ptr %l26
  store i64 %t58, ptr %l23
  br label %bb21
bb19:
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  store { i64, ptr } { i64 0, ptr @.d134 }, ptr %l28
  %t59 = load { i64, ptr }, ptr %l28
  store { i64, ptr } %t59, ptr %l29
  %t60 = load { i64, ptr }, ptr %l29
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l30
  %t62 = load i64, ptr %l30
  %t63 = mul i64 %t62, 1
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l31
  %t67 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  %t69 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t70 = load ptr, ptr %t69
  %t71 = load i64, ptr %l30
  %t72 = mul i64 %t71, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t68, ptr %t70, i64 %t72, i1 false)
  %t73 = load { i64, ptr }, ptr %l31
  store { i64, ptr } %t73, ptr %l29
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t74, ptr %rv
  br label %ret
bb21:
  %t75 = load i64, ptr %l23
  store i64 %t75, ptr %l3
  %t76 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t76, ptr %l32
  %t77 = load i64, ptr %l3
  store i64 %t77, ptr %l33
  %t78 = load i64, ptr %l33
  %t79 = add i64 %t78, 1
  store i64 %t79, ptr %l34
  %t80 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t80, ptr %l35
  %t81 = load { i64, ptr }, ptr %l35
  store { i64, ptr } %t81, ptr %l36
  %t82 = load { i64, ptr }, ptr %l36
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l37
  %t84 = load { i64, ptr }, ptr %l32
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l38
  %t86 = load i64, ptr %l34
  %t87 = icmp sge i64 %t86, 0
  store i1 %t87, ptr %l39
  %t88 = load i1, ptr %l39
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t89 = load i64, ptr %l34
  %t90 = load i64, ptr %l37
  %t91 = icmp sle i64 %t89, %t90
  store i1 %t91, ptr %l40
  %t92 = load i1, ptr %l40
  br i1 %t92, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c135)
  unreachable
bb24:
  %t93 = load i64, ptr %l37
  %t94 = load i64, ptr %l38
  %t95 = icmp sle i64 %t93, %t94
  store i1 %t95, ptr %l41
  %t96 = load i1, ptr %l41
  br i1 %t96, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c135)
  unreachable
bb26:
  %t97 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t98 = load ptr, ptr %t97
  %t99 = load i64, ptr %l34
  %t100 = load i64, ptr %l37
  %t101 = getelementptr i8, ptr %t98, i64 %t99
  %t102 = sub i64 %t100, %t99
  %t103 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t101, 1
  store { i64, ptr } %t104, ptr %l42
  %t105 = load { i64, ptr }, ptr %l42
  %t106 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t105)
  store { i64, ptr } %t106, ptr %l43
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @.c135)
  unreachable
bb28:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t107 = extractvalue { i64, ptr } { i64 1, ptr @.d136 }, 1
  %t108 = extractvalue { i64, ptr } { i64 1, ptr @.d136 }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t107, i64 %t108)
  %t109 = load { i64, ptr }, ptr %l43
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  call void @__olang_sb_put(ptr %s6, ptr %t110, i64 %t111)
  %t112 = extractvalue { i64, ptr } { i64 1, ptr @.d137 }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr @.d137 }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t112, i64 %t113)
  %t114 = load ptr, ptr %s6
  %t115 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t116 = load i64, ptr %t115
  %t117 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t114, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l44
  call void @__olang_sb_done(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, ptr }, ptr %l44
  store { i64, ptr } %t120, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  br label %bb8
bb31:
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } { i64 0, ptr @.d138 }, ptr %l45
  %t121 = load { i64, ptr }, ptr %l45
  store { i64, ptr } %t121, ptr %l46
  %t122 = load { i64, ptr }, ptr %l46
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l47
  %t124 = load i64, ptr %l47
  %t125 = mul i64 %t124, 1
  %t126 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l48
  %t129 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t130 = load ptr, ptr %t129
  %t131 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t132 = load ptr, ptr %t131
  %t133 = load i64, ptr %l47
  %t134 = mul i64 %t133, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t130, ptr %t132, i64 %t134, i1 false)
  %t135 = load { i64, ptr }, ptr %l48
  store { i64, ptr } %t135, ptr %l46
  call void @__olang_scope_close(ptr %s0)
  %t136 = load { i64, ptr }, ptr %l46
  store { i64, ptr } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i8
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l6
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l7
  %t3 = load { i64, ptr }, ptr %l6
  %t4 = load { i64, ptr }, ptr %l7
  %t5 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %t3, { i64, ptr } %t4)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l9
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store i64 %t6, ptr %l8
  br label %bb1
bb1:
  %t10 = load i64, ptr %l8
  store i64 %t10, ptr %l5
  br label %bb3
bb2:
  %t11 = load i32, ptr %l9
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  store i32 %t19, ptr %l10
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i32, ptr %l10
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t20, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load i64, ptr %l5
  store i64 %t22, ptr %l2
  %t23 = load i64, ptr %l2
  store i64 %t23, ptr %l11
  %t24 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t24, ptr %l12
  %t25 = load { i64, ptr }, ptr %l12
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l13
  %t27 = load i64, ptr %l11
  %t28 = load i64, ptr %l13
  %t29 = add i64 %t27, %t28
  store i64 %t29, ptr %l14
  %t30 = load i64, ptr %l14
  store i64 %t30, ptr %l3
  %t31 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t31, ptr %l16
  %t32 = load i64, ptr %l3
  store i64 %t32, ptr %l17
  %t33 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t33, ptr %l18
  %t34 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t34, ptr %l19
  %t35 = load { i64, ptr }, ptr %l19
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l20
  %t37 = load { i64, ptr }, ptr %l16
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l21
  %t39 = load i64, ptr %l17
  %t40 = icmp sge i64 %t39, 0
  store i1 %t40, ptr %l22
  %t41 = load i1, ptr %l22
  br i1 %t41, label %bb4, label %bb5
bb4:
  %t42 = load i64, ptr %l17
  %t43 = load i64, ptr %l20
  %t44 = icmp sle i64 %t42, %t43
  store i1 %t44, ptr %l23
  %t45 = load i1, ptr %l23
  br i1 %t45, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c139)
  unreachable
bb6:
  %t46 = load i64, ptr %l20
  %t47 = load i64, ptr %l21
  %t48 = icmp sle i64 %t46, %t47
  store i1 %t48, ptr %l24
  %t49 = load i1, ptr %l24
  br i1 %t49, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @.c139)
  unreachable
bb8:
  %t50 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  %t52 = load i64, ptr %l17
  %t53 = load i64, ptr %l20
  %t54 = getelementptr i8, ptr %t51, i64 %t52
  %t55 = sub i64 %t53, %t52
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  store { i64, ptr } %t57, ptr %l25
  store i8 34, ptr %l26
  %t58 = load { i64, ptr }, ptr %l25
  %t59 = load i8, ptr %l26
  %t60 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t58, i8 %t59)
  %t61 = extractvalue { i32, i64 } %t60, 1
  %t62 = extractvalue { i32, i64 } %t60, 0
  store i32 %t62, ptr %l28
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb11, label %ok.64
ok.64:
  store i64 %t61, ptr %l27
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @.c139)
  unreachable
bb10:
  %t65 = load i64, ptr %l27
  store i64 %t65, ptr %l15
  br label %bb12
bb11:
  %t66 = load i32, ptr %l28
  %t67 = lshr i32 %t66, 16
  %t68 = and i32 %t66, 65535
  %t69 = icmp eq i32 %t67, 1
  %t70 = select i1 %t69, i32 1, i32 0
  %t71 = icmp eq i32 %t66, 0
  %t72 = shl i32 %t70, 16
  %t73 = or i32 %t72, %t68
  %t74 = select i1 %t71, i32 0, i32 %t73
  store i32 %t74, ptr %l29
  call void @__olang_scope_close(ptr %s0)
  %t75 = load i32, ptr %l29
  %t76 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t75, 0
  store { i32, { i64, ptr } } %t76, ptr %rv
  br label %ret
bb12:
  %t77 = load i64, ptr %l15
  store i64 %t77, ptr %l4
  %t78 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t78, ptr %l30
  %t79 = load i64, ptr %l3
  store i64 %t79, ptr %l31
  %t80 = load i64, ptr %l3
  store i64 %t80, ptr %l32
  %t81 = load i64, ptr %l4
  store i64 %t81, ptr %l33
  %t82 = load i64, ptr %l32
  %t83 = load i64, ptr %l33
  %t84 = add i64 %t82, %t83
  store i64 %t84, ptr %l34
  %t85 = load { i64, ptr }, ptr %l30
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l35
  %t87 = load i64, ptr %l31
  %t88 = icmp sge i64 %t87, 0
  store i1 %t88, ptr %l36
  %t89 = load i1, ptr %l36
  br i1 %t89, label %bb13, label %bb14
bb13:
  %t90 = load i64, ptr %l31
  %t91 = load i64, ptr %l34
  %t92 = icmp sle i64 %t90, %t91
  store i1 %t92, ptr %l37
  %t93 = load i1, ptr %l37
  br i1 %t93, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c140)
  unreachable
bb15:
  %t94 = load i64, ptr %l34
  %t95 = load i64, ptr %l35
  %t96 = icmp sle i64 %t94, %t95
  store i1 %t96, ptr %l38
  %t97 = load i1, ptr %l38
  br i1 %t97, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c140)
  unreachable
bb17:
  %t98 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  %t100 = load i64, ptr %l31
  %t101 = load i64, ptr %l34
  %t102 = getelementptr i8, ptr %t99, i64 %t100
  %t103 = sub i64 %t101, %t100
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  store { i64, ptr } %t105, ptr %l39
  call void @__olang_scope_close(ptr %s0)
  %t106 = load { i64, ptr }, ptr %l39
  %t107 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t106, 1
  store { i32, { i64, ptr } } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @.c140)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2ftarget_2erefuse(ptr %v0, ptr %v1, ptr %a0, %"compiler/msgs:Msg" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/msgs:Msg"
  %l2 = alloca ptr
  %l3 = alloca { i64, [3 x i64] }
  %l4 = alloca %"compiler/msgs:Msg"
  %l5 = alloca i64
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/msgs:Msg" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l2
  store { i64, [3 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [3 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [3 x i64] }, ptr %t2
  store { i64, [3 x i64] } %t4, ptr %l3
  %t5 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t5, ptr %l4
  %t6 = load ptr, ptr %l2
  %t7 = load { i64, [3 x i64] }, ptr %l3
  %t8 = load %"compiler/msgs:Msg", ptr %l4
  %t9 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %t6, { i64, [3 x i64] } %t7, %"compiler/msgs:Msg" %t8)
  store i64 %t9, ptr %l5
  br label %bb1
bb1:
  store i32 65536, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i32, ptr %l6
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca %"compiler/target:Target"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/target:Target"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 6, ptr @.d141 }, ptr %l0
  store { i64, ptr } { i64 0, ptr @.d142 }, ptr %l1
  store { i64, ptr } { i64 0, ptr @.d143 }, ptr %l2
  store { i64, ptr } { i64 5, ptr @.d144 }, ptr %l3
  store { i64, ptr } { i64 0, ptr @.d145 }, ptr %l4
  store { i64, ptr } { i64 0, ptr @.d146 }, ptr %l5
  store { i64, ptr } { i64 0, ptr @.d147 }, ptr %l6
  store i64 0, ptr %l7
  store i1 false, ptr %l8
  store i1 false, ptr %l9
  %t1 = load { i64, ptr }, ptr %l0
  %t2 = insertvalue %"compiler/target:Target" undef, { i64, ptr } %t1, 0
  %t3 = load { i64, ptr }, ptr %l1
  %t4 = insertvalue %"compiler/target:Target" %t2, { i64, ptr } %t3, 1
  %t5 = load { i64, ptr }, ptr %l2
  %t6 = insertvalue %"compiler/target:Target" %t4, { i64, ptr } %t5, 2
  %t7 = load { i64, ptr }, ptr %l3
  %t8 = insertvalue %"compiler/target:Target" %t6, { i64, ptr } %t7, 3
  %t9 = load { i64, ptr }, ptr %l4
  %t10 = insertvalue %"compiler/target:Target" %t8, { i64, ptr } %t9, 4
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/target:Target" %t10, { i64, ptr } %t11, 5
  %t13 = load { i64, ptr }, ptr %l6
  %t14 = insertvalue %"compiler/target:Target" %t12, { i64, ptr } %t13, 6
  %t15 = load i64, ptr %l7
  %t16 = insertvalue %"compiler/target:Target" %t14, i64 %t15, 7
  %t17 = load i1, ptr %l8
  %t18 = insertvalue %"compiler/target:Target" %t16, i1 %t17, 8
  %t19 = load i1, ptr %l9
  %t20 = insertvalue %"compiler/target:Target" %t18, i1 %t19, 9
  store %"compiler/target:Target" %t20, ptr %l10
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/target:Target", ptr %l10
  store %"compiler/target:Target" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/target:Target", ptr %rv
  ret %"compiler/target:Target" %rr
}

define dso_local void @olang_2einit_2ecompiler_2ftarget() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2ftarget_2eArchs_2einit()
  br label %bb1
bb1:
  call void @compiler_2ftarget_2eArchCpuFlags_2einit()
  br label %bb2
bb2:
  call void @compiler_2ftarget_2eArchDefaultCpus_2einit()
  br label %bb3
bb3:
  call void @compiler_2ftarget_2eIeeeUnsafe_2einit()
  br label %bb4
bb4:
  call void @compiler_2ftarget_2eLevelFlags_2einit()
  br label %bb5
bb5:
  call void @compiler_2ftarget_2eSkylakeProbe_2einit()
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d0 = private constant [7 x i8] c"-march="
@.d1 = private constant [6 x i8] c"-mcpu="
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare ptr @__olang_scope_alloc(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_scope_close(ptr)
@.d2 = private constant [6 x i8] c"x86-64"
@.d3 = private constant [7 x i8] c"generic"
@.d4 = private constant [6 x i8] c"x86_64"
@.d5 = private constant [7 x i8] c"aarch64"
@.d6 = private constant [4 x i8] c"PATH"
@.d7 = private constant [0 x i8] c""
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d8 = private constant [0 x i8] c""
@.d9 = private constant [28 x i8] c"/usr/local/bin:/usr/bin:/bin"
@.d10 = private constant [8 x i8] c"clang-20"
@.d11 = private constant [5 x i8] c"clang"
declare ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d12 = private constant [1 x i8] c":"
@.d13 = private constant [0 x i8] c""
declare void @__olang_sb_put(ptr, ptr, i64)
@.d14 = private constant [1 x i8] c"/"
declare void @__olang_sb_done(ptr)
@.d15 = private constant [1 x i8] c"\00"
declare i32 @access(ptr, i32)
@.d16 = private constant [0 x i8] c""
declare ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d17 = private constant [1 x i8] c","
declare void @__olang_check_failed(ptr)
@.c18 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:234: slice bounds out of range\0A\00"
declare i32 @uname(ptr)
@.c19 = private unnamed_addr constant [53 x i8] c"compiler/target.olang:62: array length out of range\0A\00"
@.d20 = private constant [7 x i8] c"unknown"
@.d21 = private constant [7 x i8] c"unknown"
@.d22 = private constant [10 x i8] c"avx512bf16"
@.d23 = private constant [12 x i8] c"avxneconvert"
@.d24 = private constant [39 x i8] c"cx16 lahf_lm popcnt sse4_1 sse4_2 ssse3"
@.d25 = private constant [43 x i8] c"avx avx2 bmi1 bmi2 f16c fma abm movbe xsave"
@.d26 = private constant [43 x i8] c"avx512f avx512bw avx512cd avx512dq avx512vl"
@.d27 = private constant [0 x i8] c""
@.c28 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:113: slice bounds out of range\0A\00"
@.d29 = private constant [6 x i8] c"-linux"
@.c30 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:116: slice bounds out of range\0A\00"
@.d31 = private constant [0 x i8] c""
@.c32 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:118: slice bounds out of range\0A\00"
@.d33 = private constant [10 x i8] c"-linux-gnu"
@.d34 = private constant [0 x i8] c""
@.d35 = private constant [1 x i8] c":"
@.d36 = private constant [6 x i8] c"-apple"
@.d37 = private constant [8 x i8] c"-windows"
@.d38 = private constant [1 x i8] c":"
@.d39 = private constant [0 x i8] c""
@.d40 = private constant [5 x i8] c"linux"
@.d41 = private constant [0 x i8] c""
@.d42 = private constant [0 x i8] c""
@.d43 = private constant [6 x i8] c"native"
@.d44 = private constant [9 x i8] c"interpret"
@.d45 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

@.d46 = private constant [0 x i8] c""
@.d47 = private constant [9 x i8] c"--target="
@.d48 = private constant [2 x i8] c"-S"
@.d49 = private constant [10 x i8] c"-emit-llvm"
@.d50 = private constant [2 x i8] c"-o"
@.d51 = private constant [1 x i8] c"-"
@.d52 = private constant [2 x i8] c"-x"
@.d53 = private constant [1 x i8] c"c"
@.d54 = private constant [1 x i8] c"-"
@.d55 = private constant [34 x i8] c"void olang_target_probe(void) { }\0A"
@.d56 = private constant [0 x i8] c""
@.c57 = private unnamed_addr constant [53 x i8] c"compiler/target.olang:158: reached unreachable code\0A\00"
@.d58 = private constant [102 x i8] c"target datalayout = \22e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128\22\0A"
@.d59 = private constant [38 x i8] c"target triple = \22x86_64-pc-linux-gnu\22\0A"
@.d60 = private constant [66 x i8] c"attributes #0 = { noinline nounwind \22target-cpu\22=\22skylake-avx512\22 "
@.d61 = private constant [94 x i8] c"\22target-features\22=\22+avx,+avx512bf16,+avx512f,+fma,-avxneconvert,+sse2\22 \22tune-cpu\22=\22generic\22 }\0A"
@.d62 = private constant [0 x i8] c""
@.d63 = private constant [0 x i8] c""
@.d64 = private constant [1 x i8] c","
@.c65 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:245: slice bounds out of range\0A\00"
@.c66 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:248: slice bounds out of range\0A\00"
@.d67 = private constant [1 x i8] c" "
@.d68 = private constant [1 x i8] c" "
@.d69 = private constant [1 x i8] c" "
@.d70 = private constant [1 x i8] c"\22"
@.d71 = private constant [3 x i8] c"\22=\22"
@.d72 = private constant [88 x i8] c"define float @f(float %x) {\0A  %b = fptrunc float %x to bfloat\0A  %c = fadd bfloat %b, %b\0A"
@.d73 = private constant [49 x i8] c"  %r = fpext bfloat %c to float\0A  ret float %r\0A}\0A"
@.d74 = private constant [9 x i8] c"--target="
@.d75 = private constant [22 x i8] c"-fno-crash-diagnostics"
@.d76 = private constant [2 x i8] c"-c"
@.d77 = private constant [2 x i8] c"-x"
@.d78 = private constant [2 x i8] c"ir"
@.d79 = private constant [1 x i8] c"-"
@.d80 = private constant [2 x i8] c"-o"
@.d81 = private constant [9 x i8] c"/dev/null"
@.d82 = private constant [0 x i8] c""
@.c83 = private unnamed_addr constant [53 x i8] c"compiler/target.olang:261: reached unreachable code\0A\00"
@.d84 = private constant [17 x i8] c"target triple = \22"
@.d85 = private constant [21 x i8] c"target datalayout = \22"
@.d86 = private constant [17 x i8] c"attributes #0 = {"
@.c87 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:187: slice bounds out of range\0A\00"
@.c88 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:188: slice bounds out of range\0A\00"
@.d89 = private constant [5 x i8] c"-p:32"
@.d90 = private constant [5 x i8] c"-p:16"
@.d91 = private constant [10 x i8] c"target-cpu"
@.d92 = private constant [15 x i8] c"target-features"
@.d93 = private constant [0 x i8] c""
@.d94 = private constant [7 x i8] c"aarch64"
@.d95 = private constant [4 x i8] c"neon"
@.d96 = private constant [7 x i8] c"avx512f"
@.d97 = private constant [3 x i8] c"avx"
@.d98 = private constant [3 x i8] c"fma"
@.d99 = private constant [4 x i8] c"fma4"
@.d100 = private constant [8 x i8] c"tune-cpu"
@.d101 = private constant [0 x i8] c""
@.d102 = private constant [0 x i8] c""
@.d103 = private constant [13 x i8] c" \22tune-cpu\22=\22"
@.d104 = private constant [1 x i8] c"\22"
@.d105 = private constant [0 x i8] c""
@.d106 = private constant [0 x i8] c""
@.d107 = private constant [13 x i8] c"vscale_range("
@.c108 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:210: slice bounds out of range\0A\00"
@.c109 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:211: slice bounds out of range\0A\00"
@.d110 = private constant [1 x i8] c" "
@.d111 = private constant [14 x i8] c"\22target-cpu\22=\22"
@.d112 = private constant [21 x i8] c"\22 \22target-features\22=\22"
@.d113 = private constant [1 x i8] c"\22"
@.d114 = private constant [24 x i8] c" \22prefer-vector-width\22=\22"
declare ptr @__olang_sb_room(ptr, i64)
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
@.d115 = private constant [1 x i8] c"\22"
@.d116 = private constant [18 x i8] c"-unknown-linux-gnu"
@.d117 = private constant [7 x i8] c"aarch64"
@.d118 = private constant [6 x i8] c"native"
@.d119 = private constant [7 x i8] c"generic"
@.d120 = private constant [7 x i8] c"generic"
@.d121 = private constant [6 x i8] c"x86-64"
@.d122 = private constant [9 x i8] c"x86-64-v2"
@.d123 = private constant [9 x i8] c"x86-64-v3"
@.d124 = private constant [9 x i8] c"x86-64-v4"
@.d125 = private constant [6 x i8] c"native"
@.c126 = private unnamed_addr constant [53 x i8] c"compiler/target.olang:306: reached unreachable code\0A\00"
@.d127 = private constant [6 x i8] c"x86-64"
@.d128 = private constant [8 x i8] c"x86-64-v"
@.d129 = private constant [13 x i8] c"/proc/cpuinfo"
@.c130 = private unnamed_addr constant [53 x i8] c"compiler/target.olang:269: reached unreachable code\0A\00"
@.d131 = private constant [0 x i8] c""
@.c132 = private unnamed_addr constant [53 x i8] c"compiler/target.olang:270: reached unreachable code\0A\00"
@.d133 = private constant [5 x i8] c"flags"
@.d134 = private constant [0 x i8] c""
@.c135 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:273: slice bounds out of range\0A\00"
@.d136 = private constant [1 x i8] c" "
@.d137 = private constant [1 x i8] c" "
@.d138 = private constant [0 x i8] c""
@.c139 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:222: slice bounds out of range\0A\00"
@.c140 = private unnamed_addr constant [54 x i8] c"compiler/target.olang:223: slice bounds out of range\0A\00"
@.d141 = private constant [6 x i8] c"native"
@.d142 = private constant [0 x i8] c""
@.d143 = private constant [0 x i8] c""
@.d144 = private constant [5 x i8] c"linux"
@.d145 = private constant [0 x i8] c""
@.d146 = private constant [0 x i8] c""
@.d147 = private constant [0 x i8] c""
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNativeForeign(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoBackend(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
