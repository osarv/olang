; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/mir:Fn" = type { { i64, [1 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:Task" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span" }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/mir:dumper" = type { ptr, ptr, %"std/prelude/text:StringBuilder" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [7 x i64] } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/mir:verifier" = type { ptr, ptr, %"std/prelude/text:StringBuilder", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/mir:Call" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
@G_2ecompiler_2fmir_2eEmpty = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eI32T = constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eI64T = constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoLocal = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoPlace = constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2fmir_2eNoScope = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eSp0 = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
define dso_local void @compiler_2fmir_2eEmpty_2einit() #0 {
entry:
  %l0 = alloca %"compiler/mir:Range"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %t1, i32 0, i32 0)
  store %"compiler/mir:Range" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/mir:Range", ptr %l0
  store %"compiler/mir:Range" %t3, ptr @G_2ecompiler_2fmir_2eEmpty
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l51 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i1
  %l68 = alloca i64
  %l71 = alloca i64
  %l89 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l28, !tbaa !24
  store i64 %t37, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l25, !tbaa !24
  store i64 %t38, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l10, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l46, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t59, ptr %l48, !tbaa !27
  %t60 = load i64, ptr %l10, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i32, ptr %t63, i64 %t60
  %t65 = load i32, ptr %t64, !tbaa !33
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t58, i32 %t65)
  store i32 %t68, ptr %l51
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t69, i32 %a2)
  store i32 %t73, ptr %l54
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l46, !tbaa !29
  %t75 = load i32, ptr %l51, !tbaa !23
  %t76 = load i32, ptr %l54, !tbaa !23
  %t77 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t74, i32 %t75, i32 %t76)
  store i1 %t77, ptr %l55
  br label %bb14
bb14:
  %t78 = load i1, ptr %l55, !tbaa !21
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t81 = add i64 %t79, 1
  %t83 = shl i64 %t81, 16
  %t87 = or i64 %t83, %a3
  call void @__olang_scope_close(ptr %s2)
  store i64 %t87, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb8
bb19:
  store i64 0, ptr %l11, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t97 = load i64, ptr %l12, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb20, label %bb21
bb20:
  %t103 = load i64, ptr %l13, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb25
bb22:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l13, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l71, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb24
bb24:
  %t123 = load i64, ptr %l71, !tbaa !24
  store i64 %t123, ptr %l68, !tbaa !24
  br label %bb25
bb25:
  %t124 = load i64, ptr %l68, !tbaa !24
  store i64 %t124, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb28:
  br label %bb29
bb29:
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l16, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t143, ptr %l89, !tbaa !27
  %t144 = load i64, ptr %l16, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 %t144
  %t149 = load i32, ptr %t148, !tbaa !33
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb30, label %bb31
bb30:
  %t155 = load i64, ptr %l16, !tbaa !24
  %t157 = add i64 %t155, 1
  %t159 = shl i64 %t157, 16
  call void @__olang_scope_close(ptr %s6)
  store i64 %t159, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  %t161 = load i64, ptr %l15, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l15, !tbaa !24
  br label %bb26
bb34:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2eExitText(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb9
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 1 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 10 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 11 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr @.d0 }, ptr %l1, !tbaa !27
  br label %bb43
bb10:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 2 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 7, ptr @.d1 }, ptr %l1, !tbaa !27
  br label %bb43
bb14:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 3 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 19, ptr @.d2 }, ptr %l1, !tbaa !27
  br label %bb43
bb18:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 4 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 12, ptr @.d3 }, ptr %l1, !tbaa !27
  br label %bb43
bb22:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 5 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 16, ptr @.d4 }, ptr %l1, !tbaa !27
  br label %bb43
bb26:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 6 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 25, ptr @.d5 }, ptr %l1, !tbaa !27
  br label %bb43
bb30:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 7 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 25, ptr @.d6 }, ptr %l1, !tbaa !27
  br label %bb43
bb34:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 8 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store { i64, ptr } { i64 32, ptr @.d7 }, ptr %l1, !tbaa !27
  br label %bb43
bb38:
  %t56 = load i32, ptr %l0
  %t58 = trunc i64 9 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 45, ptr @.d8 }, ptr %l1, !tbaa !27
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_84efd3c782aef4d6_8c92393edf5749f2)
  unreachable
bb43:
  %t61 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2eI64T_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 6, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eNoScope_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 -1, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1, i32 %a2) #0 {
entry:
  %l1 = alloca { i64, [5 x i64] }
  %l3 = alloca i64
  %l6 = alloca i1
  %l9 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l32 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store { i64, [5 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [1 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [1 x i64] }, ptr %t7
  %t10 = extractvalue { i64, [1 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 2
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb6
bb3:
  %t13 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { { i64, [1 x i64] }, i32 }, ptr %t13, i32 0, i32 0
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32, i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t19 = trunc i64 0 to i32
  %t20 = icmp eq i32 %t17, %t19
  store i1 %t20, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l9, !tbaa !21
  store i1 %t22, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l6, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb38
bb10:
  %t24 = load { i64, [5 x i64] }, ptr %l1
  %t26 = extractvalue { i64, [5 x i64] } %t24, 0
  %t27 = icmp eq i64 %t26, 0
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t30 = getelementptr { { i64, [1 x i64] }, i32 }, ptr %t29, i32 0, i32 0
  %t31 = load { i64, [1 x i64] }, ptr %t30
  %t33 = extractvalue { i64, [1 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 2
  br i1 %t34, label %bb13, label %bb14
bb12:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb16
bb13:
  %t36 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t37 = getelementptr { { i64, [1 x i64] }, i32 }, ptr %t36, i32 0, i32 0
  %t38 = getelementptr { i64, [1 x i64] }, ptr %t37, i32 0, i32 1
  %t39 = getelementptr { i32, i32 }, ptr %t38, i32 0, i32 0
  %t40 = load i32, ptr %t39
  %t42 = trunc i64 1 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb15
bb15:
  %t45 = load i1, ptr %l17, !tbaa !21
  store i1 %t45, ptr %l14, !tbaa !21
  br label %bb16
bb16:
  %t46 = load i1, ptr %l14, !tbaa !21
  br i1 %t46, label %bb17, label %bb18
bb17:
  br label %bb27
bb18:
  %t47 = load { i64, [5 x i64] }, ptr %l1
  %t49 = extractvalue { i64, [5 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 0
  br i1 %t50, label %bb19, label %bb20
bb19:
  %t52 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t53 = getelementptr { { i64, [1 x i64] }, i32 }, ptr %t52, i32 0, i32 0
  %t54 = load { i64, [1 x i64] }, ptr %t53
  %t56 = extractvalue { i64, [1 x i64] } %t54, 0
  %t57 = icmp eq i64 %t56, 2
  br i1 %t57, label %bb21, label %bb22
bb20:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb24
bb21:
  %t59 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t60 = getelementptr { { i64, [1 x i64] }, i32 }, ptr %t59, i32 0, i32 0
  %t61 = getelementptr { i64, [1 x i64] }, ptr %t60, i32 0, i32 1
  %t62 = getelementptr { i32, i32 }, ptr %t61, i32 0, i32 0
  %t63 = load i32, ptr %t62
  %t65 = trunc i64 2 to i32
  %t66 = icmp eq i32 %t63, %t65
  store i1 %t66, ptr %l25, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t68 = load i1, ptr %l25, !tbaa !21
  store i1 %t68, ptr %l22, !tbaa !21
  br label %bb24
bb24:
  %t69 = load i1, ptr %l22, !tbaa !21
  br i1 %t69, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb38
bb28:
  %t70 = load { i64, [5 x i64] }, ptr %l1
  %t72 = extractvalue { i64, [5 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 1
  br i1 %t73, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb38
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb37
bb35:
  store %olang.scope zeroinitializer, ptr %s4
  %t79 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s4, ptr %a0, i32 %a2)
  store { i64, ptr } %t79, ptr %l32
  br label %bb36
bb36:
  %t80 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  store i64 %t81, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_419ac27aa82c7b2c_45256e944a6f3408)
  unreachable
bb38:
  %t83 = load i64, ptr %l3, !tbaa !24
  store i64 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fmir_2eSp0_2einit() #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %t1, i32 0, i32 0)
  store %"compiler/source:Span" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t3, ptr @G_2ecompiler_2fmir_2eSp0
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eaddFn(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l15 = alloca i32
  %l17 = alloca i32
  %l18 = alloca %"compiler/mir:Fn"
  %l19 = alloca ptr
  %l22 = alloca i32
  %l27 = alloca %"compiler/mir:Local"
  %l28 = alloca ptr
  %l31 = alloca i32
  %l36 = alloca %"compiler/mir:Local"
  %l37 = alloca ptr
  %l40 = alloca i32
  %l45 = alloca %"compiler/mir:Local"
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca %"compiler/source:Span"
  %l51 = alloca %"compiler/mir:Place"
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca ptr
  %l55 = alloca %"compiler/mir:Place"
  %l56 = alloca { i64, [4 x i64] }
  %l57 = alloca %"compiler/mir:Place"
  %l62 = alloca %"compiler/mir:Range"
  %l71 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/mir:Place"
  %l78 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t34 = alloca %"compiler/mir:Fn", align 8
  %t49 = alloca { i64, [1 x i64] }, align 8
  %t70 = alloca { i64, [1 x i64] }, align 8
  %t90 = alloca { i64, [1 x i64] }, align 8
  %t112 = alloca { i64, [4 x i64] }, align 8
  %t119 = alloca { i64, [4 x i64] }, align 8
  %t144 = alloca { i64, [15 x i64] }, align 8
  %t154 = alloca { i64, [21 x i64] }, align 8
  %t172 = alloca { i64, [21 x i64] }, align 8
  %t190 = alloca { i64, [4 x i64] }, align 8
  %t196 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr @.d9 })
  store i32 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i32, ptr %l6, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t9 = load i32, ptr %l1, !tbaa !23
  %t11 = insertvalue [2 x i32] undef, i32 %t8, 0
  %t13 = insertvalue [2 x i32] %t11, i32 %t9, 1
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call ptr @__olang_scope_alloc(ptr %t15, i64 8)
  store [2 x i32] %t13, ptr %t16
  %t17 = insertvalue { i64, ptr } undef, i64 2, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = extractvalue { i64, ptr } %t18, 1
  %t22 = mul i64 %t20, 4
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t7, { i64, ptr } %t25)
  store i32 %t28, ptr %l15
  br label %bb2
bb2:
  %t29 = load i32, ptr %l1, !tbaa !23
  %t30 = load ptr, ptr %l8, !tbaa !29
  %t31 = load i32, ptr %l15, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t30, i32 %t31, i32 %t29, i32 0, i32 0, i64 0)
  store i32 %t33, ptr %l17
  br label %bb3
bb3:
  %t35 = load ptr, ptr %l7, !tbaa !29
  %t36 = load i32, ptr %l17, !tbaa !23
  call void @compiler_2fmir_2etfn(ptr %t34, ptr %v0, ptr %v1, ptr %t35, i32 %t36)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t34, i64 192, i1 false)
  br label %bb4
bb4:
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 192, i64 8)
  store ptr %t37, ptr %lp2
  %t38 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %l18, i64 192, i1 false)
  %t39 = load ptr, ptr %lp2
  %t40 = getelementptr %"compiler/mir:Fn", ptr %t39, i32 0, i32 7
  store ptr %t40, ptr %l19, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/types:Table", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t44, { i64, ptr } { i64 1, ptr @.d10 })
  store i32 %t46, ptr %l22
  br label %bb5
bb5:
  %t47 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t48 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [1 x i64] }, ptr %t49, i32 0, i32 0
  store i64 3, ptr %t50
  %t51 = load { i64, [1 x i64] }, ptr %t49
  %t52 = load i32, ptr %l22, !tbaa !23
  %t57 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t52, %"compiler/source:Span" %t47, i32 %t48, i32 0, { i64, [1 x i64] } %t51)
  store %"compiler/mir:Local" %t57, ptr %l27
  br label %bb6
bb6:
  %t58 = load ptr, ptr %l19, !tbaa !29
  %t59 = load %"compiler/mir:Local", ptr %l27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eSetAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t58, i64 0, %"compiler/mir:Local" %t59)
  br label %bb7
bb7:
  %t60 = load ptr, ptr %lp2
  %t61 = getelementptr %"compiler/mir:Fn", ptr %t60, i32 0, i32 7
  store ptr %t61, ptr %l28, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/types:Table", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t65, { i64, ptr } { i64 1, ptr @.d11 })
  store i32 %t67, ptr %l31
  br label %bb8
bb8:
  %t68 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t69 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [1 x i64] }, ptr %t70, i32 0, i32 0
  store i64 3, ptr %t71
  %t72 = load { i64, [1 x i64] }, ptr %t70
  %t73 = load i32, ptr %l31, !tbaa !23
  %t78 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t73, %"compiler/source:Span" %t68, i32 %t69, i32 0, { i64, [1 x i64] } %t72)
  store %"compiler/mir:Local" %t78, ptr %l36
  br label %bb9
bb9:
  %t79 = load ptr, ptr %l28, !tbaa !29
  %t80 = load %"compiler/mir:Local", ptr %l36
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eSetAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t79, i64 1, %"compiler/mir:Local" %t80)
  br label %bb10
bb10:
  %t81 = load ptr, ptr %lp2
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/types:Table", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t85, { i64, ptr } { i64 1, ptr @.d12 })
  store i32 %t87, ptr %l40
  br label %bb11
bb11:
  %t88 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t89 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [1 x i64] }, ptr %t90, i32 0, i32 0
  store i64 3, ptr %t91
  %t92 = load { i64, [1 x i64] }, ptr %t90
  %t93 = load i32, ptr %l40, !tbaa !23
  %t98 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t93, %"compiler/source:Span" %t88, i32 %t89, i32 2, { i64, [1 x i64] } %t92)
  store %"compiler/mir:Local" %t98, ptr %l45
  br label %bb12
bb12:
  %t99 = load ptr, ptr %l37, !tbaa !29
  %t100 = load %"compiler/mir:Local", ptr %l45
  %t101 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v1, ptr %t99, %"compiler/mir:Local" %t100)
  store i32 %t101, ptr %l46
  br label %bb13
bb13:
  %t102 = load i32, ptr %l46, !tbaa !23
  store i32 %t102, ptr %l3, !tbaa !23
  store i32 0, ptr %l4, !tbaa !23
  %t103 = load ptr, ptr %lp2
  store ptr %t103, ptr %l47, !tbaa !29
  %t104 = load i32, ptr %l4, !tbaa !23
  store i32 %t104, ptr %l48, !tbaa !23
  %t105 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t105, ptr %l49
  %t106 = load i32, ptr %l3, !tbaa !23
  %t108 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t106)
  store %"compiler/mir:Place" %t108, ptr %l51
  br label %bb14
bb14:
  store i32 3, ptr %l52
  %t109 = load i32, ptr %l1, !tbaa !23
  store i32 %t109, ptr %l53, !tbaa !23
  %t110 = load ptr, ptr %lp2
  store ptr %t110, ptr %l54, !tbaa !29
  %t111 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 0)
  store %"compiler/mir:Place" %t111, ptr %l55
  br label %bb15
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 0
  store i64 1, ptr %t113
  %t114 = load %"compiler/mir:Place", ptr %l55
  %t115 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t114, 0
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  store { %"compiler/mir:Place" } %t115, ptr %t116
  %t117 = load { i64, [4 x i64] }, ptr %t112
  store { i64, [4 x i64] } %t117, ptr %l56
  %t118 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 1)
  store %"compiler/mir:Place" %t118, ptr %l57
  br label %bb16
bb16:
  store { i64, [4 x i64] } zeroinitializer, ptr %t119
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t119, i32 0, i32 0
  store i64 1, ptr %t120
  %t121 = load %"compiler/mir:Place", ptr %l57
  %t122 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t121, 0
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t119, i32 0, i32 1
  store { %"compiler/mir:Place" } %t122, ptr %t123
  %t124 = load { i64, [4 x i64] }, ptr %t119
  %t125 = load { i64, [4 x i64] }, ptr %l56
  %t126 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %t125, 0
  %t128 = insertvalue [2 x { i64, [4 x i64] }] %t126, { i64, [4 x i64] } %t124, 1
  %t130 = load ptr, ptr @__olang_prog_scope
  %t131 = call ptr @__olang_scope_alloc(ptr %t130, i64 80)
  store [2 x { i64, [4 x i64] }] %t128, ptr %t131
  %t132 = insertvalue { i64, ptr } undef, i64 2, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = extractvalue { i64, ptr } %t133, 1
  %t137 = mul i64 %t135, 40
  %t138 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t138, ptr %t136, i64 %t137, i1 false)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  %t141 = load ptr, ptr %l54, !tbaa !29
  %t143 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t141, { i64, ptr } %t140)
  store %"compiler/mir:Range" %t143, ptr %l62
  br label %bb17
bb17:
  store { i64, [15 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [15 x i64] }, ptr %t144, i32 0, i32 0
  store i64 3, ptr %t145
  %t146 = load i32, ptr %l52
  %t147 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t146, 0
  %t148 = load i32, ptr %l53, !tbaa !23
  %t149 = insertvalue { i32, i32, %"compiler/mir:Range" } %t147, i32 %t148, 1
  %t150 = load %"compiler/mir:Range", ptr %l62
  %t151 = insertvalue { i32, i32, %"compiler/mir:Range" } %t149, %"compiler/mir:Range" %t150, 2
  %t152 = getelementptr { i64, [15 x i64] }, ptr %t144, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t151, ptr %t152
  %t153 = load { i64, [15 x i64] }, ptr %t144
  store { i64, [21 x i64] } zeroinitializer, ptr %t154
  %t155 = getelementptr { i64, [21 x i64] }, ptr %t154, i32 0, i32 0
  store i64 0, ptr %t155
  %t156 = load %"compiler/source:Span", ptr %l49
  %t157 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t156, 0
  %t158 = load %"compiler/mir:Place", ptr %l51
  %t159 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t157, %"compiler/mir:Place" %t158, 1
  %t161 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t159, { i64, [15 x i64] } %t153, 2
  %t162 = getelementptr { i64, [21 x i64] }, ptr %t154, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t161, ptr %t162
  %t163 = load { i64, [21 x i64] }, ptr %t154
  %t165 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t163, ptr %t165
  %t166 = load ptr, ptr %l47, !tbaa !29
  %t167 = load i32, ptr %l48, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t166, i32 %t167, ptr %t165)
  br label %bb18
bb18:
  %t169 = load ptr, ptr %lp2
  %t170 = load i32, ptr %l4, !tbaa !23
  %t171 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [21 x i64] }, ptr %t172, i32 0, i32 0
  store i64 4, ptr %t173
  %t175 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t171, 0
  %t176 = insertvalue { %"compiler/source:Span", i32 } %t175, i32 0, 1
  %t177 = getelementptr { i64, [21 x i64] }, ptr %t172, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t176, ptr %t177
  %t178 = load { i64, [21 x i64] }, ptr %t172
  %t180 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t178, ptr %t180
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t169, i32 %t170, ptr %t180)
  br label %bb19
bb19:
  %t184 = load ptr, ptr %lp2
  store ptr %t184, ptr %l71, !tbaa !29
  %t185 = load i32, ptr %l4, !tbaa !23
  store i32 %t185, ptr %l72, !tbaa !23
  %t186 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t186, ptr %l73
  %t187 = load i32, ptr %l3, !tbaa !23
  %t189 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t187)
  store %"compiler/mir:Place" %t189, ptr %l75
  br label %bb20
bb20:
  store { i64, [4 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 0
  store i64 1, ptr %t191
  %t192 = load %"compiler/mir:Place", ptr %l75
  %t193 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t192, 0
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 1
  store { %"compiler/mir:Place" } %t193, ptr %t194
  %t195 = load { i64, [4 x i64] }, ptr %t190
  store { i64, [7 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [7 x i64] }, ptr %t196, i32 0, i32 0
  store i64 5, ptr %t197
  %t198 = load %"compiler/source:Span", ptr %l73
  %t199 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t198, 0
  %t201 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t199, { i64, [4 x i64] } %t195, 1
  %t202 = getelementptr { i64, [7 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t201, ptr %t202
  %t203 = load { i64, [7 x i64] }, ptr %t196
  %t204 = load ptr, ptr %l71, !tbaa !29
  %t205 = load i32, ptr %l72, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t204, i32 %t205, { i64, [7 x i64] } %t203)
  br label %bb21
bb21:
  %t207 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l78, ptr %t207, i64 192, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l78, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCases(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 15
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/mir:Case", ptr %t25, i64 %t22
  %t27 = load %"compiler/mir:Case", ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 15
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2ePush_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t31, %"compiler/mir:Case" %t27)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca %"compiler/mir:Range"
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca %"compiler/mir:Range"
  %l40 = alloca i64
  %rv = alloca i32
  %t17 = alloca { i64, [1 x i64] }, align 8
  %t44 = alloca { i64, [1 x i64] }, align 8
  %t71 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l2, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i64, ptr %l2, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [1 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t20 = insertvalue { i64 } undef, i64 %t16, 0
  %t21 = getelementptr { i64, [1 x i64] }, ptr %t17, i32 0, i32 1
  store { i64 } %t20, ptr %t21
  %t22 = load { i64, [1 x i64] }, ptr %t17
  store { i64, [1 x i64] } %t22, ptr %l6
  br label %bb21
bb6:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l16, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr } }, ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l3, !tbaa !27
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddBytes(ptr %v0, ptr %v1, ptr %t39, { i64, ptr } %t40)
  store %"compiler/mir:Range" %t43, ptr %l23
  br label %bb12
bb12:
  store { i64, [1 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [1 x i64] }, ptr %t44, i32 0, i32 0
  store i64 1, ptr %t45
  %t46 = load %"compiler/mir:Range", ptr %l23
  %t47 = insertvalue { %"compiler/mir:Range" } undef, %"compiler/mir:Range" %t46, 0
  %t48 = getelementptr { i64, [1 x i64] }, ptr %t44, i32 0, i32 1
  store { %"compiler/mir:Range" } %t47, ptr %t48
  %t49 = load { i64, [1 x i64] }, ptr %t44
  store { i64, [1 x i64] } %t49, ptr %l6
  br label %bb21
bb13:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l25, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 2
  store i1 %t58, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l26, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [2 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { { i64, ptr } }, ptr %t62, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  store { i64, ptr } %t64, ptr %l4, !tbaa !27
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddConstItems(ptr %v0, ptr %v1, ptr %t66, { i64, ptr } %t67)
  store %"compiler/mir:Range" %t70, ptr %l33
  br label %bb19
bb19:
  store { i64, [1 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [1 x i64] }, ptr %t71, i32 0, i32 0
  store i64 2, ptr %t72
  %t73 = load %"compiler/mir:Range", ptr %l33
  %t74 = insertvalue { %"compiler/mir:Range" } undef, %"compiler/mir:Range" %t73, 0
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t71, i32 0, i32 1
  store { %"compiler/mir:Range" } %t74, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t71
  store { i64, [1 x i64] } %t76, ptr %l6
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f17cf97eff0353b6_fea489b4a6f80ab2)
  unreachable
bb21:
  %t78 = load { i64, [1 x i64] }, ptr %l6
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/mir:Fn", ptr %t79, i32 0, i32 19
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2ePus_H34a38873c681933be8db0e4031fab6d9(ptr %v0, ptr %t81, { i64, [1 x i64] } %t78)
  br label %bb22
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/mir:Fn", ptr %t85, i32 0, i32 19
  %t89 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t87)
  store i64 %t89, ptr %l40
  br label %bb23
bb23:
  %t90 = load i64, ptr %l40, !tbaa !24
  %t91 = sub i64 %t90, 1
  %t93 = trunc i64 %t91 to i32
  store i32 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 7
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2ePush_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t3, %"compiler/mir:Local" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 7
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l11 = alloca %"compiler/mir:Local"
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t5 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 0
  store i64 3, ptr %t6
  %t7 = load { i64, [1 x i64] }, ptr %t5
  %t13 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 0, { i64, [1 x i64] } %t7)
  store %"compiler/mir:Local" %t13, ptr %l11
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = load %"compiler/mir:Local", ptr %l11
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %t14, %"compiler/mir:Local" %t15)
  store i32 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i32, ptr %l12, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/mir:Fn", ptr %t18, i32 0, i32 4
  %t21 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t20, i32 %t21)
  br label %bb3
bb3:
  %t24 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTask(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [5 x i64] } %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Range" %a3, { i64, ptr } %a4, { i64, ptr } %a5, %"compiler/mir:Range" %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l28 = alloca { i64, ptr }
  %l38 = alloca i64
  %l46 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, [5 x i64] }
  %l57 = alloca %"compiler/mir:Range"
  %l58 = alloca %"compiler/mir:Range"
  %l64 = alloca %"compiler/mir:Range"
  %l70 = alloca %"compiler/mir:Range"
  %l73 = alloca %"compiler/mir:Task"
  %l76 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eLen_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i64, ptr %l20, !tbaa !24
  store i64 %t6, ptr %l8, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l11, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l11, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t21, ptr %l28, !tbaa !27
  %t22 = load i64, ptr %l10, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/mir:Place", ptr %t25, i64 %t22
  %t27 = load %"compiler/mir:Place", ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 13
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2ePush_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t31, %"compiler/mir:Place" %t27)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t35 = load i64, ptr %l10, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l10, !tbaa !24
  br label %bb2
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/mir:Fn", ptr %t39, i32 0, i32 17
  %t43 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eLe_Ha29d98bd5fca0556754225de6d8edaab(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l38
  br label %bb9
bb9:
  %t44 = load i64, ptr %l38, !tbaa !24
  store i64 %t44, ptr %l13, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t45, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l16, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s5
  %t51 = load i64, ptr %l15, !tbaa !24
  %t52 = load i64, ptr %l16, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t59 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t59, ptr %l46, !tbaa !27
  %t60 = load i64, ptr %l15, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr %"compiler/mir:TaskClause", ptr %t63, i64 %t60
  %t65 = load %"compiler/mir:TaskClause", ptr %t64
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/mir:Fn", ptr %t67, i32 0, i32 17
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2ePu_Hee8f32853b3aef818b7318957721fb5e(ptr %v0, ptr %t69, %"compiler/mir:TaskClause" %t65)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb15:
  %t73 = load i64, ptr %l15, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l15, !tbaa !24
  br label %bb10
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/mir:Fn", ptr %t77, i32 0, i32 16
  store ptr %t79, ptr %l55, !tbaa !29
  store { i64, [5 x i64] } %a1, ptr %l56
  store %"compiler/mir:Range" %a2, ptr %l57
  store %"compiler/mir:Range" %a3, ptr %l58
  %t83 = load i64, ptr %l8, !tbaa !24
  %t85 = trunc i64 %t83 to i32
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t90 = trunc i64 %t88 to i32
  %t93 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t85, i32 %t90)
  store %"compiler/mir:Range" %t93, ptr %l64
  br label %bb17
bb17:
  %t94 = load i64, ptr %l13, !tbaa !24
  %t96 = trunc i64 %t94 to i32
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t101 = trunc i64 %t99 to i32
  %t104 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t96, i32 %t101)
  store %"compiler/mir:Range" %t104, ptr %l70
  br label %bb18
bb18:
  %t107 = load { i64, [5 x i64] }, ptr %l56
  %t108 = load %"compiler/mir:Range", ptr %l57
  %t109 = load %"compiler/mir:Range", ptr %l58
  %t110 = load %"compiler/mir:Range", ptr %l64
  %t111 = load %"compiler/mir:Range", ptr %l70
  %t114 = call %"compiler/mir:Task" @compiler_2fmir_3aTask_2ector(ptr %s0, { i64, [5 x i64] } %t107, %"compiler/mir:Range" %t108, %"compiler/mir:Range" %t109, %"compiler/mir:Range" %t110, %"compiler/mir:Range" %t111, %"compiler/mir:Range" %a6, %"compiler/source:Span" %a7)
  store %"compiler/mir:Task" %t114, ptr %l73
  br label %bb19
bb19:
  %t115 = load ptr, ptr %l55, !tbaa !29
  %t116 = load %"compiler/mir:Task", ptr %l73
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2ePush_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t115, %"compiler/mir:Task" %t116)
  br label %bb20
bb20:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/mir:Fn", ptr %t117, i32 0, i32 16
  %t121 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t119)
  store i64 %t121, ptr %l76
  br label %bb21
bb21:
  %t122 = load i64, ptr %l76, !tbaa !24
  %t123 = sub i64 %t122, 1
  %t125 = trunc i64 %t123 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca %"compiler/mir:dumper"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/mir:dumper" @compiler_2fmir_3adumper_2ector(ptr %v0, ptr %v1, ptr %v1, ptr %a0, ptr %a1)
  store %"compiler/mir:dumper" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"compiler/mir:dumper", ptr %l5
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/mir:dumper" %t6, ptr %t7
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eall(ptr %v1, ptr %t9)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/mir:dumper", ptr %t11, i32 0, i32 2
  %t15 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v1, ptr %v2, ptr %t13)
  store { i64, ptr } %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l12, !tbaa !24
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l13, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l12, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t30, ptr %l11, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 12
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [1 x i64] }, ptr %t25, i64 %t22
  %t27 = load { i64, [1 x i64] }, ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 12
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2ePush_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t31, { i64, [1 x i64] } %t27)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddBytes(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 21
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i8, ptr %t25, i64 %t22
  %t27 = load i8, ptr %t26, !tbaa !32
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t31, i8 %t27)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddConstItems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca i32
  %l55 = alloca i64
  %l63 = alloca { i64, ptr }
  %l76 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l15, !tbaa !24
  %t4 = load i64, ptr %l15, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l15, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_5b04576c3a0c01b1_2f8c01babecc81b5)
  unreachable
bb3:
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5b04576c3a0c01b1_2f8c01babecc81b5)
  unreachable
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb10
bb7:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l27, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l27, !tbaa !24
  store i64 %t46, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l24, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  store i64 %t66, ptr %l45, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l47, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t77 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %t67, ptr %t74)
  store i32 %t77, ptr %l50
  br label %bb15
bb15:
  %t78 = load i32, ptr %l50, !tbaa !23
  %t79 = load i64, ptr %l45, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i32, ptr %t81, i64 %t79
  store i32 %t78, ptr %t82, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t83 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/mir:Fn", ptr %t87, i32 0, i32 20
  %t91 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t89)
  store i64 %t91, ptr %l55
  br label %bb18
bb18:
  %t92 = load i64, ptr %l55, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l12, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t107, ptr %l63, !tbaa !27
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 %t108
  %t113 = load i32, ptr %t112, !tbaa !33
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/mir:Fn", ptr %t115, i32 0, i32 20
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t117, i32 %t113)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l11, !tbaa !24
  br label %bb19
bb25:
  %t125 = load i64, ptr %l9, !tbaa !24
  %t127 = trunc i64 %t125 to i32
  %t128 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t132 = trunc i64 %t130 to i32
  %t135 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t127, i32 %t132)
  store %"compiler/mir:Range" %t135, ptr %l76
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load %"compiler/mir:Range", ptr %l76
  store %"compiler/mir:Range" %t136, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aKey_2eText(ptr %v0, { i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t7 = getelementptr { i32, %"compiler/source:Span" }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l1, !tbaa !23
  %t10 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t11 = getelementptr { i32, %"compiler/source:Span" }, ptr %t10, i32 0, i32 1
  %t12 = load %"compiler/source:Span", ptr %t11
  store %"compiler/source:Span" %t12, ptr %l2
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t19 = extractvalue { i64, ptr } { i64 8, ptr @.d13 }, 1
  %t20 = extractvalue { i64, ptr } { i64 8, ptr @.d13 }, 0
  %t22 = sext i32 %t14 to i64
  %t23 = call i64 @__olang_fmt_i64(ptr null, i64 %t22)
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 0
  %t27 = add i64 %t24, %t26
  %t29 = sext i32 %t16 to i64
  %t30 = call i64 @__olang_fmt_i64(ptr null, i64 %t29)
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 0
  %t34 = add i64 %t31, %t33
  %t36 = sext i32 %t18 to i64
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t36)
  %t38 = add i64 %t34, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t19, i64 %t20)
  %t40 = getelementptr i8, ptr %t39, i64 %t20
  %t41 = call i64 @__olang_fmt_i64(ptr %t40, i64 %t22)
  %t42 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t42, ptr %t25, i64 %t26)
  %t43 = getelementptr i8, ptr %t42, i64 %t26
  %t44 = call i64 @__olang_fmt_i64(ptr %t43, i64 %t29)
  %t45 = getelementptr i8, ptr %t43, i64 %t30
  call void @olang_textcopy(ptr %t45, ptr %t32, i64 %t33)
  %t46 = getelementptr i8, ptr %t45, i64 %t33
  %t47 = call i64 @__olang_fmt_i64(ptr %t46, i64 %t36)
  %t48 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t39, 1
  store { i64, ptr } %t49, ptr %l8, !tbaa !27
  br label %bb17
bb4:
  %t51 = load { i64, [2 x i64] }, ptr %l0
  %t53 = extractvalue { i64, [2 x i64] } %t51, 0
  %t54 = icmp eq i64 %t53, 1
  br i1 %t54, label %bb5, label %bb6
bb5:
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t57 = getelementptr { i64, i32 }, ptr %t56, i32 0, i32 0
  %t58 = load i64, ptr %t57
  store i64 %t58, ptr %l3, !tbaa !24
  %t60 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t61 = getelementptr { i64, i32 }, ptr %t60, i32 0, i32 1
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l4, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t65 = load i32, ptr %l4, !tbaa !23
  %t66 = extractvalue { i64, ptr } { i64 7, ptr @.d16 }, 1
  %t67 = extractvalue { i64, ptr } { i64 7, ptr @.d16 }, 0
  %t69 = call i64 @__olang_fmt_i64(ptr null, i64 %t64)
  %t70 = add i64 %t67, %t69
  %t71 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 0
  %t73 = add i64 %t70, %t72
  %t75 = sext i32 %t65 to i64
  %t76 = call i64 @__olang_fmt_i64(ptr null, i64 %t75)
  %t77 = add i64 %t73, %t76
  %t78 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t66, i64 %t67)
  %t79 = getelementptr i8, ptr %t78, i64 %t67
  %t80 = call i64 @__olang_fmt_i64(ptr %t79, i64 %t64)
  %t81 = getelementptr i8, ptr %t79, i64 %t69
  call void @olang_textcopy(ptr %t81, ptr %t71, i64 %t72)
  %t82 = getelementptr i8, ptr %t81, i64 %t72
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t75)
  %t84 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t78, 1
  store { i64, ptr } %t85, ptr %l8, !tbaa !27
  br label %bb17
bb8:
  %t87 = load { i64, [2 x i64] }, ptr %l0
  %t89 = extractvalue { i64, [2 x i64] } %t87, 0
  %t90 = icmp eq i64 %t89, 2
  br i1 %t90, label %bb9, label %bb10
bb9:
  %t92 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t93 = getelementptr { i32, i32 }, ptr %t92, i32 0, i32 0
  %t94 = load i32, ptr %t93
  store i32 %t94, ptr %l5, !tbaa !23
  %t96 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t97 = getelementptr { i32, i32 }, ptr %t96, i32 0, i32 1
  %t98 = load i32, ptr %t97
  store i32 %t98, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t100 = load i32, ptr %l5, !tbaa !23
  %t101 = load i32, ptr %l6, !tbaa !23
  %t102 = extractvalue { i64, ptr } { i64 9, ptr @.d18 }, 1
  %t103 = extractvalue { i64, ptr } { i64 9, ptr @.d18 }, 0
  %t105 = sext i32 %t100 to i64
  %t106 = call i64 @__olang_fmt_i64(ptr null, i64 %t105)
  %t107 = add i64 %t103, %t106
  %t108 = extractvalue { i64, ptr } { i64 6, ptr @.d19 }, 1
  %t109 = extractvalue { i64, ptr } { i64 6, ptr @.d19 }, 0
  %t110 = add i64 %t107, %t109
  %t112 = sext i32 %t101 to i64
  %t113 = call i64 @__olang_fmt_i64(ptr null, i64 %t112)
  %t114 = add i64 %t110, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t102, i64 %t103)
  %t116 = getelementptr i8, ptr %t115, i64 %t103
  %t117 = call i64 @__olang_fmt_i64(ptr %t116, i64 %t105)
  %t118 = getelementptr i8, ptr %t116, i64 %t106
  call void @olang_textcopy(ptr %t118, ptr %t108, i64 %t109)
  %t119 = getelementptr i8, ptr %t118, i64 %t109
  %t120 = call i64 @__olang_fmt_i64(ptr %t119, i64 %t112)
  %t121 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t115, 1
  store { i64, ptr } %t122, ptr %l8, !tbaa !27
  br label %bb17
bb12:
  %t124 = load { i64, [2 x i64] }, ptr %l0
  %t126 = extractvalue { i64, [2 x i64] } %t124, 0
  %t127 = icmp eq i64 %t126, 3
  br i1 %t127, label %bb13, label %bb14
bb13:
  %t129 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t130 = getelementptr { i32 }, ptr %t129, i32 0, i32 0
  %t131 = load i32, ptr %t130
  store i32 %t131, ptr %l7, !tbaa !23
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t133 = load i32, ptr %l7, !tbaa !23
  %t134 = extractvalue { i64, ptr } { i64 6, ptr @.d20 }, 1
  %t135 = extractvalue { i64, ptr } { i64 6, ptr @.d20 }, 0
  %t137 = sext i32 %t133 to i64
  %t138 = call i64 @__olang_fmt_i64(ptr null, i64 %t137)
  %t139 = add i64 %t135, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t134, i64 %t135)
  %t141 = getelementptr i8, ptr %t140, i64 %t135
  %t142 = call i64 @__olang_fmt_i64(ptr %t141, i64 %t137)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t140, 1
  store { i64, ptr } %t144, ptr %l8, !tbaa !27
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_14ebfa33b1d03356_270fe526a4636ad2)
  unreachable
bb17:
  %t146 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t146, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/mir:Local"
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/mir:ScopeInfo"
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"compiler/mir:BasicBlock"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, [21 x i64] }
  %l43 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l57 = alloca i64
  %l59 = alloca %"std/prelude/text:StringBuilder"
  %l62 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l87 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca ptr
  %l96 = alloca { i64, [1 x i64] }
  %l97 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l109 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i64
  %l137 = alloca %"compiler/mir:Local"
  %l142 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca i64
  %l153 = alloca i32
  %l155 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l176 = alloca i64
  %l180 = alloca i64
  %l183 = alloca i64
  %l204 = alloca %"compiler/mir:ScopeInfo"
  %l208 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l226 = alloca ptr
  %l227 = alloca i64
  %l228 = alloca i32
  %l230 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l242 = alloca i64
  %l246 = alloca i64
  %l249 = alloca i64
  %l274 = alloca %"compiler/mir:BasicBlock"
  %l276 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l280 = alloca i32
  %l289 = alloca { i64, ptr }
  %l291 = alloca { i64, [21 x i64] }
  %l292 = alloca ptr
  %l295 = alloca { i64, ptr }
  %l302 = alloca ptr
  %l305 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %s16 = alloca %olang.scope
  %s20 = alloca %olang.builder
  %s20room = alloca [64 x i8], align 8
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l43, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/mir:Fn", ptr %t8, i32 0, i32 0
  %t11 = load { i64, [1 x i64] }, ptr %t10
  %t14 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %s0, ptr %t7, { i64, [1 x i64] } %t11)
  store { i64, ptr } %t14, ptr %l47
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/mir:dumper", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/mir:Fn", ptr %t19, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t18, i32 %t22)
  store { i64, ptr } %t25, ptr %l52
  br label %bb2
bb2:
  %t26 = extractvalue { i64, ptr } { i64 3, ptr @.d21 }, 1
  %t27 = extractvalue { i64, ptr } { i64 3, ptr @.d21 }, 0
  %t28 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 2, ptr @.d22 }, 1
  %t33 = extractvalue { i64, ptr } { i64 2, ptr @.d22 }, 0
  %t34 = add i64 %t31, %t33
  %t35 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = add i64 %t34, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t26, i64 %t27)
  %t40 = getelementptr i8, ptr %t39, i64 %t27
  call void @olang_textcopy(ptr %t40, ptr %t29, i64 %t30)
  %t41 = getelementptr i8, ptr %t40, i64 %t30
  call void @olang_textcopy(ptr %t41, ptr %t32, i64 %t33)
  %t42 = getelementptr i8, ptr %t41, i64 %t33
  call void @olang_textcopy(ptr %t42, ptr %t36, i64 %t37)
  %t43 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t39, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t52 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s0, ptr %t52, i64 0, { i64, ptr } %t51)
  br label %bb3
bb3:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/mir:Fn", ptr %t54, i32 0, i32 6
  %t58 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l57
  br label %bb4
bb4:
  %t59 = load i64, ptr %l57, !tbaa !24
  %t60 = icmp sgt i64 %t59, 0
  br i1 %t60, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t62, ptr %l59
  br label %bb7
bb6:
  br label %bb29
bb7:
  %t63 = load %"std/prelude/text:StringBuilder", ptr %l59
  store %"std/prelude/text:StringBuilder" %t63, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/mir:Fn", ptr %t64, i32 0, i32 6
  %t68 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l62
  br label %bb8
bb8:
  %t69 = load i64, ptr %l62, !tbaa !24
  store i64 %t69, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l3, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb9, label %bb10
bb9:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb14
bb11:
  %t80 = load i64, ptr %l4, !tbaa !24
  %t81 = load i64, ptr %l3, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l69, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb13
bb13:
  %t96 = load i64, ptr %l69, !tbaa !24
  store i64 %t96, ptr %l66, !tbaa !24
  br label %bb14
bb14:
  %t97 = load i64, ptr %l66, !tbaa !24
  store i64 %t97, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t98 = load i64, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t106 = load i64, ptr %l3, !tbaa !24
  %t107 = load i64, ptr %l7, !tbaa !24
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l8, !tbaa !24
  store ptr %l2, ptr %l87, !tbaa !29
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp sgt i64 %t116, 0
  br i1 %t118, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 2, ptr @.d23 }, ptr %l90, !tbaa !27
  br label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr @.d24 }, ptr %l90, !tbaa !27
  br label %bb21
bb21:
  %t120 = load i64, ptr %l8, !tbaa !24
  store i64 %t120, ptr %l91, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l92, !tbaa !29
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/mir:Fn", ptr %t122, i32 0, i32 6
  %t125 = load i64, ptr %l8, !tbaa !24
  %t128 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t124, i64 %t125)
  store { i64, [1 x i64] } %t128, ptr %l96
  br label %bb22
bb22:
  %t129 = load ptr, ptr %l92, !tbaa !29
  %t130 = load { i64, [1 x i64] }, ptr %l96
  %t131 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2evarKind(ptr %v0, ptr %s4, ptr %t129, { i64, [1 x i64] } %t130)
  store { i64, ptr } %t131, ptr %l97
  br label %bb23
bb23:
  %t132 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 0
  %t137 = add i64 %t134, %t136
  %t138 = load i64, ptr %l91, !tbaa !24
  %t139 = call i64 @__olang_fmt_i64(ptr null, i64 %t138)
  %t140 = add i64 %t137, %t139
  %t141 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 1
  %t142 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 0
  %t143 = add i64 %t140, %t142
  %t144 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t133, i64 %t134)
  %t149 = getelementptr i8, ptr %t148, i64 %t134
  call void @olang_textcopy(ptr %t149, ptr %t135, i64 %t136)
  %t150 = getelementptr i8, ptr %t149, i64 %t136
  %t151 = call i64 @__olang_fmt_i64(ptr %t150, i64 %t138)
  %t152 = getelementptr i8, ptr %t150, i64 %t139
  call void @olang_textcopy(ptr %t152, ptr %t141, i64 %t142)
  %t153 = getelementptr i8, ptr %t152, i64 %t142
  call void @olang_textcopy(ptr %t153, ptr %t145, i64 %t146)
  %t154 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t148, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s4, ptr %t163, { i64, ptr } %t162)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t165 = load i64, ptr %l7, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l7, !tbaa !24
  br label %bb15
bb26:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l102, !tbaa !29
  %t171 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l2)
  store { i64, ptr } %t171, ptr %l104
  br label %bb27
bb27:
  %t172 = extractvalue { i64, ptr } { i64 5, ptr @.d27 }, 1
  %t173 = extractvalue { i64, ptr } { i64 5, ptr @.d27 }, 0
  %t174 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = add i64 %t173, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t172, i64 %t173)
  %t179 = getelementptr i8, ptr %t178, i64 %t173
  call void @olang_textcopy(ptr %t179, ptr %t175, i64 %t176)
  %t180 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t178, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t189 = load ptr, ptr %l102, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s2, ptr %t189, i64 1, { i64, ptr } %t188)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  store i64 0, ptr %l9, !tbaa !24
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr %"compiler/mir:Fn", ptr %t191, i32 0, i32 7
  %t195 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t193)
  store i64 %t195, ptr %l109
  br label %bb30
bb30:
  %t196 = load i64, ptr %l109, !tbaa !24
  store i64 %t196, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t197 = load i64, ptr %l10, !tbaa !24
  %t198 = load i64, ptr %l9, !tbaa !24
  %t201 = icmp sgt i64 %t197, %t198
  br i1 %t201, label %bb31, label %bb32
bb31:
  %t203 = load i64, ptr %l11, !tbaa !24
  %t205 = icmp sgt i64 %t203, 0
  br i1 %t205, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb36
bb33:
  %t207 = load i64, ptr %l10, !tbaa !24
  %t208 = load i64, ptr %l9, !tbaa !24
  %t211 = sub i64 %t207, %t208
  %t212 = load i64, ptr %l11, !tbaa !24
  %t215 = add i64 %t211, %t212
  %t217 = sub i64 %t215, 1
  %t218 = load i64, ptr %l11, !tbaa !24
  %t221 = sdiv i64 %t217, %t218
  store i64 %t221, ptr %l116, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb35
bb35:
  %t223 = load i64, ptr %l116, !tbaa !24
  store i64 %t223, ptr %l113, !tbaa !24
  br label %bb36
bb36:
  %t224 = load i64, ptr %l113, !tbaa !24
  store i64 %t224, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t225 = load i64, ptr %l13, !tbaa !24
  %t226 = load i64, ptr %l12, !tbaa !24
  %t229 = icmp slt i64 %t225, %t226
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb39:
  br label %bb40
bb40:
  %t233 = load i64, ptr %l9, !tbaa !24
  %t234 = load i64, ptr %l13, !tbaa !24
  %t235 = load i64, ptr %l11, !tbaa !24
  %t238 = mul i64 %t234, %t235
  %t241 = add i64 %t233, %t238
  store i64 %t241, ptr %l14, !tbaa !24
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t245 = getelementptr %"compiler/mir:Fn", ptr %t243, i32 0, i32 7
  %t246 = load i64, ptr %l14, !tbaa !24
  %t249 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t245, i64 %t246)
  store %"compiler/mir:Local" %t249, ptr %l137
  br label %bb41
bb41:
  %t250 = load %"compiler/mir:Local", ptr %l137
  store %"compiler/mir:Local" %t250, ptr %l15
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/mir:dumper", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = getelementptr %"compiler/types:Table", ptr %t254, i32 0, i32 0
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t258 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 0
  %t259 = load i32, ptr %t258, !tbaa !23
  %t262 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t257, i32 %t259)
  store { i64, ptr } %t262, ptr %l142
  br label %bb42
bb42:
  %t263 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t263, ptr %l16, !tbaa !27
  %t264 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 4
  %t265 = load { i64, [1 x i64] }, ptr %t264
  %t267 = extractvalue { i64, [1 x i64] } %t265, 0
  %t268 = icmp eq i64 %t267, 3
  br i1 %t268, label %bb43, label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr @.d28 }, ptr %l145, !tbaa !27
  br label %bb46
bb44:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 4
  %t272 = load { i64, [1 x i64] }, ptr %t271
  %t275 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s9, ptr %t270, { i64, [1 x i64] } %t272)
  store { i64, ptr } %t275, ptr %l148
  br label %bb45
bb45:
  %t276 = extractvalue { i64, ptr } { i64 4, ptr @.d29 }, 1
  %t277 = extractvalue { i64, ptr } { i64 4, ptr @.d29 }, 0
  %t278 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = add i64 %t277, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t276, i64 %t277)
  %t283 = getelementptr i8, ptr %t282, i64 %t277
  call void @olang_textcopy(ptr %t283, ptr %t279, i64 %t280)
  %t284 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t282, 1
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t288 = extractvalue { i64, ptr } %t285, 1
  %t289 = mul i64 %t287, 1
  %t290 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t289)
  call void @llvm.memcpy.p0.p0.i64(ptr %t290, ptr %t288, i64 %t289, i1 false)
  %t291 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  store { i64, ptr } %t292, ptr %l145, !tbaa !27
  br label %bb46
bb46:
  %t294 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t294, ptr %l17, !tbaa !27
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l151, !tbaa !29
  %t296 = load i64, ptr %l14, !tbaa !24
  store i64 %t296, ptr %l152, !tbaa !24
  %t297 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 3
  %t298 = load i32, ptr %t297
  store i32 %t298, ptr %l153
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aLocalKind(ptr %s11, ptr %l153, i64 0)
  br label %bb47
bb47:
  %t300 = load ptr, ptr %s11
  %t301 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t302 = load i64, ptr %t301
  %t303 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t302)
  call void @olang_textcopy(ptr %t303, ptr %t300, i64 %t302)
  %t304 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  store { i64, ptr } %t305, ptr %l155, !tbaa !27
  %t306 = getelementptr %olang.builder, ptr %s11, i32 0, i32 3
  %t307 = load ptr, ptr %t306
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %sbgrew.309, label %sbdone.310
sbgrew.309:
  call void @__olang_sb_done(ptr %s11)
  br label %sbdone.310
sbdone.310:
  %t311 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  %t313 = extractvalue { i64, ptr } %t311, 1
  %t314 = mul i64 %t312, 1
  %t315 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t314)
  call void @llvm.memcpy.p0.p0.i64(ptr %t315, ptr %t313, i64 %t314, i1 false)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t315, 1
  %t319 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s9, { i64, ptr } %t317)
  store { i64, ptr } %t319, ptr %l157
  br label %bb48
bb48:
  %t320 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t324 = icmp sgt i64 %t322, 0
  br i1 %t324, label %bb49, label %bb50
bb49:
  %t326 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t327 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 1
  %t328 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 0
  %t330 = extractvalue { i64, ptr } %t326, 1
  %t331 = extractvalue { i64, ptr } %t326, 0
  %t332 = add i64 %t328, %t331
  %t333 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t327, i64 %t328)
  %t334 = getelementptr i8, ptr %t333, i64 %t328
  call void @olang_textcopy(ptr %t334, ptr %t330, i64 %t331)
  %t335 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t333, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = extractvalue { i64, ptr } %t336, 1
  %t340 = mul i64 %t338, 1
  %t341 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t340)
  call void @llvm.memcpy.p0.p0.i64(ptr %t341, ptr %t339, i64 %t340, i1 false)
  %t342 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t341, 1
  store { i64, ptr } %t343, ptr %l161, !tbaa !27
  br label %bb51
bb50:
  store { i64, ptr } { i64 0, ptr @.d31 }, ptr %l161, !tbaa !27
  br label %bb51
bb51:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/mir:dumper", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t349 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 2
  %t350 = load i32, ptr %t349, !tbaa !23
  %t353 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s9, ptr %t348, i32 %t350)
  store { i64, ptr } %t353, ptr %l168
  br label %bb52
bb52:
  %t354 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t355 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 1
  %t356 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 0
  %t357 = load i64, ptr %l152, !tbaa !24
  %t358 = call i64 @__olang_fmt_i64(ptr null, i64 %t357)
  %t359 = add i64 %t356, %t358
  %t360 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 1
  %t361 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 0
  %t362 = add i64 %t359, %t361
  %t363 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t363, 1
  %t365 = extractvalue { i64, ptr } %t363, 0
  %t366 = add i64 %t362, %t365
  %t367 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t367, 1
  %t369 = extractvalue { i64, ptr } %t367, 0
  %t370 = add i64 %t366, %t369
  %t371 = extractvalue { i64, ptr } { i64 2, ptr @.d34 }, 1
  %t372 = extractvalue { i64, ptr } { i64 2, ptr @.d34 }, 0
  %t373 = add i64 %t370, %t372
  %t374 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = add i64 %t373, %t376
  %t379 = extractvalue { i64, ptr } %t354, 1
  %t380 = extractvalue { i64, ptr } %t354, 0
  %t381 = add i64 %t377, %t380
  %t382 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t381)
  call void @olang_textcopy(ptr %t382, ptr %t355, i64 %t356)
  %t383 = getelementptr i8, ptr %t382, i64 %t356
  %t384 = call i64 @__olang_fmt_i64(ptr %t383, i64 %t357)
  %t385 = getelementptr i8, ptr %t383, i64 %t358
  call void @olang_textcopy(ptr %t385, ptr %t360, i64 %t361)
  %t386 = getelementptr i8, ptr %t385, i64 %t361
  call void @olang_textcopy(ptr %t386, ptr %t364, i64 %t365)
  %t387 = getelementptr i8, ptr %t386, i64 %t365
  call void @olang_textcopy(ptr %t387, ptr %t368, i64 %t369)
  %t388 = getelementptr i8, ptr %t387, i64 %t369
  call void @olang_textcopy(ptr %t388, ptr %t371, i64 %t372)
  %t389 = getelementptr i8, ptr %t388, i64 %t372
  call void @olang_textcopy(ptr %t389, ptr %t375, i64 %t376)
  %t390 = getelementptr i8, ptr %t389, i64 %t376
  call void @olang_textcopy(ptr %t390, ptr %t379, i64 %t380)
  %t391 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t392 = insertvalue { i64, ptr } %t391, ptr %t382, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = extractvalue { i64, ptr } %t392, 1
  %t396 = mul i64 %t394, 1
  %t397 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t396)
  call void @llvm.memcpy.p0.p0.i64(ptr %t397, ptr %t395, i64 %t396, i1 false)
  %t398 = insertvalue { i64, ptr } undef, i64 %t394, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  %t400 = load ptr, ptr %l151, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s9, ptr %t400, i64 1, { i64, ptr } %t399)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t402 = load i64, ptr %l13, !tbaa !24
  %t404 = add i64 %t402, 1
  store i64 %t404, ptr %l13, !tbaa !24
  br label %bb37
bb55:
  store i64 0, ptr %l18, !tbaa !24
  %t406 = load ptr, ptr %l1, !tbaa !29
  %t408 = getelementptr %"compiler/mir:Fn", ptr %t406, i32 0, i32 8
  %t410 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t408)
  store i64 %t410, ptr %l176
  br label %bb56
bb56:
  %t411 = load i64, ptr %l176, !tbaa !24
  store i64 %t411, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t412 = load i64, ptr %l19, !tbaa !24
  %t413 = load i64, ptr %l18, !tbaa !24
  %t416 = icmp sgt i64 %t412, %t413
  br i1 %t416, label %bb57, label %bb58
bb57:
  %t418 = load i64, ptr %l20, !tbaa !24
  %t420 = icmp sgt i64 %t418, 0
  br i1 %t420, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb62
bb59:
  %t422 = load i64, ptr %l19, !tbaa !24
  %t423 = load i64, ptr %l18, !tbaa !24
  %t426 = sub i64 %t422, %t423
  %t427 = load i64, ptr %l20, !tbaa !24
  %t430 = add i64 %t426, %t427
  %t432 = sub i64 %t430, 1
  %t433 = load i64, ptr %l20, !tbaa !24
  %t436 = sdiv i64 %t432, %t433
  store i64 %t436, ptr %l183, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb61
bb61:
  %t438 = load i64, ptr %l183, !tbaa !24
  store i64 %t438, ptr %l180, !tbaa !24
  br label %bb62
bb62:
  %t439 = load i64, ptr %l180, !tbaa !24
  store i64 %t439, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s16
  %t440 = load i64, ptr %l22, !tbaa !24
  %t441 = load i64, ptr %l21, !tbaa !24
  %t444 = icmp slt i64 %t440, %t441
  %t446 = xor i1 %t444, true
  br i1 %t446, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s16)
  br label %bb82
bb65:
  br label %bb66
bb66:
  %t448 = load i64, ptr %l18, !tbaa !24
  %t449 = load i64, ptr %l22, !tbaa !24
  %t450 = load i64, ptr %l20, !tbaa !24
  %t453 = mul i64 %t449, %t450
  %t456 = add i64 %t448, %t453
  store i64 %t456, ptr %l23, !tbaa !24
  %t458 = load ptr, ptr %l1, !tbaa !29
  %t460 = getelementptr %"compiler/mir:Fn", ptr %t458, i32 0, i32 8
  %t461 = load i64, ptr %l23, !tbaa !24
  %t464 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t460, i64 %t461)
  store %"compiler/mir:ScopeInfo" %t464, ptr %l204
  br label %bb67
bb67:
  %t465 = load %"compiler/mir:ScopeInfo", ptr %l204
  store %"compiler/mir:ScopeInfo" %t465, ptr %l24
  %t466 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 1
  %t467 = load i32, ptr %t466, !tbaa !23
  %t468 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t471 = icmp eq i32 %t467, %t468
  br i1 %t471, label %bb68, label %bb69
bb68:
  store { i64, ptr } { i64 0, ptr @.d35 }, ptr %l208, !tbaa !27
  br label %bb70
bb69:
  %t473 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 1
  %t474 = load i32, ptr %t473, !tbaa !23
  %t475 = extractvalue { i64, ptr } { i64 5, ptr @.d36 }, 1
  %t476 = extractvalue { i64, ptr } { i64 5, ptr @.d36 }, 0
  %t478 = sext i32 %t474 to i64
  %t479 = call i64 @__olang_fmt_i64(ptr null, i64 %t478)
  %t480 = add i64 %t476, %t479
  %t481 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t480)
  call void @olang_textcopy(ptr %t481, ptr %t475, i64 %t476)
  %t482 = getelementptr i8, ptr %t481, i64 %t476
  %t483 = call i64 @__olang_fmt_i64(ptr %t482, i64 %t478)
  %t484 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t485 = insertvalue { i64, ptr } %t484, ptr %t481, 1
  %t487 = extractvalue { i64, ptr } %t485, 0
  %t488 = extractvalue { i64, ptr } %t485, 1
  %t489 = mul i64 %t487, 1
  %t490 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t489)
  call void @llvm.memcpy.p0.p0.i64(ptr %t490, ptr %t488, i64 %t489, i1 false)
  %t491 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t490, 1
  store { i64, ptr } %t492, ptr %l208, !tbaa !27
  br label %bb70
bb70:
  %t494 = load { i64, ptr }, ptr %l208, !tbaa !27
  store { i64, ptr } %t494, ptr %l25, !tbaa !27
  %t495 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 2
  %t496 = load i32, ptr %t495, !tbaa !23
  %t498 = icmp slt i32 %t496, 0
  br i1 %t498, label %bb71, label %bb72
bb71:
  store { i64, ptr } { i64 0, ptr @.d37 }, ptr %l214, !tbaa !27
  br label %bb73
bb72:
  %t500 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 2
  %t501 = load i32, ptr %t500, !tbaa !23
  %t502 = extractvalue { i64, ptr } { i64 7, ptr @.d38 }, 1
  %t503 = extractvalue { i64, ptr } { i64 7, ptr @.d38 }, 0
  %t505 = sext i32 %t501 to i64
  %t506 = call i64 @__olang_fmt_i64(ptr null, i64 %t505)
  %t507 = add i64 %t503, %t506
  %t508 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t507)
  call void @olang_textcopy(ptr %t508, ptr %t502, i64 %t503)
  %t509 = getelementptr i8, ptr %t508, i64 %t503
  %t510 = call i64 @__olang_fmt_i64(ptr %t509, i64 %t505)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t508, 1
  %t514 = extractvalue { i64, ptr } %t512, 0
  %t515 = extractvalue { i64, ptr } %t512, 1
  %t516 = mul i64 %t514, 1
  %t517 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t516)
  call void @llvm.memcpy.p0.p0.i64(ptr %t517, ptr %t515, i64 %t516, i1 false)
  %t518 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t517, 1
  store { i64, ptr } %t519, ptr %l214, !tbaa !27
  br label %bb73
bb73:
  %t521 = load { i64, ptr }, ptr %l214, !tbaa !27
  store { i64, ptr } %t521, ptr %l26, !tbaa !27
  %t522 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 4
  %t523 = load i32, ptr %t522, !tbaa !23
  %t525 = icmp eq i32 %t523, 0
  br i1 %t525, label %bb74, label %bb75
bb74:
  store { i64, ptr } { i64 0, ptr @.d39 }, ptr %l220, !tbaa !27
  br label %bb77
bb75:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 4
  %t529 = load i32, ptr %t528, !tbaa !23
  %t532 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %s16, ptr %t527, i32 %t529)
  store { i64, ptr } %t532, ptr %l223
  br label %bb76
bb76:
  %t533 = extractvalue { i64, ptr } { i64 7, ptr @.d40 }, 1
  %t534 = extractvalue { i64, ptr } { i64 7, ptr @.d40 }, 0
  %t535 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t536 = extractvalue { i64, ptr } %t535, 1
  %t537 = extractvalue { i64, ptr } %t535, 0
  %t538 = add i64 %t534, %t537
  %t539 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t538)
  call void @olang_textcopy(ptr %t539, ptr %t533, i64 %t534)
  %t540 = getelementptr i8, ptr %t539, i64 %t534
  call void @olang_textcopy(ptr %t540, ptr %t536, i64 %t537)
  %t541 = insertvalue { i64, ptr } undef, i64 %t538, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t539, 1
  %t544 = extractvalue { i64, ptr } %t542, 0
  %t545 = extractvalue { i64, ptr } %t542, 1
  %t546 = mul i64 %t544, 1
  %t547 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t546)
  call void @llvm.memcpy.p0.p0.i64(ptr %t547, ptr %t545, i64 %t546, i1 false)
  %t548 = insertvalue { i64, ptr } undef, i64 %t544, 0
  %t549 = insertvalue { i64, ptr } %t548, ptr %t547, 1
  store { i64, ptr } %t549, ptr %l220, !tbaa !27
  br label %bb77
bb77:
  %t551 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t551, ptr %l27, !tbaa !27
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l226, !tbaa !29
  %t553 = load i64, ptr %l23, !tbaa !24
  store i64 %t553, ptr %l227, !tbaa !24
  %t554 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 0
  %t555 = load i32, ptr %t554
  store i32 %t555, ptr %l228
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s20
  store ptr %s20room, ptr %s20
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aScopeKind(ptr %s20, ptr %l228, i64 0)
  br label %bb78
bb78:
  %t557 = load ptr, ptr %s20
  %t558 = getelementptr %olang.builder, ptr %s20, i32 0, i32 1
  %t559 = load i64, ptr %t558
  %t560 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t559)
  call void @olang_textcopy(ptr %t560, ptr %t557, i64 %t559)
  %t561 = insertvalue { i64, ptr } undef, i64 %t559, 0
  %t562 = insertvalue { i64, ptr } %t561, ptr %t560, 1
  store { i64, ptr } %t562, ptr %l230, !tbaa !27
  %t563 = getelementptr %olang.builder, ptr %s20, i32 0, i32 3
  %t564 = load ptr, ptr %t563
  %t565 = icmp ne ptr %t564, null
  br i1 %t565, label %sbgrew.566, label %sbdone.567
sbgrew.566:
  call void @__olang_sb_done(ptr %s20)
  br label %sbdone.567
sbdone.567:
  %t568 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 0
  %t570 = extractvalue { i64, ptr } %t568, 1
  %t571 = mul i64 %t569, 1
  %t572 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t571)
  call void @llvm.memcpy.p0.p0.i64(ptr %t572, ptr %t570, i64 %t571, i1 false)
  %t573 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t572, 1
  %t576 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s16, { i64, ptr } %t574)
  store { i64, ptr } %t576, ptr %l232
  br label %bb79
bb79:
  %t577 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t578 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t579 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t580 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 1
  %t581 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 0
  %t582 = load i64, ptr %l227, !tbaa !24
  %t583 = call i64 @__olang_fmt_i64(ptr null, i64 %t582)
  %t584 = add i64 %t581, %t583
  %t585 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 1
  %t586 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 0
  %t587 = add i64 %t584, %t586
  %t588 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t589 = extractvalue { i64, ptr } %t588, 1
  %t590 = extractvalue { i64, ptr } %t588, 0
  %t591 = add i64 %t587, %t590
  %t593 = extractvalue { i64, ptr } %t577, 1
  %t594 = extractvalue { i64, ptr } %t577, 0
  %t595 = add i64 %t591, %t594
  %t597 = extractvalue { i64, ptr } %t578, 1
  %t598 = extractvalue { i64, ptr } %t578, 0
  %t599 = add i64 %t595, %t598
  %t601 = extractvalue { i64, ptr } %t579, 1
  %t602 = extractvalue { i64, ptr } %t579, 0
  %t603 = add i64 %t599, %t602
  %t604 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t603)
  call void @olang_textcopy(ptr %t604, ptr %t580, i64 %t581)
  %t605 = getelementptr i8, ptr %t604, i64 %t581
  %t606 = call i64 @__olang_fmt_i64(ptr %t605, i64 %t582)
  %t607 = getelementptr i8, ptr %t605, i64 %t583
  call void @olang_textcopy(ptr %t607, ptr %t585, i64 %t586)
  %t608 = getelementptr i8, ptr %t607, i64 %t586
  call void @olang_textcopy(ptr %t608, ptr %t589, i64 %t590)
  %t609 = getelementptr i8, ptr %t608, i64 %t590
  call void @olang_textcopy(ptr %t609, ptr %t593, i64 %t594)
  %t610 = getelementptr i8, ptr %t609, i64 %t594
  call void @olang_textcopy(ptr %t610, ptr %t597, i64 %t598)
  %t611 = getelementptr i8, ptr %t610, i64 %t598
  call void @olang_textcopy(ptr %t611, ptr %t601, i64 %t602)
  %t612 = insertvalue { i64, ptr } undef, i64 %t603, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t604, 1
  %t615 = extractvalue { i64, ptr } %t613, 0
  %t616 = extractvalue { i64, ptr } %t613, 1
  %t617 = mul i64 %t615, 1
  %t618 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t617)
  call void @llvm.memcpy.p0.p0.i64(ptr %t618, ptr %t616, i64 %t617, i1 false)
  %t619 = insertvalue { i64, ptr } undef, i64 %t615, 0
  %t620 = insertvalue { i64, ptr } %t619, ptr %t618, 1
  %t621 = load ptr, ptr %l226, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s16, ptr %t621, i64 1, { i64, ptr } %t620)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s16)
  br label %bb81
bb81:
  %t623 = load i64, ptr %l22, !tbaa !24
  %t625 = add i64 %t623, 1
  store i64 %t625, ptr %l22, !tbaa !24
  br label %bb63
bb82:
  store i64 0, ptr %l28, !tbaa !24
  %t627 = load ptr, ptr %l1, !tbaa !29
  %t629 = getelementptr %"compiler/mir:Fn", ptr %t627, i32 0, i32 9
  %t631 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %t629)
  store i64 %t631, ptr %l242
  br label %bb83
bb83:
  %t632 = load i64, ptr %l242, !tbaa !24
  store i64 %t632, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t633 = load i64, ptr %l29, !tbaa !24
  %t634 = load i64, ptr %l28, !tbaa !24
  %t637 = icmp sgt i64 %t633, %t634
  br i1 %t637, label %bb84, label %bb85
bb84:
  %t639 = load i64, ptr %l30, !tbaa !24
  %t641 = icmp sgt i64 %t639, 0
  br i1 %t641, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l246, !tbaa !24
  br label %bb89
bb86:
  %t643 = load i64, ptr %l29, !tbaa !24
  %t644 = load i64, ptr %l28, !tbaa !24
  %t647 = sub i64 %t643, %t644
  %t648 = load i64, ptr %l30, !tbaa !24
  %t651 = add i64 %t647, %t648
  %t653 = sub i64 %t651, 1
  %t654 = load i64, ptr %l30, !tbaa !24
  %t657 = sdiv i64 %t653, %t654
  store i64 %t657, ptr %l249, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l249, !tbaa !24
  br label %bb88
bb88:
  %t659 = load i64, ptr %l249, !tbaa !24
  store i64 %t659, ptr %l246, !tbaa !24
  br label %bb89
bb89:
  %t660 = load i64, ptr %l246, !tbaa !24
  store i64 %t660, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb90
bb90:
  store %olang.scope zeroinitializer, ptr %s24
  %t661 = load i64, ptr %l32, !tbaa !24
  %t662 = load i64, ptr %l31, !tbaa !24
  %t665 = icmp slt i64 %t661, %t662
  %t667 = xor i1 %t665, true
  br i1 %t667, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s24)
  br label %bb116
bb92:
  br label %bb93
bb93:
  %t669 = load i64, ptr %l28, !tbaa !24
  %t670 = load i64, ptr %l32, !tbaa !24
  %t671 = load i64, ptr %l30, !tbaa !24
  %t674 = mul i64 %t670, %t671
  %t677 = add i64 %t669, %t674
  store i64 %t677, ptr %l33, !tbaa !24
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load i64, ptr %l33, !tbaa !24
  %t681 = extractvalue { i64, ptr } { i64 2, ptr @.d43 }, 1
  %t682 = extractvalue { i64, ptr } { i64 2, ptr @.d43 }, 0
  %t684 = call i64 @__olang_fmt_i64(ptr null, i64 %t680)
  %t685 = add i64 %t682, %t684
  %t686 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 1
  %t687 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 0
  %t688 = add i64 %t685, %t687
  %t689 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t688)
  call void @olang_textcopy(ptr %t689, ptr %t681, i64 %t682)
  %t690 = getelementptr i8, ptr %t689, i64 %t682
  %t691 = call i64 @__olang_fmt_i64(ptr %t690, i64 %t680)
  %t692 = getelementptr i8, ptr %t690, i64 %t684
  call void @olang_textcopy(ptr %t692, ptr %t686, i64 %t687)
  %t693 = insertvalue { i64, ptr } undef, i64 %t688, 0
  %t694 = insertvalue { i64, ptr } %t693, ptr %t689, 1
  %t696 = extractvalue { i64, ptr } %t694, 0
  %t697 = extractvalue { i64, ptr } %t694, 1
  %t698 = mul i64 %t696, 1
  %t699 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t698)
  call void @llvm.memcpy.p0.p0.i64(ptr %t699, ptr %t697, i64 %t698, i1 false)
  %t700 = insertvalue { i64, ptr } undef, i64 %t696, 0
  %t701 = insertvalue { i64, ptr } %t700, ptr %t699, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s24, ptr %t679, i64 0, { i64, ptr } %t701)
  br label %bb94
bb94:
  %t704 = load ptr, ptr %l1, !tbaa !29
  %t706 = getelementptr %"compiler/mir:Fn", ptr %t704, i32 0, i32 9
  %t707 = load i64, ptr %l33, !tbaa !24
  %t710 = call %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v0, ptr %t706, i64 %t707)
  store %"compiler/mir:BasicBlock" %t710, ptr %l274
  br label %bb95
bb95:
  %t711 = load %"compiler/mir:BasicBlock", ptr %l274
  store %"compiler/mir:BasicBlock" %t711, ptr %l34
  %t712 = getelementptr %"compiler/mir:BasicBlock", ptr %l34, i32 0, i32 0
  store ptr %t712, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s27
  %t714 = load ptr, ptr %l35, !tbaa !29
  %t715 = load i64, ptr %l36, !tbaa !24
  %t718 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t714, i64 %t715)
  %t719 = extractvalue { i32, { i64, ptr } } %t718, 1
  %t720 = extractvalue { i32, { i64, ptr } } %t718, 0
  store i32 %t720, ptr %l280
  %t721 = icmp ne i32 %t720, 0
  br i1 %t721, label %bb98, label %ok.722
ok.722:
  store { i64, ptr } %t719, ptr %l279
  br label %bb97
bb97:
  %t723 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t723, ptr %l276, !tbaa !27
  br label %bb102
bb98:
  %t724 = load i32, ptr %l280, !tbaa !23
  %t725 = ashr i32 %t724, 16
  %t727 = icmp eq i32 %t725, 1
  br i1 %t727, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_8b8463115590657e_a0505b934de728da)
  unreachable
bb101:
  call void @__olang_scope_close(ptr %s27)
  br label %bb112
bb102:
  %t729 = load { i64, ptr }, ptr %l276, !tbaa !27
  store { i64, ptr } %t729, ptr %l37, !tbaa !27
  %t730 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t732 = extractvalue { i64, ptr } %t730, 0
  store i64 %t732, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb103
bb103:
  store %olang.scope zeroinitializer, ptr %s28
  %t734 = load i64, ptr %l39, !tbaa !24
  %t735 = load i64, ptr %l38, !tbaa !24
  %t738 = icmp slt i64 %t734, %t735
  %t740 = xor i1 %t738, true
  br i1 %t740, label %bb104, label %bb105
bb104:
  call void @__olang_scope_close(ptr %s28)
  br label %bb110
bb105:
  br label %bb106
bb106:
  %t742 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t742, ptr %l289, !tbaa !27
  %t743 = load i64, ptr %l39, !tbaa !24
  %t745 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t746 = load ptr, ptr %t745, !tbaa !27
  %t747 = getelementptr { i64, [21 x i64] }, ptr %t746, i64 %t743
  call void @llvm.memmove.p0.p0.i64(ptr %l291, ptr %t747, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %l291, i64 176, i1 false)
  %t748 = load ptr, ptr %l0, !tbaa !29
  store ptr %t748, ptr %l292, !tbaa !29
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t752 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2estmt(ptr %v0, ptr %s28, ptr %s28, ptr %t749, ptr %l40)
  store { i64, ptr } %t752, ptr %l295
  br label %bb107
bb107:
  %t753 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t754 = extractvalue { i64, ptr } %t753, 0
  %t755 = extractvalue { i64, ptr } %t753, 1
  %t756 = mul i64 %t754, 1
  %t757 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t756)
  call void @llvm.memcpy.p0.p0.i64(ptr %t757, ptr %t755, i64 %t756, i1 false)
  %t758 = insertvalue { i64, ptr } undef, i64 %t754, 0
  %t759 = insertvalue { i64, ptr } %t758, ptr %t757, 1
  %t760 = load ptr, ptr %l292, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s28, ptr %t760, i64 1, { i64, ptr } %t759)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s28)
  br label %bb109
bb109:
  %t762 = load i64, ptr %l39, !tbaa !24
  %t764 = add i64 %t762, 1
  store i64 %t764, ptr %l39, !tbaa !24
  br label %bb103
bb110:
  %t766 = load i64, ptr %l36, !tbaa !24
  %t767 = load i64, ptr %l38, !tbaa !24
  %t770 = add i64 %t766, %t767
  store i64 %t770, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s27)
  br label %bb111
bb111:
  br label %bb96
bb112:
  %t772 = load ptr, ptr %l0, !tbaa !29
  store ptr %t772, ptr %l302, !tbaa !29
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t774 = getelementptr %"compiler/mir:BasicBlock", ptr %l34, i32 0, i32 1
  %t775 = load { i64, [7 x i64] }, ptr %t774
  %t778 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eterm(ptr %v0, ptr %s24, ptr %t773, { i64, [7 x i64] } %t775)
  store { i64, ptr } %t778, ptr %l305
  br label %bb113
bb113:
  %t779 = load { i64, ptr }, ptr %l305, !tbaa !27
  %t780 = extractvalue { i64, ptr } %t779, 0
  %t781 = extractvalue { i64, ptr } %t779, 1
  %t782 = mul i64 %t780, 1
  %t783 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t782)
  call void @llvm.memcpy.p0.p0.i64(ptr %t783, ptr %t781, i64 %t782, i1 false)
  %t784 = insertvalue { i64, ptr } undef, i64 %t780, 0
  %t785 = insertvalue { i64, ptr } %t784, ptr %t783, 1
  %t786 = load ptr, ptr %l302, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s24, ptr %t786, i64 1, { i64, ptr } %t785)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s24)
  br label %bb115
bb115:
  %t788 = load i64, ptr %l32, !tbaa !24
  %t790 = add i64 %t788, 1
  store i64 %t790, ptr %l32, !tbaa !24
  br label %bb90
bb116:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecases(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Case"
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i32
  %l18 = alloca i32
  %l44 = alloca %"compiler/mir:Case"
  %l45 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i32 0, ptr %l3, !tbaa !23
  %t3 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = icmp sgt i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t14 = icmp sgt i32 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb7
bb4:
  %t16 = load i32, ptr %l4, !tbaa !23
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = sub i32 %t16, %t17
  %t21 = load i32, ptr %l5, !tbaa !23
  %t24 = add i32 %t20, %t21
  %t26 = sub i32 %t24, 1
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = sdiv i32 %t26, %t27
  store i32 %t30, ptr %l18, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l18, !tbaa !23
  store i32 %t32, ptr %l15, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l15, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i32, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l6, !tbaa !23
  %t38 = icmp slt i32 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = mul i32 %t43, %t44
  %t50 = add i32 %t42, %t47
  store i32 %t50, ptr %l8, !tbaa !23
  %t54 = getelementptr %"compiler/mir:dumper", ptr %a0, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/mir:Fn", ptr %t55, i32 0, i32 15
  %t58 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t62 = load i32, ptr %l8, !tbaa !23
  %t64 = sext i32 %t62 to i64
  %t67 = add i64 %t61, %t64
  %t70 = call %"compiler/mir:Case" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t57, i64 %t67)
  store %"compiler/mir:Case" %t70, ptr %l44
  br label %bb12
bb12:
  %t71 = load %"compiler/mir:Case", ptr %l44
  store %"compiler/mir:Case" %t71, ptr %l9
  store ptr %l2, ptr %l45, !tbaa !29
  %t72 = load i32, ptr %l8, !tbaa !23
  %t74 = icmp sgt i32 %t72, 0
  br i1 %t74, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 2, ptr @.d45 }, ptr %l48, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr @.d46 }, ptr %l48, !tbaa !27
  br label %bb15
bb15:
  %t76 = getelementptr %"compiler/mir:Case", ptr %l9, i32 0, i32 0
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = getelementptr %"compiler/mir:Case", ptr %l9, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  %t80 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = call i64 @__olang_fmt_i64(ptr null, i64 %t77)
  %t85 = add i64 %t82, %t84
  %t86 = extractvalue { i64, ptr } { i64 3, ptr @.d47 }, 1
  %t87 = extractvalue { i64, ptr } { i64 3, ptr @.d47 }, 0
  %t88 = add i64 %t85, %t87
  %t90 = sext i32 %t79 to i64
  %t91 = call i64 @__olang_fmt_i64(ptr null, i64 %t90)
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t81, i64 %t82)
  %t94 = getelementptr i8, ptr %t93, i64 %t82
  %t95 = call i64 @__olang_fmt_i64(ptr %t94, i64 %t77)
  %t96 = getelementptr i8, ptr %t94, i64 %t84
  call void @olang_textcopy(ptr %t96, ptr %t86, i64 %t87)
  %t97 = getelementptr i8, ptr %t96, i64 %t87
  %t98 = call i64 @__olang_fmt_i64(ptr %t97, i64 %t90)
  %t99 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t93, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t108, { i64, ptr } %t107)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t110 = load i32, ptr %l7, !tbaa !23
  %t112 = add i32 %t110, 1
  store i32 %t112, ptr %l7, !tbaa !23
  br label %bb8
bb18:
  %t115 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t115, ptr %l56
  br label %bb19
bb19:
  %t116 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t116, ptr %l57, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l58, !tbaa !24
  %t119 = load i64, ptr %l58, !tbaa !24
  %t120 = mul i64 %t119, 1
  %t121 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l59, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l58, !tbaa !24
  %t129 = mul i64 %t128, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t130, ptr %l57, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t131 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t131, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i32
  %l18 = alloca i32
  %l36 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 91)
  br label %bb2
bb2:
  store i32 0, ptr %l3, !tbaa !23
  %t4 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = icmp sgt i32 %t7, %t8
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load i32, ptr %l5, !tbaa !23
  %t15 = icmp sgt i32 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb4:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb8
bb5:
  %t17 = load i32, ptr %l4, !tbaa !23
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = sub i32 %t17, %t18
  %t22 = load i32, ptr %l5, !tbaa !23
  %t25 = add i32 %t21, %t22
  %t27 = sub i32 %t25, 1
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = sdiv i32 %t27, %t28
  store i32 %t31, ptr %l18, !tbaa !23
  br label %bb7
bb6:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l18, !tbaa !23
  store i32 %t33, ptr %l15, !tbaa !23
  br label %bb8
bb8:
  %t34 = load i32, ptr %l15, !tbaa !23
  store i32 %t34, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i32, ptr %l7, !tbaa !23
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = icmp slt i32 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t43 = load i32, ptr %l3, !tbaa !23
  %t44 = load i32, ptr %l7, !tbaa !23
  %t45 = load i32, ptr %l5, !tbaa !23
  %t48 = mul i32 %t44, %t45
  %t51 = add i32 %t43, %t48
  store i32 %t51, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l36, !tbaa !29
  %t53 = load i32, ptr %l8, !tbaa !23
  %t55 = icmp sgt i32 %t53, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 1, ptr @.d48 }, ptr %l39, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr @.d49 }, ptr %l39, !tbaa !27
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/mir:dumper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/mir:Fn", ptr %t61, i32 0, i32 20
  %t64 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t65 = load i32, ptr %t64, !tbaa !23
  %t67 = sext i32 %t65 to i64
  %t68 = load i32, ptr %l8, !tbaa !23
  %t70 = sext i32 %t68 to i64
  %t73 = add i64 %t67, %t70
  %t76 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t63, i64 %t73)
  store i32 %t76, ptr %l49
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = load i32, ptr %l49, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %s2, ptr %t77, i32 %t78)
  store { i64, ptr } %t79, ptr %l50
  br label %bb17
bb17:
  %t80 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = add i64 %t82, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t81, i64 %t82)
  %t88 = getelementptr i8, ptr %t87, i64 %t82
  call void @olang_textcopy(ptr %t88, ptr %t84, i64 %t85)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t98 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t98, { i64, ptr } %t97)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t100 = load i32, ptr %l7, !tbaa !23
  %t102 = add i32 %t100, 1
  store i32 %t102, ptr %l7, !tbaa !23
  br label %bb9
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 93)
  br label %bb21
bb21:
  %t106 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t106, ptr %l57
  br label %bb22
bb22:
  %t107 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t107, ptr %l58, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l59, !tbaa !24
  %t110 = load i64, ptr %l59, !tbaa !24
  %t111 = mul i64 %t110, 1
  %t112 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t111)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l60, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l59, !tbaa !24
  %t120 = mul i64 %t119, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t116, ptr %t118, i64 %t120, i1 false)
  %t121 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t121, ptr %l58, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t122 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t122, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l22 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d50 }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr @.d50 }, 0
  %t14 = sext i32 %t10 to i64
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t14)
  %t16 = add i64 %t12, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = getelementptr i8, ptr %t17, i64 %t12
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  store { i64, ptr } %t21, ptr %l7, !tbaa !27
  br label %bb20
bb4:
  %t23 = load { i64, [1 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [1 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 1
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l3, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t32 = load i32, ptr %l3, !tbaa !23
  %t33 = extractvalue { i64, ptr } { i64 9, ptr @.d51 }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr @.d51 }, 0
  %t36 = sext i32 %t32 to i64
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t36)
  %t38 = add i64 %t34, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t33, i64 %t34)
  %t40 = getelementptr i8, ptr %t39, i64 %t34
  %t41 = call i64 @__olang_fmt_i64(ptr %t40, i64 %t36)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  store { i64, ptr } %t43, ptr %l7, !tbaa !27
  br label %bb20
bb8:
  %t45 = load { i64, [1 x i64] }, ptr %l1
  %t47 = extractvalue { i64, [1 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 2
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t50 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t51 = getelementptr { i32, i32 }, ptr %t50, i32 0, i32 0
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l4
  %t54 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t55 = getelementptr { i32, i32 }, ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l5, !tbaa !23
  br label %bb11
bb10:
  br label %bb15
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t58 = load i32, ptr %l4
  store i32 %t58, ptr %l22
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %s6, ptr %l22, i64 0)
  br label %bb12
bb12:
  %t60 = load ptr, ptr %s6
  %t61 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t62 = load i64, ptr %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t60, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l24, !tbaa !27
  %t66 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t67 = load ptr, ptr %t66
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %sbgrew.69, label %sbdone.70
sbgrew.69:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.70
sbdone.70:
  %t71 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t79 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s5, { i64, ptr } %t77)
  store { i64, ptr } %t79, ptr %l26
  br label %bb13
bb13:
  %t82 = getelementptr %"compiler/mir:dumper", ptr %a0, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load i32, ptr %l5, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s5, ptr %t83, i32 %t84)
  store { i64, ptr } %t87, ptr %l30
  br label %bb14
bb14:
  %t88 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = extractvalue { i64, ptr } { i64 1, ptr @.d52 }, 1
  %t92 = extractvalue { i64, ptr } { i64 1, ptr @.d52 }, 0
  %t93 = add i64 %t90, %t92
  %t94 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = add i64 %t93, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t89, i64 %t90)
  %t99 = getelementptr i8, ptr %t98, i64 %t90
  call void @olang_textcopy(ptr %t99, ptr %t91, i64 %t92)
  %t100 = getelementptr i8, ptr %t99, i64 %t92
  call void @olang_textcopy(ptr %t100, ptr %t95, i64 %t96)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t98, 1
  store { i64, ptr } %t102, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb15:
  %t104 = load { i64, [1 x i64] }, ptr %l1
  %t106 = extractvalue { i64, [1 x i64] } %t104, 0
  %t107 = icmp eq i64 %t106, 3
  br i1 %t107, label %bb16, label %bb17
bb16:
  %t109 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t110 = getelementptr { i64 }, ptr %t109, i32 0, i32 0
  %t111 = load i64, ptr %t110
  store i64 %t111, ptr %l6, !tbaa !24
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t113 = load i64, ptr %l6, !tbaa !24
  %t114 = extractvalue { i64, ptr } { i64 5, ptr @.d53 }, 1
  %t115 = extractvalue { i64, ptr } { i64 5, ptr @.d53 }, 0
  %t117 = call i64 @__olang_fmt_i64(ptr null, i64 %t113)
  %t118 = add i64 %t115, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t114, i64 %t115)
  %t120 = getelementptr i8, ptr %t119, i64 %t115
  %t121 = call i64 @__olang_fmt_i64(ptr %t120, i64 %t113)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t119, 1
  store { i64, ptr } %t123, ptr %l7, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_792180efaebdc40a_e488d776d0fba16e)
  unreachable
bb20:
  %t125 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t125, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Place"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 4, ptr @.d54 }, ptr %l12, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l9, !tbaa !27
  br label %bb21
bb4:
  %t8 = load { i64, [4 x i64] }, ptr %l1
  %t10 = extractvalue { i64, [4 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { %"compiler/mir:Place" }, ptr %t13, i32 0, i32 0
  %t15 = load %"compiler/mir:Place", ptr %t14
  store %"compiler/mir:Place" %t15, ptr %l2
  br label %bb7
bb6:
  br label %bb9
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load %"compiler/mir:Place", ptr %l2
  %t21 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s2, ptr %t17, %"compiler/mir:Place" %t18)
  store { i64, ptr } %t21, ptr %l19
  br label %bb8
bb8:
  %t22 = extractvalue { i64, ptr } { i64 5, ptr @.d55 }, 1
  %t23 = extractvalue { i64, ptr } { i64 5, ptr @.d55 }, 0
  %t24 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t22, i64 %t23)
  %t29 = getelementptr i8, ptr %t28, i64 %t23
  call void @olang_textcopy(ptr %t29, ptr %t25, i64 %t26)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  store { i64, ptr } %t31, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb9:
  %t33 = load { i64, [4 x i64] }, ptr %l1
  %t35 = extractvalue { i64, [4 x i64] } %t33, 0
  %t36 = icmp eq i64 %t35, 2
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t39 = getelementptr { i32, i64 }, ptr %t38, i32 0, i32 0
  %t40 = load i32, ptr %t39
  store i32 %t40, ptr %l3, !tbaa !23
  %t42 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { i32, i64 }, ptr %t42, i32 0, i32 1
  %t44 = load i64, ptr %t43
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/mir:dumper", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s4, ptr %t49, i32 %t50)
  store { i64, ptr } %t53, ptr %l28
  br label %bb13
bb13:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = extractvalue { i64, ptr } { i64 6, ptr @.d56 }, 1
  %t56 = extractvalue { i64, ptr } { i64 6, ptr @.d56 }, 0
  %t57 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 1, ptr @.d57 }, 1
  %t62 = extractvalue { i64, ptr } { i64 1, ptr @.d57 }, 0
  %t63 = add i64 %t60, %t62
  %t65 = call i64 @__olang_fmt_i64(ptr null, i64 %t54)
  %t66 = add i64 %t63, %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t55, i64 %t56)
  %t68 = getelementptr i8, ptr %t67, i64 %t56
  call void @olang_textcopy(ptr %t68, ptr %t58, i64 %t59)
  %t69 = getelementptr i8, ptr %t68, i64 %t59
  call void @olang_textcopy(ptr %t69, ptr %t61, i64 %t62)
  %t70 = getelementptr i8, ptr %t69, i64 %t62
  %t71 = call i64 @__olang_fmt_i64(ptr %t70, i64 %t54)
  %t72 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t67, 1
  store { i64, ptr } %t73, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb14:
  %t75 = load { i64, [4 x i64] }, ptr %l1
  %t77 = extractvalue { i64, [4 x i64] } %t75, 0
  %t78 = icmp eq i64 %t77, 3
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t81 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t80, i32 0, i32 0
  %t82 = load i32, ptr %t81
  store i32 %t82, ptr %l5, !tbaa !23
  %t84 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t85 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t84, i32 0, i32 1
  %t86 = load i32, ptr %t85
  store i32 %t86, ptr %l6, !tbaa !23
  %t88 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t89 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t88, i32 0, i32 2
  %t90 = load i64, ptr %t89
  store i64 %t90, ptr %l7, !tbaa !24
  %t92 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t93 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t92, i32 0, i32 3
  %t94 = load %"compiler/source:Span", ptr %t93
  store %"compiler/source:Span" %t94, ptr %l8
  br label %bb17
bb16:
  br label %bb20
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/mir:dumper", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i32, ptr %l5, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s6, ptr %t99, i32 %t100)
  store { i64, ptr } %t103, ptr %l40
  br label %bb18
bb18:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l6, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %s6, ptr %t104, i32 %t105)
  store { i64, ptr } %t108, ptr %l43
  br label %bb19
bb19:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t110 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t111 = load i32, ptr %t110, !tbaa !23
  %t112 = extractvalue { i64, ptr } { i64 5, ptr @.d58 }, 1
  %t113 = extractvalue { i64, ptr } { i64 5, ptr @.d58 }, 0
  %t114 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = add i64 %t120, %t123
  %t125 = extractvalue { i64, ptr } { i64 2, ptr @.d60 }, 1
  %t126 = extractvalue { i64, ptr } { i64 2, ptr @.d60 }, 0
  %t127 = add i64 %t124, %t126
  %t129 = call i64 @__olang_fmt_i64(ptr null, i64 %t109)
  %t130 = add i64 %t127, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr @.d61 }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr @.d61 }, 0
  %t133 = add i64 %t130, %t132
  %t135 = sext i32 %t111 to i64
  %t136 = call i64 @__olang_fmt_i64(ptr null, i64 %t135)
  %t137 = add i64 %t133, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t112, i64 %t113)
  %t139 = getelementptr i8, ptr %t138, i64 %t113
  call void @olang_textcopy(ptr %t139, ptr %t115, i64 %t116)
  %t140 = getelementptr i8, ptr %t139, i64 %t116
  call void @olang_textcopy(ptr %t140, ptr %t118, i64 %t119)
  %t141 = getelementptr i8, ptr %t140, i64 %t119
  call void @olang_textcopy(ptr %t141, ptr %t122, i64 %t123)
  %t142 = getelementptr i8, ptr %t141, i64 %t123
  call void @olang_textcopy(ptr %t142, ptr %t125, i64 %t126)
  %t143 = getelementptr i8, ptr %t142, i64 %t126
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t109)
  %t145 = getelementptr i8, ptr %t143, i64 %t129
  call void @olang_textcopy(ptr %t145, ptr %t131, i64 %t132)
  %t146 = getelementptr i8, ptr %t145, i64 %t132
  %t147 = call i64 @__olang_fmt_i64(ptr %t146, i64 %t135)
  %t148 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t138, 1
  store { i64, ptr } %t149, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4b3ff56260a2bca0_3dcb0434d488ed4c)
  unreachable
bb21:
  %t151 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  store i64 %t152, ptr %l47, !tbaa !24
  %t153 = load i64, ptr %l47, !tbaa !24
  %t154 = mul i64 %t153, 1
  %t155 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t154)
  %t156 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  store { i64, ptr } %t157, ptr %l48, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = load i64, ptr %l47, !tbaa !24
  %t163 = mul i64 %t162, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t159, ptr %t161, i64 %t163, i1 false)
  %t164 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t164, ptr %l9, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t165, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l40 = alloca { i64, ptr }
  %l47 = alloca i32
  %l50 = alloca i32
  %l76 = alloca { i64, [1 x i64] }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l3
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 1, ptr @.d62 })
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb6:
  %t12 = load { i64, [2 x i64] }, ptr %l3
  %t14 = extractvalue { i64, [2 x i64] } %t12, 0
  %t15 = icmp eq i64 %t14, 1
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t17 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l4, !tbaa !23
  br label %bb9
bb8:
  br label %bb11
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i32, ptr %l4, !tbaa !23
  %t22 = extractvalue { i64, ptr } { i64 1, ptr @.d63 }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d63 }, 0
  %t25 = sext i32 %t21 to i64
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t22, i64 %t23)
  %t29 = getelementptr i8, ptr %t28, i64 %t23
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %t25)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t28, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t39)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb11:
  %t42 = load { i64, [2 x i64] }, ptr %l3
  %t44 = extractvalue { i64, [2 x i64] } %t42, 0
  %t45 = icmp eq i64 %t44, 2
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t47 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t48 = getelementptr { i64, i32, i32 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  store i64 %t49, ptr %l5, !tbaa !24
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t52 = getelementptr { i64, i32, i32 }, ptr %t51, i32 0, i32 1
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb17
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l34, !tbaa !29
  %t55 = load i64, ptr %l5, !tbaa !24
  store i64 %t55, ptr %l35, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/mir:dumper", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/types:Table", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i32, ptr %l6, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t62, i32 %t63)
  store { i64, ptr } %t66, ptr %l40
  br label %bb15
bb15:
  %t67 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 1
  %t68 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 0
  %t69 = load i64, ptr %l35, !tbaa !24
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t71 = add i64 %t68, %t70
  %t72 = extractvalue { i64, ptr } { i64 1, ptr @.d65 }, 1
  %t73 = extractvalue { i64, ptr } { i64 1, ptr @.d65 }, 0
  %t74 = add i64 %t71, %t73
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t67, i64 %t68)
  %t80 = getelementptr i8, ptr %t79, i64 %t68
  %t81 = call i64 @__olang_fmt_i64(ptr %t80, i64 %t69)
  %t82 = getelementptr i8, ptr %t80, i64 %t70
  call void @olang_textcopy(ptr %t82, ptr %t72, i64 %t73)
  %t83 = getelementptr i8, ptr %t82, i64 %t73
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t79, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = load ptr, ptr %l34, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t93, { i64, ptr } %t92)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2f605f8b851f9dfa_b0e742a1ba211956)
  unreachable
bb18:
  store i32 0, ptr %l7, !tbaa !23
  %t95 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t96 = getelementptr %"compiler/mir:Range", ptr %t95, i32 0, i32 1
  %t97 = load i32, ptr %t96, !tbaa !23
  store i32 %t97, ptr %l8, !tbaa !23
  store i32 1, ptr %l9, !tbaa !23
  %t99 = load i32, ptr %l8, !tbaa !23
  %t100 = load i32, ptr %l7, !tbaa !23
  %t103 = icmp sgt i32 %t99, %t100
  br i1 %t103, label %bb19, label %bb20
bb19:
  %t105 = load i32, ptr %l9, !tbaa !23
  %t107 = icmp sgt i32 %t105, 0
  br i1 %t107, label %bb21, label %bb22
bb20:
  store i32 0, ptr %l47, !tbaa !23
  br label %bb24
bb21:
  %t109 = load i32, ptr %l8, !tbaa !23
  %t110 = load i32, ptr %l7, !tbaa !23
  %t113 = sub i32 %t109, %t110
  %t114 = load i32, ptr %l9, !tbaa !23
  %t117 = add i32 %t113, %t114
  %t119 = sub i32 %t117, 1
  %t120 = load i32, ptr %l9, !tbaa !23
  %t123 = sdiv i32 %t119, %t120
  store i32 %t123, ptr %l50, !tbaa !23
  br label %bb23
bb22:
  store i32 0, ptr %l50, !tbaa !23
  br label %bb23
bb23:
  %t125 = load i32, ptr %l50, !tbaa !23
  store i32 %t125, ptr %l47, !tbaa !23
  br label %bb24
bb24:
  %t126 = load i32, ptr %l47, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  store i32 0, ptr %l11, !tbaa !23
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t127 = load i32, ptr %l11, !tbaa !23
  %t128 = load i32, ptr %l10, !tbaa !23
  %t131 = icmp slt i32 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb57
bb27:
  br label %bb28
bb28:
  %t135 = load i32, ptr %l7, !tbaa !23
  %t136 = load i32, ptr %l11, !tbaa !23
  %t137 = load i32, ptr %l9, !tbaa !23
  %t140 = mul i32 %t136, %t137
  %t143 = add i32 %t135, %t140
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/mir:dumper", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/mir:Fn", ptr %t148, i32 0, i32 10
  %t151 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t152 = getelementptr %"compiler/mir:Range", ptr %t151, i32 0, i32 0
  %t153 = load i32, ptr %t152, !tbaa !23
  %t155 = sext i32 %t153 to i64
  %t158 = sext i32 %t143 to i64
  %t161 = add i64 %t155, %t158
  %t164 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t150, i64 %t161)
  store { i64, [1 x i64] } %t164, ptr %l76
  br label %bb29
bb29:
  %t165 = load { i64, [1 x i64] }, ptr %l76
  store { i64, [1 x i64] } %t165, ptr %l13
  %t166 = load { i64, [1 x i64] }, ptr %l13
  %t168 = extractvalue { i64, [1 x i64] } %t166, 0
  %t169 = icmp eq i64 %t168, 0
  br i1 %t169, label %bb30, label %bb31
bb30:
  %t171 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t172 = getelementptr { i64 }, ptr %t171, i32 0, i32 0
  %t173 = load i64, ptr %t172
  store i64 %t173, ptr %l14, !tbaa !24
  br label %bb32
bb31:
  br label %bb34
bb32:
  store %olang.scope zeroinitializer, ptr %s8
  %t175 = load i64, ptr %l14, !tbaa !24
  %t176 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 1
  %t177 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 0
  %t179 = call i64 @__olang_fmt_i64(ptr null, i64 %t175)
  %t180 = add i64 %t177, %t179
  %t181 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t176, i64 %t177)
  %t182 = getelementptr i8, ptr %t181, i64 %t177
  %t183 = call i64 @__olang_fmt_i64(ptr %t182, i64 %t175)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t181, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = extractvalue { i64, ptr } %t185, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l2, { i64, ptr } %t192)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb34:
  %t195 = load { i64, [1 x i64] }, ptr %l13
  %t197 = extractvalue { i64, [1 x i64] } %t195, 0
  %t198 = icmp eq i64 %t197, 1
  br i1 %t198, label %bb35, label %bb36
bb35:
  %t200 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t201 = getelementptr { i32 }, ptr %t200, i32 0, i32 0
  %t202 = load i32, ptr %t201
  store i32 %t202, ptr %l15, !tbaa !23
  br label %bb37
bb36:
  br label %bb39
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t204 = load i32, ptr %l15, !tbaa !23
  %t205 = extractvalue { i64, ptr } { i64 2, ptr @.d67 }, 1
  %t206 = extractvalue { i64, ptr } { i64 2, ptr @.d67 }, 0
  %t208 = sext i32 %t204 to i64
  %t209 = call i64 @__olang_fmt_i64(ptr null, i64 %t208)
  %t210 = add i64 %t206, %t209
  %t211 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 0
  %t213 = add i64 %t210, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t205, i64 %t206)
  %t215 = getelementptr i8, ptr %t214, i64 %t206
  %t216 = call i64 @__olang_fmt_i64(ptr %t215, i64 %t208)
  %t217 = getelementptr i8, ptr %t215, i64 %t209
  call void @olang_textcopy(ptr %t217, ptr %t211, i64 %t212)
  %t218 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t214, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = extractvalue { i64, ptr } %t219, 1
  %t223 = mul i64 %t221, 1
  %t224 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t223)
  call void @llvm.memcpy.p0.p0.i64(ptr %t224, ptr %t222, i64 %t223, i1 false)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %l2, { i64, ptr } %t226)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb39:
  %t229 = load { i64, [1 x i64] }, ptr %l13
  %t231 = extractvalue { i64, [1 x i64] } %t229, 0
  %t232 = icmp eq i64 %t231, 2
  br i1 %t232, label %bb40, label %bb41
bb40:
  %t234 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t235 = getelementptr { i64 }, ptr %t234, i32 0, i32 0
  %t236 = load i64, ptr %t235
  store i64 %t236, ptr %l16, !tbaa !24
  br label %bb42
bb41:
  br label %bb44
bb42:
  store %olang.scope zeroinitializer, ptr %s12
  %t238 = load i64, ptr %l16, !tbaa !24
  %t239 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 1
  %t240 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 0
  %t242 = call i64 @__olang_fmt_i64(ptr null, i64 %t238)
  %t243 = add i64 %t240, %t242
  %t244 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 1
  %t245 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 0
  %t246 = add i64 %t243, %t245
  %t247 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t246)
  call void @olang_textcopy(ptr %t247, ptr %t239, i64 %t240)
  %t248 = getelementptr i8, ptr %t247, i64 %t240
  %t249 = call i64 @__olang_fmt_i64(ptr %t248, i64 %t238)
  %t250 = getelementptr i8, ptr %t248, i64 %t242
  call void @olang_textcopy(ptr %t250, ptr %t244, i64 %t245)
  %t251 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t247, 1
  %t254 = extractvalue { i64, ptr } %t252, 0
  %t255 = extractvalue { i64, ptr } %t252, 1
  %t256 = mul i64 %t254, 1
  %t257 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t256)
  call void @llvm.memcpy.p0.p0.i64(ptr %t257, ptr %t255, i64 %t256, i1 false)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } %t259)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s12)
  br label %bb55
bb44:
  %t262 = load { i64, [1 x i64] }, ptr %l13
  %t264 = extractvalue { i64, [1 x i64] } %t262, 0
  %t265 = icmp eq i64 %t264, 3
  br i1 %t265, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb49
bb47:
  store %olang.scope zeroinitializer, ptr %s14
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l2, { i64, ptr } { i64 2, ptr @.d71 })
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s14)
  br label %bb55
bb49:
  %t268 = load { i64, [1 x i64] }, ptr %l13
  %t270 = extractvalue { i64, [1 x i64] } %t268, 0
  %t271 = icmp eq i64 %t270, 4
  br i1 %t271, label %bb50, label %bb51
bb50:
  %t273 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t274 = getelementptr { i64 }, ptr %t273, i32 0, i32 0
  %t275 = load i64, ptr %t274
  store i64 %t275, ptr %l17, !tbaa !24
  br label %bb52
bb51:
  br label %bb54
bb52:
  store %olang.scope zeroinitializer, ptr %s15
  %t277 = load i64, ptr %l17, !tbaa !24
  %t278 = extractvalue { i64, ptr } { i64 4, ptr @.d72 }, 1
  %t279 = extractvalue { i64, ptr } { i64 4, ptr @.d72 }, 0
  %t281 = call i64 @__olang_fmt_i64(ptr null, i64 %t277)
  %t282 = add i64 %t279, %t281
  %t283 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t278, i64 %t279)
  %t284 = getelementptr i8, ptr %t283, i64 %t279
  %t285 = call i64 @__olang_fmt_i64(ptr %t284, i64 %t277)
  %t286 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t283, 1
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t290 = extractvalue { i64, ptr } %t287, 1
  %t291 = mul i64 %t289, 1
  %t292 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t291)
  call void @llvm.memcpy.p0.p0.i64(ptr %t292, ptr %t290, i64 %t291, i1 false)
  %t293 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l2, { i64, ptr } %t294)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s15)
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_ddfec86899b5c27b_91be796056af7d77)
  unreachable
bb55:
  call void @__olang_scope_close(ptr %s7)
  br label %bb56
bb56:
  %t297 = load i32, ptr %l11, !tbaa !23
  %t299 = add i32 %t297, 1
  store i32 %t299, ptr %l11, !tbaa !23
  br label %bb25
bb57:
  %t302 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t302, ptr %l111
  br label %bb58
bb58:
  %t303 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t303, ptr %l112, !tbaa !27
  %t304 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 0
  store i64 %t305, ptr %l113, !tbaa !24
  %t306 = load i64, ptr %l113, !tbaa !24
  %t307 = mul i64 %t306, 1
  %t308 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l114, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = load i64, ptr %l113, !tbaa !24
  %t316 = mul i64 %t315, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t312, ptr %t314, i64 %t316, i1 false)
  %t317 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t317, ptr %l112, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t318 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t318, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d73 }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr @.d73 }, 0
  %t14 = sext i32 %t10 to i64
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t14)
  %t16 = add i64 %t12, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = getelementptr i8, ptr %t17, i64 %t12
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  br label %bb21
bb4:
  %t23 = load { i64, [1 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [1 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 1
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 1
  %t34 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 0
  %t36 = call i64 @__olang_fmt_i64(ptr null, i64 %t32)
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = getelementptr i8, ptr %t38, i64 %t34
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t32)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t38, 1
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  br label %bb21
bb8:
  %t44 = load { i64, [1 x i64] }, ptr %l1
  %t46 = extractvalue { i64, [1 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 2
  br i1 %t47, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 7, ptr @.d75 }, ptr %l18, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t49, ptr %l5, !tbaa !27
  br label %bb21
bb12:
  %t51 = load { i64, [1 x i64] }, ptr %l1
  %t53 = extractvalue { i64, [1 x i64] } %t51, 0
  %t54 = icmp eq i64 %t53, 3
  br i1 %t54, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 5, ptr @.d76 }, ptr %l22, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t56, ptr %l5, !tbaa !27
  br label %bb21
bb16:
  %t58 = load { i64, [1 x i64] }, ptr %l1
  %t60 = extractvalue { i64, [1 x i64] } %t58, 0
  %t61 = icmp eq i64 %t60, 4
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t63 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { i32 }, ptr %t63, i32 0, i32 0
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l4, !tbaa !23
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t67 = load i32, ptr %l4, !tbaa !23
  %t68 = extractvalue { i64, ptr } { i64 8, ptr @.d77 }, 1
  %t69 = extractvalue { i64, ptr } { i64 8, ptr @.d77 }, 0
  %t71 = sext i32 %t67 to i64
  %t72 = call i64 @__olang_fmt_i64(ptr null, i64 %t71)
  %t73 = add i64 %t69, %t72
  %t74 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 0
  %t76 = add i64 %t73, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = getelementptr i8, ptr %t77, i64 %t69
  %t79 = call i64 @__olang_fmt_i64(ptr %t78, i64 %t71)
  %t80 = getelementptr i8, ptr %t78, i64 %t72
  call void @olang_textcopy(ptr %t80, ptr %t74, i64 %t75)
  %t81 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t77, 1
  store { i64, ptr } %t82, ptr %l5, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_3c759898227385e0_43502750c3b6307c)
  unreachable
bb21:
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l29, !tbaa !24
  %t86 = load i64, ptr %l29, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l30, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l29, !tbaa !24
  %t96 = mul i64 %t95, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t92, ptr %t94, i64 %t96, i1 false)
  %t97 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t97, ptr %l5, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ervalue(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca %"compiler/mir:Place"
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Place"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Range"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Range"
  %l13 = alloca %"compiler/mir:Place"
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca %"compiler/mir:Range"
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca i32
  %l20 = alloca { i64, [1 x i64] }
  %l21 = alloca i32
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca %"compiler/mir:Place"
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca { i64, [1 x i64] }
  %l29 = alloca i32
  %l30 = alloca { i64, [1 x i64] }
  %l31 = alloca %"compiler/mir:Range"
  %l32 = alloca %"compiler/mir:Range"
  %l33 = alloca { i64, [4 x i64] }
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca { i64, [1 x i64] }
  %l37 = alloca { i64, [1 x i64] }
  %l38 = alloca i32
  %l41 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l71 = alloca i32
  %l73 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l88 = alloca i32
  %l90 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [15 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [15 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { { i64, [4 x i64] } }, ptr %t11, i32 0, i32 0
  %t13 = load { i64, [4 x i64] }, ptr %t12
  store { i64, [4 x i64] } %t13, ptr %l3
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [4 x i64] }, ptr %l3
  %t19 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %v1, ptr %t15, { i64, [4 x i64] } %t16)
  store { i64, ptr } %t19, ptr %l47
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t20, ptr %l41, !tbaa !27
  br label %bb96
bb5:
  %t21 = load { i64, [15 x i64] }, ptr %l1
  %t23 = extractvalue { i64, [15 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t27 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t26, i32 0, i32 0
  %t28 = load %"compiler/mir:Place", ptr %t27
  store %"compiler/mir:Place" %t28, ptr %l4
  %t30 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t31 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t30, i32 0, i32 1
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb11
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/mir:Place", ptr %l4
  %t38 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s2, ptr %t34, %"compiler/mir:Place" %t35)
  store { i64, ptr } %t38, ptr %l54
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t40 = load i32, ptr %l5, !tbaa !23
  %t43 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t39, i32 %t40)
  store { i64, ptr } %t43, ptr %l57
  br label %bb10
bb10:
  %t44 = extractvalue { i64, ptr } { i64 4, ptr @.d79 }, 1
  %t45 = extractvalue { i64, ptr } { i64 4, ptr @.d79 }, 0
  %t46 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 2, ptr @.d80 }, 1
  %t51 = extractvalue { i64, ptr } { i64 2, ptr @.d80 }, 0
  %t52 = add i64 %t49, %t51
  %t53 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = add i64 %t52, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t44, i64 %t45)
  %t58 = getelementptr i8, ptr %t57, i64 %t45
  call void @olang_textcopy(ptr %t58, ptr %t47, i64 %t48)
  %t59 = getelementptr i8, ptr %t58, i64 %t48
  call void @olang_textcopy(ptr %t59, ptr %t50, i64 %t51)
  %t60 = getelementptr i8, ptr %t59, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t54, i64 %t55)
  %t61 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t57, 1
  store { i64, ptr } %t62, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb11:
  %t64 = load { i64, [15 x i64] }, ptr %l1
  %t66 = extractvalue { i64, [15 x i64] } %t64, 0
  %t67 = icmp eq i64 %t66, 2
  br i1 %t67, label %bb12, label %bb13
bb12:
  %t69 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t70 = getelementptr { %"compiler/mir:Place" }, ptr %t69, i32 0, i32 0
  %t71 = load %"compiler/mir:Place", ptr %t70
  store %"compiler/mir:Place" %t71, ptr %l6
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/mir:Place", ptr %l6
  %t77 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s4, ptr %t73, %"compiler/mir:Place" %t74)
  store { i64, ptr } %t77, ptr %l64
  br label %bb15
bb15:
  %t78 = extractvalue { i64, ptr } { i64 5, ptr @.d81 }, 1
  %t79 = extractvalue { i64, ptr } { i64 5, ptr @.d81 }, 0
  %t80 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = add i64 %t79, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t78, i64 %t79)
  %t85 = getelementptr i8, ptr %t84, i64 %t79
  call void @olang_textcopy(ptr %t85, ptr %t81, i64 %t82)
  %t86 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t84, 1
  store { i64, ptr } %t87, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb96
bb16:
  %t89 = load { i64, [15 x i64] }, ptr %l1
  %t91 = extractvalue { i64, [15 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 3
  br i1 %t92, label %bb17, label %bb18
bb17:
  %t94 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t95 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t94, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l7
  %t98 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t99 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t98, i32 0, i32 1
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l8, !tbaa !23
  %t102 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t103 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t102, i32 0, i32 2
  %t104 = load %"compiler/mir:Range", ptr %t103
  store %"compiler/mir:Range" %t104, ptr %l9
  br label %bb19
bb18:
  br label %bb24
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t106 = load i32, ptr %l7
  store i32 %t106, ptr %l71
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s7, ptr %l71, i64 0)
  br label %bb20
bb20:
  %t108 = load ptr, ptr %s7
  %t109 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t110 = load i64, ptr %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t108, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l73, !tbaa !27
  %t114 = getelementptr %olang.builder, ptr %s7, i32 0, i32 3
  %t115 = load ptr, ptr %t114
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %sbgrew.117, label %sbdone.118
sbgrew.117:
  call void @__olang_sb_done(ptr %s7)
  br label %sbdone.118
sbdone.118:
  %t119 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t127 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s6, { i64, ptr } %t125)
  store { i64, ptr } %t127, ptr %l75
  br label %bb21
bb21:
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t129 = load i32, ptr %l8, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s6, ptr %t128, i32 %t129)
  store { i64, ptr } %t132, ptr %l78
  br label %bb22
bb22:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load %"compiler/mir:Range", ptr %l9
  %t137 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s6, ptr %t133, %"compiler/mir:Range" %t134)
  store { i64, ptr } %t137, ptr %l81
  br label %bb23
bb23:
  %t138 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 1
  %t142 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 0
  %t143 = add i64 %t140, %t142
  %t144 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = extractvalue { i64, ptr } { i64 1, ptr @.d83 }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr @.d83 }, 0
  %t150 = add i64 %t147, %t149
  %t151 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 1, ptr @.d84 }, 1
  %t156 = extractvalue { i64, ptr } { i64 1, ptr @.d84 }, 0
  %t157 = add i64 %t154, %t156
  %t158 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t157)
  call void @olang_textcopy(ptr %t158, ptr %t139, i64 %t140)
  %t159 = getelementptr i8, ptr %t158, i64 %t140
  call void @olang_textcopy(ptr %t159, ptr %t141, i64 %t142)
  %t160 = getelementptr i8, ptr %t159, i64 %t142
  call void @olang_textcopy(ptr %t160, ptr %t145, i64 %t146)
  %t161 = getelementptr i8, ptr %t160, i64 %t146
  call void @olang_textcopy(ptr %t161, ptr %t148, i64 %t149)
  %t162 = getelementptr i8, ptr %t161, i64 %t149
  call void @olang_textcopy(ptr %t162, ptr %t152, i64 %t153)
  %t163 = getelementptr i8, ptr %t162, i64 %t153
  call void @olang_textcopy(ptr %t163, ptr %t155, i64 %t156)
  %t164 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t158, 1
  store { i64, ptr } %t165, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb96
bb24:
  %t167 = load { i64, [15 x i64] }, ptr %l1
  %t169 = extractvalue { i64, [15 x i64] } %t167, 0
  %t170 = icmp eq i64 %t169, 4
  br i1 %t170, label %bb25, label %bb26
bb25:
  %t172 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t173 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t172, i32 0, i32 0
  %t174 = load i32, ptr %t173
  store i32 %t174, ptr %l10
  %t176 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t177 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t176, i32 0, i32 1
  %t178 = load i32, ptr %t177
  store i32 %t178, ptr %l11, !tbaa !23
  %t180 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t181 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t180, i32 0, i32 2
  %t182 = load %"compiler/mir:Range", ptr %t181
  store %"compiler/mir:Range" %t182, ptr %l12
  br label %bb27
bb26:
  br label %bb32
bb27:
  store %olang.scope zeroinitializer, ptr %s9
  %t184 = load i32, ptr %l10
  store i32 %t184, ptr %l88
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s10, ptr %l88, i64 0)
  br label %bb28
bb28:
  %t186 = load ptr, ptr %s10
  %t187 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t188 = load i64, ptr %t187
  %t189 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t188)
  call void @olang_textcopy(ptr %t189, ptr %t186, i64 %t188)
  %t190 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l90, !tbaa !27
  %t192 = getelementptr %olang.builder, ptr %s10, i32 0, i32 3
  %t193 = load ptr, ptr %t192
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %sbgrew.195, label %sbdone.196
sbgrew.195:
  call void @__olang_sb_done(ptr %s10)
  br label %sbdone.196
sbdone.196:
  %t197 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  %t199 = extractvalue { i64, ptr } %t197, 1
  %t200 = mul i64 %t198, 1
  %t201 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t200)
  call void @llvm.memcpy.p0.p0.i64(ptr %t201, ptr %t199, i64 %t200, i1 false)
  %t202 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  %t205 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s9, { i64, ptr } %t203)
  store { i64, ptr } %t205, ptr %l92
  br label %bb29
bb29:
  %t206 = load ptr, ptr %l2, !tbaa !29
  %t207 = load i32, ptr %l11, !tbaa !23
  %t210 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s9, ptr %t206, i32 %t207)
  store { i64, ptr } %t210, ptr %l95
  br label %bb30
bb30:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load %"compiler/mir:Range", ptr %l12
  %t215 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s9, ptr %t211, %"compiler/mir:Range" %t212)
  store { i64, ptr } %t215, ptr %l98
  br label %bb31
bb31:
  %t216 = extractvalue { i64, ptr } { i64 10, ptr @.d85 }, 1
  %t217 = extractvalue { i64, ptr } { i64 10, ptr @.d85 }, 0
  %t218 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 1, ptr @.d86 }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr @.d86 }, 0
  %t224 = add i64 %t221, %t223
  %t225 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 1, ptr @.d87 }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr @.d87 }, 0
  %t231 = add i64 %t228, %t230
  %t232 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 1
  %t237 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 0
  %t238 = add i64 %t235, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t216, i64 %t217)
  %t240 = getelementptr i8, ptr %t239, i64 %t217
  call void @olang_textcopy(ptr %t240, ptr %t219, i64 %t220)
  %t241 = getelementptr i8, ptr %t240, i64 %t220
  call void @olang_textcopy(ptr %t241, ptr %t222, i64 %t223)
  %t242 = getelementptr i8, ptr %t241, i64 %t223
  call void @olang_textcopy(ptr %t242, ptr %t226, i64 %t227)
  %t243 = getelementptr i8, ptr %t242, i64 %t227
  call void @olang_textcopy(ptr %t243, ptr %t229, i64 %t230)
  %t244 = getelementptr i8, ptr %t243, i64 %t230
  call void @olang_textcopy(ptr %t244, ptr %t233, i64 %t234)
  %t245 = getelementptr i8, ptr %t244, i64 %t234
  call void @olang_textcopy(ptr %t245, ptr %t236, i64 %t237)
  %t246 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t239, 1
  store { i64, ptr } %t247, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb96
bb32:
  %t249 = load { i64, [15 x i64] }, ptr %l1
  %t251 = extractvalue { i64, [15 x i64] } %t249, 0
  %t252 = icmp eq i64 %t251, 5
  br i1 %t252, label %bb33, label %bb34
bb33:
  %t254 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t255 = getelementptr { %"compiler/mir:Place" }, ptr %t254, i32 0, i32 0
  %t256 = load %"compiler/mir:Place", ptr %t255
  store %"compiler/mir:Place" %t256, ptr %l13
  br label %bb35
bb34:
  br label %bb37
bb35:
  store %olang.scope zeroinitializer, ptr %s12
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load %"compiler/mir:Place", ptr %l13
  %t262 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s12, ptr %t258, %"compiler/mir:Place" %t259)
  store { i64, ptr } %t262, ptr %l105
  br label %bb36
bb36:
  %t263 = extractvalue { i64, ptr } { i64 4, ptr @.d89 }, 1
  %t264 = extractvalue { i64, ptr } { i64 4, ptr @.d89 }, 0
  %t265 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = add i64 %t264, %t267
  %t269 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t268)
  call void @olang_textcopy(ptr %t269, ptr %t263, i64 %t264)
  %t270 = getelementptr i8, ptr %t269, i64 %t264
  call void @olang_textcopy(ptr %t270, ptr %t266, i64 %t267)
  %t271 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t269, 1
  store { i64, ptr } %t272, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb96
bb37:
  %t274 = load { i64, [15 x i64] }, ptr %l1
  %t276 = extractvalue { i64, [15 x i64] } %t274, 0
  %t277 = icmp eq i64 %t276, 6
  br i1 %t277, label %bb38, label %bb39
bb38:
  %t279 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t280 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t279, i32 0, i32 0
  %t281 = load i32, ptr %t280
  store i32 %t281, ptr %l14, !tbaa !23
  %t283 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t284 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t283, i32 0, i32 1
  %t285 = load i64, ptr %t284
  store i64 %t285, ptr %l15, !tbaa !24
  %t287 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t288 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t287, i32 0, i32 2
  %t289 = load %"compiler/mir:Range", ptr %t288
  store %"compiler/mir:Range" %t289, ptr %l16
  br label %bb40
bb39:
  br label %bb46
bb40:
  store %olang.scope zeroinitializer, ptr %s14
  %t291 = load ptr, ptr %l2, !tbaa !29
  %t292 = load i32, ptr %l14, !tbaa !23
  %t295 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s14, ptr %t291, i32 %t292)
  store { i64, ptr } %t295, ptr %l114
  br label %bb41
bb41:
  %t296 = load i64, ptr %l15, !tbaa !24
  %t298 = icmp sgt i64 %t296, 0
  br i1 %t298, label %bb42, label %bb43
bb42:
  %t300 = load i64, ptr %l15, !tbaa !24
  %t301 = extractvalue { i64, ptr } { i64 2, ptr @.d90 }, 1
  %t302 = extractvalue { i64, ptr } { i64 2, ptr @.d90 }, 0
  %t304 = call i64 @__olang_fmt_i64(ptr null, i64 %t300)
  %t305 = add i64 %t302, %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t301, i64 %t302)
  %t307 = getelementptr i8, ptr %t306, i64 %t302
  %t308 = call i64 @__olang_fmt_i64(ptr %t307, i64 %t300)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t306, 1
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = extractvalue { i64, ptr } %t310, 1
  %t314 = mul i64 %t312, 1
  %t315 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t314)
  call void @llvm.memcpy.p0.p0.i64(ptr %t315, ptr %t313, i64 %t314, i1 false)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t315, 1
  store { i64, ptr } %t317, ptr %l117, !tbaa !27
  br label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr @.d91 }, ptr %l117, !tbaa !27
  br label %bb44
bb44:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load %"compiler/mir:Range", ptr %l16
  %t323 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s14, ptr %t319, %"compiler/mir:Range" %t320)
  store { i64, ptr } %t323, ptr %l123
  br label %bb45
bb45:
  %t324 = extractvalue { i64, ptr } { i64 5, ptr @.d92 }, 1
  %t325 = extractvalue { i64, ptr } { i64 5, ptr @.d92 }, 0
  %t326 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = add i64 %t325, %t328
  %t330 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 1
  %t332 = extractvalue { i64, ptr } %t330, 0
  %t333 = add i64 %t329, %t332
  %t334 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 1
  %t335 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 0
  %t336 = add i64 %t333, %t335
  %t337 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t337, 1
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t340 = add i64 %t336, %t339
  %t341 = extractvalue { i64, ptr } { i64 1, ptr @.d94 }, 1
  %t342 = extractvalue { i64, ptr } { i64 1, ptr @.d94 }, 0
  %t343 = add i64 %t340, %t342
  %t344 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t343)
  call void @olang_textcopy(ptr %t344, ptr %t324, i64 %t325)
  %t345 = getelementptr i8, ptr %t344, i64 %t325
  call void @olang_textcopy(ptr %t345, ptr %t327, i64 %t328)
  %t346 = getelementptr i8, ptr %t345, i64 %t328
  call void @olang_textcopy(ptr %t346, ptr %t331, i64 %t332)
  %t347 = getelementptr i8, ptr %t346, i64 %t332
  call void @olang_textcopy(ptr %t347, ptr %t334, i64 %t335)
  %t348 = getelementptr i8, ptr %t347, i64 %t335
  call void @olang_textcopy(ptr %t348, ptr %t338, i64 %t339)
  %t349 = getelementptr i8, ptr %t348, i64 %t339
  call void @olang_textcopy(ptr %t349, ptr %t341, i64 %t342)
  %t350 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t344, 1
  store { i64, ptr } %t351, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb96
bb46:
  %t353 = load { i64, [15 x i64] }, ptr %l1
  %t355 = extractvalue { i64, [15 x i64] } %t353, 0
  %t356 = icmp eq i64 %t355, 7
  br i1 %t356, label %bb47, label %bb48
bb47:
  %t358 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t359 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t358, i32 0, i32 0
  %t360 = load { i64, [1 x i64] }, ptr %t359
  store { i64, [1 x i64] } %t360, ptr %l17
  %t362 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t363 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t362, i32 0, i32 1
  %t364 = load { i64, [4 x i64] }, ptr %t363
  store { i64, [4 x i64] } %t364, ptr %l18
  %t366 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t367 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t366, i32 0, i32 2
  %t368 = load i32, ptr %t367
  store i32 %t368, ptr %l19, !tbaa !23
  br label %bb49
bb48:
  br label %bb53
bb49:
  store %olang.scope zeroinitializer, ptr %s17
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load { i64, [1 x i64] }, ptr %l17
  %t374 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s17, ptr %t370, { i64, [1 x i64] } %t371)
  store { i64, ptr } %t374, ptr %l132
  br label %bb50
bb50:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load { i64, [4 x i64] }, ptr %l18
  %t379 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s17, ptr %t375, { i64, [4 x i64] } %t376)
  store { i64, ptr } %t379, ptr %l135
  br label %bb51
bb51:
  %t380 = load ptr, ptr %l2, !tbaa !29
  %t381 = load i32, ptr %l19, !tbaa !23
  %t384 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s17, ptr %t380, i32 %t381)
  store { i64, ptr } %t384, ptr %l138
  br label %bb52
bb52:
  %t385 = extractvalue { i64, ptr } { i64 7, ptr @.d95 }, 1
  %t386 = extractvalue { i64, ptr } { i64 7, ptr @.d95 }, 0
  %t387 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t387, 1
  %t389 = extractvalue { i64, ptr } %t387, 0
  %t390 = add i64 %t386, %t389
  %t391 = extractvalue { i64, ptr } { i64 1, ptr @.d96 }, 1
  %t392 = extractvalue { i64, ptr } { i64 1, ptr @.d96 }, 0
  %t393 = add i64 %t390, %t392
  %t394 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = add i64 %t393, %t396
  %t398 = extractvalue { i64, ptr } { i64 2, ptr @.d97 }, 1
  %t399 = extractvalue { i64, ptr } { i64 2, ptr @.d97 }, 0
  %t400 = add i64 %t397, %t399
  %t401 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t401, 1
  %t403 = extractvalue { i64, ptr } %t401, 0
  %t404 = add i64 %t400, %t403
  %t405 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t404)
  call void @olang_textcopy(ptr %t405, ptr %t385, i64 %t386)
  %t406 = getelementptr i8, ptr %t405, i64 %t386
  call void @olang_textcopy(ptr %t406, ptr %t388, i64 %t389)
  %t407 = getelementptr i8, ptr %t406, i64 %t389
  call void @olang_textcopy(ptr %t407, ptr %t391, i64 %t392)
  %t408 = getelementptr i8, ptr %t407, i64 %t392
  call void @olang_textcopy(ptr %t408, ptr %t395, i64 %t396)
  %t409 = getelementptr i8, ptr %t408, i64 %t396
  call void @olang_textcopy(ptr %t409, ptr %t398, i64 %t399)
  %t410 = getelementptr i8, ptr %t409, i64 %t399
  call void @olang_textcopy(ptr %t410, ptr %t402, i64 %t403)
  %t411 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t405, 1
  store { i64, ptr } %t412, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb96
bb53:
  %t414 = load { i64, [15 x i64] }, ptr %l1
  %t416 = extractvalue { i64, [15 x i64] } %t414, 0
  %t417 = icmp eq i64 %t416, 8
  br i1 %t417, label %bb54, label %bb55
bb54:
  %t419 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t420 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t419, i32 0, i32 0
  %t421 = load { i64, [1 x i64] }, ptr %t420
  store { i64, [1 x i64] } %t421, ptr %l20
  %t423 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t424 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t423, i32 0, i32 1
  %t425 = load i32, ptr %t424
  store i32 %t425, ptr %l21, !tbaa !23
  %t427 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t428 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t427, i32 0, i32 2
  %t429 = load { i64, [4 x i64] }, ptr %t428
  store { i64, [4 x i64] } %t429, ptr %l22
  %t431 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t432 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t431, i32 0, i32 3
  %t433 = load { i64, [4 x i64] }, ptr %t432
  store { i64, [4 x i64] } %t433, ptr %l23
  br label %bb56
bb55:
  br label %bb61
bb56:
  store %olang.scope zeroinitializer, ptr %s19
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load { i64, [1 x i64] }, ptr %l20
  %t439 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s19, ptr %t435, { i64, [1 x i64] } %t436)
  store { i64, ptr } %t439, ptr %l148
  br label %bb57
bb57:
  %t440 = load ptr, ptr %l2, !tbaa !29
  %t441 = load i32, ptr %l21, !tbaa !23
  %t444 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s19, ptr %t440, i32 %t441)
  store { i64, ptr } %t444, ptr %l151
  br label %bb58
bb58:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load { i64, [4 x i64] }, ptr %l22
  %t449 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s19, ptr %t445, { i64, [4 x i64] } %t446)
  store { i64, ptr } %t449, ptr %l154
  br label %bb59
bb59:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load { i64, [4 x i64] }, ptr %l23
  %t454 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s19, ptr %t450, { i64, [4 x i64] } %t451)
  store { i64, ptr } %t454, ptr %l157
  br label %bb60
bb60:
  %t455 = extractvalue { i64, ptr } { i64 12, ptr @.d98 }, 1
  %t456 = extractvalue { i64, ptr } { i64 12, ptr @.d98 }, 0
  %t457 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t457, 1
  %t459 = extractvalue { i64, ptr } %t457, 0
  %t460 = add i64 %t456, %t459
  %t461 = extractvalue { i64, ptr } { i64 1, ptr @.d99 }, 1
  %t462 = extractvalue { i64, ptr } { i64 1, ptr @.d99 }, 0
  %t463 = add i64 %t460, %t462
  %t464 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 1
  %t466 = extractvalue { i64, ptr } %t464, 0
  %t467 = add i64 %t463, %t466
  %t468 = extractvalue { i64, ptr } { i64 1, ptr @.d100 }, 1
  %t469 = extractvalue { i64, ptr } { i64 1, ptr @.d100 }, 0
  %t470 = add i64 %t467, %t469
  %t471 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t471, 1
  %t473 = extractvalue { i64, ptr } %t471, 0
  %t474 = add i64 %t470, %t473
  %t475 = extractvalue { i64, ptr } { i64 2, ptr @.d101 }, 1
  %t476 = extractvalue { i64, ptr } { i64 2, ptr @.d101 }, 0
  %t477 = add i64 %t474, %t476
  %t478 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t478, 1
  %t480 = extractvalue { i64, ptr } %t478, 0
  %t481 = add i64 %t477, %t480
  %t482 = extractvalue { i64, ptr } { i64 1, ptr @.d102 }, 1
  %t483 = extractvalue { i64, ptr } { i64 1, ptr @.d102 }, 0
  %t484 = add i64 %t481, %t483
  %t485 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t484)
  call void @olang_textcopy(ptr %t485, ptr %t455, i64 %t456)
  %t486 = getelementptr i8, ptr %t485, i64 %t456
  call void @olang_textcopy(ptr %t486, ptr %t458, i64 %t459)
  %t487 = getelementptr i8, ptr %t486, i64 %t459
  call void @olang_textcopy(ptr %t487, ptr %t461, i64 %t462)
  %t488 = getelementptr i8, ptr %t487, i64 %t462
  call void @olang_textcopy(ptr %t488, ptr %t465, i64 %t466)
  %t489 = getelementptr i8, ptr %t488, i64 %t466
  call void @olang_textcopy(ptr %t489, ptr %t468, i64 %t469)
  %t490 = getelementptr i8, ptr %t489, i64 %t469
  call void @olang_textcopy(ptr %t490, ptr %t472, i64 %t473)
  %t491 = getelementptr i8, ptr %t490, i64 %t473
  call void @olang_textcopy(ptr %t491, ptr %t475, i64 %t476)
  %t492 = getelementptr i8, ptr %t491, i64 %t476
  call void @olang_textcopy(ptr %t492, ptr %t479, i64 %t480)
  %t493 = getelementptr i8, ptr %t492, i64 %t480
  call void @olang_textcopy(ptr %t493, ptr %t482, i64 %t483)
  %t494 = insertvalue { i64, ptr } undef, i64 %t484, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t485, 1
  store { i64, ptr } %t495, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb96
bb61:
  %t497 = load { i64, [15 x i64] }, ptr %l1
  %t499 = extractvalue { i64, [15 x i64] } %t497, 0
  %t500 = icmp eq i64 %t499, 9
  br i1 %t500, label %bb62, label %bb63
bb62:
  %t502 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t503 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t502, i32 0, i32 0
  %t504 = load %"compiler/mir:Place", ptr %t503
  store %"compiler/mir:Place" %t504, ptr %l24
  %t506 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t507 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t506, i32 0, i32 1
  %t508 = load { i64, [4 x i64] }, ptr %t507
  store { i64, [4 x i64] } %t508, ptr %l25
  %t510 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t511 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t510, i32 0, i32 2
  %t512 = load { i64, [4 x i64] }, ptr %t511
  store { i64, [4 x i64] } %t512, ptr %l26
  %t514 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t515 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t514, i32 0, i32 3
  %t516 = load i32, ptr %t515
  store i32 %t516, ptr %l27, !tbaa !23
  br label %bb64
bb63:
  br label %bb69
bb64:
  store %olang.scope zeroinitializer, ptr %s21
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load %"compiler/mir:Place", ptr %l24
  %t522 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s21, ptr %t518, %"compiler/mir:Place" %t519)
  store { i64, ptr } %t522, ptr %l167
  br label %bb65
bb65:
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t524 = load { i64, [4 x i64] }, ptr %l25
  %t527 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s21, ptr %t523, { i64, [4 x i64] } %t524)
  store { i64, ptr } %t527, ptr %l170
  br label %bb66
bb66:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load { i64, [4 x i64] }, ptr %l26
  %t532 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s21, ptr %t528, { i64, [4 x i64] } %t529)
  store { i64, ptr } %t532, ptr %l173
  br label %bb67
bb67:
  %t533 = load ptr, ptr %l2, !tbaa !29
  %t534 = load i32, ptr %l27, !tbaa !23
  %t537 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s21, ptr %t533, i32 %t534)
  store { i64, ptr } %t537, ptr %l176
  br label %bb68
bb68:
  %t538 = extractvalue { i64, ptr } { i64 6, ptr @.d103 }, 1
  %t539 = extractvalue { i64, ptr } { i64 6, ptr @.d103 }, 0
  %t540 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t540, 1
  %t542 = extractvalue { i64, ptr } %t540, 0
  %t543 = add i64 %t539, %t542
  %t544 = extractvalue { i64, ptr } { i64 1, ptr @.d104 }, 1
  %t545 = extractvalue { i64, ptr } { i64 1, ptr @.d104 }, 0
  %t546 = add i64 %t543, %t545
  %t547 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t547, 1
  %t549 = extractvalue { i64, ptr } %t547, 0
  %t550 = add i64 %t546, %t549
  %t551 = extractvalue { i64, ptr } { i64 3, ptr @.d105 }, 1
  %t552 = extractvalue { i64, ptr } { i64 3, ptr @.d105 }, 0
  %t553 = add i64 %t550, %t552
  %t554 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t554, 1
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t557 = add i64 %t553, %t556
  %t558 = extractvalue { i64, ptr } { i64 3, ptr @.d106 }, 1
  %t559 = extractvalue { i64, ptr } { i64 3, ptr @.d106 }, 0
  %t560 = add i64 %t557, %t559
  %t561 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t562 = extractvalue { i64, ptr } %t561, 1
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t564 = add i64 %t560, %t563
  %t565 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t564)
  call void @olang_textcopy(ptr %t565, ptr %t538, i64 %t539)
  %t566 = getelementptr i8, ptr %t565, i64 %t539
  call void @olang_textcopy(ptr %t566, ptr %t541, i64 %t542)
  %t567 = getelementptr i8, ptr %t566, i64 %t542
  call void @olang_textcopy(ptr %t567, ptr %t544, i64 %t545)
  %t568 = getelementptr i8, ptr %t567, i64 %t545
  call void @olang_textcopy(ptr %t568, ptr %t548, i64 %t549)
  %t569 = getelementptr i8, ptr %t568, i64 %t549
  call void @olang_textcopy(ptr %t569, ptr %t551, i64 %t552)
  %t570 = getelementptr i8, ptr %t569, i64 %t552
  call void @olang_textcopy(ptr %t570, ptr %t555, i64 %t556)
  %t571 = getelementptr i8, ptr %t570, i64 %t556
  call void @olang_textcopy(ptr %t571, ptr %t558, i64 %t559)
  %t572 = getelementptr i8, ptr %t571, i64 %t559
  call void @olang_textcopy(ptr %t572, ptr %t562, i64 %t563)
  %t573 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t565, 1
  store { i64, ptr } %t574, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s21)
  br label %bb96
bb69:
  %t576 = load { i64, [15 x i64] }, ptr %l1
  %t578 = extractvalue { i64, [15 x i64] } %t576, 0
  %t579 = icmp eq i64 %t578, 10
  br i1 %t579, label %bb70, label %bb71
bb70:
  %t581 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t582 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t581, i32 0, i32 0
  %t583 = load { i64, [1 x i64] }, ptr %t582
  store { i64, [1 x i64] } %t583, ptr %l28
  %t585 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t586 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t585, i32 0, i32 1
  %t587 = load i32, ptr %t586
  store i32 %t587, ptr %l29, !tbaa !23
  %t589 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t590 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t589, i32 0, i32 2
  %t591 = load { i64, [1 x i64] }, ptr %t590
  store { i64, [1 x i64] } %t591, ptr %l30
  %t593 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t594 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t593, i32 0, i32 3
  %t595 = load %"compiler/mir:Range", ptr %t594
  store %"compiler/mir:Range" %t595, ptr %l31
  %t597 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t598 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t597, i32 0, i32 4
  %t599 = load %"compiler/mir:Range", ptr %t598
  store %"compiler/mir:Range" %t599, ptr %l32
  br label %bb72
bb71:
  br label %bb81
bb72:
  store %olang.scope zeroinitializer, ptr %s23
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t602 = load { i64, [1 x i64] }, ptr %l28
  %t605 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %s23, ptr %t601, { i64, [1 x i64] } %t602)
  store { i64, ptr } %t605, ptr %l187
  br label %bb73
bb73:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load { i64, [1 x i64] }, ptr %l30
  %t610 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s23, ptr %t606, { i64, [1 x i64] } %t607)
  store { i64, ptr } %t610, ptr %l190
  br label %bb74
bb74:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load %"compiler/mir:Range", ptr %l31
  %t615 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s23, ptr %t611, %"compiler/mir:Range" %t612)
  store { i64, ptr } %t615, ptr %l193
  br label %bb75
bb75:
  %t616 = getelementptr %"compiler/mir:Range", ptr %l32, i32 0, i32 1
  %t617 = load i32, ptr %t616, !tbaa !23
  %t619 = icmp sgt i32 %t617, 0
  br i1 %t619, label %bb76, label %bb77
bb76:
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load %"compiler/mir:Range", ptr %l32
  %t625 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s23, ptr %t621, %"compiler/mir:Range" %t622)
  store { i64, ptr } %t625, ptr %l199
  br label %bb78
bb77:
  store { i64, ptr } { i64 0, ptr @.d107 }, ptr %l196, !tbaa !27
  br label %bb79
bb78:
  %t626 = extractvalue { i64, ptr } { i64 10, ptr @.d108 }, 1
  %t627 = extractvalue { i64, ptr } { i64 10, ptr @.d108 }, 0
  %t628 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t629 = extractvalue { i64, ptr } %t628, 1
  %t630 = extractvalue { i64, ptr } %t628, 0
  %t631 = add i64 %t627, %t630
  %t632 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t631)
  call void @olang_textcopy(ptr %t632, ptr %t626, i64 %t627)
  %t633 = getelementptr i8, ptr %t632, i64 %t627
  call void @olang_textcopy(ptr %t633, ptr %t629, i64 %t630)
  %t634 = insertvalue { i64, ptr } undef, i64 %t631, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t632, 1
  %t637 = extractvalue { i64, ptr } %t635, 0
  %t638 = extractvalue { i64, ptr } %t635, 1
  %t639 = mul i64 %t637, 1
  %t640 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t639)
  call void @llvm.memcpy.p0.p0.i64(ptr %t640, ptr %t638, i64 %t639, i1 false)
  %t641 = insertvalue { i64, ptr } undef, i64 %t637, 0
  %t642 = insertvalue { i64, ptr } %t641, ptr %t640, 1
  store { i64, ptr } %t642, ptr %l196, !tbaa !27
  br label %bb79
bb79:
  %t644 = load ptr, ptr %l2, !tbaa !29
  %t645 = load i32, ptr %l29, !tbaa !23
  %t648 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s23, ptr %t644, i32 %t645)
  store { i64, ptr } %t648, ptr %l204
  br label %bb80
bb80:
  %t649 = extractvalue { i64, ptr } { i64 8, ptr @.d109 }, 1
  %t650 = extractvalue { i64, ptr } { i64 8, ptr @.d109 }, 0
  %t651 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t652 = extractvalue { i64, ptr } %t651, 1
  %t653 = extractvalue { i64, ptr } %t651, 0
  %t654 = add i64 %t650, %t653
  %t655 = extractvalue { i64, ptr } { i64 4, ptr @.d110 }, 1
  %t656 = extractvalue { i64, ptr } { i64 4, ptr @.d110 }, 0
  %t657 = add i64 %t654, %t656
  %t658 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t659 = extractvalue { i64, ptr } %t658, 1
  %t660 = extractvalue { i64, ptr } %t658, 0
  %t661 = add i64 %t657, %t660
  %t662 = extractvalue { i64, ptr } { i64 1, ptr @.d111 }, 1
  %t663 = extractvalue { i64, ptr } { i64 1, ptr @.d111 }, 0
  %t664 = add i64 %t661, %t663
  %t665 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t665, 1
  %t667 = extractvalue { i64, ptr } %t665, 0
  %t668 = add i64 %t664, %t667
  %t669 = extractvalue { i64, ptr } { i64 1, ptr @.d112 }, 1
  %t670 = extractvalue { i64, ptr } { i64 1, ptr @.d112 }, 0
  %t671 = add i64 %t668, %t670
  %t672 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t673 = extractvalue { i64, ptr } %t672, 1
  %t674 = extractvalue { i64, ptr } %t672, 0
  %t675 = add i64 %t671, %t674
  %t676 = extractvalue { i64, ptr } { i64 2, ptr @.d113 }, 1
  %t677 = extractvalue { i64, ptr } { i64 2, ptr @.d113 }, 0
  %t678 = add i64 %t675, %t677
  %t679 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 1
  %t681 = extractvalue { i64, ptr } %t679, 0
  %t682 = add i64 %t678, %t681
  %t683 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t682)
  call void @olang_textcopy(ptr %t683, ptr %t649, i64 %t650)
  %t684 = getelementptr i8, ptr %t683, i64 %t650
  call void @olang_textcopy(ptr %t684, ptr %t652, i64 %t653)
  %t685 = getelementptr i8, ptr %t684, i64 %t653
  call void @olang_textcopy(ptr %t685, ptr %t655, i64 %t656)
  %t686 = getelementptr i8, ptr %t685, i64 %t656
  call void @olang_textcopy(ptr %t686, ptr %t659, i64 %t660)
  %t687 = getelementptr i8, ptr %t686, i64 %t660
  call void @olang_textcopy(ptr %t687, ptr %t662, i64 %t663)
  %t688 = getelementptr i8, ptr %t687, i64 %t663
  call void @olang_textcopy(ptr %t688, ptr %t666, i64 %t667)
  %t689 = getelementptr i8, ptr %t688, i64 %t667
  call void @olang_textcopy(ptr %t689, ptr %t669, i64 %t670)
  %t690 = getelementptr i8, ptr %t689, i64 %t670
  call void @olang_textcopy(ptr %t690, ptr %t673, i64 %t674)
  %t691 = getelementptr i8, ptr %t690, i64 %t674
  call void @olang_textcopy(ptr %t691, ptr %t676, i64 %t677)
  %t692 = getelementptr i8, ptr %t691, i64 %t677
  call void @olang_textcopy(ptr %t692, ptr %t680, i64 %t681)
  %t693 = insertvalue { i64, ptr } undef, i64 %t682, 0
  %t694 = insertvalue { i64, ptr } %t693, ptr %t683, 1
  store { i64, ptr } %t694, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s23)
  br label %bb96
bb81:
  %t696 = load { i64, [15 x i64] }, ptr %l1
  %t698 = extractvalue { i64, [15 x i64] } %t696, 0
  %t699 = icmp eq i64 %t698, 11
  br i1 %t699, label %bb82, label %bb83
bb82:
  %t701 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t702 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t701, i32 0, i32 0
  %t703 = load { i64, [4 x i64] }, ptr %t702
  store { i64, [4 x i64] } %t703, ptr %l33
  %t705 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t706 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t705, i32 0, i32 1
  %t707 = load i32, ptr %t706
  store i32 %t707, ptr %l34, !tbaa !23
  %t709 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t710 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t709, i32 0, i32 2
  %t711 = load i32, ptr %t710
  store i32 %t711, ptr %l35, !tbaa !23
  br label %bb84
bb83:
  br label %bb88
bb84:
  store %olang.scope zeroinitializer, ptr %s26
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load { i64, [4 x i64] }, ptr %l33
  %t717 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s26, ptr %t713, { i64, [4 x i64] } %t714)
  store { i64, ptr } %t717, ptr %l213
  br label %bb85
bb85:
  %t718 = load ptr, ptr %l0, !tbaa !29
  %t719 = load i32, ptr %l34, !tbaa !23
  %t722 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %s26, ptr %t718, i32 %t719)
  store { i64, ptr } %t722, ptr %l216
  br label %bb86
bb86:
  %t723 = load ptr, ptr %l0, !tbaa !29
  %t724 = load i32, ptr %l35, !tbaa !23
  %t727 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %s26, ptr %t723, i32 %t724)
  store { i64, ptr } %t727, ptr %l219
  br label %bb87
bb87:
  %t728 = extractvalue { i64, ptr } { i64 7, ptr @.d114 }, 1
  %t729 = extractvalue { i64, ptr } { i64 7, ptr @.d114 }, 0
  %t730 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t731 = extractvalue { i64, ptr } %t730, 1
  %t732 = extractvalue { i64, ptr } %t730, 0
  %t733 = add i64 %t729, %t732
  %t734 = extractvalue { i64, ptr } { i64 6, ptr @.d115 }, 1
  %t735 = extractvalue { i64, ptr } { i64 6, ptr @.d115 }, 0
  %t736 = add i64 %t733, %t735
  %t737 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t738 = extractvalue { i64, ptr } %t737, 1
  %t739 = extractvalue { i64, ptr } %t737, 0
  %t740 = add i64 %t736, %t739
  %t741 = extractvalue { i64, ptr } { i64 4, ptr @.d116 }, 1
  %t742 = extractvalue { i64, ptr } { i64 4, ptr @.d116 }, 0
  %t743 = add i64 %t740, %t742
  %t744 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t745 = extractvalue { i64, ptr } %t744, 1
  %t746 = extractvalue { i64, ptr } %t744, 0
  %t747 = add i64 %t743, %t746
  %t748 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t747)
  call void @olang_textcopy(ptr %t748, ptr %t728, i64 %t729)
  %t749 = getelementptr i8, ptr %t748, i64 %t729
  call void @olang_textcopy(ptr %t749, ptr %t731, i64 %t732)
  %t750 = getelementptr i8, ptr %t749, i64 %t732
  call void @olang_textcopy(ptr %t750, ptr %t734, i64 %t735)
  %t751 = getelementptr i8, ptr %t750, i64 %t735
  call void @olang_textcopy(ptr %t751, ptr %t738, i64 %t739)
  %t752 = getelementptr i8, ptr %t751, i64 %t739
  call void @olang_textcopy(ptr %t752, ptr %t741, i64 %t742)
  %t753 = getelementptr i8, ptr %t752, i64 %t742
  call void @olang_textcopy(ptr %t753, ptr %t745, i64 %t746)
  %t754 = insertvalue { i64, ptr } undef, i64 %t747, 0
  %t755 = insertvalue { i64, ptr } %t754, ptr %t748, 1
  store { i64, ptr } %t755, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s26)
  br label %bb96
bb88:
  %t757 = load { i64, [15 x i64] }, ptr %l1
  %t759 = extractvalue { i64, [15 x i64] } %t757, 0
  %t760 = icmp eq i64 %t759, 12
  br i1 %t760, label %bb89, label %bb90
bb89:
  %t762 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t763 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t762, i32 0, i32 0
  %t764 = load { i64, [1 x i64] }, ptr %t763
  store { i64, [1 x i64] } %t764, ptr %l36
  %t766 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t767 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t766, i32 0, i32 1
  %t768 = load { i64, [1 x i64] }, ptr %t767
  store { i64, [1 x i64] } %t768, ptr %l37
  %t770 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t771 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t770, i32 0, i32 2
  %t772 = load i32, ptr %t771
  store i32 %t772, ptr %l38, !tbaa !23
  br label %bb91
bb90:
  br label %bb95
bb91:
  store %olang.scope zeroinitializer, ptr %s28
  %t774 = load ptr, ptr %l0, !tbaa !29
  %t775 = load { i64, [1 x i64] }, ptr %l36
  %t778 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s28, ptr %t774, { i64, [1 x i64] } %t775)
  store { i64, ptr } %t778, ptr %l228
  br label %bb92
bb92:
  %t779 = load ptr, ptr %l0, !tbaa !29
  %t780 = load { i64, [1 x i64] }, ptr %l37
  %t783 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s28, ptr %t779, { i64, [1 x i64] } %t780)
  store { i64, ptr } %t783, ptr %l231
  br label %bb93
bb93:
  %t784 = load ptr, ptr %l2, !tbaa !29
  %t785 = load i32, ptr %l38, !tbaa !23
  %t788 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s28, ptr %t784, i32 %t785)
  store { i64, ptr } %t788, ptr %l234
  br label %bb94
bb94:
  %t789 = extractvalue { i64, ptr } { i64 5, ptr @.d117 }, 1
  %t790 = extractvalue { i64, ptr } { i64 5, ptr @.d117 }, 0
  %t791 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t792 = extractvalue { i64, ptr } %t791, 1
  %t793 = extractvalue { i64, ptr } %t791, 0
  %t794 = add i64 %t790, %t793
  %t795 = extractvalue { i64, ptr } { i64 4, ptr @.d118 }, 1
  %t796 = extractvalue { i64, ptr } { i64 4, ptr @.d118 }, 0
  %t797 = add i64 %t794, %t796
  %t798 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t799 = extractvalue { i64, ptr } %t798, 1
  %t800 = extractvalue { i64, ptr } %t798, 0
  %t801 = add i64 %t797, %t800
  %t802 = extractvalue { i64, ptr } { i64 2, ptr @.d119 }, 1
  %t803 = extractvalue { i64, ptr } { i64 2, ptr @.d119 }, 0
  %t804 = add i64 %t801, %t803
  %t805 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t806 = extractvalue { i64, ptr } %t805, 1
  %t807 = extractvalue { i64, ptr } %t805, 0
  %t808 = add i64 %t804, %t807
  %t809 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t808)
  call void @olang_textcopy(ptr %t809, ptr %t789, i64 %t790)
  %t810 = getelementptr i8, ptr %t809, i64 %t790
  call void @olang_textcopy(ptr %t810, ptr %t792, i64 %t793)
  %t811 = getelementptr i8, ptr %t810, i64 %t793
  call void @olang_textcopy(ptr %t811, ptr %t795, i64 %t796)
  %t812 = getelementptr i8, ptr %t811, i64 %t796
  call void @olang_textcopy(ptr %t812, ptr %t799, i64 %t800)
  %t813 = getelementptr i8, ptr %t812, i64 %t800
  call void @olang_textcopy(ptr %t813, ptr %t802, i64 %t803)
  %t814 = getelementptr i8, ptr %t813, i64 %t803
  call void @olang_textcopy(ptr %t814, ptr %t806, i64 %t807)
  %t815 = insertvalue { i64, ptr } undef, i64 %t808, 0
  %t816 = insertvalue { i64, ptr } %t815, ptr %t809, 1
  store { i64, ptr } %t816, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s28)
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_55b2be13c853614c_e5b496909f3a0f10)
  unreachable
bb96:
  %t818 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t818, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2etask(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Task" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Task"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l15 = alloca %"compiler/mir:TaskClause"
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca %"compiler/typed:Item"
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l30 = alloca i32
  %l33 = alloca i32
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l64 = alloca %"compiler/mir:Place"
  %l65 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l92 = alloca i32
  %l95 = alloca i32
  %l121 = alloca %"compiler/mir:TaskClause"
  %l129 = alloca i32
  %l132 = alloca i32
  %l158 = alloca %"compiler/typed:Item"
  %l159 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l177 = alloca ptr
  %l180 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l188 = alloca i64
  %l189 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Task" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l23
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 3
  %t4 = getelementptr %"compiler/mir:Range", ptr %t3, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = icmp sgt i32 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 0, ptr %l3, !tbaa !23
  %t9 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 3
  %t10 = getelementptr %"compiler/mir:Range", ptr %t9, i32 0, i32 1
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t13 = load i32, ptr %l4, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = icmp sgt i32 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb3:
  br label %bb23
bb4:
  %t19 = load i32, ptr %l5, !tbaa !23
  %t21 = icmp sgt i32 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i32 0, ptr %l30, !tbaa !23
  br label %bb9
bb6:
  %t23 = load i32, ptr %l4, !tbaa !23
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = sub i32 %t23, %t24
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = add i32 %t27, %t28
  %t33 = sub i32 %t31, 1
  %t34 = load i32, ptr %l5, !tbaa !23
  %t37 = sdiv i32 %t33, %t34
  store i32 %t37, ptr %l33, !tbaa !23
  br label %bb8
bb7:
  store i32 0, ptr %l33, !tbaa !23
  br label %bb8
bb8:
  %t39 = load i32, ptr %l33, !tbaa !23
  store i32 %t39, ptr %l30, !tbaa !23
  br label %bb9
bb9:
  %t40 = load i32, ptr %l30, !tbaa !23
  store i32 %t40, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load i32, ptr %l7, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = icmp slt i32 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t49 = load i32, ptr %l3, !tbaa !23
  %t50 = load i32, ptr %l7, !tbaa !23
  %t51 = load i32, ptr %l5, !tbaa !23
  %t54 = mul i32 %t50, %t51
  %t57 = add i32 %t49, %t54
  store i32 %t57, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l51, !tbaa !29
  %t59 = load i32, ptr %l8, !tbaa !23
  %t61 = icmp sgt i32 %t59, 0
  br i1 %t61, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 2, ptr @.d120 }, ptr %l54, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr @.d121 }, ptr %l54, !tbaa !27
  br label %bb16
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l55, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/mir:dumper", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/mir:Fn", ptr %t67, i32 0, i32 13
  %t70 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 3
  %t71 = getelementptr %"compiler/mir:Range", ptr %t70, i32 0, i32 0
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  %t75 = load i32, ptr %l8, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t80 = add i64 %t74, %t77
  %t83 = call %"compiler/mir:Place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t69, i64 %t80)
  store %"compiler/mir:Place" %t83, ptr %l64
  br label %bb17
bb17:
  %t84 = load ptr, ptr %l55, !tbaa !29
  %t85 = load %"compiler/mir:Place", ptr %l64
  %t86 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s3, ptr %t84, %"compiler/mir:Place" %t85)
  store { i64, ptr } %t86, ptr %l65
  br label %bb18
bb18:
  %t87 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = add i64 %t89, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t88, i64 %t89)
  %t95 = getelementptr i8, ptr %t94, i64 %t89
  call void @olang_textcopy(ptr %t95, ptr %t91, i64 %t92)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t94, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t105, { i64, ptr } %t104)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t107 = load i32, ptr %l7, !tbaa !23
  %t109 = add i32 %t107, 1
  store i32 %t109, ptr %l7, !tbaa !23
  br label %bb10
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 3, ptr @.d122 })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb23:
  store ptr %l2, ptr %l71, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 0
  %t114 = load { i64, [5 x i64] }, ptr %t113
  %t117 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %s0, ptr %t112, { i64, [5 x i64] } %t114)
  store { i64, ptr } %t117, ptr %l74
  br label %bb24
bb24:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 1
  %t120 = load %"compiler/mir:Range", ptr %t119
  %t123 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s0, ptr %t118, %"compiler/mir:Range" %t120)
  store { i64, ptr } %t123, ptr %l77
  br label %bb25
bb25:
  %t124 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } { i64 1, ptr @.d123 }, 1
  %t128 = extractvalue { i64, ptr } { i64 1, ptr @.d123 }, 0
  %t129 = add i64 %t126, %t128
  %t130 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d124 }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr @.d124 }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t125, i64 %t126)
  %t138 = getelementptr i8, ptr %t137, i64 %t126
  call void @olang_textcopy(ptr %t138, ptr %t127, i64 %t128)
  %t139 = getelementptr i8, ptr %t138, i64 %t128
  call void @olang_textcopy(ptr %t139, ptr %t131, i64 %t132)
  %t140 = getelementptr i8, ptr %t139, i64 %t132
  call void @olang_textcopy(ptr %t140, ptr %t134, i64 %t135)
  %t141 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t137, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  %t150 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t150, { i64, ptr } %t149)
  br label %bb26
bb26:
  %t152 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 2
  %t153 = getelementptr %"compiler/mir:Range", ptr %t152, i32 0, i32 1
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = icmp sgt i32 %t154, 0
  br i1 %t156, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l2, ptr %l82, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 2
  %t160 = load %"compiler/mir:Range", ptr %t159
  %t163 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s7, ptr %t158, %"compiler/mir:Range" %t160)
  store { i64, ptr } %t163, ptr %l85
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t164 = extractvalue { i64, ptr } { i64 2, ptr @.d125 }, 1
  %t165 = extractvalue { i64, ptr } { i64 2, ptr @.d125 }, 0
  %t166 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 1, ptr @.d126 }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr @.d126 }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t164, i64 %t165)
  %t174 = getelementptr i8, ptr %t173, i64 %t165
  call void @olang_textcopy(ptr %t174, ptr %t167, i64 %t168)
  %t175 = getelementptr i8, ptr %t174, i64 %t168
  call void @olang_textcopy(ptr %t175, ptr %t170, i64 %t171)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t173, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load ptr, ptr %l82, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t185, { i64, ptr } %t184)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb31:
  store i32 0, ptr %l9, !tbaa !23
  %t187 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 4
  %t188 = getelementptr %"compiler/mir:Range", ptr %t187, i32 0, i32 1
  %t189 = load i32, ptr %t188, !tbaa !23
  store i32 %t189, ptr %l10, !tbaa !23
  store i32 1, ptr %l11, !tbaa !23
  %t191 = load i32, ptr %l10, !tbaa !23
  %t192 = load i32, ptr %l9, !tbaa !23
  %t195 = icmp sgt i32 %t191, %t192
  br i1 %t195, label %bb32, label %bb33
bb32:
  %t197 = load i32, ptr %l11, !tbaa !23
  %t199 = icmp sgt i32 %t197, 0
  br i1 %t199, label %bb34, label %bb35
bb33:
  store i32 0, ptr %l92, !tbaa !23
  br label %bb37
bb34:
  %t201 = load i32, ptr %l10, !tbaa !23
  %t202 = load i32, ptr %l9, !tbaa !23
  %t205 = sub i32 %t201, %t202
  %t206 = load i32, ptr %l11, !tbaa !23
  %t209 = add i32 %t205, %t206
  %t211 = sub i32 %t209, 1
  %t212 = load i32, ptr %l11, !tbaa !23
  %t215 = sdiv i32 %t211, %t212
  store i32 %t215, ptr %l95, !tbaa !23
  br label %bb36
bb35:
  store i32 0, ptr %l95, !tbaa !23
  br label %bb36
bb36:
  %t217 = load i32, ptr %l95, !tbaa !23
  store i32 %t217, ptr %l92, !tbaa !23
  br label %bb37
bb37:
  %t218 = load i32, ptr %l92, !tbaa !23
  store i32 %t218, ptr %l12, !tbaa !23
  store i32 0, ptr %l13, !tbaa !23
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t219 = load i32, ptr %l13, !tbaa !23
  %t220 = load i32, ptr %l12, !tbaa !23
  %t223 = icmp slt i32 %t219, %t220
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s10)
  br label %bb72
bb40:
  br label %bb41
bb41:
  %t227 = load i32, ptr %l9, !tbaa !23
  %t228 = load i32, ptr %l13, !tbaa !23
  %t229 = load i32, ptr %l11, !tbaa !23
  %t232 = mul i32 %t228, %t229
  %t235 = add i32 %t227, %t232
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/mir:dumper", ptr %t237, i32 0, i32 0
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/mir:Fn", ptr %t240, i32 0, i32 17
  %t243 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 4
  %t244 = getelementptr %"compiler/mir:Range", ptr %t243, i32 0, i32 0
  %t245 = load i32, ptr %t244, !tbaa !23
  %t247 = sext i32 %t245 to i64
  %t250 = sext i32 %t235 to i64
  %t253 = add i64 %t247, %t250
  %t256 = call %"compiler/mir:TaskClause" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eAt_H2a51e389d978bc4a54496c3113cf8f80(ptr %v0, ptr %t242, i64 %t253)
  store %"compiler/mir:TaskClause" %t256, ptr %l121
  br label %bb42
bb42:
  %t257 = load %"compiler/mir:TaskClause", ptr %l121
  store %"compiler/mir:TaskClause" %t257, ptr %l15
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %l2, { i64, ptr } { i64 6, ptr @.d127 })
  br label %bb43
bb43:
  %t259 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 1
  %t260 = load i1, ptr %t259, !tbaa !21
  br i1 %t260, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s11
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %l2, { i64, ptr } { i64 4, ptr @.d128 })
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb47
bb47:
  store i32 0, ptr %l16, !tbaa !23
  %t263 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 0
  %t264 = getelementptr %"compiler/mir:Range", ptr %t263, i32 0, i32 1
  %t265 = load i32, ptr %t264, !tbaa !23
  store i32 %t265, ptr %l17, !tbaa !23
  store i32 1, ptr %l18, !tbaa !23
  %t267 = load i32, ptr %l17, !tbaa !23
  %t268 = load i32, ptr %l16, !tbaa !23
  %t271 = icmp sgt i32 %t267, %t268
  br i1 %t271, label %bb48, label %bb49
bb48:
  %t273 = load i32, ptr %l18, !tbaa !23
  %t275 = icmp sgt i32 %t273, 0
  br i1 %t275, label %bb50, label %bb51
bb49:
  store i32 0, ptr %l129, !tbaa !23
  br label %bb53
bb50:
  %t277 = load i32, ptr %l17, !tbaa !23
  %t278 = load i32, ptr %l16, !tbaa !23
  %t281 = sub i32 %t277, %t278
  %t282 = load i32, ptr %l18, !tbaa !23
  %t285 = add i32 %t281, %t282
  %t287 = sub i32 %t285, 1
  %t288 = load i32, ptr %l18, !tbaa !23
  %t291 = sdiv i32 %t287, %t288
  store i32 %t291, ptr %l132, !tbaa !23
  br label %bb52
bb51:
  store i32 0, ptr %l132, !tbaa !23
  br label %bb52
bb52:
  %t293 = load i32, ptr %l132, !tbaa !23
  store i32 %t293, ptr %l129, !tbaa !23
  br label %bb53
bb53:
  %t294 = load i32, ptr %l129, !tbaa !23
  store i32 %t294, ptr %l19, !tbaa !23
  store i32 0, ptr %l20, !tbaa !23
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s13
  %t295 = load i32, ptr %l20, !tbaa !23
  %t296 = load i32, ptr %l19, !tbaa !23
  %t299 = icmp slt i32 %t295, %t296
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s13)
  br label %bb65
bb56:
  br label %bb57
bb57:
  %t303 = load i32, ptr %l16, !tbaa !23
  %t304 = load i32, ptr %l20, !tbaa !23
  %t305 = load i32, ptr %l18, !tbaa !23
  %t308 = mul i32 %t304, %t305
  %t311 = add i32 %t303, %t308
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/mir:dumper", ptr %t313, i32 0, i32 0
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t318 = getelementptr %"compiler/mir:Fn", ptr %t316, i32 0, i32 18
  %t319 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 0
  %t320 = getelementptr %"compiler/mir:Range", ptr %t319, i32 0, i32 0
  %t321 = load i32, ptr %t320, !tbaa !23
  %t323 = sext i32 %t321 to i64
  %t326 = sext i32 %t311 to i64
  %t329 = add i64 %t323, %t326
  %t332 = call %"compiler/typed:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t318, i64 %t329)
  store %"compiler/typed:Item" %t332, ptr %l158
  br label %bb58
bb58:
  %t333 = load %"compiler/typed:Item", ptr %l158
  store %"compiler/typed:Item" %t333, ptr %l22
  store ptr %l2, ptr %l159, !tbaa !29
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/mir:dumper", ptr %t334, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t338 = getelementptr %"compiler/typed:Item", ptr %l22, i32 0, i32 0
  %t339 = load i32, ptr %t338, !tbaa !23
  %t342 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s13, ptr %t337, i32 %t339)
  store { i64, ptr } %t342, ptr %l163
  br label %bb59
bb59:
  %t343 = getelementptr %"compiler/typed:Item", ptr %l22, i32 0, i32 1
  %t344 = load i64, ptr %t343, !tbaa !24
  %t346 = icmp slt i64 %t344, 0
  br i1 %t346, label %bb60, label %bb61
bb60:
  store { i64, ptr } { i64 0, ptr @.d129 }, ptr %l166, !tbaa !27
  br label %bb62
bb61:
  %t348 = getelementptr %"compiler/typed:Item", ptr %l22, i32 0, i32 1
  %t349 = load i64, ptr %t348, !tbaa !24
  %t350 = extractvalue { i64, ptr } { i64 1, ptr @.d130 }, 1
  %t351 = extractvalue { i64, ptr } { i64 1, ptr @.d130 }, 0
  %t353 = call i64 @__olang_fmt_i64(ptr null, i64 %t349)
  %t354 = add i64 %t351, %t353
  %t355 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t354)
  call void @olang_textcopy(ptr %t355, ptr %t350, i64 %t351)
  %t356 = getelementptr i8, ptr %t355, i64 %t351
  %t357 = call i64 @__olang_fmt_i64(ptr %t356, i64 %t349)
  %t358 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t355, 1
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t362 = extractvalue { i64, ptr } %t359, 1
  %t363 = mul i64 %t361, 1
  %t364 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t363)
  call void @llvm.memcpy.p0.p0.i64(ptr %t364, ptr %t362, i64 %t363, i1 false)
  %t365 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t364, 1
  store { i64, ptr } %t366, ptr %l166, !tbaa !27
  br label %bb62
bb62:
  %t368 = extractvalue { i64, ptr } { i64 1, ptr @.d131 }, 1
  %t369 = extractvalue { i64, ptr } { i64 1, ptr @.d131 }, 0
  %t370 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 1
  %t372 = extractvalue { i64, ptr } %t370, 0
  %t373 = add i64 %t369, %t372
  %t374 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = add i64 %t373, %t376
  %t378 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t377)
  call void @olang_textcopy(ptr %t378, ptr %t368, i64 %t369)
  %t379 = getelementptr i8, ptr %t378, i64 %t369
  call void @olang_textcopy(ptr %t379, ptr %t371, i64 %t372)
  %t380 = getelementptr i8, ptr %t379, i64 %t372
  call void @olang_textcopy(ptr %t380, ptr %t375, i64 %t376)
  %t381 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t378, 1
  %t384 = extractvalue { i64, ptr } %t382, 0
  %t385 = extractvalue { i64, ptr } %t382, 1
  %t386 = mul i64 %t384, 1
  %t387 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t386)
  call void @llvm.memcpy.p0.p0.i64(ptr %t387, ptr %t385, i64 %t386, i1 false)
  %t388 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t387, 1
  %t390 = load ptr, ptr %l159, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %t390, { i64, ptr } %t389)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s13)
  br label %bb64
bb64:
  %t392 = load i32, ptr %l20, !tbaa !23
  %t394 = add i32 %t392, 1
  store i32 %t394, ptr %l20, !tbaa !23
  br label %bb54
bb65:
  %t396 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 2
  %t397 = load { i64, [4 x i64] }, ptr %t396
  %t399 = extractvalue { i64, [4 x i64] } %t397, 0
  %t400 = icmp eq i64 %t399, 0
  %t402 = xor i1 %t400, true
  br i1 %t402, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s17
  store ptr %l2, ptr %l177, !tbaa !29
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 2
  %t406 = load { i64, [4 x i64] }, ptr %t405
  %t409 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s17, ptr %t404, { i64, [4 x i64] } %t406)
  store { i64, ptr } %t409, ptr %l180
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t410 = extractvalue { i64, ptr } { i64 4, ptr @.d132 }, 1
  %t411 = extractvalue { i64, ptr } { i64 4, ptr @.d132 }, 0
  %t412 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t412, 1
  %t414 = extractvalue { i64, ptr } %t412, 0
  %t415 = add i64 %t411, %t414
  %t416 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t415)
  call void @olang_textcopy(ptr %t416, ptr %t410, i64 %t411)
  %t417 = getelementptr i8, ptr %t416, i64 %t411
  call void @olang_textcopy(ptr %t417, ptr %t413, i64 %t414)
  %t418 = insertvalue { i64, ptr } undef, i64 %t415, 0
  %t419 = insertvalue { i64, ptr } %t418, ptr %t416, 1
  %t421 = extractvalue { i64, ptr } %t419, 0
  %t422 = extractvalue { i64, ptr } %t419, 1
  %t423 = mul i64 %t421, 1
  %t424 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t423)
  call void @llvm.memcpy.p0.p0.i64(ptr %t424, ptr %t422, i64 %t423, i1 false)
  %t425 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t424, 1
  %t427 = load ptr, ptr %l177, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %t427, { i64, ptr } %t426)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s17)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s10)
  br label %bb71
bb71:
  %t429 = load i32, ptr %l13, !tbaa !23
  %t431 = add i32 %t429, 1
  store i32 %t431, ptr %l13, !tbaa !23
  br label %bb38
bb72:
  %t434 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t434, ptr %l186
  br label %bb73
bb73:
  %t435 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t435, ptr %l187, !tbaa !27
  %t436 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t437 = extractvalue { i64, ptr } %t436, 0
  store i64 %t437, ptr %l188, !tbaa !24
  %t438 = load i64, ptr %l188, !tbaa !24
  %t439 = mul i64 %t438, 1
  %t440 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t439)
  %t441 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t442 = insertvalue { i64, ptr } %t441, ptr %t440, 1
  store { i64, ptr } %t442, ptr %l189, !tbaa !27
  %t443 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !27
  %t447 = load i64, ptr %l188, !tbaa !24
  %t448 = mul i64 %t447, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t444, ptr %t446, i64 %t448, i1 false)
  %t449 = load { i64, ptr }, ptr %l189, !tbaa !27
  store { i64, ptr } %t449, ptr %l187, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t450 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t450, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2evarKind(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l15 = alloca { i64, [1 x i64] }
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = extractvalue { i64, ptr } { i64 6, ptr @.d133 }, 1
  %t12 = extractvalue { i64, ptr } { i64 6, ptr @.d133 }, 0
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %t10)
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t11, i64 %t12)
  %t17 = getelementptr i8, ptr %t16, i64 %t12
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %t10)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t16, 1
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb15
bb4:
  %t22 = load { i64, [1 x i64] }, ptr %l1
  %t24 = extractvalue { i64, [1 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 4
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = extractvalue { i64, ptr } { i64 8, ptr @.d134 }, 1
  %t33 = extractvalue { i64, ptr } { i64 8, ptr @.d134 }, 0
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = getelementptr i8, ptr %t37, i64 %t33
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t31)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  store { i64, ptr } %t41, ptr %l4, !tbaa !27
  br label %bb15
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb14
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t43 = load { i64, [1 x i64] }, ptr %l1
  store { i64, [1 x i64] } %t43, ptr %l15
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aVarKind(ptr %s6, ptr %l15, i64 0)
  br label %bb12
bb12:
  %t45 = load ptr, ptr %s6
  %t46 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t47 = load i64, ptr %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t45, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l17, !tbaa !27
  %t51 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t52 = load ptr, ptr %t51
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %sbgrew.54, label %sbdone.55
sbgrew.54:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.55
sbdone.55:
  %t56 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  %t58 = extractvalue { i64, ptr } %t56, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t64 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s5, { i64, ptr } %t62)
  store { i64, ptr } %t64, ptr %l19
  br label %bb13
bb13:
  %t65 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6326b544498e75fa_e53a2c99f88826ee)
  unreachable
bb15:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l10 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 11
  %t7 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t14 = add i64 %t10, %a2
  %t17 = call { i64, [4 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t6, i64 %t14)
  store { i64, [4 x i64] } %t17, ptr %l10
  br label %bb1
bb1:
  %t18 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t18, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/mir:verifier", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l10
  br label %bb2
bb2:
  %t18 = load i32, ptr %l10
  %t20 = trunc i64 19 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i32, ptr %l2, !tbaa !23
  store i32 %t23, ptr %l13, !tbaa !23
  br label %bb5
bb4:
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t25, ptr %l13, !tbaa !23
  br label %bb5
bb5:
  %t27 = load i32, ptr %l13, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l9 = alloca i1
  %l20 = alloca %"compiler/mir:ScopeInfo"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l9
  br label %bb4
bb4:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = extractvalue { i64, ptr } { i64 10, ptr @.d135 }, 1
  %t21 = extractvalue { i64, ptr } { i64 10, ptr @.d135 }, 0
  %t23 = sext i32 %t19 to i64
  %t24 = call i64 @__olang_fmt_i64(ptr null, i64 %t23)
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 19, ptr @.d136 }, 1
  %t27 = extractvalue { i64, ptr } { i64 19, ptr @.d136 }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t23)
  %t32 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t32, ptr %t26, i64 %t27)
  %t33 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t29, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t18, { i64, ptr } %t41)
  br label %bb7
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/mir:verifier", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/mir:Fn", ptr %t47, i32 0, i32 8
  %t50 = load i32, ptr %l2, !tbaa !23
  %t52 = sext i32 %t50 to i64
  %t55 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t49, i64 %t52)
  store %"compiler/mir:ScopeInfo" %t55, ptr %l20
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb8:
  %t56 = getelementptr %"compiler/mir:ScopeInfo", ptr %l20, i32 0, i32 0
  %t57 = load i32, ptr %t56
  %t59 = trunc i64 5 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t64 = extractvalue { i64, ptr } { i64 10, ptr @.d137 }, 1
  %t65 = extractvalue { i64, ptr } { i64 10, ptr @.d137 }, 0
  %t67 = sext i32 %t63 to i64
  %t68 = call i64 @__olang_fmt_i64(ptr null, i64 %t67)
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 16, ptr @.d138 }, 1
  %t71 = extractvalue { i64, ptr } { i64 16, ptr @.d138 }, 0
  %t72 = add i64 %t69, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t64, i64 %t65)
  %t74 = getelementptr i8, ptr %t73, i64 %t65
  %t75 = call i64 @__olang_fmt_i64(ptr %t74, i64 %t67)
  %t76 = getelementptr i8, ptr %t74, i64 %t68
  call void @olang_textcopy(ptr %t76, ptr %t70, i64 %t71)
  %t77 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t73, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = extractvalue { i64, ptr } %t78, 1
  %t82 = mul i64 %t80, 1
  %t83 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t82)
  call void @llvm.memcpy.p0.p0.i64(ptr %t83, ptr %t81, i64 %t82, i1 false)
  %t84 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t62, { i64, ptr } %t85)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb24
bb14:
  %t88 = load { i64, [1 x i64] }, ptr %l1
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 4
  br i1 %t91, label %bb15, label %bb16
bb15:
  %t93 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l3, !tbaa !23
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t97, i32 %t98)
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a15aa4830130cc38_9fcdb454ad4b970c)
  unreachable
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [5 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  store { i64, [5 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %a0, { i64, [4 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_43daeee16a7347fc_3936ff71893c42a0)
  unreachable
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [5 x i64] }
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l18 = alloca i32
  %l26 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, [5 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [1 x i64] }, i32 }, ptr %t6, i32 0, i32 1
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb5
bb2:
  %t10 = load { i64, [5 x i64] }, ptr %l1
  %t12 = extractvalue { i64, [5 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { i64, i32 }, ptr %t15, i32 0, i32 1
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = load i32, ptr %l2, !tbaa !23
  store i32 %t19, ptr %l5, !tbaa !23
  br label %bb12
bb6:
  %t21 = load { i64, [5 x i64] }, ptr %l1
  %t23 = extractvalue { i64, [5 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 2
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t27 = getelementptr { { i64, [4 x i64] } }, ptr %t26, i32 0, i32 0
  %t28 = load { i64, [4 x i64] }, ptr %t27
  store { i64, [4 x i64] } %t28, ptr %l3
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, [4 x i64] }, ptr %l3
  %t34 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t30, { i64, [4 x i64] } %t31)
  store i32 %t34, ptr %l18
  br label %bb10
bb10:
  %t35 = load i32, ptr %l18, !tbaa !23
  store i32 %t35, ptr %l5, !tbaa !23
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_690174ade0b6e824_1aa5c898f3f73ab8)
  unreachable
bb12:
  %t36 = load i32, ptr %l5, !tbaa !23
  store i32 %t36, ptr %l4, !tbaa !23
  %t37 = load i32, ptr %l4, !tbaa !23
  %t38 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t41 = icmp eq i32 %t37, %t38
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/mir:verifier", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load i32, ptr %l4, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l26
  br label %bb16
bb16:
  %t53 = load i32, ptr %l26
  %t55 = trunc i64 21 to i32
  %t56 = icmp eq i32 %t53, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l30, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l4, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s4, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l33
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t66 = extractvalue { i64, ptr } { i64 12, ptr @.d139 }, 1
  %t67 = extractvalue { i64, ptr } { i64 12, ptr @.d139 }, 0
  %t68 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 16, ptr @.d140 }, 1
  %t73 = extractvalue { i64, ptr } { i64 16, ptr @.d140 }, 0
  %t74 = add i64 %t71, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t66, i64 %t67)
  %t76 = getelementptr i8, ptr %t75, i64 %t67
  call void @olang_textcopy(ptr %t76, ptr %t69, i64 %t70)
  %t77 = getelementptr i8, ptr %t76, i64 %t70
  call void @olang_textcopy(ptr %t77, ptr %t72, i64 %t73)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t75, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t87 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t87, { i64, ptr } %t86)
  br label %bb20
bb20:
  %t89 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  store i32 %t89, ptr %rv
  br label %ret
bb21:
  %t91 = load i32, ptr %l4, !tbaa !23
  store i32 %t91, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l16 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i32
  %rv = alloca { i32, i1 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 24 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l16
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t27 = load i32, ptr %l16, !tbaa !23
  %t28 = insertvalue { i32, i1 } undef, i32 %t27, 0
  %t29 = insertvalue { i32, i1 } %t28, i1 true, 1
  store { i32, i1 } %t29, ptr %rv
  br label %ret
bb6:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l20
  br label %bb7
bb7:
  %t36 = load i32, ptr %l20
  %t38 = trunc i64 18 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l2, !tbaa !29
  store ptr %t41, ptr %l24, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb12
bb10:
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t48 = load i32, ptr %l27, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t49, ptr %l28
  br label %bb11
bb11:
  %t50 = load i32, ptr %l28
  %t52 = trunc i64 1 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t55 = load i1, ptr %l23, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t57 = load i32, ptr %l3, !tbaa !23
  %t60 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb16
bb15:
  %t61 = load i1, ptr %l34, !tbaa !21
  store i1 %t61, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t62 = load i1, ptr %l31, !tbaa !21
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t64 = load i32, ptr %l3, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l37
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t68 = load i32, ptr %l37, !tbaa !23
  %t69 = insertvalue { i32, i1 } undef, i32 %t68, 0
  %t70 = insertvalue { i32, i1 } %t69, i1 true, 1
  store { i32, i1 } %t70, ptr %rv
  br label %ret
bb20:
  %t72 = insertvalue { i32, i1 } undef, i32 0, 0
  %t73 = insertvalue { i32, i1 } %t72, i1 false, 1
  store { i32, i1 } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l54 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l66 = alloca i64
  %l69 = alloca i64
  %l88 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l115 = alloca i64
  %l118 = alloca i64
  %l137 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l154 = alloca i64
  %l156 = alloca { i64, ptr }
  %l157 = alloca i64
  %l160 = alloca i64
  %l163 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca i32
  %l176 = alloca { i64, ptr }
  %l191 = alloca i64
  %l194 = alloca i64
  %l213 = alloca { i64, ptr }
  %l220 = alloca i1
  %l222 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l242 = alloca i1
  %l244 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l262 = alloca i64
  %l265 = alloca i64
  %l284 = alloca { i64, ptr }
  %l287 = alloca i1
  %l289 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l308 = alloca { i64, ptr }
  %l310 = alloca i64
  %l313 = alloca i64
  %l318 = alloca i64
  %l322 = alloca i64
  %l325 = alloca i64
  %l344 = alloca i1
  %l348 = alloca { i64, ptr }
  %l353 = alloca i32
  %l357 = alloca i32
  %l363 = alloca ptr
  %l364 = alloca i32
  %l366 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 7
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l47
  br label %bb1
bb1:
  %t11 = load i64, ptr %l47, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 8
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l50
  br label %bb2
bb2:
  %t17 = load i64, ptr %l50, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = load i32, ptr %l1, !tbaa !23
  %t20 = sext i32 %t18 to i64
  store i64 %t20, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/mir:verifier", ptr %t22, i32 0, i32 6
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l54, !tbaa !27
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i1, ptr %t29, i64 %t26
  %t31 = load i1, ptr %t30, !tbaa !31
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/mir:verifier", ptr %t35, i32 0, i32 6
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l59, !tbaa !27
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i1, ptr %t42, i64 %t39
  store i1 true, ptr %t43, !tbaa !31
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/mir:verifier", ptr %t44, i32 0, i32 18
  store i1 true, ptr %t46, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  store i64 %t47, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = icmp sgt i64 %t49, %t50
  br i1 %t53, label %bb5, label %bb6
bb4:
  br label %bb47
bb5:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb10
bb7:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = sub i64 %t59, %t60
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = add i64 %t63, %t64
  %t69 = sub i64 %t67, 1
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = sdiv i64 %t69, %t70
  store i64 %t73, ptr %l69, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb9
bb9:
  %t75 = load i64, ptr %l69, !tbaa !24
  store i64 %t75, ptr %l66, !tbaa !24
  br label %bb10
bb10:
  %t76 = load i64, ptr %l66, !tbaa !24
  store i64 %t76, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t85 = load i64, ptr %l6, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = mul i64 %t86, %t87
  %t93 = add i64 %t85, %t90
  store i64 %t93, ptr %l11, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/mir:verifier", ptr %t95, i32 0, i32 7
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l88, !tbaa !27
  %t99 = load i64, ptr %l5, !tbaa !24
  %t100 = load i64, ptr %l3, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t104 = load i64, ptr %l11, !tbaa !24
  %t107 = add i64 %t103, %t104
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/mir:verifier", ptr %t108, i32 0, i32 14
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l95, !tbaa !27
  %t112 = load i64, ptr %l11, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i1, ptr %t115, i64 %t112
  %t117 = load i1, ptr %t116, !tbaa !31
  %t120 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i1, ptr %t121, i64 %t107
  store i1 %t117, ptr %t122, !tbaa !31
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/mir:verifier", ptr %t123, i32 0, i32 8
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l99, !tbaa !27
  %t127 = load i64, ptr %l5, !tbaa !24
  %t128 = load i64, ptr %l3, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = add i64 %t131, %t132
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/mir:verifier", ptr %t136, i32 0, i32 15
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l106, !tbaa !27
  %t140 = load i64, ptr %l11, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i1, ptr %t143, i64 %t140
  %t145 = load i1, ptr %t144, !tbaa !31
  %t148 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i1, ptr %t149, i64 %t135
  store i1 %t145, ptr %t150, !tbaa !31
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t151 = load i64, ptr %l10, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l10, !tbaa !24
  br label %bb11
bb16:
  store i64 0, ptr %l12, !tbaa !24
  %t155 = load i64, ptr %l4, !tbaa !24
  store i64 %t155, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t157 = load i64, ptr %l13, !tbaa !24
  %t158 = load i64, ptr %l12, !tbaa !24
  %t161 = icmp sgt i64 %t157, %t158
  br i1 %t161, label %bb17, label %bb18
bb17:
  %t163 = load i64, ptr %l14, !tbaa !24
  %t165 = icmp sgt i64 %t163, 0
  br i1 %t165, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb22
bb19:
  %t167 = load i64, ptr %l13, !tbaa !24
  %t168 = load i64, ptr %l12, !tbaa !24
  %t171 = sub i64 %t167, %t168
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = add i64 %t171, %t172
  %t177 = sub i64 %t175, 1
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = sdiv i64 %t177, %t178
  store i64 %t181, ptr %l118, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb21
bb21:
  %t183 = load i64, ptr %l118, !tbaa !24
  store i64 %t183, ptr %l115, !tbaa !24
  br label %bb22
bb22:
  %t184 = load i64, ptr %l115, !tbaa !24
  store i64 %t184, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t185 = load i64, ptr %l16, !tbaa !24
  %t186 = load i64, ptr %l15, !tbaa !24
  %t189 = icmp slt i64 %t185, %t186
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t193 = load i64, ptr %l12, !tbaa !24
  %t194 = load i64, ptr %l16, !tbaa !24
  %t195 = load i64, ptr %l14, !tbaa !24
  %t198 = mul i64 %t194, %t195
  %t201 = add i64 %t193, %t198
  store i64 %t201, ptr %l17, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/mir:verifier", ptr %t203, i32 0, i32 9
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  store { i64, ptr } %t206, ptr %l137, !tbaa !27
  %t207 = load i64, ptr %l5, !tbaa !24
  %t208 = load i64, ptr %l4, !tbaa !24
  %t211 = mul i64 %t207, %t208
  %t212 = load i64, ptr %l17, !tbaa !24
  %t215 = add i64 %t211, %t212
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/mir:verifier", ptr %t216, i32 0, i32 16
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  store { i64, ptr } %t219, ptr %l144, !tbaa !27
  %t220 = load i64, ptr %l17, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i1, ptr %t223, i64 %t220
  %t225 = load i1, ptr %t224, !tbaa !31
  %t228 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i1, ptr %t229, i64 %t215
  store i1 %t225, ptr %t230, !tbaa !31
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  %t231 = load i64, ptr %l16, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l16, !tbaa !24
  br label %bb23
bb28:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/mir:verifier", ptr %t235, i32 0, i32 10
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  store { i64, ptr } %t238, ptr %l150, !tbaa !27
  %t239 = load i64, ptr %l5, !tbaa !24
  store i64 %t239, ptr %l151, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/mir:verifier", ptr %t240, i32 0, i32 12
  %t244 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t242)
  store i64 %t244, ptr %l154
  br label %bb29
bb29:
  %t245 = load i64, ptr %l154, !tbaa !24
  %t246 = load i64, ptr %l151, !tbaa !24
  %t247 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = getelementptr i64, ptr %t248, i64 %t246
  store i64 %t245, ptr %t249, !tbaa !34
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/mir:verifier", ptr %t250, i32 0, i32 11
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  store { i64, ptr } %t253, ptr %l156, !tbaa !27
  %t254 = load i64, ptr %l5, !tbaa !24
  store i64 %t254, ptr %l157, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/mir:verifier", ptr %t255, i32 0, i32 17
  %t259 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t257)
  store i64 %t259, ptr %l160
  br label %bb30
bb30:
  %t260 = load i64, ptr %l160, !tbaa !24
  %t261 = load i64, ptr %l157, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i64, ptr %t263, i64 %t261
  store i64 %t260, ptr %t264, !tbaa !34
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/mir:verifier", ptr %t265, i32 0, i32 17
  store ptr %t267, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t269 = load ptr, ptr %l18, !tbaa !29
  %t270 = load i64, ptr %l19, !tbaa !24
  %t273 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eRunFrom_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t269, i64 %t270)
  %t274 = extractvalue { i32, { i64, ptr } } %t273, 1
  %t275 = extractvalue { i32, { i64, ptr } } %t273, 0
  store i32 %t275, ptr %l167
  %t276 = icmp ne i32 %t275, 0
  br i1 %t276, label %bb33, label %ok.277
ok.277:
  store { i64, ptr } %t274, ptr %l166
  br label %bb32
bb32:
  %t278 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t278, ptr %l163, !tbaa !27
  br label %bb37
bb33:
  %t279 = load i32, ptr %l167, !tbaa !23
  %t280 = ashr i32 %t279, 16
  %t282 = icmp eq i32 %t280, 1
  br i1 %t282, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_e290732eef120a74_d968defd427617c0)
  unreachable
bb36:
  call void @__olang_scope_close(ptr %s9)
  br label %bb46
bb37:
  %t284 = load { i64, ptr }, ptr %l163, !tbaa !27
  store { i64, ptr } %t284, ptr %l20, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t285, 0
  store i64 %t287, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t289 = load i64, ptr %l22, !tbaa !24
  %t290 = load i64, ptr %l21, !tbaa !24
  %t293 = icmp slt i64 %t289, %t290
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s10)
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t297 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t297, ptr %l176, !tbaa !27
  %t298 = load i64, ptr %l22, !tbaa !24
  %t300 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr i32, ptr %t301, i64 %t298
  %t303 = load i32, ptr %t302, !tbaa !33
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/mir:verifier", ptr %t305, i32 0, i32 12
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t307, i32 %t303)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb43
bb43:
  %t311 = load i64, ptr %l22, !tbaa !24
  %t313 = add i64 %t311, 1
  store i64 %t313, ptr %l22, !tbaa !24
  br label %bb38
bb44:
  %t315 = load i64, ptr %l19, !tbaa !24
  %t316 = load i64, ptr %l21, !tbaa !24
  %t319 = add i64 %t315, %t316
  store i64 %t319, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb45
bb45:
  br label %bb31
bb46:
  br label %ret
bb47:
  store i64 0, ptr %l24, !tbaa !24
  %t321 = load i64, ptr %l3, !tbaa !24
  store i64 %t321, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t323 = load i64, ptr %l25, !tbaa !24
  %t324 = load i64, ptr %l24, !tbaa !24
  %t327 = icmp sgt i64 %t323, %t324
  br i1 %t327, label %bb48, label %bb49
bb48:
  %t329 = load i64, ptr %l26, !tbaa !24
  %t331 = icmp sgt i64 %t329, 0
  br i1 %t331, label %bb50, label %bb51
bb49:
  store i64 0, ptr %l191, !tbaa !24
  br label %bb53
bb50:
  %t333 = load i64, ptr %l25, !tbaa !24
  %t334 = load i64, ptr %l24, !tbaa !24
  %t337 = sub i64 %t333, %t334
  %t338 = load i64, ptr %l26, !tbaa !24
  %t341 = add i64 %t337, %t338
  %t343 = sub i64 %t341, 1
  %t344 = load i64, ptr %l26, !tbaa !24
  %t347 = sdiv i64 %t343, %t344
  store i64 %t347, ptr %l194, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l194, !tbaa !24
  br label %bb52
bb52:
  %t349 = load i64, ptr %l194, !tbaa !24
  store i64 %t349, ptr %l191, !tbaa !24
  br label %bb53
bb53:
  %t350 = load i64, ptr %l191, !tbaa !24
  store i64 %t350, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s13
  %t351 = load i64, ptr %l28, !tbaa !24
  %t352 = load i64, ptr %l27, !tbaa !24
  %t355 = icmp slt i64 %t351, %t352
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s13)
  br label %bb71
bb56:
  br label %bb57
bb57:
  %t359 = load i64, ptr %l24, !tbaa !24
  %t360 = load i64, ptr %l28, !tbaa !24
  %t361 = load i64, ptr %l26, !tbaa !24
  %t364 = mul i64 %t360, %t361
  %t367 = add i64 %t359, %t364
  store i64 %t367, ptr %l29, !tbaa !24
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/mir:verifier", ptr %t369, i32 0, i32 7
  %t372 = load { i64, ptr }, ptr %t371, !tbaa !27
  store { i64, ptr } %t372, ptr %l213, !tbaa !27
  %t373 = load i64, ptr %l5, !tbaa !24
  %t374 = load i64, ptr %l3, !tbaa !24
  %t377 = mul i64 %t373, %t374
  %t378 = load i64, ptr %l29, !tbaa !24
  %t381 = add i64 %t377, %t378
  %t383 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !27
  %t385 = getelementptr i1, ptr %t384, i64 %t381
  %t386 = load i1, ptr %t385, !tbaa !31
  br i1 %t386, label %bb58, label %bb59
bb58:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/mir:verifier", ptr %t388, i32 0, i32 14
  %t391 = load { i64, ptr }, ptr %t390, !tbaa !27
  store { i64, ptr } %t391, ptr %l222, !tbaa !27
  %t392 = load i64, ptr %l29, !tbaa !24
  %t394 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !27
  %t396 = getelementptr i1, ptr %t395, i64 %t392
  %t397 = load i1, ptr %t396, !tbaa !31
  %t399 = xor i1 %t397, true
  store i1 %t399, ptr %l220, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb60
bb60:
  %t401 = load i1, ptr %l220, !tbaa !21
  br i1 %t401, label %bb61, label %bb62
bb61:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/mir:verifier", ptr %t402, i32 0, i32 7
  %t405 = load { i64, ptr }, ptr %t404, !tbaa !27
  store { i64, ptr } %t405, ptr %l227, !tbaa !27
  %t406 = load i64, ptr %l5, !tbaa !24
  %t407 = load i64, ptr %l3, !tbaa !24
  %t410 = mul i64 %t406, %t407
  %t411 = load i64, ptr %l29, !tbaa !24
  %t414 = add i64 %t410, %t411
  %t416 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !27
  %t418 = getelementptr i1, ptr %t417, i64 %t414
  store i1 false, ptr %t418, !tbaa !31
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr %"compiler/mir:verifier", ptr %t419, i32 0, i32 18
  store i1 true, ptr %t421, !tbaa !21
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/mir:verifier", ptr %t422, i32 0, i32 8
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  store { i64, ptr } %t425, ptr %l235, !tbaa !27
  %t426 = load i64, ptr %l5, !tbaa !24
  %t427 = load i64, ptr %l3, !tbaa !24
  %t430 = mul i64 %t426, %t427
  %t431 = load i64, ptr %l29, !tbaa !24
  %t434 = add i64 %t430, %t431
  %t436 = getelementptr { i64, ptr }, ptr %l235, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = getelementptr i1, ptr %t437, i64 %t434
  %t439 = load i1, ptr %t438, !tbaa !31
  br i1 %t439, label %bb64, label %bb65
bb64:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/mir:verifier", ptr %t441, i32 0, i32 15
  %t444 = load { i64, ptr }, ptr %t443, !tbaa !27
  store { i64, ptr } %t444, ptr %l244, !tbaa !27
  %t445 = load i64, ptr %l29, !tbaa !24
  %t447 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr i1, ptr %t448, i64 %t445
  %t450 = load i1, ptr %t449, !tbaa !31
  %t452 = xor i1 %t450, true
  store i1 %t452, ptr %l242, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l242, !tbaa !21
  br label %bb66
bb66:
  %t454 = load i1, ptr %l242, !tbaa !21
  br i1 %t454, label %bb67, label %bb68
bb67:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/mir:verifier", ptr %t455, i32 0, i32 8
  %t458 = load { i64, ptr }, ptr %t457, !tbaa !27
  store { i64, ptr } %t458, ptr %l249, !tbaa !27
  %t459 = load i64, ptr %l5, !tbaa !24
  %t460 = load i64, ptr %l3, !tbaa !24
  %t463 = mul i64 %t459, %t460
  %t464 = load i64, ptr %l29, !tbaa !24
  %t467 = add i64 %t463, %t464
  %t469 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !27
  %t471 = getelementptr i1, ptr %t470, i64 %t467
  store i1 false, ptr %t471, !tbaa !31
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/mir:verifier", ptr %t472, i32 0, i32 18
  store i1 true, ptr %t474, !tbaa !21
  br label %bb69
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s13)
  br label %bb70
bb70:
  %t475 = load i64, ptr %l28, !tbaa !24
  %t477 = add i64 %t475, 1
  store i64 %t477, ptr %l28, !tbaa !24
  br label %bb54
bb71:
  store i64 0, ptr %l30, !tbaa !24
  %t479 = load i64, ptr %l4, !tbaa !24
  store i64 %t479, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t481 = load i64, ptr %l31, !tbaa !24
  %t482 = load i64, ptr %l30, !tbaa !24
  %t485 = icmp sgt i64 %t481, %t482
  br i1 %t485, label %bb72, label %bb73
bb72:
  %t487 = load i64, ptr %l32, !tbaa !24
  %t489 = icmp sgt i64 %t487, 0
  br i1 %t489, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l262, !tbaa !24
  br label %bb77
bb74:
  %t491 = load i64, ptr %l31, !tbaa !24
  %t492 = load i64, ptr %l30, !tbaa !24
  %t495 = sub i64 %t491, %t492
  %t496 = load i64, ptr %l32, !tbaa !24
  %t499 = add i64 %t495, %t496
  %t501 = sub i64 %t499, 1
  %t502 = load i64, ptr %l32, !tbaa !24
  %t505 = sdiv i64 %t501, %t502
  store i64 %t505, ptr %l265, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l265, !tbaa !24
  br label %bb76
bb76:
  %t507 = load i64, ptr %l265, !tbaa !24
  store i64 %t507, ptr %l262, !tbaa !24
  br label %bb77
bb77:
  %t508 = load i64, ptr %l262, !tbaa !24
  store i64 %t508, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s18
  %t509 = load i64, ptr %l34, !tbaa !24
  %t510 = load i64, ptr %l33, !tbaa !24
  %t513 = icmp slt i64 %t509, %t510
  %t515 = xor i1 %t513, true
  br i1 %t515, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s18)
  br label %bb89
bb80:
  br label %bb81
bb81:
  %t517 = load i64, ptr %l30, !tbaa !24
  %t518 = load i64, ptr %l34, !tbaa !24
  %t519 = load i64, ptr %l32, !tbaa !24
  %t522 = mul i64 %t518, %t519
  %t525 = add i64 %t517, %t522
  store i64 %t525, ptr %l35, !tbaa !24
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr %"compiler/mir:verifier", ptr %t527, i32 0, i32 16
  %t530 = load { i64, ptr }, ptr %t529, !tbaa !27
  store { i64, ptr } %t530, ptr %l284, !tbaa !27
  %t531 = load i64, ptr %l35, !tbaa !24
  %t533 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t534 = load ptr, ptr %t533, !tbaa !27
  %t535 = getelementptr i1, ptr %t534, i64 %t531
  %t536 = load i1, ptr %t535, !tbaa !31
  br i1 %t536, label %bb82, label %bb83
bb82:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t540 = getelementptr %"compiler/mir:verifier", ptr %t538, i32 0, i32 9
  %t541 = load { i64, ptr }, ptr %t540, !tbaa !27
  store { i64, ptr } %t541, ptr %l289, !tbaa !27
  %t542 = load i64, ptr %l5, !tbaa !24
  %t543 = load i64, ptr %l4, !tbaa !24
  %t546 = mul i64 %t542, %t543
  %t547 = load i64, ptr %l35, !tbaa !24
  %t550 = add i64 %t546, %t547
  %t552 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t553 = load ptr, ptr %t552, !tbaa !27
  %t554 = getelementptr i1, ptr %t553, i64 %t550
  %t555 = load i1, ptr %t554, !tbaa !31
  %t557 = xor i1 %t555, true
  store i1 %t557, ptr %l287, !tbaa !21
  br label %bb84
bb83:
  store i1 false, ptr %l287, !tbaa !21
  br label %bb84
bb84:
  %t559 = load i1, ptr %l287, !tbaa !21
  br i1 %t559, label %bb85, label %bb86
bb85:
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t562 = getelementptr %"compiler/mir:verifier", ptr %t560, i32 0, i32 9
  %t563 = load { i64, ptr }, ptr %t562, !tbaa !27
  store { i64, ptr } %t563, ptr %l298, !tbaa !27
  %t564 = load i64, ptr %l5, !tbaa !24
  %t565 = load i64, ptr %l4, !tbaa !24
  %t568 = mul i64 %t564, %t565
  %t569 = load i64, ptr %l35, !tbaa !24
  %t572 = add i64 %t568, %t569
  %t574 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = getelementptr i1, ptr %t575, i64 %t572
  store i1 true, ptr %t576, !tbaa !31
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t579 = getelementptr %"compiler/mir:verifier", ptr %t577, i32 0, i32 18
  store i1 true, ptr %t579, !tbaa !21
  br label %bb87
bb86:
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s18)
  br label %bb88
bb88:
  %t580 = load i64, ptr %l34, !tbaa !24
  %t582 = add i64 %t580, 1
  store i64 %t582, ptr %l34, !tbaa !24
  br label %bb78
bb89:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t586 = getelementptr %"compiler/mir:verifier", ptr %t584, i32 0, i32 11
  %t587 = load { i64, ptr }, ptr %t586, !tbaa !27
  store { i64, ptr } %t587, ptr %l308, !tbaa !27
  %t588 = load i64, ptr %l5, !tbaa !24
  %t590 = getelementptr { i64, ptr }, ptr %l308, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr i64, ptr %t591, i64 %t588
  %t593 = load i64, ptr %t592, !tbaa !34
  store i64 %t593, ptr %l310, !tbaa !24
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t596 = getelementptr %"compiler/mir:verifier", ptr %t594, i32 0, i32 17
  %t598 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t596)
  store i64 %t598, ptr %l313
  br label %bb90
bb90:
  %t599 = load i64, ptr %l310, !tbaa !24
  %t600 = load i64, ptr %l313, !tbaa !24
  %t601 = icmp eq i64 %t599, %t600
  store i1 %t601, ptr %l36, !tbaa !21
  %t603 = load i1, ptr %l36, !tbaa !21
  br i1 %t603, label %bb91, label %bb92
bb91:
  store i64 0, ptr %l37, !tbaa !24
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t607 = getelementptr %"compiler/mir:verifier", ptr %t605, i32 0, i32 17
  %t609 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t607)
  store i64 %t609, ptr %l318
  br label %bb93
bb92:
  br label %bb111
bb93:
  %t610 = load i64, ptr %l318, !tbaa !24
  store i64 %t610, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t611 = load i64, ptr %l38, !tbaa !24
  %t612 = load i64, ptr %l37, !tbaa !24
  %t615 = icmp sgt i64 %t611, %t612
  br i1 %t615, label %bb94, label %bb95
bb94:
  %t617 = load i64, ptr %l39, !tbaa !24
  %t619 = icmp sgt i64 %t617, 0
  br i1 %t619, label %bb96, label %bb97
bb95:
  store i64 0, ptr %l322, !tbaa !24
  br label %bb99
bb96:
  %t621 = load i64, ptr %l38, !tbaa !24
  %t622 = load i64, ptr %l37, !tbaa !24
  %t625 = sub i64 %t621, %t622
  %t626 = load i64, ptr %l39, !tbaa !24
  %t629 = add i64 %t625, %t626
  %t631 = sub i64 %t629, 1
  %t632 = load i64, ptr %l39, !tbaa !24
  %t635 = sdiv i64 %t631, %t632
  store i64 %t635, ptr %l325, !tbaa !24
  br label %bb98
bb97:
  store i64 0, ptr %l325, !tbaa !24
  br label %bb98
bb98:
  %t637 = load i64, ptr %l325, !tbaa !24
  store i64 %t637, ptr %l322, !tbaa !24
  br label %bb99
bb99:
  %t638 = load i64, ptr %l322, !tbaa !24
  store i64 %t638, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s23
  %t639 = load i64, ptr %l41, !tbaa !24
  %t640 = load i64, ptr %l40, !tbaa !24
  %t643 = icmp slt i64 %t639, %t640
  %t645 = xor i1 %t643, true
  br i1 %t645, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s23)
  br label %bb110
bb102:
  br label %bb103
bb103:
  %t647 = load i64, ptr %l37, !tbaa !24
  %t648 = load i64, ptr %l41, !tbaa !24
  %t649 = load i64, ptr %l39, !tbaa !24
  %t652 = mul i64 %t648, %t649
  %t655 = add i64 %t647, %t652
  store i64 %t655, ptr %l42, !tbaa !24
  %t657 = load i1, ptr %l36, !tbaa !21
  br i1 %t657, label %bb104, label %bb105
bb104:
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t661 = getelementptr %"compiler/mir:verifier", ptr %t659, i32 0, i32 12
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t664 = getelementptr %"compiler/mir:verifier", ptr %t662, i32 0, i32 10
  %t665 = load { i64, ptr }, ptr %t664, !tbaa !27
  store { i64, ptr } %t665, ptr %l348, !tbaa !27
  %t666 = load i64, ptr %l5, !tbaa !24
  %t668 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t669 = load ptr, ptr %t668, !tbaa !27
  %t670 = getelementptr i64, ptr %t669, i64 %t666
  %t671 = load i64, ptr %t670, !tbaa !34
  %t672 = load i64, ptr %l42, !tbaa !24
  %t675 = add i64 %t671, %t672
  %t678 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t661, i64 %t675)
  store i32 %t678, ptr %l353
  br label %bb106
bb105:
  store i1 false, ptr %l344, !tbaa !21
  br label %bb108
bb106:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t681 = getelementptr %"compiler/mir:verifier", ptr %t679, i32 0, i32 17
  %t682 = load i64, ptr %l42, !tbaa !24
  %t685 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t681, i64 %t682)
  store i32 %t685, ptr %l357
  br label %bb107
bb107:
  %t686 = load i32, ptr %l353, !tbaa !23
  %t687 = load i32, ptr %l357, !tbaa !23
  %t688 = icmp eq i32 %t686, %t687
  store i1 %t688, ptr %l344, !tbaa !21
  br label %bb108
bb108:
  %t690 = load i1, ptr %l344, !tbaa !21
  store i1 %t690, ptr %l36, !tbaa !21
  call void @__olang_scope_close(ptr %s23)
  br label %bb109
bb109:
  %t691 = load i64, ptr %l41, !tbaa !24
  %t693 = add i64 %t691, 1
  store i64 %t693, ptr %l41, !tbaa !24
  br label %bb100
bb110:
  br label %bb111
bb111:
  %t695 = load i1, ptr %l36, !tbaa !21
  %t697 = xor i1 %t695, true
  br i1 %t697, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s25
  %t699 = load ptr, ptr %l0, !tbaa !29
  store ptr %t699, ptr %l363, !tbaa !29
  %t700 = load i32, ptr %l1, !tbaa !23
  store i32 %t700, ptr %l364, !tbaa !23
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t703 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %s25, ptr %t701)
  store { i64, ptr } %t703, ptr %l366
  br label %bb114
bb113:
  br label %bb117
bb114:
  %t704 = load ptr, ptr %l0, !tbaa !29
  %t705 = load i32, ptr %l1, !tbaa !23
  %t708 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackOf(ptr %v0, ptr %s25, ptr %t704, i32 %t705)
  store { i64, ptr } %t708, ptr %l369
  br label %bb115
bb115:
  %t709 = extractvalue { i64, ptr } { i64 9, ptr @.d141 }, 1
  %t710 = extractvalue { i64, ptr } { i64 9, ptr @.d141 }, 0
  %t711 = load i32, ptr %l364, !tbaa !23
  %t712 = sext i32 %t711 to i64
  %t713 = call i64 @__olang_fmt_i64(ptr null, i64 %t712)
  %t714 = add i64 %t710, %t713
  %t715 = extractvalue { i64, ptr } { i64 13, ptr @.d142 }, 1
  %t716 = extractvalue { i64, ptr } { i64 13, ptr @.d142 }, 0
  %t717 = add i64 %t714, %t716
  %t718 = load { i64, ptr }, ptr %l366, !tbaa !27
  %t719 = extractvalue { i64, ptr } %t718, 1
  %t720 = extractvalue { i64, ptr } %t718, 0
  %t721 = add i64 %t717, %t720
  %t722 = extractvalue { i64, ptr } { i64 25, ptr @.d143 }, 1
  %t723 = extractvalue { i64, ptr } { i64 25, ptr @.d143 }, 0
  %t724 = add i64 %t721, %t723
  %t725 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t726 = extractvalue { i64, ptr } %t725, 1
  %t727 = extractvalue { i64, ptr } %t725, 0
  %t728 = add i64 %t724, %t727
  %t729 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t728)
  call void @olang_textcopy(ptr %t729, ptr %t709, i64 %t710)
  %t730 = getelementptr i8, ptr %t729, i64 %t710
  %t731 = call i64 @__olang_fmt_i64(ptr %t730, i64 %t712)
  %t732 = getelementptr i8, ptr %t730, i64 %t713
  call void @olang_textcopy(ptr %t732, ptr %t715, i64 %t716)
  %t733 = getelementptr i8, ptr %t732, i64 %t716
  call void @olang_textcopy(ptr %t733, ptr %t719, i64 %t720)
  %t734 = getelementptr i8, ptr %t733, i64 %t720
  call void @olang_textcopy(ptr %t734, ptr %t722, i64 %t723)
  %t735 = getelementptr i8, ptr %t734, i64 %t723
  call void @olang_textcopy(ptr %t735, ptr %t726, i64 %t727)
  %t736 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t737 = insertvalue { i64, ptr } %t736, ptr %t729, 1
  %t739 = extractvalue { i64, ptr } %t737, 0
  %t740 = extractvalue { i64, ptr } %t737, 1
  %t741 = mul i64 %t739, 1
  %t742 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t741)
  call void @llvm.memcpy.p0.p0.i64(ptr %t742, ptr %t740, i64 %t741, i1 false)
  %t743 = insertvalue { i64, ptr } undef, i64 %t739, 0
  %t744 = insertvalue { i64, ptr } %t743, ptr %t742, 1
  %t745 = load ptr, ptr %l363, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s25, ptr %t745, { i64, ptr } %t744)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s25)
  br label %bb117
bb117:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2efieldsOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l20 = alloca i32
  %l24 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i32
  %rv = alloca { i32, i1 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i32, ptr %l12
  store i32 %t17, ptr %l4
  %t18 = load i32, ptr %l4
  %t20 = trunc i64 22 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  %t23 = load i32, ptr %l4
  %t25 = trunc i64 23 to i32
  %t26 = icmp eq i32 %t23, %t25
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l20
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t34 = load i32, ptr %l20, !tbaa !23
  %t35 = insertvalue { i32, i1 } undef, i32 %t34, 0
  %t36 = insertvalue { i32, i1 } %t35, i1 true, 1
  store { i32, i1 } %t36, ptr %rv
  br label %ret
bb9:
  %t38 = load i32, ptr %l4
  %t40 = trunc i64 18 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l28
  br label %bb12
bb11:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb14
bb12:
  %t49 = load ptr, ptr %l25, !tbaa !29
  %t50 = load i32, ptr %l28, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l29
  br label %bb13
bb13:
  %t52 = load i32, ptr %l29
  %t54 = trunc i64 0 to i32
  %t55 = icmp eq i32 %t52, %t54
  store i1 %t55, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l24, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l35
  br label %bb17
bb16:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb18
bb17:
  %t63 = load i1, ptr %l35, !tbaa !21
  store i1 %t63, ptr %l32, !tbaa !21
  br label %bb18
bb18:
  %t64 = load i1, ptr %l32, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l38
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t70 = load i32, ptr %l38, !tbaa !23
  %t71 = insertvalue { i32, i1 } undef, i32 %t70, 0
  %t72 = insertvalue { i32, i1 } %t71, i1 true, 1
  store { i32, i1 } %t72, ptr %rv
  br label %ret
bb22:
  %t74 = insertvalue { i32, i1 } undef, i32 0, 0
  %t75 = insertvalue { i32, i1 } %t74, i1 false, 1
  store { i32, i1 } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i1
  %l19 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i1
  %l56 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t12 = load i32, ptr %l2, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  store i1 %t16, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t22 = load i32, ptr %l2, !tbaa !23
  %t26 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t20, i32 %t21, i32 %t22)
  store i1 %t26, ptr %l19
  br label %bb7
bb7:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = load i32, ptr %l1, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l26
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t40 = load i1, ptr %l26, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb15:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l30
  br label %bb16
bb16:
  %t46 = load i32, ptr %l30
  %t48 = trunc i64 21 to i32
  %t49 = icmp eq i32 %t46, %t48
  store i1 %t49, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t51 = load i1, ptr %l27, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
bb18:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l35
  br label %bb19
bb19:
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l39
  br label %bb22
bb21:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb23
bb22:
  %t63 = load i1, ptr %l39, !tbaa !21
  store i1 %t63, ptr %l36, !tbaa !21
  br label %bb23
bb23:
  %t64 = load i1, ptr %l36, !tbaa !21
  br i1 %t64, label %bb24, label %bb25
bb24:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l42
  br label %bb26
bb25:
  br label %bb34
bb26:
  %t70 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t71 = load i64, ptr %l42, !tbaa !24
  %t73 = or i64 %t71, %t70
  store i64 %t73, ptr %l4, !tbaa !24
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t76 = load i32, ptr %l2, !tbaa !23
  %t79 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l47
  br label %bb27
bb27:
  %t80 = load i64, ptr %l47, !tbaa !24
  store i64 %t80, ptr %l5, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l48, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l51
  br label %bb28
bb28:
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l54
  br label %bb29
bb29:
  %t92 = load ptr, ptr %l48, !tbaa !29
  %t93 = load i32, ptr %l51, !tbaa !23
  %t94 = load i32, ptr %l54, !tbaa !23
  %t95 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t92, i32 %t93, i32 %t94)
  store i1 %t95, ptr %l55
  br label %bb30
bb30:
  %t96 = load i1, ptr %l55, !tbaa !21
  br i1 %t96, label %bb31, label %bb32
bb31:
  %t97 = load i64, ptr %l4, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = or i64 %t97, %t98
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  store i1 %t105, ptr %l56, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb33
bb33:
  %t107 = load i1, ptr %l56, !tbaa !21
  store i1 %t107, ptr %rv
  br label %ret
bb34:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eflow(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca i64
  %l64 = alloca ptr
  %l67 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i64
  %l88 = alloca ptr
  %l89 = alloca i64
  %l94 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca i32
  %l107 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i32
  %l134 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l150 = alloca i64
  %l153 = alloca i64
  %l172 = alloca { i64, ptr }
  %l173 = alloca i64
  %l177 = alloca %"compiler/mir:Local"
  %l189 = alloca i64
  %l192 = alloca i64
  %l211 = alloca { i64, ptr }
  %l228 = alloca i64
  %l231 = alloca i64
  %l250 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 9
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l41
  br label %bb1
bb1:
  %t11 = load i64, ptr %l41, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 7
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l44
  br label %bb2
bb2:
  %t17 = load i64, ptr %l44, !tbaa !24
  store i64 %t17, ptr %l3, !tbaa !24
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/mir:Fn", ptr %t18, i32 0, i32 8
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l47
  br label %bb3
bb3:
  %t23 = load i64, ptr %l47, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l48, !tbaa !29
  %t25 = load i64, ptr %l2, !tbaa !24
  store i64 %t25, ptr %l49, !tbaa !24
  %t26 = load i64, ptr %l49, !tbaa !24
  %t27 = icmp sge i64 %t26, 0
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i64, ptr %l49, !tbaa !24
  %t30 = mul i64 %t29, 1
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t35 = load ptr, ptr %l48, !tbaa !29
  %t36 = getelementptr %"compiler/mir:verifier", ptr %t35, i32 0, i32 6
  store { i64, ptr } %t33, ptr %t36, !tbaa !27
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l52, !tbaa !29
  %t38 = load i64, ptr %l2, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = mul i64 %t38, %t39
  store i64 %t42, ptr %l55, !tbaa !24
  %t43 = load i64, ptr %l55, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  br i1 %t44, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3fc64ab4d22c7cd1_9c9bbb4060ef765d)
  unreachable
bb6:
  %t46 = load i64, ptr %l55, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = load ptr, ptr %l52, !tbaa !29
  %t53 = getelementptr %"compiler/mir:verifier", ptr %t52, i32 0, i32 7
  store { i64, ptr } %t50, ptr %t53, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l58, !tbaa !29
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load i64, ptr %l3, !tbaa !24
  %t59 = mul i64 %t55, %t56
  store i64 %t59, ptr %l61, !tbaa !24
  %t60 = load i64, ptr %l61, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  br i1 %t61, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_82a5970c46c34ec4_64144421b638a2b0)
  unreachable
bb8:
  %t63 = load i64, ptr %l61, !tbaa !24
  %t64 = mul i64 %t63, 1
  %t65 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t69 = load ptr, ptr %l58, !tbaa !29
  %t70 = getelementptr %"compiler/mir:verifier", ptr %t69, i32 0, i32 8
  store { i64, ptr } %t67, ptr %t70, !tbaa !27
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l64, !tbaa !29
  %t72 = load i64, ptr %l2, !tbaa !24
  %t73 = load i64, ptr %l4, !tbaa !24
  %t76 = mul i64 %t72, %t73
  store i64 %t76, ptr %l67, !tbaa !24
  %t77 = load i64, ptr %l67, !tbaa !24
  %t78 = icmp sge i64 %t77, 0
  br i1 %t78, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2ac31f2db6082ba7_5ac69b59325af853)
  unreachable
bb10:
  %t80 = load i64, ptr %l67, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t86 = load ptr, ptr %l64, !tbaa !29
  %t87 = getelementptr %"compiler/mir:verifier", ptr %t86, i32 0, i32 9
  store { i64, ptr } %t84, ptr %t87, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l70, !tbaa !29
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %l71, !tbaa !24
  %t90 = load i64, ptr %l71, !tbaa !24
  %t91 = icmp sge i64 %t90, 0
  br i1 %t91, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_397ae699ba890fb2_f6680c8259f4281e)
  unreachable
bb12:
  %t93 = load i64, ptr %l71, !tbaa !24
  %t94 = icmp sle i64 %t93, 1152921504606846975
  br i1 %t94, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2836fb8ea59de3a5_79eeb5d0a68fc1c9)
  unreachable
bb14:
  %t96 = load i64, ptr %l71, !tbaa !24
  %t97 = mul i64 %t96, 8
  %t98 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = load ptr, ptr %l70, !tbaa !29
  %t103 = getelementptr %"compiler/mir:verifier", ptr %t102, i32 0, i32 10
  store { i64, ptr } %t100, ptr %t103, !tbaa !27
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l75, !tbaa !29
  %t105 = load i64, ptr %l2, !tbaa !24
  store i64 %t105, ptr %l76, !tbaa !24
  %t106 = load i64, ptr %l76, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  br i1 %t107, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2836fb8ea59de3a5_79eeb5d0a68fc1c9)
  unreachable
bb16:
  %t109 = load i64, ptr %l76, !tbaa !24
  %t110 = icmp sle i64 %t109, 1152921504606846975
  br i1 %t110, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_13b0920ad4a1e938_72d556b41507b57c)
  unreachable
bb18:
  %t112 = load i64, ptr %l76, !tbaa !24
  %t113 = mul i64 %t112, 8
  %t114 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t118 = load ptr, ptr %l75, !tbaa !29
  %t119 = getelementptr %"compiler/mir:verifier", ptr %t118, i32 0, i32 11
  store { i64, ptr } %t116, ptr %t119, !tbaa !27
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l80, !tbaa !29
  %t121 = load i64, ptr %l3, !tbaa !24
  store i64 %t121, ptr %l81, !tbaa !24
  %t122 = load i64, ptr %l81, !tbaa !24
  %t123 = icmp sge i64 %t122, 0
  br i1 %t123, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_13b0920ad4a1e938_72d556b41507b57c)
  unreachable
bb20:
  %t125 = load i64, ptr %l81, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t131 = load ptr, ptr %l80, !tbaa !29
  %t132 = getelementptr %"compiler/mir:verifier", ptr %t131, i32 0, i32 14
  store { i64, ptr } %t129, ptr %t132, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l84, !tbaa !29
  %t134 = load i64, ptr %l3, !tbaa !24
  store i64 %t134, ptr %l85, !tbaa !24
  %t135 = load i64, ptr %l85, !tbaa !24
  %t136 = icmp sge i64 %t135, 0
  br i1 %t136, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f0f79482ff998b1b_575016ccefde52df)
  unreachable
bb22:
  %t138 = load i64, ptr %l85, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t144 = load ptr, ptr %l84, !tbaa !29
  %t145 = getelementptr %"compiler/mir:verifier", ptr %t144, i32 0, i32 15
  store { i64, ptr } %t142, ptr %t145, !tbaa !27
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l88, !tbaa !29
  %t147 = load i64, ptr %l4, !tbaa !24
  store i64 %t147, ptr %l89, !tbaa !24
  %t148 = load i64, ptr %l89, !tbaa !24
  %t149 = icmp sge i64 %t148, 0
  br i1 %t149, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a4c79ab2e91ac186_f4797f1baf8f450a)
  unreachable
bb24:
  %t151 = load i64, ptr %l89, !tbaa !24
  %t152 = mul i64 %t151, 1
  %t153 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t152)
  %t154 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  %t157 = load ptr, ptr %l88, !tbaa !29
  %t158 = getelementptr %"compiler/mir:verifier", ptr %t157, i32 0, i32 16
  store { i64, ptr } %t155, ptr %t158, !tbaa !27
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/mir:Fn", ptr %t159, i32 0, i32 4
  store ptr %t161, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2c486f9205676389_1881cd4b4e7e41e5)
  unreachable
bb26:
  store %olang.scope zeroinitializer, ptr %s2
  %t163 = load ptr, ptr %l5, !tbaa !29
  %t164 = load i64, ptr %l6, !tbaa !24
  %t167 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eRunFrom_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t163, i64 %t164)
  %t168 = extractvalue { i32, { i64, ptr } } %t167, 1
  %t169 = extractvalue { i32, { i64, ptr } } %t167, 0
  store i32 %t169, ptr %l98
  %t170 = icmp ne i32 %t169, 0
  br i1 %t170, label %bb28, label %ok.171
ok.171:
  store { i64, ptr } %t168, ptr %l97
  br label %bb27
bb27:
  %t172 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t172, ptr %l94, !tbaa !27
  br label %bb32
bb28:
  %t173 = load i32, ptr %l98, !tbaa !23
  %t174 = ashr i32 %t173, 16
  %t176 = icmp eq i32 %t174, 1
  br i1 %t176, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_76008615ce7bb613_dfc695a1b8c60ec7)
  unreachable
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb32:
  %t178 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t178, ptr %l7, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  store i64 %t181, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s3
  %t183 = load i64, ptr %l9, !tbaa !24
  %t184 = load i64, ptr %l8, !tbaa !24
  %t187 = icmp slt i64 %t183, %t184
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb35:
  br label %bb36
bb36:
  %t191 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t191, ptr %l107, !tbaa !27
  %t192 = load i64, ptr %l9, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i32, ptr %t195, i64 %t192
  %t197 = load i32, ptr %t196, !tbaa !33
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/mir:verifier", ptr %t199, i32 0, i32 14
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  store { i64, ptr } %t202, ptr %l111, !tbaa !27
  %t205 = sext i32 %t197 to i64
  %t207 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr i1, ptr %t208, i64 %t205
  store i1 true, ptr %t209, !tbaa !31
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb37:
  %t210 = load i64, ptr %l9, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l9, !tbaa !24
  br label %bb33
bb38:
  %t214 = load i64, ptr %l6, !tbaa !24
  %t215 = load i64, ptr %l8, !tbaa !24
  %t218 = add i64 %t214, %t215
  store i64 %t218, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb39:
  br label %bb26
bb40:
  %t220 = load ptr, ptr %l1, !tbaa !29
  %t222 = getelementptr %"compiler/mir:Fn", ptr %t220, i32 0, i32 5
  store ptr %t222, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t224 = load ptr, ptr %l11, !tbaa !29
  %t225 = load i64, ptr %l12, !tbaa !24
  %t228 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eRunFrom_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t224, i64 %t225)
  %t229 = extractvalue { i32, { i64, ptr } } %t228, 1
  %t230 = extractvalue { i32, { i64, ptr } } %t228, 0
  store i32 %t230, ptr %l125
  %t231 = icmp ne i32 %t230, 0
  br i1 %t231, label %bb43, label %ok.232
ok.232:
  store { i64, ptr } %t229, ptr %l124
  br label %bb42
bb42:
  %t233 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t233, ptr %l121, !tbaa !27
  br label %bb47
bb43:
  %t234 = load i32, ptr %l125, !tbaa !23
  %t235 = ashr i32 %t234, 16
  %t237 = icmp eq i32 %t235, 1
  br i1 %t237, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_6235ba26342102c9_f7dccacc13d72055)
  unreachable
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb47:
  %t239 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t239, ptr %l13, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t240, 0
  store i64 %t242, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t244 = load i64, ptr %l15, !tbaa !24
  %t245 = load i64, ptr %l14, !tbaa !24
  %t248 = icmp slt i64 %t244, %t245
  %t250 = xor i1 %t248, true
  br i1 %t250, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t252 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t252, ptr %l134, !tbaa !27
  %t253 = load i64, ptr %l15, !tbaa !24
  %t255 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr i32, ptr %t256, i64 %t253
  %t258 = load i32, ptr %t257, !tbaa !33
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/mir:verifier", ptr %t260, i32 0, i32 14
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l138, !tbaa !27
  %t266 = sext i32 %t258 to i64
  %t268 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr i1, ptr %t269, i64 %t266
  store i1 true, ptr %t270, !tbaa !31
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb52:
  %t271 = load i64, ptr %l15, !tbaa !24
  %t273 = add i64 %t271, 1
  store i64 %t273, ptr %l15, !tbaa !24
  br label %bb48
bb53:
  %t275 = load i64, ptr %l12, !tbaa !24
  %t276 = load i64, ptr %l14, !tbaa !24
  %t279 = add i64 %t275, %t276
  store i64 %t279, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb54
bb54:
  br label %bb41
bb55:
  store i64 0, ptr %l17, !tbaa !24
  %t281 = load i64, ptr %l3, !tbaa !24
  store i64 %t281, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t283 = load i64, ptr %l18, !tbaa !24
  %t284 = load i64, ptr %l17, !tbaa !24
  %t287 = icmp sgt i64 %t283, %t284
  br i1 %t287, label %bb56, label %bb57
bb56:
  %t289 = load i64, ptr %l19, !tbaa !24
  %t291 = icmp sgt i64 %t289, 0
  br i1 %t291, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l150, !tbaa !24
  br label %bb61
bb58:
  %t293 = load i64, ptr %l18, !tbaa !24
  %t294 = load i64, ptr %l17, !tbaa !24
  %t297 = sub i64 %t293, %t294
  %t298 = load i64, ptr %l19, !tbaa !24
  %t301 = add i64 %t297, %t298
  %t303 = sub i64 %t301, 1
  %t304 = load i64, ptr %l19, !tbaa !24
  %t307 = sdiv i64 %t303, %t304
  store i64 %t307, ptr %l153, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l153, !tbaa !24
  br label %bb60
bb60:
  %t309 = load i64, ptr %l153, !tbaa !24
  store i64 %t309, ptr %l150, !tbaa !24
  br label %bb61
bb61:
  %t310 = load i64, ptr %l150, !tbaa !24
  store i64 %t310, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t311 = load i64, ptr %l21, !tbaa !24
  %t312 = load i64, ptr %l20, !tbaa !24
  %t315 = icmp slt i64 %t311, %t312
  %t317 = xor i1 %t315, true
  br i1 %t317, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb64:
  br label %bb65
bb65:
  %t319 = load i64, ptr %l17, !tbaa !24
  %t320 = load i64, ptr %l21, !tbaa !24
  %t321 = load i64, ptr %l19, !tbaa !24
  %t324 = mul i64 %t320, %t321
  %t327 = add i64 %t319, %t324
  store i64 %t327, ptr %l22, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/mir:verifier", ptr %t329, i32 0, i32 15
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  store { i64, ptr } %t332, ptr %l172, !tbaa !27
  %t333 = load i64, ptr %l22, !tbaa !24
  store i64 %t333, ptr %l173, !tbaa !24
  %t334 = load ptr, ptr %l1, !tbaa !29
  %t336 = getelementptr %"compiler/mir:Fn", ptr %t334, i32 0, i32 7
  %t337 = load i64, ptr %l22, !tbaa !24
  %t340 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t336, i64 %t337)
  store %"compiler/mir:Local" %t340, ptr %l177
  br label %bb66
bb66:
  %t341 = getelementptr %"compiler/mir:Local", ptr %l177, i32 0, i32 4
  %t342 = load { i64, [1 x i64] }, ptr %t341
  %t344 = extractvalue { i64, [1 x i64] } %t342, 0
  %t345 = icmp eq i64 %t344, 3
  %t347 = load i64, ptr %l173, !tbaa !24
  %t348 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr i1, ptr %t349, i64 %t347
  store i1 %t345, ptr %t350, !tbaa !31
  call void @__olang_scope_close(ptr %s10)
  br label %bb67
bb67:
  %t351 = load i64, ptr %l21, !tbaa !24
  %t353 = add i64 %t351, 1
  store i64 %t353, ptr %l21, !tbaa !24
  br label %bb62
bb68:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/mir:verifier", ptr %t355, i32 0, i32 5
  store i1 false, ptr %t357, !tbaa !21
  %t358 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t358, i32 0)
  br label %bb69
bb69:
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s12
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/mir:verifier", ptr %t360, i32 0, i32 18
  store i1 false, ptr %t362, !tbaa !21
  store i64 0, ptr %l23, !tbaa !24
  %t363 = load i64, ptr %l2, !tbaa !24
  store i64 %t363, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t365 = load i64, ptr %l24, !tbaa !24
  %t366 = load i64, ptr %l23, !tbaa !24
  %t369 = icmp sgt i64 %t365, %t366
  br i1 %t369, label %bb71, label %bb72
bb71:
  %t371 = load i64, ptr %l25, !tbaa !24
  %t373 = icmp sgt i64 %t371, 0
  br i1 %t373, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l189, !tbaa !24
  br label %bb76
bb73:
  %t375 = load i64, ptr %l24, !tbaa !24
  %t376 = load i64, ptr %l23, !tbaa !24
  %t379 = sub i64 %t375, %t376
  %t380 = load i64, ptr %l25, !tbaa !24
  %t383 = add i64 %t379, %t380
  %t385 = sub i64 %t383, 1
  %t386 = load i64, ptr %l25, !tbaa !24
  %t389 = sdiv i64 %t385, %t386
  store i64 %t389, ptr %l192, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l192, !tbaa !24
  br label %bb75
bb75:
  %t391 = load i64, ptr %l192, !tbaa !24
  store i64 %t391, ptr %l189, !tbaa !24
  br label %bb76
bb76:
  %t392 = load i64, ptr %l189, !tbaa !24
  store i64 %t392, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s14
  %t393 = load i64, ptr %l27, !tbaa !24
  %t394 = load i64, ptr %l26, !tbaa !24
  %t397 = icmp slt i64 %t393, %t394
  %t399 = xor i1 %t397, true
  br i1 %t399, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s14)
  br label %bb86
bb79:
  br label %bb80
bb80:
  %t401 = load i64, ptr %l23, !tbaa !24
  %t402 = load i64, ptr %l27, !tbaa !24
  %t403 = load i64, ptr %l25, !tbaa !24
  %t406 = mul i64 %t402, %t403
  %t409 = add i64 %t401, %t406
  store i64 %t409, ptr %l28, !tbaa !24
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/mir:verifier", ptr %t411, i32 0, i32 6
  %t414 = load { i64, ptr }, ptr %t413, !tbaa !27
  store { i64, ptr } %t414, ptr %l211, !tbaa !27
  %t415 = load i64, ptr %l28, !tbaa !24
  %t417 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = getelementptr i1, ptr %t418, i64 %t415
  %t420 = load i1, ptr %t419, !tbaa !31
  br i1 %t420, label %bb81, label %bb82
bb81:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load i64, ptr %l28, !tbaa !24
  %t425 = trunc i64 %t423 to i32
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %t422, i32 %t425)
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s14)
  br label %bb85
bb85:
  %t429 = load i64, ptr %l27, !tbaa !24
  %t431 = add i64 %t429, 1
  store i64 %t431, ptr %l27, !tbaa !24
  br label %bb77
bb86:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/mir:verifier", ptr %t433, i32 0, i32 18
  %t436 = load i1, ptr %t435, !tbaa !21
  %t438 = xor i1 %t436, true
  br i1 %t438, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s12)
  br label %bb91
bb88:
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s12)
  br label %bb90
bb90:
  br label %bb70
bb91:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = getelementptr %"compiler/mir:verifier", ptr %t440, i32 0, i32 5
  store i1 true, ptr %t442, !tbaa !21
  store i64 0, ptr %l29, !tbaa !24
  %t443 = load i64, ptr %l2, !tbaa !24
  store i64 %t443, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t445 = load i64, ptr %l30, !tbaa !24
  %t446 = load i64, ptr %l29, !tbaa !24
  %t449 = icmp sgt i64 %t445, %t446
  br i1 %t449, label %bb92, label %bb93
bb92:
  %t451 = load i64, ptr %l31, !tbaa !24
  %t453 = icmp sgt i64 %t451, 0
  br i1 %t453, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l228, !tbaa !24
  br label %bb97
bb94:
  %t455 = load i64, ptr %l30, !tbaa !24
  %t456 = load i64, ptr %l29, !tbaa !24
  %t459 = sub i64 %t455, %t456
  %t460 = load i64, ptr %l31, !tbaa !24
  %t463 = add i64 %t459, %t460
  %t465 = sub i64 %t463, 1
  %t466 = load i64, ptr %l31, !tbaa !24
  %t469 = sdiv i64 %t465, %t466
  store i64 %t469, ptr %l231, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l231, !tbaa !24
  br label %bb96
bb96:
  %t471 = load i64, ptr %l231, !tbaa !24
  store i64 %t471, ptr %l228, !tbaa !24
  br label %bb97
bb97:
  %t472 = load i64, ptr %l228, !tbaa !24
  store i64 %t472, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s19
  %t473 = load i64, ptr %l33, !tbaa !24
  %t474 = load i64, ptr %l32, !tbaa !24
  %t477 = icmp slt i64 %t473, %t474
  %t479 = xor i1 %t477, true
  br i1 %t479, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s19)
  br label %bb107
bb100:
  br label %bb101
bb101:
  %t481 = load i64, ptr %l29, !tbaa !24
  %t482 = load i64, ptr %l33, !tbaa !24
  %t483 = load i64, ptr %l31, !tbaa !24
  %t486 = mul i64 %t482, %t483
  %t489 = add i64 %t481, %t486
  store i64 %t489, ptr %l34, !tbaa !24
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/mir:verifier", ptr %t491, i32 0, i32 6
  %t494 = load { i64, ptr }, ptr %t493, !tbaa !27
  store { i64, ptr } %t494, ptr %l250, !tbaa !27
  %t495 = load i64, ptr %l34, !tbaa !24
  %t497 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !27
  %t499 = getelementptr i1, ptr %t498, i64 %t495
  %t500 = load i1, ptr %t499, !tbaa !31
  br i1 %t500, label %bb102, label %bb103
bb102:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i64, ptr %l34, !tbaa !24
  %t505 = trunc i64 %t503 to i32
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %t502, i32 %t505)
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s19)
  br label %bb106
bb106:
  %t509 = load i64, ptr %l33, !tbaa !24
  %t511 = add i64 %t509, 1
  store i64 %t511, ptr %l33, !tbaa !24
  br label %bb98
bb107:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t517 = getelementptr %"compiler/mir:verifier", ptr %t513, i32 0, i32 3
  store i64 -1, ptr %t517, !tbaa !24
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t522 = getelementptr %"compiler/mir:verifier", ptr %t518, i32 0, i32 4
  store i64 -1, ptr %t522, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l7, !tbaa !23
  %t12 = icmp ne i32 %t10, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  store { i64, ptr } %a3, ptr %l11, !tbaa !27
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l14
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l17
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } { i64 6, ptr @.d144 }, 1
  %t30 = extractvalue { i64, ptr } { i64 6, ptr @.d144 }, 0
  %t31 = add i64 %t28, %t30
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 8, ptr @.d145 }, 1
  %t37 = extractvalue { i64, ptr } { i64 8, ptr @.d145 }, 0
  %t38 = add i64 %t35, %t37
  %t39 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = add i64 %t38, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t27, i64 %t28)
  %t44 = getelementptr i8, ptr %t43, i64 %t28
  call void @olang_textcopy(ptr %t44, ptr %t29, i64 %t30)
  %t45 = getelementptr i8, ptr %t44, i64 %t30
  call void @olang_textcopy(ptr %t45, ptr %t33, i64 %t34)
  %t46 = getelementptr i8, ptr %t45, i64 %t34
  call void @olang_textcopy(ptr %t46, ptr %t36, i64 %t37)
  %t47 = getelementptr i8, ptr %t46, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t40, i64 %t41)
  %t48 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t43, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } %t49, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  %t57 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t57, { i64, ptr } %t56)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t59 = load i32, ptr %l2, !tbaa !23
  store i32 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l23 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 17
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eRunFrom_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l14
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l13
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6a09071e7826f026_b8c4b46880cabab2)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb7:
  %t20 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 %t34
  %t39 = load i32, ptr %t38, !tbaa !33
  %t45 = icmp eq i32 %t39, %a1
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l6, !tbaa !24
  br label %bb8
bb16:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = add i64 %t52, %t53
  store i64 %t56, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb1
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Range"
  %l7 = alloca i64
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store %"compiler/mir:Range" %a1, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/mir:verifier", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 11
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load %"compiler/mir:Range", ptr %l3
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s0, ptr %t11, %"compiler/mir:Range" %t12, i64 %t13, { i64, ptr } { i64 8, ptr @.d146 })
  store i1 %t14, ptr %l8
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l60 = alloca { i64, [4 x i64] }
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t4, i32 %a2)
  store { i64, ptr } %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t9, ptr %l4, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t13 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t19 = icmp ne i64 %t12, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l20, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t26 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t22, i32 %a1)
  store { i64, ptr } %t26, ptr %l23
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = extractvalue { i64, ptr } { i64 2, ptr @.d147 }, 1
  %t33 = extractvalue { i64, ptr } { i64 2, ptr @.d147 }, 0
  %t34 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 4, ptr @.d148 }, 1
  %t39 = extractvalue { i64, ptr } { i64 4, ptr @.d148 }, 0
  %t40 = add i64 %t37, %t39
  %t42 = call i64 @__olang_fmt_i64(ptr null, i64 %t29)
  %t43 = add i64 %t40, %t42
  %t44 = extractvalue { i64, ptr } { i64 15, ptr @.d149 }, 1
  %t45 = extractvalue { i64, ptr } { i64 15, ptr @.d149 }, 0
  %t46 = add i64 %t43, %t45
  %t48 = sext i32 %t31 to i64
  %t49 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t50 = add i64 %t46, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t32, i64 %t33)
  %t52 = getelementptr i8, ptr %t51, i64 %t33
  call void @olang_textcopy(ptr %t52, ptr %t35, i64 %t36)
  %t53 = getelementptr i8, ptr %t52, i64 %t36
  call void @olang_textcopy(ptr %t53, ptr %t38, i64 %t39)
  %t54 = getelementptr i8, ptr %t53, i64 %t39
  %t55 = call i64 @__olang_fmt_i64(ptr %t54, i64 %t29)
  %t56 = getelementptr i8, ptr %t54, i64 %t42
  call void @olang_textcopy(ptr %t56, ptr %t44, i64 %t45)
  %t57 = getelementptr i8, ptr %t56, i64 %t45
  %t58 = call i64 @__olang_fmt_i64(ptr %t57, i64 %t48)
  %t59 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t51, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = extractvalue { i64, ptr } %t60, 1
  %t64 = mul i64 %t62, 1
  %t65 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t64)
  call void @llvm.memcpy.p0.p0.i64(ptr %t65, ptr %t63, i64 %t64, i1 false)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t68 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t68, { i64, ptr } %t67)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb6:
  store i64 0, ptr %l5, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = icmp sgt i64 %t74, %t75
  br i1 %t78, label %bb7, label %bb8
bb7:
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp sgt i64 %t80, 0
  br i1 %t82, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = sub i64 %t84, %t85
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = add i64 %t88, %t89
  %t94 = sub i64 %t92, 1
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = sdiv i64 %t94, %t95
  store i64 %t98, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t100 = load i64, ptr %l37, !tbaa !24
  store i64 %t100, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t101 = load i64, ptr %l34, !tbaa !24
  store i64 %t101, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t102 = load i64, ptr %l9, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = icmp slt i64 %t102, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t110 = load i64, ptr %l5, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = mul i64 %t111, %t112
  %t118 = add i64 %t110, %t115
  store i64 %t118, ptr %l10, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l55, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l56, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/mir:Range", ptr %l3
  %t124 = load i64, ptr %l10, !tbaa !24
  %t128 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t122, %"compiler/mir:Range" %t123, i64 %t124)
  store { i64, [4 x i64] } %t128, ptr %l60
  br label %bb17
bb17:
  %t129 = load ptr, ptr %l56, !tbaa !29
  %t130 = load { i64, [4 x i64] }, ptr %l60
  %t131 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t129, { i64, [4 x i64] } %t130)
  store i32 %t131, ptr %l61
  br label %bb18
bb18:
  %t132 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t132, ptr %l62, !tbaa !27
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i32, ptr %t136, i64 %t133
  %t138 = load i32, ptr %t137, !tbaa !33
  %t139 = load i64, ptr %l10, !tbaa !24
  %t140 = extractvalue { i64, ptr } { i64 5, ptr @.d150 }, 1
  %t141 = extractvalue { i64, ptr } { i64 5, ptr @.d150 }, 0
  %t143 = call i64 @__olang_fmt_i64(ptr null, i64 %t139)
  %t144 = add i64 %t141, %t143
  %t145 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t140, i64 %t141)
  %t146 = getelementptr i8, ptr %t145, i64 %t141
  %t147 = call i64 @__olang_fmt_i64(ptr %t146, i64 %t139)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t145, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = extractvalue { i64, ptr } %t149, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t157 = load ptr, ptr %l55, !tbaa !29
  %t158 = load i32, ptr %l61, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s4, ptr %t157, i32 %t158, i32 %t138, { i64, ptr } %t156)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t161 = load i64, ptr %l9, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l9, !tbaa !24
  br label %bb13
bb21:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprimType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l16 = alloca { i32, i1 }
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca i32
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca i32
  %l69 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l79 = alloca { i64, [4 x i64] }
  %l80 = alloca i32
  %l87 = alloca i32
  %l102 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i32
  %l107 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l129 = alloca i1
  %l131 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i32
  %l138 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l156 = alloca i1
  %l158 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l164 = alloca { i64, [4 x i64] }
  %l165 = alloca i32
  %l166 = alloca i32
  %l167 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i32
  %l172 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l183 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i32
  %l188 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l204 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l226 = alloca ptr
  %l229 = alloca { i64, [4 x i64] }
  %l230 = alloca i32
  %l231 = alloca ptr
  %l232 = alloca i32
  %l235 = alloca i32
  %l236 = alloca i1
  %l238 = alloca ptr
  %l239 = alloca i32
  %l241 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l254 = alloca i1
  %l256 = alloca i1
  %l260 = alloca i1
  %l264 = alloca i1
  %l268 = alloca ptr
  %l269 = alloca i32
  %l271 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l282 = alloca ptr
  %l283 = alloca i32
  %l285 = alloca { i64, ptr }
  %l287 = alloca { i64, ptr }
  %l290 = alloca { i64, ptr }
  %l295 = alloca ptr
  %l298 = alloca { i64, [4 x i64] }
  %l299 = alloca i32
  %l302 = alloca i32
  %l305 = alloca i32
  %l309 = alloca i1
  %l312 = alloca i1
  %l315 = alloca i1
  %l316 = alloca ptr
  %l319 = alloca i32
  %l322 = alloca i32
  %l323 = alloca i1
  %l327 = alloca i1
  %l331 = alloca i1
  %l334 = alloca ptr
  %l337 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l346 = alloca ptr
  %l349 = alloca { i64, ptr }
  %l360 = alloca i1
  %l361 = alloca i32
  %l364 = alloca i32
  %l368 = alloca i32
  %l371 = alloca ptr
  %l374 = alloca { i64, ptr }
  %l380 = alloca ptr
  %l383 = alloca { i64, ptr }
  %l390 = alloca i1
  %l391 = alloca i32
  %l394 = alloca i32
  %l398 = alloca i32
  %l401 = alloca ptr
  %l404 = alloca { i64, ptr }
  %l410 = alloca ptr
  %l413 = alloca { i64, ptr }
  %l420 = alloca { i32, i1 }
  %l424 = alloca ptr
  %l427 = alloca { i64, ptr }
  %l433 = alloca ptr
  %l436 = alloca { i64, ptr }
  %l441 = alloca i1
  %l443 = alloca i1
  %l444 = alloca ptr
  %l445 = alloca ptr
  %l448 = alloca i32
  %l449 = alloca i32
  %l450 = alloca i1
  %l452 = alloca i1
  %l455 = alloca i64
  %l459 = alloca ptr
  %l460 = alloca i32
  %l462 = alloca { i64, ptr }
  %l464 = alloca { i64, ptr }
  %l467 = alloca { i64, ptr }
  %l472 = alloca i32
  %l477 = alloca i64
  %l480 = alloca i64
  %l498 = alloca ptr
  %l499 = alloca ptr
  %l503 = alloca { i64, [4 x i64] }
  %l504 = alloca i32
  %l505 = alloca i32
  %l506 = alloca i32
  %l508 = alloca { i64, ptr }
  %l510 = alloca { i64, ptr }
  %l521 = alloca ptr
  %l524 = alloca { i64, ptr }
  %l530 = alloca i1
  %l532 = alloca ptr
  %l533 = alloca i32
  %l535 = alloca { i64, ptr }
  %l537 = alloca { i64, ptr }
  %l540 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.builder
  %s15room = alloca [64 x i8], align 8
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.builder
  %s19room = alloca [64 x i8], align 8
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.builder
  %s23room = alloca [64 x i8], align 8
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.builder
  %s26room = alloca [64 x i8], align 8
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.builder
  %s33room = alloca [64 x i8], align 8
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.builder
  %s36room = alloca [64 x i8], align 8
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.builder
  %s39room = alloca [64 x i8], align 8
  %s43 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s59 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s64 = alloca %olang.scope
  %s65 = alloca %olang.builder
  %s65room = alloca [64 x i8], align 8
  %s69 = alloca %olang.scope
  %s70 = alloca %olang.builder
  %s70room = alloca [64 x i8], align 8
  %s74 = alloca %olang.scope
  %s77 = alloca %olang.scope
  %s78 = alloca %olang.builder
  %s78room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  store i64 %t9, ptr %l5, !tbaa !24
  %t11 = load i32, ptr %l1
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb1, label %bb2
bb1:
  br label %bb11
bb2:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 1 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 2 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  %t26 = load i32, ptr %l1
  %t28 = trunc i64 20 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t31 = load i32, ptr %l1
  %t33 = trunc i64 21 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 1, ptr %l29, !tbaa !24
  br label %bb35
bb12:
  %t36 = load i32, ptr %l1
  %t38 = trunc i64 22 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  %t41 = load i32, ptr %l1
  %t43 = trunc i64 26 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  %t46 = load i32, ptr %l1
  %t48 = trunc i64 31 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 1, ptr %l29, !tbaa !24
  br label %bb35
bb20:
  %t51 = load i32, ptr %l1
  %t53 = trunc i64 24 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  %t56 = load i32, ptr %l1
  %t58 = trunc i64 25 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb35
bb26:
  %t61 = load i32, ptr %l1
  %t63 = trunc i64 30 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i64 3, ptr %l29, !tbaa !24
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i64 2, ptr %l29, !tbaa !24
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d0c28dbd82f4c36a_9dd446291f7ee706)
  unreachable
bb35:
  %t66 = load i64, ptr %l29, !tbaa !24
  store i64 %t66, ptr %l6, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t69 = icmp slt i64 %t67, 0
  br i1 %t69, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l54, !tbaa !29
  %t72 = load i32, ptr %l1
  store i32 %t72, ptr %l55
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s7, ptr %l55, i64 0)
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t74 = load ptr, ptr %s7
  %t75 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t76 = load i64, ptr %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t74, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l57, !tbaa !27
  %t80 = getelementptr %olang.builder, ptr %s7, i32 0, i32 3
  %t81 = load ptr, ptr %t80
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %sbgrew.83, label %sbdone.84
sbgrew.83:
  call void @__olang_sb_done(ptr %s7)
  br label %sbdone.84
sbdone.84:
  %t85 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s6, { i64, ptr } %t91)
  store { i64, ptr } %t93, ptr %l59
  br label %bb39
bb39:
  %t94 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = extractvalue { i64, ptr } { i64 39, ptr @.d151 }, 1
  %t98 = extractvalue { i64, ptr } { i64 39, ptr @.d151 }, 0
  %t99 = add i64 %t96, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t95, i64 %t96)
  %t101 = getelementptr i8, ptr %t100, i64 %t96
  call void @olang_textcopy(ptr %t101, ptr %t97, i64 %t98)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = extractvalue { i64, ptr } %t103, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t111 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s6, ptr %t111, { i64, ptr } %t110)
  br label %bb40
bb40:
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  store i32 %t113, ptr %rv
  br label %ret
bb41:
  %t115 = load i64, ptr %l5, !tbaa !24
  %t116 = load i64, ptr %l6, !tbaa !24
  %t119 = icmp ne i64 %t115, %t116
  br i1 %t119, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s9
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l66, !tbaa !29
  %t122 = load i32, ptr %l1
  store i32 %t122, ptr %l67
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s10, ptr %l67, i64 0)
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t124 = load ptr, ptr %s10
  %t125 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t126 = load i64, ptr %t125
  %t127 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t126)
  call void @olang_textcopy(ptr %t127, ptr %t124, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l69, !tbaa !27
  %t130 = getelementptr %olang.builder, ptr %s10, i32 0, i32 3
  %t131 = load ptr, ptr %t130
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %sbgrew.133, label %sbdone.134
sbgrew.133:
  call void @__olang_sb_done(ptr %s10)
  br label %sbdone.134
sbdone.134:
  %t135 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = mul i64 %t136, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t143 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s9, { i64, ptr } %t141)
  store { i64, ptr } %t143, ptr %l71
  br label %bb45
bb45:
  %t144 = load i64, ptr %l5, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } { i64 4, ptr @.d152 }, 1
  %t149 = extractvalue { i64, ptr } { i64 4, ptr @.d152 }, 0
  %t150 = add i64 %t147, %t149
  %t152 = call i64 @__olang_fmt_i64(ptr null, i64 %t144)
  %t153 = add i64 %t150, %t152
  %t154 = extractvalue { i64, ptr } { i64 9, ptr @.d153 }, 1
  %t155 = extractvalue { i64, ptr } { i64 9, ptr @.d153 }, 0
  %t156 = add i64 %t153, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t146, i64 %t147)
  %t158 = getelementptr i8, ptr %t157, i64 %t147
  call void @olang_textcopy(ptr %t158, ptr %t148, i64 %t149)
  %t159 = getelementptr i8, ptr %t158, i64 %t149
  %t160 = call i64 @__olang_fmt_i64(ptr %t159, i64 %t144)
  %t161 = getelementptr i8, ptr %t159, i64 %t152
  call void @olang_textcopy(ptr %t161, ptr %t154, i64 %t155)
  %t162 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t157, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  %t171 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s9, ptr %t171, { i64, ptr } %t170)
  br label %bb46
bb46:
  %t173 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  store i32 %t173, ptr %rv
  br label %ret
bb47:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l76, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load %"compiler/mir:Range", ptr %l3
  %t180 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t176, %"compiler/mir:Range" %t177, i64 0)
  store { i64, [4 x i64] } %t180, ptr %l79
  br label %bb48
bb48:
  %t181 = load ptr, ptr %l76, !tbaa !29
  %t182 = load { i64, [4 x i64] }, ptr %l79
  %t183 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t181, { i64, [4 x i64] } %t182)
  store i32 %t183, ptr %l80
  br label %bb49
bb49:
  %t184 = load i32, ptr %l80, !tbaa !23
  store i32 %t184, ptr %l7, !tbaa !23
  %t185 = load i32, ptr %l7, !tbaa !23
  %t186 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t189 = icmp eq i32 %t185, %t186
  br i1 %t189, label %bb50, label %bb51
bb50:
  %t191 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t191, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t193 = load ptr, ptr %l4, !tbaa !29
  %t194 = load i32, ptr %l7, !tbaa !23
  %t197 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t193, i32 %t194)
  store i32 %t197, ptr %l87
  br label %bb53
bb53:
  %t198 = load i32, ptr %l87, !tbaa !23
  store i32 %t198, ptr %l8, !tbaa !23
  %t199 = load i32, ptr %l1
  %t201 = trunc i64 0 to i32
  %t202 = icmp eq i32 %t199, %t201
  br i1 %t202, label %bb54, label %bb55
bb54:
  br label %bb66
bb55:
  %t204 = load i32, ptr %l1
  %t206 = trunc i64 3 to i32
  %t207 = icmp eq i32 %t204, %t206
  br i1 %t207, label %bb56, label %bb57
bb56:
  br label %bb66
bb57:
  %t209 = load i32, ptr %l1
  %t211 = trunc i64 4 to i32
  %t212 = icmp eq i32 %t209, %t211
  br i1 %t212, label %bb58, label %bb59
bb58:
  br label %bb66
bb59:
  %t214 = load i32, ptr %l1
  %t216 = trunc i64 5 to i32
  %t217 = icmp eq i32 %t214, %t216
  br i1 %t217, label %bb60, label %bb61
bb60:
  br label %bb66
bb61:
  %t219 = load i32, ptr %l1
  %t221 = trunc i64 6 to i32
  %t222 = icmp eq i32 %t219, %t221
  br i1 %t222, label %bb62, label %bb63
bb62:
  br label %bb66
bb63:
  %t224 = load i32, ptr %l1
  %t226 = trunc i64 7 to i32
  %t227 = icmp eq i32 %t224, %t226
  br i1 %t227, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb76
bb66:
  %t229 = load ptr, ptr %l4, !tbaa !29
  %t230 = load i32, ptr %l8, !tbaa !23
  %t233 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t229, i32 %t230)
  store i1 %t233, ptr %l102
  br label %bb67
bb67:
  %t234 = load i1, ptr %l102, !tbaa !21
  %t235 = xor i1 %t234, true
  br i1 %t235, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s14
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l104, !tbaa !29
  %t238 = load i32, ptr %l1
  store i32 %t238, ptr %l105
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s15
  store ptr %s15room, ptr %s15
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s15, ptr %l105, i64 0)
  br label %bb70
bb69:
  br label %bb74
bb70:
  %t240 = load ptr, ptr %s15
  %t241 = getelementptr %olang.builder, ptr %s15, i32 0, i32 1
  %t242 = load i64, ptr %t241
  %t243 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t242)
  call void @olang_textcopy(ptr %t243, ptr %t240, i64 %t242)
  %t244 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  store { i64, ptr } %t245, ptr %l107, !tbaa !27
  %t246 = getelementptr %olang.builder, ptr %s15, i32 0, i32 3
  %t247 = load ptr, ptr %t246
  %t248 = icmp ne ptr %t247, null
  br i1 %t248, label %sbgrew.249, label %sbdone.250
sbgrew.249:
  call void @__olang_sb_done(ptr %s15)
  br label %sbdone.250
sbdone.250:
  %t251 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t253 = extractvalue { i64, ptr } %t251, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  %t259 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s14, { i64, ptr } %t257)
  store { i64, ptr } %t259, ptr %l109
  br label %bb71
bb71:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load i32, ptr %l7, !tbaa !23
  %t264 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s14, ptr %t260, i32 %t261)
  store { i64, ptr } %t264, ptr %l112
  br label %bb72
bb72:
  %t265 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = extractvalue { i64, ptr } { i64 6, ptr @.d154 }, 1
  %t269 = extractvalue { i64, ptr } { i64 6, ptr @.d154 }, 0
  %t270 = add i64 %t267, %t269
  %t271 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = add i64 %t270, %t273
  %t275 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t274)
  call void @olang_textcopy(ptr %t275, ptr %t266, i64 %t267)
  %t276 = getelementptr i8, ptr %t275, i64 %t267
  call void @olang_textcopy(ptr %t276, ptr %t268, i64 %t269)
  %t277 = getelementptr i8, ptr %t276, i64 %t269
  call void @olang_textcopy(ptr %t277, ptr %t272, i64 %t273)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t275, 1
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t282 = extractvalue { i64, ptr } %t279, 1
  %t283 = mul i64 %t281, 1
  %t284 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t284, ptr %t282, i64 %t283, i1 false)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t284, 1
  %t287 = load ptr, ptr %l104, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s14, ptr %t287, { i64, ptr } %t286)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s14)
  br label %bb74
bb74:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i32, ptr %l1
  %t291 = load %"compiler/mir:Range", ptr %l3
  %t292 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %t289, i32 %t290, %"compiler/mir:Range" %t291, i32 %t292)
  br label %bb75
bb75:
  br label %bb342
bb76:
  %t297 = load i32, ptr %l1
  %t299 = trunc i64 1 to i32
  %t300 = icmp eq i32 %t297, %t299
  br i1 %t300, label %bb77, label %bb78
bb77:
  br label %bb85
bb78:
  %t302 = load i32, ptr %l1
  %t304 = trunc i64 10 to i32
  %t305 = icmp eq i32 %t302, %t304
  br i1 %t305, label %bb79, label %bb80
bb79:
  br label %bb85
bb80:
  %t307 = load i32, ptr %l1
  %t309 = trunc i64 11 to i32
  %t310 = icmp eq i32 %t307, %t309
  br i1 %t310, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  %t312 = load i32, ptr %l1
  %t314 = trunc i64 12 to i32
  %t315 = icmp eq i32 %t312, %t314
  br i1 %t315, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb98
bb85:
  %t317 = load ptr, ptr %l4, !tbaa !29
  %t318 = load i32, ptr %l8, !tbaa !23
  %t321 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t317, i32 %t318)
  store i1 %t321, ptr %l129
  br label %bb86
bb86:
  %t322 = load i1, ptr %l129, !tbaa !21
  %t323 = xor i1 %t322, true
  br i1 %t323, label %bb87, label %bb88
bb87:
  %t325 = load i32, ptr %l8, !tbaa !23
  %t326 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t329 = icmp ne i32 %t325, %t326
  store i1 %t329, ptr %l131, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb89
bb89:
  %t331 = load i1, ptr %l131, !tbaa !21
  br i1 %t331, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s18
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l135, !tbaa !29
  %t333 = load i32, ptr %l1
  store i32 %t333, ptr %l136
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s19
  store ptr %s19room, ptr %s19
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s19, ptr %l136, i64 0)
  br label %bb92
bb91:
  br label %bb96
bb92:
  %t335 = load ptr, ptr %s19
  %t336 = getelementptr %olang.builder, ptr %s19, i32 0, i32 1
  %t337 = load i64, ptr %t336
  %t338 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t337)
  call void @olang_textcopy(ptr %t338, ptr %t335, i64 %t337)
  %t339 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  store { i64, ptr } %t340, ptr %l138, !tbaa !27
  %t341 = getelementptr %olang.builder, ptr %s19, i32 0, i32 3
  %t342 = load ptr, ptr %t341
  %t343 = icmp ne ptr %t342, null
  br i1 %t343, label %sbgrew.344, label %sbdone.345
sbgrew.344:
  call void @__olang_sb_done(ptr %s19)
  br label %sbdone.345
sbdone.345:
  %t346 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t346, 0
  %t348 = extractvalue { i64, ptr } %t346, 1
  %t349 = mul i64 %t347, 1
  %t350 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t349)
  call void @llvm.memcpy.p0.p0.i64(ptr %t350, ptr %t348, i64 %t349, i1 false)
  %t351 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t350, 1
  %t354 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s18, { i64, ptr } %t352)
  store { i64, ptr } %t354, ptr %l140
  br label %bb93
bb93:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i32, ptr %l7, !tbaa !23
  %t359 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s18, ptr %t355, i32 %t356)
  store { i64, ptr } %t359, ptr %l143
  br label %bb94
bb94:
  %t360 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t360, 1
  %t362 = extractvalue { i64, ptr } %t360, 0
  %t363 = extractvalue { i64, ptr } { i64 6, ptr @.d155 }, 1
  %t364 = extractvalue { i64, ptr } { i64 6, ptr @.d155 }, 0
  %t365 = add i64 %t362, %t364
  %t366 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 1
  %t368 = extractvalue { i64, ptr } %t366, 0
  %t369 = add i64 %t365, %t368
  %t370 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t369)
  call void @olang_textcopy(ptr %t370, ptr %t361, i64 %t362)
  %t371 = getelementptr i8, ptr %t370, i64 %t362
  call void @olang_textcopy(ptr %t371, ptr %t363, i64 %t364)
  %t372 = getelementptr i8, ptr %t371, i64 %t364
  call void @olang_textcopy(ptr %t372, ptr %t367, i64 %t368)
  %t373 = insertvalue { i64, ptr } undef, i64 %t369, 0
  %t374 = insertvalue { i64, ptr } %t373, ptr %t370, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = extractvalue { i64, ptr } %t374, 1
  %t378 = mul i64 %t376, 1
  %t379 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t378)
  call void @llvm.memcpy.p0.p0.i64(ptr %t379, ptr %t377, i64 %t378, i1 false)
  %t380 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t379, 1
  %t382 = load ptr, ptr %l135, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s18, ptr %t382, { i64, ptr } %t381)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s18)
  br label %bb96
bb96:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i32, ptr %l1
  %t386 = load %"compiler/mir:Range", ptr %l3
  %t387 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %t384, i32 %t385, %"compiler/mir:Range" %t386, i32 %t387)
  br label %bb97
bb97:
  br label %bb342
bb98:
  %t392 = load i32, ptr %l1
  %t394 = trunc i64 8 to i32
  %t395 = icmp eq i32 %t392, %t394
  br i1 %t395, label %bb99, label %bb100
bb99:
  br label %bb103
bb100:
  %t397 = load i32, ptr %l1
  %t399 = trunc i64 9 to i32
  %t400 = icmp eq i32 %t397, %t399
  br i1 %t400, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb128
bb103:
  %t402 = load ptr, ptr %l4, !tbaa !29
  %t403 = load i32, ptr %l8, !tbaa !23
  %t406 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t402, i32 %t403)
  store i1 %t406, ptr %l156
  br label %bb104
bb104:
  %t407 = load i1, ptr %l156, !tbaa !21
  %t408 = xor i1 %t407, true
  br i1 %t408, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l158, !tbaa !21
  br label %bb111
bb106:
  %t410 = load ptr, ptr %l4, !tbaa !29
  store ptr %t410, ptr %l159, !tbaa !29
  %t411 = load ptr, ptr %l4, !tbaa !29
  store ptr %t411, ptr %l160, !tbaa !29
  %t412 = load ptr, ptr %l0, !tbaa !29
  store ptr %t412, ptr %l161, !tbaa !29
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load %"compiler/mir:Range", ptr %l3
  %t417 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t413, %"compiler/mir:Range" %t414, i64 1)
  store { i64, [4 x i64] } %t417, ptr %l164
  br label %bb107
bb107:
  %t418 = load ptr, ptr %l161, !tbaa !29
  %t419 = load { i64, [4 x i64] }, ptr %l164
  %t420 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t418, { i64, [4 x i64] } %t419)
  store i32 %t420, ptr %l165
  br label %bb108
bb108:
  %t421 = load ptr, ptr %l160, !tbaa !29
  %t422 = load i32, ptr %l165, !tbaa !23
  %t423 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t421, i32 %t422)
  store i32 %t423, ptr %l166
  br label %bb109
bb109:
  %t424 = load ptr, ptr %l159, !tbaa !29
  %t425 = load i32, ptr %l166, !tbaa !23
  %t426 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t424, i32 %t425)
  store i1 %t426, ptr %l167
  br label %bb110
bb110:
  %t427 = load i1, ptr %l167, !tbaa !21
  %t428 = xor i1 %t427, true
  store i1 %t428, ptr %l158, !tbaa !21
  br label %bb111
bb111:
  %t430 = load i1, ptr %l158, !tbaa !21
  br i1 %t430, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s22
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l169, !tbaa !29
  %t432 = load i32, ptr %l1
  store i32 %t432, ptr %l170
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s23
  store ptr %s23room, ptr %s23
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s23, ptr %l170, i64 0)
  br label %bb114
bb113:
  br label %bb118
bb114:
  %t434 = load ptr, ptr %s23
  %t435 = getelementptr %olang.builder, ptr %s23, i32 0, i32 1
  %t436 = load i64, ptr %t435
  %t437 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t436)
  call void @olang_textcopy(ptr %t437, ptr %t434, i64 %t436)
  %t438 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t437, 1
  store { i64, ptr } %t439, ptr %l172, !tbaa !27
  %t440 = getelementptr %olang.builder, ptr %s23, i32 0, i32 3
  %t441 = load ptr, ptr %t440
  %t442 = icmp ne ptr %t441, null
  br i1 %t442, label %sbgrew.443, label %sbdone.444
sbgrew.443:
  call void @__olang_sb_done(ptr %s23)
  br label %sbdone.444
sbdone.444:
  %t445 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t445, 0
  %t447 = extractvalue { i64, ptr } %t445, 1
  %t448 = mul i64 %t446, 1
  %t449 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t448)
  call void @llvm.memcpy.p0.p0.i64(ptr %t449, ptr %t447, i64 %t448, i1 false)
  %t450 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t449, 1
  %t453 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s22, { i64, ptr } %t451)
  store { i64, ptr } %t453, ptr %l174
  br label %bb115
bb115:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load i32, ptr %l7, !tbaa !23
  %t458 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s22, ptr %t454, i32 %t455)
  store { i64, ptr } %t458, ptr %l177
  br label %bb116
bb116:
  %t459 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t459, 1
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t462 = extractvalue { i64, ptr } { i64 6, ptr @.d156 }, 1
  %t463 = extractvalue { i64, ptr } { i64 6, ptr @.d156 }, 0
  %t464 = add i64 %t461, %t463
  %t465 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 1
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t468 = add i64 %t464, %t467
  %t469 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t468)
  call void @olang_textcopy(ptr %t469, ptr %t460, i64 %t461)
  %t470 = getelementptr i8, ptr %t469, i64 %t461
  call void @olang_textcopy(ptr %t470, ptr %t462, i64 %t463)
  %t471 = getelementptr i8, ptr %t470, i64 %t463
  call void @olang_textcopy(ptr %t471, ptr %t466, i64 %t467)
  %t472 = insertvalue { i64, ptr } undef, i64 %t468, 0
  %t473 = insertvalue { i64, ptr } %t472, ptr %t469, 1
  %t475 = extractvalue { i64, ptr } %t473, 0
  %t476 = extractvalue { i64, ptr } %t473, 1
  %t477 = mul i64 %t475, 1
  %t478 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t477)
  call void @llvm.memcpy.p0.p0.i64(ptr %t478, ptr %t476, i64 %t477, i1 false)
  %t479 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t478, 1
  %t481 = load ptr, ptr %l169, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s22, ptr %t481, { i64, ptr } %t480)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s22)
  br label %bb118
bb118:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load i32, ptr %l7, !tbaa !23
  %t485 = load i32, ptr %l2, !tbaa !23
  %t489 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t483, i32 %t484, i32 %t485)
  store i1 %t489, ptr %l183
  br label %bb119
bb119:
  %t490 = load i1, ptr %l183, !tbaa !21
  %t491 = xor i1 %t490, true
  br i1 %t491, label %bb120, label %bb121
bb120:
  store %olang.scope zeroinitializer, ptr %s25
  %t493 = load ptr, ptr %l0, !tbaa !29
  store ptr %t493, ptr %l185, !tbaa !29
  %t494 = load i32, ptr %l1
  store i32 %t494, ptr %l186
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s26
  store ptr %s26room, ptr %s26
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s26, ptr %l186, i64 0)
  br label %bb122
bb121:
  br label %bb127
bb122:
  %t496 = load ptr, ptr %s26
  %t497 = getelementptr %olang.builder, ptr %s26, i32 0, i32 1
  %t498 = load i64, ptr %t497
  %t499 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t498)
  call void @olang_textcopy(ptr %t499, ptr %t496, i64 %t498)
  %t500 = insertvalue { i64, ptr } undef, i64 %t498, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t499, 1
  store { i64, ptr } %t501, ptr %l188, !tbaa !27
  %t502 = getelementptr %olang.builder, ptr %s26, i32 0, i32 3
  %t503 = load ptr, ptr %t502
  %t504 = icmp ne ptr %t503, null
  br i1 %t504, label %sbgrew.505, label %sbdone.506
sbgrew.505:
  call void @__olang_sb_done(ptr %s26)
  br label %sbdone.506
sbdone.506:
  %t507 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t508 = extractvalue { i64, ptr } %t507, 0
  %t509 = extractvalue { i64, ptr } %t507, 1
  %t510 = mul i64 %t508, 1
  %t511 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t509, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  %t515 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s25, { i64, ptr } %t513)
  store { i64, ptr } %t515, ptr %l190
  br label %bb123
bb123:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load i32, ptr %l7, !tbaa !23
  %t520 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s25, ptr %t516, i32 %t517)
  store { i64, ptr } %t520, ptr %l193
  br label %bb124
bb124:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load i32, ptr %l2, !tbaa !23
  %t525 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s25, ptr %t521, i32 %t522)
  store { i64, ptr } %t525, ptr %l196
  br label %bb125
bb125:
  %t526 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t527 = extractvalue { i64, ptr } %t526, 1
  %t528 = extractvalue { i64, ptr } %t526, 0
  %t529 = extractvalue { i64, ptr } { i64 6, ptr @.d157 }, 1
  %t530 = extractvalue { i64, ptr } { i64 6, ptr @.d157 }, 0
  %t531 = add i64 %t528, %t530
  %t532 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t532, 1
  %t534 = extractvalue { i64, ptr } %t532, 0
  %t535 = add i64 %t531, %t534
  %t536 = extractvalue { i64, ptr } { i64 7, ptr @.d158 }, 1
  %t537 = extractvalue { i64, ptr } { i64 7, ptr @.d158 }, 0
  %t538 = add i64 %t535, %t537
  %t539 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t539, 1
  %t541 = extractvalue { i64, ptr } %t539, 0
  %t542 = add i64 %t538, %t541
  %t543 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t542)
  call void @olang_textcopy(ptr %t543, ptr %t527, i64 %t528)
  %t544 = getelementptr i8, ptr %t543, i64 %t528
  call void @olang_textcopy(ptr %t544, ptr %t529, i64 %t530)
  %t545 = getelementptr i8, ptr %t544, i64 %t530
  call void @olang_textcopy(ptr %t545, ptr %t533, i64 %t534)
  %t546 = getelementptr i8, ptr %t545, i64 %t534
  call void @olang_textcopy(ptr %t546, ptr %t536, i64 %t537)
  %t547 = getelementptr i8, ptr %t546, i64 %t537
  call void @olang_textcopy(ptr %t547, ptr %t540, i64 %t541)
  %t548 = insertvalue { i64, ptr } undef, i64 %t542, 0
  %t549 = insertvalue { i64, ptr } %t548, ptr %t543, 1
  %t551 = extractvalue { i64, ptr } %t549, 0
  %t552 = extractvalue { i64, ptr } %t549, 1
  %t553 = mul i64 %t551, 1
  %t554 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t553)
  call void @llvm.memcpy.p0.p0.i64(ptr %t554, ptr %t552, i64 %t553, i1 false)
  %t555 = insertvalue { i64, ptr } undef, i64 %t551, 0
  %t556 = insertvalue { i64, ptr } %t555, ptr %t554, 1
  %t557 = load ptr, ptr %l185, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s25, ptr %t557, { i64, ptr } %t556)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s25)
  br label %bb127
bb127:
  br label %bb342
bb128:
  %t559 = load i32, ptr %l1
  %t561 = trunc i64 2 to i32
  %t562 = icmp eq i32 %t559, %t561
  br i1 %t562, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb138
bb131:
  %t564 = load i32, ptr %l8, !tbaa !23
  %t565 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t568 = icmp ne i32 %t564, %t565
  br i1 %t568, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s29
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l204, !tbaa !29
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load i32, ptr %l7, !tbaa !23
  %t575 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s29, ptr %t571, i32 %t572)
  store { i64, ptr } %t575, ptr %l207
  br label %bb134
bb133:
  br label %bb136
bb134:
  %t576 = extractvalue { i64, ptr } { i64 9, ptr @.d159 }, 1
  %t577 = extractvalue { i64, ptr } { i64 9, ptr @.d159 }, 0
  %t578 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t578, 1
  %t580 = extractvalue { i64, ptr } %t578, 0
  %t581 = add i64 %t577, %t580
  %t582 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t581)
  call void @olang_textcopy(ptr %t582, ptr %t576, i64 %t577)
  %t583 = getelementptr i8, ptr %t582, i64 %t577
  call void @olang_textcopy(ptr %t583, ptr %t579, i64 %t580)
  %t584 = insertvalue { i64, ptr } undef, i64 %t581, 0
  %t585 = insertvalue { i64, ptr } %t584, ptr %t582, 1
  %t587 = extractvalue { i64, ptr } %t585, 0
  %t588 = extractvalue { i64, ptr } %t585, 1
  %t589 = mul i64 %t587, 1
  %t590 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t589)
  call void @llvm.memcpy.p0.p0.i64(ptr %t590, ptr %t588, i64 %t589, i1 false)
  %t591 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t592 = insertvalue { i64, ptr } %t591, ptr %t590, 1
  %t593 = load ptr, ptr %l204, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s29, ptr %t593, { i64, ptr } %t592)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s29)
  br label %bb136
bb136:
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load i32, ptr %l1
  %t597 = load %"compiler/mir:Range", ptr %l3
  %t598 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %t595, i32 %t596, %"compiler/mir:Range" %t597, i32 %t598)
  br label %bb137
bb137:
  br label %bb342
bb138:
  %t603 = load i32, ptr %l1
  %t605 = trunc i64 13 to i32
  %t606 = icmp eq i32 %t603, %t605
  br i1 %t606, label %bb139, label %bb140
bb139:
  br label %bb151
bb140:
  %t608 = load i32, ptr %l1
  %t610 = trunc i64 14 to i32
  %t611 = icmp eq i32 %t608, %t610
  br i1 %t611, label %bb141, label %bb142
bb141:
  br label %bb151
bb142:
  %t613 = load i32, ptr %l1
  %t615 = trunc i64 15 to i32
  %t616 = icmp eq i32 %t613, %t615
  br i1 %t616, label %bb143, label %bb144
bb143:
  br label %bb151
bb144:
  %t618 = load i32, ptr %l1
  %t620 = trunc i64 16 to i32
  %t621 = icmp eq i32 %t618, %t620
  br i1 %t621, label %bb145, label %bb146
bb145:
  br label %bb151
bb146:
  %t623 = load i32, ptr %l1
  %t625 = trunc i64 17 to i32
  %t626 = icmp eq i32 %t623, %t625
  br i1 %t626, label %bb147, label %bb148
bb147:
  br label %bb151
bb148:
  %t628 = load i32, ptr %l1
  %t630 = trunc i64 18 to i32
  %t631 = icmp eq i32 %t628, %t630
  br i1 %t631, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb188
bb151:
  %t633 = load ptr, ptr %l0, !tbaa !29
  store ptr %t633, ptr %l226, !tbaa !29
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t635 = load %"compiler/mir:Range", ptr %l3
  %t638 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t634, %"compiler/mir:Range" %t635, i64 1)
  store { i64, [4 x i64] } %t638, ptr %l229
  br label %bb152
bb152:
  %t639 = load ptr, ptr %l226, !tbaa !29
  %t640 = load { i64, [4 x i64] }, ptr %l229
  %t641 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t639, { i64, [4 x i64] } %t640)
  store i32 %t641, ptr %l230
  br label %bb153
bb153:
  %t642 = load i32, ptr %l230, !tbaa !23
  store i32 %t642, ptr %l9, !tbaa !23
  %t643 = load ptr, ptr %l4, !tbaa !29
  store ptr %t643, ptr %l231, !tbaa !29
  %t644 = load i32, ptr %l8, !tbaa !23
  store i32 %t644, ptr %l232, !tbaa !23
  %t645 = load ptr, ptr %l4, !tbaa !29
  %t646 = load i32, ptr %l9, !tbaa !23
  %t649 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t645, i32 %t646)
  store i32 %t649, ptr %l235
  br label %bb154
bb154:
  %t650 = load ptr, ptr %l231, !tbaa !29
  %t651 = load i32, ptr %l232, !tbaa !23
  %t652 = load i32, ptr %l235, !tbaa !23
  %t653 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t650, i32 %t651, i32 %t652)
  store i1 %t653, ptr %l236
  br label %bb155
bb155:
  %t654 = load i1, ptr %l236, !tbaa !21
  %t655 = xor i1 %t654, true
  br i1 %t655, label %bb156, label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s32
  %t657 = load ptr, ptr %l0, !tbaa !29
  store ptr %t657, ptr %l238, !tbaa !29
  %t658 = load i32, ptr %l1
  store i32 %t658, ptr %l239
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s33
  store ptr %s33room, ptr %s33
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s33, ptr %l239, i64 0)
  br label %bb158
bb157:
  br label %bb163
bb158:
  %t660 = load ptr, ptr %s33
  %t661 = getelementptr %olang.builder, ptr %s33, i32 0, i32 1
  %t662 = load i64, ptr %t661
  %t663 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t662)
  call void @olang_textcopy(ptr %t663, ptr %t660, i64 %t662)
  %t664 = insertvalue { i64, ptr } undef, i64 %t662, 0
  %t665 = insertvalue { i64, ptr } %t664, ptr %t663, 1
  store { i64, ptr } %t665, ptr %l241, !tbaa !27
  %t666 = getelementptr %olang.builder, ptr %s33, i32 0, i32 3
  %t667 = load ptr, ptr %t666
  %t668 = icmp ne ptr %t667, null
  br i1 %t668, label %sbgrew.669, label %sbdone.670
sbgrew.669:
  call void @__olang_sb_done(ptr %s33)
  br label %sbdone.670
sbdone.670:
  %t671 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t672 = extractvalue { i64, ptr } %t671, 0
  %t673 = extractvalue { i64, ptr } %t671, 1
  %t674 = mul i64 %t672, 1
  %t675 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t674)
  call void @llvm.memcpy.p0.p0.i64(ptr %t675, ptr %t673, i64 %t674, i1 false)
  %t676 = insertvalue { i64, ptr } undef, i64 %t672, 0
  %t677 = insertvalue { i64, ptr } %t676, ptr %t675, 1
  %t679 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s32, { i64, ptr } %t677)
  store { i64, ptr } %t679, ptr %l243
  br label %bb159
bb159:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load i32, ptr %l7, !tbaa !23
  %t684 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s32, ptr %t680, i32 %t681)
  store { i64, ptr } %t684, ptr %l246
  br label %bb160
bb160:
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load i32, ptr %l9, !tbaa !23
  %t689 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s32, ptr %t685, i32 %t686)
  store { i64, ptr } %t689, ptr %l249
  br label %bb161
bb161:
  %t690 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t691 = extractvalue { i64, ptr } %t690, 1
  %t692 = extractvalue { i64, ptr } %t690, 0
  %t693 = extractvalue { i64, ptr } { i64 6, ptr @.d160 }, 1
  %t694 = extractvalue { i64, ptr } { i64 6, ptr @.d160 }, 0
  %t695 = add i64 %t692, %t694
  %t696 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t697 = extractvalue { i64, ptr } %t696, 1
  %t698 = extractvalue { i64, ptr } %t696, 0
  %t699 = add i64 %t695, %t698
  %t700 = extractvalue { i64, ptr } { i64 7, ptr @.d161 }, 1
  %t701 = extractvalue { i64, ptr } { i64 7, ptr @.d161 }, 0
  %t702 = add i64 %t699, %t701
  %t703 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t704 = extractvalue { i64, ptr } %t703, 1
  %t705 = extractvalue { i64, ptr } %t703, 0
  %t706 = add i64 %t702, %t705
  %t707 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t706)
  call void @olang_textcopy(ptr %t707, ptr %t691, i64 %t692)
  %t708 = getelementptr i8, ptr %t707, i64 %t692
  call void @olang_textcopy(ptr %t708, ptr %t693, i64 %t694)
  %t709 = getelementptr i8, ptr %t708, i64 %t694
  call void @olang_textcopy(ptr %t709, ptr %t697, i64 %t698)
  %t710 = getelementptr i8, ptr %t709, i64 %t698
  call void @olang_textcopy(ptr %t710, ptr %t700, i64 %t701)
  %t711 = getelementptr i8, ptr %t710, i64 %t701
  call void @olang_textcopy(ptr %t711, ptr %t704, i64 %t705)
  %t712 = insertvalue { i64, ptr } undef, i64 %t706, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t707, 1
  %t715 = extractvalue { i64, ptr } %t713, 0
  %t716 = extractvalue { i64, ptr } %t713, 1
  %t717 = mul i64 %t715, 1
  %t718 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t717)
  call void @llvm.memcpy.p0.p0.i64(ptr %t718, ptr %t716, i64 %t717, i1 false)
  %t719 = insertvalue { i64, ptr } undef, i64 %t715, 0
  %t720 = insertvalue { i64, ptr } %t719, ptr %t718, 1
  %t721 = load ptr, ptr %l238, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s32, ptr %t721, { i64, ptr } %t720)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s32)
  br label %bb163
bb163:
  %t723 = load ptr, ptr %l4, !tbaa !29
  %t724 = load i32, ptr %l8, !tbaa !23
  %t727 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t723, i32 %t724)
  store i1 %t727, ptr %l254
  br label %bb164
bb164:
  %t728 = load i1, ptr %l254, !tbaa !21
  %t729 = xor i1 %t728, true
  br i1 %t729, label %bb165, label %bb166
bb165:
  %t731 = load i32, ptr %l8, !tbaa !23
  %t732 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t735 = icmp ne i32 %t731, %t732
  store i1 %t735, ptr %l256, !tbaa !21
  br label %bb167
bb166:
  store i1 false, ptr %l256, !tbaa !21
  br label %bb167
bb167:
  %t737 = load i1, ptr %l256, !tbaa !21
  br i1 %t737, label %bb168, label %bb169
bb168:
  %t738 = load i32, ptr %l1
  %t740 = trunc i64 13 to i32
  %t741 = icmp eq i32 %t738, %t740
  %t743 = xor i1 %t741, true
  store i1 %t743, ptr %l260, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb170
bb170:
  %t745 = load i1, ptr %l260, !tbaa !21
  br i1 %t745, label %bb171, label %bb172
bb171:
  %t746 = load i32, ptr %l1
  %t748 = trunc i64 14 to i32
  %t749 = icmp eq i32 %t746, %t748
  %t751 = xor i1 %t749, true
  store i1 %t751, ptr %l264, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l264, !tbaa !21
  br label %bb173
bb173:
  %t753 = load i1, ptr %l264, !tbaa !21
  br i1 %t753, label %bb174, label %bb175
bb174:
  store %olang.scope zeroinitializer, ptr %s35
  %t754 = load ptr, ptr %l0, !tbaa !29
  store ptr %t754, ptr %l268, !tbaa !29
  %t755 = load i32, ptr %l1
  store i32 %t755, ptr %l269
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s36
  store ptr %s36room, ptr %s36
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s36, ptr %l269, i64 0)
  br label %bb176
bb175:
  br label %bb180
bb176:
  %t757 = load ptr, ptr %s36
  %t758 = getelementptr %olang.builder, ptr %s36, i32 0, i32 1
  %t759 = load i64, ptr %t758
  %t760 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t759)
  call void @olang_textcopy(ptr %t760, ptr %t757, i64 %t759)
  %t761 = insertvalue { i64, ptr } undef, i64 %t759, 0
  %t762 = insertvalue { i64, ptr } %t761, ptr %t760, 1
  store { i64, ptr } %t762, ptr %l271, !tbaa !27
  %t763 = getelementptr %olang.builder, ptr %s36, i32 0, i32 3
  %t764 = load ptr, ptr %t763
  %t765 = icmp ne ptr %t764, null
  br i1 %t765, label %sbgrew.766, label %sbdone.767
sbgrew.766:
  call void @__olang_sb_done(ptr %s36)
  br label %sbdone.767
sbdone.767:
  %t768 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t769 = extractvalue { i64, ptr } %t768, 0
  %t770 = extractvalue { i64, ptr } %t768, 1
  %t771 = mul i64 %t769, 1
  %t772 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t771)
  call void @llvm.memcpy.p0.p0.i64(ptr %t772, ptr %t770, i64 %t771, i1 false)
  %t773 = insertvalue { i64, ptr } undef, i64 %t769, 0
  %t774 = insertvalue { i64, ptr } %t773, ptr %t772, 1
  %t776 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s35, { i64, ptr } %t774)
  store { i64, ptr } %t776, ptr %l273
  br label %bb177
bb177:
  %t777 = load ptr, ptr %l0, !tbaa !29
  %t778 = load i32, ptr %l7, !tbaa !23
  %t781 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s35, ptr %t777, i32 %t778)
  store { i64, ptr } %t781, ptr %l276
  br label %bb178
bb178:
  %t782 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t783 = extractvalue { i64, ptr } %t782, 1
  %t784 = extractvalue { i64, ptr } %t782, 0
  %t785 = extractvalue { i64, ptr } { i64 6, ptr @.d162 }, 1
  %t786 = extractvalue { i64, ptr } { i64 6, ptr @.d162 }, 0
  %t787 = add i64 %t784, %t786
  %t788 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t789 = extractvalue { i64, ptr } %t788, 1
  %t790 = extractvalue { i64, ptr } %t788, 0
  %t791 = add i64 %t787, %t790
  %t792 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t791)
  call void @olang_textcopy(ptr %t792, ptr %t783, i64 %t784)
  %t793 = getelementptr i8, ptr %t792, i64 %t784
  call void @olang_textcopy(ptr %t793, ptr %t785, i64 %t786)
  %t794 = getelementptr i8, ptr %t793, i64 %t786
  call void @olang_textcopy(ptr %t794, ptr %t789, i64 %t790)
  %t795 = insertvalue { i64, ptr } undef, i64 %t791, 0
  %t796 = insertvalue { i64, ptr } %t795, ptr %t792, 1
  %t798 = extractvalue { i64, ptr } %t796, 0
  %t799 = extractvalue { i64, ptr } %t796, 1
  %t800 = mul i64 %t798, 1
  %t801 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t800)
  call void @llvm.memcpy.p0.p0.i64(ptr %t801, ptr %t799, i64 %t800, i1 false)
  %t802 = insertvalue { i64, ptr } undef, i64 %t798, 0
  %t803 = insertvalue { i64, ptr } %t802, ptr %t801, 1
  %t804 = load ptr, ptr %l268, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s35, ptr %t804, { i64, ptr } %t803)
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s35)
  br label %bb180
bb180:
  %t806 = load i32, ptr %l2, !tbaa !23
  %t807 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t810 = icmp ne i32 %t806, %t807
  br i1 %t810, label %bb181, label %bb182
bb181:
  store %olang.scope zeroinitializer, ptr %s38
  %t812 = load ptr, ptr %l0, !tbaa !29
  store ptr %t812, ptr %l282, !tbaa !29
  %t813 = load i32, ptr %l1
  store i32 %t813, ptr %l283
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s39
  store ptr %s39room, ptr %s39
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s39, ptr %l283, i64 0)
  br label %bb183
bb182:
  br label %bb187
bb183:
  %t815 = load ptr, ptr %s39
  %t816 = getelementptr %olang.builder, ptr %s39, i32 0, i32 1
  %t817 = load i64, ptr %t816
  %t818 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t817)
  call void @olang_textcopy(ptr %t818, ptr %t815, i64 %t817)
  %t819 = insertvalue { i64, ptr } undef, i64 %t817, 0
  %t820 = insertvalue { i64, ptr } %t819, ptr %t818, 1
  store { i64, ptr } %t820, ptr %l285, !tbaa !27
  %t821 = getelementptr %olang.builder, ptr %s39, i32 0, i32 3
  %t822 = load ptr, ptr %t821
  %t823 = icmp ne ptr %t822, null
  br i1 %t823, label %sbgrew.824, label %sbdone.825
sbgrew.824:
  call void @__olang_sb_done(ptr %s39)
  br label %sbdone.825
sbdone.825:
  %t826 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t827 = extractvalue { i64, ptr } %t826, 0
  %t828 = extractvalue { i64, ptr } %t826, 1
  %t829 = mul i64 %t827, 1
  %t830 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t829)
  call void @llvm.memcpy.p0.p0.i64(ptr %t830, ptr %t828, i64 %t829, i1 false)
  %t831 = insertvalue { i64, ptr } undef, i64 %t827, 0
  %t832 = insertvalue { i64, ptr } %t831, ptr %t830, 1
  %t834 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s38, { i64, ptr } %t832)
  store { i64, ptr } %t834, ptr %l287
  br label %bb184
bb184:
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t836 = load i32, ptr %l2, !tbaa !23
  %t839 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s38, ptr %t835, i32 %t836)
  store { i64, ptr } %t839, ptr %l290
  br label %bb185
bb185:
  %t840 = load { i64, ptr }, ptr %l287, !tbaa !27
  %t841 = extractvalue { i64, ptr } %t840, 1
  %t842 = extractvalue { i64, ptr } %t840, 0
  %t843 = extractvalue { i64, ptr } { i64 7, ptr @.d163 }, 1
  %t844 = extractvalue { i64, ptr } { i64 7, ptr @.d163 }, 0
  %t845 = add i64 %t842, %t844
  %t846 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t847 = extractvalue { i64, ptr } %t846, 1
  %t848 = extractvalue { i64, ptr } %t846, 0
  %t849 = add i64 %t845, %t848
  %t850 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t849)
  call void @olang_textcopy(ptr %t850, ptr %t841, i64 %t842)
  %t851 = getelementptr i8, ptr %t850, i64 %t842
  call void @olang_textcopy(ptr %t851, ptr %t843, i64 %t844)
  %t852 = getelementptr i8, ptr %t851, i64 %t844
  call void @olang_textcopy(ptr %t852, ptr %t847, i64 %t848)
  %t853 = insertvalue { i64, ptr } undef, i64 %t849, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t850, 1
  %t856 = extractvalue { i64, ptr } %t854, 0
  %t857 = extractvalue { i64, ptr } %t854, 1
  %t858 = mul i64 %t856, 1
  %t859 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t858)
  call void @llvm.memcpy.p0.p0.i64(ptr %t859, ptr %t857, i64 %t858, i1 false)
  %t860 = insertvalue { i64, ptr } undef, i64 %t856, 0
  %t861 = insertvalue { i64, ptr } %t860, ptr %t859, 1
  %t862 = load ptr, ptr %l282, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s38, ptr %t862, { i64, ptr } %t861)
  br label %bb186
bb186:
  call void @__olang_scope_close(ptr %s38)
  br label %bb187
bb187:
  br label %bb342
bb188:
  %t864 = load i32, ptr %l1
  %t866 = trunc i64 19 to i32
  %t867 = icmp eq i32 %t864, %t866
  br i1 %t867, label %bb189, label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb224
bb191:
  %t869 = load ptr, ptr %l0, !tbaa !29
  store ptr %t869, ptr %l295, !tbaa !29
  %t870 = load ptr, ptr %l0, !tbaa !29
  %t871 = load %"compiler/mir:Range", ptr %l3
  %t874 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t870, %"compiler/mir:Range" %t871, i64 1)
  store { i64, [4 x i64] } %t874, ptr %l298
  br label %bb192
bb192:
  %t875 = load ptr, ptr %l295, !tbaa !29
  %t876 = load { i64, [4 x i64] }, ptr %l298
  %t877 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t875, { i64, [4 x i64] } %t876)
  store i32 %t877, ptr %l299
  br label %bb193
bb193:
  %t878 = load i32, ptr %l299, !tbaa !23
  store i32 %t878, ptr %l10, !tbaa !23
  %t879 = load ptr, ptr %l4, !tbaa !29
  %t880 = load i32, ptr %l8, !tbaa !23
  %t883 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t879, i32 %t880)
  store i32 %t883, ptr %l302
  br label %bb194
bb194:
  %t884 = load i32, ptr %l302
  store i32 %t884, ptr %l11
  %t885 = load ptr, ptr %l4, !tbaa !29
  %t886 = load i32, ptr %l10, !tbaa !23
  %t889 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t885, i32 %t886)
  store i32 %t889, ptr %l305
  br label %bb195
bb195:
  %t890 = load i32, ptr %l305, !tbaa !23
  store i32 %t890, ptr %l12, !tbaa !23
  %t891 = load ptr, ptr %l4, !tbaa !29
  %t892 = load i32, ptr %l12, !tbaa !23
  %t893 = load i32, ptr %l8, !tbaa !23
  %t897 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t891, i32 %t892, i32 %t893)
  store i1 %t897, ptr %l309
  br label %bb196
bb196:
  %t898 = load i1, ptr %l309, !tbaa !21
  store i1 %t898, ptr %l13, !tbaa !21
  %t899 = load i32, ptr %l11
  %t901 = trunc i64 20 to i32
  %t902 = icmp eq i32 %t899, %t901
  br i1 %t902, label %bb197, label %bb198
bb197:
  %t904 = load ptr, ptr %l4, !tbaa !29
  %t905 = load i32, ptr %l12, !tbaa !23
  %t908 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t904, i32 %t905)
  store i1 %t908, ptr %l315
  br label %bb199
bb198:
  store i1 false, ptr %l312, !tbaa !21
  br label %bb200
bb199:
  %t909 = load i1, ptr %l315, !tbaa !21
  store i1 %t909, ptr %l312, !tbaa !21
  br label %bb200
bb200:
  %t910 = load i1, ptr %l312, !tbaa !21
  br i1 %t910, label %bb201, label %bb202
bb201:
  %t911 = load ptr, ptr %l0, !tbaa !29
  store ptr %t911, ptr %l316, !tbaa !29
  %t912 = load ptr, ptr %l4, !tbaa !29
  %t913 = load i32, ptr %l8, !tbaa !23
  %t916 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t912, i32 %t913)
  store i32 %t916, ptr %l319
  br label %bb203
bb202:
  br label %bb206
bb203:
  %t917 = load ptr, ptr %l4, !tbaa !29
  %t918 = load i32, ptr %l12, !tbaa !23
  %t921 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t917, i32 %t918)
  store i32 %t921, ptr %l322
  br label %bb204
bb204:
  %t922 = load ptr, ptr %l316, !tbaa !29
  %t923 = load i32, ptr %l319, !tbaa !23
  %t924 = load i32, ptr %l322, !tbaa !23
  %t925 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t922, i32 %t923, i32 %t924)
  store i1 %t925, ptr %l323
  br label %bb205
bb205:
  %t926 = load i1, ptr %l323, !tbaa !21
  store i1 %t926, ptr %l13, !tbaa !21
  br label %bb206
bb206:
  %t927 = load i32, ptr %l11
  %t929 = trunc i64 20 to i32
  %t930 = icmp eq i32 %t927, %t929
  %t932 = xor i1 %t930, true
  br i1 %t932, label %bb207, label %bb208
bb207:
  %t934 = load i32, ptr %l11
  %t936 = trunc i64 21 to i32
  %t937 = icmp eq i32 %t934, %t936
  %t939 = xor i1 %t937, true
  store i1 %t939, ptr %l327, !tbaa !21
  br label %bb209
bb208:
  store i1 false, ptr %l327, !tbaa !21
  br label %bb209
bb209:
  %t941 = load i1, ptr %l327, !tbaa !21
  br i1 %t941, label %bb210, label %bb211
bb210:
  store i1 true, ptr %l331, !tbaa !21
  br label %bb212
bb211:
  %t942 = load i1, ptr %l13, !tbaa !21
  %t944 = xor i1 %t942, true
  store i1 %t944, ptr %l331, !tbaa !21
  br label %bb212
bb212:
  %t946 = load i1, ptr %l331, !tbaa !21
  br i1 %t946, label %bb213, label %bb214
bb213:
  store %olang.scope zeroinitializer, ptr %s43
  %t947 = load ptr, ptr %l0, !tbaa !29
  store ptr %t947, ptr %l334, !tbaa !29
  %t948 = load ptr, ptr %l0, !tbaa !29
  %t949 = load i32, ptr %l7, !tbaa !23
  %t952 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s43, ptr %t948, i32 %t949)
  store { i64, ptr } %t952, ptr %l337
  br label %bb215
bb214:
  br label %bb218
bb215:
  %t953 = load ptr, ptr %l0, !tbaa !29
  %t954 = load i32, ptr %l10, !tbaa !23
  %t957 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s43, ptr %t953, i32 %t954)
  store { i64, ptr } %t957, ptr %l340
  br label %bb216
bb216:
  %t958 = extractvalue { i64, ptr } { i64 10, ptr @.d164 }, 1
  %t959 = extractvalue { i64, ptr } { i64 10, ptr @.d164 }, 0
  %t960 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t961 = extractvalue { i64, ptr } %t960, 1
  %t962 = extractvalue { i64, ptr } %t960, 0
  %t963 = add i64 %t959, %t962
  %t964 = extractvalue { i64, ptr } { i64 7, ptr @.d165 }, 1
  %t965 = extractvalue { i64, ptr } { i64 7, ptr @.d165 }, 0
  %t966 = add i64 %t963, %t965
  %t967 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t968 = extractvalue { i64, ptr } %t967, 1
  %t969 = extractvalue { i64, ptr } %t967, 0
  %t970 = add i64 %t966, %t969
  %t971 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t970)
  call void @olang_textcopy(ptr %t971, ptr %t958, i64 %t959)
  %t972 = getelementptr i8, ptr %t971, i64 %t959
  call void @olang_textcopy(ptr %t972, ptr %t961, i64 %t962)
  %t973 = getelementptr i8, ptr %t972, i64 %t962
  call void @olang_textcopy(ptr %t973, ptr %t964, i64 %t965)
  %t974 = getelementptr i8, ptr %t973, i64 %t965
  call void @olang_textcopy(ptr %t974, ptr %t968, i64 %t969)
  %t975 = insertvalue { i64, ptr } undef, i64 %t970, 0
  %t976 = insertvalue { i64, ptr } %t975, ptr %t971, 1
  %t978 = extractvalue { i64, ptr } %t976, 0
  %t979 = extractvalue { i64, ptr } %t976, 1
  %t980 = mul i64 %t978, 1
  %t981 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t980)
  call void @llvm.memcpy.p0.p0.i64(ptr %t981, ptr %t979, i64 %t980, i1 false)
  %t982 = insertvalue { i64, ptr } undef, i64 %t978, 0
  %t983 = insertvalue { i64, ptr } %t982, ptr %t981, 1
  %t984 = load ptr, ptr %l334, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s43, ptr %t984, { i64, ptr } %t983)
  br label %bb217
bb217:
  call void @__olang_scope_close(ptr %s43)
  br label %bb218
bb218:
  %t986 = load i32, ptr %l2, !tbaa !23
  %t987 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t990 = icmp ne i32 %t986, %t987
  br i1 %t990, label %bb219, label %bb220
bb219:
  store %olang.scope zeroinitializer, ptr %s45
  %t992 = load ptr, ptr %l0, !tbaa !29
  store ptr %t992, ptr %l346, !tbaa !29
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t994 = load i32, ptr %l2, !tbaa !23
  %t997 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s45, ptr %t993, i32 %t994)
  store { i64, ptr } %t997, ptr %l349
  br label %bb221
bb220:
  br label %bb223
bb221:
  %t998 = extractvalue { i64, ptr } { i64 11, ptr @.d166 }, 1
  %t999 = extractvalue { i64, ptr } { i64 11, ptr @.d166 }, 0
  %t1000 = load { i64, ptr }, ptr %l349, !tbaa !27
  %t1001 = extractvalue { i64, ptr } %t1000, 1
  %t1002 = extractvalue { i64, ptr } %t1000, 0
  %t1003 = add i64 %t999, %t1002
  %t1004 = call ptr @__olang_scope_alloc(ptr %s45, i64 %t1003)
  call void @olang_textcopy(ptr %t1004, ptr %t998, i64 %t999)
  %t1005 = getelementptr i8, ptr %t1004, i64 %t999
  call void @olang_textcopy(ptr %t1005, ptr %t1001, i64 %t1002)
  %t1006 = insertvalue { i64, ptr } undef, i64 %t1003, 0
  %t1007 = insertvalue { i64, ptr } %t1006, ptr %t1004, 1
  %t1009 = extractvalue { i64, ptr } %t1007, 0
  %t1010 = extractvalue { i64, ptr } %t1007, 1
  %t1011 = mul i64 %t1009, 1
  %t1012 = call ptr @__olang_scope_alloc(ptr %s45, i64 %t1011)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1012, ptr %t1010, i64 %t1011, i1 false)
  %t1013 = insertvalue { i64, ptr } undef, i64 %t1009, 0
  %t1014 = insertvalue { i64, ptr } %t1013, ptr %t1012, 1
  %t1015 = load ptr, ptr %l346, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s45, ptr %t1015, { i64, ptr } %t1014)
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s45)
  br label %bb223
bb223:
  br label %bb342
bb224:
  %t1017 = load i32, ptr %l1
  %t1019 = trunc i64 20 to i32
  %t1020 = icmp eq i32 %t1017, %t1019
  br i1 %t1020, label %bb225, label %bb226
bb225:
  br label %bb229
bb226:
  %t1022 = load i32, ptr %l1
  %t1024 = trunc i64 21 to i32
  %t1025 = icmp eq i32 %t1022, %t1024
  br i1 %t1025, label %bb227, label %bb228
bb227:
  br label %bb229
bb228:
  br label %bb230
bb229:
  br label %bb342
bb230:
  %t1027 = load i32, ptr %l1
  %t1029 = trunc i64 22 to i32
  %t1030 = icmp eq i32 %t1027, %t1029
  br i1 %t1030, label %bb231, label %bb232
bb231:
  br label %bb233
bb232:
  br label %bb250
bb233:
  %t1032 = load ptr, ptr %l4, !tbaa !29
  %t1033 = load i32, ptr %l8, !tbaa !23
  %t1036 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t1032, i32 %t1033)
  store i1 %t1036, ptr %l360
  br label %bb234
bb234:
  %t1037 = load i1, ptr %l360, !tbaa !21
  br i1 %t1037, label %bb235, label %bb236
bb235:
  %t1038 = load ptr, ptr %l4, !tbaa !29
  %t1039 = load i32, ptr %l8, !tbaa !23
  %t1042 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1038, i32 %t1039)
  store i32 %t1042, ptr %l364
  br label %bb237
bb236:
  %t1043 = load i32, ptr %l7, !tbaa !23
  store i32 %t1043, ptr %l361, !tbaa !23
  br label %bb238
bb237:
  %t1045 = load i32, ptr %l364, !tbaa !23
  store i32 %t1045, ptr %l361, !tbaa !23
  br label %bb238
bb238:
  %t1046 = load i32, ptr %l361, !tbaa !23
  %t1047 = load ptr, ptr %l0, !tbaa !29
  %t1051 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t1047, i32 %t1046)
  store i32 %t1051, ptr %l368
  br label %bb239
bb239:
  %t1052 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1053 = load i32, ptr %l368, !tbaa !23
  %t1055 = icmp eq i32 %t1053, %t1052
  br i1 %t1055, label %bb240, label %bb241
bb240:
  store %olang.scope zeroinitializer, ptr %s49
  %t1057 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1057, ptr %l371, !tbaa !29
  %t1058 = load ptr, ptr %l0, !tbaa !29
  %t1059 = load i32, ptr %l7, !tbaa !23
  %t1062 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s49, ptr %t1058, i32 %t1059)
  store { i64, ptr } %t1062, ptr %l374
  br label %bb242
bb241:
  br label %bb244
bb242:
  %t1063 = extractvalue { i64, ptr } { i64 9, ptr @.d167 }, 1
  %t1064 = extractvalue { i64, ptr } { i64 9, ptr @.d167 }, 0
  %t1065 = load { i64, ptr }, ptr %l374, !tbaa !27
  %t1066 = extractvalue { i64, ptr } %t1065, 1
  %t1067 = extractvalue { i64, ptr } %t1065, 0
  %t1068 = add i64 %t1064, %t1067
  %t1069 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1068)
  call void @olang_textcopy(ptr %t1069, ptr %t1063, i64 %t1064)
  %t1070 = getelementptr i8, ptr %t1069, i64 %t1064
  call void @olang_textcopy(ptr %t1070, ptr %t1066, i64 %t1067)
  %t1071 = insertvalue { i64, ptr } undef, i64 %t1068, 0
  %t1072 = insertvalue { i64, ptr } %t1071, ptr %t1069, 1
  %t1074 = extractvalue { i64, ptr } %t1072, 0
  %t1075 = extractvalue { i64, ptr } %t1072, 1
  %t1076 = mul i64 %t1074, 1
  %t1077 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1076)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1077, ptr %t1075, i64 %t1076, i1 false)
  %t1078 = insertvalue { i64, ptr } undef, i64 %t1074, 0
  %t1079 = insertvalue { i64, ptr } %t1078, ptr %t1077, 1
  %t1080 = load ptr, ptr %l371, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s49, ptr %t1080, { i64, ptr } %t1079)
  br label %bb243
bb243:
  call void @__olang_scope_close(ptr %s49)
  br label %bb244
bb244:
  %t1082 = load i32, ptr %l2, !tbaa !23
  %t1083 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1086 = icmp ne i32 %t1082, %t1083
  br i1 %t1086, label %bb245, label %bb246
bb245:
  store %olang.scope zeroinitializer, ptr %s51
  %t1088 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1088, ptr %l380, !tbaa !29
  %t1089 = load ptr, ptr %l0, !tbaa !29
  %t1090 = load i32, ptr %l2, !tbaa !23
  %t1093 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s51, ptr %t1089, i32 %t1090)
  store { i64, ptr } %t1093, ptr %l383
  br label %bb247
bb246:
  br label %bb249
bb247:
  %t1094 = extractvalue { i64, ptr } { i64 10, ptr @.d168 }, 1
  %t1095 = extractvalue { i64, ptr } { i64 10, ptr @.d168 }, 0
  %t1096 = load { i64, ptr }, ptr %l383, !tbaa !27
  %t1097 = extractvalue { i64, ptr } %t1096, 1
  %t1098 = extractvalue { i64, ptr } %t1096, 0
  %t1099 = add i64 %t1095, %t1098
  %t1100 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1099)
  call void @olang_textcopy(ptr %t1100, ptr %t1094, i64 %t1095)
  %t1101 = getelementptr i8, ptr %t1100, i64 %t1095
  call void @olang_textcopy(ptr %t1101, ptr %t1097, i64 %t1098)
  %t1102 = insertvalue { i64, ptr } undef, i64 %t1099, 0
  %t1103 = insertvalue { i64, ptr } %t1102, ptr %t1100, 1
  %t1105 = extractvalue { i64, ptr } %t1103, 0
  %t1106 = extractvalue { i64, ptr } %t1103, 1
  %t1107 = mul i64 %t1105, 1
  %t1108 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1108, ptr %t1106, i64 %t1107, i1 false)
  %t1109 = insertvalue { i64, ptr } undef, i64 %t1105, 0
  %t1110 = insertvalue { i64, ptr } %t1109, ptr %t1108, 1
  %t1111 = load ptr, ptr %l380, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s51, ptr %t1111, { i64, ptr } %t1110)
  br label %bb248
bb248:
  call void @__olang_scope_close(ptr %s51)
  br label %bb249
bb249:
  br label %bb342
bb250:
  %t1113 = load i32, ptr %l1
  %t1115 = trunc i64 31 to i32
  %t1116 = icmp eq i32 %t1113, %t1115
  br i1 %t1116, label %bb251, label %bb252
bb251:
  br label %bb253
bb252:
  br label %bb270
bb253:
  %t1118 = load ptr, ptr %l4, !tbaa !29
  %t1119 = load i32, ptr %l8, !tbaa !23
  %t1122 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t1118, i32 %t1119)
  store i1 %t1122, ptr %l390
  br label %bb254
bb254:
  %t1123 = load i1, ptr %l390, !tbaa !21
  br i1 %t1123, label %bb255, label %bb256
bb255:
  %t1124 = load ptr, ptr %l4, !tbaa !29
  %t1125 = load i32, ptr %l8, !tbaa !23
  %t1128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1124, i32 %t1125)
  store i32 %t1128, ptr %l394
  br label %bb257
bb256:
  %t1129 = load i32, ptr %l7, !tbaa !23
  store i32 %t1129, ptr %l391, !tbaa !23
  br label %bb258
bb257:
  %t1131 = load i32, ptr %l394, !tbaa !23
  store i32 %t1131, ptr %l391, !tbaa !23
  br label %bb258
bb258:
  %t1132 = load i32, ptr %l391, !tbaa !23
  %t1133 = load ptr, ptr %l0, !tbaa !29
  %t1137 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t1133, i32 %t1132)
  store i32 %t1137, ptr %l398
  br label %bb259
bb259:
  %t1138 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1139 = load i32, ptr %l398, !tbaa !23
  %t1141 = icmp eq i32 %t1139, %t1138
  br i1 %t1141, label %bb260, label %bb261
bb260:
  store %olang.scope zeroinitializer, ptr %s54
  %t1143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1143, ptr %l401, !tbaa !29
  %t1144 = load ptr, ptr %l0, !tbaa !29
  %t1145 = load i32, ptr %l7, !tbaa !23
  %t1148 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s54, ptr %t1144, i32 %t1145)
  store { i64, ptr } %t1148, ptr %l404
  br label %bb262
bb261:
  br label %bb264
bb262:
  %t1149 = extractvalue { i64, ptr } { i64 12, ptr @.d169 }, 1
  %t1150 = extractvalue { i64, ptr } { i64 12, ptr @.d169 }, 0
  %t1151 = load { i64, ptr }, ptr %l404, !tbaa !27
  %t1152 = extractvalue { i64, ptr } %t1151, 1
  %t1153 = extractvalue { i64, ptr } %t1151, 0
  %t1154 = add i64 %t1150, %t1153
  %t1155 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1154)
  call void @olang_textcopy(ptr %t1155, ptr %t1149, i64 %t1150)
  %t1156 = getelementptr i8, ptr %t1155, i64 %t1150
  call void @olang_textcopy(ptr %t1156, ptr %t1152, i64 %t1153)
  %t1157 = insertvalue { i64, ptr } undef, i64 %t1154, 0
  %t1158 = insertvalue { i64, ptr } %t1157, ptr %t1155, 1
  %t1160 = extractvalue { i64, ptr } %t1158, 0
  %t1161 = extractvalue { i64, ptr } %t1158, 1
  %t1162 = mul i64 %t1160, 1
  %t1163 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1162)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1163, ptr %t1161, i64 %t1162, i1 false)
  %t1164 = insertvalue { i64, ptr } undef, i64 %t1160, 0
  %t1165 = insertvalue { i64, ptr } %t1164, ptr %t1163, 1
  %t1166 = load ptr, ptr %l401, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s54, ptr %t1166, { i64, ptr } %t1165)
  br label %bb263
bb263:
  call void @__olang_scope_close(ptr %s54)
  br label %bb264
bb264:
  %t1168 = load i32, ptr %l2, !tbaa !23
  %t1169 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1172 = icmp ne i32 %t1168, %t1169
  br i1 %t1172, label %bb265, label %bb266
bb265:
  store %olang.scope zeroinitializer, ptr %s56
  %t1174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1174, ptr %l410, !tbaa !29
  %t1175 = load ptr, ptr %l0, !tbaa !29
  %t1176 = load i32, ptr %l2, !tbaa !23
  %t1179 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s56, ptr %t1175, i32 %t1176)
  store { i64, ptr } %t1179, ptr %l413
  br label %bb267
bb266:
  br label %bb269
bb267:
  %t1180 = extractvalue { i64, ptr } { i64 13, ptr @.d170 }, 1
  %t1181 = extractvalue { i64, ptr } { i64 13, ptr @.d170 }, 0
  %t1182 = load { i64, ptr }, ptr %l413, !tbaa !27
  %t1183 = extractvalue { i64, ptr } %t1182, 1
  %t1184 = extractvalue { i64, ptr } %t1182, 0
  %t1185 = add i64 %t1181, %t1184
  %t1186 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t1185)
  call void @olang_textcopy(ptr %t1186, ptr %t1180, i64 %t1181)
  %t1187 = getelementptr i8, ptr %t1186, i64 %t1181
  call void @olang_textcopy(ptr %t1187, ptr %t1183, i64 %t1184)
  %t1188 = insertvalue { i64, ptr } undef, i64 %t1185, 0
  %t1189 = insertvalue { i64, ptr } %t1188, ptr %t1186, 1
  %t1191 = extractvalue { i64, ptr } %t1189, 0
  %t1192 = extractvalue { i64, ptr } %t1189, 1
  %t1193 = mul i64 %t1191, 1
  %t1194 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t1193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1194, ptr %t1192, i64 %t1193, i1 false)
  %t1195 = insertvalue { i64, ptr } undef, i64 %t1191, 0
  %t1196 = insertvalue { i64, ptr } %t1195, ptr %t1194, 1
  %t1197 = load ptr, ptr %l410, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s56, ptr %t1197, { i64, ptr } %t1196)
  br label %bb268
bb268:
  call void @__olang_scope_close(ptr %s56)
  br label %bb269
bb269:
  br label %bb342
bb270:
  %t1199 = load i32, ptr %l1
  %t1201 = trunc i64 23 to i32
  %t1202 = icmp eq i32 %t1199, %t1201
  br i1 %t1202, label %bb271, label %bb272
bb271:
  br label %bb273
bb272:
  br label %bb285
bb273:
  %t1204 = load ptr, ptr %l0, !tbaa !29
  %t1205 = load i32, ptr %l7, !tbaa !23
  %t1208 = call { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOf(ptr %v0, ptr %t1204, i32 %t1205)
  store { i32, i1 } %t1208, ptr %l420
  br label %bb274
bb274:
  %t1209 = load { i32, i1 }, ptr %l420
  store { i32, i1 } %t1209, ptr %l16
  %t1210 = getelementptr { i32, i1 }, ptr %l16, i32 0, i32 1
  %t1211 = load i1, ptr %t1210, !tbaa !21
  %t1215 = xor i1 %t1211, true
  br i1 %t1215, label %bb275, label %bb276
bb275:
  store %olang.scope zeroinitializer, ptr %s59
  %t1217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1217, ptr %l424, !tbaa !29
  %t1218 = load ptr, ptr %l0, !tbaa !29
  %t1219 = load i32, ptr %l7, !tbaa !23
  %t1222 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s59, ptr %t1218, i32 %t1219)
  store { i64, ptr } %t1222, ptr %l427
  br label %bb277
bb276:
  br label %bb279
bb277:
  %t1223 = extractvalue { i64, ptr } { i64 12, ptr @.d171 }, 1
  %t1224 = extractvalue { i64, ptr } { i64 12, ptr @.d171 }, 0
  %t1225 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t1226 = extractvalue { i64, ptr } %t1225, 1
  %t1227 = extractvalue { i64, ptr } %t1225, 0
  %t1228 = add i64 %t1224, %t1227
  %t1229 = call ptr @__olang_scope_alloc(ptr %s59, i64 %t1228)
  call void @olang_textcopy(ptr %t1229, ptr %t1223, i64 %t1224)
  %t1230 = getelementptr i8, ptr %t1229, i64 %t1224
  call void @olang_textcopy(ptr %t1230, ptr %t1226, i64 %t1227)
  %t1231 = insertvalue { i64, ptr } undef, i64 %t1228, 0
  %t1232 = insertvalue { i64, ptr } %t1231, ptr %t1229, 1
  %t1234 = extractvalue { i64, ptr } %t1232, 0
  %t1235 = extractvalue { i64, ptr } %t1232, 1
  %t1236 = mul i64 %t1234, 1
  %t1237 = call ptr @__olang_scope_alloc(ptr %s59, i64 %t1236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1237, ptr %t1235, i64 %t1236, i1 false)
  %t1238 = insertvalue { i64, ptr } undef, i64 %t1234, 0
  %t1239 = insertvalue { i64, ptr } %t1238, ptr %t1237, 1
  %t1240 = load ptr, ptr %l424, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s59, ptr %t1240, { i64, ptr } %t1239)
  br label %bb278
bb278:
  call void @__olang_scope_close(ptr %s59)
  br label %bb279
bb279:
  %t1242 = load i32, ptr %l2, !tbaa !23
  %t1243 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1246 = icmp ne i32 %t1242, %t1243
  br i1 %t1246, label %bb280, label %bb281
bb280:
  store %olang.scope zeroinitializer, ptr %s61
  %t1248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1248, ptr %l433, !tbaa !29
  %t1249 = load ptr, ptr %l0, !tbaa !29
  %t1250 = load i32, ptr %l2, !tbaa !23
  %t1253 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s61, ptr %t1249, i32 %t1250)
  store { i64, ptr } %t1253, ptr %l436
  br label %bb282
bb281:
  br label %bb284
bb282:
  %t1254 = extractvalue { i64, ptr } { i64 13, ptr @.d172 }, 1
  %t1255 = extractvalue { i64, ptr } { i64 13, ptr @.d172 }, 0
  %t1256 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t1257 = extractvalue { i64, ptr } %t1256, 1
  %t1258 = extractvalue { i64, ptr } %t1256, 0
  %t1259 = add i64 %t1255, %t1258
  %t1260 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1259)
  call void @olang_textcopy(ptr %t1260, ptr %t1254, i64 %t1255)
  %t1261 = getelementptr i8, ptr %t1260, i64 %t1255
  call void @olang_textcopy(ptr %t1261, ptr %t1257, i64 %t1258)
  %t1262 = insertvalue { i64, ptr } undef, i64 %t1259, 0
  %t1263 = insertvalue { i64, ptr } %t1262, ptr %t1260, 1
  %t1265 = extractvalue { i64, ptr } %t1263, 0
  %t1266 = extractvalue { i64, ptr } %t1263, 1
  %t1267 = mul i64 %t1265, 1
  %t1268 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1268, ptr %t1266, i64 %t1267, i1 false)
  %t1269 = insertvalue { i64, ptr } undef, i64 %t1265, 0
  %t1270 = insertvalue { i64, ptr } %t1269, ptr %t1268, 1
  %t1271 = load ptr, ptr %l433, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s61, ptr %t1271, { i64, ptr } %t1270)
  br label %bb283
bb283:
  call void @__olang_scope_close(ptr %s61)
  br label %bb284
bb284:
  br label %bb342
bb285:
  br i1 true, label %bb286, label %bb287
bb286:
  br label %bb288
bb287:
  br label %bb341
bb288:
  %t1273 = load ptr, ptr %l4, !tbaa !29
  %t1274 = load i32, ptr %l8, !tbaa !23
  %t1277 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t1273, i32 %t1274)
  store i1 %t1277, ptr %l441
  br label %bb289
bb289:
  %t1278 = load i1, ptr %l441, !tbaa !21
  %t1279 = xor i1 %t1278, true
  br i1 %t1279, label %bb290, label %bb291
bb290:
  store i1 true, ptr %l443, !tbaa !21
  br label %bb295
bb291:
  %t1281 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1281, ptr %l444, !tbaa !29
  %t1282 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1282, ptr %l445, !tbaa !29
  %t1283 = load ptr, ptr %l4, !tbaa !29
  %t1284 = load i32, ptr %l8, !tbaa !23
  %t1287 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1283, i32 %t1284)
  store i32 %t1287, ptr %l448
  br label %bb292
bb292:
  %t1288 = load ptr, ptr %l445, !tbaa !29
  %t1289 = load i32, ptr %l448, !tbaa !23
  %t1290 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1288, i32 %t1289)
  store i32 %t1290, ptr %l449
  br label %bb293
bb293:
  %t1291 = load ptr, ptr %l444, !tbaa !29
  %t1292 = load i32, ptr %l449, !tbaa !23
  %t1293 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t1291, i32 %t1292)
  store i1 %t1293, ptr %l450
  br label %bb294
bb294:
  %t1294 = load i1, ptr %l450, !tbaa !21
  %t1295 = xor i1 %t1294, true
  store i1 %t1295, ptr %l443, !tbaa !21
  br label %bb295
bb295:
  %t1297 = load i1, ptr %l443, !tbaa !21
  br i1 %t1297, label %bb296, label %bb297
bb296:
  store i1 true, ptr %l452, !tbaa !21
  br label %bb299
bb297:
  %t1298 = load ptr, ptr %l4, !tbaa !29
  %t1299 = load i32, ptr %l8, !tbaa !23
  %t1302 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1298, i32 %t1299)
  store i64 %t1302, ptr %l455
  br label %bb298
bb298:
  %t1303 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1304 = load i64, ptr %l455, !tbaa !24
  %t1306 = and i64 %t1304, %t1303
  %t1308 = icmp eq i64 %t1306, 0
  store i1 %t1308, ptr %l452, !tbaa !21
  br label %bb299
bb299:
  %t1310 = load i1, ptr %l452, !tbaa !21
  br i1 %t1310, label %bb300, label %bb301
bb300:
  store %olang.scope zeroinitializer, ptr %s64
  %t1311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1311, ptr %l459, !tbaa !29
  %t1312 = load i32, ptr %l1
  store i32 %t1312, ptr %l460
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s65
  store ptr %s65room, ptr %s65
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s65, ptr %l460, i64 0)
  br label %bb302
bb301:
  %t1314 = load ptr, ptr %l4, !tbaa !29
  %t1315 = load i32, ptr %l8, !tbaa !23
  %t1318 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1314, i32 %t1315)
  store i32 %t1318, ptr %l472
  br label %bb306
bb302:
  %t1319 = load ptr, ptr %s65
  %t1320 = getelementptr %olang.builder, ptr %s65, i32 0, i32 1
  %t1321 = load i64, ptr %t1320
  %t1322 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1321)
  call void @olang_textcopy(ptr %t1322, ptr %t1319, i64 %t1321)
  %t1323 = insertvalue { i64, ptr } undef, i64 %t1321, 0
  %t1324 = insertvalue { i64, ptr } %t1323, ptr %t1322, 1
  store { i64, ptr } %t1324, ptr %l462, !tbaa !27
  %t1325 = getelementptr %olang.builder, ptr %s65, i32 0, i32 3
  %t1326 = load ptr, ptr %t1325
  %t1327 = icmp ne ptr %t1326, null
  br i1 %t1327, label %sbgrew.1328, label %sbdone.1329
sbgrew.1328:
  call void @__olang_sb_done(ptr %s65)
  br label %sbdone.1329
sbdone.1329:
  %t1330 = load { i64, ptr }, ptr %l462, !tbaa !27
  %t1331 = extractvalue { i64, ptr } %t1330, 0
  %t1332 = extractvalue { i64, ptr } %t1330, 1
  %t1333 = mul i64 %t1331, 1
  %t1334 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1333)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1334, ptr %t1332, i64 %t1333, i1 false)
  %t1335 = insertvalue { i64, ptr } undef, i64 %t1331, 0
  %t1336 = insertvalue { i64, ptr } %t1335, ptr %t1334, 1
  %t1338 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s64, { i64, ptr } %t1336)
  store { i64, ptr } %t1338, ptr %l464
  br label %bb303
bb303:
  %t1339 = load ptr, ptr %l0, !tbaa !29
  %t1340 = load i32, ptr %l7, !tbaa !23
  %t1343 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s64, ptr %t1339, i32 %t1340)
  store { i64, ptr } %t1343, ptr %l467
  br label %bb304
bb304:
  %t1344 = load { i64, ptr }, ptr %l464, !tbaa !27
  %t1345 = extractvalue { i64, ptr } %t1344, 1
  %t1346 = extractvalue { i64, ptr } %t1344, 0
  %t1347 = extractvalue { i64, ptr } { i64 6, ptr @.d173 }, 1
  %t1348 = extractvalue { i64, ptr } { i64 6, ptr @.d173 }, 0
  %t1349 = add i64 %t1346, %t1348
  %t1350 = load { i64, ptr }, ptr %l467, !tbaa !27
  %t1351 = extractvalue { i64, ptr } %t1350, 1
  %t1352 = extractvalue { i64, ptr } %t1350, 0
  %t1353 = add i64 %t1349, %t1352
  %t1354 = extractvalue { i64, ptr } { i64 40, ptr @.d174 }, 1
  %t1355 = extractvalue { i64, ptr } { i64 40, ptr @.d174 }, 0
  %t1356 = add i64 %t1353, %t1355
  %t1357 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1356)
  call void @olang_textcopy(ptr %t1357, ptr %t1345, i64 %t1346)
  %t1358 = getelementptr i8, ptr %t1357, i64 %t1346
  call void @olang_textcopy(ptr %t1358, ptr %t1347, i64 %t1348)
  %t1359 = getelementptr i8, ptr %t1358, i64 %t1348
  call void @olang_textcopy(ptr %t1359, ptr %t1351, i64 %t1352)
  %t1360 = getelementptr i8, ptr %t1359, i64 %t1352
  call void @olang_textcopy(ptr %t1360, ptr %t1354, i64 %t1355)
  %t1361 = insertvalue { i64, ptr } undef, i64 %t1356, 0
  %t1362 = insertvalue { i64, ptr } %t1361, ptr %t1357, 1
  %t1364 = extractvalue { i64, ptr } %t1362, 0
  %t1365 = extractvalue { i64, ptr } %t1362, 1
  %t1366 = mul i64 %t1364, 1
  %t1367 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1366)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1367, ptr %t1365, i64 %t1366, i1 false)
  %t1368 = insertvalue { i64, ptr } undef, i64 %t1364, 0
  %t1369 = insertvalue { i64, ptr } %t1368, ptr %t1367, 1
  %t1370 = load ptr, ptr %l459, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s64, ptr %t1370, { i64, ptr } %t1369)
  br label %bb305
bb305:
  call void @__olang_scope_close(ptr %s64)
  br label %bb340
bb306:
  %t1372 = load i32, ptr %l472, !tbaa !23
  store i32 %t1372, ptr %l18, !tbaa !23
  store i64 1, ptr %l19, !tbaa !24
  %t1373 = load i64, ptr %l5, !tbaa !24
  store i64 %t1373, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t1375 = load i64, ptr %l20, !tbaa !24
  %t1376 = load i64, ptr %l19, !tbaa !24
  %t1379 = icmp sgt i64 %t1375, %t1376
  br i1 %t1379, label %bb307, label %bb308
bb307:
  %t1381 = load i64, ptr %l21, !tbaa !24
  %t1383 = icmp sgt i64 %t1381, 0
  br i1 %t1383, label %bb309, label %bb310
bb308:
  store i64 0, ptr %l477, !tbaa !24
  br label %bb312
bb309:
  %t1385 = load i64, ptr %l20, !tbaa !24
  %t1386 = load i64, ptr %l19, !tbaa !24
  %t1389 = sub i64 %t1385, %t1386
  %t1390 = load i64, ptr %l21, !tbaa !24
  %t1393 = add i64 %t1389, %t1390
  %t1395 = sub i64 %t1393, 1
  %t1396 = load i64, ptr %l21, !tbaa !24
  %t1399 = sdiv i64 %t1395, %t1396
  store i64 %t1399, ptr %l480, !tbaa !24
  br label %bb311
bb310:
  store i64 0, ptr %l480, !tbaa !24
  br label %bb311
bb311:
  %t1401 = load i64, ptr %l480, !tbaa !24
  store i64 %t1401, ptr %l477, !tbaa !24
  br label %bb312
bb312:
  %t1402 = load i64, ptr %l477, !tbaa !24
  store i64 %t1402, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb313
bb313:
  store %olang.scope zeroinitializer, ptr %s69
  %t1403 = load i64, ptr %l23, !tbaa !24
  %t1404 = load i64, ptr %l22, !tbaa !24
  %t1407 = icmp slt i64 %t1403, %t1404
  %t1409 = xor i1 %t1407, true
  br i1 %t1409, label %bb314, label %bb315
bb314:
  call void @__olang_scope_close(ptr %s69)
  br label %bb323
bb315:
  br label %bb316
bb316:
  %t1411 = load i64, ptr %l19, !tbaa !24
  %t1412 = load i64, ptr %l23, !tbaa !24
  %t1413 = load i64, ptr %l21, !tbaa !24
  %t1416 = mul i64 %t1412, %t1413
  %t1419 = add i64 %t1411, %t1416
  store i64 %t1419, ptr %l24, !tbaa !24
  %t1421 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1421, ptr %l498, !tbaa !29
  %t1422 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1422, ptr %l499, !tbaa !29
  %t1423 = load ptr, ptr %l0, !tbaa !29
  %t1424 = load %"compiler/mir:Range", ptr %l3
  %t1425 = load i64, ptr %l24, !tbaa !24
  %t1429 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t1423, %"compiler/mir:Range" %t1424, i64 %t1425)
  store { i64, [4 x i64] } %t1429, ptr %l503
  br label %bb317
bb317:
  %t1430 = load ptr, ptr %l499, !tbaa !29
  %t1431 = load { i64, [4 x i64] }, ptr %l503
  %t1432 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t1430, { i64, [4 x i64] } %t1431)
  store i32 %t1432, ptr %l504
  br label %bb318
bb318:
  %t1433 = load i32, ptr %l18, !tbaa !23
  store i32 %t1433, ptr %l505, !tbaa !23
  %t1434 = load i32, ptr %l1
  store i32 %t1434, ptr %l506
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s70
  store ptr %s70room, ptr %s70
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s70, ptr %l506, i64 0)
  br label %bb319
bb319:
  %t1436 = load ptr, ptr %s70
  %t1437 = getelementptr %olang.builder, ptr %s70, i32 0, i32 1
  %t1438 = load i64, ptr %t1437
  %t1439 = call ptr @__olang_scope_alloc(ptr %s69, i64 %t1438)
  call void @olang_textcopy(ptr %t1439, ptr %t1436, i64 %t1438)
  %t1440 = insertvalue { i64, ptr } undef, i64 %t1438, 0
  %t1441 = insertvalue { i64, ptr } %t1440, ptr %t1439, 1
  store { i64, ptr } %t1441, ptr %l508, !tbaa !27
  %t1442 = getelementptr %olang.builder, ptr %s70, i32 0, i32 3
  %t1443 = load ptr, ptr %t1442
  %t1444 = icmp ne ptr %t1443, null
  br i1 %t1444, label %sbgrew.1445, label %sbdone.1446
sbgrew.1445:
  call void @__olang_sb_done(ptr %s70)
  br label %sbdone.1446
sbdone.1446:
  %t1447 = load { i64, ptr }, ptr %l508, !tbaa !27
  %t1448 = extractvalue { i64, ptr } %t1447, 0
  %t1449 = extractvalue { i64, ptr } %t1447, 1
  %t1450 = mul i64 %t1448, 1
  %t1451 = call ptr @__olang_scope_alloc(ptr %s69, i64 %t1450)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1451, ptr %t1449, i64 %t1450, i1 false)
  %t1452 = insertvalue { i64, ptr } undef, i64 %t1448, 0
  %t1453 = insertvalue { i64, ptr } %t1452, ptr %t1451, 1
  %t1455 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s69, { i64, ptr } %t1453)
  store { i64, ptr } %t1455, ptr %l510
  br label %bb320
bb320:
  %t1456 = load i64, ptr %l24, !tbaa !24
  %t1457 = load { i64, ptr }, ptr %l510, !tbaa !27
  %t1458 = extractvalue { i64, ptr } %t1457, 1
  %t1459 = extractvalue { i64, ptr } %t1457, 0
  %t1460 = extractvalue { i64, ptr } { i64 11, ptr @.d175 }, 1
  %t1461 = extractvalue { i64, ptr } { i64 11, ptr @.d175 }, 0
  %t1462 = add i64 %t1459, %t1461
  %t1464 = call i64 @__olang_fmt_i64(ptr null, i64 %t1456)
  %t1465 = add i64 %t1462, %t1464
  %t1466 = call ptr @__olang_scope_alloc(ptr %s69, i64 %t1465)
  call void @olang_textcopy(ptr %t1466, ptr %t1458, i64 %t1459)
  %t1467 = getelementptr i8, ptr %t1466, i64 %t1459
  call void @olang_textcopy(ptr %t1467, ptr %t1460, i64 %t1461)
  %t1468 = getelementptr i8, ptr %t1467, i64 %t1461
  %t1469 = call i64 @__olang_fmt_i64(ptr %t1468, i64 %t1456)
  %t1470 = insertvalue { i64, ptr } undef, i64 %t1465, 0
  %t1471 = insertvalue { i64, ptr } %t1470, ptr %t1466, 1
  %t1473 = extractvalue { i64, ptr } %t1471, 0
  %t1474 = extractvalue { i64, ptr } %t1471, 1
  %t1475 = mul i64 %t1473, 1
  %t1476 = call ptr @__olang_scope_alloc(ptr %s69, i64 %t1475)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1476, ptr %t1474, i64 %t1475, i1 false)
  %t1477 = insertvalue { i64, ptr } undef, i64 %t1473, 0
  %t1478 = insertvalue { i64, ptr } %t1477, ptr %t1476, 1
  %t1479 = load ptr, ptr %l498, !tbaa !29
  %t1480 = load i32, ptr %l504, !tbaa !23
  %t1481 = load i32, ptr %l505, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s69, ptr %t1479, i32 %t1480, i32 %t1481, { i64, ptr } %t1478)
  br label %bb321
bb321:
  call void @__olang_scope_close(ptr %s69)
  br label %bb322
bb322:
  %t1483 = load i64, ptr %l23, !tbaa !24
  %t1485 = add i64 %t1483, 1
  store i64 %t1485, ptr %l23, !tbaa !24
  br label %bb313
bb323:
  %t1487 = load i32, ptr %l1
  %t1489 = trunc i64 27 to i32
  %t1490 = icmp eq i32 %t1487, %t1489
  br i1 %t1490, label %bb324, label %bb325
bb324:
  %t1492 = load i32, ptr %l2, !tbaa !23
  %t1493 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1496 = icmp ne i32 %t1492, %t1493
  br i1 %t1496, label %bb326, label %bb327
bb325:
  %t1498 = load ptr, ptr %l0, !tbaa !29
  %t1499 = load i32, ptr %l18, !tbaa !23
  %t1500 = load i32, ptr %l2, !tbaa !23
  %t1504 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t1498, i32 %t1499, i32 %t1500)
  store i1 %t1504, ptr %l530
  br label %bb331
bb326:
  store %olang.scope zeroinitializer, ptr %s74
  %t1505 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1505, ptr %l521, !tbaa !29
  %t1506 = load ptr, ptr %l0, !tbaa !29
  %t1507 = load i32, ptr %l2, !tbaa !23
  %t1510 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s74, ptr %t1506, i32 %t1507)
  store { i64, ptr } %t1510, ptr %l524
  br label %bb328
bb327:
  br label %bb330
bb328:
  %t1511 = extractvalue { i64, ptr } { i64 18, ptr @.d176 }, 1
  %t1512 = extractvalue { i64, ptr } { i64 18, ptr @.d176 }, 0
  %t1513 = load { i64, ptr }, ptr %l524, !tbaa !27
  %t1514 = extractvalue { i64, ptr } %t1513, 1
  %t1515 = extractvalue { i64, ptr } %t1513, 0
  %t1516 = add i64 %t1512, %t1515
  %t1517 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1516)
  call void @olang_textcopy(ptr %t1517, ptr %t1511, i64 %t1512)
  %t1518 = getelementptr i8, ptr %t1517, i64 %t1512
  call void @olang_textcopy(ptr %t1518, ptr %t1514, i64 %t1515)
  %t1519 = insertvalue { i64, ptr } undef, i64 %t1516, 0
  %t1520 = insertvalue { i64, ptr } %t1519, ptr %t1517, 1
  %t1522 = extractvalue { i64, ptr } %t1520, 0
  %t1523 = extractvalue { i64, ptr } %t1520, 1
  %t1524 = mul i64 %t1522, 1
  %t1525 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1524)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1525, ptr %t1523, i64 %t1524, i1 false)
  %t1526 = insertvalue { i64, ptr } undef, i64 %t1522, 0
  %t1527 = insertvalue { i64, ptr } %t1526, ptr %t1525, 1
  %t1528 = load ptr, ptr %l521, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s74, ptr %t1528, { i64, ptr } %t1527)
  br label %bb329
bb329:
  call void @__olang_scope_close(ptr %s74)
  br label %bb330
bb330:
  br label %bb339
bb331:
  %t1530 = load i1, ptr %l530, !tbaa !21
  %t1531 = xor i1 %t1530, true
  br i1 %t1531, label %bb332, label %bb333
bb332:
  store %olang.scope zeroinitializer, ptr %s77
  %t1533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1533, ptr %l532, !tbaa !29
  %t1534 = load i32, ptr %l1
  store i32 %t1534, ptr %l533
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s78
  store ptr %s78room, ptr %s78
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s78, ptr %l533, i64 0)
  br label %bb334
bb333:
  br label %bb338
bb334:
  %t1536 = load ptr, ptr %s78
  %t1537 = getelementptr %olang.builder, ptr %s78, i32 0, i32 1
  %t1538 = load i64, ptr %t1537
  %t1539 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1538)
  call void @olang_textcopy(ptr %t1539, ptr %t1536, i64 %t1538)
  %t1540 = insertvalue { i64, ptr } undef, i64 %t1538, 0
  %t1541 = insertvalue { i64, ptr } %t1540, ptr %t1539, 1
  store { i64, ptr } %t1541, ptr %l535, !tbaa !27
  %t1542 = getelementptr %olang.builder, ptr %s78, i32 0, i32 3
  %t1543 = load ptr, ptr %t1542
  %t1544 = icmp ne ptr %t1543, null
  br i1 %t1544, label %sbgrew.1545, label %sbdone.1546
sbgrew.1545:
  call void @__olang_sb_done(ptr %s78)
  br label %sbdone.1546
sbdone.1546:
  %t1547 = load { i64, ptr }, ptr %l535, !tbaa !27
  %t1548 = extractvalue { i64, ptr } %t1547, 0
  %t1549 = extractvalue { i64, ptr } %t1547, 1
  %t1550 = mul i64 %t1548, 1
  %t1551 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1550)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1551, ptr %t1549, i64 %t1550, i1 false)
  %t1552 = insertvalue { i64, ptr } undef, i64 %t1548, 0
  %t1553 = insertvalue { i64, ptr } %t1552, ptr %t1551, 1
  %t1555 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s77, { i64, ptr } %t1553)
  store { i64, ptr } %t1555, ptr %l537
  br label %bb335
bb335:
  %t1556 = load ptr, ptr %l0, !tbaa !29
  %t1557 = load i32, ptr %l2, !tbaa !23
  %t1560 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s77, ptr %t1556, i32 %t1557)
  store { i64, ptr } %t1560, ptr %l540
  br label %bb336
bb336:
  %t1561 = load { i64, ptr }, ptr %l537, !tbaa !27
  %t1562 = extractvalue { i64, ptr } %t1561, 1
  %t1563 = extractvalue { i64, ptr } %t1561, 0
  %t1564 = extractvalue { i64, ptr } { i64 7, ptr @.d177 }, 1
  %t1565 = extractvalue { i64, ptr } { i64 7, ptr @.d177 }, 0
  %t1566 = add i64 %t1563, %t1565
  %t1567 = load { i64, ptr }, ptr %l540, !tbaa !27
  %t1568 = extractvalue { i64, ptr } %t1567, 1
  %t1569 = extractvalue { i64, ptr } %t1567, 0
  %t1570 = add i64 %t1566, %t1569
  %t1571 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1570)
  call void @olang_textcopy(ptr %t1571, ptr %t1562, i64 %t1563)
  %t1572 = getelementptr i8, ptr %t1571, i64 %t1563
  call void @olang_textcopy(ptr %t1572, ptr %t1564, i64 %t1565)
  %t1573 = getelementptr i8, ptr %t1572, i64 %t1565
  call void @olang_textcopy(ptr %t1573, ptr %t1568, i64 %t1569)
  %t1574 = insertvalue { i64, ptr } undef, i64 %t1570, 0
  %t1575 = insertvalue { i64, ptr } %t1574, ptr %t1571, 1
  %t1577 = extractvalue { i64, ptr } %t1575, 0
  %t1578 = extractvalue { i64, ptr } %t1575, 1
  %t1579 = mul i64 %t1577, 1
  %t1580 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1579)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1580, ptr %t1578, i64 %t1579, i1 false)
  %t1581 = insertvalue { i64, ptr } undef, i64 %t1577, 0
  %t1582 = insertvalue { i64, ptr } %t1581, ptr %t1580, 1
  %t1583 = load ptr, ptr %l532, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s77, ptr %t1583, { i64, ptr } %t1582)
  br label %bb337
bb337:
  call void @__olang_scope_close(ptr %s77)
  br label %bb338
bb338:
  br label %bb339
bb339:
  br label %bb340
bb340:
  br label %bb342
bb341:
  call void @__olang_check_failed(ptr @olang_loc_7968c2a45e42402b_522993cc8bbef1e7)
  unreachable
bb342:
  %t1585 = load i32, ptr %l2, !tbaa !23
  store i32 %t1585, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Range"
  %l7 = alloca i64
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store %"compiler/mir:Range" %a1, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/mir:verifier", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 12
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load %"compiler/mir:Range", ptr %l3
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s0, ptr %t11, %"compiler/mir:Range" %t12, i64 %t13, { i64, ptr } { i64 6, ptr @.d178 })
  store i1 %t14, ptr %l8
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueShape(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Place"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [1 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Place"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca %"compiler/mir:Range"
  %l15 = alloca %"compiler/mir:Range"
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t10, { i64, [4 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb62
bb5:
  %t14 = load { i64, [15 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [15 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t19, i32 0, i32 0
  %t21 = load %"compiler/mir:Place", ptr %t20
  store %"compiler/mir:Place" %t21, ptr %l3
  br label %bb12
bb7:
  %t23 = load { i64, [15 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [15 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { %"compiler/mir:Place" }, ptr %t28, i32 0, i32 0
  %t30 = load %"compiler/mir:Place", ptr %t29
  store %"compiler/mir:Place" %t30, ptr %l3
  br label %bb12
bb9:
  %t32 = load { i64, [15 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [15 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 5
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { %"compiler/mir:Place" }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/mir:Place", ptr %t38
  store %"compiler/mir:Place" %t39, ptr %l3
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/mir:Place", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t41, %"compiler/mir:Place" %t42)
  br label %bb13
bb13:
  br label %bb62
bb14:
  %t45 = load { i64, [15 x i64] }, ptr %l1
  %t47 = extractvalue { i64, [15 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 3
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t51 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t50, i32 0, i32 2
  %t52 = load %"compiler/mir:Range", ptr %t51
  store %"compiler/mir:Range" %t52, ptr %l4
  br label %bb21
bb16:
  %t54 = load { i64, [15 x i64] }, ptr %l1
  %t56 = extractvalue { i64, [15 x i64] } %t54, 0
  %t57 = icmp eq i64 %t56, 4
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t60 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t59, i32 0, i32 2
  %t61 = load %"compiler/mir:Range", ptr %t60
  store %"compiler/mir:Range" %t61, ptr %l4
  br label %bb21
bb18:
  %t63 = load { i64, [15 x i64] }, ptr %l1
  %t65 = extractvalue { i64, [15 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 6
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t69 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t68, i32 0, i32 2
  %t70 = load %"compiler/mir:Range", ptr %t69
  store %"compiler/mir:Range" %t70, ptr %l4
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load %"compiler/mir:Range", ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t72, %"compiler/mir:Range" %t73)
  br label %bb22
bb22:
  br label %bb62
bb23:
  %t76 = load { i64, [15 x i64] }, ptr %l1
  %t78 = extractvalue { i64, [15 x i64] } %t76, 0
  %t79 = icmp eq i64 %t78, 7
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t81 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t82 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t81, i32 0, i32 0
  %t83 = load { i64, [1 x i64] }, ptr %t82
  store { i64, [1 x i64] } %t83, ptr %l5
  %t85 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t86 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t85, i32 0, i32 1
  %t87 = load { i64, [4 x i64] }, ptr %t86
  store { i64, [4 x i64] } %t87, ptr %l6
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load { i64, [1 x i64] }, ptr %l5
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t89, { i64, [1 x i64] } %t90)
  br label %bb27
bb27:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t93, { i64, [4 x i64] } %t94)
  br label %bb28
bb28:
  br label %bb62
bb29:
  %t97 = load { i64, [15 x i64] }, ptr %l1
  %t99 = extractvalue { i64, [15 x i64] } %t97, 0
  %t100 = icmp eq i64 %t99, 8
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t102 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t103 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t102, i32 0, i32 0
  %t104 = load { i64, [1 x i64] }, ptr %t103
  store { i64, [1 x i64] } %t104, ptr %l7
  %t106 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t107 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t106, i32 0, i32 2
  %t108 = load { i64, [4 x i64] }, ptr %t107
  store { i64, [4 x i64] } %t108, ptr %l8
  %t110 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t111 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t110, i32 0, i32 3
  %t112 = load { i64, [4 x i64] }, ptr %t111
  store { i64, [4 x i64] } %t112, ptr %l9
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load { i64, [1 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t114, { i64, [1 x i64] } %t115)
  br label %bb33
bb33:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, [4 x i64] }, ptr %l8
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t118, { i64, [4 x i64] } %t119)
  br label %bb34
bb34:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, [4 x i64] }, ptr %l9
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t122, { i64, [4 x i64] } %t123)
  br label %bb35
bb35:
  br label %bb62
bb36:
  %t126 = load { i64, [15 x i64] }, ptr %l1
  %t128 = extractvalue { i64, [15 x i64] } %t126, 0
  %t129 = icmp eq i64 %t128, 9
  br i1 %t129, label %bb37, label %bb38
bb37:
  %t131 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t132 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t131, i32 0, i32 0
  %t133 = load %"compiler/mir:Place", ptr %t132
  store %"compiler/mir:Place" %t133, ptr %l10
  %t135 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t136 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t135, i32 0, i32 1
  %t137 = load { i64, [4 x i64] }, ptr %t136
  store { i64, [4 x i64] } %t137, ptr %l11
  %t139 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t140 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t139, i32 0, i32 2
  %t141 = load { i64, [4 x i64] }, ptr %t140
  store { i64, [4 x i64] } %t141, ptr %l12
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load %"compiler/mir:Place", ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t143, %"compiler/mir:Place" %t144)
  br label %bb40
bb40:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load { i64, [4 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t147, { i64, [4 x i64] } %t148)
  br label %bb41
bb41:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load { i64, [4 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t151, { i64, [4 x i64] } %t152)
  br label %bb42
bb42:
  br label %bb62
bb43:
  %t155 = load { i64, [15 x i64] }, ptr %l1
  %t157 = extractvalue { i64, [15 x i64] } %t155, 0
  %t158 = icmp eq i64 %t157, 10
  br i1 %t158, label %bb44, label %bb45
bb44:
  %t160 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t161 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t160, i32 0, i32 2
  %t162 = load { i64, [1 x i64] }, ptr %t161
  store { i64, [1 x i64] } %t162, ptr %l13
  %t164 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t165 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t164, i32 0, i32 3
  %t166 = load %"compiler/mir:Range", ptr %t165
  store %"compiler/mir:Range" %t166, ptr %l14
  %t168 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t169 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t168, i32 0, i32 4
  %t170 = load %"compiler/mir:Range", ptr %t169
  store %"compiler/mir:Range" %t170, ptr %l15
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load { i64, [1 x i64] }, ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t172, { i64, [1 x i64] } %t173)
  br label %bb47
bb47:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load %"compiler/mir:Range", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t176, %"compiler/mir:Range" %t177)
  br label %bb48
bb48:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load %"compiler/mir:Range", ptr %l15
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %t180, %"compiler/mir:Range" %t181)
  br label %bb49
bb49:
  br label %bb62
bb50:
  %t184 = load { i64, [15 x i64] }, ptr %l1
  %t186 = extractvalue { i64, [15 x i64] } %t184, 0
  %t187 = icmp eq i64 %t186, 11
  br i1 %t187, label %bb51, label %bb52
bb51:
  %t189 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t190 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t189, i32 0, i32 0
  %t191 = load { i64, [4 x i64] }, ptr %t190
  store { i64, [4 x i64] } %t191, ptr %l16
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, [4 x i64] }, ptr %l16
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t193, { i64, [4 x i64] } %t194)
  br label %bb54
bb54:
  br label %bb62
bb55:
  %t197 = load { i64, [15 x i64] }, ptr %l1
  %t199 = extractvalue { i64, [15 x i64] } %t197, 0
  %t200 = icmp eq i64 %t199, 12
  br i1 %t200, label %bb56, label %bb57
bb56:
  %t202 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t203 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t202, i32 0, i32 0
  %t204 = load { i64, [1 x i64] }, ptr %t203
  store { i64, [1 x i64] } %t204, ptr %l17
  %t206 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t207 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t206, i32 0, i32 1
  %t208 = load { i64, [1 x i64] }, ptr %t207
  store { i64, [1 x i64] } %t208, ptr %l18
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load { i64, [1 x i64] }, ptr %l17
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t210, { i64, [1 x i64] } %t211)
  br label %bb59
bb59:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load { i64, [1 x i64] }, ptr %l18
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t214, { i64, [1 x i64] } %t215)
  br label %bb60
bb60:
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_d06e38c3720099d6_401a7f863dec038a)
  unreachable
bb62:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i64
  %l10 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 8
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l4, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = extractvalue { i64, ptr } { i64 10, ptr @.d179 }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr @.d179 }, 0
  %t26 = sext i32 %t22 to i64
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t26)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } %t40)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb8:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esliceType(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i32
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca i32
  %l80 = alloca i1
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load i32, ptr %l16, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l5, !tbaa !29
  store ptr %t12, ptr %l17, !tbaa !29
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t14 = load i32, ptr %l4, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l20
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l17, !tbaa !29
  %t19 = load i32, ptr %l20, !tbaa !23
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t20, ptr %l21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l21, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l23, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l24, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l27
  br label %bb6
bb5:
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t29, ptr %l22, !tbaa !23
  br label %bb9
bb6:
  %t31 = load ptr, ptr %l24, !tbaa !29
  %t32 = load i32, ptr %l27, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t33, ptr %l28
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t35 = load i32, ptr %l28, !tbaa !23
  %t36 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l29
  br label %bb8
bb8:
  %t37 = load i32, ptr %l29, !tbaa !23
  store i32 %t37, ptr %l22, !tbaa !23
  br label %bb9
bb9:
  %t38 = load i32, ptr %l22, !tbaa !23
  store i32 %t38, ptr %l7, !tbaa !23
  %t39 = load i32, ptr %l6, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp eq i32 %t39, %t40
  br i1 %t43, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb12
bb11:
  %t45 = load i32, ptr %l7, !tbaa !23
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t49 = icmp eq i32 %t45, %t46
  store i1 %t49, ptr %l34, !tbaa !21
  br label %bb12
bb12:
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb20
bb14:
  %t52 = load ptr, ptr %l5, !tbaa !29
  store ptr %t52, ptr %l39, !tbaa !29
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l40, !tbaa !29
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t55 = load i32, ptr %l6, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l43
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l40, !tbaa !29
  %t60 = load i32, ptr %l43, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t61, ptr %l44
  br label %bb16
bb16:
  %t62 = load ptr, ptr %l5, !tbaa !29
  store ptr %t62, ptr %l45, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t64 = load i32, ptr %l7, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l48
  br label %bb17
bb17:
  %t68 = load ptr, ptr %l45, !tbaa !29
  %t69 = load i32, ptr %l48, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t70, ptr %l49
  br label %bb18
bb18:
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = load i32, ptr %l44, !tbaa !23
  %t73 = load i32, ptr %l49, !tbaa !23
  %t74 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t71, i32 %t72, i32 %t73)
  store i1 %t74, ptr %l50
  br label %bb19
bb19:
  %t75 = load i1, ptr %l50, !tbaa !21
  %t76 = xor i1 %t75, true
  store i1 %t76, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t78 = load i1, ptr %l38, !tbaa !21
  br i1 %t78, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s1
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l52, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l4, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t80, i32 %t81)
  store { i64, ptr } %t84, ptr %l55
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l1, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t85, i32 %t86)
  store { i64, ptr } %t89, ptr %l58
  br label %bb24
bb24:
  %t90 = extractvalue { i64, ptr } { i64 8, ptr @.d180 }, 1
  %t91 = extractvalue { i64, ptr } { i64 8, ptr @.d180 }, 0
  %t92 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 6, ptr @.d181 }, 1
  %t97 = extractvalue { i64, ptr } { i64 6, ptr @.d181 }, 0
  %t98 = add i64 %t95, %t97
  %t99 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = add i64 %t98, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t90, i64 %t91)
  %t104 = getelementptr i8, ptr %t103, i64 %t91
  call void @olang_textcopy(ptr %t104, ptr %t93, i64 %t94)
  %t105 = getelementptr i8, ptr %t104, i64 %t94
  call void @olang_textcopy(ptr %t105, ptr %t96, i64 %t97)
  %t106 = getelementptr i8, ptr %t105, i64 %t97
  call void @olang_textcopy(ptr %t106, ptr %t100, i64 %t101)
  %t107 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t103, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = extractvalue { i64, ptr } %t108, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t116 = load ptr, ptr %l52, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t116, { i64, ptr } %t115)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t121 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %a2, 0
  %t123 = insertvalue [2 x { i64, [4 x i64] }] %t121, { i64, [4 x i64] } %a3, 1
  %t125 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 80, i64 8)
  store [2 x { i64, [4 x i64] }] %t123, ptr %t125
  store ptr %t125, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t127 = load ptr, ptr %l8
  store i64 2, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t130 = load i64, ptr %l9, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb29:
  br label %bb30
bb30:
  %t138 = load ptr, ptr %l8
  %t139 = load i64, ptr %l9, !tbaa !24
  %t142 = getelementptr [2 x { i64, [4 x i64] }], ptr %t138, i64 0, i64 %t139
  %t143 = load { i64, [4 x i64] }, ptr %t142
  %t145 = load ptr, ptr %l5, !tbaa !29
  store ptr %t145, ptr %l74, !tbaa !29
  %t146 = load ptr, ptr %l5, !tbaa !29
  store ptr %t146, ptr %l75, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t151 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t147, { i64, [4 x i64] } %t143)
  store i32 %t151, ptr %l78
  br label %bb31
bb31:
  %t152 = load ptr, ptr %l75, !tbaa !29
  %t153 = load i32, ptr %l78, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t154, ptr %l79
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l74, !tbaa !29
  %t156 = load i32, ptr %l79, !tbaa !23
  %t157 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t155, i32 %t156)
  store i1 %t157, ptr %l80
  br label %bb33
bb33:
  %t158 = load i1, ptr %l80, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t161 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t161, { i64, ptr } { i64 34, ptr @.d182 })
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb38:
  %t163 = load i64, ptr %l9, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l9, !tbaa !24
  br label %bb27
bb39:
  call void @__olang_scope_close(ptr %s3)
  %t167 = load i32, ptr %l4, !tbaa !23
  store i32 %t167, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtFlow(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Place"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca %"compiler/mir:Place"
  %l17 = alloca %"compiler/mir:Place"
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca %"compiler/mir:Place"
  %l21 = alloca %"compiler/mir:Place"
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca %"compiler/mir:Task"
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l70 = alloca %"compiler/mir:Local"
  %l78 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca i1
  %l92 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca i64
  %l103 = alloca %"compiler/mir:Local"
  %l106 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca i1
  %l121 = alloca i64
  %l123 = alloca i32
  %l125 = alloca ptr
  %l128 = alloca i64
  %l130 = alloca i32
  %l136 = alloca %"compiler/mir:ScopeInfo"
  %l141 = alloca ptr
  %l142 = alloca i32
  %l145 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l159 = alloca i1
  %l167 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l176 = alloca i1
  %l185 = alloca %"compiler/mir:ScopeInfo"
  %l195 = alloca ptr
  %l196 = alloca i1
  %l207 = alloca ptr
  %l208 = alloca i1
  %l219 = alloca ptr
  %l220 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l239 = alloca ptr
  %l240 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca i1
  %l265 = alloca i1
  %l275 = alloca %"compiler/mir:Task"
  %l280 = alloca i32
  %l283 = alloca i32
  %l301 = alloca ptr
  %l309 = alloca %"compiler/mir:Place"
  %l320 = alloca i32
  %l323 = alloca i32
  %l341 = alloca ptr
  %l349 = alloca { i64, [1 x i64] }
  %l356 = alloca i32
  %l359 = alloca i32
  %l377 = alloca ptr
  %l385 = alloca %"compiler/mir:TaskClause"
  %l390 = alloca { i64, ptr }
  %l393 = alloca ptr
  %l394 = alloca i1
  %l397 = alloca ptr
  %l398 = alloca i1
  %l407 = alloca i1
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t7 = load ptr, ptr %l48, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l48, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l49, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l49, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t17, i32 0, i32 1
  %t19 = load %"compiler/mir:Place", ptr %t18
  store %"compiler/mir:Place" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t23, i32 0, i32 2
  %t25 = load { i64, [15 x i64] }, ptr %t24
  store { i64, [15 x i64] } %t25, ptr %l4
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, [15 x i64] }, ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueFlow(ptr %v0, ptr %t27, { i64, [15 x i64] } %t28)
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/mir:Place", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estores(ptr %v0, ptr %t31, %"compiler/mir:Place" %t32)
  br label %bb7
bb7:
  br label %bb192
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t36 = load ptr, ptr %l60, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l60, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 1
  store i1 %t42, ptr %l61, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l61, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [21 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32 }, ptr %t46, i32 0, i32 1
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/mir:Fn", ptr %t50, i32 0, i32 7
  %t53 = load i32, ptr %l5, !tbaa !23
  %t55 = sext i32 %t53 to i64
  %t58 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t52, i64 %t55)
  store %"compiler/mir:Local" %t58, ptr %l70
  br label %bb14
bb14:
  %t59 = getelementptr %"compiler/mir:Local", ptr %l70, i32 0, i32 4
  %t60 = load { i64, [1 x i64] }, ptr %t59
  store { i64, [1 x i64] } %t60, ptr %l6
  %t62 = load { i64, [1 x i64] }, ptr %l6
  %t64 = extractvalue { i64, [1 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 3
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load { i64, [1 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t69, { i64, [1 x i64] } %t70)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/mir:verifier", ptr %t73, i32 0, i32 15
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l78, !tbaa !27
  %t77 = load i32, ptr %l5, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t81 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i1, ptr %t82, i64 %t79
  store i1 true, ptr %t83, !tbaa !31
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/mir:verifier", ptr %t84, i32 0, i32 14
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l82, !tbaa !27
  %t88 = load i32, ptr %l5, !tbaa !23
  %t90 = sext i32 %t88 to i64
  %t92 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i1, ptr %t93, i64 %t90
  store i1 false, ptr %t94, !tbaa !31
  br label %bb192
bb19:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t96 = load ptr, ptr %l85, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb20, label %bb21
bb20:
  %t99 = load ptr, ptr %l85, !tbaa !29
  %t100 = load i64, ptr %t99
  %t102 = icmp eq i64 %t100, 2
  store i1 %t102, ptr %l86, !tbaa !21
  br label %bb21
bb21:
  %t103 = load i1, ptr %l86, !tbaa !21
  br i1 %t103, label %bb22, label %bb23
bb22:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [21 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32 }, ptr %t106, i32 0, i32 1
  %t108 = load i32, ptr %t107
  store i32 %t108, ptr %l7, !tbaa !23
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/mir:verifier", ptr %t110, i32 0, i32 14
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l92, !tbaa !27
  %t114 = load i32, ptr %l7, !tbaa !23
  %t116 = sext i32 %t114 to i64
  %t118 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i1, ptr %t119, i64 %t116
  store i1 false, ptr %t120, !tbaa !31
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/mir:verifier", ptr %t121, i32 0, i32 15
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l96, !tbaa !27
  %t125 = load i32, ptr %l7, !tbaa !23
  %t127 = sext i32 %t125 to i64
  store i64 %t127, ptr %l98, !tbaa !24
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t130 = getelementptr %"compiler/mir:Fn", ptr %t128, i32 0, i32 7
  %t131 = load i32, ptr %l7, !tbaa !23
  %t133 = sext i32 %t131 to i64
  %t136 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t130, i64 %t133)
  store %"compiler/mir:Local" %t136, ptr %l103
  br label %bb25
bb25:
  %t137 = getelementptr %"compiler/mir:Local", ptr %l103, i32 0, i32 4
  %t138 = load { i64, [1 x i64] }, ptr %t137
  %t140 = extractvalue { i64, [1 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 3
  %t143 = load i64, ptr %l98, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i1, ptr %t145, i64 %t143
  store i1 %t141, ptr %t146, !tbaa !31
  br label %bb192
bb26:
  %t147 = load ptr, ptr %l1, !tbaa !29
  store ptr %t147, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t148 = load ptr, ptr %l106, !tbaa !29
  %t149 = icmp ne ptr %t148, null
  br i1 %t149, label %bb27, label %bb28
bb27:
  %t151 = load ptr, ptr %l106, !tbaa !29
  %t152 = load i64, ptr %t151
  %t154 = icmp eq i64 %t152, 3
  store i1 %t154, ptr %l107, !tbaa !21
  br label %bb28
bb28:
  %t155 = load i1, ptr %l107, !tbaa !21
  br i1 %t155, label %bb29, label %bb30
bb29:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr { i64, [21 x i64] }, ptr %t156, i32 0, i32 1
  %t159 = getelementptr { %"compiler/source:Span", i32 }, ptr %t158, i32 0, i32 1
  %t160 = load i32, ptr %t159
  store i32 %t160, ptr %l8, !tbaa !23
  br label %bb31
bb30:
  br label %bb51
bb31:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l8, !tbaa !23
  %t166 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t162, i32 %t163)
  store i1 %t166, ptr %l114
  br label %bb32
bb32:
  %t167 = load i1, ptr %l114, !tbaa !21
  br i1 %t167, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l8, !tbaa !23
  %t170 = extractvalue { i64, ptr } { i64 1, ptr @.d183 }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr @.d183 }, 0
  %t173 = sext i32 %t169 to i64
  %t174 = call i64 @__olang_fmt_i64(ptr null, i64 %t173)
  %t175 = add i64 %t171, %t174
  %t176 = extractvalue { i64, ptr } { i64 24, ptr @.d184 }, 1
  %t177 = extractvalue { i64, ptr } { i64 24, ptr @.d184 }, 0
  %t178 = add i64 %t175, %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t170, i64 %t171)
  %t180 = getelementptr i8, ptr %t179, i64 %t171
  %t181 = call i64 @__olang_fmt_i64(ptr %t180, i64 %t173)
  %t182 = getelementptr i8, ptr %t180, i64 %t174
  call void @olang_textcopy(ptr %t182, ptr %t176, i64 %t177)
  %t183 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t179, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = extractvalue { i64, ptr } %t184, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s6, ptr %t168, { i64, ptr } %t191)
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb36:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/mir:verifier", ptr %t194, i32 0, i32 17
  %t198 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t196)
  store i64 %t198, ptr %l121
  br label %bb37
bb37:
  %t199 = load i64, ptr %l121, !tbaa !24
  %t200 = icmp sgt i64 %t199, 0
  br i1 %t200, label %bb38, label %bb39
bb38:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/mir:verifier", ptr %t202, i32 0, i32 17
  store ptr %t204, ptr %l125, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/mir:verifier", ptr %t205, i32 0, i32 17
  %t209 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t207)
  store i64 %t209, ptr %l128
  br label %bb40
bb39:
  %t210 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  store i32 %t210, ptr %l123, !tbaa !23
  br label %bb42
bb40:
  %t212 = load i64, ptr %l128, !tbaa !24
  %t213 = sub i64 %t212, 1
  %t214 = load ptr, ptr %l125, !tbaa !29
  %t216 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t214, i64 %t213)
  store i32 %t216, ptr %l130
  br label %bb41
bb41:
  %t217 = load i32, ptr %l130, !tbaa !23
  store i32 %t217, ptr %l123, !tbaa !23
  br label %bb42
bb42:
  %t218 = load i32, ptr %l123, !tbaa !23
  store i32 %t218, ptr %l9, !tbaa !23
  %t219 = load ptr, ptr %l2, !tbaa !29
  %t221 = getelementptr %"compiler/mir:Fn", ptr %t219, i32 0, i32 8
  %t222 = load i32, ptr %l8, !tbaa !23
  %t224 = sext i32 %t222 to i64
  %t227 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t221, i64 %t224)
  store %"compiler/mir:ScopeInfo" %t227, ptr %l136
  br label %bb43
bb43:
  %t228 = getelementptr %"compiler/mir:ScopeInfo", ptr %l136, i32 0, i32 1
  %t229 = load i32, ptr %t228, !tbaa !23
  store i32 %t229, ptr %l10, !tbaa !23
  %t231 = load i32, ptr %l10, !tbaa !23
  %t232 = load i32, ptr %l9, !tbaa !23
  %t235 = icmp ne i32 %t231, %t232
  br i1 %t235, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l141, !tbaa !29
  %t238 = load i32, ptr %l8, !tbaa !23
  store i32 %t238, ptr %l142, !tbaa !23
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l9, !tbaa !23
  %t243 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %s8, ptr %t239, i32 %t240)
  store { i64, ptr } %t243, ptr %l145
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i32, ptr %l10, !tbaa !23
  %t248 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %s8, ptr %t244, i32 %t245)
  store { i64, ptr } %t248, ptr %l148
  br label %bb47
bb47:
  %t249 = extractvalue { i64, ptr } { i64 1, ptr @.d185 }, 1
  %t250 = extractvalue { i64, ptr } { i64 1, ptr @.d185 }, 0
  %t251 = load i32, ptr %l142, !tbaa !23
  %t252 = sext i32 %t251 to i64
  %t253 = call i64 @__olang_fmt_i64(ptr null, i64 %t252)
  %t254 = add i64 %t250, %t253
  %t255 = extractvalue { i64, ptr } { i64 11, ptr @.d186 }, 1
  %t256 = extractvalue { i64, ptr } { i64 11, ptr @.d186 }, 0
  %t257 = add i64 %t254, %t256
  %t258 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = add i64 %t257, %t260
  %t262 = extractvalue { i64, ptr } { i64 20, ptr @.d187 }, 1
  %t263 = extractvalue { i64, ptr } { i64 20, ptr @.d187 }, 0
  %t264 = add i64 %t261, %t263
  %t265 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = add i64 %t264, %t267
  %t269 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t268)
  call void @olang_textcopy(ptr %t269, ptr %t249, i64 %t250)
  %t270 = getelementptr i8, ptr %t269, i64 %t250
  %t271 = call i64 @__olang_fmt_i64(ptr %t270, i64 %t252)
  %t272 = getelementptr i8, ptr %t270, i64 %t253
  call void @olang_textcopy(ptr %t272, ptr %t255, i64 %t256)
  %t273 = getelementptr i8, ptr %t272, i64 %t256
  call void @olang_textcopy(ptr %t273, ptr %t259, i64 %t260)
  %t274 = getelementptr i8, ptr %t273, i64 %t260
  call void @olang_textcopy(ptr %t274, ptr %t262, i64 %t263)
  %t275 = getelementptr i8, ptr %t274, i64 %t263
  call void @olang_textcopy(ptr %t275, ptr %t266, i64 %t267)
  %t276 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t269, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = extractvalue { i64, ptr } %t277, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  %t285 = load ptr, ptr %l141, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t285, { i64, ptr } %t284)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb49:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/mir:verifier", ptr %t287, i32 0, i32 17
  %t290 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t289, i32 %t290)
  br label %bb50
bb50:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/mir:verifier", ptr %t293, i32 0, i32 16
  %t296 = load { i64, ptr }, ptr %t295, !tbaa !27
  store { i64, ptr } %t296, ptr %l155, !tbaa !27
  %t297 = load i32, ptr %l8, !tbaa !23
  %t299 = sext i32 %t297 to i64
  %t301 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr i1, ptr %t302, i64 %t299
  store i1 false, ptr %t303, !tbaa !31
  br label %bb192
bb51:
  %t304 = load ptr, ptr %l1, !tbaa !29
  store ptr %t304, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t305 = load ptr, ptr %l158, !tbaa !29
  %t306 = icmp ne ptr %t305, null
  br i1 %t306, label %bb52, label %bb53
bb52:
  %t308 = load ptr, ptr %l158, !tbaa !29
  %t309 = load i64, ptr %t308
  %t311 = icmp eq i64 %t309, 4
  store i1 %t311, ptr %l159, !tbaa !21
  br label %bb53
bb53:
  %t312 = load i1, ptr %l159, !tbaa !21
  br i1 %t312, label %bb54, label %bb55
bb54:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [21 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", i32 }, ptr %t315, i32 0, i32 1
  %t317 = load i32, ptr %t316
  store i32 %t317, ptr %l11, !tbaa !23
  br label %bb56
bb55:
  br label %bb62
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %s10, ptr %t319, i32 %t320, { i64, ptr } { i64 6, ptr @.d188 })
  br label %bb57
bb57:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/mir:verifier", ptr %t323, i32 0, i32 16
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l167, !tbaa !27
  %t327 = load i32, ptr %l11, !tbaa !23
  %t329 = sext i32 %t327 to i64
  %t331 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr i1, ptr %t332, i64 %t329
  %t334 = load i1, ptr %t333, !tbaa !31
  br i1 %t334, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i32, ptr %l11, !tbaa !23
  %t338 = extractvalue { i64, ptr } { i64 6, ptr @.d189 }, 1
  %t339 = extractvalue { i64, ptr } { i64 6, ptr @.d189 }, 0
  %t341 = sext i32 %t337 to i64
  %t342 = call i64 @__olang_fmt_i64(ptr null, i64 %t341)
  %t343 = add i64 %t339, %t342
  %t344 = extractvalue { i64, ptr } { i64 33, ptr @.d190 }, 1
  %t345 = extractvalue { i64, ptr } { i64 33, ptr @.d190 }, 0
  %t346 = add i64 %t343, %t345
  %t347 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t346)
  call void @olang_textcopy(ptr %t347, ptr %t338, i64 %t339)
  %t348 = getelementptr i8, ptr %t347, i64 %t339
  %t349 = call i64 @__olang_fmt_i64(ptr %t348, i64 %t341)
  %t350 = getelementptr i8, ptr %t348, i64 %t342
  call void @olang_textcopy(ptr %t350, ptr %t344, i64 %t345)
  %t351 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t347, 1
  %t354 = extractvalue { i64, ptr } %t352, 0
  %t355 = extractvalue { i64, ptr } %t352, 1
  %t356 = mul i64 %t354, 1
  %t357 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t356)
  call void @llvm.memcpy.p0.p0.i64(ptr %t357, ptr %t355, i64 %t356, i1 false)
  %t358 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t336, { i64, ptr } %t359)
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s11)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  br label %bb192
bb62:
  %t362 = load ptr, ptr %l1, !tbaa !29
  store ptr %t362, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t363 = load ptr, ptr %l175, !tbaa !29
  %t364 = icmp ne ptr %t363, null
  br i1 %t364, label %bb63, label %bb64
bb63:
  %t366 = load ptr, ptr %l175, !tbaa !29
  %t367 = load i64, ptr %t366
  %t369 = icmp eq i64 %t367, 5
  store i1 %t369, ptr %l176, !tbaa !21
  br label %bb64
bb64:
  %t370 = load i1, ptr %l176, !tbaa !21
  br i1 %t370, label %bb65, label %bb66
bb65:
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [21 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", i32 }, ptr %t373, i32 0, i32 1
  %t375 = load i32, ptr %t374
  store i32 %t375, ptr %l12, !tbaa !23
  br label %bb67
bb66:
  br label %bb74
bb67:
  store %olang.scope zeroinitializer, ptr %s13
  %t377 = load ptr, ptr %l2, !tbaa !29
  %t379 = getelementptr %"compiler/mir:Fn", ptr %t377, i32 0, i32 8
  %t380 = load i32, ptr %l12, !tbaa !23
  %t382 = sext i32 %t380 to i64
  %t385 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t379, i64 %t382)
  store %"compiler/mir:ScopeInfo" %t385, ptr %l185
  br label %bb68
bb68:
  %t386 = getelementptr %"compiler/mir:ScopeInfo", ptr %l185, i32 0, i32 0
  %t387 = load i32, ptr %t386
  %t389 = trunc i64 4 to i32
  %t390 = icmp eq i32 %t387, %t389
  %t392 = xor i1 %t390, true
  br i1 %t392, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s14
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load i32, ptr %l12, !tbaa !23
  %t396 = extractvalue { i64, ptr } { i64 1, ptr @.d191 }, 1
  %t397 = extractvalue { i64, ptr } { i64 1, ptr @.d191 }, 0
  %t399 = sext i32 %t395 to i64
  %t400 = call i64 @__olang_fmt_i64(ptr null, i64 %t399)
  %t401 = add i64 %t397, %t400
  %t402 = extractvalue { i64, ptr } { i64 32, ptr @.d192 }, 1
  %t403 = extractvalue { i64, ptr } { i64 32, ptr @.d192 }, 0
  %t404 = add i64 %t401, %t403
  %t405 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t404)
  call void @olang_textcopy(ptr %t405, ptr %t396, i64 %t397)
  %t406 = getelementptr i8, ptr %t405, i64 %t397
  %t407 = call i64 @__olang_fmt_i64(ptr %t406, i64 %t399)
  %t408 = getelementptr i8, ptr %t406, i64 %t400
  call void @olang_textcopy(ptr %t408, ptr %t402, i64 %t403)
  %t409 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t405, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = extractvalue { i64, ptr } %t410, 1
  %t414 = mul i64 %t412, 1
  %t415 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t414)
  call void @llvm.memcpy.p0.p0.i64(ptr %t415, ptr %t413, i64 %t414, i1 false)
  %t416 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t415, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s14, ptr %t394, { i64, ptr } %t417)
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s14)
  br label %bb72
bb72:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %s13, ptr %t420, i32 %t421, { i64, ptr } { i64 10, ptr @.d193 })
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s13)
  br label %bb192
bb74:
  %t424 = load ptr, ptr %l1, !tbaa !29
  store ptr %t424, ptr %l195, !tbaa !29
  store i1 false, ptr %l196, !tbaa !21
  %t425 = load ptr, ptr %l195, !tbaa !29
  %t426 = icmp ne ptr %t425, null
  br i1 %t426, label %bb75, label %bb76
bb75:
  %t428 = load ptr, ptr %l195, !tbaa !29
  %t429 = load i64, ptr %t428
  %t431 = icmp eq i64 %t429, 6
  store i1 %t431, ptr %l196, !tbaa !21
  br label %bb76
bb76:
  %t432 = load i1, ptr %l196, !tbaa !21
  br i1 %t432, label %bb77, label %bb78
bb77:
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t435 = getelementptr { i64, [21 x i64] }, ptr %t433, i32 0, i32 1
  %t436 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t435, i32 0, i32 1
  %t437 = load { i64, [1 x i64] }, ptr %t436
  store { i64, [1 x i64] } %t437, ptr %l13
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr { i64, [21 x i64] }, ptr %t439, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t441, i32 0, i32 3
  %t443 = load { i64, [4 x i64] }, ptr %t442
  store { i64, [4 x i64] } %t443, ptr %l14
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load { i64, [1 x i64] }, ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t445, { i64, [1 x i64] } %t446)
  br label %bb80
bb80:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t450 = load { i64, [4 x i64] }, ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t449, { i64, [4 x i64] } %t450)
  br label %bb81
bb81:
  br label %bb192
bb82:
  %t453 = load ptr, ptr %l1, !tbaa !29
  store ptr %t453, ptr %l207, !tbaa !29
  store i1 false, ptr %l208, !tbaa !21
  %t454 = load ptr, ptr %l207, !tbaa !29
  %t455 = icmp ne ptr %t454, null
  br i1 %t455, label %bb83, label %bb84
bb83:
  %t457 = load ptr, ptr %l207, !tbaa !29
  %t458 = load i64, ptr %t457
  %t460 = icmp eq i64 %t458, 7
  store i1 %t460, ptr %l208, !tbaa !21
  br label %bb84
bb84:
  %t461 = load i1, ptr %l208, !tbaa !21
  br i1 %t461, label %bb85, label %bb86
bb85:
  %t462 = load ptr, ptr %l1, !tbaa !29
  %t464 = getelementptr { i64, [21 x i64] }, ptr %t462, i32 0, i32 1
  %t465 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t464, i32 0, i32 1
  %t466 = load { i64, [1 x i64] }, ptr %t465
  store { i64, [1 x i64] } %t466, ptr %l15
  %t468 = load ptr, ptr %l1, !tbaa !29
  %t470 = getelementptr { i64, [21 x i64] }, ptr %t468, i32 0, i32 1
  %t471 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t470, i32 0, i32 2
  %t472 = load %"compiler/mir:Place", ptr %t471
  store %"compiler/mir:Place" %t472, ptr %l16
  br label %bb87
bb86:
  br label %bb90
bb87:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load { i64, [1 x i64] }, ptr %l15
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t474, { i64, [1 x i64] } %t475)
  br label %bb88
bb88:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/mir:Place", ptr %l16
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t478, %"compiler/mir:Place" %t479)
  br label %bb89
bb89:
  br label %bb192
bb90:
  %t482 = load ptr, ptr %l1, !tbaa !29
  store ptr %t482, ptr %l219, !tbaa !29
  store i1 false, ptr %l220, !tbaa !21
  %t483 = load ptr, ptr %l219, !tbaa !29
  %t484 = icmp ne ptr %t483, null
  br i1 %t484, label %bb91, label %bb92
bb91:
  %t486 = load ptr, ptr %l219, !tbaa !29
  %t487 = load i64, ptr %t486
  %t489 = icmp eq i64 %t487, 8
  store i1 %t489, ptr %l220, !tbaa !21
  br label %bb92
bb92:
  %t490 = load i1, ptr %l220, !tbaa !21
  br i1 %t490, label %bb93, label %bb94
bb93:
  %t491 = load ptr, ptr %l1, !tbaa !29
  %t493 = getelementptr { i64, [21 x i64] }, ptr %t491, i32 0, i32 1
  %t494 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place" }, ptr %t493, i32 0, i32 1
  %t495 = load %"compiler/mir:Place", ptr %t494
  store %"compiler/mir:Place" %t495, ptr %l17
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load %"compiler/mir:Place", ptr %l17
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t497, %"compiler/mir:Place" %t498)
  br label %bb96
bb96:
  br label %bb192
bb97:
  %t501 = load ptr, ptr %l1, !tbaa !29
  store ptr %t501, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t502 = load ptr, ptr %l227, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb98, label %bb99
bb98:
  %t505 = load ptr, ptr %l227, !tbaa !29
  %t506 = load i64, ptr %t505
  %t508 = icmp eq i64 %t506, 9
  store i1 %t508, ptr %l228, !tbaa !21
  br label %bb99
bb99:
  %t509 = load i1, ptr %l228, !tbaa !21
  br i1 %t509, label %bb100, label %bb101
bb100:
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [21 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t512, i32 0, i32 1
  %t514 = load { i64, [1 x i64] }, ptr %t513
  store { i64, [1 x i64] } %t514, ptr %l18
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr { i64, [21 x i64] }, ptr %t516, i32 0, i32 1
  %t519 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t518, i32 0, i32 3
  %t520 = load { i64, [4 x i64] }, ptr %t519
  store { i64, [4 x i64] } %t520, ptr %l19
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load { i64, [1 x i64] }, ptr %l18
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t522, { i64, [1 x i64] } %t523)
  br label %bb103
bb103:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load { i64, [4 x i64] }, ptr %l19
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t526, { i64, [4 x i64] } %t527)
  br label %bb104
bb104:
  br label %bb192
bb105:
  %t530 = load ptr, ptr %l1, !tbaa !29
  store ptr %t530, ptr %l239, !tbaa !29
  store i1 false, ptr %l240, !tbaa !21
  %t531 = load ptr, ptr %l239, !tbaa !29
  %t532 = icmp ne ptr %t531, null
  br i1 %t532, label %bb106, label %bb107
bb106:
  %t534 = load ptr, ptr %l239, !tbaa !29
  %t535 = load i64, ptr %t534
  %t537 = icmp eq i64 %t535, 10
  store i1 %t537, ptr %l240, !tbaa !21
  br label %bb107
bb107:
  %t538 = load i1, ptr %l240, !tbaa !21
  br i1 %t538, label %bb108, label %bb109
bb108:
  %t539 = load ptr, ptr %l1, !tbaa !29
  %t541 = getelementptr { i64, [21 x i64] }, ptr %t539, i32 0, i32 1
  %t542 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t541, i32 0, i32 1
  %t543 = load %"compiler/mir:Place", ptr %t542
  store %"compiler/mir:Place" %t543, ptr %l20
  %t545 = load ptr, ptr %l1, !tbaa !29
  %t547 = getelementptr { i64, [21 x i64] }, ptr %t545, i32 0, i32 1
  %t548 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t547, i32 0, i32 2
  %t549 = load %"compiler/mir:Place", ptr %t548
  store %"compiler/mir:Place" %t549, ptr %l21
  %t551 = load ptr, ptr %l1, !tbaa !29
  %t553 = getelementptr { i64, [21 x i64] }, ptr %t551, i32 0, i32 1
  %t554 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t553, i32 0, i32 3
  %t555 = load { i64, [4 x i64] }, ptr %t554
  store { i64, [4 x i64] } %t555, ptr %l22
  br label %bb110
bb109:
  br label %bb114
bb110:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load %"compiler/mir:Place", ptr %l21
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t557, %"compiler/mir:Place" %t558)
  br label %bb111
bb111:
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t562 = load { i64, [4 x i64] }, ptr %l22
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t561, { i64, [4 x i64] } %t562)
  br label %bb112
bb112:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load %"compiler/mir:Place", ptr %l20
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t565, %"compiler/mir:Place" %t566)
  br label %bb113
bb113:
  br label %bb192
bb114:
  %t569 = load ptr, ptr %l1, !tbaa !29
  store ptr %t569, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t570 = load ptr, ptr %l255, !tbaa !29
  %t571 = icmp ne ptr %t570, null
  br i1 %t571, label %bb115, label %bb116
bb115:
  %t573 = load ptr, ptr %l255, !tbaa !29
  %t574 = load i64, ptr %t573
  %t576 = icmp eq i64 %t574, 11
  store i1 %t576, ptr %l256, !tbaa !21
  br label %bb116
bb116:
  %t577 = load i1, ptr %l256, !tbaa !21
  br i1 %t577, label %bb117, label %bb118
bb117:
  %t578 = load ptr, ptr %l1, !tbaa !29
  %t580 = getelementptr { i64, [21 x i64] }, ptr %t578, i32 0, i32 1
  %t581 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t580, i32 0, i32 1
  %t582 = load i32, ptr %t581
  store i32 %t582, ptr %l23, !tbaa !23
  %t584 = load ptr, ptr %l1, !tbaa !29
  %t586 = getelementptr { i64, [21 x i64] }, ptr %t584, i32 0, i32 1
  %t587 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t586, i32 0, i32 2
  %t588 = load i32, ptr %t587
  store i32 %t588, ptr %l24, !tbaa !23
  br label %bb119
bb118:
  br label %bb170
bb119:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load i32, ptr %l23, !tbaa !23
  %t594 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t590, i32 %t591)
  store i1 %t594, ptr %l265
  br label %bb120
bb120:
  %t595 = load i1, ptr %l265, !tbaa !21
  %t596 = xor i1 %t595, true
  br i1 %t596, label %bb121, label %bb122
bb121:
  store %olang.scope zeroinitializer, ptr %s22
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load i32, ptr %l23, !tbaa !23
  %t600 = extractvalue { i64, ptr } { i64 14, ptr @.d194 }, 1
  %t601 = extractvalue { i64, ptr } { i64 14, ptr @.d194 }, 0
  %t603 = sext i32 %t599 to i64
  %t604 = call i64 @__olang_fmt_i64(ptr null, i64 %t603)
  %t605 = add i64 %t601, %t604
  %t606 = extractvalue { i64, ptr } { i64 19, ptr @.d195 }, 1
  %t607 = extractvalue { i64, ptr } { i64 19, ptr @.d195 }, 0
  %t608 = add i64 %t605, %t607
  %t609 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t608)
  call void @olang_textcopy(ptr %t609, ptr %t600, i64 %t601)
  %t610 = getelementptr i8, ptr %t609, i64 %t601
  %t611 = call i64 @__olang_fmt_i64(ptr %t610, i64 %t603)
  %t612 = getelementptr i8, ptr %t610, i64 %t604
  call void @olang_textcopy(ptr %t612, ptr %t606, i64 %t607)
  %t613 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t614 = insertvalue { i64, ptr } %t613, ptr %t609, 1
  %t616 = extractvalue { i64, ptr } %t614, 0
  %t617 = extractvalue { i64, ptr } %t614, 1
  %t618 = mul i64 %t616, 1
  %t619 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t618)
  call void @llvm.memcpy.p0.p0.i64(ptr %t619, ptr %t617, i64 %t618, i1 false)
  %t620 = insertvalue { i64, ptr } undef, i64 %t616, 0
  %t621 = insertvalue { i64, ptr } %t620, ptr %t619, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s22, ptr %t598, { i64, ptr } %t621)
  br label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_scope_close(ptr %s22)
  br label %bb124
bb124:
  %t624 = load ptr, ptr %l2, !tbaa !29
  %t626 = getelementptr %"compiler/mir:Fn", ptr %t624, i32 0, i32 16
  %t627 = load i32, ptr %l24, !tbaa !23
  %t629 = sext i32 %t627 to i64
  %t632 = call %"compiler/mir:Task" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t626, i64 %t629)
  store %"compiler/mir:Task" %t632, ptr %l275
  br label %bb125
bb125:
  %t633 = load %"compiler/mir:Task", ptr %l275
  store %"compiler/mir:Task" %t633, ptr %l25
  store i32 0, ptr %l26, !tbaa !23
  %t634 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 3
  %t635 = getelementptr %"compiler/mir:Range", ptr %t634, i32 0, i32 1
  %t636 = load i32, ptr %t635, !tbaa !23
  store i32 %t636, ptr %l27, !tbaa !23
  store i32 1, ptr %l28, !tbaa !23
  %t638 = load i32, ptr %l27, !tbaa !23
  %t639 = load i32, ptr %l26, !tbaa !23
  %t642 = icmp sgt i32 %t638, %t639
  br i1 %t642, label %bb126, label %bb127
bb126:
  %t644 = load i32, ptr %l28, !tbaa !23
  %t646 = icmp sgt i32 %t644, 0
  br i1 %t646, label %bb128, label %bb129
bb127:
  store i32 0, ptr %l280, !tbaa !23
  br label %bb131
bb128:
  %t648 = load i32, ptr %l27, !tbaa !23
  %t649 = load i32, ptr %l26, !tbaa !23
  %t652 = sub i32 %t648, %t649
  %t653 = load i32, ptr %l28, !tbaa !23
  %t656 = add i32 %t652, %t653
  %t658 = sub i32 %t656, 1
  %t659 = load i32, ptr %l28, !tbaa !23
  %t662 = sdiv i32 %t658, %t659
  store i32 %t662, ptr %l283, !tbaa !23
  br label %bb130
bb129:
  store i32 0, ptr %l283, !tbaa !23
  br label %bb130
bb130:
  %t664 = load i32, ptr %l283, !tbaa !23
  store i32 %t664, ptr %l280, !tbaa !23
  br label %bb131
bb131:
  %t665 = load i32, ptr %l280, !tbaa !23
  store i32 %t665, ptr %l29, !tbaa !23
  store i32 0, ptr %l30, !tbaa !23
  br label %bb132
bb132:
  store %olang.scope zeroinitializer, ptr %s25
  %t666 = load i32, ptr %l30, !tbaa !23
  %t667 = load i32, ptr %l29, !tbaa !23
  %t670 = icmp slt i32 %t666, %t667
  %t672 = xor i1 %t670, true
  br i1 %t672, label %bb133, label %bb134
bb133:
  call void @__olang_scope_close(ptr %s25)
  br label %bb139
bb134:
  br label %bb135
bb135:
  %t674 = load i32, ptr %l26, !tbaa !23
  %t675 = load i32, ptr %l30, !tbaa !23
  %t676 = load i32, ptr %l28, !tbaa !23
  %t679 = mul i32 %t675, %t676
  %t682 = add i32 %t674, %t679
  %t684 = load ptr, ptr %l0, !tbaa !29
  store ptr %t684, ptr %l301, !tbaa !29
  %t685 = load ptr, ptr %l2, !tbaa !29
  %t687 = getelementptr %"compiler/mir:Fn", ptr %t685, i32 0, i32 13
  %t688 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 3
  %t689 = getelementptr %"compiler/mir:Range", ptr %t688, i32 0, i32 0
  %t690 = load i32, ptr %t689, !tbaa !23
  %t692 = sext i32 %t690 to i64
  %t695 = sext i32 %t682 to i64
  %t698 = add i64 %t692, %t695
  %t701 = call %"compiler/mir:Place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t687, i64 %t698)
  store %"compiler/mir:Place" %t701, ptr %l309
  br label %bb136
bb136:
  %t702 = load ptr, ptr %l301, !tbaa !29
  %t703 = load %"compiler/mir:Place", ptr %l309
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t702, %"compiler/mir:Place" %t703)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s25)
  br label %bb138
bb138:
  %t704 = load i32, ptr %l30, !tbaa !23
  %t706 = add i32 %t704, 1
  store i32 %t706, ptr %l30, !tbaa !23
  br label %bb132
bb139:
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t709 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 0
  %t710 = load { i64, [5 x i64] }, ptr %t709
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %t708, { i64, [5 x i64] } %t710)
  br label %bb140
bb140:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 1
  %t715 = load %"compiler/mir:Range", ptr %t714
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t713, %"compiler/mir:Range" %t715)
  br label %bb141
bb141:
  store i32 0, ptr %l32, !tbaa !23
  %t718 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 2
  %t719 = getelementptr %"compiler/mir:Range", ptr %t718, i32 0, i32 1
  %t720 = load i32, ptr %t719, !tbaa !23
  store i32 %t720, ptr %l33, !tbaa !23
  store i32 1, ptr %l34, !tbaa !23
  %t722 = load i32, ptr %l33, !tbaa !23
  %t723 = load i32, ptr %l32, !tbaa !23
  %t726 = icmp sgt i32 %t722, %t723
  br i1 %t726, label %bb142, label %bb143
bb142:
  %t728 = load i32, ptr %l34, !tbaa !23
  %t730 = icmp sgt i32 %t728, 0
  br i1 %t730, label %bb144, label %bb145
bb143:
  store i32 0, ptr %l320, !tbaa !23
  br label %bb147
bb144:
  %t732 = load i32, ptr %l33, !tbaa !23
  %t733 = load i32, ptr %l32, !tbaa !23
  %t736 = sub i32 %t732, %t733
  %t737 = load i32, ptr %l34, !tbaa !23
  %t740 = add i32 %t736, %t737
  %t742 = sub i32 %t740, 1
  %t743 = load i32, ptr %l34, !tbaa !23
  %t746 = sdiv i32 %t742, %t743
  store i32 %t746, ptr %l323, !tbaa !23
  br label %bb146
bb145:
  store i32 0, ptr %l323, !tbaa !23
  br label %bb146
bb146:
  %t748 = load i32, ptr %l323, !tbaa !23
  store i32 %t748, ptr %l320, !tbaa !23
  br label %bb147
bb147:
  %t749 = load i32, ptr %l320, !tbaa !23
  store i32 %t749, ptr %l35, !tbaa !23
  store i32 0, ptr %l36, !tbaa !23
  br label %bb148
bb148:
  store %olang.scope zeroinitializer, ptr %s28
  %t750 = load i32, ptr %l36, !tbaa !23
  %t751 = load i32, ptr %l35, !tbaa !23
  %t754 = icmp slt i32 %t750, %t751
  %t756 = xor i1 %t754, true
  br i1 %t756, label %bb149, label %bb150
bb149:
  call void @__olang_scope_close(ptr %s28)
  br label %bb155
bb150:
  br label %bb151
bb151:
  %t758 = load i32, ptr %l32, !tbaa !23
  %t759 = load i32, ptr %l36, !tbaa !23
  %t760 = load i32, ptr %l34, !tbaa !23
  %t763 = mul i32 %t759, %t760
  %t766 = add i32 %t758, %t763
  %t768 = load ptr, ptr %l0, !tbaa !29
  store ptr %t768, ptr %l341, !tbaa !29
  %t769 = load ptr, ptr %l2, !tbaa !29
  %t771 = getelementptr %"compiler/mir:Fn", ptr %t769, i32 0, i32 12
  %t772 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 2
  %t773 = getelementptr %"compiler/mir:Range", ptr %t772, i32 0, i32 0
  %t774 = load i32, ptr %t773, !tbaa !23
  %t776 = sext i32 %t774 to i64
  %t779 = sext i32 %t766 to i64
  %t782 = add i64 %t776, %t779
  %t785 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t771, i64 %t782)
  store { i64, [1 x i64] } %t785, ptr %l349
  br label %bb152
bb152:
  %t786 = load ptr, ptr %l341, !tbaa !29
  %t787 = load { i64, [1 x i64] }, ptr %l349
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t786, { i64, [1 x i64] } %t787)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s28)
  br label %bb154
bb154:
  %t788 = load i32, ptr %l36, !tbaa !23
  %t790 = add i32 %t788, 1
  store i32 %t790, ptr %l36, !tbaa !23
  br label %bb148
bb155:
  store i32 0, ptr %l38, !tbaa !23
  %t792 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 4
  %t793 = getelementptr %"compiler/mir:Range", ptr %t792, i32 0, i32 1
  %t794 = load i32, ptr %t793, !tbaa !23
  store i32 %t794, ptr %l39, !tbaa !23
  store i32 1, ptr %l40, !tbaa !23
  %t796 = load i32, ptr %l39, !tbaa !23
  %t797 = load i32, ptr %l38, !tbaa !23
  %t800 = icmp sgt i32 %t796, %t797
  br i1 %t800, label %bb156, label %bb157
bb156:
  %t802 = load i32, ptr %l40, !tbaa !23
  %t804 = icmp sgt i32 %t802, 0
  br i1 %t804, label %bb158, label %bb159
bb157:
  store i32 0, ptr %l356, !tbaa !23
  br label %bb161
bb158:
  %t806 = load i32, ptr %l39, !tbaa !23
  %t807 = load i32, ptr %l38, !tbaa !23
  %t810 = sub i32 %t806, %t807
  %t811 = load i32, ptr %l40, !tbaa !23
  %t814 = add i32 %t810, %t811
  %t816 = sub i32 %t814, 1
  %t817 = load i32, ptr %l40, !tbaa !23
  %t820 = sdiv i32 %t816, %t817
  store i32 %t820, ptr %l359, !tbaa !23
  br label %bb160
bb159:
  store i32 0, ptr %l359, !tbaa !23
  br label %bb160
bb160:
  %t822 = load i32, ptr %l359, !tbaa !23
  store i32 %t822, ptr %l356, !tbaa !23
  br label %bb161
bb161:
  %t823 = load i32, ptr %l356, !tbaa !23
  store i32 %t823, ptr %l41, !tbaa !23
  store i32 0, ptr %l42, !tbaa !23
  br label %bb162
bb162:
  store %olang.scope zeroinitializer, ptr %s31
  %t824 = load i32, ptr %l42, !tbaa !23
  %t825 = load i32, ptr %l41, !tbaa !23
  %t828 = icmp slt i32 %t824, %t825
  %t830 = xor i1 %t828, true
  br i1 %t830, label %bb163, label %bb164
bb163:
  call void @__olang_scope_close(ptr %s31)
  br label %bb169
bb164:
  br label %bb165
bb165:
  %t832 = load i32, ptr %l38, !tbaa !23
  %t833 = load i32, ptr %l42, !tbaa !23
  %t834 = load i32, ptr %l40, !tbaa !23
  %t837 = mul i32 %t833, %t834
  %t840 = add i32 %t832, %t837
  %t842 = load ptr, ptr %l0, !tbaa !29
  store ptr %t842, ptr %l377, !tbaa !29
  %t843 = load ptr, ptr %l2, !tbaa !29
  %t845 = getelementptr %"compiler/mir:Fn", ptr %t843, i32 0, i32 17
  %t846 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 4
  %t847 = getelementptr %"compiler/mir:Range", ptr %t846, i32 0, i32 0
  %t848 = load i32, ptr %t847, !tbaa !23
  %t850 = sext i32 %t848 to i64
  %t853 = sext i32 %t840 to i64
  %t856 = add i64 %t850, %t853
  %t859 = call %"compiler/mir:TaskClause" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eAt_H2a51e389d978bc4a54496c3113cf8f80(ptr %v0, ptr %t845, i64 %t856)
  store %"compiler/mir:TaskClause" %t859, ptr %l385
  br label %bb166
bb166:
  %t860 = getelementptr %"compiler/mir:TaskClause", ptr %l385, i32 0, i32 2
  %t861 = load { i64, [4 x i64] }, ptr %t860
  %t862 = load ptr, ptr %l377, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t862, { i64, [4 x i64] } %t861)
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s31)
  br label %bb168
bb168:
  %t864 = load i32, ptr %l42, !tbaa !23
  %t866 = add i32 %t864, 1
  store i32 %t866, ptr %l42, !tbaa !23
  br label %bb162
bb169:
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t870 = getelementptr %"compiler/mir:verifier", ptr %t868, i32 0, i32 16
  %t871 = load { i64, ptr }, ptr %t870, !tbaa !27
  store { i64, ptr } %t871, ptr %l390, !tbaa !27
  %t872 = load i32, ptr %l23, !tbaa !23
  %t874 = sext i32 %t872 to i64
  %t876 = getelementptr { i64, ptr }, ptr %l390, i32 0, i32 1
  %t877 = load ptr, ptr %t876, !tbaa !27
  %t878 = getelementptr i1, ptr %t877, i64 %t874
  store i1 true, ptr %t878, !tbaa !31
  br label %bb192
bb170:
  %t879 = load ptr, ptr %l1, !tbaa !29
  store ptr %t879, ptr %l393, !tbaa !29
  store i1 false, ptr %l394, !tbaa !21
  %t880 = load ptr, ptr %l393, !tbaa !29
  %t881 = icmp ne ptr %t880, null
  br i1 %t881, label %bb171, label %bb172
bb171:
  %t883 = load ptr, ptr %l393, !tbaa !29
  %t884 = load i64, ptr %t883
  %t886 = icmp eq i64 %t884, 12
  store i1 %t886, ptr %l394, !tbaa !21
  br label %bb172
bb172:
  %t887 = load i1, ptr %l394, !tbaa !21
  br i1 %t887, label %bb173, label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb176
bb175:
  br label %bb192
bb176:
  %t888 = load ptr, ptr %l1, !tbaa !29
  store ptr %t888, ptr %l397, !tbaa !29
  store i1 false, ptr %l398, !tbaa !21
  %t889 = load ptr, ptr %l397, !tbaa !29
  %t890 = icmp ne ptr %t889, null
  br i1 %t890, label %bb177, label %bb178
bb177:
  %t892 = load ptr, ptr %l397, !tbaa !29
  %t893 = load i64, ptr %t892
  %t895 = icmp eq i64 %t893, 13
  store i1 %t895, ptr %l398, !tbaa !21
  br label %bb178
bb178:
  %t896 = load i1, ptr %l398, !tbaa !21
  br i1 %t896, label %bb179, label %bb180
bb179:
  %t897 = load ptr, ptr %l1, !tbaa !29
  %t899 = getelementptr { i64, [21 x i64] }, ptr %t897, i32 0, i32 1
  %t900 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t899, i32 0, i32 1
  %t901 = load i32, ptr %t900
  store i32 %t901, ptr %l44, !tbaa !23
  %t903 = load ptr, ptr %l1, !tbaa !29
  %t905 = getelementptr { i64, [21 x i64] }, ptr %t903, i32 0, i32 1
  %t906 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t905, i32 0, i32 2
  %t907 = load i32, ptr %t906
  store i32 %t907, ptr %l45, !tbaa !23
  br label %bb181
bb180:
  br label %bb191
bb181:
  %t909 = load ptr, ptr %l0, !tbaa !29
  %t910 = load i32, ptr %l44, !tbaa !23
  %t913 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t909, i32 %t910)
  store i1 %t913, ptr %l407
  br label %bb182
bb182:
  %t914 = load i1, ptr %l407, !tbaa !21
  %t915 = xor i1 %t914, true
  br i1 %t915, label %bb183, label %bb184
bb183:
  store %olang.scope zeroinitializer, ptr %s35
  %t917 = load ptr, ptr %l0, !tbaa !29
  %t918 = load i32, ptr %l44, !tbaa !23
  %t919 = extractvalue { i64, ptr } { i64 29, ptr @.d196 }, 1
  %t920 = extractvalue { i64, ptr } { i64 29, ptr @.d196 }, 0
  %t922 = sext i32 %t918 to i64
  %t923 = call i64 @__olang_fmt_i64(ptr null, i64 %t922)
  %t924 = add i64 %t920, %t923
  %t925 = extractvalue { i64, ptr } { i64 19, ptr @.d197 }, 1
  %t926 = extractvalue { i64, ptr } { i64 19, ptr @.d197 }, 0
  %t927 = add i64 %t924, %t926
  %t928 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t927)
  call void @olang_textcopy(ptr %t928, ptr %t919, i64 %t920)
  %t929 = getelementptr i8, ptr %t928, i64 %t920
  %t930 = call i64 @__olang_fmt_i64(ptr %t929, i64 %t922)
  %t931 = getelementptr i8, ptr %t929, i64 %t923
  call void @olang_textcopy(ptr %t931, ptr %t925, i64 %t926)
  %t932 = insertvalue { i64, ptr } undef, i64 %t927, 0
  %t933 = insertvalue { i64, ptr } %t932, ptr %t928, 1
  %t935 = extractvalue { i64, ptr } %t933, 0
  %t936 = extractvalue { i64, ptr } %t933, 1
  %t937 = mul i64 %t935, 1
  %t938 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t937)
  call void @llvm.memcpy.p0.p0.i64(ptr %t938, ptr %t936, i64 %t937, i1 false)
  %t939 = insertvalue { i64, ptr } undef, i64 %t935, 0
  %t940 = insertvalue { i64, ptr } %t939, ptr %t938, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s35, ptr %t917, { i64, ptr } %t940)
  br label %bb185
bb184:
  br label %bb186
bb185:
  call void @__olang_scope_close(ptr %s35)
  br label %bb186
bb186:
  %t943 = load i32, ptr %l45, !tbaa !23
  %t944 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t947 = icmp ne i32 %t943, %t944
  br i1 %t947, label %bb187, label %bb188
bb187:
  %t949 = load ptr, ptr %l0, !tbaa !29
  %t950 = load i32, ptr %l45, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t949, i32 %t950)
  br label %bb189
bb188:
  br label %bb190
bb189:
  br label %bb190
bb190:
  br label %bb192
bb191:
  call void @__olang_check_failed(ptr @olang_loc_30c75e8686103aec_2a803509807dc2e8)
  unreachable
bb192:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estores(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l9 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/mir:verifier", ptr %t13, i32 0, i32 15
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = load i32, ptr %l3, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t21 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i1, ptr %t22, i64 %t19
  %t24 = load i1, ptr %t23, !tbaa !31
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = extractvalue { i64, ptr } { i64 1, ptr @.d198 }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr @.d198 }, 0
  %t33 = sext i32 %t29 to i64
  %t34 = call i64 @__olang_fmt_i64(ptr null, i64 %t33)
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 50, ptr @.d199 }, 1
  %t37 = extractvalue { i64, ptr } { i64 50, ptr @.d199 }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  %t41 = call i64 @__olang_fmt_i64(ptr %t40, i64 %t33)
  %t42 = getelementptr i8, ptr %t40, i64 %t34
  call void @olang_textcopy(ptr %t42, ptr %t36, i64 %t37)
  %t43 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t39, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t28, { i64, ptr } %t51)
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t54 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t55 = getelementptr %"compiler/mir:Range", ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55, !tbaa !23
  %t58 = icmp eq i32 %t56, 0
  br i1 %t58, label %bb8, label %bb9
bb8:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/mir:verifier", ptr %t60, i32 0, i32 14
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l21, !tbaa !27
  %t64 = load i32, ptr %l3, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t68 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i1, ptr %t69, i64 %t66
  store i1 true, ptr %t70, !tbaa !31
  br label %bb11
bb9:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/mir:Place", ptr %l1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t71, %"compiler/mir:Place" %t72)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb18
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load %"compiler/mir:Place", ptr %l1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t75, %"compiler/mir:Place" %t76)
  br label %bb16
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8c773ec7d9409528_6b556770aed18854)
  unreachable
bb18:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etagType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i32, i1 }
  %l3 = alloca i1
  %l6 = alloca { i32, i1 }
  %l11 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOf(ptr %v0, ptr %t1, i32 %t2)
  store { i32, i1 } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i32, i1 }, ptr %l6
  store { i32, i1 } %t6, ptr %l2
  %t7 = getelementptr { i32, i1 }, ptr %l2, i32 0, i32 1
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  %t10 = load i32, ptr %l1, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp ne i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i1, ptr %l3, !tbaa !21
  %t18 = xor i1 %t16, true
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l11, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l17
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t27 = extractvalue { i64, ptr } { i64 14, ptr @.d200 }, 1
  %t28 = extractvalue { i64, ptr } { i64 14, ptr @.d200 }, 0
  %t29 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 13, ptr @.d201 }, 1
  %t34 = extractvalue { i64, ptr } { i64 13, ptr @.d201 }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  call void @olang_textcopy(ptr %t37, ptr %t30, i64 %t31)
  %t38 = getelementptr i8, ptr %t37, i64 %t31
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t36, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t48 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t48, { i64, ptr } %t47)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t50 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermFlow(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l16 = alloca i32
  %l17 = alloca %"compiler/mir:Call"
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i1
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i1
  %l61 = alloca i32
  %l64 = alloca i32
  %l82 = alloca ptr
  %l90 = alloca %"compiler/mir:Case"
  %l103 = alloca %"compiler/mir:Call"
  %l112 = alloca i32
  %l115 = alloca i32
  %l133 = alloca ptr
  %l141 = alloca { i64, [1 x i64] }
  %l148 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l187 = alloca i64
  %l189 = alloca ptr
  %l191 = alloca { i64, ptr }
  %l207 = alloca i1
  %l214 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [7 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [7 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t15, i32 %t16)
  br label %bb4
bb4:
  br label %bb103
bb5:
  %t19 = load { i64, [7 x i64] }, ptr %l1
  %t21 = extractvalue { i64, [7 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 2
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t25 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t24, i32 0, i32 0
  %t26 = load { i64, [4 x i64] }, ptr %t25
  store { i64, [4 x i64] } %t26, ptr %l4
  %t28 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l5, !tbaa !23
  %t32 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t33 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t32, i32 0, i32 2
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l6, !tbaa !23
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, [4 x i64] }, ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t36, { i64, [4 x i64] } %t37)
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t40, i32 %t41)
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t44, i32 %t45)
  br label %bb11
bb11:
  br label %bb103
bb12:
  %t48 = load { i64, [7 x i64] }, ptr %l1
  %t50 = extractvalue { i64, [7 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 3
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t54 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t53, i32 0, i32 0
  %t55 = load { i64, [4 x i64] }, ptr %t54
  store { i64, [4 x i64] } %t55, ptr %l7
  %t57 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t58 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t57, i32 0, i32 1
  %t59 = load %"compiler/mir:Range", ptr %t58
  store %"compiler/mir:Range" %t59, ptr %l8
  %t61 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t61, i32 0, i32 2
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l9, !tbaa !23
  br label %bb15
bb14:
  br label %bb32
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, [4 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t65, { i64, [4 x i64] } %t66)
  br label %bb16
bb16:
  store i32 0, ptr %l10, !tbaa !23
  %t69 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 1
  %t70 = load i32, ptr %t69, !tbaa !23
  store i32 %t70, ptr %l11, !tbaa !23
  store i32 1, ptr %l12, !tbaa !23
  %t72 = load i32, ptr %l11, !tbaa !23
  %t73 = load i32, ptr %l10, !tbaa !23
  %t76 = icmp sgt i32 %t72, %t73
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load i32, ptr %l12, !tbaa !23
  %t80 = icmp sgt i32 %t78, 0
  br i1 %t80, label %bb19, label %bb20
bb18:
  store i32 0, ptr %l61, !tbaa !23
  br label %bb22
bb19:
  %t82 = load i32, ptr %l11, !tbaa !23
  %t83 = load i32, ptr %l10, !tbaa !23
  %t86 = sub i32 %t82, %t83
  %t87 = load i32, ptr %l12, !tbaa !23
  %t90 = add i32 %t86, %t87
  %t92 = sub i32 %t90, 1
  %t93 = load i32, ptr %l12, !tbaa !23
  %t96 = sdiv i32 %t92, %t93
  store i32 %t96, ptr %l64, !tbaa !23
  br label %bb21
bb20:
  store i32 0, ptr %l64, !tbaa !23
  br label %bb21
bb21:
  %t98 = load i32, ptr %l64, !tbaa !23
  store i32 %t98, ptr %l61, !tbaa !23
  br label %bb22
bb22:
  %t99 = load i32, ptr %l61, !tbaa !23
  store i32 %t99, ptr %l13, !tbaa !23
  store i32 0, ptr %l14, !tbaa !23
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t100 = load i32, ptr %l14, !tbaa !23
  %t101 = load i32, ptr %l13, !tbaa !23
  %t104 = icmp slt i32 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t108 = load i32, ptr %l10, !tbaa !23
  %t109 = load i32, ptr %l14, !tbaa !23
  %t110 = load i32, ptr %l12, !tbaa !23
  %t113 = mul i32 %t109, %t110
  %t116 = add i32 %t108, %t113
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l82, !tbaa !29
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = getelementptr %"compiler/mir:Fn", ptr %t119, i32 0, i32 15
  %t122 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t123 = load i32, ptr %t122, !tbaa !23
  %t125 = sext i32 %t123 to i64
  %t128 = sext i32 %t116 to i64
  %t131 = add i64 %t125, %t128
  %t134 = call %"compiler/mir:Case" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t121, i64 %t131)
  store %"compiler/mir:Case" %t134, ptr %l90
  br label %bb27
bb27:
  %t135 = getelementptr %"compiler/mir:Case", ptr %l90, i32 0, i32 1
  %t136 = load i32, ptr %t135, !tbaa !23
  %t137 = load ptr, ptr %l82, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t137, i32 %t136)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t139 = load i32, ptr %l14, !tbaa !23
  %t141 = add i32 %t139, 1
  store i32 %t141, ptr %l14, !tbaa !23
  br label %bb23
bb30:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t143, i32 %t144)
  br label %bb31
bb31:
  br label %bb103
bb32:
  %t147 = load { i64, [7 x i64] }, ptr %l1
  %t149 = extractvalue { i64, [7 x i64] } %t147, 0
  %t150 = icmp eq i64 %t149, 4
  br i1 %t150, label %bb33, label %bb34
bb33:
  %t152 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", i32 }, ptr %t152, i32 0, i32 1
  %t154 = load i32, ptr %t153
  store i32 %t154, ptr %l16, !tbaa !23
  br label %bb35
bb34:
  br label %bb66
bb35:
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t158 = getelementptr %"compiler/mir:Fn", ptr %t156, i32 0, i32 14
  %t159 = load i32, ptr %l16, !tbaa !23
  %t161 = sext i32 %t159 to i64
  %t164 = call %"compiler/mir:Call" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t158, i64 %t161)
  store %"compiler/mir:Call" %t164, ptr %l103
  br label %bb36
bb36:
  %t165 = load %"compiler/mir:Call", ptr %l103
  store %"compiler/mir:Call" %t165, ptr %l17
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 0
  %t168 = load { i64, [5 x i64] }, ptr %t167
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %t166, { i64, [5 x i64] } %t168)
  br label %bb37
bb37:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 1
  %t173 = load %"compiler/mir:Range", ptr %t172
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t171, %"compiler/mir:Range" %t173)
  br label %bb38
bb38:
  store i32 0, ptr %l18, !tbaa !23
  %t176 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 2
  %t177 = getelementptr %"compiler/mir:Range", ptr %t176, i32 0, i32 1
  %t178 = load i32, ptr %t177, !tbaa !23
  store i32 %t178, ptr %l19, !tbaa !23
  store i32 1, ptr %l20, !tbaa !23
  %t180 = load i32, ptr %l19, !tbaa !23
  %t181 = load i32, ptr %l18, !tbaa !23
  %t184 = icmp sgt i32 %t180, %t181
  br i1 %t184, label %bb39, label %bb40
bb39:
  %t186 = load i32, ptr %l20, !tbaa !23
  %t188 = icmp sgt i32 %t186, 0
  br i1 %t188, label %bb41, label %bb42
bb40:
  store i32 0, ptr %l112, !tbaa !23
  br label %bb44
bb41:
  %t190 = load i32, ptr %l19, !tbaa !23
  %t191 = load i32, ptr %l18, !tbaa !23
  %t194 = sub i32 %t190, %t191
  %t195 = load i32, ptr %l20, !tbaa !23
  %t198 = add i32 %t194, %t195
  %t200 = sub i32 %t198, 1
  %t201 = load i32, ptr %l20, !tbaa !23
  %t204 = sdiv i32 %t200, %t201
  store i32 %t204, ptr %l115, !tbaa !23
  br label %bb43
bb42:
  store i32 0, ptr %l115, !tbaa !23
  br label %bb43
bb43:
  %t206 = load i32, ptr %l115, !tbaa !23
  store i32 %t206, ptr %l112, !tbaa !23
  br label %bb44
bb44:
  %t207 = load i32, ptr %l112, !tbaa !23
  store i32 %t207, ptr %l21, !tbaa !23
  store i32 0, ptr %l22, !tbaa !23
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t208 = load i32, ptr %l22, !tbaa !23
  %t209 = load i32, ptr %l21, !tbaa !23
  %t212 = icmp slt i32 %t208, %t209
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb47:
  br label %bb48
bb48:
  %t216 = load i32, ptr %l18, !tbaa !23
  %t217 = load i32, ptr %l22, !tbaa !23
  %t218 = load i32, ptr %l20, !tbaa !23
  %t221 = mul i32 %t217, %t218
  %t224 = add i32 %t216, %t221
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l133, !tbaa !29
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t229 = getelementptr %"compiler/mir:Fn", ptr %t227, i32 0, i32 12
  %t230 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 2
  %t231 = getelementptr %"compiler/mir:Range", ptr %t230, i32 0, i32 0
  %t232 = load i32, ptr %t231, !tbaa !23
  %t234 = sext i32 %t232 to i64
  %t237 = sext i32 %t224 to i64
  %t240 = add i64 %t234, %t237
  %t243 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t229, i64 %t240)
  store { i64, [1 x i64] } %t243, ptr %l141
  br label %bb49
bb49:
  %t244 = load ptr, ptr %l133, !tbaa !29
  %t245 = load { i64, [1 x i64] }, ptr %l141
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t244, { i64, [1 x i64] } %t245)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb51:
  %t246 = load i32, ptr %l22, !tbaa !23
  %t248 = add i32 %t246, 1
  store i32 %t248, ptr %l22, !tbaa !23
  br label %bb45
bb52:
  %t250 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 7
  %t251 = load i32, ptr %t250, !tbaa !23
  %t252 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t255 = icmp ne i32 %t251, %t252
  br i1 %t255, label %bb53, label %bb54
bb53:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/mir:verifier", ptr %t257, i32 0, i32 15
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  store { i64, ptr } %t260, ptr %l148, !tbaa !27
  %t261 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t262 = load i32, ptr %t261, !tbaa !23
  %t264 = sext i32 %t262 to i64
  %t266 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i1, ptr %t267, i64 %t264
  %t269 = load i1, ptr %t268, !tbaa !31
  br i1 %t269, label %bb55, label %bb56
bb54:
  br label %bb60
bb55:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/mir:verifier", ptr %t271, i32 0, i32 14
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  store { i64, ptr } %t274, ptr %l153, !tbaa !27
  %t275 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t276 = load i32, ptr %t275, !tbaa !23
  %t278 = sext i32 %t276 to i64
  %t280 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr i1, ptr %t281, i64 %t278
  %t283 = load i1, ptr %t282, !tbaa !31
  store i1 %t283, ptr %l24, !tbaa !21
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/mir:verifier", ptr %t285, i32 0, i32 14
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  store { i64, ptr } %t288, ptr %l158, !tbaa !27
  %t289 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t290 = load i32, ptr %t289, !tbaa !23
  %t292 = sext i32 %t290 to i64
  %t294 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr i1, ptr %t295, i64 %t292
  store i1 true, ptr %t296, !tbaa !31
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 7
  %t299 = load i32, ptr %t298, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t297, i32 %t299)
  br label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s13
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t304 = load i32, ptr %t303, !tbaa !23
  %t305 = extractvalue { i64, ptr } { i64 1, ptr @.d202 }, 1
  %t306 = extractvalue { i64, ptr } { i64 1, ptr @.d202 }, 0
  %t308 = sext i32 %t304 to i64
  %t309 = call i64 @__olang_fmt_i64(ptr null, i64 %t308)
  %t310 = add i64 %t306, %t309
  %t311 = extractvalue { i64, ptr } { i64 36, ptr @.d203 }, 1
  %t312 = extractvalue { i64, ptr } { i64 36, ptr @.d203 }, 0
  %t313 = add i64 %t310, %t312
  %t314 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t313)
  call void @olang_textcopy(ptr %t314, ptr %t305, i64 %t306)
  %t315 = getelementptr i8, ptr %t314, i64 %t306
  %t316 = call i64 @__olang_fmt_i64(ptr %t315, i64 %t308)
  %t317 = getelementptr i8, ptr %t315, i64 %t309
  call void @olang_textcopy(ptr %t317, ptr %t311, i64 %t312)
  %t318 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t314, 1
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t322 = extractvalue { i64, ptr } %t319, 1
  %t323 = mul i64 %t321, 1
  %t324 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t323)
  call void @llvm.memcpy.p0.p0.i64(ptr %t324, ptr %t322, i64 %t323, i1 false)
  %t325 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t324, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s13, ptr %t302, { i64, ptr } %t326)
  br label %bb58
bb57:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/mir:verifier", ptr %t329, i32 0, i32 14
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  store { i64, ptr } %t332, ptr %l164, !tbaa !27
  %t333 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t334 = load i32, ptr %t333, !tbaa !23
  %t336 = sext i32 %t334 to i64
  %t337 = load i1, ptr %l24, !tbaa !21
  %t340 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr i1, ptr %t341, i64 %t336
  store i1 %t337, ptr %t342, !tbaa !31
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s13)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t343 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 4
  %t344 = load i1, ptr %t343, !tbaa !21
  br i1 %t344, label %bb61, label %bb62
bb61:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 3
  %t348 = load %"compiler/mir:Place", ptr %t347
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estores(ptr %v0, ptr %t346, %"compiler/mir:Place" %t348)
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 5
  %t353 = load i32, ptr %t352, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t351, i32 %t353)
  br label %bb65
bb65:
  br label %bb103
bb66:
  %t356 = load { i64, [7 x i64] }, ptr %l1
  %t358 = extractvalue { i64, [7 x i64] } %t356, 0
  %t359 = icmp eq i64 %t358, 5
  br i1 %t359, label %bb67, label %bb68
bb67:
  %t361 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t362 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t361, i32 0, i32 1
  %t363 = load { i64, [4 x i64] }, ptr %t362
  store { i64, [4 x i64] } %t363, ptr %l25
  br label %bb71
bb68:
  %t365 = load { i64, [7 x i64] }, ptr %l1
  %t367 = extractvalue { i64, [7 x i64] } %t365, 0
  %t368 = icmp eq i64 %t367, 6
  br i1 %t368, label %bb69, label %bb70
bb69:
  %t370 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t371 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t370, i32 0, i32 1
  %t372 = load { i64, [4 x i64] }, ptr %t371
  store { i64, [4 x i64] } %t372, ptr %l25
  br label %bb71
bb70:
  br label %bb79
bb71:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load { i64, [4 x i64] }, ptr %l25
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t374, { i64, [4 x i64] } %t375)
  br label %bb72
bb72:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/mir:verifier", ptr %t378, i32 0, i32 17
  %t382 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t380)
  store i64 %t382, ptr %l187
  br label %bb73
bb73:
  %t383 = load i64, ptr %l187, !tbaa !24
  %t384 = icmp sgt i64 %t383, 0
  br i1 %t384, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s17
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l189, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %s17, ptr %t387)
  store { i64, ptr } %t389, ptr %l191
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t390 = extractvalue { i64, ptr } { i64 25, ptr @.d204 }, 1
  %t391 = extractvalue { i64, ptr } { i64 25, ptr @.d204 }, 0
  %t392 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = add i64 %t391, %t394
  %t396 = extractvalue { i64, ptr } { i64 5, ptr @.d205 }, 1
  %t397 = extractvalue { i64, ptr } { i64 5, ptr @.d205 }, 0
  %t398 = add i64 %t395, %t397
  %t399 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t398)
  call void @olang_textcopy(ptr %t399, ptr %t390, i64 %t391)
  %t400 = getelementptr i8, ptr %t399, i64 %t391
  call void @olang_textcopy(ptr %t400, ptr %t393, i64 %t394)
  %t401 = getelementptr i8, ptr %t400, i64 %t394
  call void @olang_textcopy(ptr %t401, ptr %t396, i64 %t397)
  %t402 = insertvalue { i64, ptr } undef, i64 %t398, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t399, 1
  %t405 = extractvalue { i64, ptr } %t403, 0
  %t406 = extractvalue { i64, ptr } %t403, 1
  %t407 = mul i64 %t405, 1
  %t408 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t407)
  call void @llvm.memcpy.p0.p0.i64(ptr %t408, ptr %t406, i64 %t407, i1 false)
  %t409 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t408, 1
  %t411 = load ptr, ptr %l189, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s17, ptr %t411, { i64, ptr } %t410)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s17)
  br label %bb78
bb78:
  br label %bb103
bb79:
  %t413 = load { i64, [7 x i64] }, ptr %l1
  %t415 = extractvalue { i64, [7 x i64] } %t413, 0
  %t416 = icmp eq i64 %t415, 8
  br i1 %t416, label %bb80, label %bb81
bb80:
  %t418 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t419 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t418, i32 0, i32 2
  %t420 = load { i64, [4 x i64] }, ptr %t419
  store { i64, [4 x i64] } %t420, ptr %l26
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load { i64, [4 x i64] }, ptr %l26
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t422, { i64, [4 x i64] } %t423)
  br label %bb83
bb83:
  br label %bb103
bb84:
  %t426 = load { i64, [7 x i64] }, ptr %l1
  %t428 = extractvalue { i64, [7 x i64] } %t426, 0
  %t429 = icmp eq i64 %t428, 7
  br i1 %t429, label %bb85, label %bb86
bb85:
  %t431 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t431, i32 0, i32 1
  %t433 = load i32, ptr %t432
  store i32 %t433, ptr %l27, !tbaa !23
  %t435 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t436 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t435, i32 0, i32 2
  %t437 = load i32, ptr %t436
  store i32 %t437, ptr %l28, !tbaa !23
  %t439 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t440 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t439, i32 0, i32 3
  %t441 = load i32, ptr %t440
  store i32 %t441, ptr %l29, !tbaa !23
  %t443 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t444 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t443, i32 0, i32 4
  %t445 = load i32, ptr %t444
  store i32 %t445, ptr %l30, !tbaa !23
  br label %bb87
bb86:
  br label %bb98
bb87:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load i32, ptr %l27, !tbaa !23
  %t451 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t447, i32 %t448)
  store i1 %t451, ptr %l207
  br label %bb88
bb88:
  %t452 = load i1, ptr %l207, !tbaa !21
  %t453 = xor i1 %t452, true
  br i1 %t453, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s21
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load i32, ptr %l27, !tbaa !23
  %t457 = extractvalue { i64, ptr } { i64 12, ptr @.d206 }, 1
  %t458 = extractvalue { i64, ptr } { i64 12, ptr @.d206 }, 0
  %t460 = sext i32 %t456 to i64
  %t461 = call i64 @__olang_fmt_i64(ptr null, i64 %t460)
  %t462 = add i64 %t458, %t461
  %t463 = extractvalue { i64, ptr } { i64 19, ptr @.d207 }, 1
  %t464 = extractvalue { i64, ptr } { i64 19, ptr @.d207 }, 0
  %t465 = add i64 %t462, %t464
  %t466 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t465)
  call void @olang_textcopy(ptr %t466, ptr %t457, i64 %t458)
  %t467 = getelementptr i8, ptr %t466, i64 %t458
  %t468 = call i64 @__olang_fmt_i64(ptr %t467, i64 %t460)
  %t469 = getelementptr i8, ptr %t467, i64 %t461
  call void @olang_textcopy(ptr %t469, ptr %t463, i64 %t464)
  %t470 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t466, 1
  %t473 = extractvalue { i64, ptr } %t471, 0
  %t474 = extractvalue { i64, ptr } %t471, 1
  %t475 = mul i64 %t473, 1
  %t476 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t475)
  call void @llvm.memcpy.p0.p0.i64(ptr %t476, ptr %t474, i64 %t475, i1 false)
  %t477 = insertvalue { i64, ptr } undef, i64 %t473, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t476, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s21, ptr %t455, { i64, ptr } %t478)
  br label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_scope_close(ptr %s21)
  br label %bb92
bb92:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/mir:verifier", ptr %t481, i32 0, i32 16
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  store { i64, ptr } %t484, ptr %l214, !tbaa !27
  %t485 = load i32, ptr %l27, !tbaa !23
  %t487 = sext i32 %t485 to i64
  %t489 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = getelementptr i1, ptr %t490, i64 %t487
  store i1 false, ptr %t491, !tbaa !31
  %t492 = load i32, ptr %l30, !tbaa !23
  %t493 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t496 = icmp ne i32 %t492, %t493
  br i1 %t496, label %bb93, label %bb94
bb93:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/mir:verifier", ptr %t498, i32 0, i32 14
  %t501 = load { i64, ptr }, ptr %t500, !tbaa !27
  store { i64, ptr } %t501, ptr %l221, !tbaa !27
  %t502 = load i32, ptr %l29, !tbaa !23
  %t504 = sext i32 %t502 to i64
  %t506 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr i1, ptr %t507, i64 %t504
  %t509 = load i1, ptr %t508, !tbaa !31
  store i1 %t509, ptr %l31, !tbaa !21
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t513 = getelementptr %"compiler/mir:verifier", ptr %t511, i32 0, i32 14
  %t514 = load { i64, ptr }, ptr %t513, !tbaa !27
  store { i64, ptr } %t514, ptr %l226, !tbaa !27
  %t515 = load i32, ptr %l29, !tbaa !23
  %t517 = sext i32 %t515 to i64
  %t519 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t520 = load ptr, ptr %t519, !tbaa !27
  %t521 = getelementptr i1, ptr %t520, i64 %t517
  store i1 true, ptr %t521, !tbaa !31
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load i32, ptr %l30, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t522, i32 %t523)
  br label %bb95
bb94:
  br label %bb96
bb95:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t528 = getelementptr %"compiler/mir:verifier", ptr %t526, i32 0, i32 14
  %t529 = load { i64, ptr }, ptr %t528, !tbaa !27
  store { i64, ptr } %t529, ptr %l232, !tbaa !27
  %t530 = load i32, ptr %l29, !tbaa !23
  %t532 = sext i32 %t530 to i64
  %t533 = load i1, ptr %l31, !tbaa !21
  %t536 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t537 = load ptr, ptr %t536, !tbaa !27
  %t538 = getelementptr i1, ptr %t537, i64 %t532
  store i1 %t533, ptr %t538, !tbaa !31
  br label %bb96
bb96:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load i32, ptr %l28, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t539, i32 %t540)
  br label %bb97
bb97:
  br label %bb103
bb98:
  br i1 true, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_d66c95c574566df8_862c2f5cde7f4614)
  unreachable
bb103:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l9 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l9
  br label %bb4
bb4:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = extractvalue { i64, ptr } { i64 1, ptr @.d208 }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr @.d208 }, 0
  %t23 = sext i32 %t19 to i64
  %t24 = call i64 @__olang_fmt_i64(ptr null, i64 %t23)
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 26, ptr @.d209 }, 1
  %t27 = extractvalue { i64, ptr } { i64 26, ptr @.d209 }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t23)
  %t32 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t32, ptr %t26, i64 %t27)
  %t33 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t29, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t18, { i64, ptr } %t41)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  br label %bb19
bb9:
  %t44 = load { i64, [1 x i64] }, ptr %l1
  %t46 = extractvalue { i64, [1 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 4
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t50 = getelementptr { i32 }, ptr %t49, i32 0, i32 0
  %t51 = load i32, ptr %t50
  store i32 %t51, ptr %l3, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t53, i32 %t54)
  br label %bb13
bb13:
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_587900af1cc61a9a_48225b2d2b7d46c6)
  unreachable
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t1, i32 %t2, i32 %t3)
  store i1 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l9, !tbaa !29
  store { i64, ptr } %a3, ptr %l10, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t13, i32 %t14)
  store { i64, ptr } %t17, ptr %l13
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l16
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } { i64 6, ptr @.d210 }, 1
  %t27 = extractvalue { i64, ptr } { i64 6, ptr @.d210 }, 0
  %t28 = add i64 %t25, %t27
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 10, ptr @.d211 }, 1
  %t34 = extractvalue { i64, ptr } { i64 10, ptr @.d211 }, 0
  %t35 = add i64 %t32, %t34
  %t36 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 10, ptr @.d212 }, 1
  %t41 = extractvalue { i64, ptr } { i64 10, ptr @.d212 }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t24, i64 %t25)
  %t44 = getelementptr i8, ptr %t43, i64 %t25
  call void @olang_textcopy(ptr %t44, ptr %t26, i64 %t27)
  %t45 = getelementptr i8, ptr %t44, i64 %t27
  call void @olang_textcopy(ptr %t45, ptr %t30, i64 %t31)
  %t46 = getelementptr i8, ptr %t45, i64 %t31
  call void @olang_textcopy(ptr %t46, ptr %t33, i64 %t34)
  %t47 = getelementptr i8, ptr %t46, i64 %t34
  call void @olang_textcopy(ptr %t47, ptr %t37, i64 %t38)
  %t48 = getelementptr i8, ptr %t47, i64 %t38
  call void @olang_textcopy(ptr %t48, ptr %t40, i64 %t41)
  %t49 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t43, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t58 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t58, { i64, ptr } %t57)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eexpect(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v0, ptr %s0, ptr %a1, ptr %a0)
  store { i64, ptr } %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %v1, { i64, ptr } %t7, { i64, ptr } %t8)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l12
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15
ok.15:
  store i64 %t12, ptr %l11
  br label %bb2
bb2:
  %t16 = load i64, ptr %l11, !tbaa !24
  store i64 %t16, ptr %l8, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t20 = icmp sge i64 %t17, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t24 = extractvalue { i64, ptr } { i64 8, ptr @.d213 }, 1
  %t25 = extractvalue { i64, ptr } { i64 8, ptr @.d213 }, 0
  %t27 = extractvalue { i64, ptr } %t22, 1
  %t28 = extractvalue { i64, ptr } %t22, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 9, ptr @.d214 }, 1
  %t31 = extractvalue { i64, ptr } { i64 9, ptr @.d214 }, 0
  %t32 = add i64 %t29, %t31
  %t34 = extractvalue { i64, ptr } %t23, 1
  %t35 = extractvalue { i64, ptr } %t23, 0
  %t36 = add i64 %t32, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t24, i64 %t25)
  %t38 = getelementptr i8, ptr %t37, i64 %t25
  call void @olang_textcopy(ptr %t38, ptr %t27, i64 %t28)
  %t39 = getelementptr i8, ptr %t38, i64 %t28
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t40, ptr %t34, i64 %t35)
  %t41 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t37, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = extractvalue { i64, ptr } %t49, 0
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  call void @__olang_check_failed_text(ptr @olang_loc_2787a88b0b468961_ce97027662ecd8ed, { i64, ptr } %t54)
  unreachable
ret:
  ret void
}

define dso_local %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [5 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Place" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7) #0 {
entry:
  %rv = alloca %"compiler/mir:Call"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/mir:Call" undef, { i64, [5 x i64] } %a0, 0
  %t20 = insertvalue %"compiler/mir:Call" %t18, %"compiler/mir:Range" %a1, 1
  %t22 = insertvalue %"compiler/mir:Call" %t20, %"compiler/mir:Range" %a2, 2
  %t24 = insertvalue %"compiler/mir:Call" %t22, %"compiler/mir:Place" %a3, 3
  %t26 = insertvalue %"compiler/mir:Call" %t24, i1 %a4, 4
  %t28 = insertvalue %"compiler/mir:Call" %t26, i32 %a5, 5
  %t30 = insertvalue %"compiler/mir:Call" %t28, i32 %a6, 6
  %t32 = insertvalue %"compiler/mir:Call" %t30, i32 %a7, 7
  store %"compiler/mir:Call" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Call", ptr %rv
  ret %"compiler/mir:Call" %rr
}

define dso_local %"compiler/mir:Case" @compiler_2fmir_3aCase_2ector(ptr %v0, i64 %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/mir:Case"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/mir:Case" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/mir:Case" %t6, i32 %a1, 1
  store %"compiler/mir:Case" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Case", ptr %rv
  ret %"compiler/mir:Case" %rr
}

define dso_local void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [1 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"compiler/mir:Fn"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [1 x i64] } %a0, ptr %l4
  store i32 %a1, ptr %l5, !tbaa !23
  store i64 %a2, ptr %l6, !tbaa !24
  store %"compiler/source:Span" %a3, ptr %l7
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l31
  br label %bb1
bb1:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l8
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e(ptr %t12)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l32
  br label %bb2
bb2:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l9
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e(ptr %t15)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l33
  br label %bb3
bb3:
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l10
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e(ptr %t18)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l34
  br label %bb4
bb4:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l11
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t21)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l35
  br label %bb5
bb5:
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l12
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t24)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l36
  br label %bb6
bb6:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l13
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e(ptr %t27)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l37
  br label %bb7
bb7:
  %t29 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l14
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e(ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l38
  br label %bb8
bb8:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l15
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e(ptr %t33)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l39
  br label %bb9
bb9:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l16
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e(ptr %t36)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l40
  br label %bb10
bb10:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l17
  %t39 = load ptr, ptr @__olang_prog_scope
  %t40 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e(ptr %t39)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l41
  br label %bb11
bb11:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l18
  %t42 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e(ptr %t42)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l42
  br label %bb12
bb12:
  %t44 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l19
  %t45 = load ptr, ptr @__olang_prog_scope
  %t46 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e(ptr %t45)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l43
  br label %bb13
bb13:
  %t47 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l20
  %t48 = load ptr, ptr @__olang_prog_scope
  %t49 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e(ptr %t48)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l44
  br label %bb14
bb14:
  %t50 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l21
  %t51 = load ptr, ptr @__olang_prog_scope
  %t52 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e(ptr %t51)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l45
  br label %bb15
bb15:
  %t53 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l22
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e(ptr %t54)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l46
  br label %bb16
bb16:
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l23
  %t57 = load ptr, ptr @__olang_prog_scope
  %t58 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %t57)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l47
  br label %bb17
bb17:
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l24
  %t60 = load ptr, ptr @__olang_prog_scope
  %t61 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cU8_3e(ptr %t60)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l48
  br label %bb18
bb18:
  %t62 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l25
  %t63 = load ptr, ptr @__olang_prog_scope
  %t64 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %t63)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l49
  br label %bb19
bb19:
  %t65 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  %t66 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 0
  %t67 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t67, ptr %t66
  %t68 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 1
  %t69 = load i32, ptr %l5, !tbaa !23
  store i32 %t69, ptr %t68, !tbaa !23
  %t70 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 2
  %t71 = load i64, ptr %l6, !tbaa !24
  store i64 %t71, ptr %t70, !tbaa !24
  %t72 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 3
  %t73 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t73, ptr %t72
  %t74 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 4
  %t75 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %t74
  %t76 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 5
  %t77 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %t76
  %t78 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 6
  %t79 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t79, ptr %t78
  %t80 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 7
  %t81 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %t80
  %t82 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 8
  %t83 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %t82
  %t84 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 9
  %t85 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %t84
  %t86 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 10
  %t87 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %t86
  %t88 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 11
  %t89 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t89, ptr %t88
  %t90 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 12
  %t91 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %t90
  %t92 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 13
  %t93 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t93, ptr %t92
  %t94 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 14
  %t95 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %t94
  %t96 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 15
  %t97 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %t96
  %t98 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 16
  %t99 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t99, ptr %t98
  %t100 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 17
  %t101 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t101, ptr %t100
  %t102 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 18
  %t103 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t103, ptr %t102
  %t104 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 19
  %t105 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %t104
  %t106 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 20
  %t107 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t107, ptr %t106
  %t108 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 21
  %t109 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t109, ptr %t108
  %t110 = getelementptr %"compiler/mir:Fn", ptr %l50, i32 0, i32 22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %t110
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l50, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:ScopeInfo" @compiler_2fmir_3aScopeInfo_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4) #0 {
entry:
  %rv = alloca %"compiler/mir:ScopeInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/mir:ScopeInfo" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/mir:ScopeInfo" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/mir:ScopeInfo" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/mir:ScopeInfo" %t16, %"compiler/source:Span" %a3, 3
  %t20 = insertvalue %"compiler/mir:ScopeInfo" %t18, i32 %a4, 4
  store %"compiler/mir:ScopeInfo" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:ScopeInfo", ptr %rv
  ret %"compiler/mir:ScopeInfo" %rr
}

define dso_local %"compiler/mir:TaskClause" @compiler_2fmir_3aTaskClause_2ector(ptr %v0, %"compiler/mir:Range" %a0, i1 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %rv = alloca %"compiler/mir:TaskClause"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/mir:TaskClause" undef, %"compiler/mir:Range" %a0, 0
  %t10 = insertvalue %"compiler/mir:TaskClause" %t8, i1 %a1, 1
  %t12 = insertvalue %"compiler/mir:TaskClause" %t10, { i64, [4 x i64] } %a2, 2
  store %"compiler/mir:TaskClause" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:TaskClause", ptr %rv
  ret %"compiler/mir:TaskClause" %rr
}

define dso_local void @compiler_2fmir_3averifier_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l38 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"compiler/mir:verifier"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr @__olang_prog_scope
  %t6 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %t5)
  store %"std/prelude/text:StringBuilder" %t6, ptr %l23
  br label %bb1
bb1:
  %t7 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t7, ptr %l4
  store i64 -1, ptr %l5, !tbaa !24
  store i64 -1, ptr %l6, !tbaa !24
  store i1 true, ptr %l7, !tbaa !21
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = mul i64 0, 1
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 0, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  %t15 = icmp sge i64 0, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_5380db3ec2a99a3_371ccfada9fdfeef)
  unreachable
bb4:
  %t17 = mul i64 0, 1
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l9, !tbaa !27
  %t22 = icmp sge i64 0, 0
  br i1 %t22, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5983d076d5883d2e_1665ff00cbce2e1a)
  unreachable
bb6:
  %t24 = mul i64 0, 1
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l10, !tbaa !27
  %t29 = icmp sge i64 0, 0
  br i1 %t29, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_910dd2c5a789172d_f03cfbb9736a8799)
  unreachable
bb8:
  %t31 = mul i64 0, 1
  %t32 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 0, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l11, !tbaa !27
  %t36 = icmp sge i64 0, 0
  br i1 %t36, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2a1e3324a3ced000_b715b4216485c88c)
  unreachable
bb10:
  %t38 = icmp sle i64 0, 1152921504606846975
  br i1 %t38, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_424aba850193e62f_5d41a9f8bd7e1e63)
  unreachable
bb12:
  %t40 = mul i64 0, 8
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 0, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l12, !tbaa !27
  %t45 = icmp sge i64 0, 0
  br i1 %t45, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_424aba850193e62f_5d41a9f8bd7e1e63)
  unreachable
bb14:
  %t47 = icmp sle i64 0, 1152921504606846975
  br i1 %t47, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_26e15834dfadce5a_40849b88d9a51eee)
  unreachable
bb16:
  %t49 = mul i64 0, 8
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 0, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l13, !tbaa !27
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e(ptr %t54)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l38
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_26e15834dfadce5a_40849b88d9a51eee)
  unreachable
bb18:
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l14
  %t57 = icmp sge i64 0, 0
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = mul i64 0, 1
  %t60 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 0, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l15, !tbaa !27
  %t64 = icmp sge i64 0, 0
  br i1 %t64, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_390ccbe637d1d3d9_30a6ef9f1a3ec7ed)
  unreachable
bb21:
  %t66 = mul i64 0, 1
  %t67 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 0, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l16, !tbaa !27
  %t71 = icmp sge i64 0, 0
  br i1 %t71, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_1f26baa5abf820cc_81869963bb6d62c0)
  unreachable
bb23:
  %t73 = mul i64 0, 1
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 0, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l17, !tbaa !27
  %t78 = icmp sge i64 0, 0
  br i1 %t78, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_200617782b41aa6b_62fe98f9543f67b7)
  unreachable
bb25:
  %t80 = mul i64 0, 1
  %t81 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 0, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l18, !tbaa !27
  %t85 = load ptr, ptr @__olang_prog_scope
  %t86 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e(ptr %t85)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %l47
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_d8b0f1b6ba5e5556_5a69466de52f9302)
  unreachable
bb27:
  %t87 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  %t88 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 0
  %t89 = load ptr, ptr %l2, !tbaa !29
  store ptr %t89, ptr %t88, !tbaa !29
  %t90 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 1
  %t91 = load ptr, ptr %l3, !tbaa !29
  store ptr %t91, ptr %t90, !tbaa !29
  %t92 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 2
  %t93 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t93, ptr %t92
  %t94 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 3
  %t95 = load i64, ptr %l5, !tbaa !24
  store i64 %t95, ptr %t94, !tbaa !24
  %t96 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 4
  %t97 = load i64, ptr %l6, !tbaa !24
  store i64 %t97, ptr %t96, !tbaa !24
  %t98 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 5
  %t99 = load i1, ptr %l7, !tbaa !21
  store i1 %t99, ptr %t98, !tbaa !21
  %t100 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 6
  %t101 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t101, ptr %t100, !tbaa !27
  %t102 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 7
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t103, ptr %t102, !tbaa !27
  %t104 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 8
  %t105 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t105, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 9
  %t107 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t107, ptr %t106, !tbaa !27
  %t108 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 10
  %t109 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t109, ptr %t108, !tbaa !27
  %t110 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 11
  %t111 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t111, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 12
  %t113 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t113, ptr %t112
  %t114 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 13
  %t115 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t115, ptr %t114, !tbaa !27
  %t116 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 14
  %t117 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t117, ptr %t116, !tbaa !27
  %t118 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 15
  %t119 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t119, ptr %t118, !tbaa !27
  %t120 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 16
  %t121 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t121, ptr %t120, !tbaa !27
  %t122 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 17
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %t122
  %t124 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 18
  store i1 false, ptr %t124, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l48, i64 232, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2ecompiler_2fmir() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fmir_2eNoBlock_2einit()
  br label %bb1
bb1:
  call void @compiler_2fmir_2eNoLocal_2einit()
  br label %bb2
bb2:
  call void @compiler_2fmir_2eNoScope_2einit()
  br label %bb3
bb3:
  call void @compiler_2fmir_2eEmpty_2einit()
  br label %bb4
bb4:
  call void @compiler_2fmir_2eNoPlace_2einit()
  br label %bb5
bb5:
  call void @compiler_2fmir_2eI32T_2einit()
  br label %bb6
bb6:
  call void @compiler_2fmir_2eI64T_2einit()
  br label %bb7
bb7:
  call void @compiler_2fmir_2eSp0_2einit()
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant [0 x i8] c""
@.d1 = private constant [7 x i8] c"aborted"
@.d2 = private constant [19 x i8] c"unreachable reached"
@.d3 = private constant [12 x i8] c"null reached"
@.d4 = private constant [16 x i8] c"assertion failed"
@.d5 = private constant [25 x i8] c"slice bounds out of range"
@.d6 = private constant [25 x i8] c"array length out of range"
@.d7 = private constant [32 x i8] c"'as' named what the value is not"
@.d8 = private constant [45 x i8] c"array length does not match its fixed storage"
declare void @__olang_check_failed(ptr)
@.d9 = private constant [3 x i8] c"I32"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d10 = private constant [1 x i8] c"a"
@.d11 = private constant [1 x i8] c"b"
@.d12 = private constant [1 x i8] c"s"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d13 = private constant [8 x i8] c"assert B"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d14 = private constant [1 x i8] c" "
@.d15 = private constant [1 x i8] c":"
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d16 = private constant [7 x i8] c"global "
@.d17 = private constant [1 x i8] c":"
@.d18 = private constant [9 x i8] c"literal B"
@.d19 = private constant [6 x i8] c" site "
@.d20 = private constant [6 x i8] c"zero T"
@.d21 = private constant [3 x i8] c"fn "
@.d22 = private constant [2 x i8] c": "
@.d23 = private constant [2 x i8] c", "
@.d24 = private constant [0 x i8] c""
@.d25 = private constant [1 x i8] c"V"
@.d26 = private constant [1 x i8] c" "
@.d27 = private constant [5 x i8] c"vars "
@.d28 = private constant [0 x i8] c""
@.d29 = private constant [4 x i8] c" in "
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aLocalKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 15, ptr @.d215 }, 1
  %t6 = extractvalue { i64, ptr } { i64 15, ptr @.d215 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 17, ptr @.d216 }, 1
  %t8 = extractvalue { i64, ptr } { i64 17, ptr @.d216 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 13, ptr @.d217 }, 1
  %t10 = extractvalue { i64, ptr } { i64 13, ptr @.d217 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 14, ptr @.d218 }, 1
  %t12 = extractvalue { i64, ptr } { i64 14, ptr @.d218 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d30 = private constant [1 x i8] c" "
@.d31 = private constant [0 x i8] c""
@.d32 = private constant [1 x i8] c"L"
@.d33 = private constant [1 x i8] c" "
@.d34 = private constant [2 x i8] c": "
@.d35 = private constant [0 x i8] c""
@.d36 = private constant [5 x i8] c" in S"
@.d37 = private constant [0 x i8] c""
@.d38 = private constant [7 x i8] c" block "
@.d39 = private constant [0 x i8] c""
@.d40 = private constant [7 x i8] c" fails "
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aScopeKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 15, ptr @.d219 }, 1
  %t6 = extractvalue { i64, ptr } { i64 15, ptr @.d219 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 15, ptr @.d220 }, 1
  %t8 = extractvalue { i64, ptr } { i64 15, ptr @.d220 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr @.d221 }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr @.d221 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 14, ptr @.d222 }, 1
  %t12 = extractvalue { i64, ptr } { i64 14, ptr @.d222 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 16, ptr @.d223 }, 1
  %t14 = extractvalue { i64, ptr } { i64 16, ptr @.d223 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 15, ptr @.d224 }, 1
  %t16 = extractvalue { i64, ptr } { i64 15, ptr @.d224 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 17, ptr @.d225 }, 1
  %t18 = extractvalue { i64, ptr } { i64 17, ptr @.d225 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
ret:
  ret void
}

@.d41 = private constant [1 x i8] c"S"
@.d42 = private constant [1 x i8] c" "
@.d43 = private constant [2 x i8] c"bb"
@.d44 = private constant [1 x i8] c":"
@.d45 = private constant [2 x i8] c", "
@.d46 = private constant [0 x i8] c""
@.d47 = private constant [3 x i8] c" bb"
@.d48 = private constant [1 x i8] c" "
@.d49 = private constant [0 x i8] c""
@.d50 = private constant [1 x i8] c"B"
@.d51 = private constant [9 x i8] c"adapter B"
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 17, ptr @.d226 }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr @.d226 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 16, ptr @.d227 }, 1
  %t8 = extractvalue { i64, ptr } { i64 16, ptr @.d227 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 15, ptr @.d228 }, 1
  %t10 = extractvalue { i64, ptr } { i64 15, ptr @.d228 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 15, ptr @.d229 }, 1
  %t12 = extractvalue { i64, ptr } { i64 15, ptr @.d229 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
ret:
  ret void
}

@.d52 = private constant [1 x i8] c" "
@.d53 = private constant [5 x i8] c"init "
@.d54 = private constant [4 x i8] c"none"
@.d55 = private constant [5 x i8] c"copy "
@.d56 = private constant [6 x i8] c"const "
@.d57 = private constant [1 x i8] c" "
@.d58 = private constant [5 x i8] c"data "
@.d59 = private constant [1 x i8] c" "
@.d60 = private constant [2 x i8] c" @"
@.d61 = private constant [1 x i8] c":"
@.d62 = private constant [1 x i8] c"_"
@.d63 = private constant [1 x i8] c"L"
@.d64 = private constant [1 x i8] c"G"
@.d65 = private constant [1 x i8] c":"
@.d66 = private constant [1 x i8] c"."
@.d67 = private constant [2 x i8] c"[L"
@.d68 = private constant [1 x i8] c"]"
@.d69 = private constant [1 x i8] c"["
@.d70 = private constant [1 x i8] c"]"
@.d71 = private constant [2 x i8] c".*"
@.d72 = private constant [4 x i8] c" as "
@.d73 = private constant [1 x i8] c"S"
@.d74 = private constant [1 x i8] c"V"
@.d75 = private constant [7 x i8] c"program"
@.d76 = private constant [5 x i8] c"frame"
@.d77 = private constant [8 x i8] c"region(L"
@.d78 = private constant [1 x i8] c")"
@.d79 = private constant [4 x i8] c"ref "
@.d80 = private constant [2 x i8] c": "
@.d81 = private constant [5 x i8] c"take "
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr @.d230 }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr @.d230 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d231 }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr @.d231 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 10, ptr @.d232 }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr @.d232 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 10, ptr @.d233 }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr @.d233 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 10, ptr @.d234 }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr @.d234 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 10, ptr @.d235 }, 1
  %t16 = extractvalue { i64, ptr } { i64 10, ptr @.d235 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 10, ptr @.d236 }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr @.d236 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 10, ptr @.d237 }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr @.d237 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 10, ptr @.d238 }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr @.d238 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 10, ptr @.d239 }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr @.d239 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 13, ptr @.d240 }, 1
  %t26 = extractvalue { i64, ptr } { i64 13, ptr @.d240 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 12, ptr @.d241 }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr @.d241 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 13, ptr @.d242 }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr @.d242 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 9, ptr @.d243 }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr @.d243 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 9, ptr @.d244 }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr @.d244 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 9, ptr @.d245 }, 1
  %t36 = extractvalue { i64, ptr } { i64 9, ptr @.d245 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 9, ptr @.d246 }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr @.d246 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr @.d247 }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr @.d247 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 9, ptr @.d248 }, 1
  %t42 = extractvalue { i64, ptr } { i64 9, ptr @.d248 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 11, ptr @.d249 }, 1
  %t44 = extractvalue { i64, ptr } { i64 11, ptr @.d249 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 14, ptr @.d250 }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr @.d250 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 14, ptr @.d251 }, 1
  %t48 = extractvalue { i64, ptr } { i64 14, ptr @.d251 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 10, ptr @.d252 }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr @.d252 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 13, ptr @.d253 }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr @.d253 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 14, ptr @.d254 }, 1
  %t54 = extractvalue { i64, ptr } { i64 14, ptr @.d254 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 18, ptr @.d255 }, 1
  %t56 = extractvalue { i64, ptr } { i64 18, ptr @.d255 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 17, ptr @.d256 }, 1
  %t58 = extractvalue { i64, ptr } { i64 17, ptr @.d256 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 18, ptr @.d257 }, 1
  %t60 = extractvalue { i64, ptr } { i64 18, ptr @.d257 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 16, ptr @.d258 }, 1
  %t62 = extractvalue { i64, ptr } { i64 16, ptr @.d258 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 17, ptr @.d259 }, 1
  %t64 = extractvalue { i64, ptr } { i64 17, ptr @.d259 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 24, ptr @.d260 }, 1
  %t66 = extractvalue { i64, ptr } { i64 24, ptr @.d260 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 13, ptr @.d261 }, 1
  %t68 = extractvalue { i64, ptr } { i64 13, ptr @.d261 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
ret:
  ret void
}

@.d82 = private constant [1 x i8] c" "
@.d83 = private constant [1 x i8] c"("
@.d84 = private constant [1 x i8] c")"
@.d85 = private constant [10 x i8] c"overflows "
@.d86 = private constant [1 x i8] c" "
@.d87 = private constant [1 x i8] c"("
@.d88 = private constant [1 x i8] c")"
@.d89 = private constant [4 x i8] c"tag "
@.d90 = private constant [2 x i8] c" #"
@.d91 = private constant [0 x i8] c""
@.d92 = private constant [5 x i8] c"make "
@.d93 = private constant [1 x i8] c"("
@.d94 = private constant [1 x i8] c")"
@.d95 = private constant [7 x i8] c"new in "
@.d96 = private constant [1 x i8] c" "
@.d97 = private constant [2 x i8] c": "
@.d98 = private constant [12 x i8] c"newarray in "
@.d99 = private constant [1 x i8] c" "
@.d100 = private constant [1 x i8] c"("
@.d101 = private constant [2 x i8] c", "
@.d102 = private constant [1 x i8] c")"
@.d103 = private constant [6 x i8] c"slice "
@.d104 = private constant [1 x i8] c"["
@.d105 = private constant [3 x i8] c" : "
@.d106 = private constant [3 x i8] c"]: "
@.d107 = private constant [0 x i8] c""
@.d108 = private constant [10 x i8] c" captures "
@.d109 = private constant [8 x i8] c"closure "
@.d110 = private constant [4 x i8] c" in "
@.d111 = private constant [1 x i8] c"("
@.d112 = private constant [1 x i8] c")"
@.d113 = private constant [2 x i8] c": "
@.d114 = private constant [7 x i8] c"recode "
@.d115 = private constant [6 x i8] c" from "
@.d116 = private constant [4 x i8] c" to "
@.d117 = private constant [5 x i8] c"text "
@.d118 = private constant [4 x i8] c" in "
@.d119 = private constant [2 x i8] c": "
@.d120 = private constant [2 x i8] c", "
@.d121 = private constant [0 x i8] c""
@.d122 = private constant [3 x i8] c" = "
@.d123 = private constant [1 x i8] c"("
@.d124 = private constant [1 x i8] c")"
@.d125 = private constant [2 x i8] c" ["
@.d126 = private constant [1 x i8] c"]"
@.d127 = private constant [6 x i8] c" catch"
@.d128 = private constant [4 x i8] c" all"
@.d129 = private constant [0 x i8] c""
@.d130 = private constant [1 x i8] c"."
@.d131 = private constant [1 x i8] c" "
@.d132 = private constant [4 x i8] c" -> "
@.d133 = private constant [6 x i8] c"param "
@.d134 = private constant [8 x i8] c"capture "
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aVarKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 13, ptr @.d262 }, 1
  %t5 = extractvalue { i64, ptr } { i64 13, ptr @.d262 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d263 }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d263 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 1
  %t10 = getelementptr { i64 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  %t13 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t14 = call i64 @__olang_fmt_i64(ptr %t13, i64 %t11)
  call void @__olang_sb_add(ptr %v0, i64 %t14)
  %t15 = extractvalue { i64, ptr } { i64 1, ptr @.d264 }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr @.d264 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb3:
  %t17 = extractvalue { i64, ptr } { i64 14, ptr @.d265 }, 1
  %t18 = extractvalue { i64, ptr } { i64 14, ptr @.d265 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb4:
  %t19 = extractvalue { i64, ptr } { i64 16, ptr @.d266 }, 1
  %t20 = extractvalue { i64, ptr } { i64 16, ptr @.d266 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb5:
  %t21 = extractvalue { i64, ptr } { i64 15, ptr @.d267 }, 1
  %t22 = extractvalue { i64, ptr } { i64 15, ptr @.d267 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb6:
  %t23 = extractvalue { i64, ptr } { i64 15, ptr @.d268 }, 1
  %t24 = extractvalue { i64, ptr } { i64 15, ptr @.d268 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  %t25 = extractvalue { i64, ptr } { i64 1, ptr @.d263 }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d263 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr { i64, [1 x i64] }, ptr %t27, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  %t32 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t33 = call i64 @__olang_fmt_i64(ptr %t32, i64 %t30)
  call void @__olang_sb_add(ptr %v0, i64 %t33)
  %t34 = extractvalue { i64, ptr } { i64 1, ptr @.d264 }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr @.d264 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t34, i64 %t35)
  br label %bb1
bb7:
  %t36 = extractvalue { i64, ptr } { i64 15, ptr @.d269 }, 1
  %t37 = extractvalue { i64, ptr } { i64 15, ptr @.d269 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t36, i64 %t37)
  br label %bb1
ret:
  ret void
}

@.d135 = private constant [10 x i8] c"built in S"
@.d136 = private constant [19 x i8] c", which is not open"
@.d137 = private constant [10 x i8] c"built in S"
@.d138 = private constant [16 x i8] c", which is inert"
@.d139 = private constant [12 x i8] c"a call of a "
@.d140 = private constant [16 x i8] c", not a function"
@.d141 = private constant [9 x i8] c"enters bb"
@.d142 = private constant [13 x i8] c" with scopes "
@.d143 = private constant [25 x i8] c", where another path has "
@.d144 = private constant [6 x i8] c" is a "
@.d145 = private constant [8 x i8] c", not a "
@.d146 = private constant [8 x i8] c"operands"
@.d147 = private constant [2 x i8] c"a "
@.d148 = private constant [4 x i8] c" of "
@.d149 = private constant [15 x i8] c" parts made of "
@.d150 = private constant [5 x i8] c"part "
@.d151 = private constant [39 x i8] c" is a check: a test and a branch in MIR"
@.d152 = private constant [4 x i8] c" of "
@.d153 = private constant [9 x i8] c" operands"
@.d154 = private constant [6 x i8] c" of a "
@.d155 = private constant [6 x i8] c" of a "
@.d156 = private constant [6 x i8] c" of a "
@.d157 = private constant [6 x i8] c" of a "
@.d158 = private constant [7 x i8] c" typed "
@.d159 = private constant [9 x i8] c"Not of a "
@.d160 = private constant [6 x i8] c" of a "
@.d161 = private constant [7 x i8] c" and a "
@.d162 = private constant [6 x i8] c" of a "
@.d163 = private constant [7 x i8] c" typed "
@.d164 = private constant [10 x i8] c"Same of a "
@.d165 = private constant [7 x i8] c" and a "
@.d166 = private constant [11 x i8] c"Same typed "
@.d167 = private constant [9 x i8] c"Len of a "
@.d168 = private constant [10 x i8] c"Len typed "
@.d169 = private constant [12 x i8] c"Retire of a "
@.d170 = private constant [13 x i8] c"Retire typed "
@.d171 = private constant [12 x i8] c"IsCase of a "
@.d172 = private constant [13 x i8] c"IsCase typed "
@.d173 = private constant [6 x i8] c" of a "
@.d174 = private constant [40 x i8] c", not a writable reference to an integer"
@.d175 = private constant [11 x i8] c"'s operand "
@.d176 = private constant [18 x i8] c"AtomicStore typed "
@.d177 = private constant [7 x i8] c" typed "
@.d178 = private constant [6 x i8] c"scopes"
@.d179 = private constant [10 x i8] c"no scope S"
@.d180 = private constant [8 x i8] c"a slice "
@.d181 = private constant [6 x i8] c" of a "
@.d182 = private constant [34 x i8] c"a slice's bound that is no integer"
@.d183 = private constant [1 x i8] c"S"
@.d184 = private constant [24 x i8] c" opened while it is open"
@.d185 = private constant [1 x i8] c"S"
@.d186 = private constant [11 x i8] c" opened in "
@.d187 = private constant [20 x i8] c", not in its parent "
@.d188 = private constant [6 x i8] c"closed"
@.d189 = private constant [6 x i8] c"join S"
@.d190 = private constant [33 x i8] c" closed with tasks not waited for"
@.d191 = private constant [1 x i8] c"S"
@.d192 = private constant [32 x i8] c" given away, but it is no region"
@.d193 = private constant [10 x i8] c"given away"
@.d194 = private constant [14 x i8] c"a spawn into S"
@.d195 = private constant [19 x i8] c", which is not open"
@.d196 = private constant [29 x i8] c"deferred code registered at S"
@.d197 = private constant [19 x i8] c", which is not open"
@.d198 = private constant [1 x i8] c"L"
@.d199 = private constant [50 x i8] c" stored into with no storage: its Live not reached"
@.d200 = private constant [14 x i8] c"the case of a "
@.d201 = private constant [13 x i8] c", not an enum"
@.d202 = private constant [1 x i8] c"L"
@.d203 = private constant [36 x i8] c" given an error code with no storage"
@.d204 = private constant [25 x i8] c"leaves the function with "
@.d205 = private constant [5 x i8] c" open"
@.d206 = private constant [12 x i8] c"a wait for S"
@.d207 = private constant [19 x i8] c", which is not open"
@.d208 = private constant [1 x i8] c"S"
@.d209 = private constant [26 x i8] c" used where it is not open"
@.d210 = private constant [6 x i8] c" is a "
@.d211 = private constant [10 x i8] c", where a "
@.d212 = private constant [10 x i8] c" is wanted"
@.d213 = private constant [8 x i8] c"wanted '"
@.d214 = private constant [9 x i8] c"' among:\0A"
declare void @__olang_check_failed_text(ptr, { i64, ptr })
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cU8_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cU8_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t1)
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d215 = private unnamed_addr constant [15 x i8] c"LocalKind.Param"
declare void @__olang_sb_put(ptr, ptr, i64)
@.d216 = private unnamed_addr constant [17 x i8] c"LocalKind.Capture"
@.d217 = private unnamed_addr constant [13 x i8] c"LocalKind.Var"
@.d218 = private unnamed_addr constant [14 x i8] c"LocalKind.Temp"
@.d219 = private unnamed_addr constant [15 x i8] c"ScopeKind.Frame"
@.d220 = private unnamed_addr constant [15 x i8] c"ScopeKind.Block"
@.d221 = private unnamed_addr constant [14 x i8] c"ScopeKind.Loop"
@.d222 = private unnamed_addr constant [14 x i8] c"ScopeKind.Join"
@.d223 = private unnamed_addr constant [16 x i8] c"ScopeKind.Region"
@.d224 = private unnamed_addr constant [15 x i8] c"ScopeKind.Inert"
@.d225 = private unnamed_addr constant [17 x i8] c"ScopeKind.Builder"
@.d226 = private unnamed_addr constant [17 x i8] c"HelperKind.Render"
@.d227 = private unnamed_addr constant [16 x i8] c"HelperKind.Equal"
@.d228 = private unnamed_addr constant [15 x i8] c"HelperKind.Hash"
@.d229 = private unnamed_addr constant [15 x i8] c"HelperKind.Zero"
@.d230 = private unnamed_addr constant [10 x i8] c"PrimOp.Neg"
@.d231 = private unnamed_addr constant [13 x i8] c"PrimOp.BitNot"
@.d232 = private unnamed_addr constant [10 x i8] c"PrimOp.Not"
@.d233 = private unnamed_addr constant [10 x i8] c"PrimOp.Add"
@.d234 = private unnamed_addr constant [10 x i8] c"PrimOp.Sub"
@.d235 = private unnamed_addr constant [10 x i8] c"PrimOp.Mul"
@.d236 = private unnamed_addr constant [10 x i8] c"PrimOp.Div"
@.d237 = private unnamed_addr constant [10 x i8] c"PrimOp.Rem"
@.d238 = private unnamed_addr constant [10 x i8] c"PrimOp.Shl"
@.d239 = private unnamed_addr constant [10 x i8] c"PrimOp.Shr"
@.d240 = private unnamed_addr constant [13 x i8] c"PrimOp.BitAnd"
@.d241 = private unnamed_addr constant [12 x i8] c"PrimOp.BitOr"
@.d242 = private unnamed_addr constant [13 x i8] c"PrimOp.BitXor"
@.d243 = private unnamed_addr constant [9 x i8] c"PrimOp.Eq"
@.d244 = private unnamed_addr constant [9 x i8] c"PrimOp.Ne"
@.d245 = private unnamed_addr constant [9 x i8] c"PrimOp.Lt"
@.d246 = private unnamed_addr constant [9 x i8] c"PrimOp.Le"
@.d247 = private unnamed_addr constant [9 x i8] c"PrimOp.Gt"
@.d248 = private unnamed_addr constant [9 x i8] c"PrimOp.Ge"
@.d249 = private unnamed_addr constant [11 x i8] c"PrimOp.Same"
@.d250 = private unnamed_addr constant [14 x i8] c"PrimOp.Convert"
@.d251 = private unnamed_addr constant [14 x i8] c"PrimOp.Bitcast"
@.d252 = private unnamed_addr constant [10 x i8] c"PrimOp.Len"
@.d253 = private unnamed_addr constant [13 x i8] c"PrimOp.IsCase"
@.d254 = private unnamed_addr constant [14 x i8] c"PrimOp.InRange"
@.d255 = private unnamed_addr constant [18 x i8] c"PrimOp.InRangeIncl"
@.d256 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicLoad"
@.d257 = private unnamed_addr constant [18 x i8] c"PrimOp.AtomicStore"
@.d258 = private unnamed_addr constant [16 x i8] c"PrimOp.AtomicAdd"
@.d259 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicSwap"
@.d260 = private unnamed_addr constant [24 x i8] c"PrimOp.AtomicCompareSwap"
@.d261 = private unnamed_addr constant [13 x i8] c"PrimOp.Retire"
@.d262 = private unnamed_addr constant [13 x i8] c"VarKind.Param"
@.d263 = private unnamed_addr constant [1 x i8] c"("
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d264 = private unnamed_addr constant [1 x i8] c")"
@.d265 = private unnamed_addr constant [14 x i8] c"VarKind.Result"
@.d266 = private unnamed_addr constant [16 x i8] c"VarKind.Instance"
@.d267 = private unnamed_addr constant [15 x i8] c"VarKind.Closing"
@.d268 = private unnamed_addr constant [15 x i8] c"VarKind.Capture"
@.d269 = private unnamed_addr constant [15 x i8] c"VarKind.Builder"
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@olang_loc_84efd3c782aef4d6_8c92393edf5749f2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_419ac27aa82c7b2c_45256e944a6f3408 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare void @compiler_2fmir_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eSetAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Local" %a2)
declare %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %a0)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [7 x i64] } %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2ePush_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, %"compiler/mir:Case" %a1)
@olang_loc_f17cf97eff0353b6_fea489b4a6f80ab2 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2ePus_H34a38873c681933be8db0e4031fab6d9(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2ePush_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eLen_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2ePush_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eLe_Ha29d98bd5fca0556754225de6d8edaab(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2ePu_Hee8f32853b3aef818b7318957721fb5e(ptr %v0, ptr %a0, %"compiler/mir:TaskClause" %a1)
declare %"compiler/mir:Task" @compiler_2fmir_3aTask_2ector(ptr %v0, { i64, [5 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4, %"compiler/mir:Range" %a5, %"compiler/source:Span" %a6)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2ePush_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, %"compiler/mir:Task" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:dumper" @compiler_2fmir_3adumper_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2ePush_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_5b04576c3a0c01b1_2f8c01babecc81b5 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_14ebfa33b1d03356_270fe526a4636ad2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmir_2eshort(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8b8463115590657e_a0505b934de728da = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eterm(ptr %v0, ptr %v1, ptr %a0, { i64, [7 x i64] } %a1)
declare %"compiler/mir:Case" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_792180efaebdc40a_e488d776d0fba16e = external constant [0 x i8]
@olang_loc_4b3ff56260a2bca0_3dcb0434d488ed4c = external constant [0 x i8]
@olang_loc_2f605f8b851f9dfa_b0e742a1ba211956 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ddfec86899b5c27b_91be796056af7d77 = external constant [0 x i8]
@olang_loc_3c759898227385e0_43502750c3b6307c = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
@olang_loc_55b2be13c853614c_e5b496909f3a0f10 = external constant [0 x i8]
declare %"compiler/mir:Place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %v1, ptr %a0, { i64, [5 x i64] } %a1)
declare %"compiler/mir:TaskClause" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eAt_H2a51e389d978bc4a54496c3113cf8f80(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6326b544498e75fa_e53a2c99f88826ee = external constant [0 x i8]
declare { i64, [4 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a15aa4830130cc38_9fcdb454ad4b970c = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
@olang_loc_43daeee16a7347fc_3936ff71893c42a0 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
@olang_loc_690174ade0b6e824_1aa5c898f3f73ab8 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eRunFrom_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e290732eef120a74_d968defd427617c0 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3fc64ab4d22c7cd1_9c9bbb4060ef765d = external constant [0 x i8]
@olang_loc_82a5970c46c34ec4_64144421b638a2b0 = external constant [0 x i8]
@olang_loc_2ac31f2db6082ba7_5ac69b59325af853 = external constant [0 x i8]
@olang_loc_397ae699ba890fb2_f6680c8259f4281e = external constant [0 x i8]
@olang_loc_2836fb8ea59de3a5_79eeb5d0a68fc1c9 = external constant [0 x i8]
@olang_loc_13b0920ad4a1e938_72d556b41507b57c = external constant [0 x i8]
@olang_loc_f0f79482ff998b1b_575016ccefde52df = external constant [0 x i8]
@olang_loc_a4c79ab2e91ac186_f4797f1baf8f450a = external constant [0 x i8]
@olang_loc_2c486f9205676389_1881cd4b4e7e41e5 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eRunFrom_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_76008615ce7bb613_dfc695a1b8c60ec7 = external constant [0 x i8]
@olang_loc_6235ba26342102c9_f7dccacc13d72055 = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6a09071e7826f026_b8c4b46880cabab2 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_d0c28dbd82f4c36a_9dd446291f7ee706 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %a0, i32 %a1, %"compiler/mir:Range" %a2, i32 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_7968c2a45e42402b_522993cc8bbef1e7 = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_d06e38c3720099d6_401a7f863dec038a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueFlow(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
declare %"compiler/mir:Task" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_30c75e8686103aec_2a803509807dc2e8 = external constant [0 x i8]
@olang_loc_8c773ec7d9409528_6b556770aed18854 = external constant [0 x i8]
declare %"compiler/mir:Call" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d66c95c574566df8_862c2f5cde7f4614 = external constant [0 x i8]
@olang_loc_587900af1cc61a9a_48225b2d2b7d46c6 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2787a88b0b468961_ce97027662ecd8ed = external constant [0 x i8]
@olang_loc_5380db3ec2a99a3_371ccfada9fdfeef = external constant [0 x i8]
@olang_loc_5983d076d5883d2e_1665ff00cbce2e1a = external constant [0 x i8]
@olang_loc_910dd2c5a789172d_f03cfbb9736a8799 = external constant [0 x i8]
@olang_loc_2a1e3324a3ced000_b715b4216485c88c = external constant [0 x i8]
@olang_loc_424aba850193e62f_5d41a9f8bd7e1e63 = external constant [0 x i8]
@olang_loc_26e15834dfadce5a_40849b88d9a51eee = external constant [0 x i8]
@olang_loc_390ccbe637d1d3d9_30a6ef9f1a3ec7ed = external constant [0 x i8]
@olang_loc_1f26baa5abf820cc_81869963bb6d62c0 = external constant [0 x i8]
@olang_loc_200617782b41aa6b_62fe98f9543f67b7 = external constant [0 x i8]
@olang_loc_d8b0f1b6ba5e5556_5a69466de52f9302 = external constant [0 x i8]
declare void @compiler_2fmir_2eNoBlock_2einit()
declare void @compiler_2fmir_2eNoLocal_2einit()
declare void @compiler_2fmir_2eNoPlace_2einit()
declare void @compiler_2fmir_2eI32T_2einit()
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cU8_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
