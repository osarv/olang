; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/mir:dumper" = type { ptr, ptr, %"std/prelude/text:StringBuilder" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [8 x i64] } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/mir:verifier" = type { ptr, ptr, %"std/prelude/text:StringBuilder", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
@G_2ecompiler_2fmir_2eEmpty = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eI32T = constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eI64T = constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoLocal = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoPlace = constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2fmir_2eNoScope = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eSp0 = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
define dso_local void @compiler_2fmir_2eEmpty_2einit() #0 {
entry:
  %l0 = alloca %"compiler/mir:Range"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %t1, i32 0, i32 0)
  store %"compiler/mir:Range" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/mir:Range", ptr %l0
  store %"compiler/mir:Range" %t3, ptr @G_2ecompiler_2fmir_2eEmpty
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l51 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i1
  %l68 = alloca i64
  %l71 = alloca i64
  %l89 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l28, !tbaa !24
  store i64 %t37, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l25, !tbaa !24
  store i64 %t38, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l10, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l46, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t59, ptr %l48, !tbaa !27
  %t60 = load i64, ptr %l10, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i32, ptr %t63, i64 %t60
  %t65 = load i32, ptr %t64, !tbaa !33
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t58, i32 %t65)
  store i32 %t68, ptr %l51
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t69, i32 %a2)
  store i32 %t73, ptr %l54
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l46, !tbaa !29
  %t75 = load i32, ptr %l51, !tbaa !23
  %t76 = load i32, ptr %l54, !tbaa !23
  %t77 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t74, i32 %t75, i32 %t76)
  store i1 %t77, ptr %l55
  br label %bb14
bb14:
  %t78 = load i1, ptr %l55, !tbaa !21
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t81 = add i64 %t79, 1
  %t83 = shl i64 %t81, 16
  %t87 = or i64 %t83, %a3
  store i64 %t87, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb8
bb19:
  store i64 0, ptr %l11, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t97 = load i64, ptr %l12, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb20, label %bb21
bb20:
  %t103 = load i64, ptr %l13, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb25
bb22:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l13, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l71, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb24
bb24:
  %t123 = load i64, ptr %l71, !tbaa !24
  store i64 %t123, ptr %l68, !tbaa !24
  br label %bb25
bb25:
  %t124 = load i64, ptr %l68, !tbaa !24
  store i64 %t124, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb26
bb26:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb27, label %bb28
bb27:
  br label %bb34
bb28:
  br label %bb29
bb29:
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l16, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t143, ptr %l89, !tbaa !27
  %t144 = load i64, ptr %l16, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 %t144
  %t149 = load i32, ptr %t148, !tbaa !33
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb30, label %bb31
bb30:
  %t155 = load i64, ptr %l16, !tbaa !24
  %t157 = add i64 %t155, 1
  %t159 = shl i64 %t157, 16
  store i64 %t159, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t161 = load i64, ptr %l15, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l15, !tbaa !24
  br label %bb26
bb34:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2eExitText(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb9
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 1 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 13 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 14 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb10:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 2 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb14:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 3 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb18:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 4 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb22:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 5 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb26:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 6 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb30:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 7 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb34:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 8 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb38:
  %t56 = load i32, ptr %l0
  %t58 = trunc i64 9 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb42:
  %t61 = load i32, ptr %l0
  %t63 = trunc i64 10 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb46:
  %t66 = load i32, ptr %l0
  %t68 = trunc i64 11 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb50:
  %t71 = load i32, ptr %l0
  %t73 = trunc i64 12 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_84efd3c782aef4d6_8c92393edf5749f2)
  unreachable
bb55:
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2eI64T_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 6, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eNoScope_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 -1, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2) #0 {
entry:
  %l1 = alloca { i64, [7 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l43 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %rv = alloca i64
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [2 x i64] }, ptr %t7
  %t10 = extractvalue { i64, [2 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 2
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb3:
  %t13 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t13, i32 0, i32 0
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32, i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t19 = trunc i64 0 to i32
  %t20 = icmp eq i32 %t17, %t19
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l10, !tbaa !21
  store i1 %t22, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l7, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb14
bb8:
  %t24 = load { i64, [7 x i64] }, ptr %l1
  %t26 = extractvalue { i64, [7 x i64] } %t24, 0
  %t27 = icmp eq i64 %t26, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t30 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t29, i32 0, i32 0
  %t31 = load { i64, [2 x i64] }, ptr %t30
  %t33 = extractvalue { i64, [2 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 4
  store i1 %t34, ptr %l15, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l15, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 1, ptr %l4, !tbaa !24
  br label %bb49
bb15:
  %t37 = load { i64, [7 x i64] }, ptr %l1
  %t39 = extractvalue { i64, [7 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 0
  br i1 %t40, label %bb16, label %bb17
bb16:
  %t42 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t42, i32 0, i32 0
  %t44 = load { i64, [2 x i64] }, ptr %t43
  %t46 = extractvalue { i64, [2 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 2
  br i1 %t47, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb21
bb18:
  %t49 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t50 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t49, i32 0, i32 0
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  %t55 = trunc i64 1 to i32
  %t56 = icmp eq i32 %t53, %t55
  store i1 %t56, ptr %l23, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l23, !tbaa !21
  store i1 %t58, ptr %l20, !tbaa !21
  br label %bb21
bb21:
  %t59 = load i1, ptr %l20, !tbaa !21
  br i1 %t59, label %bb22, label %bb23
bb22:
  br label %bb32
bb23:
  %t60 = load { i64, [7 x i64] }, ptr %l1
  %t62 = extractvalue { i64, [7 x i64] } %t60, 0
  %t63 = icmp eq i64 %t62, 0
  br i1 %t63, label %bb24, label %bb25
bb24:
  %t65 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t66 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t65, i32 0, i32 0
  %t67 = load { i64, [2 x i64] }, ptr %t66
  %t69 = extractvalue { i64, [2 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 2
  br i1 %t70, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb29
bb26:
  %t72 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t73 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t72, i32 0, i32 0
  %t74 = getelementptr { i64, [2 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { i32, i32 }, ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75
  %t78 = trunc i64 2 to i32
  %t79 = icmp eq i32 %t76, %t78
  store i1 %t79, ptr %l31, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb28
bb28:
  %t81 = load i1, ptr %l31, !tbaa !21
  store i1 %t81, ptr %l28, !tbaa !21
  br label %bb29
bb29:
  %t82 = load i1, ptr %l28, !tbaa !21
  br i1 %t82, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb49
bb33:
  %t83 = load { i64, [7 x i64] }, ptr %l1
  %t85 = extractvalue { i64, [7 x i64] } %t83, 0
  %t86 = icmp eq i64 %t85, 1
  br i1 %t86, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb49
bb37:
  %t88 = load { i64, [7 x i64] }, ptr %l1
  %t90 = extractvalue { i64, [7 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 3
  br i1 %t91, label %bb38, label %bb39
bb38:
  %t93 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t94 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t93, i32 0, i32 1
  %t95 = load i64, ptr %t94
  store i64 %t95, ptr %l3, !tbaa !24
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t97 = load i64, ptr %l3, !tbaa !24
  %t99 = icmp slt i64 %t97, 0
  br i1 %t99, label %bb41, label %bb42
bb41:
  store i64 1, ptr %l4, !tbaa !24
  br label %bb49
bb42:
  br label %bb43
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s5
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s5, ptr %a0, i32 %a2)
  store { i64, ptr } %t105, ptr %l43
  br label %bb47
bb47:
  %t106 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_419ac27aa82c7b2c_45256e944a6f3408)
  unreachable
bb49:
  %t109 = load i64, ptr %l4, !tbaa !24
  store i64 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fmir_2eSp0_2einit() #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %t1, i32 0, i32 0)
  store %"compiler/source:Span" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t3, ptr @G_2ecompiler_2fmir_2eSp0
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eaddFn(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l15 = alloca i32
  %l16 = alloca %"compiler/mir:Fn"
  %l17 = alloca ptr
  %l20 = alloca i32
  %l25 = alloca %"compiler/mir:Local"
  %l26 = alloca ptr
  %l29 = alloca i32
  %l34 = alloca %"compiler/mir:Local"
  %l35 = alloca ptr
  %l38 = alloca i32
  %l43 = alloca %"compiler/mir:Local"
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca %"compiler/source:Span"
  %l49 = alloca %"compiler/mir:Place"
  %l50 = alloca i32
  %l51 = alloca i32
  %l52 = alloca ptr
  %l53 = alloca %"compiler/mir:Place"
  %l54 = alloca { i64, [4 x i64] }
  %l55 = alloca %"compiler/mir:Place"
  %l57 = alloca { i64, ptr }
  %l58 = alloca %"compiler/mir:Range"
  %l67 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca %"compiler/source:Span"
  %l71 = alloca %"compiler/mir:Place"
  %l74 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t30 = alloca %"compiler/mir:Fn", align 8
  %t45 = alloca { i64, [1 x i64] }, align 8
  %t66 = alloca { i64, [1 x i64] }, align 8
  %t86 = alloca { i64, [1 x i64] }, align 8
  %t108 = alloca { i64, [4 x i64] }, align 8
  %t115 = alloca { i64, [4 x i64] }, align 8
  %t136 = alloca { i64, [15 x i64] }, align 8
  %t146 = alloca { i64, [21 x i64] }, align 8
  %t164 = alloca { i64, [21 x i64] }, align 8
  %t182 = alloca { i64, [4 x i64] }, align 8
  %t188 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i32 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i32, ptr %l6, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t9 = load i32, ptr %l1, !tbaa !23
  %t10 = mul i64 2, 4
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 2, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l12, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i32, ptr %t16, i64 0
  store i32 %t8, ptr %t17, !tbaa !33
  %t19 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 1
  store i32 %t9, ptr %t21, !tbaa !33
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t7, { i64, ptr } %t23)
  store i32 %t24, ptr %l13
  br label %bb2
bb2:
  %t25 = load i32, ptr %l1, !tbaa !23
  %t26 = load ptr, ptr %l8, !tbaa !29
  %t27 = load i32, ptr %l13, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t26, i32 %t27, i32 %t25, i32 0, i32 0, i64 0)
  store i32 %t29, ptr %l15
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l7, !tbaa !29
  %t32 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fmir_2etfn(ptr %t30, ptr %v0, ptr %v1, ptr %t31, i32 %t32)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t30, i64 248, i1 false)
  br label %bb4
bb4:
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 248, i64 8)
  store ptr %t33, ptr %lp2
  %t34 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t34, ptr %l16, i64 248, i1 false)
  %t35 = load ptr, ptr %lp2
  %t36 = getelementptr %"compiler/mir:Fn", ptr %t35, i32 0, i32 7
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/types:Table", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t40, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i32 %t42, ptr %l20
  br label %bb5
bb5:
  %t43 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t44 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t45
  %t46 = getelementptr { i64, [1 x i64] }, ptr %t45, i32 0, i32 0
  store i64 3, ptr %t46
  %t47 = load { i64, [1 x i64] }, ptr %t45
  %t48 = load i32, ptr %l20, !tbaa !23
  %t53 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t48, %"compiler/source:Span" %t43, i32 %t44, i32 0, { i64, [1 x i64] } %t47)
  store %"compiler/mir:Local" %t53, ptr %l25
  br label %bb6
bb6:
  %t54 = load ptr, ptr %l17, !tbaa !29
  %t55 = load %"compiler/mir:Local", ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eSetAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t54, i64 0, %"compiler/mir:Local" %t55)
  br label %bb7
bb7:
  %t56 = load ptr, ptr %lp2
  %t57 = getelementptr %"compiler/mir:Fn", ptr %t56, i32 0, i32 7
  store ptr %t57, ptr %l26, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/types:Table", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t61, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i32 %t63, ptr %l29
  br label %bb8
bb8:
  %t64 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t65 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [1 x i64] }, ptr %t66, i32 0, i32 0
  store i64 3, ptr %t67
  %t68 = load { i64, [1 x i64] }, ptr %t66
  %t69 = load i32, ptr %l29, !tbaa !23
  %t74 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t69, %"compiler/source:Span" %t64, i32 %t65, i32 0, { i64, [1 x i64] } %t68)
  store %"compiler/mir:Local" %t74, ptr %l34
  br label %bb9
bb9:
  %t75 = load ptr, ptr %l26, !tbaa !29
  %t76 = load %"compiler/mir:Local", ptr %l34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eSetAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t75, i64 1, %"compiler/mir:Local" %t76)
  br label %bb10
bb10:
  %t77 = load ptr, ptr %lp2
  store ptr %t77, ptr %l35, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/types:Table", ptr %t78, i32 0, i32 0
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t81, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i32 %t83, ptr %l38
  br label %bb11
bb11:
  %t84 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t85 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [1 x i64] }, ptr %t86, i32 0, i32 0
  store i64 3, ptr %t87
  %t88 = load { i64, [1 x i64] }, ptr %t86
  %t89 = load i32, ptr %l38, !tbaa !23
  %t94 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t89, %"compiler/source:Span" %t84, i32 %t85, i32 2, { i64, [1 x i64] } %t88)
  store %"compiler/mir:Local" %t94, ptr %l43
  br label %bb12
bb12:
  %t95 = load ptr, ptr %l35, !tbaa !29
  %t96 = load %"compiler/mir:Local", ptr %l43
  %t97 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v1, ptr %t95, %"compiler/mir:Local" %t96)
  store i32 %t97, ptr %l44
  br label %bb13
bb13:
  %t98 = load i32, ptr %l44, !tbaa !23
  store i32 %t98, ptr %l3, !tbaa !23
  store i32 0, ptr %l4, !tbaa !23
  %t99 = load ptr, ptr %lp2
  store ptr %t99, ptr %l45, !tbaa !29
  %t100 = load i32, ptr %l4, !tbaa !23
  store i32 %t100, ptr %l46, !tbaa !23
  %t101 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t101, ptr %l47
  %t102 = load i32, ptr %l3, !tbaa !23
  %t104 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t102)
  store %"compiler/mir:Place" %t104, ptr %l49
  br label %bb14
bb14:
  store i32 3, ptr %l50
  %t105 = load i32, ptr %l1, !tbaa !23
  store i32 %t105, ptr %l51, !tbaa !23
  %t106 = load ptr, ptr %lp2
  store ptr %t106, ptr %l52, !tbaa !29
  %t107 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 0)
  store %"compiler/mir:Place" %t107, ptr %l53
  br label %bb15
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t108
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 0
  store i64 1, ptr %t109
  %t110 = load %"compiler/mir:Place", ptr %l53
  %t111 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t110, 0
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  store { %"compiler/mir:Place" } %t111, ptr %t112
  %t113 = load { i64, [4 x i64] }, ptr %t108
  store { i64, [4 x i64] } %t113, ptr %l54
  %t114 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 1)
  store %"compiler/mir:Place" %t114, ptr %l55
  br label %bb16
bb16:
  store { i64, [4 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 0
  store i64 1, ptr %t116
  %t117 = load %"compiler/mir:Place", ptr %l55
  %t118 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t117, 0
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  store { %"compiler/mir:Place" } %t118, ptr %t119
  %t120 = load { i64, [4 x i64] }, ptr %t115
  %t121 = mul i64 2, 40
  %t122 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 2, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l57, !tbaa !27
  %t125 = load { i64, [4 x i64] }, ptr %l54
  %t126 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t127, i64 0
  store { i64, [4 x i64] } %t125, ptr %t128
  %t130 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t131, i64 1
  store { i64, [4 x i64] } %t120, ptr %t132
  %t133 = load ptr, ptr %l52, !tbaa !29
  %t134 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t135 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t133, { i64, ptr } %t134)
  store %"compiler/mir:Range" %t135, ptr %l58
  br label %bb17
bb17:
  store { i64, [15 x i64] } zeroinitializer, ptr %t136
  %t137 = getelementptr { i64, [15 x i64] }, ptr %t136, i32 0, i32 0
  store i64 3, ptr %t137
  %t138 = load i32, ptr %l50
  %t139 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t138, 0
  %t140 = load i32, ptr %l51, !tbaa !23
  %t141 = insertvalue { i32, i32, %"compiler/mir:Range" } %t139, i32 %t140, 1
  %t142 = load %"compiler/mir:Range", ptr %l58
  %t143 = insertvalue { i32, i32, %"compiler/mir:Range" } %t141, %"compiler/mir:Range" %t142, 2
  %t144 = getelementptr { i64, [15 x i64] }, ptr %t136, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t143, ptr %t144
  %t145 = load { i64, [15 x i64] }, ptr %t136
  store { i64, [21 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [21 x i64] }, ptr %t146, i32 0, i32 0
  store i64 0, ptr %t147
  %t148 = load %"compiler/source:Span", ptr %l47
  %t149 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t148, 0
  %t150 = load %"compiler/mir:Place", ptr %l49
  %t151 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t149, %"compiler/mir:Place" %t150, 1
  %t153 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t151, { i64, [15 x i64] } %t145, 2
  %t154 = getelementptr { i64, [21 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t153, ptr %t154
  %t155 = load { i64, [21 x i64] }, ptr %t146
  %t157 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t155, ptr %t157
  %t158 = load ptr, ptr %l45, !tbaa !29
  %t159 = load i32, ptr %l46, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t158, i32 %t159, ptr %t157)
  br label %bb18
bb18:
  %t161 = load ptr, ptr %lp2
  %t162 = load i32, ptr %l4, !tbaa !23
  %t163 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t164
  %t165 = getelementptr { i64, [21 x i64] }, ptr %t164, i32 0, i32 0
  store i64 4, ptr %t165
  %t167 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t163, 0
  %t168 = insertvalue { %"compiler/source:Span", i32 } %t167, i32 0, 1
  %t169 = getelementptr { i64, [21 x i64] }, ptr %t164, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t168, ptr %t169
  %t170 = load { i64, [21 x i64] }, ptr %t164
  %t172 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t170, ptr %t172
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t161, i32 %t162, ptr %t172)
  br label %bb19
bb19:
  %t176 = load ptr, ptr %lp2
  store ptr %t176, ptr %l67, !tbaa !29
  %t177 = load i32, ptr %l4, !tbaa !23
  store i32 %t177, ptr %l68, !tbaa !23
  %t178 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t178, ptr %l69
  %t179 = load i32, ptr %l3, !tbaa !23
  %t181 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t179)
  store %"compiler/mir:Place" %t181, ptr %l71
  br label %bb20
bb20:
  store { i64, [4 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 0
  store i64 1, ptr %t183
  %t184 = load %"compiler/mir:Place", ptr %l71
  %t185 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t184, 0
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 1
  store { %"compiler/mir:Place" } %t185, ptr %t186
  %t187 = load { i64, [4 x i64] }, ptr %t182
  store { i64, [8 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [8 x i64] }, ptr %t188, i32 0, i32 0
  store i64 5, ptr %t189
  %t190 = load %"compiler/source:Span", ptr %l69
  %t191 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t190, 0
  %t193 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t191, { i64, [4 x i64] } %t187, 1
  %t194 = getelementptr { i64, [8 x i64] }, ptr %t188, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t193, ptr %t194
  %t195 = load { i64, [8 x i64] }, ptr %t188
  %t196 = load ptr, ptr %l67, !tbaa !29
  %t197 = load i32, ptr %l68, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t196, i32 %t197, { i64, [8 x i64] } %t195)
  br label %bb21
bb21:
  %t199 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %t199, i64 248, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l74, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCases(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 15
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/mir:Case", ptr %t25, i64 %t22
  %t27 = load %"compiler/mir:Case", ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2ePush_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t31, %"compiler/mir:Case" %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca %"compiler/mir:Range"
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca %"compiler/mir:Range"
  %l40 = alloca i64
  %rv = alloca i32
  %t17 = alloca { i64, [1 x i64] }, align 8
  %t44 = alloca { i64, [1 x i64] }, align 8
  %t71 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l2, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i64, ptr %l2, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [1 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t20 = insertvalue { i64 } undef, i64 %t16, 0
  %t21 = getelementptr { i64, [1 x i64] }, ptr %t17, i32 0, i32 1
  store { i64 } %t20, ptr %t21
  %t22 = load { i64, [1 x i64] }, ptr %t17
  store { i64, [1 x i64] } %t22, ptr %l6
  br label %bb21
bb6:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l16, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr } }, ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l3, !tbaa !27
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddBytes(ptr %v0, ptr %v1, ptr %t39, { i64, ptr } %t40)
  store %"compiler/mir:Range" %t43, ptr %l23
  br label %bb12
bb12:
  store { i64, [1 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [1 x i64] }, ptr %t44, i32 0, i32 0
  store i64 1, ptr %t45
  %t46 = load %"compiler/mir:Range", ptr %l23
  %t47 = insertvalue { %"compiler/mir:Range" } undef, %"compiler/mir:Range" %t46, 0
  %t48 = getelementptr { i64, [1 x i64] }, ptr %t44, i32 0, i32 1
  store { %"compiler/mir:Range" } %t47, ptr %t48
  %t49 = load { i64, [1 x i64] }, ptr %t44
  store { i64, [1 x i64] } %t49, ptr %l6
  br label %bb21
bb13:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l25, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 2
  store i1 %t58, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l26, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [2 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { { i64, ptr } }, ptr %t62, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  store { i64, ptr } %t64, ptr %l4, !tbaa !27
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddConstItems(ptr %v0, ptr %v1, ptr %t66, { i64, ptr } %t67)
  store %"compiler/mir:Range" %t70, ptr %l33
  br label %bb19
bb19:
  store { i64, [1 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [1 x i64] }, ptr %t71, i32 0, i32 0
  store i64 2, ptr %t72
  %t73 = load %"compiler/mir:Range", ptr %l33
  %t74 = insertvalue { %"compiler/mir:Range" } undef, %"compiler/mir:Range" %t73, 0
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t71, i32 0, i32 1
  store { %"compiler/mir:Range" } %t74, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t71
  store { i64, [1 x i64] } %t76, ptr %l6
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f17cf97eff0353b6_fea489b4a6f80ab2)
  unreachable
bb21:
  %t78 = load { i64, [1 x i64] }, ptr %l6
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/mir:Fn", ptr %t79, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2ePush_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t81, { i64, [1 x i64] } %t78)
  br label %bb22
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/mir:Fn", ptr %t85, i32 0, i32 19
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t87)
  store i64 %t89, ptr %l40
  br label %bb23
bb23:
  %t90 = load i64, ptr %l40, !tbaa !24
  %t91 = sub i64 %t90, 1
  %t93 = trunc i64 %t91 to i32
  store i32 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2ePush_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t3, %"compiler/mir:Local" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 7
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l11 = alloca %"compiler/mir:Local"
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t5 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 0
  store i64 3, ptr %t6
  %t7 = load { i64, [1 x i64] }, ptr %t5
  %t13 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 0, { i64, [1 x i64] } %t7)
  store %"compiler/mir:Local" %t13, ptr %l11
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = load %"compiler/mir:Local", ptr %l11
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %t14, %"compiler/mir:Local" %t15)
  store i32 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i32, ptr %l12, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/mir:Fn", ptr %t18, i32 0, i32 4
  %t21 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t20, i32 %t21)
  br label %bb3
bb3:
  %t24 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTask(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [7 x i64] } %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Range" %a3, { i64, ptr } %a4, { i64, ptr } %a5, %"compiler/mir:Range" %a6, %"compiler/source:Span" %a7, %"compiler/mir:Range" %a8) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l21 = alloca i64
  %l29 = alloca { i64, ptr }
  %l39 = alloca i64
  %l47 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca { i64, [7 x i64] }
  %l58 = alloca %"compiler/mir:Range"
  %l59 = alloca %"compiler/mir:Range"
  %l65 = alloca %"compiler/mir:Range"
  %l71 = alloca %"compiler/mir:Range"
  %l75 = alloca %"compiler/mir:Task"
  %l78 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2eLen_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load i64, ptr %l21, !tbaa !24
  store i64 %t6, ptr %l9, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t7, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l12, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l12, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t21, ptr %l29, !tbaa !27
  %t22 = load i64, ptr %l11, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/mir:Place", ptr %t25, i64 %t22
  %t27 = load %"compiler/mir:Place", ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2ePush_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t31, %"compiler/mir:Place" %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l11, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l11, !tbaa !24
  br label %bb2
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/mir:Fn", ptr %t39, i32 0, i32 17
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eLen_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l39
  br label %bb9
bb9:
  %t44 = load i64, ptr %l39, !tbaa !24
  store i64 %t44, ptr %l14, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t45, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l17, !tbaa !24
  br label %bb10
bb10:
  %t51 = load i64, ptr %l16, !tbaa !24
  %t52 = load i64, ptr %l17, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t59 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t59, ptr %l47, !tbaa !27
  %t60 = load i64, ptr %l16, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr %"compiler/mir:TaskClause", ptr %t63, i64 %t60
  %t65 = load %"compiler/mir:TaskClause", ptr %t64
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/mir:Fn", ptr %t67, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2ePush_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t69, %"compiler/mir:TaskClause" %t65)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t73 = load i64, ptr %l16, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l16, !tbaa !24
  br label %bb10
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/mir:Fn", ptr %t77, i32 0, i32 16
  store ptr %t79, ptr %l56, !tbaa !29
  store { i64, [7 x i64] } %a1, ptr %l57
  store %"compiler/mir:Range" %a2, ptr %l58
  store %"compiler/mir:Range" %a3, ptr %l59
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = trunc i64 %t83 to i32
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t90 = trunc i64 %t88 to i32
  %t93 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t85, i32 %t90)
  store %"compiler/mir:Range" %t93, ptr %l65
  br label %bb17
bb17:
  %t94 = load i64, ptr %l14, !tbaa !24
  %t96 = trunc i64 %t94 to i32
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t101 = trunc i64 %t99 to i32
  %t104 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t96, i32 %t101)
  store %"compiler/mir:Range" %t104, ptr %l71
  br label %bb18
bb18:
  %t108 = load { i64, [7 x i64] }, ptr %l57
  %t109 = load %"compiler/mir:Range", ptr %l58
  %t110 = load %"compiler/mir:Range", ptr %l59
  %t111 = load %"compiler/mir:Range", ptr %l65
  %t112 = load %"compiler/mir:Range", ptr %l71
  %t116 = call %"compiler/mir:Task" @compiler_2fmir_3aTask_2ector(ptr %s0, { i64, [7 x i64] } %t108, %"compiler/mir:Range" %t109, %"compiler/mir:Range" %t110, %"compiler/mir:Range" %t111, %"compiler/mir:Range" %t112, %"compiler/mir:Range" %a6, %"compiler/source:Span" %a7, %"compiler/mir:Range" %a8)
  store %"compiler/mir:Task" %t116, ptr %l75
  br label %bb19
bb19:
  %t117 = load ptr, ptr %l56, !tbaa !29
  %t118 = load %"compiler/mir:Task", ptr %l75
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2ePush_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t117, %"compiler/mir:Task" %t118)
  br label %bb20
bb20:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/mir:Fn", ptr %t119, i32 0, i32 16
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t121)
  store i64 %t123, ptr %l78
  br label %bb21
bb21:
  %t124 = load i64, ptr %l78, !tbaa !24
  %t125 = sub i64 %t124, 1
  %t127 = trunc i64 %t125 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t127, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca %"compiler/mir:dumper"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/mir:dumper" @compiler_2fmir_3adumper_2ector(ptr %v0, ptr %v1, ptr %v1, ptr %a0, ptr %a1)
  store %"compiler/mir:dumper" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"compiler/mir:dumper", ptr %l5
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/mir:dumper" %t6, ptr %t7
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eall(ptr %v1, ptr %t9)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/mir:dumper", ptr %t11, i32 0, i32 2
  %t15 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v1, ptr %v2, ptr %t13)
  store { i64, ptr } %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l12, !tbaa !24
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l13, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l12, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t30, ptr %l11, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 12
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [1 x i64] }, ptr %t25, i64 %t22
  %t27 = load { i64, [1 x i64] }, ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ePush_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t31, { i64, [1 x i64] } %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddBytes(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 21
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i8, ptr %t25, i64 %t22
  %t27 = load i8, ptr %t26, !tbaa !32
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t31, i8 %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddConstItems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca i32
  %l55 = alloca i64
  %l63 = alloca { i64, ptr }
  %l76 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l15, !tbaa !24
  %t4 = load i64, ptr %l15, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l15, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_5b04576c3a0c01b1_2f8c01babecc81b5)
  unreachable
bb3:
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5b04576c3a0c01b1_2f8c01babecc81b5)
  unreachable
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb10
bb7:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l27, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l27, !tbaa !24
  store i64 %t46, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l24, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  store i64 %t66, ptr %l45, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l47, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t77 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %t67, ptr %t74)
  store i32 %t77, ptr %l50
  br label %bb15
bb15:
  %t78 = load i32, ptr %l50, !tbaa !23
  %t79 = load i64, ptr %l45, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i32, ptr %t81, i64 %t79
  store i32 %t78, ptr %t82, !tbaa !33
  br label %bb16
bb16:
  %t83 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/mir:Fn", ptr %t87, i32 0, i32 20
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t89)
  store i64 %t91, ptr %l55
  br label %bb18
bb18:
  %t92 = load i64, ptr %l55, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l12, !tbaa !24
  br label %bb19
bb19:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t107, ptr %l63, !tbaa !27
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 %t108
  %t113 = load i32, ptr %t112, !tbaa !33
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/mir:Fn", ptr %t115, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t117, i32 %t113)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l11, !tbaa !24
  br label %bb19
bb25:
  %t125 = load i64, ptr %l9, !tbaa !24
  %t127 = trunc i64 %t125 to i32
  %t128 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t132 = trunc i64 %t130 to i32
  %t135 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t127, i32 %t132)
  store %"compiler/mir:Range" %t135, ptr %l76
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load %"compiler/mir:Range", ptr %l76
  store %"compiler/mir:Range" %t136, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aKey_2eText(ptr %v0, { i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t7 = getelementptr { i32, %"compiler/source:Span" }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l1, !tbaa !23
  %t10 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t11 = getelementptr { i32, %"compiler/source:Span" }, ptr %t10, i32 0, i32 1
  %t12 = load %"compiler/source:Span", ptr %t11
  store %"compiler/source:Span" %t12, ptr %l2
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t19 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t22 = sext i32 %t14 to i64
  %t23 = call i64 @__olang_fmt_i64(ptr null, i64 %t22)
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = sext i32 %t16 to i64
  %t30 = call i64 @__olang_fmt_i64(ptr null, i64 %t29)
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t36 = sext i32 %t18 to i64
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t36)
  %t38 = add i64 %t34, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t19, i64 %t20)
  %t40 = getelementptr i8, ptr %t39, i64 %t20
  %t41 = call i64 @__olang_fmt_i64(ptr %t40, i64 %t22)
  %t42 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t42, ptr %t25, i64 %t26)
  %t43 = getelementptr i8, ptr %t42, i64 %t26
  %t44 = call i64 @__olang_fmt_i64(ptr %t43, i64 %t29)
  %t45 = getelementptr i8, ptr %t43, i64 %t30
  call void @olang_textcopy(ptr %t45, ptr %t32, i64 %t33)
  %t46 = getelementptr i8, ptr %t45, i64 %t33
  %t47 = call i64 @__olang_fmt_i64(ptr %t46, i64 %t36)
  %t48 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t39, 1
  store { i64, ptr } %t49, ptr %l8, !tbaa !27
  br label %bb17
bb4:
  %t51 = load { i64, [2 x i64] }, ptr %l0
  %t53 = extractvalue { i64, [2 x i64] } %t51, 0
  %t54 = icmp eq i64 %t53, 1
  br i1 %t54, label %bb5, label %bb6
bb5:
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t57 = getelementptr { i64, i32 }, ptr %t56, i32 0, i32 0
  %t58 = load i64, ptr %t57
  store i64 %t58, ptr %l3, !tbaa !24
  %t60 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t61 = getelementptr { i64, i32 }, ptr %t60, i32 0, i32 1
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l4, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t65 = load i32, ptr %l4, !tbaa !23
  %t66 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t69 = call i64 @__olang_fmt_i64(ptr null, i64 %t64)
  %t70 = add i64 %t67, %t69
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t75 = sext i32 %t65 to i64
  %t76 = call i64 @__olang_fmt_i64(ptr null, i64 %t75)
  %t77 = add i64 %t73, %t76
  %t78 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t66, i64 %t67)
  %t79 = getelementptr i8, ptr %t78, i64 %t67
  %t80 = call i64 @__olang_fmt_i64(ptr %t79, i64 %t64)
  %t81 = getelementptr i8, ptr %t79, i64 %t69
  call void @olang_textcopy(ptr %t81, ptr %t71, i64 %t72)
  %t82 = getelementptr i8, ptr %t81, i64 %t72
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t75)
  %t84 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t78, 1
  store { i64, ptr } %t85, ptr %l8, !tbaa !27
  br label %bb17
bb8:
  %t87 = load { i64, [2 x i64] }, ptr %l0
  %t89 = extractvalue { i64, [2 x i64] } %t87, 0
  %t90 = icmp eq i64 %t89, 2
  br i1 %t90, label %bb9, label %bb10
bb9:
  %t92 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t93 = getelementptr { i32, i32 }, ptr %t92, i32 0, i32 0
  %t94 = load i32, ptr %t93
  store i32 %t94, ptr %l5, !tbaa !23
  %t96 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t97 = getelementptr { i32, i32 }, ptr %t96, i32 0, i32 1
  %t98 = load i32, ptr %t97
  store i32 %t98, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t100 = load i32, ptr %l5, !tbaa !23
  %t101 = load i32, ptr %l6, !tbaa !23
  %t102 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t105 = sext i32 %t100 to i64
  %t106 = call i64 @__olang_fmt_i64(ptr null, i64 %t105)
  %t107 = add i64 %t103, %t106
  %t108 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t110 = add i64 %t107, %t109
  %t112 = sext i32 %t101 to i64
  %t113 = call i64 @__olang_fmt_i64(ptr null, i64 %t112)
  %t114 = add i64 %t110, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t102, i64 %t103)
  %t116 = getelementptr i8, ptr %t115, i64 %t103
  %t117 = call i64 @__olang_fmt_i64(ptr %t116, i64 %t105)
  %t118 = getelementptr i8, ptr %t116, i64 %t106
  call void @olang_textcopy(ptr %t118, ptr %t108, i64 %t109)
  %t119 = getelementptr i8, ptr %t118, i64 %t109
  %t120 = call i64 @__olang_fmt_i64(ptr %t119, i64 %t112)
  %t121 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t115, 1
  store { i64, ptr } %t122, ptr %l8, !tbaa !27
  br label %bb17
bb12:
  %t124 = load { i64, [2 x i64] }, ptr %l0
  %t126 = extractvalue { i64, [2 x i64] } %t124, 0
  %t127 = icmp eq i64 %t126, 3
  br i1 %t127, label %bb13, label %bb14
bb13:
  %t129 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t130 = getelementptr { i32 }, ptr %t129, i32 0, i32 0
  %t131 = load i32, ptr %t130
  store i32 %t131, ptr %l7, !tbaa !23
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t133 = load i32, ptr %l7, !tbaa !23
  %t134 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t137 = sext i32 %t133 to i64
  %t138 = call i64 @__olang_fmt_i64(ptr null, i64 %t137)
  %t139 = add i64 %t135, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t134, i64 %t135)
  %t141 = getelementptr i8, ptr %t140, i64 %t135
  %t142 = call i64 @__olang_fmt_i64(ptr %t141, i64 %t137)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t140, 1
  store { i64, ptr } %t144, ptr %l8, !tbaa !27
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_14ebfa33b1d03356_270fe526a4636ad2)
  unreachable
bb17:
  %t146 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t146, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/mir:Local"
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/mir:ScopeInfo"
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"compiler/mir:BasicBlock"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca { i64, [21 x i64] }
  %l40 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l54 = alloca i64
  %l56 = alloca %"std/prelude/text:StringBuilder"
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l84 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca ptr
  %l93 = alloca { i64, [1 x i64] }
  %l94 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l106 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i64
  %l134 = alloca %"compiler/mir:Local"
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca i64
  %l150 = alloca i32
  %l152 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l173 = alloca i64
  %l177 = alloca i64
  %l180 = alloca i64
  %l201 = alloca %"compiler/mir:ScopeInfo"
  %l205 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l223 = alloca ptr
  %l224 = alloca i64
  %l225 = alloca i32
  %l227 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l239 = alloca i64
  %l243 = alloca i64
  %l246 = alloca i64
  %l271 = alloca %"compiler/mir:BasicBlock"
  %l273 = alloca i64
  %l275 = alloca i64
  %l280 = alloca { i64, [21 x i64] }
  %l281 = alloca ptr
  %l284 = alloca { i64, ptr }
  %l288 = alloca ptr
  %l291 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %s16 = alloca %olang.scope
  %s20 = alloca %olang.builder
  %s20room = alloca [64 x i8], align 8
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l40, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/mir:Fn", ptr %t8, i32 0, i32 0
  %t11 = load { i64, [2 x i64] }, ptr %t10
  %t14 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %s0, ptr %t7, { i64, [2 x i64] } %t11)
  store { i64, ptr } %t14, ptr %l44
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/mir:dumper", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/mir:Fn", ptr %t19, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t18, i32 %t22)
  store { i64, ptr } %t25, ptr %l49
  br label %bb2
bb2:
  %t26 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t28 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = add i64 %t34, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t26, i64 %t27)
  %t40 = getelementptr i8, ptr %t39, i64 %t27
  call void @olang_textcopy(ptr %t40, ptr %t29, i64 %t30)
  %t41 = getelementptr i8, ptr %t40, i64 %t30
  call void @olang_textcopy(ptr %t41, ptr %t32, i64 %t33)
  %t42 = getelementptr i8, ptr %t41, i64 %t33
  call void @olang_textcopy(ptr %t42, ptr %t36, i64 %t37)
  %t43 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t39, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t52 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s0, ptr %t52, i64 0, { i64, ptr } %t51)
  br label %bb3
bb3:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/mir:Fn", ptr %t54, i32 0, i32 6
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l54
  br label %bb4
bb4:
  %t59 = load i64, ptr %l54, !tbaa !24
  %t60 = icmp sgt i64 %t59, 0
  br i1 %t60, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t62, ptr %l56
  br label %bb7
bb6:
  br label %bb29
bb7:
  %t63 = load %"std/prelude/text:StringBuilder", ptr %l56
  store %"std/prelude/text:StringBuilder" %t63, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/mir:Fn", ptr %t64, i32 0, i32 6
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l59
  br label %bb8
bb8:
  %t69 = load i64, ptr %l59, !tbaa !24
  store i64 %t69, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l3, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb9, label %bb10
bb9:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb14
bb11:
  %t80 = load i64, ptr %l4, !tbaa !24
  %t81 = load i64, ptr %l3, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l66, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb13
bb13:
  %t96 = load i64, ptr %l66, !tbaa !24
  store i64 %t96, ptr %l63, !tbaa !24
  br label %bb14
bb14:
  %t97 = load i64, ptr %l63, !tbaa !24
  store i64 %t97, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t98 = load i64, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t106 = load i64, ptr %l3, !tbaa !24
  %t107 = load i64, ptr %l7, !tbaa !24
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l8, !tbaa !24
  store ptr %l2, ptr %l84, !tbaa !29
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp sgt i64 %t116, 0
  br i1 %t118, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb21
bb21:
  %t120 = load i64, ptr %l8, !tbaa !24
  store i64 %t120, ptr %l88, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l89, !tbaa !29
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/mir:Fn", ptr %t122, i32 0, i32 6
  %t125 = load i64, ptr %l8, !tbaa !24
  %t128 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t124, i64 %t125)
  store { i64, [1 x i64] } %t128, ptr %l93
  br label %bb22
bb22:
  %t129 = load ptr, ptr %l89, !tbaa !29
  %t130 = load { i64, [1 x i64] }, ptr %l93
  %t131 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2evarKind(ptr %v0, ptr %s4, ptr %t129, { i64, [1 x i64] } %t130)
  store { i64, ptr } %t131, ptr %l94
  br label %bb23
bb23:
  %t132 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = load i64, ptr %l88, !tbaa !24
  %t139 = call i64 @__olang_fmt_i64(ptr null, i64 %t138)
  %t140 = add i64 %t137, %t139
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t133, i64 %t134)
  %t149 = getelementptr i8, ptr %t148, i64 %t134
  call void @olang_textcopy(ptr %t149, ptr %t135, i64 %t136)
  %t150 = getelementptr i8, ptr %t149, i64 %t136
  %t151 = call i64 @__olang_fmt_i64(ptr %t150, i64 %t138)
  %t152 = getelementptr i8, ptr %t150, i64 %t139
  call void @olang_textcopy(ptr %t152, ptr %t141, i64 %t142)
  %t153 = getelementptr i8, ptr %t152, i64 %t142
  call void @olang_textcopy(ptr %t153, ptr %t145, i64 %t146)
  %t154 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t148, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load ptr, ptr %l84, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s4, ptr %t163, { i64, ptr } %t162)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t165 = load i64, ptr %l7, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l7, !tbaa !24
  br label %bb15
bb26:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l99, !tbaa !29
  %t171 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l2)
  store { i64, ptr } %t171, ptr %l101
  br label %bb27
bb27:
  %t172 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t174 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = add i64 %t173, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t172, i64 %t173)
  %t179 = getelementptr i8, ptr %t178, i64 %t173
  call void @olang_textcopy(ptr %t179, ptr %t175, i64 %t176)
  %t180 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t178, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t189 = load ptr, ptr %l99, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s2, ptr %t189, i64 1, { i64, ptr } %t188)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  store i64 0, ptr %l9, !tbaa !24
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr %"compiler/mir:Fn", ptr %t191, i32 0, i32 7
  %t195 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t193)
  store i64 %t195, ptr %l106
  br label %bb30
bb30:
  %t196 = load i64, ptr %l106, !tbaa !24
  store i64 %t196, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t197 = load i64, ptr %l10, !tbaa !24
  %t198 = load i64, ptr %l9, !tbaa !24
  %t201 = icmp sgt i64 %t197, %t198
  br i1 %t201, label %bb31, label %bb32
bb31:
  %t203 = load i64, ptr %l11, !tbaa !24
  %t205 = icmp sgt i64 %t203, 0
  br i1 %t205, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb36
bb33:
  %t207 = load i64, ptr %l10, !tbaa !24
  %t208 = load i64, ptr %l9, !tbaa !24
  %t211 = sub i64 %t207, %t208
  %t212 = load i64, ptr %l11, !tbaa !24
  %t215 = add i64 %t211, %t212
  %t217 = sub i64 %t215, 1
  %t218 = load i64, ptr %l11, !tbaa !24
  %t221 = sdiv i64 %t217, %t218
  store i64 %t221, ptr %l113, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb35
bb35:
  %t223 = load i64, ptr %l113, !tbaa !24
  store i64 %t223, ptr %l110, !tbaa !24
  br label %bb36
bb36:
  %t224 = load i64, ptr %l110, !tbaa !24
  store i64 %t224, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t225 = load i64, ptr %l13, !tbaa !24
  %t226 = load i64, ptr %l12, !tbaa !24
  %t229 = icmp slt i64 %t225, %t226
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb39:
  br label %bb40
bb40:
  %t233 = load i64, ptr %l9, !tbaa !24
  %t234 = load i64, ptr %l13, !tbaa !24
  %t235 = load i64, ptr %l11, !tbaa !24
  %t238 = mul i64 %t234, %t235
  %t241 = add i64 %t233, %t238
  store i64 %t241, ptr %l14, !tbaa !24
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t245 = getelementptr %"compiler/mir:Fn", ptr %t243, i32 0, i32 7
  %t246 = load i64, ptr %l14, !tbaa !24
  %t249 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t245, i64 %t246)
  store %"compiler/mir:Local" %t249, ptr %l134
  br label %bb41
bb41:
  %t250 = load %"compiler/mir:Local", ptr %l134
  store %"compiler/mir:Local" %t250, ptr %l15
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/mir:dumper", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = getelementptr %"compiler/types:Table", ptr %t254, i32 0, i32 0
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t258 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 0
  %t259 = load i32, ptr %t258, !tbaa !23
  %t262 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t257, i32 %t259)
  store { i64, ptr } %t262, ptr %l139
  br label %bb42
bb42:
  %t263 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t263, ptr %l16, !tbaa !27
  %t264 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 4
  %t265 = load { i64, [1 x i64] }, ptr %t264
  %t267 = extractvalue { i64, [1 x i64] } %t265, 0
  %t268 = icmp eq i64 %t267, 3
  br i1 %t268, label %bb43, label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l142, !tbaa !27
  br label %bb46
bb44:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 4
  %t272 = load { i64, [1 x i64] }, ptr %t271
  %t275 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s9, ptr %t270, { i64, [1 x i64] } %t272)
  store { i64, ptr } %t275, ptr %l145
  br label %bb45
bb45:
  %t276 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t277 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t278 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = add i64 %t277, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t276, i64 %t277)
  %t283 = getelementptr i8, ptr %t282, i64 %t277
  call void @olang_textcopy(ptr %t283, ptr %t279, i64 %t280)
  %t284 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t282, 1
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t288 = extractvalue { i64, ptr } %t285, 1
  %t289 = mul i64 %t287, 1
  %t290 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t289)
  call void @llvm.memcpy.p0.p0.i64(ptr %t290, ptr %t288, i64 %t289, i1 false)
  %t291 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  store { i64, ptr } %t292, ptr %l142, !tbaa !27
  br label %bb46
bb46:
  %t294 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t294, ptr %l17, !tbaa !27
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l148, !tbaa !29
  %t296 = load i64, ptr %l14, !tbaa !24
  store i64 %t296, ptr %l149, !tbaa !24
  %t297 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 3
  %t298 = load i32, ptr %t297
  store i32 %t298, ptr %l150
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aLocalKind(ptr %s11, ptr %l150, i64 0)
  br label %bb47
bb47:
  %t300 = load ptr, ptr %s11
  %t301 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t302 = load i64, ptr %t301
  %t303 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t302)
  call void @olang_textcopy(ptr %t303, ptr %t300, i64 %t302)
  %t304 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  store { i64, ptr } %t305, ptr %l152, !tbaa !27
  %t306 = getelementptr %olang.builder, ptr %s11, i32 0, i32 3
  %t307 = load ptr, ptr %t306
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %sbgrew.309, label %sbdone.310
sbgrew.309:
  call void @__olang_sb_done(ptr %s11)
  br label %sbdone.310
sbdone.310:
  %t311 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  %t313 = extractvalue { i64, ptr } %t311, 1
  %t314 = mul i64 %t312, 1
  %t315 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t314)
  call void @llvm.memcpy.p0.p0.i64(ptr %t315, ptr %t313, i64 %t314, i1 false)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t315, 1
  %t319 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s9, { i64, ptr } %t317)
  store { i64, ptr } %t319, ptr %l154
  br label %bb48
bb48:
  %t320 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t324 = icmp sgt i64 %t322, 0
  br i1 %t324, label %bb49, label %bb50
bb49:
  %t326 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t327 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t328 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t330 = extractvalue { i64, ptr } %t326, 1
  %t331 = extractvalue { i64, ptr } %t326, 0
  %t332 = add i64 %t328, %t331
  %t333 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t327, i64 %t328)
  %t334 = getelementptr i8, ptr %t333, i64 %t328
  call void @olang_textcopy(ptr %t334, ptr %t330, i64 %t331)
  %t335 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t333, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = extractvalue { i64, ptr } %t336, 1
  %t340 = mul i64 %t338, 1
  %t341 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t340)
  call void @llvm.memcpy.p0.p0.i64(ptr %t341, ptr %t339, i64 %t340, i1 false)
  %t342 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t341, 1
  store { i64, ptr } %t343, ptr %l158, !tbaa !27
  br label %bb51
bb50:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l158, !tbaa !27
  br label %bb51
bb51:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/mir:dumper", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t349 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 2
  %t350 = load i32, ptr %t349, !tbaa !23
  %t353 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s9, ptr %t348, i32 %t350)
  store { i64, ptr } %t353, ptr %l165
  br label %bb52
bb52:
  %t354 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t355 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t356 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t357 = load i64, ptr %l149, !tbaa !24
  %t358 = call i64 @__olang_fmt_i64(ptr null, i64 %t357)
  %t359 = add i64 %t356, %t358
  %t360 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t361 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t362 = add i64 %t359, %t361
  %t363 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t363, 1
  %t365 = extractvalue { i64, ptr } %t363, 0
  %t366 = add i64 %t362, %t365
  %t367 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t367, 1
  %t369 = extractvalue { i64, ptr } %t367, 0
  %t370 = add i64 %t366, %t369
  %t371 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t372 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t373 = add i64 %t370, %t372
  %t374 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = add i64 %t373, %t376
  %t379 = extractvalue { i64, ptr } %t354, 1
  %t380 = extractvalue { i64, ptr } %t354, 0
  %t381 = add i64 %t377, %t380
  %t382 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t381)
  call void @olang_textcopy(ptr %t382, ptr %t355, i64 %t356)
  %t383 = getelementptr i8, ptr %t382, i64 %t356
  %t384 = call i64 @__olang_fmt_i64(ptr %t383, i64 %t357)
  %t385 = getelementptr i8, ptr %t383, i64 %t358
  call void @olang_textcopy(ptr %t385, ptr %t360, i64 %t361)
  %t386 = getelementptr i8, ptr %t385, i64 %t361
  call void @olang_textcopy(ptr %t386, ptr %t364, i64 %t365)
  %t387 = getelementptr i8, ptr %t386, i64 %t365
  call void @olang_textcopy(ptr %t387, ptr %t368, i64 %t369)
  %t388 = getelementptr i8, ptr %t387, i64 %t369
  call void @olang_textcopy(ptr %t388, ptr %t371, i64 %t372)
  %t389 = getelementptr i8, ptr %t388, i64 %t372
  call void @olang_textcopy(ptr %t389, ptr %t375, i64 %t376)
  %t390 = getelementptr i8, ptr %t389, i64 %t376
  call void @olang_textcopy(ptr %t390, ptr %t379, i64 %t380)
  %t391 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t392 = insertvalue { i64, ptr } %t391, ptr %t382, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = extractvalue { i64, ptr } %t392, 1
  %t396 = mul i64 %t394, 1
  %t397 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t396)
  call void @llvm.memcpy.p0.p0.i64(ptr %t397, ptr %t395, i64 %t396, i1 false)
  %t398 = insertvalue { i64, ptr } undef, i64 %t394, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  %t400 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s9, ptr %t400, i64 1, { i64, ptr } %t399)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t402 = load i64, ptr %l13, !tbaa !24
  %t404 = add i64 %t402, 1
  store i64 %t404, ptr %l13, !tbaa !24
  br label %bb37
bb55:
  store i64 0, ptr %l18, !tbaa !24
  %t406 = load ptr, ptr %l1, !tbaa !29
  %t408 = getelementptr %"compiler/mir:Fn", ptr %t406, i32 0, i32 8
  %t410 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t408)
  store i64 %t410, ptr %l173
  br label %bb56
bb56:
  %t411 = load i64, ptr %l173, !tbaa !24
  store i64 %t411, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t412 = load i64, ptr %l19, !tbaa !24
  %t413 = load i64, ptr %l18, !tbaa !24
  %t416 = icmp sgt i64 %t412, %t413
  br i1 %t416, label %bb57, label %bb58
bb57:
  %t418 = load i64, ptr %l20, !tbaa !24
  %t420 = icmp sgt i64 %t418, 0
  br i1 %t420, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l177, !tbaa !24
  br label %bb62
bb59:
  %t422 = load i64, ptr %l19, !tbaa !24
  %t423 = load i64, ptr %l18, !tbaa !24
  %t426 = sub i64 %t422, %t423
  %t427 = load i64, ptr %l20, !tbaa !24
  %t430 = add i64 %t426, %t427
  %t432 = sub i64 %t430, 1
  %t433 = load i64, ptr %l20, !tbaa !24
  %t436 = sdiv i64 %t432, %t433
  store i64 %t436, ptr %l180, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb61
bb61:
  %t438 = load i64, ptr %l180, !tbaa !24
  store i64 %t438, ptr %l177, !tbaa !24
  br label %bb62
bb62:
  %t439 = load i64, ptr %l177, !tbaa !24
  store i64 %t439, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s16
  %t440 = load i64, ptr %l22, !tbaa !24
  %t441 = load i64, ptr %l21, !tbaa !24
  %t444 = icmp slt i64 %t440, %t441
  %t446 = xor i1 %t444, true
  br i1 %t446, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s16)
  br label %bb82
bb65:
  br label %bb66
bb66:
  %t448 = load i64, ptr %l18, !tbaa !24
  %t449 = load i64, ptr %l22, !tbaa !24
  %t450 = load i64, ptr %l20, !tbaa !24
  %t453 = mul i64 %t449, %t450
  %t456 = add i64 %t448, %t453
  store i64 %t456, ptr %l23, !tbaa !24
  %t458 = load ptr, ptr %l1, !tbaa !29
  %t460 = getelementptr %"compiler/mir:Fn", ptr %t458, i32 0, i32 8
  %t461 = load i64, ptr %l23, !tbaa !24
  %t464 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t460, i64 %t461)
  store %"compiler/mir:ScopeInfo" %t464, ptr %l201
  br label %bb67
bb67:
  %t465 = load %"compiler/mir:ScopeInfo", ptr %l201
  store %"compiler/mir:ScopeInfo" %t465, ptr %l24
  %t466 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 1
  %t467 = load i32, ptr %t466, !tbaa !23
  %t468 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t471 = icmp eq i32 %t467, %t468
  br i1 %t471, label %bb68, label %bb69
bb68:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l205, !tbaa !27
  br label %bb70
bb69:
  %t473 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 1
  %t474 = load i32, ptr %t473, !tbaa !23
  %t475 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t476 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t478 = sext i32 %t474 to i64
  %t479 = call i64 @__olang_fmt_i64(ptr null, i64 %t478)
  %t480 = add i64 %t476, %t479
  %t481 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t480)
  call void @olang_textcopy(ptr %t481, ptr %t475, i64 %t476)
  %t482 = getelementptr i8, ptr %t481, i64 %t476
  %t483 = call i64 @__olang_fmt_i64(ptr %t482, i64 %t478)
  %t484 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t485 = insertvalue { i64, ptr } %t484, ptr %t481, 1
  %t487 = extractvalue { i64, ptr } %t485, 0
  %t488 = extractvalue { i64, ptr } %t485, 1
  %t489 = mul i64 %t487, 1
  %t490 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t489)
  call void @llvm.memcpy.p0.p0.i64(ptr %t490, ptr %t488, i64 %t489, i1 false)
  %t491 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t490, 1
  store { i64, ptr } %t492, ptr %l205, !tbaa !27
  br label %bb70
bb70:
  %t494 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t494, ptr %l25, !tbaa !27
  %t495 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 2
  %t496 = load i32, ptr %t495, !tbaa !23
  %t498 = icmp slt i32 %t496, 0
  br i1 %t498, label %bb71, label %bb72
bb71:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l211, !tbaa !27
  br label %bb73
bb72:
  %t500 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 2
  %t501 = load i32, ptr %t500, !tbaa !23
  %t502 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t505 = sext i32 %t501 to i64
  %t506 = call i64 @__olang_fmt_i64(ptr null, i64 %t505)
  %t507 = add i64 %t503, %t506
  %t508 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t507)
  call void @olang_textcopy(ptr %t508, ptr %t502, i64 %t503)
  %t509 = getelementptr i8, ptr %t508, i64 %t503
  %t510 = call i64 @__olang_fmt_i64(ptr %t509, i64 %t505)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t508, 1
  %t514 = extractvalue { i64, ptr } %t512, 0
  %t515 = extractvalue { i64, ptr } %t512, 1
  %t516 = mul i64 %t514, 1
  %t517 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t516)
  call void @llvm.memcpy.p0.p0.i64(ptr %t517, ptr %t515, i64 %t516, i1 false)
  %t518 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t517, 1
  store { i64, ptr } %t519, ptr %l211, !tbaa !27
  br label %bb73
bb73:
  %t521 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t521, ptr %l26, !tbaa !27
  %t522 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 4
  %t523 = load i32, ptr %t522, !tbaa !23
  %t525 = icmp eq i32 %t523, 0
  br i1 %t525, label %bb74, label %bb75
bb74:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l217, !tbaa !27
  br label %bb77
bb75:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 4
  %t529 = load i32, ptr %t528, !tbaa !23
  %t532 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %s16, ptr %t527, i32 %t529)
  store { i64, ptr } %t532, ptr %l220
  br label %bb76
bb76:
  %t533 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t534 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t535 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t536 = extractvalue { i64, ptr } %t535, 1
  %t537 = extractvalue { i64, ptr } %t535, 0
  %t538 = add i64 %t534, %t537
  %t539 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t538)
  call void @olang_textcopy(ptr %t539, ptr %t533, i64 %t534)
  %t540 = getelementptr i8, ptr %t539, i64 %t534
  call void @olang_textcopy(ptr %t540, ptr %t536, i64 %t537)
  %t541 = insertvalue { i64, ptr } undef, i64 %t538, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t539, 1
  %t544 = extractvalue { i64, ptr } %t542, 0
  %t545 = extractvalue { i64, ptr } %t542, 1
  %t546 = mul i64 %t544, 1
  %t547 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t546)
  call void @llvm.memcpy.p0.p0.i64(ptr %t547, ptr %t545, i64 %t546, i1 false)
  %t548 = insertvalue { i64, ptr } undef, i64 %t544, 0
  %t549 = insertvalue { i64, ptr } %t548, ptr %t547, 1
  store { i64, ptr } %t549, ptr %l217, !tbaa !27
  br label %bb77
bb77:
  %t551 = load { i64, ptr }, ptr %l217, !tbaa !27
  store { i64, ptr } %t551, ptr %l27, !tbaa !27
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l223, !tbaa !29
  %t553 = load i64, ptr %l23, !tbaa !24
  store i64 %t553, ptr %l224, !tbaa !24
  %t554 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 0
  %t555 = load i32, ptr %t554
  store i32 %t555, ptr %l225
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s20
  store ptr %s20room, ptr %s20
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aScopeKind(ptr %s20, ptr %l225, i64 0)
  br label %bb78
bb78:
  %t557 = load ptr, ptr %s20
  %t558 = getelementptr %olang.builder, ptr %s20, i32 0, i32 1
  %t559 = load i64, ptr %t558
  %t560 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t559)
  call void @olang_textcopy(ptr %t560, ptr %t557, i64 %t559)
  %t561 = insertvalue { i64, ptr } undef, i64 %t559, 0
  %t562 = insertvalue { i64, ptr } %t561, ptr %t560, 1
  store { i64, ptr } %t562, ptr %l227, !tbaa !27
  %t563 = getelementptr %olang.builder, ptr %s20, i32 0, i32 3
  %t564 = load ptr, ptr %t563
  %t565 = icmp ne ptr %t564, null
  br i1 %t565, label %sbgrew.566, label %sbdone.567
sbgrew.566:
  call void @__olang_sb_done(ptr %s20)
  br label %sbdone.567
sbdone.567:
  %t568 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 0
  %t570 = extractvalue { i64, ptr } %t568, 1
  %t571 = mul i64 %t569, 1
  %t572 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t571)
  call void @llvm.memcpy.p0.p0.i64(ptr %t572, ptr %t570, i64 %t571, i1 false)
  %t573 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t572, 1
  %t576 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s16, { i64, ptr } %t574)
  store { i64, ptr } %t576, ptr %l229
  br label %bb79
bb79:
  %t577 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t578 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t579 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t580 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t581 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t582 = load i64, ptr %l224, !tbaa !24
  %t583 = call i64 @__olang_fmt_i64(ptr null, i64 %t582)
  %t584 = add i64 %t581, %t583
  %t585 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t586 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t587 = add i64 %t584, %t586
  %t588 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t589 = extractvalue { i64, ptr } %t588, 1
  %t590 = extractvalue { i64, ptr } %t588, 0
  %t591 = add i64 %t587, %t590
  %t593 = extractvalue { i64, ptr } %t577, 1
  %t594 = extractvalue { i64, ptr } %t577, 0
  %t595 = add i64 %t591, %t594
  %t597 = extractvalue { i64, ptr } %t578, 1
  %t598 = extractvalue { i64, ptr } %t578, 0
  %t599 = add i64 %t595, %t598
  %t601 = extractvalue { i64, ptr } %t579, 1
  %t602 = extractvalue { i64, ptr } %t579, 0
  %t603 = add i64 %t599, %t602
  %t604 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t603)
  call void @olang_textcopy(ptr %t604, ptr %t580, i64 %t581)
  %t605 = getelementptr i8, ptr %t604, i64 %t581
  %t606 = call i64 @__olang_fmt_i64(ptr %t605, i64 %t582)
  %t607 = getelementptr i8, ptr %t605, i64 %t583
  call void @olang_textcopy(ptr %t607, ptr %t585, i64 %t586)
  %t608 = getelementptr i8, ptr %t607, i64 %t586
  call void @olang_textcopy(ptr %t608, ptr %t589, i64 %t590)
  %t609 = getelementptr i8, ptr %t608, i64 %t590
  call void @olang_textcopy(ptr %t609, ptr %t593, i64 %t594)
  %t610 = getelementptr i8, ptr %t609, i64 %t594
  call void @olang_textcopy(ptr %t610, ptr %t597, i64 %t598)
  %t611 = getelementptr i8, ptr %t610, i64 %t598
  call void @olang_textcopy(ptr %t611, ptr %t601, i64 %t602)
  %t612 = insertvalue { i64, ptr } undef, i64 %t603, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t604, 1
  %t615 = extractvalue { i64, ptr } %t613, 0
  %t616 = extractvalue { i64, ptr } %t613, 1
  %t617 = mul i64 %t615, 1
  %t618 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t617)
  call void @llvm.memcpy.p0.p0.i64(ptr %t618, ptr %t616, i64 %t617, i1 false)
  %t619 = insertvalue { i64, ptr } undef, i64 %t615, 0
  %t620 = insertvalue { i64, ptr } %t619, ptr %t618, 1
  %t621 = load ptr, ptr %l223, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s16, ptr %t621, i64 1, { i64, ptr } %t620)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s16)
  br label %bb81
bb81:
  %t623 = load i64, ptr %l22, !tbaa !24
  %t625 = add i64 %t623, 1
  store i64 %t625, ptr %l22, !tbaa !24
  br label %bb63
bb82:
  store i64 0, ptr %l28, !tbaa !24
  %t627 = load ptr, ptr %l1, !tbaa !29
  %t629 = getelementptr %"compiler/mir:Fn", ptr %t627, i32 0, i32 9
  %t631 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t629)
  store i64 %t631, ptr %l239
  br label %bb83
bb83:
  %t632 = load i64, ptr %l239, !tbaa !24
  store i64 %t632, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t633 = load i64, ptr %l29, !tbaa !24
  %t634 = load i64, ptr %l28, !tbaa !24
  %t637 = icmp sgt i64 %t633, %t634
  br i1 %t637, label %bb84, label %bb85
bb84:
  %t639 = load i64, ptr %l30, !tbaa !24
  %t641 = icmp sgt i64 %t639, 0
  br i1 %t641, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l243, !tbaa !24
  br label %bb89
bb86:
  %t643 = load i64, ptr %l29, !tbaa !24
  %t644 = load i64, ptr %l28, !tbaa !24
  %t647 = sub i64 %t643, %t644
  %t648 = load i64, ptr %l30, !tbaa !24
  %t651 = add i64 %t647, %t648
  %t653 = sub i64 %t651, 1
  %t654 = load i64, ptr %l30, !tbaa !24
  %t657 = sdiv i64 %t653, %t654
  store i64 %t657, ptr %l246, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l246, !tbaa !24
  br label %bb88
bb88:
  %t659 = load i64, ptr %l246, !tbaa !24
  store i64 %t659, ptr %l243, !tbaa !24
  br label %bb89
bb89:
  %t660 = load i64, ptr %l243, !tbaa !24
  store i64 %t660, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb90
bb90:
  store %olang.scope zeroinitializer, ptr %s24
  %t661 = load i64, ptr %l32, !tbaa !24
  %t662 = load i64, ptr %l31, !tbaa !24
  %t665 = icmp slt i64 %t661, %t662
  %t667 = xor i1 %t665, true
  br i1 %t667, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s24)
  br label %bb109
bb92:
  br label %bb93
bb93:
  %t669 = load i64, ptr %l28, !tbaa !24
  %t670 = load i64, ptr %l32, !tbaa !24
  %t671 = load i64, ptr %l30, !tbaa !24
  %t674 = mul i64 %t670, %t671
  %t677 = add i64 %t669, %t674
  store i64 %t677, ptr %l33, !tbaa !24
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load i64, ptr %l33, !tbaa !24
  %t681 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t682 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t684 = call i64 @__olang_fmt_i64(ptr null, i64 %t680)
  %t685 = add i64 %t682, %t684
  %t686 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t687 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t688 = add i64 %t685, %t687
  %t689 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t688)
  call void @olang_textcopy(ptr %t689, ptr %t681, i64 %t682)
  %t690 = getelementptr i8, ptr %t689, i64 %t682
  %t691 = call i64 @__olang_fmt_i64(ptr %t690, i64 %t680)
  %t692 = getelementptr i8, ptr %t690, i64 %t684
  call void @olang_textcopy(ptr %t692, ptr %t686, i64 %t687)
  %t693 = insertvalue { i64, ptr } undef, i64 %t688, 0
  %t694 = insertvalue { i64, ptr } %t693, ptr %t689, 1
  %t696 = extractvalue { i64, ptr } %t694, 0
  %t697 = extractvalue { i64, ptr } %t694, 1
  %t698 = mul i64 %t696, 1
  %t699 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t698)
  call void @llvm.memcpy.p0.p0.i64(ptr %t699, ptr %t697, i64 %t698, i1 false)
  %t700 = insertvalue { i64, ptr } undef, i64 %t696, 0
  %t701 = insertvalue { i64, ptr } %t700, ptr %t699, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s24, ptr %t679, i64 0, { i64, ptr } %t701)
  br label %bb94
bb94:
  %t704 = load ptr, ptr %l1, !tbaa !29
  %t706 = getelementptr %"compiler/mir:Fn", ptr %t704, i32 0, i32 9
  %t707 = load i64, ptr %l33, !tbaa !24
  %t710 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t706, i64 %t707)
  store %"compiler/mir:BasicBlock" %t710, ptr %l271
  br label %bb95
bb95:
  %t711 = load %"compiler/mir:BasicBlock", ptr %l271
  store %"compiler/mir:BasicBlock" %t711, ptr %l34
  %t712 = getelementptr %"compiler/mir:BasicBlock", ptr %l34, i32 0, i32 0
  store ptr %t712, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s27
  %t714 = load i64, ptr %l36, !tbaa !24
  store i64 %t714, ptr %l273, !tbaa !24
  %t715 = load ptr, ptr %l35, !tbaa !29
  %t717 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t715)
  store i64 %t717, ptr %l275
  br label %bb97
bb97:
  %t718 = load i64, ptr %l273, !tbaa !24
  %t719 = load i64, ptr %l275, !tbaa !24
  %t720 = icmp slt i64 %t718, %t719
  %t722 = xor i1 %t720, true
  br i1 %t722, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s27)
  br label %bb105
bb99:
  br label %bb100
bb100:
  %t724 = load ptr, ptr %l35, !tbaa !29
  %t725 = load i64, ptr %l36, !tbaa !24
  %t728 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t724, i64 %t725)
  store { i64, [21 x i64] } %t728, ptr %l280
  br label %bb101
bb101:
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %l280, i64 176, i1 false)
  %t729 = load ptr, ptr %l0, !tbaa !29
  store ptr %t729, ptr %l281, !tbaa !29
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t733 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2estmt(ptr %v0, ptr %s27, ptr %s27, ptr %t730, ptr %l37)
  store { i64, ptr } %t733, ptr %l284
  br label %bb102
bb102:
  %t734 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t735 = extractvalue { i64, ptr } %t734, 0
  %t736 = extractvalue { i64, ptr } %t734, 1
  %t737 = mul i64 %t735, 1
  %t738 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t737)
  call void @llvm.memcpy.p0.p0.i64(ptr %t738, ptr %t736, i64 %t737, i1 false)
  %t739 = insertvalue { i64, ptr } undef, i64 %t735, 0
  %t740 = insertvalue { i64, ptr } %t739, ptr %t738, 1
  %t741 = load ptr, ptr %l281, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s27, ptr %t741, i64 1, { i64, ptr } %t740)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s27)
  br label %bb104
bb104:
  %t743 = load i64, ptr %l36, !tbaa !24
  %t745 = add i64 %t743, 1
  store i64 %t745, ptr %l36, !tbaa !24
  br label %bb96
bb105:
  %t747 = load ptr, ptr %l0, !tbaa !29
  store ptr %t747, ptr %l288, !tbaa !29
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t749 = getelementptr %"compiler/mir:BasicBlock", ptr %l34, i32 0, i32 1
  %t750 = load { i64, [8 x i64] }, ptr %t749
  %t753 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eterm(ptr %v0, ptr %s24, ptr %t748, { i64, [8 x i64] } %t750)
  store { i64, ptr } %t753, ptr %l291
  br label %bb106
bb106:
  %t754 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t755 = extractvalue { i64, ptr } %t754, 0
  %t756 = extractvalue { i64, ptr } %t754, 1
  %t757 = mul i64 %t755, 1
  %t758 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t757)
  call void @llvm.memcpy.p0.p0.i64(ptr %t758, ptr %t756, i64 %t757, i1 false)
  %t759 = insertvalue { i64, ptr } undef, i64 %t755, 0
  %t760 = insertvalue { i64, ptr } %t759, ptr %t758, 1
  %t761 = load ptr, ptr %l288, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s24, ptr %t761, i64 1, { i64, ptr } %t760)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s24)
  br label %bb108
bb108:
  %t763 = load i64, ptr %l32, !tbaa !24
  %t765 = add i64 %t763, 1
  store i64 %t765, ptr %l32, !tbaa !24
  br label %bb90
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecases(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Case"
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i32
  %l18 = alloca i32
  %l44 = alloca %"compiler/mir:Case"
  %l45 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i32 0, ptr %l3, !tbaa !23
  %t3 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = icmp sgt i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t14 = icmp sgt i32 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb7
bb4:
  %t16 = load i32, ptr %l4, !tbaa !23
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = sub i32 %t16, %t17
  %t21 = load i32, ptr %l5, !tbaa !23
  %t24 = add i32 %t20, %t21
  %t26 = sub i32 %t24, 1
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = sdiv i32 %t26, %t27
  store i32 %t30, ptr %l18, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l18, !tbaa !23
  store i32 %t32, ptr %l15, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l15, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i32, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l6, !tbaa !23
  %t38 = icmp slt i32 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = mul i32 %t43, %t44
  %t50 = add i32 %t42, %t47
  store i32 %t50, ptr %l8, !tbaa !23
  %t54 = getelementptr %"compiler/mir:dumper", ptr %a0, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/mir:Fn", ptr %t55, i32 0, i32 15
  %t58 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t62 = load i32, ptr %l8, !tbaa !23
  %t64 = sext i32 %t62 to i64
  %t67 = add i64 %t61, %t64
  %t70 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t57, i64 %t67)
  store %"compiler/mir:Case" %t70, ptr %l44
  br label %bb12
bb12:
  %t71 = load %"compiler/mir:Case", ptr %l44
  store %"compiler/mir:Case" %t71, ptr %l9
  store ptr %l2, ptr %l45, !tbaa !29
  %t72 = load i32, ptr %l8, !tbaa !23
  %t74 = icmp sgt i32 %t72, 0
  br i1 %t74, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l48, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l48, !tbaa !27
  br label %bb15
bb15:
  %t76 = getelementptr %"compiler/mir:Case", ptr %l9, i32 0, i32 0
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = getelementptr %"compiler/mir:Case", ptr %l9, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  %t80 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = call i64 @__olang_fmt_i64(ptr null, i64 %t77)
  %t85 = add i64 %t82, %t84
  %t86 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t90 = sext i32 %t79 to i64
  %t91 = call i64 @__olang_fmt_i64(ptr null, i64 %t90)
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t81, i64 %t82)
  %t94 = getelementptr i8, ptr %t93, i64 %t82
  %t95 = call i64 @__olang_fmt_i64(ptr %t94, i64 %t77)
  %t96 = getelementptr i8, ptr %t94, i64 %t84
  call void @olang_textcopy(ptr %t96, ptr %t86, i64 %t87)
  %t97 = getelementptr i8, ptr %t96, i64 %t87
  %t98 = call i64 @__olang_fmt_i64(ptr %t97, i64 %t90)
  %t99 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t93, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t108, { i64, ptr } %t107)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t110 = load i32, ptr %l7, !tbaa !23
  %t112 = add i32 %t110, 1
  store i32 %t112, ptr %l7, !tbaa !23
  br label %bb8
bb18:
  %t115 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t115, ptr %l56
  br label %bb19
bb19:
  %t116 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t116, ptr %l57, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l58, !tbaa !24
  %t119 = load i64, ptr %l58, !tbaa !24
  %t120 = mul i64 %t119, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l59, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l58, !tbaa !24
  %t129 = mul i64 %t128, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t130, ptr %l57, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t131 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t131, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i32
  %l18 = alloca i32
  %l36 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 91)
  br label %bb2
bb2:
  store i32 0, ptr %l3, !tbaa !23
  %t4 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = icmp sgt i32 %t7, %t8
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load i32, ptr %l5, !tbaa !23
  %t15 = icmp sgt i32 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb4:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb8
bb5:
  %t17 = load i32, ptr %l4, !tbaa !23
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = sub i32 %t17, %t18
  %t22 = load i32, ptr %l5, !tbaa !23
  %t25 = add i32 %t21, %t22
  %t27 = sub i32 %t25, 1
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = sdiv i32 %t27, %t28
  store i32 %t31, ptr %l18, !tbaa !23
  br label %bb7
bb6:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l18, !tbaa !23
  store i32 %t33, ptr %l15, !tbaa !23
  br label %bb8
bb8:
  %t34 = load i32, ptr %l15, !tbaa !23
  store i32 %t34, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i32, ptr %l7, !tbaa !23
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = icmp slt i32 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t43 = load i32, ptr %l3, !tbaa !23
  %t44 = load i32, ptr %l7, !tbaa !23
  %t45 = load i32, ptr %l5, !tbaa !23
  %t48 = mul i32 %t44, %t45
  %t51 = add i32 %t43, %t48
  store i32 %t51, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l36, !tbaa !29
  %t53 = load i32, ptr %l8, !tbaa !23
  %t55 = icmp sgt i32 %t53, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/mir:dumper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/mir:Fn", ptr %t61, i32 0, i32 20
  %t64 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t65 = load i32, ptr %t64, !tbaa !23
  %t67 = sext i32 %t65 to i64
  %t68 = load i32, ptr %l8, !tbaa !23
  %t70 = sext i32 %t68 to i64
  %t73 = add i64 %t67, %t70
  %t76 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t63, i64 %t73)
  store i32 %t76, ptr %l49
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = load i32, ptr %l49, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %s2, ptr %t77, i32 %t78)
  store { i64, ptr } %t79, ptr %l50
  br label %bb17
bb17:
  %t80 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = add i64 %t82, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t81, i64 %t82)
  %t88 = getelementptr i8, ptr %t87, i64 %t82
  call void @olang_textcopy(ptr %t88, ptr %t84, i64 %t85)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t98 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t98, { i64, ptr } %t97)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t100 = load i32, ptr %l7, !tbaa !23
  %t102 = add i32 %t100, 1
  store i32 %t102, ptr %l7, !tbaa !23
  br label %bb9
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 93)
  br label %bb21
bb21:
  %t106 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t106, ptr %l57
  br label %bb22
bb22:
  %t107 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t107, ptr %l58, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l59, !tbaa !24
  %t110 = load i64, ptr %l59, !tbaa !24
  %t111 = mul i64 %t110, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t111)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l60, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l59, !tbaa !24
  %t120 = mul i64 %t119, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t116, ptr %t118, i64 %t120, i1 false)
  %t121 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t121, ptr %l58, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t122 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t122, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l24 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t14 = sext i32 %t10 to i64
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t14)
  %t16 = add i64 %t12, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = getelementptr i8, ptr %t17, i64 %t12
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  store { i64, ptr } %t21, ptr %l9, !tbaa !27
  br label %bb27
bb4:
  %t23 = load { i64, [2 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 1
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l3, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t32 = load i32, ptr %l3, !tbaa !23
  %t33 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t36 = sext i32 %t32 to i64
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t36)
  %t38 = add i64 %t34, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t33, i64 %t34)
  %t40 = getelementptr i8, ptr %t39, i64 %t34
  %t41 = call i64 @__olang_fmt_i64(ptr %t40, i64 %t36)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  store { i64, ptr } %t43, ptr %l9, !tbaa !27
  br label %bb27
bb8:
  %t45 = load { i64, [2 x i64] }, ptr %l1
  %t47 = extractvalue { i64, [2 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 2
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t50 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t51 = getelementptr { i32, i32 }, ptr %t50, i32 0, i32 0
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l4
  %t54 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t55 = getelementptr { i32, i32 }, ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l5, !tbaa !23
  br label %bb11
bb10:
  br label %bb15
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t58 = load i32, ptr %l4
  store i32 %t58, ptr %l24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %s6, ptr %l24, i64 0)
  br label %bb12
bb12:
  %t60 = load ptr, ptr %s6
  %t61 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t62 = load i64, ptr %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t60, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l26, !tbaa !27
  %t66 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t67 = load ptr, ptr %t66
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %sbgrew.69, label %sbdone.70
sbgrew.69:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.70
sbdone.70:
  %t71 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t79 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s5, { i64, ptr } %t77)
  store { i64, ptr } %t79, ptr %l28
  br label %bb13
bb13:
  %t82 = getelementptr %"compiler/mir:dumper", ptr %a0, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load i32, ptr %l5, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s5, ptr %t83, i32 %t84)
  store { i64, ptr } %t87, ptr %l32
  br label %bb14
bb14:
  %t88 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t94 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = add i64 %t93, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t89, i64 %t90)
  %t99 = getelementptr i8, ptr %t98, i64 %t90
  call void @olang_textcopy(ptr %t99, ptr %t91, i64 %t92)
  %t100 = getelementptr i8, ptr %t99, i64 %t92
  call void @olang_textcopy(ptr %t100, ptr %t95, i64 %t96)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t98, 1
  store { i64, ptr } %t102, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb15:
  %t104 = load { i64, [2 x i64] }, ptr %l1
  %t106 = extractvalue { i64, [2 x i64] } %t104, 0
  %t107 = icmp eq i64 %t106, 3
  br i1 %t107, label %bb16, label %bb17
bb16:
  %t109 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t110 = getelementptr { i64 }, ptr %t109, i32 0, i32 0
  %t111 = load i64, ptr %t110
  store i64 %t111, ptr %l6, !tbaa !24
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t113 = load i64, ptr %l6, !tbaa !24
  %t114 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t117 = call i64 @__olang_fmt_i64(ptr null, i64 %t113)
  %t118 = add i64 %t115, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t114, i64 %t115)
  %t120 = getelementptr i8, ptr %t119, i64 %t115
  %t121 = call i64 @__olang_fmt_i64(ptr %t120, i64 %t113)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t119, 1
  store { i64, ptr } %t123, ptr %l9, !tbaa !27
  br label %bb27
bb19:
  %t125 = load { i64, [2 x i64] }, ptr %l1
  %t127 = extractvalue { i64, [2 x i64] } %t125, 0
  %t128 = icmp eq i64 %t127, 4
  br i1 %t128, label %bb20, label %bb21
bb20:
  %t130 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t131 = getelementptr { i64, i1 }, ptr %t130, i32 0, i32 0
  %t132 = load i64, ptr %t131
  store i64 %t132, ptr %l7, !tbaa !24
  %t134 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t135 = getelementptr { i64, i1 }, ptr %t134, i32 0, i32 1
  %t136 = load i1, ptr %t135
  store i1 %t136, ptr %l8, !tbaa !21
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t138 = load i64, ptr %l7, !tbaa !24
  store i64 %t138, ptr %l43, !tbaa !24
  %t139 = load i1, ptr %l8, !tbaa !21
  br i1 %t139, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l45, !tbaa !27
  br label %bb25
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l45, !tbaa !27
  br label %bb25
bb25:
  %t141 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t143 = load i64, ptr %l43, !tbaa !24
  %t144 = call i64 @__olang_fmt_i64(ptr null, i64 %t143)
  %t145 = add i64 %t142, %t144
  %t146 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = add i64 %t145, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t141, i64 %t142)
  %t151 = getelementptr i8, ptr %t150, i64 %t142
  %t152 = call i64 @__olang_fmt_i64(ptr %t151, i64 %t143)
  %t153 = getelementptr i8, ptr %t151, i64 %t144
  call void @olang_textcopy(ptr %t153, ptr %t147, i64 %t148)
  %t154 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t150, 1
  store { i64, ptr } %t155, ptr %l9, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_792180efaebdc40a_e488d776d0fba16e)
  unreachable
bb27:
  %t157 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t157, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Place"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l9, !tbaa !27
  br label %bb21
bb4:
  %t8 = load { i64, [4 x i64] }, ptr %l1
  %t10 = extractvalue { i64, [4 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { %"compiler/mir:Place" }, ptr %t13, i32 0, i32 0
  %t15 = load %"compiler/mir:Place", ptr %t14
  store %"compiler/mir:Place" %t15, ptr %l2
  br label %bb7
bb6:
  br label %bb9
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load %"compiler/mir:Place", ptr %l2
  %t21 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s2, ptr %t17, %"compiler/mir:Place" %t18)
  store { i64, ptr } %t21, ptr %l19
  br label %bb8
bb8:
  %t22 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t24 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t22, i64 %t23)
  %t29 = getelementptr i8, ptr %t28, i64 %t23
  call void @olang_textcopy(ptr %t29, ptr %t25, i64 %t26)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  store { i64, ptr } %t31, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb9:
  %t33 = load { i64, [4 x i64] }, ptr %l1
  %t35 = extractvalue { i64, [4 x i64] } %t33, 0
  %t36 = icmp eq i64 %t35, 2
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t39 = getelementptr { i32, i64 }, ptr %t38, i32 0, i32 0
  %t40 = load i32, ptr %t39
  store i32 %t40, ptr %l3, !tbaa !23
  %t42 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { i32, i64 }, ptr %t42, i32 0, i32 1
  %t44 = load i64, ptr %t43
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/mir:dumper", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s4, ptr %t49, i32 %t50)
  store { i64, ptr } %t53, ptr %l28
  br label %bb13
bb13:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t57 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t65 = call i64 @__olang_fmt_i64(ptr null, i64 %t54)
  %t66 = add i64 %t63, %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t55, i64 %t56)
  %t68 = getelementptr i8, ptr %t67, i64 %t56
  call void @olang_textcopy(ptr %t68, ptr %t58, i64 %t59)
  %t69 = getelementptr i8, ptr %t68, i64 %t59
  call void @olang_textcopy(ptr %t69, ptr %t61, i64 %t62)
  %t70 = getelementptr i8, ptr %t69, i64 %t62
  %t71 = call i64 @__olang_fmt_i64(ptr %t70, i64 %t54)
  %t72 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t67, 1
  store { i64, ptr } %t73, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb14:
  %t75 = load { i64, [4 x i64] }, ptr %l1
  %t77 = extractvalue { i64, [4 x i64] } %t75, 0
  %t78 = icmp eq i64 %t77, 3
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t81 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t80, i32 0, i32 0
  %t82 = load i32, ptr %t81
  store i32 %t82, ptr %l5, !tbaa !23
  %t84 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t85 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t84, i32 0, i32 1
  %t86 = load i32, ptr %t85
  store i32 %t86, ptr %l6, !tbaa !23
  %t88 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t89 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t88, i32 0, i32 2
  %t90 = load i64, ptr %t89
  store i64 %t90, ptr %l7, !tbaa !24
  %t92 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t93 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t92, i32 0, i32 3
  %t94 = load %"compiler/source:Span", ptr %t93
  store %"compiler/source:Span" %t94, ptr %l8
  br label %bb17
bb16:
  br label %bb20
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/mir:dumper", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i32, ptr %l5, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s6, ptr %t99, i32 %t100)
  store { i64, ptr } %t103, ptr %l40
  br label %bb18
bb18:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l6, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %s6, ptr %t104, i32 %t105)
  store { i64, ptr } %t108, ptr %l43
  br label %bb19
bb19:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t110 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t111 = load i32, ptr %t110, !tbaa !23
  %t112 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t114 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = add i64 %t120, %t123
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t127 = add i64 %t124, %t126
  %t129 = call i64 @__olang_fmt_i64(ptr null, i64 %t109)
  %t130 = add i64 %t127, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t135 = sext i32 %t111 to i64
  %t136 = call i64 @__olang_fmt_i64(ptr null, i64 %t135)
  %t137 = add i64 %t133, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t112, i64 %t113)
  %t139 = getelementptr i8, ptr %t138, i64 %t113
  call void @olang_textcopy(ptr %t139, ptr %t115, i64 %t116)
  %t140 = getelementptr i8, ptr %t139, i64 %t116
  call void @olang_textcopy(ptr %t140, ptr %t118, i64 %t119)
  %t141 = getelementptr i8, ptr %t140, i64 %t119
  call void @olang_textcopy(ptr %t141, ptr %t122, i64 %t123)
  %t142 = getelementptr i8, ptr %t141, i64 %t123
  call void @olang_textcopy(ptr %t142, ptr %t125, i64 %t126)
  %t143 = getelementptr i8, ptr %t142, i64 %t126
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t109)
  %t145 = getelementptr i8, ptr %t143, i64 %t129
  call void @olang_textcopy(ptr %t145, ptr %t131, i64 %t132)
  %t146 = getelementptr i8, ptr %t145, i64 %t132
  %t147 = call i64 @__olang_fmt_i64(ptr %t146, i64 %t135)
  %t148 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t138, 1
  store { i64, ptr } %t149, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4b3ff56260a2bca0_3dcb0434d488ed4c)
  unreachable
bb21:
  %t151 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  store i64 %t152, ptr %l47, !tbaa !24
  %t153 = load i64, ptr %l47, !tbaa !24
  %t154 = mul i64 %t153, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t154)
  %t156 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  store { i64, ptr } %t157, ptr %l48, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = load i64, ptr %l47, !tbaa !24
  %t163 = mul i64 %t162, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t159, ptr %t161, i64 %t163, i1 false)
  %t164 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t164, ptr %l9, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t165, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l40 = alloca { i64, ptr }
  %l47 = alloca i32
  %l50 = alloca i32
  %l76 = alloca { i64, [1 x i64] }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l3
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb6:
  %t12 = load { i64, [2 x i64] }, ptr %l3
  %t14 = extractvalue { i64, [2 x i64] } %t12, 0
  %t15 = icmp eq i64 %t14, 1
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t17 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l4, !tbaa !23
  br label %bb9
bb8:
  br label %bb11
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i32, ptr %l4, !tbaa !23
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t25 = sext i32 %t21 to i64
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t22, i64 %t23)
  %t29 = getelementptr i8, ptr %t28, i64 %t23
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %t25)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t28, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t39)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb11:
  %t42 = load { i64, [2 x i64] }, ptr %l3
  %t44 = extractvalue { i64, [2 x i64] } %t42, 0
  %t45 = icmp eq i64 %t44, 2
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t47 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t48 = getelementptr { i64, i32, i32 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  store i64 %t49, ptr %l5, !tbaa !24
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t52 = getelementptr { i64, i32, i32 }, ptr %t51, i32 0, i32 1
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb17
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l34, !tbaa !29
  %t55 = load i64, ptr %l5, !tbaa !24
  store i64 %t55, ptr %l35, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/mir:dumper", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/types:Table", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i32, ptr %l6, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t62, i32 %t63)
  store { i64, ptr } %t66, ptr %l40
  br label %bb15
bb15:
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t69 = load i64, ptr %l35, !tbaa !24
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t71 = add i64 %t68, %t70
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t67, i64 %t68)
  %t80 = getelementptr i8, ptr %t79, i64 %t68
  %t81 = call i64 @__olang_fmt_i64(ptr %t80, i64 %t69)
  %t82 = getelementptr i8, ptr %t80, i64 %t70
  call void @olang_textcopy(ptr %t82, ptr %t72, i64 %t73)
  %t83 = getelementptr i8, ptr %t82, i64 %t73
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t79, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = load ptr, ptr %l34, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t93, { i64, ptr } %t92)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2f605f8b851f9dfa_b0e742a1ba211956)
  unreachable
bb18:
  store i32 0, ptr %l7, !tbaa !23
  %t95 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t96 = getelementptr %"compiler/mir:Range", ptr %t95, i32 0, i32 1
  %t97 = load i32, ptr %t96, !tbaa !23
  store i32 %t97, ptr %l8, !tbaa !23
  store i32 1, ptr %l9, !tbaa !23
  %t99 = load i32, ptr %l8, !tbaa !23
  %t100 = load i32, ptr %l7, !tbaa !23
  %t103 = icmp sgt i32 %t99, %t100
  br i1 %t103, label %bb19, label %bb20
bb19:
  %t105 = load i32, ptr %l9, !tbaa !23
  %t107 = icmp sgt i32 %t105, 0
  br i1 %t107, label %bb21, label %bb22
bb20:
  store i32 0, ptr %l47, !tbaa !23
  br label %bb24
bb21:
  %t109 = load i32, ptr %l8, !tbaa !23
  %t110 = load i32, ptr %l7, !tbaa !23
  %t113 = sub i32 %t109, %t110
  %t114 = load i32, ptr %l9, !tbaa !23
  %t117 = add i32 %t113, %t114
  %t119 = sub i32 %t117, 1
  %t120 = load i32, ptr %l9, !tbaa !23
  %t123 = sdiv i32 %t119, %t120
  store i32 %t123, ptr %l50, !tbaa !23
  br label %bb23
bb22:
  store i32 0, ptr %l50, !tbaa !23
  br label %bb23
bb23:
  %t125 = load i32, ptr %l50, !tbaa !23
  store i32 %t125, ptr %l47, !tbaa !23
  br label %bb24
bb24:
  %t126 = load i32, ptr %l47, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  store i32 0, ptr %l11, !tbaa !23
  br label %bb25
bb25:
  %t127 = load i32, ptr %l11, !tbaa !23
  %t128 = load i32, ptr %l10, !tbaa !23
  %t131 = icmp slt i32 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb26, label %bb27
bb26:
  br label %bb57
bb27:
  br label %bb28
bb28:
  %t135 = load i32, ptr %l7, !tbaa !23
  %t136 = load i32, ptr %l11, !tbaa !23
  %t137 = load i32, ptr %l9, !tbaa !23
  %t140 = mul i32 %t136, %t137
  %t143 = add i32 %t135, %t140
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/mir:dumper", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/mir:Fn", ptr %t148, i32 0, i32 10
  %t151 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t152 = getelementptr %"compiler/mir:Range", ptr %t151, i32 0, i32 0
  %t153 = load i32, ptr %t152, !tbaa !23
  %t155 = sext i32 %t153 to i64
  %t158 = sext i32 %t143 to i64
  %t161 = add i64 %t155, %t158
  %t164 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t150, i64 %t161)
  store { i64, [1 x i64] } %t164, ptr %l76
  br label %bb29
bb29:
  %t165 = load { i64, [1 x i64] }, ptr %l76
  store { i64, [1 x i64] } %t165, ptr %l13
  %t166 = load { i64, [1 x i64] }, ptr %l13
  %t168 = extractvalue { i64, [1 x i64] } %t166, 0
  %t169 = icmp eq i64 %t168, 0
  br i1 %t169, label %bb30, label %bb31
bb30:
  %t171 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t172 = getelementptr { i64 }, ptr %t171, i32 0, i32 0
  %t173 = load i64, ptr %t172
  store i64 %t173, ptr %l14, !tbaa !24
  br label %bb32
bb31:
  br label %bb34
bb32:
  store %olang.scope zeroinitializer, ptr %s8
  %t175 = load i64, ptr %l14, !tbaa !24
  %t176 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t179 = call i64 @__olang_fmt_i64(ptr null, i64 %t175)
  %t180 = add i64 %t177, %t179
  %t181 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t176, i64 %t177)
  %t182 = getelementptr i8, ptr %t181, i64 %t177
  %t183 = call i64 @__olang_fmt_i64(ptr %t182, i64 %t175)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t181, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = extractvalue { i64, ptr } %t185, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l2, { i64, ptr } %t192)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb34:
  %t195 = load { i64, [1 x i64] }, ptr %l13
  %t197 = extractvalue { i64, [1 x i64] } %t195, 0
  %t198 = icmp eq i64 %t197, 1
  br i1 %t198, label %bb35, label %bb36
bb35:
  %t200 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t201 = getelementptr { i32 }, ptr %t200, i32 0, i32 0
  %t202 = load i32, ptr %t201
  store i32 %t202, ptr %l15, !tbaa !23
  br label %bb37
bb36:
  br label %bb39
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t204 = load i32, ptr %l15, !tbaa !23
  %t205 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t208 = sext i32 %t204 to i64
  %t209 = call i64 @__olang_fmt_i64(ptr null, i64 %t208)
  %t210 = add i64 %t206, %t209
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t213 = add i64 %t210, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t205, i64 %t206)
  %t215 = getelementptr i8, ptr %t214, i64 %t206
  %t216 = call i64 @__olang_fmt_i64(ptr %t215, i64 %t208)
  %t217 = getelementptr i8, ptr %t215, i64 %t209
  call void @olang_textcopy(ptr %t217, ptr %t211, i64 %t212)
  %t218 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t214, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = extractvalue { i64, ptr } %t219, 1
  %t223 = mul i64 %t221, 1
  %t224 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t223)
  call void @llvm.memcpy.p0.p0.i64(ptr %t224, ptr %t222, i64 %t223, i1 false)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %l2, { i64, ptr } %t226)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb39:
  %t229 = load { i64, [1 x i64] }, ptr %l13
  %t231 = extractvalue { i64, [1 x i64] } %t229, 0
  %t232 = icmp eq i64 %t231, 2
  br i1 %t232, label %bb40, label %bb41
bb40:
  %t234 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t235 = getelementptr { i64 }, ptr %t234, i32 0, i32 0
  %t236 = load i64, ptr %t235
  store i64 %t236, ptr %l16, !tbaa !24
  br label %bb42
bb41:
  br label %bb44
bb42:
  store %olang.scope zeroinitializer, ptr %s12
  %t238 = load i64, ptr %l16, !tbaa !24
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t242 = call i64 @__olang_fmt_i64(ptr null, i64 %t238)
  %t243 = add i64 %t240, %t242
  %t244 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t245 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t246 = add i64 %t243, %t245
  %t247 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t246)
  call void @olang_textcopy(ptr %t247, ptr %t239, i64 %t240)
  %t248 = getelementptr i8, ptr %t247, i64 %t240
  %t249 = call i64 @__olang_fmt_i64(ptr %t248, i64 %t238)
  %t250 = getelementptr i8, ptr %t248, i64 %t242
  call void @olang_textcopy(ptr %t250, ptr %t244, i64 %t245)
  %t251 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t247, 1
  %t254 = extractvalue { i64, ptr } %t252, 0
  %t255 = extractvalue { i64, ptr } %t252, 1
  %t256 = mul i64 %t254, 1
  %t257 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t256)
  call void @llvm.memcpy.p0.p0.i64(ptr %t257, ptr %t255, i64 %t256, i1 false)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } %t259)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s12)
  br label %bb55
bb44:
  %t262 = load { i64, [1 x i64] }, ptr %l13
  %t264 = extractvalue { i64, [1 x i64] } %t262, 0
  %t265 = icmp eq i64 %t264, 3
  br i1 %t265, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb49
bb47:
  store %olang.scope zeroinitializer, ptr %s14
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) })
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s14)
  br label %bb55
bb49:
  %t268 = load { i64, [1 x i64] }, ptr %l13
  %t270 = extractvalue { i64, [1 x i64] } %t268, 0
  %t271 = icmp eq i64 %t270, 4
  br i1 %t271, label %bb50, label %bb51
bb50:
  %t273 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t274 = getelementptr { i64 }, ptr %t273, i32 0, i32 0
  %t275 = load i64, ptr %t274
  store i64 %t275, ptr %l17, !tbaa !24
  br label %bb52
bb51:
  br label %bb54
bb52:
  store %olang.scope zeroinitializer, ptr %s15
  %t277 = load i64, ptr %l17, !tbaa !24
  %t278 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t279 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t281 = call i64 @__olang_fmt_i64(ptr null, i64 %t277)
  %t282 = add i64 %t279, %t281
  %t283 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t278, i64 %t279)
  %t284 = getelementptr i8, ptr %t283, i64 %t279
  %t285 = call i64 @__olang_fmt_i64(ptr %t284, i64 %t277)
  %t286 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t283, 1
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t290 = extractvalue { i64, ptr } %t287, 1
  %t291 = mul i64 %t289, 1
  %t292 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t291)
  call void @llvm.memcpy.p0.p0.i64(ptr %t292, ptr %t290, i64 %t291, i1 false)
  %t293 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l2, { i64, ptr } %t294)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s15)
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_ddfec86899b5c27b_91be796056af7d77)
  unreachable
bb55:
  br label %bb56
bb56:
  %t297 = load i32, ptr %l11, !tbaa !23
  %t299 = add i32 %t297, 1
  store i32 %t299, ptr %l11, !tbaa !23
  br label %bb25
bb57:
  %t302 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t302, ptr %l111
  br label %bb58
bb58:
  %t303 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t303, ptr %l112, !tbaa !27
  %t304 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 0
  store i64 %t305, ptr %l113, !tbaa !24
  %t306 = load i64, ptr %l113, !tbaa !24
  %t307 = mul i64 %t306, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l114, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = load i64, ptr %l113, !tbaa !24
  %t316 = mul i64 %t315, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t312, ptr %t314, i64 %t316, i1 false)
  %t317 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t317, ptr %l112, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t318 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t318, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t14 = sext i32 %t10 to i64
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t14)
  %t16 = add i64 %t12, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = getelementptr i8, ptr %t17, i64 %t12
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  br label %bb21
bb4:
  %t23 = load { i64, [1 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [1 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 1
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t36 = call i64 @__olang_fmt_i64(ptr null, i64 %t32)
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = getelementptr i8, ptr %t38, i64 %t34
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t32)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t38, 1
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  br label %bb21
bb8:
  %t44 = load { i64, [1 x i64] }, ptr %l1
  %t46 = extractvalue { i64, [1 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 2
  br i1 %t47, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t49, ptr %l5, !tbaa !27
  br label %bb21
bb12:
  %t51 = load { i64, [1 x i64] }, ptr %l1
  %t53 = extractvalue { i64, [1 x i64] } %t51, 0
  %t54 = icmp eq i64 %t53, 3
  br i1 %t54, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t56, ptr %l5, !tbaa !27
  br label %bb21
bb16:
  %t58 = load { i64, [1 x i64] }, ptr %l1
  %t60 = extractvalue { i64, [1 x i64] } %t58, 0
  %t61 = icmp eq i64 %t60, 4
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t63 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { i32 }, ptr %t63, i32 0, i32 0
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l4, !tbaa !23
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t67 = load i32, ptr %l4, !tbaa !23
  %t68 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t71 = sext i32 %t67 to i64
  %t72 = call i64 @__olang_fmt_i64(ptr null, i64 %t71)
  %t73 = add i64 %t69, %t72
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = getelementptr i8, ptr %t77, i64 %t69
  %t79 = call i64 @__olang_fmt_i64(ptr %t78, i64 %t71)
  %t80 = getelementptr i8, ptr %t78, i64 %t72
  call void @olang_textcopy(ptr %t80, ptr %t74, i64 %t75)
  %t81 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t77, 1
  store { i64, ptr } %t82, ptr %l5, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_3c759898227385e0_43502750c3b6307c)
  unreachable
bb21:
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l29, !tbaa !24
  %t86 = load i64, ptr %l29, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l30, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l29, !tbaa !24
  %t96 = mul i64 %t95, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t92, ptr %t94, i64 %t96, i1 false)
  %t97 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t97, ptr %l5, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ervalue(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca %"compiler/mir:Place"
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Place"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Range"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Range"
  %l13 = alloca %"compiler/mir:Place"
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca %"compiler/mir:Range"
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca i32
  %l20 = alloca { i64, [1 x i64] }
  %l21 = alloca i32
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca %"compiler/mir:Place"
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca i32
  %l30 = alloca { i64, [1 x i64] }
  %l31 = alloca %"compiler/mir:Range"
  %l32 = alloca %"compiler/mir:Range"
  %l33 = alloca { i64, [4 x i64] }
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca { i64, [1 x i64] }
  %l37 = alloca { i64, [1 x i64] }
  %l38 = alloca i32
  %l39 = alloca { i64, [1 x i64] }
  %l40 = alloca { i64, [4 x i64] }
  %l41 = alloca { i64, [1 x i64] }
  %l44 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l74 = alloca i32
  %l76 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l91 = alloca i32
  %l93 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l252 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [15 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [15 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { { i64, [4 x i64] } }, ptr %t11, i32 0, i32 0
  %t13 = load { i64, [4 x i64] }, ptr %t12
  store { i64, [4 x i64] } %t13, ptr %l3
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [4 x i64] }, ptr %l3
  %t19 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %v1, ptr %t15, { i64, [4 x i64] } %t16)
  store { i64, ptr } %t19, ptr %l50
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t20, ptr %l44, !tbaa !27
  br label %bb107
bb5:
  %t21 = load { i64, [15 x i64] }, ptr %l1
  %t23 = extractvalue { i64, [15 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t27 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t26, i32 0, i32 0
  %t28 = load %"compiler/mir:Place", ptr %t27
  store %"compiler/mir:Place" %t28, ptr %l4
  %t30 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t31 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t30, i32 0, i32 1
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb11
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/mir:Place", ptr %l4
  %t38 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s2, ptr %t34, %"compiler/mir:Place" %t35)
  store { i64, ptr } %t38, ptr %l57
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t40 = load i32, ptr %l5, !tbaa !23
  %t43 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t39, i32 %t40)
  store { i64, ptr } %t43, ptr %l60
  br label %bb10
bb10:
  %t44 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t46 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = add i64 %t52, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t44, i64 %t45)
  %t58 = getelementptr i8, ptr %t57, i64 %t45
  call void @olang_textcopy(ptr %t58, ptr %t47, i64 %t48)
  %t59 = getelementptr i8, ptr %t58, i64 %t48
  call void @olang_textcopy(ptr %t59, ptr %t50, i64 %t51)
  %t60 = getelementptr i8, ptr %t59, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t54, i64 %t55)
  %t61 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t57, 1
  store { i64, ptr } %t62, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb11:
  %t64 = load { i64, [15 x i64] }, ptr %l1
  %t66 = extractvalue { i64, [15 x i64] } %t64, 0
  %t67 = icmp eq i64 %t66, 2
  br i1 %t67, label %bb12, label %bb13
bb12:
  %t69 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t70 = getelementptr { %"compiler/mir:Place" }, ptr %t69, i32 0, i32 0
  %t71 = load %"compiler/mir:Place", ptr %t70
  store %"compiler/mir:Place" %t71, ptr %l6
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/mir:Place", ptr %l6
  %t77 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s4, ptr %t73, %"compiler/mir:Place" %t74)
  store { i64, ptr } %t77, ptr %l67
  br label %bb15
bb15:
  %t78 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t80 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = add i64 %t79, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t78, i64 %t79)
  %t85 = getelementptr i8, ptr %t84, i64 %t79
  call void @olang_textcopy(ptr %t85, ptr %t81, i64 %t82)
  %t86 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t84, 1
  store { i64, ptr } %t87, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb107
bb16:
  %t89 = load { i64, [15 x i64] }, ptr %l1
  %t91 = extractvalue { i64, [15 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 3
  br i1 %t92, label %bb17, label %bb18
bb17:
  %t94 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t95 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t94, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l7
  %t98 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t99 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t98, i32 0, i32 1
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l8, !tbaa !23
  %t102 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t103 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t102, i32 0, i32 2
  %t104 = load %"compiler/mir:Range", ptr %t103
  store %"compiler/mir:Range" %t104, ptr %l9
  br label %bb19
bb18:
  br label %bb24
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t106 = load i32, ptr %l7
  store i32 %t106, ptr %l74
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s7, ptr %l74, i64 0)
  br label %bb20
bb20:
  %t108 = load ptr, ptr %s7
  %t109 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t110 = load i64, ptr %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t108, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l76, !tbaa !27
  %t114 = getelementptr %olang.builder, ptr %s7, i32 0, i32 3
  %t115 = load ptr, ptr %t114
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %sbgrew.117, label %sbdone.118
sbgrew.117:
  call void @__olang_sb_done(ptr %s7)
  br label %sbdone.118
sbdone.118:
  %t119 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t127 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s6, { i64, ptr } %t125)
  store { i64, ptr } %t127, ptr %l78
  br label %bb21
bb21:
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t129 = load i32, ptr %l8, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s6, ptr %t128, i32 %t129)
  store { i64, ptr } %t132, ptr %l81
  br label %bb22
bb22:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load %"compiler/mir:Range", ptr %l9
  %t137 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s6, ptr %t133, %"compiler/mir:Range" %t134)
  store { i64, ptr } %t137, ptr %l84
  br label %bb23
bb23:
  %t138 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t151 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t157 = add i64 %t154, %t156
  %t158 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t157)
  call void @olang_textcopy(ptr %t158, ptr %t139, i64 %t140)
  %t159 = getelementptr i8, ptr %t158, i64 %t140
  call void @olang_textcopy(ptr %t159, ptr %t141, i64 %t142)
  %t160 = getelementptr i8, ptr %t159, i64 %t142
  call void @olang_textcopy(ptr %t160, ptr %t145, i64 %t146)
  %t161 = getelementptr i8, ptr %t160, i64 %t146
  call void @olang_textcopy(ptr %t161, ptr %t148, i64 %t149)
  %t162 = getelementptr i8, ptr %t161, i64 %t149
  call void @olang_textcopy(ptr %t162, ptr %t152, i64 %t153)
  %t163 = getelementptr i8, ptr %t162, i64 %t153
  call void @olang_textcopy(ptr %t163, ptr %t155, i64 %t156)
  %t164 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t158, 1
  store { i64, ptr } %t165, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb107
bb24:
  %t167 = load { i64, [15 x i64] }, ptr %l1
  %t169 = extractvalue { i64, [15 x i64] } %t167, 0
  %t170 = icmp eq i64 %t169, 4
  br i1 %t170, label %bb25, label %bb26
bb25:
  %t172 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t173 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t172, i32 0, i32 0
  %t174 = load i32, ptr %t173
  store i32 %t174, ptr %l10
  %t176 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t177 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t176, i32 0, i32 1
  %t178 = load i32, ptr %t177
  store i32 %t178, ptr %l11, !tbaa !23
  %t180 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t181 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t180, i32 0, i32 2
  %t182 = load %"compiler/mir:Range", ptr %t181
  store %"compiler/mir:Range" %t182, ptr %l12
  br label %bb27
bb26:
  br label %bb32
bb27:
  store %olang.scope zeroinitializer, ptr %s9
  %t184 = load i32, ptr %l10
  store i32 %t184, ptr %l91
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s10, ptr %l91, i64 0)
  br label %bb28
bb28:
  %t186 = load ptr, ptr %s10
  %t187 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t188 = load i64, ptr %t187
  %t189 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t188)
  call void @olang_textcopy(ptr %t189, ptr %t186, i64 %t188)
  %t190 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l93, !tbaa !27
  %t192 = getelementptr %olang.builder, ptr %s10, i32 0, i32 3
  %t193 = load ptr, ptr %t192
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %sbgrew.195, label %sbdone.196
sbgrew.195:
  call void @__olang_sb_done(ptr %s10)
  br label %sbdone.196
sbdone.196:
  %t197 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  %t199 = extractvalue { i64, ptr } %t197, 1
  %t200 = mul i64 %t198, 1
  %t201 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t200)
  call void @llvm.memcpy.p0.p0.i64(ptr %t201, ptr %t199, i64 %t200, i1 false)
  %t202 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  %t205 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s9, { i64, ptr } %t203)
  store { i64, ptr } %t205, ptr %l95
  br label %bb29
bb29:
  %t206 = load ptr, ptr %l2, !tbaa !29
  %t207 = load i32, ptr %l11, !tbaa !23
  %t210 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s9, ptr %t206, i32 %t207)
  store { i64, ptr } %t210, ptr %l98
  br label %bb30
bb30:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load %"compiler/mir:Range", ptr %l12
  %t215 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s9, ptr %t211, %"compiler/mir:Range" %t212)
  store { i64, ptr } %t215, ptr %l101
  br label %bb31
bb31:
  %t216 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t218 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t231 = add i64 %t228, %t230
  %t232 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t216, i64 %t217)
  %t240 = getelementptr i8, ptr %t239, i64 %t217
  call void @olang_textcopy(ptr %t240, ptr %t219, i64 %t220)
  %t241 = getelementptr i8, ptr %t240, i64 %t220
  call void @olang_textcopy(ptr %t241, ptr %t222, i64 %t223)
  %t242 = getelementptr i8, ptr %t241, i64 %t223
  call void @olang_textcopy(ptr %t242, ptr %t226, i64 %t227)
  %t243 = getelementptr i8, ptr %t242, i64 %t227
  call void @olang_textcopy(ptr %t243, ptr %t229, i64 %t230)
  %t244 = getelementptr i8, ptr %t243, i64 %t230
  call void @olang_textcopy(ptr %t244, ptr %t233, i64 %t234)
  %t245 = getelementptr i8, ptr %t244, i64 %t234
  call void @olang_textcopy(ptr %t245, ptr %t236, i64 %t237)
  %t246 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t239, 1
  store { i64, ptr } %t247, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb107
bb32:
  %t249 = load { i64, [15 x i64] }, ptr %l1
  %t251 = extractvalue { i64, [15 x i64] } %t249, 0
  %t252 = icmp eq i64 %t251, 5
  br i1 %t252, label %bb33, label %bb34
bb33:
  %t254 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t255 = getelementptr { %"compiler/mir:Place" }, ptr %t254, i32 0, i32 0
  %t256 = load %"compiler/mir:Place", ptr %t255
  store %"compiler/mir:Place" %t256, ptr %l13
  br label %bb35
bb34:
  br label %bb37
bb35:
  store %olang.scope zeroinitializer, ptr %s12
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load %"compiler/mir:Place", ptr %l13
  %t262 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s12, ptr %t258, %"compiler/mir:Place" %t259)
  store { i64, ptr } %t262, ptr %l108
  br label %bb36
bb36:
  %t263 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t265 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = add i64 %t264, %t267
  %t269 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t268)
  call void @olang_textcopy(ptr %t269, ptr %t263, i64 %t264)
  %t270 = getelementptr i8, ptr %t269, i64 %t264
  call void @olang_textcopy(ptr %t270, ptr %t266, i64 %t267)
  %t271 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t269, 1
  store { i64, ptr } %t272, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb107
bb37:
  %t274 = load { i64, [15 x i64] }, ptr %l1
  %t276 = extractvalue { i64, [15 x i64] } %t274, 0
  %t277 = icmp eq i64 %t276, 6
  br i1 %t277, label %bb38, label %bb39
bb38:
  %t279 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t280 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t279, i32 0, i32 0
  %t281 = load i32, ptr %t280
  store i32 %t281, ptr %l14, !tbaa !23
  %t283 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t284 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t283, i32 0, i32 1
  %t285 = load i64, ptr %t284
  store i64 %t285, ptr %l15, !tbaa !24
  %t287 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t288 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t287, i32 0, i32 2
  %t289 = load %"compiler/mir:Range", ptr %t288
  store %"compiler/mir:Range" %t289, ptr %l16
  br label %bb40
bb39:
  br label %bb46
bb40:
  store %olang.scope zeroinitializer, ptr %s14
  %t291 = load ptr, ptr %l2, !tbaa !29
  %t292 = load i32, ptr %l14, !tbaa !23
  %t295 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s14, ptr %t291, i32 %t292)
  store { i64, ptr } %t295, ptr %l117
  br label %bb41
bb41:
  %t296 = load i64, ptr %l15, !tbaa !24
  %t298 = icmp sgt i64 %t296, 0
  br i1 %t298, label %bb42, label %bb43
bb42:
  %t300 = load i64, ptr %l15, !tbaa !24
  %t301 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t304 = call i64 @__olang_fmt_i64(ptr null, i64 %t300)
  %t305 = add i64 %t302, %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t301, i64 %t302)
  %t307 = getelementptr i8, ptr %t306, i64 %t302
  %t308 = call i64 @__olang_fmt_i64(ptr %t307, i64 %t300)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t306, 1
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = extractvalue { i64, ptr } %t310, 1
  %t314 = mul i64 %t312, 1
  %t315 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t314)
  call void @llvm.memcpy.p0.p0.i64(ptr %t315, ptr %t313, i64 %t314, i1 false)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t315, 1
  store { i64, ptr } %t317, ptr %l120, !tbaa !27
  br label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l120, !tbaa !27
  br label %bb44
bb44:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load %"compiler/mir:Range", ptr %l16
  %t323 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s14, ptr %t319, %"compiler/mir:Range" %t320)
  store { i64, ptr } %t323, ptr %l126
  br label %bb45
bb45:
  %t324 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t326 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = add i64 %t325, %t328
  %t330 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 1
  %t332 = extractvalue { i64, ptr } %t330, 0
  %t333 = add i64 %t329, %t332
  %t334 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t335 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t336 = add i64 %t333, %t335
  %t337 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t337, 1
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t340 = add i64 %t336, %t339
  %t341 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t343 = add i64 %t340, %t342
  %t344 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t343)
  call void @olang_textcopy(ptr %t344, ptr %t324, i64 %t325)
  %t345 = getelementptr i8, ptr %t344, i64 %t325
  call void @olang_textcopy(ptr %t345, ptr %t327, i64 %t328)
  %t346 = getelementptr i8, ptr %t345, i64 %t328
  call void @olang_textcopy(ptr %t346, ptr %t331, i64 %t332)
  %t347 = getelementptr i8, ptr %t346, i64 %t332
  call void @olang_textcopy(ptr %t347, ptr %t334, i64 %t335)
  %t348 = getelementptr i8, ptr %t347, i64 %t335
  call void @olang_textcopy(ptr %t348, ptr %t338, i64 %t339)
  %t349 = getelementptr i8, ptr %t348, i64 %t339
  call void @olang_textcopy(ptr %t349, ptr %t341, i64 %t342)
  %t350 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t344, 1
  store { i64, ptr } %t351, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb107
bb46:
  %t353 = load { i64, [15 x i64] }, ptr %l1
  %t355 = extractvalue { i64, [15 x i64] } %t353, 0
  %t356 = icmp eq i64 %t355, 7
  br i1 %t356, label %bb47, label %bb48
bb47:
  %t358 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t359 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t358, i32 0, i32 0
  %t360 = load { i64, [1 x i64] }, ptr %t359
  store { i64, [1 x i64] } %t360, ptr %l17
  %t362 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t363 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t362, i32 0, i32 1
  %t364 = load { i64, [4 x i64] }, ptr %t363
  store { i64, [4 x i64] } %t364, ptr %l18
  %t366 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t367 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t366, i32 0, i32 2
  %t368 = load i32, ptr %t367
  store i32 %t368, ptr %l19, !tbaa !23
  br label %bb49
bb48:
  br label %bb53
bb49:
  store %olang.scope zeroinitializer, ptr %s17
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load { i64, [1 x i64] }, ptr %l17
  %t374 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s17, ptr %t370, { i64, [1 x i64] } %t371)
  store { i64, ptr } %t374, ptr %l135
  br label %bb50
bb50:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load { i64, [4 x i64] }, ptr %l18
  %t379 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s17, ptr %t375, { i64, [4 x i64] } %t376)
  store { i64, ptr } %t379, ptr %l138
  br label %bb51
bb51:
  %t380 = load ptr, ptr %l2, !tbaa !29
  %t381 = load i32, ptr %l19, !tbaa !23
  %t384 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s17, ptr %t380, i32 %t381)
  store { i64, ptr } %t384, ptr %l141
  br label %bb52
bb52:
  %t385 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t386 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t387 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t387, 1
  %t389 = extractvalue { i64, ptr } %t387, 0
  %t390 = add i64 %t386, %t389
  %t391 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t393 = add i64 %t390, %t392
  %t394 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = add i64 %t393, %t396
  %t398 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t399 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t400 = add i64 %t397, %t399
  %t401 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t401, 1
  %t403 = extractvalue { i64, ptr } %t401, 0
  %t404 = add i64 %t400, %t403
  %t405 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t404)
  call void @olang_textcopy(ptr %t405, ptr %t385, i64 %t386)
  %t406 = getelementptr i8, ptr %t405, i64 %t386
  call void @olang_textcopy(ptr %t406, ptr %t388, i64 %t389)
  %t407 = getelementptr i8, ptr %t406, i64 %t389
  call void @olang_textcopy(ptr %t407, ptr %t391, i64 %t392)
  %t408 = getelementptr i8, ptr %t407, i64 %t392
  call void @olang_textcopy(ptr %t408, ptr %t395, i64 %t396)
  %t409 = getelementptr i8, ptr %t408, i64 %t396
  call void @olang_textcopy(ptr %t409, ptr %t398, i64 %t399)
  %t410 = getelementptr i8, ptr %t409, i64 %t399
  call void @olang_textcopy(ptr %t410, ptr %t402, i64 %t403)
  %t411 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t405, 1
  store { i64, ptr } %t412, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb107
bb53:
  %t414 = load { i64, [15 x i64] }, ptr %l1
  %t416 = extractvalue { i64, [15 x i64] } %t414, 0
  %t417 = icmp eq i64 %t416, 8
  br i1 %t417, label %bb54, label %bb55
bb54:
  %t419 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t420 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t419, i32 0, i32 0
  %t421 = load { i64, [1 x i64] }, ptr %t420
  store { i64, [1 x i64] } %t421, ptr %l20
  %t423 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t424 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t423, i32 0, i32 1
  %t425 = load i32, ptr %t424
  store i32 %t425, ptr %l21, !tbaa !23
  %t427 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t428 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t427, i32 0, i32 2
  %t429 = load { i64, [4 x i64] }, ptr %t428
  store { i64, [4 x i64] } %t429, ptr %l22
  %t431 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t432 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t431, i32 0, i32 3
  %t433 = load { i64, [4 x i64] }, ptr %t432
  store { i64, [4 x i64] } %t433, ptr %l23
  br label %bb56
bb55:
  br label %bb61
bb56:
  store %olang.scope zeroinitializer, ptr %s19
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load { i64, [1 x i64] }, ptr %l20
  %t439 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s19, ptr %t435, { i64, [1 x i64] } %t436)
  store { i64, ptr } %t439, ptr %l151
  br label %bb57
bb57:
  %t440 = load ptr, ptr %l2, !tbaa !29
  %t441 = load i32, ptr %l21, !tbaa !23
  %t444 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s19, ptr %t440, i32 %t441)
  store { i64, ptr } %t444, ptr %l154
  br label %bb58
bb58:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load { i64, [4 x i64] }, ptr %l22
  %t449 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s19, ptr %t445, { i64, [4 x i64] } %t446)
  store { i64, ptr } %t449, ptr %l157
  br label %bb59
bb59:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load { i64, [4 x i64] }, ptr %l23
  %t454 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s19, ptr %t450, { i64, [4 x i64] } %t451)
  store { i64, ptr } %t454, ptr %l160
  br label %bb60
bb60:
  %t455 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t456 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t457 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t457, 1
  %t459 = extractvalue { i64, ptr } %t457, 0
  %t460 = add i64 %t456, %t459
  %t461 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t463 = add i64 %t460, %t462
  %t464 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 1
  %t466 = extractvalue { i64, ptr } %t464, 0
  %t467 = add i64 %t463, %t466
  %t468 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t469 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t470 = add i64 %t467, %t469
  %t471 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t471, 1
  %t473 = extractvalue { i64, ptr } %t471, 0
  %t474 = add i64 %t470, %t473
  %t475 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t476 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t477 = add i64 %t474, %t476
  %t478 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t478, 1
  %t480 = extractvalue { i64, ptr } %t478, 0
  %t481 = add i64 %t477, %t480
  %t482 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t483 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t484 = add i64 %t481, %t483
  %t485 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t484)
  call void @olang_textcopy(ptr %t485, ptr %t455, i64 %t456)
  %t486 = getelementptr i8, ptr %t485, i64 %t456
  call void @olang_textcopy(ptr %t486, ptr %t458, i64 %t459)
  %t487 = getelementptr i8, ptr %t486, i64 %t459
  call void @olang_textcopy(ptr %t487, ptr %t461, i64 %t462)
  %t488 = getelementptr i8, ptr %t487, i64 %t462
  call void @olang_textcopy(ptr %t488, ptr %t465, i64 %t466)
  %t489 = getelementptr i8, ptr %t488, i64 %t466
  call void @olang_textcopy(ptr %t489, ptr %t468, i64 %t469)
  %t490 = getelementptr i8, ptr %t489, i64 %t469
  call void @olang_textcopy(ptr %t490, ptr %t472, i64 %t473)
  %t491 = getelementptr i8, ptr %t490, i64 %t473
  call void @olang_textcopy(ptr %t491, ptr %t475, i64 %t476)
  %t492 = getelementptr i8, ptr %t491, i64 %t476
  call void @olang_textcopy(ptr %t492, ptr %t479, i64 %t480)
  %t493 = getelementptr i8, ptr %t492, i64 %t480
  call void @olang_textcopy(ptr %t493, ptr %t482, i64 %t483)
  %t494 = insertvalue { i64, ptr } undef, i64 %t484, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t485, 1
  store { i64, ptr } %t495, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb107
bb61:
  %t497 = load { i64, [15 x i64] }, ptr %l1
  %t499 = extractvalue { i64, [15 x i64] } %t497, 0
  %t500 = icmp eq i64 %t499, 9
  br i1 %t500, label %bb62, label %bb63
bb62:
  %t502 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t503 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t502, i32 0, i32 0
  %t504 = load %"compiler/mir:Place", ptr %t503
  store %"compiler/mir:Place" %t504, ptr %l24
  %t506 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t507 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t506, i32 0, i32 1
  %t508 = load { i64, [4 x i64] }, ptr %t507
  store { i64, [4 x i64] } %t508, ptr %l25
  %t510 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t511 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t510, i32 0, i32 2
  %t512 = load { i64, [4 x i64] }, ptr %t511
  store { i64, [4 x i64] } %t512, ptr %l26
  %t514 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t515 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t514, i32 0, i32 3
  %t516 = load i32, ptr %t515
  store i32 %t516, ptr %l27, !tbaa !23
  br label %bb64
bb63:
  br label %bb69
bb64:
  store %olang.scope zeroinitializer, ptr %s21
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load %"compiler/mir:Place", ptr %l24
  %t522 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s21, ptr %t518, %"compiler/mir:Place" %t519)
  store { i64, ptr } %t522, ptr %l170
  br label %bb65
bb65:
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t524 = load { i64, [4 x i64] }, ptr %l25
  %t527 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s21, ptr %t523, { i64, [4 x i64] } %t524)
  store { i64, ptr } %t527, ptr %l173
  br label %bb66
bb66:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load { i64, [4 x i64] }, ptr %l26
  %t532 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s21, ptr %t528, { i64, [4 x i64] } %t529)
  store { i64, ptr } %t532, ptr %l176
  br label %bb67
bb67:
  %t533 = load ptr, ptr %l2, !tbaa !29
  %t534 = load i32, ptr %l27, !tbaa !23
  %t537 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s21, ptr %t533, i32 %t534)
  store { i64, ptr } %t537, ptr %l179
  br label %bb68
bb68:
  %t538 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t539 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t540 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t540, 1
  %t542 = extractvalue { i64, ptr } %t540, 0
  %t543 = add i64 %t539, %t542
  %t544 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t545 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t546 = add i64 %t543, %t545
  %t547 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t547, 1
  %t549 = extractvalue { i64, ptr } %t547, 0
  %t550 = add i64 %t546, %t549
  %t551 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t552 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t553 = add i64 %t550, %t552
  %t554 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t554, 1
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t557 = add i64 %t553, %t556
  %t558 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t560 = add i64 %t557, %t559
  %t561 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t562 = extractvalue { i64, ptr } %t561, 1
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t564 = add i64 %t560, %t563
  %t565 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t564)
  call void @olang_textcopy(ptr %t565, ptr %t538, i64 %t539)
  %t566 = getelementptr i8, ptr %t565, i64 %t539
  call void @olang_textcopy(ptr %t566, ptr %t541, i64 %t542)
  %t567 = getelementptr i8, ptr %t566, i64 %t542
  call void @olang_textcopy(ptr %t567, ptr %t544, i64 %t545)
  %t568 = getelementptr i8, ptr %t567, i64 %t545
  call void @olang_textcopy(ptr %t568, ptr %t548, i64 %t549)
  %t569 = getelementptr i8, ptr %t568, i64 %t549
  call void @olang_textcopy(ptr %t569, ptr %t551, i64 %t552)
  %t570 = getelementptr i8, ptr %t569, i64 %t552
  call void @olang_textcopy(ptr %t570, ptr %t555, i64 %t556)
  %t571 = getelementptr i8, ptr %t570, i64 %t556
  call void @olang_textcopy(ptr %t571, ptr %t558, i64 %t559)
  %t572 = getelementptr i8, ptr %t571, i64 %t559
  call void @olang_textcopy(ptr %t572, ptr %t562, i64 %t563)
  %t573 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t565, 1
  store { i64, ptr } %t574, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s21)
  br label %bb107
bb69:
  %t576 = load { i64, [15 x i64] }, ptr %l1
  %t578 = extractvalue { i64, [15 x i64] } %t576, 0
  %t579 = icmp eq i64 %t578, 10
  br i1 %t579, label %bb70, label %bb71
bb70:
  %t581 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t582 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t581, i32 0, i32 0
  %t583 = load { i64, [2 x i64] }, ptr %t582
  store { i64, [2 x i64] } %t583, ptr %l28
  %t585 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t586 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t585, i32 0, i32 1
  %t587 = load i32, ptr %t586
  store i32 %t587, ptr %l29, !tbaa !23
  %t589 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t590 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t589, i32 0, i32 2
  %t591 = load { i64, [1 x i64] }, ptr %t590
  store { i64, [1 x i64] } %t591, ptr %l30
  %t593 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t594 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t593, i32 0, i32 3
  %t595 = load %"compiler/mir:Range", ptr %t594
  store %"compiler/mir:Range" %t595, ptr %l31
  %t597 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t598 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t597, i32 0, i32 4
  %t599 = load %"compiler/mir:Range", ptr %t598
  store %"compiler/mir:Range" %t599, ptr %l32
  br label %bb72
bb71:
  br label %bb81
bb72:
  store %olang.scope zeroinitializer, ptr %s23
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t602 = load { i64, [2 x i64] }, ptr %l28
  %t605 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %s23, ptr %t601, { i64, [2 x i64] } %t602)
  store { i64, ptr } %t605, ptr %l190
  br label %bb73
bb73:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load { i64, [1 x i64] }, ptr %l30
  %t610 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s23, ptr %t606, { i64, [1 x i64] } %t607)
  store { i64, ptr } %t610, ptr %l193
  br label %bb74
bb74:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load %"compiler/mir:Range", ptr %l31
  %t615 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s23, ptr %t611, %"compiler/mir:Range" %t612)
  store { i64, ptr } %t615, ptr %l196
  br label %bb75
bb75:
  %t616 = getelementptr %"compiler/mir:Range", ptr %l32, i32 0, i32 1
  %t617 = load i32, ptr %t616, !tbaa !23
  %t619 = icmp sgt i32 %t617, 0
  br i1 %t619, label %bb76, label %bb77
bb76:
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load %"compiler/mir:Range", ptr %l32
  %t625 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s23, ptr %t621, %"compiler/mir:Range" %t622)
  store { i64, ptr } %t625, ptr %l202
  br label %bb78
bb77:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d113, i32 0, i32 1) }, ptr %l199, !tbaa !27
  br label %bb79
bb78:
  %t626 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t627 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t628 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t629 = extractvalue { i64, ptr } %t628, 1
  %t630 = extractvalue { i64, ptr } %t628, 0
  %t631 = add i64 %t627, %t630
  %t632 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t631)
  call void @olang_textcopy(ptr %t632, ptr %t626, i64 %t627)
  %t633 = getelementptr i8, ptr %t632, i64 %t627
  call void @olang_textcopy(ptr %t633, ptr %t629, i64 %t630)
  %t634 = insertvalue { i64, ptr } undef, i64 %t631, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t632, 1
  %t637 = extractvalue { i64, ptr } %t635, 0
  %t638 = extractvalue { i64, ptr } %t635, 1
  %t639 = mul i64 %t637, 1
  %t640 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t639)
  call void @llvm.memcpy.p0.p0.i64(ptr %t640, ptr %t638, i64 %t639, i1 false)
  %t641 = insertvalue { i64, ptr } undef, i64 %t637, 0
  %t642 = insertvalue { i64, ptr } %t641, ptr %t640, 1
  store { i64, ptr } %t642, ptr %l199, !tbaa !27
  br label %bb79
bb79:
  %t644 = load ptr, ptr %l2, !tbaa !29
  %t645 = load i32, ptr %l29, !tbaa !23
  %t648 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s23, ptr %t644, i32 %t645)
  store { i64, ptr } %t648, ptr %l207
  br label %bb80
bb80:
  %t649 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t650 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t651 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t652 = extractvalue { i64, ptr } %t651, 1
  %t653 = extractvalue { i64, ptr } %t651, 0
  %t654 = add i64 %t650, %t653
  %t655 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t656 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t657 = add i64 %t654, %t656
  %t658 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t659 = extractvalue { i64, ptr } %t658, 1
  %t660 = extractvalue { i64, ptr } %t658, 0
  %t661 = add i64 %t657, %t660
  %t662 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t663 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t664 = add i64 %t661, %t663
  %t665 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t665, 1
  %t667 = extractvalue { i64, ptr } %t665, 0
  %t668 = add i64 %t664, %t667
  %t669 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t670 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t671 = add i64 %t668, %t670
  %t672 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t673 = extractvalue { i64, ptr } %t672, 1
  %t674 = extractvalue { i64, ptr } %t672, 0
  %t675 = add i64 %t671, %t674
  %t676 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t677 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t678 = add i64 %t675, %t677
  %t679 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 1
  %t681 = extractvalue { i64, ptr } %t679, 0
  %t682 = add i64 %t678, %t681
  %t683 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t682)
  call void @olang_textcopy(ptr %t683, ptr %t649, i64 %t650)
  %t684 = getelementptr i8, ptr %t683, i64 %t650
  call void @olang_textcopy(ptr %t684, ptr %t652, i64 %t653)
  %t685 = getelementptr i8, ptr %t684, i64 %t653
  call void @olang_textcopy(ptr %t685, ptr %t655, i64 %t656)
  %t686 = getelementptr i8, ptr %t685, i64 %t656
  call void @olang_textcopy(ptr %t686, ptr %t659, i64 %t660)
  %t687 = getelementptr i8, ptr %t686, i64 %t660
  call void @olang_textcopy(ptr %t687, ptr %t662, i64 %t663)
  %t688 = getelementptr i8, ptr %t687, i64 %t663
  call void @olang_textcopy(ptr %t688, ptr %t666, i64 %t667)
  %t689 = getelementptr i8, ptr %t688, i64 %t667
  call void @olang_textcopy(ptr %t689, ptr %t669, i64 %t670)
  %t690 = getelementptr i8, ptr %t689, i64 %t670
  call void @olang_textcopy(ptr %t690, ptr %t673, i64 %t674)
  %t691 = getelementptr i8, ptr %t690, i64 %t674
  call void @olang_textcopy(ptr %t691, ptr %t676, i64 %t677)
  %t692 = getelementptr i8, ptr %t691, i64 %t677
  call void @olang_textcopy(ptr %t692, ptr %t680, i64 %t681)
  %t693 = insertvalue { i64, ptr } undef, i64 %t682, 0
  %t694 = insertvalue { i64, ptr } %t693, ptr %t683, 1
  store { i64, ptr } %t694, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s23)
  br label %bb107
bb81:
  %t696 = load { i64, [15 x i64] }, ptr %l1
  %t698 = extractvalue { i64, [15 x i64] } %t696, 0
  %t699 = icmp eq i64 %t698, 11
  br i1 %t699, label %bb82, label %bb83
bb82:
  %t701 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t702 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t701, i32 0, i32 0
  %t703 = load { i64, [4 x i64] }, ptr %t702
  store { i64, [4 x i64] } %t703, ptr %l33
  %t705 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t706 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t705, i32 0, i32 1
  %t707 = load i32, ptr %t706
  store i32 %t707, ptr %l34, !tbaa !23
  %t709 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t710 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t709, i32 0, i32 2
  %t711 = load i32, ptr %t710
  store i32 %t711, ptr %l35, !tbaa !23
  br label %bb84
bb83:
  br label %bb88
bb84:
  store %olang.scope zeroinitializer, ptr %s26
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load { i64, [4 x i64] }, ptr %l33
  %t717 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s26, ptr %t713, { i64, [4 x i64] } %t714)
  store { i64, ptr } %t717, ptr %l216
  br label %bb85
bb85:
  %t718 = load ptr, ptr %l0, !tbaa !29
  %t719 = load i32, ptr %l34, !tbaa !23
  %t722 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %s26, ptr %t718, i32 %t719)
  store { i64, ptr } %t722, ptr %l219
  br label %bb86
bb86:
  %t723 = load ptr, ptr %l0, !tbaa !29
  %t724 = load i32, ptr %l35, !tbaa !23
  %t727 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %s26, ptr %t723, i32 %t724)
  store { i64, ptr } %t727, ptr %l222
  br label %bb87
bb87:
  %t728 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t729 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t730 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t731 = extractvalue { i64, ptr } %t730, 1
  %t732 = extractvalue { i64, ptr } %t730, 0
  %t733 = add i64 %t729, %t732
  %t734 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t735 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t736 = add i64 %t733, %t735
  %t737 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t738 = extractvalue { i64, ptr } %t737, 1
  %t739 = extractvalue { i64, ptr } %t737, 0
  %t740 = add i64 %t736, %t739
  %t741 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t742 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t743 = add i64 %t740, %t742
  %t744 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t745 = extractvalue { i64, ptr } %t744, 1
  %t746 = extractvalue { i64, ptr } %t744, 0
  %t747 = add i64 %t743, %t746
  %t748 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t747)
  call void @olang_textcopy(ptr %t748, ptr %t728, i64 %t729)
  %t749 = getelementptr i8, ptr %t748, i64 %t729
  call void @olang_textcopy(ptr %t749, ptr %t731, i64 %t732)
  %t750 = getelementptr i8, ptr %t749, i64 %t732
  call void @olang_textcopy(ptr %t750, ptr %t734, i64 %t735)
  %t751 = getelementptr i8, ptr %t750, i64 %t735
  call void @olang_textcopy(ptr %t751, ptr %t738, i64 %t739)
  %t752 = getelementptr i8, ptr %t751, i64 %t739
  call void @olang_textcopy(ptr %t752, ptr %t741, i64 %t742)
  %t753 = getelementptr i8, ptr %t752, i64 %t742
  call void @olang_textcopy(ptr %t753, ptr %t745, i64 %t746)
  %t754 = insertvalue { i64, ptr } undef, i64 %t747, 0
  %t755 = insertvalue { i64, ptr } %t754, ptr %t748, 1
  store { i64, ptr } %t755, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s26)
  br label %bb107
bb88:
  %t757 = load { i64, [15 x i64] }, ptr %l1
  %t759 = extractvalue { i64, [15 x i64] } %t757, 0
  %t760 = icmp eq i64 %t759, 12
  br i1 %t760, label %bb89, label %bb90
bb89:
  %t762 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t763 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t762, i32 0, i32 0
  %t764 = load { i64, [1 x i64] }, ptr %t763
  store { i64, [1 x i64] } %t764, ptr %l36
  %t766 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t767 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t766, i32 0, i32 1
  %t768 = load { i64, [1 x i64] }, ptr %t767
  store { i64, [1 x i64] } %t768, ptr %l37
  %t770 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t771 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t770, i32 0, i32 2
  %t772 = load i32, ptr %t771
  store i32 %t772, ptr %l38, !tbaa !23
  br label %bb91
bb90:
  br label %bb95
bb91:
  store %olang.scope zeroinitializer, ptr %s28
  %t774 = load ptr, ptr %l0, !tbaa !29
  %t775 = load { i64, [1 x i64] }, ptr %l36
  %t778 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s28, ptr %t774, { i64, [1 x i64] } %t775)
  store { i64, ptr } %t778, ptr %l231
  br label %bb92
bb92:
  %t779 = load ptr, ptr %l0, !tbaa !29
  %t780 = load { i64, [1 x i64] }, ptr %l37
  %t783 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s28, ptr %t779, { i64, [1 x i64] } %t780)
  store { i64, ptr } %t783, ptr %l234
  br label %bb93
bb93:
  %t784 = load ptr, ptr %l2, !tbaa !29
  %t785 = load i32, ptr %l38, !tbaa !23
  %t788 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s28, ptr %t784, i32 %t785)
  store { i64, ptr } %t788, ptr %l237
  br label %bb94
bb94:
  %t789 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t790 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t791 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t792 = extractvalue { i64, ptr } %t791, 1
  %t793 = extractvalue { i64, ptr } %t791, 0
  %t794 = add i64 %t790, %t793
  %t795 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t796 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t797 = add i64 %t794, %t796
  %t798 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t799 = extractvalue { i64, ptr } %t798, 1
  %t800 = extractvalue { i64, ptr } %t798, 0
  %t801 = add i64 %t797, %t800
  %t802 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t803 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t804 = add i64 %t801, %t803
  %t805 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t806 = extractvalue { i64, ptr } %t805, 1
  %t807 = extractvalue { i64, ptr } %t805, 0
  %t808 = add i64 %t804, %t807
  %t809 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t808)
  call void @olang_textcopy(ptr %t809, ptr %t789, i64 %t790)
  %t810 = getelementptr i8, ptr %t809, i64 %t790
  call void @olang_textcopy(ptr %t810, ptr %t792, i64 %t793)
  %t811 = getelementptr i8, ptr %t810, i64 %t793
  call void @olang_textcopy(ptr %t811, ptr %t795, i64 %t796)
  %t812 = getelementptr i8, ptr %t811, i64 %t796
  call void @olang_textcopy(ptr %t812, ptr %t799, i64 %t800)
  %t813 = getelementptr i8, ptr %t812, i64 %t800
  call void @olang_textcopy(ptr %t813, ptr %t802, i64 %t803)
  %t814 = getelementptr i8, ptr %t813, i64 %t803
  call void @olang_textcopy(ptr %t814, ptr %t806, i64 %t807)
  %t815 = insertvalue { i64, ptr } undef, i64 %t808, 0
  %t816 = insertvalue { i64, ptr } %t815, ptr %t809, 1
  store { i64, ptr } %t816, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s28)
  br label %bb107
bb95:
  %t818 = load { i64, [15 x i64] }, ptr %l1
  %t820 = extractvalue { i64, [15 x i64] } %t818, 0
  %t821 = icmp eq i64 %t820, 13
  br i1 %t821, label %bb96, label %bb97
bb96:
  %t823 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t824 = getelementptr { { i64, [1 x i64] } }, ptr %t823, i32 0, i32 0
  %t825 = load { i64, [1 x i64] }, ptr %t824
  store { i64, [1 x i64] } %t825, ptr %l39
  br label %bb98
bb97:
  br label %bb100
bb98:
  store %olang.scope zeroinitializer, ptr %s30
  %t827 = load ptr, ptr %l0, !tbaa !29
  %t828 = load { i64, [1 x i64] }, ptr %l39
  %t831 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s30, ptr %t827, { i64, [1 x i64] } %t828)
  store { i64, ptr } %t831, ptr %l244
  br label %bb99
bb99:
  %t832 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t833 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t834 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t835 = extractvalue { i64, ptr } %t834, 1
  %t836 = extractvalue { i64, ptr } %t834, 0
  %t837 = add i64 %t833, %t836
  %t838 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t837)
  call void @olang_textcopy(ptr %t838, ptr %t832, i64 %t833)
  %t839 = getelementptr i8, ptr %t838, i64 %t833
  call void @olang_textcopy(ptr %t839, ptr %t835, i64 %t836)
  %t840 = insertvalue { i64, ptr } undef, i64 %t837, 0
  %t841 = insertvalue { i64, ptr } %t840, ptr %t838, 1
  store { i64, ptr } %t841, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s30)
  br label %bb107
bb100:
  %t843 = load { i64, [15 x i64] }, ptr %l1
  %t845 = extractvalue { i64, [15 x i64] } %t843, 0
  %t846 = icmp eq i64 %t845, 14
  br i1 %t846, label %bb101, label %bb102
bb101:
  %t848 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t849 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t848, i32 0, i32 0
  %t850 = load { i64, [4 x i64] }, ptr %t849
  store { i64, [4 x i64] } %t850, ptr %l40
  %t852 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t853 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t852, i32 0, i32 1
  %t854 = load { i64, [1 x i64] }, ptr %t853
  store { i64, [1 x i64] } %t854, ptr %l41
  br label %bb103
bb102:
  br label %bb106
bb103:
  store %olang.scope zeroinitializer, ptr %s32
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t857 = load { i64, [4 x i64] }, ptr %l40
  %t860 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s32, ptr %t856, { i64, [4 x i64] } %t857)
  store { i64, ptr } %t860, ptr %l252
  br label %bb104
bb104:
  %t861 = load ptr, ptr %l0, !tbaa !29
  %t862 = load { i64, [1 x i64] }, ptr %l41
  %t865 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s32, ptr %t861, { i64, [1 x i64] } %t862)
  store { i64, ptr } %t865, ptr %l255
  br label %bb105
bb105:
  %t866 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t867 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t868 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t869 = extractvalue { i64, ptr } %t868, 1
  %t870 = extractvalue { i64, ptr } %t868, 0
  %t871 = add i64 %t867, %t870
  %t872 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t873 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t874 = add i64 %t871, %t873
  %t875 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t876 = extractvalue { i64, ptr } %t875, 1
  %t877 = extractvalue { i64, ptr } %t875, 0
  %t878 = add i64 %t874, %t877
  %t879 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t878)
  call void @olang_textcopy(ptr %t879, ptr %t866, i64 %t867)
  %t880 = getelementptr i8, ptr %t879, i64 %t867
  call void @olang_textcopy(ptr %t880, ptr %t869, i64 %t870)
  %t881 = getelementptr i8, ptr %t880, i64 %t870
  call void @olang_textcopy(ptr %t881, ptr %t872, i64 %t873)
  %t882 = getelementptr i8, ptr %t881, i64 %t873
  call void @olang_textcopy(ptr %t882, ptr %t876, i64 %t877)
  %t883 = insertvalue { i64, ptr } undef, i64 %t878, 0
  %t884 = insertvalue { i64, ptr } %t883, ptr %t879, 1
  store { i64, ptr } %t884, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s32)
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_55b2be13c853614c_e5b496909f3a0f10)
  unreachable
bb107:
  %t886 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t886, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2etask(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Task" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Task"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l15 = alloca %"compiler/mir:TaskClause"
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca %"compiler/typed:Item"
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l30 = alloca i32
  %l33 = alloca i32
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l64 = alloca %"compiler/mir:Place"
  %l65 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l100 = alloca i32
  %l103 = alloca i32
  %l129 = alloca %"compiler/mir:TaskClause"
  %l137 = alloca i32
  %l140 = alloca i32
  %l166 = alloca %"compiler/typed:Item"
  %l167 = alloca ptr
  %l171 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca i64
  %l197 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Task" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l23
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 3
  %t4 = getelementptr %"compiler/mir:Range", ptr %t3, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = icmp sgt i32 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 0, ptr %l3, !tbaa !23
  %t9 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 3
  %t10 = getelementptr %"compiler/mir:Range", ptr %t9, i32 0, i32 1
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t13 = load i32, ptr %l4, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = icmp sgt i32 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb3:
  br label %bb23
bb4:
  %t19 = load i32, ptr %l5, !tbaa !23
  %t21 = icmp sgt i32 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i32 0, ptr %l30, !tbaa !23
  br label %bb9
bb6:
  %t23 = load i32, ptr %l4, !tbaa !23
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = sub i32 %t23, %t24
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = add i32 %t27, %t28
  %t33 = sub i32 %t31, 1
  %t34 = load i32, ptr %l5, !tbaa !23
  %t37 = sdiv i32 %t33, %t34
  store i32 %t37, ptr %l33, !tbaa !23
  br label %bb8
bb7:
  store i32 0, ptr %l33, !tbaa !23
  br label %bb8
bb8:
  %t39 = load i32, ptr %l33, !tbaa !23
  store i32 %t39, ptr %l30, !tbaa !23
  br label %bb9
bb9:
  %t40 = load i32, ptr %l30, !tbaa !23
  store i32 %t40, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load i32, ptr %l7, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = icmp slt i32 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t49 = load i32, ptr %l3, !tbaa !23
  %t50 = load i32, ptr %l7, !tbaa !23
  %t51 = load i32, ptr %l5, !tbaa !23
  %t54 = mul i32 %t50, %t51
  %t57 = add i32 %t49, %t54
  store i32 %t57, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l51, !tbaa !29
  %t59 = load i32, ptr %l8, !tbaa !23
  %t61 = icmp sgt i32 %t59, 0
  br i1 %t61, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d129, i32 0, i32 1) }, ptr %l54, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d130, i32 0, i32 1) }, ptr %l54, !tbaa !27
  br label %bb16
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l55, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/mir:dumper", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/mir:Fn", ptr %t67, i32 0, i32 13
  %t70 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 3
  %t71 = getelementptr %"compiler/mir:Range", ptr %t70, i32 0, i32 0
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  %t75 = load i32, ptr %l8, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t80 = add i64 %t74, %t77
  %t83 = call %"compiler/mir:Place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t69, i64 %t80)
  store %"compiler/mir:Place" %t83, ptr %l64
  br label %bb17
bb17:
  %t84 = load ptr, ptr %l55, !tbaa !29
  %t85 = load %"compiler/mir:Place", ptr %l64
  %t86 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s3, ptr %t84, %"compiler/mir:Place" %t85)
  store { i64, ptr } %t86, ptr %l65
  br label %bb18
bb18:
  %t87 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = add i64 %t89, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t88, i64 %t89)
  %t95 = getelementptr i8, ptr %t94, i64 %t89
  call void @olang_textcopy(ptr %t95, ptr %t91, i64 %t92)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t94, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t105, { i64, ptr } %t104)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t107 = load i32, ptr %l7, !tbaa !23
  %t109 = add i32 %t107, 1
  store i32 %t109, ptr %l7, !tbaa !23
  br label %bb10
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d131, i32 0, i32 1) })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb23:
  store ptr %l2, ptr %l71, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 0
  %t114 = load { i64, [7 x i64] }, ptr %t113
  %t117 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %s0, ptr %t112, { i64, [7 x i64] } %t114)
  store { i64, ptr } %t117, ptr %l74
  br label %bb24
bb24:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 1
  %t120 = load %"compiler/mir:Range", ptr %t119
  %t123 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s0, ptr %t118, %"compiler/mir:Range" %t120)
  store { i64, ptr } %t123, ptr %l77
  br label %bb25
bb25:
  %t124 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t130 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t125, i64 %t126)
  %t138 = getelementptr i8, ptr %t137, i64 %t126
  call void @olang_textcopy(ptr %t138, ptr %t127, i64 %t128)
  %t139 = getelementptr i8, ptr %t138, i64 %t128
  call void @olang_textcopy(ptr %t139, ptr %t131, i64 %t132)
  %t140 = getelementptr i8, ptr %t139, i64 %t132
  call void @olang_textcopy(ptr %t140, ptr %t134, i64 %t135)
  %t141 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t137, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  %t150 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t150, { i64, ptr } %t149)
  br label %bb26
bb26:
  %t152 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 2
  %t153 = getelementptr %"compiler/mir:Range", ptr %t152, i32 0, i32 1
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = icmp sgt i32 %t154, 0
  br i1 %t156, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l2, ptr %l82, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 2
  %t160 = load %"compiler/mir:Range", ptr %t159
  %t163 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s7, ptr %t158, %"compiler/mir:Range" %t160)
  store { i64, ptr } %t163, ptr %l85
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t164 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t166 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t164, i64 %t165)
  %t174 = getelementptr i8, ptr %t173, i64 %t165
  call void @olang_textcopy(ptr %t174, ptr %t167, i64 %t168)
  %t175 = getelementptr i8, ptr %t174, i64 %t168
  call void @olang_textcopy(ptr %t175, ptr %t170, i64 %t171)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t173, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load ptr, ptr %l82, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t185, { i64, ptr } %t184)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb31:
  %t187 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 7
  %t188 = getelementptr %"compiler/mir:Range", ptr %t187, i32 0, i32 1
  %t189 = load i32, ptr %t188, !tbaa !23
  %t191 = icmp sgt i32 %t189, 0
  br i1 %t191, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  store ptr %l2, ptr %l90, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 7
  %t195 = load %"compiler/mir:Range", ptr %t194
  %t198 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s9, ptr %t193, %"compiler/mir:Range" %t195)
  store { i64, ptr } %t198, ptr %l93
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t199 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t201 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = add i64 %t200, %t203
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t207 = add i64 %t204, %t206
  %t208 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t199, i64 %t200)
  %t209 = getelementptr i8, ptr %t208, i64 %t200
  call void @olang_textcopy(ptr %t209, ptr %t202, i64 %t203)
  %t210 = getelementptr i8, ptr %t209, i64 %t203
  call void @olang_textcopy(ptr %t210, ptr %t205, i64 %t206)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t208, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } %t212, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  %t220 = load ptr, ptr %l90, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t220, { i64, ptr } %t219)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb36:
  store i32 0, ptr %l9, !tbaa !23
  %t222 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 4
  %t223 = getelementptr %"compiler/mir:Range", ptr %t222, i32 0, i32 1
  %t224 = load i32, ptr %t223, !tbaa !23
  store i32 %t224, ptr %l10, !tbaa !23
  store i32 1, ptr %l11, !tbaa !23
  %t226 = load i32, ptr %l10, !tbaa !23
  %t227 = load i32, ptr %l9, !tbaa !23
  %t230 = icmp sgt i32 %t226, %t227
  br i1 %t230, label %bb37, label %bb38
bb37:
  %t232 = load i32, ptr %l11, !tbaa !23
  %t234 = icmp sgt i32 %t232, 0
  br i1 %t234, label %bb39, label %bb40
bb38:
  store i32 0, ptr %l100, !tbaa !23
  br label %bb42
bb39:
  %t236 = load i32, ptr %l10, !tbaa !23
  %t237 = load i32, ptr %l9, !tbaa !23
  %t240 = sub i32 %t236, %t237
  %t241 = load i32, ptr %l11, !tbaa !23
  %t244 = add i32 %t240, %t241
  %t246 = sub i32 %t244, 1
  %t247 = load i32, ptr %l11, !tbaa !23
  %t250 = sdiv i32 %t246, %t247
  store i32 %t250, ptr %l103, !tbaa !23
  br label %bb41
bb40:
  store i32 0, ptr %l103, !tbaa !23
  br label %bb41
bb41:
  %t252 = load i32, ptr %l103, !tbaa !23
  store i32 %t252, ptr %l100, !tbaa !23
  br label %bb42
bb42:
  %t253 = load i32, ptr %l100, !tbaa !23
  store i32 %t253, ptr %l12, !tbaa !23
  store i32 0, ptr %l13, !tbaa !23
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s12
  %t254 = load i32, ptr %l13, !tbaa !23
  %t255 = load i32, ptr %l12, !tbaa !23
  %t258 = icmp slt i32 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s12)
  br label %bb77
bb45:
  br label %bb46
bb46:
  %t262 = load i32, ptr %l9, !tbaa !23
  %t263 = load i32, ptr %l13, !tbaa !23
  %t264 = load i32, ptr %l11, !tbaa !23
  %t267 = mul i32 %t263, %t264
  %t270 = add i32 %t262, %t267
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/mir:dumper", ptr %t272, i32 0, i32 0
  %t275 = load ptr, ptr %t274, !tbaa !29
  %t277 = getelementptr %"compiler/mir:Fn", ptr %t275, i32 0, i32 17
  %t278 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 4
  %t279 = getelementptr %"compiler/mir:Range", ptr %t278, i32 0, i32 0
  %t280 = load i32, ptr %t279, !tbaa !23
  %t282 = sext i32 %t280 to i64
  %t285 = sext i32 %t270 to i64
  %t288 = add i64 %t282, %t285
  %t291 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t277, i64 %t288)
  store %"compiler/mir:TaskClause" %t291, ptr %l129
  br label %bb47
bb47:
  %t292 = load %"compiler/mir:TaskClause", ptr %l129
  store %"compiler/mir:TaskClause" %t292, ptr %l15
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d138, i32 0, i32 1) })
  br label %bb48
bb48:
  %t294 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 1
  %t295 = load i1, ptr %t294, !tbaa !21
  br i1 %t295, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s13
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %l2, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d139, i32 0, i32 1) })
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s13)
  br label %bb52
bb52:
  store i32 0, ptr %l16, !tbaa !23
  %t298 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 0
  %t299 = getelementptr %"compiler/mir:Range", ptr %t298, i32 0, i32 1
  %t300 = load i32, ptr %t299, !tbaa !23
  store i32 %t300, ptr %l17, !tbaa !23
  store i32 1, ptr %l18, !tbaa !23
  %t302 = load i32, ptr %l17, !tbaa !23
  %t303 = load i32, ptr %l16, !tbaa !23
  %t306 = icmp sgt i32 %t302, %t303
  br i1 %t306, label %bb53, label %bb54
bb53:
  %t308 = load i32, ptr %l18, !tbaa !23
  %t310 = icmp sgt i32 %t308, 0
  br i1 %t310, label %bb55, label %bb56
bb54:
  store i32 0, ptr %l137, !tbaa !23
  br label %bb58
bb55:
  %t312 = load i32, ptr %l17, !tbaa !23
  %t313 = load i32, ptr %l16, !tbaa !23
  %t316 = sub i32 %t312, %t313
  %t317 = load i32, ptr %l18, !tbaa !23
  %t320 = add i32 %t316, %t317
  %t322 = sub i32 %t320, 1
  %t323 = load i32, ptr %l18, !tbaa !23
  %t326 = sdiv i32 %t322, %t323
  store i32 %t326, ptr %l140, !tbaa !23
  br label %bb57
bb56:
  store i32 0, ptr %l140, !tbaa !23
  br label %bb57
bb57:
  %t328 = load i32, ptr %l140, !tbaa !23
  store i32 %t328, ptr %l137, !tbaa !23
  br label %bb58
bb58:
  %t329 = load i32, ptr %l137, !tbaa !23
  store i32 %t329, ptr %l19, !tbaa !23
  store i32 0, ptr %l20, !tbaa !23
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s15
  %t330 = load i32, ptr %l20, !tbaa !23
  %t331 = load i32, ptr %l19, !tbaa !23
  %t334 = icmp slt i32 %t330, %t331
  %t336 = xor i1 %t334, true
  br i1 %t336, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s15)
  br label %bb70
bb61:
  br label %bb62
bb62:
  %t338 = load i32, ptr %l16, !tbaa !23
  %t339 = load i32, ptr %l20, !tbaa !23
  %t340 = load i32, ptr %l18, !tbaa !23
  %t343 = mul i32 %t339, %t340
  %t346 = add i32 %t338, %t343
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/mir:dumper", ptr %t348, i32 0, i32 0
  %t351 = load ptr, ptr %t350, !tbaa !29
  %t353 = getelementptr %"compiler/mir:Fn", ptr %t351, i32 0, i32 18
  %t354 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 0
  %t355 = getelementptr %"compiler/mir:Range", ptr %t354, i32 0, i32 0
  %t356 = load i32, ptr %t355, !tbaa !23
  %t358 = sext i32 %t356 to i64
  %t361 = sext i32 %t346 to i64
  %t364 = add i64 %t358, %t361
  %t367 = call %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t353, i64 %t364)
  store %"compiler/typed:Item" %t367, ptr %l166
  br label %bb63
bb63:
  %t368 = load %"compiler/typed:Item", ptr %l166
  store %"compiler/typed:Item" %t368, ptr %l22
  store ptr %l2, ptr %l167, !tbaa !29
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/mir:dumper", ptr %t369, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !29
  %t373 = getelementptr %"compiler/typed:Item", ptr %l22, i32 0, i32 0
  %t374 = load i32, ptr %t373, !tbaa !23
  %t377 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s15, ptr %t372, i32 %t374)
  store { i64, ptr } %t377, ptr %l171
  br label %bb64
bb64:
  %t378 = getelementptr %"compiler/typed:Item", ptr %l22, i32 0, i32 1
  %t379 = load i64, ptr %t378, !tbaa !24
  %t381 = icmp slt i64 %t379, 0
  br i1 %t381, label %bb65, label %bb66
bb65:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d140, i32 0, i32 1) }, ptr %l174, !tbaa !27
  br label %bb67
bb66:
  %t383 = getelementptr %"compiler/typed:Item", ptr %l22, i32 0, i32 1
  %t384 = load i64, ptr %t383, !tbaa !24
  %t385 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t386 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t388 = call i64 @__olang_fmt_i64(ptr null, i64 %t384)
  %t389 = add i64 %t386, %t388
  %t390 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t389)
  call void @olang_textcopy(ptr %t390, ptr %t385, i64 %t386)
  %t391 = getelementptr i8, ptr %t390, i64 %t386
  %t392 = call i64 @__olang_fmt_i64(ptr %t391, i64 %t384)
  %t393 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t390, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = extractvalue { i64, ptr } %t394, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  store { i64, ptr } %t401, ptr %l174, !tbaa !27
  br label %bb67
bb67:
  %t403 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t405 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t406 = extractvalue { i64, ptr } %t405, 1
  %t407 = extractvalue { i64, ptr } %t405, 0
  %t408 = add i64 %t404, %t407
  %t409 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t409, 1
  %t411 = extractvalue { i64, ptr } %t409, 0
  %t412 = add i64 %t408, %t411
  %t413 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t412)
  call void @olang_textcopy(ptr %t413, ptr %t403, i64 %t404)
  %t414 = getelementptr i8, ptr %t413, i64 %t404
  call void @olang_textcopy(ptr %t414, ptr %t406, i64 %t407)
  %t415 = getelementptr i8, ptr %t414, i64 %t407
  call void @olang_textcopy(ptr %t415, ptr %t410, i64 %t411)
  %t416 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t413, 1
  %t419 = extractvalue { i64, ptr } %t417, 0
  %t420 = extractvalue { i64, ptr } %t417, 1
  %t421 = mul i64 %t419, 1
  %t422 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t421)
  call void @llvm.memcpy.p0.p0.i64(ptr %t422, ptr %t420, i64 %t421, i1 false)
  %t423 = insertvalue { i64, ptr } undef, i64 %t419, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t422, 1
  %t425 = load ptr, ptr %l167, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %t425, { i64, ptr } %t424)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s15)
  br label %bb69
bb69:
  %t427 = load i32, ptr %l20, !tbaa !23
  %t429 = add i32 %t427, 1
  store i32 %t429, ptr %l20, !tbaa !23
  br label %bb59
bb70:
  %t431 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 2
  %t432 = load { i64, [4 x i64] }, ptr %t431
  %t434 = extractvalue { i64, [4 x i64] } %t432, 0
  %t435 = icmp eq i64 %t434, 0
  %t437 = xor i1 %t435, true
  br i1 %t437, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s19
  store ptr %l2, ptr %l185, !tbaa !29
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 2
  %t441 = load { i64, [4 x i64] }, ptr %t440
  %t444 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s19, ptr %t439, { i64, [4 x i64] } %t441)
  store { i64, ptr } %t444, ptr %l188
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t445 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t447 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t447, 1
  %t449 = extractvalue { i64, ptr } %t447, 0
  %t450 = add i64 %t446, %t449
  %t451 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t450)
  call void @olang_textcopy(ptr %t451, ptr %t445, i64 %t446)
  %t452 = getelementptr i8, ptr %t451, i64 %t446
  call void @olang_textcopy(ptr %t452, ptr %t448, i64 %t449)
  %t453 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t451, 1
  %t456 = extractvalue { i64, ptr } %t454, 0
  %t457 = extractvalue { i64, ptr } %t454, 1
  %t458 = mul i64 %t456, 1
  %t459 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t458)
  call void @llvm.memcpy.p0.p0.i64(ptr %t459, ptr %t457, i64 %t458, i1 false)
  %t460 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t459, 1
  %t462 = load ptr, ptr %l185, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s19, ptr %t462, { i64, ptr } %t461)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s19)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s12)
  br label %bb76
bb76:
  %t464 = load i32, ptr %l13, !tbaa !23
  %t466 = add i32 %t464, 1
  store i32 %t466, ptr %l13, !tbaa !23
  br label %bb43
bb77:
  %t469 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t469, ptr %l194
  br label %bb78
bb78:
  %t470 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t470, ptr %l195, !tbaa !27
  %t471 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t471, 0
  store i64 %t472, ptr %l196, !tbaa !24
  %t473 = load i64, ptr %l196, !tbaa !24
  %t474 = mul i64 %t473, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t474)
  %t476 = insertvalue { i64, ptr } undef, i64 %t473, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  store { i64, ptr } %t477, ptr %l197, !tbaa !27
  %t478 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !27
  %t480 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = load i64, ptr %l196, !tbaa !24
  %t483 = mul i64 %t482, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t479, ptr %t481, i64 %t483, i1 false)
  %t484 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t484, ptr %l195, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t485 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t485, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2evarKind(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l15 = alloca { i64, [1 x i64] }
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %t10)
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t11, i64 %t12)
  %t17 = getelementptr i8, ptr %t16, i64 %t12
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %t10)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t16, 1
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb15
bb4:
  %t22 = load { i64, [1 x i64] }, ptr %l1
  %t24 = extractvalue { i64, [1 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 4
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = getelementptr i8, ptr %t37, i64 %t33
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t31)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  store { i64, ptr } %t41, ptr %l4, !tbaa !27
  br label %bb15
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb14
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t43 = load { i64, [1 x i64] }, ptr %l1
  store { i64, [1 x i64] } %t43, ptr %l15
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aVarKind(ptr %s6, ptr %l15, i64 0)
  br label %bb12
bb12:
  %t45 = load ptr, ptr %s6
  %t46 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t47 = load i64, ptr %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t45, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l17, !tbaa !27
  %t51 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t52 = load ptr, ptr %t51
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %sbgrew.54, label %sbdone.55
sbgrew.54:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.55
sbdone.55:
  %t56 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  %t58 = extractvalue { i64, ptr } %t56, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t64 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s5, { i64, ptr } %t62)
  store { i64, ptr } %t64, ptr %l19
  br label %bb13
bb13:
  %t65 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6326b544498e75fa_e53a2c99f88826ee)
  unreachable
bb15:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l10 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 11
  %t7 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t14 = add i64 %t10, %a2
  %t17 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t6, i64 %t14)
  store { i64, [4 x i64] } %t17, ptr %l10
  br label %bb1
bb1:
  %t18 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t18, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/mir:verifier", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l10
  br label %bb2
bb2:
  %t18 = load i32, ptr %l10
  %t20 = trunc i64 19 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i32, ptr %l2, !tbaa !23
  store i32 %t23, ptr %l13, !tbaa !23
  br label %bb5
bb4:
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t25, ptr %l13, !tbaa !23
  br label %bb5
bb5:
  %t27 = load i32, ptr %l13, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l9 = alloca i1
  %l20 = alloca %"compiler/mir:ScopeInfo"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l9
  br label %bb4
bb4:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t23 = sext i32 %t19 to i64
  %t24 = call i64 @__olang_fmt_i64(ptr null, i64 %t23)
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t23)
  %t32 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t32, ptr %t26, i64 %t27)
  %t33 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t29, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t18, { i64, ptr } %t41)
  br label %bb7
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/mir:verifier", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/mir:Fn", ptr %t47, i32 0, i32 8
  %t50 = load i32, ptr %l2, !tbaa !23
  %t52 = sext i32 %t50 to i64
  %t55 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t49, i64 %t52)
  store %"compiler/mir:ScopeInfo" %t55, ptr %l20
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb8:
  %t56 = getelementptr %"compiler/mir:ScopeInfo", ptr %l20, i32 0, i32 0
  %t57 = load i32, ptr %t56
  %t59 = trunc i64 5 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t64 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t67 = sext i32 %t63 to i64
  %t68 = call i64 @__olang_fmt_i64(ptr null, i64 %t67)
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t64, i64 %t65)
  %t74 = getelementptr i8, ptr %t73, i64 %t65
  %t75 = call i64 @__olang_fmt_i64(ptr %t74, i64 %t67)
  %t76 = getelementptr i8, ptr %t74, i64 %t68
  call void @olang_textcopy(ptr %t76, ptr %t70, i64 %t71)
  %t77 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t73, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = extractvalue { i64, ptr } %t78, 1
  %t82 = mul i64 %t80, 1
  %t83 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t82)
  call void @llvm.memcpy.p0.p0.i64(ptr %t83, ptr %t81, i64 %t82, i1 false)
  %t84 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t62, { i64, ptr } %t85)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb24
bb14:
  %t88 = load { i64, [1 x i64] }, ptr %l1
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 4
  br i1 %t91, label %bb15, label %bb16
bb15:
  %t93 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l3, !tbaa !23
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t97, i32 %t98)
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a15aa4830130cc38_9fcdb454ad4b970c)
  unreachable
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %a0, { i64, [4 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_43daeee16a7347fc_3936ff71893c42a0)
  unreachable
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca i32
  %l20 = alloca i32
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l53 = alloca i32
  %l57 = alloca ptr
  %l60 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 1
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb5
bb2:
  %t10 = load { i64, [7 x i64] }, ptr %l1
  %t12 = extractvalue { i64, [7 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { i64, i32 }, ptr %t15, i32 0, i32 1
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = load i32, ptr %l2, !tbaa !23
  store i32 %t19, ptr %l7, !tbaa !23
  br label %bb16
bb6:
  %t21 = load { i64, [7 x i64] }, ptr %l1
  %t23 = extractvalue { i64, [7 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 2
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t27 = getelementptr { { i64, [4 x i64] } }, ptr %t26, i32 0, i32 0
  %t28 = load { i64, [4 x i64] }, ptr %t27
  store { i64, [4 x i64] } %t28, ptr %l3
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, [4 x i64] }, ptr %l3
  %t34 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t30, { i64, [4 x i64] } %t31)
  store i32 %t34, ptr %l20
  br label %bb10
bb10:
  %t35 = load i32, ptr %l20, !tbaa !23
  store i32 %t35, ptr %l7, !tbaa !23
  br label %bb16
bb11:
  %t36 = load { i64, [7 x i64] }, ptr %l1
  %t38 = extractvalue { i64, [7 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 3
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t42 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t41, i32 0, i32 2
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l4, !tbaa !23
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t45 = load i32, ptr %l4, !tbaa !23
  store i32 %t45, ptr %l7, !tbaa !23
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_690174ade0b6e824_1aa5c898f3f73ab8)
  unreachable
bb16:
  %t47 = load i32, ptr %l7, !tbaa !23
  store i32 %t47, ptr %l5, !tbaa !23
  %t48 = load { i64, [7 x i64] }, ptr %l1
  %t50 = extractvalue { i64, [7 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 3
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t53 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t54 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load { i64, [4 x i64] }, ptr %t54
  store { i64, [4 x i64] } %t55, ptr %l6
  br label %bb19
bb18:
  br label %bb29
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:verifier", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l29, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/mir:verifier", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  store ptr %t64, ptr %l31, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, [4 x i64] }, ptr %l6
  %t69 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t65, { i64, [4 x i64] } %t66)
  store i32 %t69, ptr %l34
  br label %bb20
bb20:
  %t70 = load ptr, ptr %l31, !tbaa !29
  %t71 = load i32, ptr %l34, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l35
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l29, !tbaa !29
  %t74 = load i32, ptr %l35, !tbaa !23
  %t75 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t73, i32 %t74)
  store i1 %t75, ptr %l36
  br label %bb22
bb22:
  %t76 = load i1, ptr %l36, !tbaa !21
  %t77 = xor i1 %t76, true
  br i1 %t77, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l38, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l39, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load { i64, [4 x i64] }, ptr %l6
  %t85 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t81, { i64, [4 x i64] } %t82)
  store i32 %t85, ptr %l42
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t86 = load ptr, ptr %l39, !tbaa !29
  %t87 = load i32, ptr %l42, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t86, i32 %t87)
  store { i64, ptr } %t88, ptr %l43
  br label %bb26
bb26:
  %t89 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t91 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = add i64 %t90, %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t89, i64 %t90)
  %t96 = getelementptr i8, ptr %t95, i64 %t90
  call void @olang_textcopy(ptr %t96, ptr %t92, i64 %t93)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t101 = extractvalue { i64, ptr } %t98, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  %t106 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t106, { i64, ptr } %t105)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_b20acbf668615715_202a9ab5dba06089)
  unreachable
bb34:
  %t108 = load i32, ptr %l5, !tbaa !23
  %t109 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t112 = icmp eq i32 %t108, %t109
  br i1 %t112, label %bb35, label %bb36
bb35:
  %t114 = load i32, ptr %l5, !tbaa !23
  store i32 %t114, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/mir:verifier", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load i32, ptr %l5, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t119, i32 %t120)
  store i32 %t123, ptr %l53
  br label %bb38
bb38:
  %t124 = load i32, ptr %l53
  %t126 = trunc i64 21 to i32
  %t127 = icmp eq i32 %t124, %t126
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s9
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l57, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l5, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s9, ptr %t132, i32 %t133)
  store { i64, ptr } %t136, ptr %l60
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t137 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t139 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t137, i64 %t138)
  %t147 = getelementptr i8, ptr %t146, i64 %t138
  call void @olang_textcopy(ptr %t147, ptr %t140, i64 %t141)
  %t148 = getelementptr i8, ptr %t147, i64 %t141
  call void @olang_textcopy(ptr %t148, ptr %t143, i64 %t144)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t146, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = extractvalue { i64, ptr } %t150, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t158 = load ptr, ptr %l57, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s9, ptr %t158, { i64, ptr } %t157)
  br label %bb42
bb42:
  %t160 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  store i32 %t160, ptr %rv
  br label %ret
bb43:
  %t162 = load i32, ptr %l5, !tbaa !23
  store i32 %t162, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l16 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i32
  %rv = alloca { i32, i1 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 24 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l16
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t27 = load i32, ptr %l16, !tbaa !23
  %t28 = insertvalue { i32, i1 } undef, i32 %t27, 0
  %t29 = insertvalue { i32, i1 } %t28, i1 true, 1
  store { i32, i1 } %t29, ptr %rv
  br label %ret
bb6:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l20
  br label %bb7
bb7:
  %t36 = load i32, ptr %l20
  %t38 = trunc i64 18 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l2, !tbaa !29
  store ptr %t41, ptr %l24, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb12
bb10:
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t48 = load i32, ptr %l27, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t49, ptr %l28
  br label %bb11
bb11:
  %t50 = load i32, ptr %l28
  %t52 = trunc i64 1 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t55 = load i1, ptr %l23, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t57 = load i32, ptr %l3, !tbaa !23
  %t60 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb16
bb15:
  %t61 = load i1, ptr %l34, !tbaa !21
  store i1 %t61, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t62 = load i1, ptr %l31, !tbaa !21
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t64 = load i32, ptr %l3, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l37
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t68 = load i32, ptr %l37, !tbaa !23
  %t69 = insertvalue { i32, i1 } undef, i32 %t68, 0
  %t70 = insertvalue { i32, i1 } %t69, i1 true, 1
  store { i32, i1 } %t70, ptr %rv
  br label %ret
bb20:
  %t72 = insertvalue { i32, i1 } undef, i32 0, 0
  %t73 = insertvalue { i32, i1 } %t72, i1 false, 1
  store { i32, i1 } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l51 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l63 = alloca i64
  %l66 = alloca i64
  %l85 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l112 = alloca i64
  %l115 = alloca i64
  %l134 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l148 = alloca i64
  %l151 = alloca i64
  %l153 = alloca { i64, ptr }
  %l154 = alloca i64
  %l157 = alloca i64
  %l160 = alloca i64
  %l162 = alloca i64
  %l167 = alloca i32
  %l177 = alloca i64
  %l180 = alloca i64
  %l199 = alloca { i64, ptr }
  %l206 = alloca i1
  %l208 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l228 = alloca i1
  %l230 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l248 = alloca i64
  %l251 = alloca i64
  %l270 = alloca { i64, ptr }
  %l273 = alloca i1
  %l275 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l294 = alloca { i64, ptr }
  %l296 = alloca i64
  %l299 = alloca i64
  %l304 = alloca i64
  %l308 = alloca i64
  %l311 = alloca i64
  %l330 = alloca i1
  %l334 = alloca { i64, ptr }
  %l339 = alloca i32
  %l343 = alloca i32
  %l349 = alloca ptr
  %l350 = alloca i32
  %l352 = alloca { i64, ptr }
  %l355 = alloca { i64, ptr }
  %s24 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 7
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l44
  br label %bb1
bb1:
  %t11 = load i64, ptr %l44, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 8
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l47
  br label %bb2
bb2:
  %t17 = load i64, ptr %l47, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = load i32, ptr %l1, !tbaa !23
  %t20 = sext i32 %t18 to i64
  store i64 %t20, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/mir:verifier", ptr %t22, i32 0, i32 6
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l51, !tbaa !27
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i1, ptr %t29, i64 %t26
  %t31 = load i1, ptr %t30, !tbaa !31
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/mir:verifier", ptr %t35, i32 0, i32 6
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l56, !tbaa !27
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i1, ptr %t42, i64 %t39
  store i1 true, ptr %t43, !tbaa !31
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/mir:verifier", ptr %t44, i32 0, i32 18
  store i1 true, ptr %t46, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  store i64 %t47, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = icmp sgt i64 %t49, %t50
  br i1 %t53, label %bb5, label %bb6
bb4:
  br label %bb40
bb5:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb10
bb7:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = sub i64 %t59, %t60
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = add i64 %t63, %t64
  %t69 = sub i64 %t67, 1
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = sdiv i64 %t69, %t70
  store i64 %t73, ptr %l66, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb9
bb9:
  %t75 = load i64, ptr %l66, !tbaa !24
  store i64 %t75, ptr %l63, !tbaa !24
  br label %bb10
bb10:
  %t76 = load i64, ptr %l63, !tbaa !24
  store i64 %t76, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t85 = load i64, ptr %l6, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = mul i64 %t86, %t87
  %t93 = add i64 %t85, %t90
  store i64 %t93, ptr %l11, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/mir:verifier", ptr %t95, i32 0, i32 7
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l85, !tbaa !27
  %t99 = load i64, ptr %l5, !tbaa !24
  %t100 = load i64, ptr %l3, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t104 = load i64, ptr %l11, !tbaa !24
  %t107 = add i64 %t103, %t104
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/mir:verifier", ptr %t108, i32 0, i32 14
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l92, !tbaa !27
  %t112 = load i64, ptr %l11, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i1, ptr %t115, i64 %t112
  %t117 = load i1, ptr %t116, !tbaa !31
  %t120 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i1, ptr %t121, i64 %t107
  store i1 %t117, ptr %t122, !tbaa !31
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/mir:verifier", ptr %t123, i32 0, i32 8
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l96, !tbaa !27
  %t127 = load i64, ptr %l5, !tbaa !24
  %t128 = load i64, ptr %l3, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = add i64 %t131, %t132
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/mir:verifier", ptr %t136, i32 0, i32 15
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l103, !tbaa !27
  %t140 = load i64, ptr %l11, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i1, ptr %t143, i64 %t140
  %t145 = load i1, ptr %t144, !tbaa !31
  %t148 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i1, ptr %t149, i64 %t135
  store i1 %t145, ptr %t150, !tbaa !31
  br label %bb15
bb15:
  %t151 = load i64, ptr %l10, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l10, !tbaa !24
  br label %bb11
bb16:
  store i64 0, ptr %l12, !tbaa !24
  %t155 = load i64, ptr %l4, !tbaa !24
  store i64 %t155, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t157 = load i64, ptr %l13, !tbaa !24
  %t158 = load i64, ptr %l12, !tbaa !24
  %t161 = icmp sgt i64 %t157, %t158
  br i1 %t161, label %bb17, label %bb18
bb17:
  %t163 = load i64, ptr %l14, !tbaa !24
  %t165 = icmp sgt i64 %t163, 0
  br i1 %t165, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb22
bb19:
  %t167 = load i64, ptr %l13, !tbaa !24
  %t168 = load i64, ptr %l12, !tbaa !24
  %t171 = sub i64 %t167, %t168
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = add i64 %t171, %t172
  %t177 = sub i64 %t175, 1
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = sdiv i64 %t177, %t178
  store i64 %t181, ptr %l115, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb21
bb21:
  %t183 = load i64, ptr %l115, !tbaa !24
  store i64 %t183, ptr %l112, !tbaa !24
  br label %bb22
bb22:
  %t184 = load i64, ptr %l112, !tbaa !24
  store i64 %t184, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb23
bb23:
  %t185 = load i64, ptr %l16, !tbaa !24
  %t186 = load i64, ptr %l15, !tbaa !24
  %t189 = icmp slt i64 %t185, %t186
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t193 = load i64, ptr %l12, !tbaa !24
  %t194 = load i64, ptr %l16, !tbaa !24
  %t195 = load i64, ptr %l14, !tbaa !24
  %t198 = mul i64 %t194, %t195
  %t201 = add i64 %t193, %t198
  store i64 %t201, ptr %l17, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/mir:verifier", ptr %t203, i32 0, i32 9
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  store { i64, ptr } %t206, ptr %l134, !tbaa !27
  %t207 = load i64, ptr %l5, !tbaa !24
  %t208 = load i64, ptr %l4, !tbaa !24
  %t211 = mul i64 %t207, %t208
  %t212 = load i64, ptr %l17, !tbaa !24
  %t215 = add i64 %t211, %t212
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/mir:verifier", ptr %t216, i32 0, i32 16
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  store { i64, ptr } %t219, ptr %l141, !tbaa !27
  %t220 = load i64, ptr %l17, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i1, ptr %t223, i64 %t220
  %t225 = load i1, ptr %t224, !tbaa !31
  %t228 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i1, ptr %t229, i64 %t215
  store i1 %t225, ptr %t230, !tbaa !31
  br label %bb27
bb27:
  %t231 = load i64, ptr %l16, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l16, !tbaa !24
  br label %bb23
bb28:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/mir:verifier", ptr %t235, i32 0, i32 10
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  store { i64, ptr } %t238, ptr %l147, !tbaa !27
  %t239 = load i64, ptr %l5, !tbaa !24
  store i64 %t239, ptr %l148, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/mir:verifier", ptr %t240, i32 0, i32 12
  %t244 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t242)
  store i64 %t244, ptr %l151
  br label %bb29
bb29:
  %t245 = load i64, ptr %l151, !tbaa !24
  %t246 = load i64, ptr %l148, !tbaa !24
  %t247 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = getelementptr i64, ptr %t248, i64 %t246
  store i64 %t245, ptr %t249, !tbaa !34
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/mir:verifier", ptr %t250, i32 0, i32 11
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  store { i64, ptr } %t253, ptr %l153, !tbaa !27
  %t254 = load i64, ptr %l5, !tbaa !24
  store i64 %t254, ptr %l154, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/mir:verifier", ptr %t255, i32 0, i32 17
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t257)
  store i64 %t259, ptr %l157
  br label %bb30
bb30:
  %t260 = load i64, ptr %l157, !tbaa !24
  %t261 = load i64, ptr %l154, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i64, ptr %t263, i64 %t261
  store i64 %t260, ptr %t264, !tbaa !34
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/mir:verifier", ptr %t265, i32 0, i32 17
  store ptr %t267, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb31
bb31:
  %t269 = load i64, ptr %l19, !tbaa !24
  store i64 %t269, ptr %l160, !tbaa !24
  %t270 = load ptr, ptr %l18, !tbaa !29
  %t272 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t270)
  store i64 %t272, ptr %l162
  br label %bb32
bb32:
  %t273 = load i64, ptr %l160, !tbaa !24
  %t274 = load i64, ptr %l162, !tbaa !24
  %t275 = icmp slt i64 %t273, %t274
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb33, label %bb34
bb33:
  br label %bb39
bb34:
  br label %bb35
bb35:
  %t279 = load ptr, ptr %l18, !tbaa !29
  %t280 = load i64, ptr %l19, !tbaa !24
  %t283 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t279, i64 %t280)
  store i32 %t283, ptr %l167
  br label %bb36
bb36:
  %t284 = load i32, ptr %l167, !tbaa !23
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/mir:verifier", ptr %t285, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t287, i32 %t284)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t291 = load i64, ptr %l19, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l19, !tbaa !24
  br label %bb31
bb39:
  br label %ret
bb40:
  store i64 0, ptr %l21, !tbaa !24
  %t295 = load i64, ptr %l3, !tbaa !24
  store i64 %t295, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t297 = load i64, ptr %l22, !tbaa !24
  %t298 = load i64, ptr %l21, !tbaa !24
  %t301 = icmp sgt i64 %t297, %t298
  br i1 %t301, label %bb41, label %bb42
bb41:
  %t303 = load i64, ptr %l23, !tbaa !24
  %t305 = icmp sgt i64 %t303, 0
  br i1 %t305, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l177, !tbaa !24
  br label %bb46
bb43:
  %t307 = load i64, ptr %l22, !tbaa !24
  %t308 = load i64, ptr %l21, !tbaa !24
  %t311 = sub i64 %t307, %t308
  %t312 = load i64, ptr %l23, !tbaa !24
  %t315 = add i64 %t311, %t312
  %t317 = sub i64 %t315, 1
  %t318 = load i64, ptr %l23, !tbaa !24
  %t321 = sdiv i64 %t317, %t318
  store i64 %t321, ptr %l180, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb45
bb45:
  %t323 = load i64, ptr %l180, !tbaa !24
  store i64 %t323, ptr %l177, !tbaa !24
  br label %bb46
bb46:
  %t324 = load i64, ptr %l177, !tbaa !24
  store i64 %t324, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb47
bb47:
  %t325 = load i64, ptr %l25, !tbaa !24
  %t326 = load i64, ptr %l24, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb48, label %bb49
bb48:
  br label %bb64
bb49:
  br label %bb50
bb50:
  %t333 = load i64, ptr %l21, !tbaa !24
  %t334 = load i64, ptr %l25, !tbaa !24
  %t335 = load i64, ptr %l23, !tbaa !24
  %t338 = mul i64 %t334, %t335
  %t341 = add i64 %t333, %t338
  store i64 %t341, ptr %l26, !tbaa !24
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/mir:verifier", ptr %t343, i32 0, i32 7
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !27
  store { i64, ptr } %t346, ptr %l199, !tbaa !27
  %t347 = load i64, ptr %l5, !tbaa !24
  %t348 = load i64, ptr %l3, !tbaa !24
  %t351 = mul i64 %t347, %t348
  %t352 = load i64, ptr %l26, !tbaa !24
  %t355 = add i64 %t351, %t352
  %t357 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = getelementptr i1, ptr %t358, i64 %t355
  %t360 = load i1, ptr %t359, !tbaa !31
  br i1 %t360, label %bb51, label %bb52
bb51:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/mir:verifier", ptr %t362, i32 0, i32 14
  %t365 = load { i64, ptr }, ptr %t364, !tbaa !27
  store { i64, ptr } %t365, ptr %l208, !tbaa !27
  %t366 = load i64, ptr %l26, !tbaa !24
  %t368 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr i1, ptr %t369, i64 %t366
  %t371 = load i1, ptr %t370, !tbaa !31
  %t373 = xor i1 %t371, true
  store i1 %t373, ptr %l206, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb53
bb53:
  %t375 = load i1, ptr %l206, !tbaa !21
  br i1 %t375, label %bb54, label %bb55
bb54:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/mir:verifier", ptr %t376, i32 0, i32 7
  %t379 = load { i64, ptr }, ptr %t378, !tbaa !27
  store { i64, ptr } %t379, ptr %l213, !tbaa !27
  %t380 = load i64, ptr %l5, !tbaa !24
  %t381 = load i64, ptr %l3, !tbaa !24
  %t384 = mul i64 %t380, %t381
  %t385 = load i64, ptr %l26, !tbaa !24
  %t388 = add i64 %t384, %t385
  %t390 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr i1, ptr %t391, i64 %t388
  store i1 false, ptr %t392, !tbaa !31
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t395 = getelementptr %"compiler/mir:verifier", ptr %t393, i32 0, i32 18
  store i1 true, ptr %t395, !tbaa !21
  br label %bb56
bb55:
  br label %bb56
bb56:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/mir:verifier", ptr %t396, i32 0, i32 8
  %t399 = load { i64, ptr }, ptr %t398, !tbaa !27
  store { i64, ptr } %t399, ptr %l221, !tbaa !27
  %t400 = load i64, ptr %l5, !tbaa !24
  %t401 = load i64, ptr %l3, !tbaa !24
  %t404 = mul i64 %t400, %t401
  %t405 = load i64, ptr %l26, !tbaa !24
  %t408 = add i64 %t404, %t405
  %t410 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !27
  %t412 = getelementptr i1, ptr %t411, i64 %t408
  %t413 = load i1, ptr %t412, !tbaa !31
  br i1 %t413, label %bb57, label %bb58
bb57:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/mir:verifier", ptr %t415, i32 0, i32 15
  %t418 = load { i64, ptr }, ptr %t417, !tbaa !27
  store { i64, ptr } %t418, ptr %l230, !tbaa !27
  %t419 = load i64, ptr %l26, !tbaa !24
  %t421 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr i1, ptr %t422, i64 %t419
  %t424 = load i1, ptr %t423, !tbaa !31
  %t426 = xor i1 %t424, true
  store i1 %t426, ptr %l228, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb59
bb59:
  %t428 = load i1, ptr %l228, !tbaa !21
  br i1 %t428, label %bb60, label %bb61
bb60:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/mir:verifier", ptr %t429, i32 0, i32 8
  %t432 = load { i64, ptr }, ptr %t431, !tbaa !27
  store { i64, ptr } %t432, ptr %l235, !tbaa !27
  %t433 = load i64, ptr %l5, !tbaa !24
  %t434 = load i64, ptr %l3, !tbaa !24
  %t437 = mul i64 %t433, %t434
  %t438 = load i64, ptr %l26, !tbaa !24
  %t441 = add i64 %t437, %t438
  %t443 = getelementptr { i64, ptr }, ptr %l235, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr i1, ptr %t444, i64 %t441
  store i1 false, ptr %t445, !tbaa !31
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/mir:verifier", ptr %t446, i32 0, i32 18
  store i1 true, ptr %t448, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t449 = load i64, ptr %l25, !tbaa !24
  %t451 = add i64 %t449, 1
  store i64 %t451, ptr %l25, !tbaa !24
  br label %bb47
bb64:
  store i64 0, ptr %l27, !tbaa !24
  %t453 = load i64, ptr %l4, !tbaa !24
  store i64 %t453, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t455 = load i64, ptr %l28, !tbaa !24
  %t456 = load i64, ptr %l27, !tbaa !24
  %t459 = icmp sgt i64 %t455, %t456
  br i1 %t459, label %bb65, label %bb66
bb65:
  %t461 = load i64, ptr %l29, !tbaa !24
  %t463 = icmp sgt i64 %t461, 0
  br i1 %t463, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l248, !tbaa !24
  br label %bb70
bb67:
  %t465 = load i64, ptr %l28, !tbaa !24
  %t466 = load i64, ptr %l27, !tbaa !24
  %t469 = sub i64 %t465, %t466
  %t470 = load i64, ptr %l29, !tbaa !24
  %t473 = add i64 %t469, %t470
  %t475 = sub i64 %t473, 1
  %t476 = load i64, ptr %l29, !tbaa !24
  %t479 = sdiv i64 %t475, %t476
  store i64 %t479, ptr %l251, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l251, !tbaa !24
  br label %bb69
bb69:
  %t481 = load i64, ptr %l251, !tbaa !24
  store i64 %t481, ptr %l248, !tbaa !24
  br label %bb70
bb70:
  %t482 = load i64, ptr %l248, !tbaa !24
  store i64 %t482, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb71
bb71:
  %t483 = load i64, ptr %l31, !tbaa !24
  %t484 = load i64, ptr %l30, !tbaa !24
  %t487 = icmp slt i64 %t483, %t484
  %t489 = xor i1 %t487, true
  br i1 %t489, label %bb72, label %bb73
bb72:
  br label %bb82
bb73:
  br label %bb74
bb74:
  %t491 = load i64, ptr %l27, !tbaa !24
  %t492 = load i64, ptr %l31, !tbaa !24
  %t493 = load i64, ptr %l29, !tbaa !24
  %t496 = mul i64 %t492, %t493
  %t499 = add i64 %t491, %t496
  store i64 %t499, ptr %l32, !tbaa !24
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = getelementptr %"compiler/mir:verifier", ptr %t501, i32 0, i32 16
  %t504 = load { i64, ptr }, ptr %t503, !tbaa !27
  store { i64, ptr } %t504, ptr %l270, !tbaa !27
  %t505 = load i64, ptr %l32, !tbaa !24
  %t507 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !27
  %t509 = getelementptr i1, ptr %t508, i64 %t505
  %t510 = load i1, ptr %t509, !tbaa !31
  br i1 %t510, label %bb75, label %bb76
bb75:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr %"compiler/mir:verifier", ptr %t512, i32 0, i32 9
  %t515 = load { i64, ptr }, ptr %t514, !tbaa !27
  store { i64, ptr } %t515, ptr %l275, !tbaa !27
  %t516 = load i64, ptr %l5, !tbaa !24
  %t517 = load i64, ptr %l4, !tbaa !24
  %t520 = mul i64 %t516, %t517
  %t521 = load i64, ptr %l32, !tbaa !24
  %t524 = add i64 %t520, %t521
  %t526 = getelementptr { i64, ptr }, ptr %l275, i32 0, i32 1
  %t527 = load ptr, ptr %t526, !tbaa !27
  %t528 = getelementptr i1, ptr %t527, i64 %t524
  %t529 = load i1, ptr %t528, !tbaa !31
  %t531 = xor i1 %t529, true
  store i1 %t531, ptr %l273, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb77
bb77:
  %t533 = load i1, ptr %l273, !tbaa !21
  br i1 %t533, label %bb78, label %bb79
bb78:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t536 = getelementptr %"compiler/mir:verifier", ptr %t534, i32 0, i32 9
  %t537 = load { i64, ptr }, ptr %t536, !tbaa !27
  store { i64, ptr } %t537, ptr %l284, !tbaa !27
  %t538 = load i64, ptr %l5, !tbaa !24
  %t539 = load i64, ptr %l4, !tbaa !24
  %t542 = mul i64 %t538, %t539
  %t543 = load i64, ptr %l32, !tbaa !24
  %t546 = add i64 %t542, %t543
  %t548 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = getelementptr i1, ptr %t549, i64 %t546
  store i1 true, ptr %t550, !tbaa !31
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t553 = getelementptr %"compiler/mir:verifier", ptr %t551, i32 0, i32 18
  store i1 true, ptr %t553, !tbaa !21
  br label %bb80
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t554 = load i64, ptr %l31, !tbaa !24
  %t556 = add i64 %t554, 1
  store i64 %t556, ptr %l31, !tbaa !24
  br label %bb71
bb82:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t560 = getelementptr %"compiler/mir:verifier", ptr %t558, i32 0, i32 11
  %t561 = load { i64, ptr }, ptr %t560, !tbaa !27
  store { i64, ptr } %t561, ptr %l294, !tbaa !27
  %t562 = load i64, ptr %l5, !tbaa !24
  %t564 = getelementptr { i64, ptr }, ptr %l294, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !27
  %t566 = getelementptr i64, ptr %t565, i64 %t562
  %t567 = load i64, ptr %t566, !tbaa !34
  store i64 %t567, ptr %l296, !tbaa !24
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = getelementptr %"compiler/mir:verifier", ptr %t568, i32 0, i32 17
  %t572 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t570)
  store i64 %t572, ptr %l299
  br label %bb83
bb83:
  %t573 = load i64, ptr %l296, !tbaa !24
  %t574 = load i64, ptr %l299, !tbaa !24
  %t575 = icmp eq i64 %t573, %t574
  store i1 %t575, ptr %l33, !tbaa !21
  %t577 = load i1, ptr %l33, !tbaa !21
  br i1 %t577, label %bb84, label %bb85
bb84:
  store i64 0, ptr %l34, !tbaa !24
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t581 = getelementptr %"compiler/mir:verifier", ptr %t579, i32 0, i32 17
  %t583 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t581)
  store i64 %t583, ptr %l304
  br label %bb86
bb85:
  br label %bb104
bb86:
  %t584 = load i64, ptr %l304, !tbaa !24
  store i64 %t584, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t585 = load i64, ptr %l35, !tbaa !24
  %t586 = load i64, ptr %l34, !tbaa !24
  %t589 = icmp sgt i64 %t585, %t586
  br i1 %t589, label %bb87, label %bb88
bb87:
  %t591 = load i64, ptr %l36, !tbaa !24
  %t593 = icmp sgt i64 %t591, 0
  br i1 %t593, label %bb89, label %bb90
bb88:
  store i64 0, ptr %l308, !tbaa !24
  br label %bb92
bb89:
  %t595 = load i64, ptr %l35, !tbaa !24
  %t596 = load i64, ptr %l34, !tbaa !24
  %t599 = sub i64 %t595, %t596
  %t600 = load i64, ptr %l36, !tbaa !24
  %t603 = add i64 %t599, %t600
  %t605 = sub i64 %t603, 1
  %t606 = load i64, ptr %l36, !tbaa !24
  %t609 = sdiv i64 %t605, %t606
  store i64 %t609, ptr %l311, !tbaa !24
  br label %bb91
bb90:
  store i64 0, ptr %l311, !tbaa !24
  br label %bb91
bb91:
  %t611 = load i64, ptr %l311, !tbaa !24
  store i64 %t611, ptr %l308, !tbaa !24
  br label %bb92
bb92:
  %t612 = load i64, ptr %l308, !tbaa !24
  store i64 %t612, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb93
bb93:
  %t613 = load i64, ptr %l38, !tbaa !24
  %t614 = load i64, ptr %l37, !tbaa !24
  %t617 = icmp slt i64 %t613, %t614
  %t619 = xor i1 %t617, true
  br i1 %t619, label %bb94, label %bb95
bb94:
  br label %bb103
bb95:
  br label %bb96
bb96:
  %t621 = load i64, ptr %l34, !tbaa !24
  %t622 = load i64, ptr %l38, !tbaa !24
  %t623 = load i64, ptr %l36, !tbaa !24
  %t626 = mul i64 %t622, %t623
  %t629 = add i64 %t621, %t626
  store i64 %t629, ptr %l39, !tbaa !24
  %t631 = load i1, ptr %l33, !tbaa !21
  br i1 %t631, label %bb97, label %bb98
bb97:
  %t633 = load ptr, ptr %l0, !tbaa !29
  %t635 = getelementptr %"compiler/mir:verifier", ptr %t633, i32 0, i32 12
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t638 = getelementptr %"compiler/mir:verifier", ptr %t636, i32 0, i32 10
  %t639 = load { i64, ptr }, ptr %t638, !tbaa !27
  store { i64, ptr } %t639, ptr %l334, !tbaa !27
  %t640 = load i64, ptr %l5, !tbaa !24
  %t642 = getelementptr { i64, ptr }, ptr %l334, i32 0, i32 1
  %t643 = load ptr, ptr %t642, !tbaa !27
  %t644 = getelementptr i64, ptr %t643, i64 %t640
  %t645 = load i64, ptr %t644, !tbaa !34
  %t646 = load i64, ptr %l39, !tbaa !24
  %t649 = add i64 %t645, %t646
  %t652 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t635, i64 %t649)
  store i32 %t652, ptr %l339
  br label %bb99
bb98:
  store i1 false, ptr %l330, !tbaa !21
  br label %bb101
bb99:
  %t653 = load ptr, ptr %l0, !tbaa !29
  %t655 = getelementptr %"compiler/mir:verifier", ptr %t653, i32 0, i32 17
  %t656 = load i64, ptr %l39, !tbaa !24
  %t659 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t655, i64 %t656)
  store i32 %t659, ptr %l343
  br label %bb100
bb100:
  %t660 = load i32, ptr %l339, !tbaa !23
  %t661 = load i32, ptr %l343, !tbaa !23
  %t662 = icmp eq i32 %t660, %t661
  store i1 %t662, ptr %l330, !tbaa !21
  br label %bb101
bb101:
  %t664 = load i1, ptr %l330, !tbaa !21
  store i1 %t664, ptr %l33, !tbaa !21
  br label %bb102
bb102:
  %t665 = load i64, ptr %l38, !tbaa !24
  %t667 = add i64 %t665, 1
  store i64 %t667, ptr %l38, !tbaa !24
  br label %bb93
bb103:
  br label %bb104
bb104:
  %t669 = load i1, ptr %l33, !tbaa !21
  %t671 = xor i1 %t669, true
  br i1 %t671, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s24
  %t673 = load ptr, ptr %l0, !tbaa !29
  store ptr %t673, ptr %l349, !tbaa !29
  %t674 = load i32, ptr %l1, !tbaa !23
  store i32 %t674, ptr %l350, !tbaa !23
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t677 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %s24, ptr %t675)
  store { i64, ptr } %t677, ptr %l352
  br label %bb107
bb106:
  br label %bb110
bb107:
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t679 = load i32, ptr %l1, !tbaa !23
  %t682 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackOf(ptr %v0, ptr %s24, ptr %t678, i32 %t679)
  store { i64, ptr } %t682, ptr %l355
  br label %bb108
bb108:
  %t683 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t684 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t685 = load i32, ptr %l350, !tbaa !23
  %t686 = sext i32 %t685 to i64
  %t687 = call i64 @__olang_fmt_i64(ptr null, i64 %t686)
  %t688 = add i64 %t684, %t687
  %t689 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t690 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t691 = add i64 %t688, %t690
  %t692 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t693 = extractvalue { i64, ptr } %t692, 1
  %t694 = extractvalue { i64, ptr } %t692, 0
  %t695 = add i64 %t691, %t694
  %t696 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t697 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t698 = add i64 %t695, %t697
  %t699 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t700 = extractvalue { i64, ptr } %t699, 1
  %t701 = extractvalue { i64, ptr } %t699, 0
  %t702 = add i64 %t698, %t701
  %t703 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t702)
  call void @olang_textcopy(ptr %t703, ptr %t683, i64 %t684)
  %t704 = getelementptr i8, ptr %t703, i64 %t684
  %t705 = call i64 @__olang_fmt_i64(ptr %t704, i64 %t686)
  %t706 = getelementptr i8, ptr %t704, i64 %t687
  call void @olang_textcopy(ptr %t706, ptr %t689, i64 %t690)
  %t707 = getelementptr i8, ptr %t706, i64 %t690
  call void @olang_textcopy(ptr %t707, ptr %t693, i64 %t694)
  %t708 = getelementptr i8, ptr %t707, i64 %t694
  call void @olang_textcopy(ptr %t708, ptr %t696, i64 %t697)
  %t709 = getelementptr i8, ptr %t708, i64 %t697
  call void @olang_textcopy(ptr %t709, ptr %t700, i64 %t701)
  %t710 = insertvalue { i64, ptr } undef, i64 %t702, 0
  %t711 = insertvalue { i64, ptr } %t710, ptr %t703, 1
  %t713 = extractvalue { i64, ptr } %t711, 0
  %t714 = extractvalue { i64, ptr } %t711, 1
  %t715 = mul i64 %t713, 1
  %t716 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t715)
  call void @llvm.memcpy.p0.p0.i64(ptr %t716, ptr %t714, i64 %t715, i1 false)
  %t717 = insertvalue { i64, ptr } undef, i64 %t713, 0
  %t718 = insertvalue { i64, ptr } %t717, ptr %t716, 1
  %t719 = load ptr, ptr %l349, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s24, ptr %t719, { i64, ptr } %t718)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s24)
  br label %bb110
bb110:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2efieldsOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l20 = alloca i32
  %l24 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i32
  %rv = alloca { i32, i1 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i32, ptr %l12
  store i32 %t17, ptr %l4
  %t18 = load i32, ptr %l4
  %t20 = trunc i64 22 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  %t23 = load i32, ptr %l4
  %t25 = trunc i64 23 to i32
  %t26 = icmp eq i32 %t23, %t25
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l20
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t34 = load i32, ptr %l20, !tbaa !23
  %t35 = insertvalue { i32, i1 } undef, i32 %t34, 0
  %t36 = insertvalue { i32, i1 } %t35, i1 true, 1
  store { i32, i1 } %t36, ptr %rv
  br label %ret
bb9:
  %t38 = load i32, ptr %l4
  %t40 = trunc i64 18 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l28
  br label %bb12
bb11:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb14
bb12:
  %t49 = load ptr, ptr %l25, !tbaa !29
  %t50 = load i32, ptr %l28, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l29
  br label %bb13
bb13:
  %t52 = load i32, ptr %l29
  %t54 = trunc i64 0 to i32
  %t55 = icmp eq i32 %t52, %t54
  store i1 %t55, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l24, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l35
  br label %bb17
bb16:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb18
bb17:
  %t63 = load i1, ptr %l35, !tbaa !21
  store i1 %t63, ptr %l32, !tbaa !21
  br label %bb18
bb18:
  %t64 = load i1, ptr %l32, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l38
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t70 = load i32, ptr %l38, !tbaa !23
  %t71 = insertvalue { i32, i1 } undef, i32 %t70, 0
  %t72 = insertvalue { i32, i1 } %t71, i1 true, 1
  store { i32, i1 } %t72, ptr %rv
  br label %ret
bb22:
  %t74 = insertvalue { i32, i1 } undef, i32 0, 0
  %t75 = insertvalue { i32, i1 } %t74, i1 false, 1
  store { i32, i1 } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i1
  %l19 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i1
  %l56 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t12 = load i32, ptr %l2, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  store i1 %t16, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t22 = load i32, ptr %l2, !tbaa !23
  %t26 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t20, i32 %t21, i32 %t22)
  store i1 %t26, ptr %l19
  br label %bb7
bb7:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = load i32, ptr %l1, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l26
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t40 = load i1, ptr %l26, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb15:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l30
  br label %bb16
bb16:
  %t46 = load i32, ptr %l30
  %t48 = trunc i64 21 to i32
  %t49 = icmp eq i32 %t46, %t48
  store i1 %t49, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t51 = load i1, ptr %l27, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
bb18:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l35
  br label %bb19
bb19:
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l39
  br label %bb22
bb21:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb23
bb22:
  %t63 = load i1, ptr %l39, !tbaa !21
  store i1 %t63, ptr %l36, !tbaa !21
  br label %bb23
bb23:
  %t64 = load i1, ptr %l36, !tbaa !21
  br i1 %t64, label %bb24, label %bb25
bb24:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l42
  br label %bb26
bb25:
  br label %bb34
bb26:
  %t70 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t71 = load i64, ptr %l42, !tbaa !24
  %t73 = or i64 %t71, %t70
  store i64 %t73, ptr %l4, !tbaa !24
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t76 = load i32, ptr %l2, !tbaa !23
  %t79 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l47
  br label %bb27
bb27:
  %t80 = load i64, ptr %l47, !tbaa !24
  store i64 %t80, ptr %l5, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l48, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l51
  br label %bb28
bb28:
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l54
  br label %bb29
bb29:
  %t92 = load ptr, ptr %l48, !tbaa !29
  %t93 = load i32, ptr %l51, !tbaa !23
  %t94 = load i32, ptr %l54, !tbaa !23
  %t95 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t92, i32 %t93, i32 %t94)
  store i1 %t95, ptr %l55
  br label %bb30
bb30:
  %t96 = load i1, ptr %l55, !tbaa !21
  br i1 %t96, label %bb31, label %bb32
bb31:
  %t97 = load i64, ptr %l4, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = or i64 %t97, %t98
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  store i1 %t105, ptr %l56, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb33
bb33:
  %t107 = load i1, ptr %l56, !tbaa !21
  store i1 %t107, ptr %rv
  br label %ret
bb34:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eflow(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l46 = alloca ptr
  %l49 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i64
  %l88 = alloca i64
  %l90 = alloca i64
  %l95 = alloca i32
  %l97 = alloca { i64, ptr }
  %l104 = alloca i64
  %l106 = alloca i64
  %l111 = alloca i32
  %l113 = alloca { i64, ptr }
  %l122 = alloca i64
  %l125 = alloca i64
  %l144 = alloca { i64, ptr }
  %l145 = alloca i64
  %l149 = alloca %"compiler/mir:Local"
  %l161 = alloca i64
  %l164 = alloca i64
  %l183 = alloca { i64, ptr }
  %l200 = alloca i64
  %l203 = alloca i64
  %l222 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 9
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l35
  br label %bb1
bb1:
  %t11 = load i64, ptr %l35, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 7
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l38
  br label %bb2
bb2:
  %t17 = load i64, ptr %l38, !tbaa !24
  store i64 %t17, ptr %l3, !tbaa !24
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/mir:Fn", ptr %t18, i32 0, i32 8
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l41
  br label %bb3
bb3:
  %t23 = load i64, ptr %l41, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l42, !tbaa !29
  %t25 = load i64, ptr %l2, !tbaa !24
  store i64 %t25, ptr %l43, !tbaa !24
  %t26 = load i64, ptr %l43, !tbaa !24
  %t27 = icmp sge i64 %t26, 0
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i64, ptr %l43, !tbaa !24
  %t30 = mul i64 %t29, 1
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t35 = load ptr, ptr %l42, !tbaa !29
  %t36 = getelementptr %"compiler/mir:verifier", ptr %t35, i32 0, i32 6
  store { i64, ptr } %t33, ptr %t36, !tbaa !27
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l46, !tbaa !29
  %t38 = load i64, ptr %l2, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = mul i64 %t38, %t39
  store i64 %t42, ptr %l49, !tbaa !24
  %t43 = load i64, ptr %l49, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  br i1 %t44, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3fc64ab4d22c7cd1_9c9bbb4060ef765d)
  unreachable
bb6:
  %t46 = load i64, ptr %l49, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = load ptr, ptr %l46, !tbaa !29
  %t53 = getelementptr %"compiler/mir:verifier", ptr %t52, i32 0, i32 7
  store { i64, ptr } %t50, ptr %t53, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l52, !tbaa !29
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load i64, ptr %l3, !tbaa !24
  %t59 = mul i64 %t55, %t56
  store i64 %t59, ptr %l55, !tbaa !24
  %t60 = load i64, ptr %l55, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  br i1 %t61, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_82a5970c46c34ec4_64144421b638a2b0)
  unreachable
bb8:
  %t63 = load i64, ptr %l55, !tbaa !24
  %t64 = mul i64 %t63, 1
  %t65 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t69 = load ptr, ptr %l52, !tbaa !29
  %t70 = getelementptr %"compiler/mir:verifier", ptr %t69, i32 0, i32 8
  store { i64, ptr } %t67, ptr %t70, !tbaa !27
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l58, !tbaa !29
  %t72 = load i64, ptr %l2, !tbaa !24
  %t73 = load i64, ptr %l4, !tbaa !24
  %t76 = mul i64 %t72, %t73
  store i64 %t76, ptr %l61, !tbaa !24
  %t77 = load i64, ptr %l61, !tbaa !24
  %t78 = icmp sge i64 %t77, 0
  br i1 %t78, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2ac31f2db6082ba7_5ac69b59325af853)
  unreachable
bb10:
  %t80 = load i64, ptr %l61, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t86 = load ptr, ptr %l58, !tbaa !29
  %t87 = getelementptr %"compiler/mir:verifier", ptr %t86, i32 0, i32 9
  store { i64, ptr } %t84, ptr %t87, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l64, !tbaa !29
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %l65, !tbaa !24
  %t90 = load i64, ptr %l65, !tbaa !24
  %t91 = icmp sge i64 %t90, 0
  br i1 %t91, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_397ae699ba890fb2_f6680c8259f4281e)
  unreachable
bb12:
  %t93 = load i64, ptr %l65, !tbaa !24
  %t94 = icmp sle i64 %t93, 1152921504606846975
  br i1 %t94, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2836fb8ea59de3a5_79eeb5d0a68fc1c9)
  unreachable
bb14:
  %t96 = load i64, ptr %l65, !tbaa !24
  %t97 = mul i64 %t96, 8
  %t98 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = load ptr, ptr %l64, !tbaa !29
  %t103 = getelementptr %"compiler/mir:verifier", ptr %t102, i32 0, i32 10
  store { i64, ptr } %t100, ptr %t103, !tbaa !27
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l69, !tbaa !29
  %t105 = load i64, ptr %l2, !tbaa !24
  store i64 %t105, ptr %l70, !tbaa !24
  %t106 = load i64, ptr %l70, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  br i1 %t107, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2836fb8ea59de3a5_79eeb5d0a68fc1c9)
  unreachable
bb16:
  %t109 = load i64, ptr %l70, !tbaa !24
  %t110 = icmp sle i64 %t109, 1152921504606846975
  br i1 %t110, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_13b0920ad4a1e938_72d556b41507b57c)
  unreachable
bb18:
  %t112 = load i64, ptr %l70, !tbaa !24
  %t113 = mul i64 %t112, 8
  %t114 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t118 = load ptr, ptr %l69, !tbaa !29
  %t119 = getelementptr %"compiler/mir:verifier", ptr %t118, i32 0, i32 11
  store { i64, ptr } %t116, ptr %t119, !tbaa !27
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l74, !tbaa !29
  %t121 = load i64, ptr %l3, !tbaa !24
  store i64 %t121, ptr %l75, !tbaa !24
  %t122 = load i64, ptr %l75, !tbaa !24
  %t123 = icmp sge i64 %t122, 0
  br i1 %t123, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_13b0920ad4a1e938_72d556b41507b57c)
  unreachable
bb20:
  %t125 = load i64, ptr %l75, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t131 = load ptr, ptr %l74, !tbaa !29
  %t132 = getelementptr %"compiler/mir:verifier", ptr %t131, i32 0, i32 14
  store { i64, ptr } %t129, ptr %t132, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l78, !tbaa !29
  %t134 = load i64, ptr %l3, !tbaa !24
  store i64 %t134, ptr %l79, !tbaa !24
  %t135 = load i64, ptr %l79, !tbaa !24
  %t136 = icmp sge i64 %t135, 0
  br i1 %t136, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f0f79482ff998b1b_575016ccefde52df)
  unreachable
bb22:
  %t138 = load i64, ptr %l79, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t144 = load ptr, ptr %l78, !tbaa !29
  %t145 = getelementptr %"compiler/mir:verifier", ptr %t144, i32 0, i32 15
  store { i64, ptr } %t142, ptr %t145, !tbaa !27
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l82, !tbaa !29
  %t147 = load i64, ptr %l4, !tbaa !24
  store i64 %t147, ptr %l83, !tbaa !24
  %t148 = load i64, ptr %l83, !tbaa !24
  %t149 = icmp sge i64 %t148, 0
  br i1 %t149, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a4c79ab2e91ac186_f4797f1baf8f450a)
  unreachable
bb24:
  %t151 = load i64, ptr %l83, !tbaa !24
  %t152 = mul i64 %t151, 1
  %t153 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t152)
  %t154 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  %t157 = load ptr, ptr %l82, !tbaa !29
  %t158 = getelementptr %"compiler/mir:verifier", ptr %t157, i32 0, i32 16
  store { i64, ptr } %t155, ptr %t158, !tbaa !27
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/mir:Fn", ptr %t159, i32 0, i32 4
  store ptr %t161, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2c486f9205676389_1881cd4b4e7e41e5)
  unreachable
bb26:
  %t163 = load i64, ptr %l6, !tbaa !24
  store i64 %t163, ptr %l88, !tbaa !24
  %t164 = load ptr, ptr %l5, !tbaa !29
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t164)
  store i64 %t166, ptr %l90
  br label %bb27
bb27:
  %t167 = load i64, ptr %l88, !tbaa !24
  %t168 = load i64, ptr %l90, !tbaa !24
  %t169 = icmp slt i64 %t167, %t168
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb28, label %bb29
bb28:
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t173 = load ptr, ptr %l5, !tbaa !29
  %t174 = load i64, ptr %l6, !tbaa !24
  %t177 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t173, i64 %t174)
  store i32 %t177, ptr %l95
  br label %bb31
bb31:
  %t178 = load i32, ptr %l95, !tbaa !23
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/mir:verifier", ptr %t179, i32 0, i32 14
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  store { i64, ptr } %t182, ptr %l97, !tbaa !27
  %t185 = sext i32 %t178 to i64
  %t187 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i1, ptr %t188, i64 %t185
  store i1 true, ptr %t189, !tbaa !31
  br label %bb32
bb32:
  %t190 = load i64, ptr %l6, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l6, !tbaa !24
  br label %bb26
bb33:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/mir:Fn", ptr %t194, i32 0, i32 5
  store ptr %t196, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb34
bb34:
  %t198 = load i64, ptr %l9, !tbaa !24
  store i64 %t198, ptr %l104, !tbaa !24
  %t199 = load ptr, ptr %l8, !tbaa !29
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t199)
  store i64 %t201, ptr %l106
  br label %bb35
bb35:
  %t202 = load i64, ptr %l104, !tbaa !24
  %t203 = load i64, ptr %l106, !tbaa !24
  %t204 = icmp slt i64 %t202, %t203
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t208 = load ptr, ptr %l8, !tbaa !29
  %t209 = load i64, ptr %l9, !tbaa !24
  %t212 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t208, i64 %t209)
  store i32 %t212, ptr %l111
  br label %bb39
bb39:
  %t213 = load i32, ptr %l111, !tbaa !23
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/mir:verifier", ptr %t214, i32 0, i32 14
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l113, !tbaa !27
  %t220 = sext i32 %t213 to i64
  %t222 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i1, ptr %t223, i64 %t220
  store i1 true, ptr %t224, !tbaa !31
  br label %bb40
bb40:
  %t225 = load i64, ptr %l9, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l9, !tbaa !24
  br label %bb34
bb41:
  store i64 0, ptr %l11, !tbaa !24
  %t229 = load i64, ptr %l3, !tbaa !24
  store i64 %t229, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t231 = load i64, ptr %l12, !tbaa !24
  %t232 = load i64, ptr %l11, !tbaa !24
  %t235 = icmp sgt i64 %t231, %t232
  br i1 %t235, label %bb42, label %bb43
bb42:
  %t237 = load i64, ptr %l13, !tbaa !24
  %t239 = icmp sgt i64 %t237, 0
  br i1 %t239, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb47
bb44:
  %t241 = load i64, ptr %l12, !tbaa !24
  %t242 = load i64, ptr %l11, !tbaa !24
  %t245 = sub i64 %t241, %t242
  %t246 = load i64, ptr %l13, !tbaa !24
  %t249 = add i64 %t245, %t246
  %t251 = sub i64 %t249, 1
  %t252 = load i64, ptr %l13, !tbaa !24
  %t255 = sdiv i64 %t251, %t252
  store i64 %t255, ptr %l125, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb46
bb46:
  %t257 = load i64, ptr %l125, !tbaa !24
  store i64 %t257, ptr %l122, !tbaa !24
  br label %bb47
bb47:
  %t258 = load i64, ptr %l122, !tbaa !24
  store i64 %t258, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb48
bb48:
  %t259 = load i64, ptr %l15, !tbaa !24
  %t260 = load i64, ptr %l14, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb49, label %bb50
bb49:
  br label %bb54
bb50:
  br label %bb51
bb51:
  %t267 = load i64, ptr %l11, !tbaa !24
  %t268 = load i64, ptr %l15, !tbaa !24
  %t269 = load i64, ptr %l13, !tbaa !24
  %t272 = mul i64 %t268, %t269
  %t275 = add i64 %t267, %t272
  store i64 %t275, ptr %l16, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/mir:verifier", ptr %t277, i32 0, i32 15
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l144, !tbaa !27
  %t281 = load i64, ptr %l16, !tbaa !24
  store i64 %t281, ptr %l145, !tbaa !24
  %t282 = load ptr, ptr %l1, !tbaa !29
  %t284 = getelementptr %"compiler/mir:Fn", ptr %t282, i32 0, i32 7
  %t285 = load i64, ptr %l16, !tbaa !24
  %t288 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t284, i64 %t285)
  store %"compiler/mir:Local" %t288, ptr %l149
  br label %bb52
bb52:
  %t289 = getelementptr %"compiler/mir:Local", ptr %l149, i32 0, i32 4
  %t290 = load { i64, [1 x i64] }, ptr %t289
  %t292 = extractvalue { i64, [1 x i64] } %t290, 0
  %t293 = icmp eq i64 %t292, 3
  %t295 = load i64, ptr %l145, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr i1, ptr %t297, i64 %t295
  store i1 %t293, ptr %t298, !tbaa !31
  br label %bb53
bb53:
  %t299 = load i64, ptr %l15, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l15, !tbaa !24
  br label %bb48
bb54:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/mir:verifier", ptr %t303, i32 0, i32 5
  store i1 false, ptr %t305, !tbaa !21
  %t306 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t306, i32 0)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/mir:verifier", ptr %t308, i32 0, i32 18
  store i1 false, ptr %t310, !tbaa !21
  store i64 0, ptr %l17, !tbaa !24
  %t311 = load i64, ptr %l2, !tbaa !24
  store i64 %t311, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t313 = load i64, ptr %l18, !tbaa !24
  %t314 = load i64, ptr %l17, !tbaa !24
  %t317 = icmp sgt i64 %t313, %t314
  br i1 %t317, label %bb57, label %bb58
bb57:
  %t319 = load i64, ptr %l19, !tbaa !24
  %t321 = icmp sgt i64 %t319, 0
  br i1 %t321, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb62
bb59:
  %t323 = load i64, ptr %l18, !tbaa !24
  %t324 = load i64, ptr %l17, !tbaa !24
  %t327 = sub i64 %t323, %t324
  %t328 = load i64, ptr %l19, !tbaa !24
  %t331 = add i64 %t327, %t328
  %t333 = sub i64 %t331, 1
  %t334 = load i64, ptr %l19, !tbaa !24
  %t337 = sdiv i64 %t333, %t334
  store i64 %t337, ptr %l164, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb61
bb61:
  %t339 = load i64, ptr %l164, !tbaa !24
  store i64 %t339, ptr %l161, !tbaa !24
  br label %bb62
bb62:
  %t340 = load i64, ptr %l161, !tbaa !24
  store i64 %t340, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb63
bb63:
  %t341 = load i64, ptr %l21, !tbaa !24
  %t342 = load i64, ptr %l20, !tbaa !24
  %t345 = icmp slt i64 %t341, %t342
  %t347 = xor i1 %t345, true
  br i1 %t347, label %bb64, label %bb65
bb64:
  br label %bb72
bb65:
  br label %bb66
bb66:
  %t349 = load i64, ptr %l17, !tbaa !24
  %t350 = load i64, ptr %l21, !tbaa !24
  %t351 = load i64, ptr %l19, !tbaa !24
  %t354 = mul i64 %t350, %t351
  %t357 = add i64 %t349, %t354
  store i64 %t357, ptr %l22, !tbaa !24
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/mir:verifier", ptr %t359, i32 0, i32 6
  %t362 = load { i64, ptr }, ptr %t361, !tbaa !27
  store { i64, ptr } %t362, ptr %l183, !tbaa !27
  %t363 = load i64, ptr %l22, !tbaa !24
  %t365 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr i1, ptr %t366, i64 %t363
  %t368 = load i1, ptr %t367, !tbaa !31
  br i1 %t368, label %bb67, label %bb68
bb67:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load i64, ptr %l22, !tbaa !24
  %t373 = trunc i64 %t371 to i32
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %t370, i32 %t373)
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t377 = load i64, ptr %l21, !tbaa !24
  %t379 = add i64 %t377, 1
  store i64 %t379, ptr %l21, !tbaa !24
  br label %bb63
bb72:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/mir:verifier", ptr %t381, i32 0, i32 18
  %t384 = load i1, ptr %t383, !tbaa !21
  %t386 = xor i1 %t384, true
  br i1 %t386, label %bb73, label %bb74
bb73:
  br label %bb77
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb56
bb77:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/mir:verifier", ptr %t388, i32 0, i32 5
  store i1 true, ptr %t390, !tbaa !21
  store i64 0, ptr %l23, !tbaa !24
  %t391 = load i64, ptr %l2, !tbaa !24
  store i64 %t391, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t393 = load i64, ptr %l24, !tbaa !24
  %t394 = load i64, ptr %l23, !tbaa !24
  %t397 = icmp sgt i64 %t393, %t394
  br i1 %t397, label %bb78, label %bb79
bb78:
  %t399 = load i64, ptr %l25, !tbaa !24
  %t401 = icmp sgt i64 %t399, 0
  br i1 %t401, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l200, !tbaa !24
  br label %bb83
bb80:
  %t403 = load i64, ptr %l24, !tbaa !24
  %t404 = load i64, ptr %l23, !tbaa !24
  %t407 = sub i64 %t403, %t404
  %t408 = load i64, ptr %l25, !tbaa !24
  %t411 = add i64 %t407, %t408
  %t413 = sub i64 %t411, 1
  %t414 = load i64, ptr %l25, !tbaa !24
  %t417 = sdiv i64 %t413, %t414
  store i64 %t417, ptr %l203, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l203, !tbaa !24
  br label %bb82
bb82:
  %t419 = load i64, ptr %l203, !tbaa !24
  store i64 %t419, ptr %l200, !tbaa !24
  br label %bb83
bb83:
  %t420 = load i64, ptr %l200, !tbaa !24
  store i64 %t420, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb84
bb84:
  %t421 = load i64, ptr %l27, !tbaa !24
  %t422 = load i64, ptr %l26, !tbaa !24
  %t425 = icmp slt i64 %t421, %t422
  %t427 = xor i1 %t425, true
  br i1 %t427, label %bb85, label %bb86
bb85:
  br label %bb93
bb86:
  br label %bb87
bb87:
  %t429 = load i64, ptr %l23, !tbaa !24
  %t430 = load i64, ptr %l27, !tbaa !24
  %t431 = load i64, ptr %l25, !tbaa !24
  %t434 = mul i64 %t430, %t431
  %t437 = add i64 %t429, %t434
  store i64 %t437, ptr %l28, !tbaa !24
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/mir:verifier", ptr %t439, i32 0, i32 6
  %t442 = load { i64, ptr }, ptr %t441, !tbaa !27
  store { i64, ptr } %t442, ptr %l222, !tbaa !27
  %t443 = load i64, ptr %l28, !tbaa !24
  %t445 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !27
  %t447 = getelementptr i1, ptr %t446, i64 %t443
  %t448 = load i1, ptr %t447, !tbaa !31
  br i1 %t448, label %bb88, label %bb89
bb88:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load i64, ptr %l28, !tbaa !24
  %t453 = trunc i64 %t451 to i32
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %t450, i32 %t453)
  br label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t457 = load i64, ptr %l27, !tbaa !24
  %t459 = add i64 %t457, 1
  store i64 %t459, ptr %l27, !tbaa !24
  br label %bb84
bb93:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t465 = getelementptr %"compiler/mir:verifier", ptr %t461, i32 0, i32 3
  store i64 -1, ptr %t465, !tbaa !24
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t470 = getelementptr %"compiler/mir:verifier", ptr %t466, i32 0, i32 4
  store i64 -1, ptr %t470, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l7, !tbaa !23
  %t12 = icmp ne i32 %t10, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  store { i64, ptr } %a3, ptr %l11, !tbaa !27
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l14
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l17
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = add i64 %t38, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t27, i64 %t28)
  %t44 = getelementptr i8, ptr %t43, i64 %t28
  call void @olang_textcopy(ptr %t44, ptr %t29, i64 %t30)
  %t45 = getelementptr i8, ptr %t44, i64 %t30
  call void @olang_textcopy(ptr %t45, ptr %t33, i64 %t34)
  %t46 = getelementptr i8, ptr %t45, i64 %t34
  call void @olang_textcopy(ptr %t46, ptr %t36, i64 %t37)
  %t47 = getelementptr i8, ptr %t46, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t40, i64 %t41)
  %t48 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t43, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } %t49, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  %t57 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t57, { i64, ptr } %t56)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t59 = load i32, ptr %l2, !tbaa !23
  store i32 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 17
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t15, i64 %t16)
  store i32 %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load i32, ptr %l14, !tbaa !23
  %t25 = icmp eq i32 %t20, %a1
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Range"
  %l7 = alloca i64
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store %"compiler/mir:Range" %a1, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/mir:verifier", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 11
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load %"compiler/mir:Range", ptr %l3
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s0, ptr %t11, %"compiler/mir:Range" %t12, i64 %t13, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d158, i32 0, i32 1) })
  store i1 %t14, ptr %l8
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l60 = alloca { i64, [4 x i64] }
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t4, i32 %a2)
  store { i64, ptr } %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t9, ptr %l4, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t13 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t19 = icmp ne i64 %t12, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l20, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t26 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t22, i32 %a1)
  store { i64, ptr } %t26, ptr %l23
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t34 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t42 = call i64 @__olang_fmt_i64(ptr null, i64 %t29)
  %t43 = add i64 %t40, %t42
  %t44 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t48 = sext i32 %t31 to i64
  %t49 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t50 = add i64 %t46, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t32, i64 %t33)
  %t52 = getelementptr i8, ptr %t51, i64 %t33
  call void @olang_textcopy(ptr %t52, ptr %t35, i64 %t36)
  %t53 = getelementptr i8, ptr %t52, i64 %t36
  call void @olang_textcopy(ptr %t53, ptr %t38, i64 %t39)
  %t54 = getelementptr i8, ptr %t53, i64 %t39
  %t55 = call i64 @__olang_fmt_i64(ptr %t54, i64 %t29)
  %t56 = getelementptr i8, ptr %t54, i64 %t42
  call void @olang_textcopy(ptr %t56, ptr %t44, i64 %t45)
  %t57 = getelementptr i8, ptr %t56, i64 %t45
  %t58 = call i64 @__olang_fmt_i64(ptr %t57, i64 %t48)
  %t59 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t51, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = extractvalue { i64, ptr } %t60, 1
  %t64 = mul i64 %t62, 1
  %t65 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t64)
  call void @llvm.memcpy.p0.p0.i64(ptr %t65, ptr %t63, i64 %t64, i1 false)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t68 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t68, { i64, ptr } %t67)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb6:
  store i64 0, ptr %l5, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = icmp sgt i64 %t74, %t75
  br i1 %t78, label %bb7, label %bb8
bb7:
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp sgt i64 %t80, 0
  br i1 %t82, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = sub i64 %t84, %t85
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = add i64 %t88, %t89
  %t94 = sub i64 %t92, 1
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = sdiv i64 %t94, %t95
  store i64 %t98, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t100 = load i64, ptr %l37, !tbaa !24
  store i64 %t100, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t101 = load i64, ptr %l34, !tbaa !24
  store i64 %t101, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t102 = load i64, ptr %l9, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = icmp slt i64 %t102, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t110 = load i64, ptr %l5, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = mul i64 %t111, %t112
  %t118 = add i64 %t110, %t115
  store i64 %t118, ptr %l10, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l55, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l56, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/mir:Range", ptr %l3
  %t124 = load i64, ptr %l10, !tbaa !24
  %t128 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t122, %"compiler/mir:Range" %t123, i64 %t124)
  store { i64, [4 x i64] } %t128, ptr %l60
  br label %bb17
bb17:
  %t129 = load ptr, ptr %l56, !tbaa !29
  %t130 = load { i64, [4 x i64] }, ptr %l60
  %t131 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t129, { i64, [4 x i64] } %t130)
  store i32 %t131, ptr %l61
  br label %bb18
bb18:
  %t132 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t132, ptr %l62, !tbaa !27
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i32, ptr %t136, i64 %t133
  %t138 = load i32, ptr %t137, !tbaa !33
  %t139 = load i64, ptr %l10, !tbaa !24
  %t140 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t143 = call i64 @__olang_fmt_i64(ptr null, i64 %t139)
  %t144 = add i64 %t141, %t143
  %t145 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t140, i64 %t141)
  %t146 = getelementptr i8, ptr %t145, i64 %t141
  %t147 = call i64 @__olang_fmt_i64(ptr %t146, i64 %t139)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t145, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = extractvalue { i64, ptr } %t149, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t157 = load ptr, ptr %l55, !tbaa !29
  %t158 = load i32, ptr %l61, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s4, ptr %t157, i32 %t158, i32 %t138, { i64, ptr } %t156)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t161 = load i64, ptr %l9, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l9, !tbaa !24
  br label %bb13
bb21:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2epointerLike(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/mir:verifier", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t8, i32 %a1)
  store i32 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l8, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t15, ptr %l9
  br label %bb2
bb2:
  %t16 = load i32, ptr %l9
  store i32 %t16, ptr %l2
  %t17 = load i32, ptr %l2
  %t19 = trunc i64 20 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t22 = load i32, ptr %l2
  %t24 = trunc i64 19 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l12, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  %t28 = load i32, ptr %l2
  %t30 = trunc i64 15 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l15, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprimType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l16 = alloca { i32, i1 }
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca i32
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l87 = alloca { i64, [4 x i64] }
  %l88 = alloca i32
  %l95 = alloca i32
  %l110 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i32
  %l115 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l137 = alloca i1
  %l139 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i32
  %l146 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l164 = alloca i1
  %l166 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca ptr
  %l169 = alloca ptr
  %l172 = alloca { i64, [4 x i64] }
  %l173 = alloca i32
  %l174 = alloca i32
  %l175 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca i32
  %l180 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l191 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i32
  %l196 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l212 = alloca ptr
  %l215 = alloca { i64, ptr }
  %l234 = alloca ptr
  %l237 = alloca { i64, [4 x i64] }
  %l238 = alloca i32
  %l239 = alloca ptr
  %l240 = alloca i32
  %l243 = alloca i32
  %l244 = alloca i1
  %l246 = alloca ptr
  %l247 = alloca i32
  %l249 = alloca { i64, ptr }
  %l251 = alloca { i64, ptr }
  %l254 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l262 = alloca i1
  %l264 = alloca i1
  %l268 = alloca i1
  %l272 = alloca i1
  %l276 = alloca ptr
  %l277 = alloca i32
  %l279 = alloca { i64, ptr }
  %l281 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l290 = alloca ptr
  %l291 = alloca i32
  %l293 = alloca { i64, ptr }
  %l295 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l306 = alloca { i64, [4 x i64] }
  %l307 = alloca i32
  %l310 = alloca i32
  %l313 = alloca i32
  %l317 = alloca i1
  %l320 = alloca i1
  %l323 = alloca i1
  %l324 = alloca ptr
  %l327 = alloca i32
  %l330 = alloca i32
  %l331 = alloca i1
  %l335 = alloca i1
  %l339 = alloca i1
  %l342 = alloca ptr
  %l345 = alloca { i64, ptr }
  %l348 = alloca { i64, ptr }
  %l354 = alloca ptr
  %l357 = alloca { i64, ptr }
  %l368 = alloca i1
  %l369 = alloca i32
  %l372 = alloca i32
  %l376 = alloca i32
  %l379 = alloca ptr
  %l382 = alloca { i64, ptr }
  %l388 = alloca ptr
  %l391 = alloca { i64, ptr }
  %l402 = alloca i1
  %l404 = alloca ptr
  %l405 = alloca i32
  %l407 = alloca { i64, ptr }
  %l409 = alloca { i64, ptr }
  %l412 = alloca { i64, ptr }
  %l418 = alloca ptr
  %l419 = alloca i32
  %l421 = alloca { i64, ptr }
  %l423 = alloca { i64, ptr }
  %l426 = alloca { i64, ptr }
  %l433 = alloca i1
  %l435 = alloca ptr
  %l438 = alloca { i64, ptr }
  %l451 = alloca i1
  %l453 = alloca i1
  %l454 = alloca ptr
  %l455 = alloca ptr
  %l458 = alloca { i64, [4 x i64] }
  %l459 = alloca i32
  %l460 = alloca i32
  %l463 = alloca ptr
  %l464 = alloca i32
  %l466 = alloca { i64, ptr }
  %l468 = alloca { i64, ptr }
  %l471 = alloca { i64, ptr }
  %l477 = alloca i1
  %l479 = alloca ptr
  %l480 = alloca i32
  %l482 = alloca { i64, ptr }
  %l484 = alloca { i64, ptr }
  %l487 = alloca { i64, ptr }
  %l490 = alloca { i64, ptr }
  %l497 = alloca i1
  %l498 = alloca i32
  %l501 = alloca i32
  %l505 = alloca i32
  %l508 = alloca ptr
  %l511 = alloca { i64, ptr }
  %l517 = alloca ptr
  %l520 = alloca { i64, ptr }
  %l527 = alloca { i32, i1 }
  %l531 = alloca ptr
  %l534 = alloca { i64, ptr }
  %l540 = alloca ptr
  %l543 = alloca { i64, ptr }
  %l550 = alloca i1
  %l552 = alloca i1
  %l555 = alloca i1
  %l556 = alloca ptr
  %l559 = alloca { i64, ptr }
  %l562 = alloca ptr
  %l565 = alloca i32
  %l566 = alloca i1
  %l568 = alloca ptr
  %l571 = alloca { i64, ptr }
  %l574 = alloca ptr
  %l575 = alloca ptr
  %l578 = alloca { i64, [4 x i64] }
  %l579 = alloca i32
  %l580 = alloca i32
  %l588 = alloca i1
  %l590 = alloca ptr
  %l593 = alloca { i64, ptr }
  %l596 = alloca ptr
  %l599 = alloca i32
  %l600 = alloca i1
  %l602 = alloca ptr
  %l605 = alloca { i64, ptr }
  %l612 = alloca i1
  %l614 = alloca ptr
  %l617 = alloca { i64, ptr }
  %l623 = alloca ptr
  %l626 = alloca { i64, ptr }
  %l631 = alloca i1
  %l633 = alloca i1
  %l634 = alloca ptr
  %l635 = alloca ptr
  %l638 = alloca i32
  %l639 = alloca i32
  %l640 = alloca i1
  %l642 = alloca i1
  %l645 = alloca i64
  %l649 = alloca ptr
  %l650 = alloca i32
  %l652 = alloca { i64, ptr }
  %l654 = alloca { i64, ptr }
  %l657 = alloca { i64, ptr }
  %l662 = alloca i32
  %l667 = alloca i64
  %l670 = alloca i64
  %l688 = alloca ptr
  %l689 = alloca ptr
  %l693 = alloca { i64, [4 x i64] }
  %l694 = alloca i32
  %l695 = alloca i32
  %l696 = alloca i32
  %l698 = alloca { i64, ptr }
  %l700 = alloca { i64, ptr }
  %l711 = alloca ptr
  %l714 = alloca { i64, ptr }
  %l720 = alloca i1
  %l722 = alloca ptr
  %l723 = alloca i32
  %l725 = alloca { i64, ptr }
  %l727 = alloca { i64, ptr }
  %l730 = alloca { i64, ptr }
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.builder
  %s16room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.builder
  %s20room = alloca [64 x i8], align 8
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.builder
  %s27room = alloca [64 x i8], align 8
  %s30 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.builder
  %s34room = alloca [64 x i8], align 8
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.builder
  %s37room = alloca [64 x i8], align 8
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.builder
  %s40room = alloca [64 x i8], align 8
  %s44 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %s56 = alloca %olang.builder
  %s56room = alloca [64 x i8], align 8
  %s58 = alloca %olang.scope
  %s59 = alloca %olang.builder
  %s59room = alloca [64 x i8], align 8
  %s62 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %s66 = alloca %olang.builder
  %s66room = alloca [64 x i8], align 8
  %s68 = alloca %olang.scope
  %s69 = alloca %olang.builder
  %s69room = alloca [64 x i8], align 8
  %s72 = alloca %olang.scope
  %s74 = alloca %olang.scope
  %s77 = alloca %olang.scope
  %s79 = alloca %olang.scope
  %s82 = alloca %olang.scope
  %s84 = alloca %olang.scope
  %s86 = alloca %olang.scope
  %s88 = alloca %olang.scope
  %s90 = alloca %olang.scope
  %s93 = alloca %olang.scope
  %s95 = alloca %olang.scope
  %s98 = alloca %olang.scope
  %s99 = alloca %olang.builder
  %s99room = alloca [64 x i8], align 8
  %s103 = alloca %olang.scope
  %s104 = alloca %olang.builder
  %s104room = alloca [64 x i8], align 8
  %s108 = alloca %olang.scope
  %s111 = alloca %olang.scope
  %s112 = alloca %olang.builder
  %s112room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  store i64 %t9, ptr %l5, !tbaa !24
  %t11 = load i32, ptr %l1
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb1, label %bb2
bb1:
  br label %bb11
bb2:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 1 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 2 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  %t26 = load i32, ptr %l1
  %t28 = trunc i64 20 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t31 = load i32, ptr %l1
  %t33 = trunc i64 21 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 1, ptr %l29, !tbaa !24
  br label %bb45
bb12:
  %t36 = load i32, ptr %l1
  %t38 = trunc i64 22 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  %t41 = load i32, ptr %l1
  %t43 = trunc i64 24 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb15, label %bb16
bb15:
  br label %bb21
bb16:
  %t46 = load i32, ptr %l1
  %t48 = trunc i64 29 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb17, label %bb18
bb17:
  br label %bb21
bb18:
  %t51 = load i32, ptr %l1
  %t53 = trunc i64 41 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i64 1, ptr %l29, !tbaa !24
  br label %bb45
bb22:
  %t56 = load i32, ptr %l1
  %t58 = trunc i64 31 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  %t61 = load i32, ptr %l1
  %t63 = trunc i64 32 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  %t66 = load i32, ptr %l1
  %t68 = trunc i64 33 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  %t71 = load i32, ptr %l1
  %t73 = trunc i64 36 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i64 1, ptr %l29, !tbaa !24
  br label %bb45
bb32:
  %t76 = load i32, ptr %l1
  %t78 = trunc i64 37 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb45
bb36:
  %t81 = load i32, ptr %l1
  %t83 = trunc i64 28 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i64 3, ptr %l29, !tbaa !24
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i64 2, ptr %l29, !tbaa !24
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_d0c28dbd82f4c36a_9dd446291f7ee706)
  unreachable
bb45:
  %t86 = load i64, ptr %l29, !tbaa !24
  store i64 %t86, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t89 = icmp slt i64 %t87, 0
  br i1 %t89, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s7
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l62, !tbaa !29
  %t92 = load i32, ptr %l1
  store i32 %t92, ptr %l63
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s8, ptr %l63, i64 0)
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t94 = load ptr, ptr %s8
  %t95 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t96 = load i64, ptr %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t94, i64 %t96)
  %t98 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l65, !tbaa !27
  %t100 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t101 = load ptr, ptr %t100
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %sbgrew.103, label %sbdone.104
sbgrew.103:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.104
sbdone.104:
  %t105 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s7, { i64, ptr } %t111)
  store { i64, ptr } %t113, ptr %l67
  br label %bb49
bb49:
  %t114 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t115, i64 %t116)
  %t121 = getelementptr i8, ptr %t120, i64 %t116
  call void @olang_textcopy(ptr %t121, ptr %t117, i64 %t118)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t120, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = extractvalue { i64, ptr } %t123, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t131 = load ptr, ptr %l62, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s7, ptr %t131, { i64, ptr } %t130)
  br label %bb50
bb50:
  %t133 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  store i32 %t133, ptr %rv
  br label %ret
bb51:
  %t135 = load i64, ptr %l5, !tbaa !24
  %t136 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp ne i64 %t135, %t136
  br i1 %t139, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l74, !tbaa !29
  %t142 = load i32, ptr %l1
  store i32 %t142, ptr %l75
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s11, ptr %l75, i64 0)
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t144 = load ptr, ptr %s11
  %t145 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t146 = load i64, ptr %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t144, i64 %t146)
  %t148 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  store { i64, ptr } %t149, ptr %l77, !tbaa !27
  %t150 = getelementptr %olang.builder, ptr %s11, i32 0, i32 3
  %t151 = load ptr, ptr %t150
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %sbgrew.153, label %sbdone.154
sbgrew.153:
  call void @__olang_sb_done(ptr %s11)
  br label %sbdone.154
sbdone.154:
  %t155 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t157 = extractvalue { i64, ptr } %t155, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  %t163 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s10, { i64, ptr } %t161)
  store { i64, ptr } %t163, ptr %l79
  br label %bb55
bb55:
  %t164 = load i64, ptr %l5, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t172 = call i64 @__olang_fmt_i64(ptr null, i64 %t164)
  %t173 = add i64 %t170, %t172
  %t174 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t166, i64 %t167)
  %t178 = getelementptr i8, ptr %t177, i64 %t167
  call void @olang_textcopy(ptr %t178, ptr %t168, i64 %t169)
  %t179 = getelementptr i8, ptr %t178, i64 %t169
  %t180 = call i64 @__olang_fmt_i64(ptr %t179, i64 %t164)
  %t181 = getelementptr i8, ptr %t179, i64 %t172
  call void @olang_textcopy(ptr %t181, ptr %t174, i64 %t175)
  %t182 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t177, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t191 = load ptr, ptr %l74, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t191, { i64, ptr } %t190)
  br label %bb56
bb56:
  %t193 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  store i32 %t193, ptr %rv
  br label %ret
bb57:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l84, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load %"compiler/mir:Range", ptr %l3
  %t200 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t196, %"compiler/mir:Range" %t197, i64 0)
  store { i64, [4 x i64] } %t200, ptr %l87
  br label %bb58
bb58:
  %t201 = load ptr, ptr %l84, !tbaa !29
  %t202 = load { i64, [4 x i64] }, ptr %l87
  %t203 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t201, { i64, [4 x i64] } %t202)
  store i32 %t203, ptr %l88
  br label %bb59
bb59:
  %t204 = load i32, ptr %l88, !tbaa !23
  store i32 %t204, ptr %l7, !tbaa !23
  %t205 = load i32, ptr %l7, !tbaa !23
  %t206 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t209 = icmp eq i32 %t205, %t206
  br i1 %t209, label %bb60, label %bb61
bb60:
  %t211 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t211, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t213 = load ptr, ptr %l4, !tbaa !29
  %t214 = load i32, ptr %l7, !tbaa !23
  %t217 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t213, i32 %t214)
  store i32 %t217, ptr %l95
  br label %bb63
bb63:
  %t218 = load i32, ptr %l95, !tbaa !23
  store i32 %t218, ptr %l8, !tbaa !23
  %t219 = load i32, ptr %l1
  %t221 = trunc i64 0 to i32
  %t222 = icmp eq i32 %t219, %t221
  br i1 %t222, label %bb64, label %bb65
bb64:
  br label %bb76
bb65:
  %t224 = load i32, ptr %l1
  %t226 = trunc i64 3 to i32
  %t227 = icmp eq i32 %t224, %t226
  br i1 %t227, label %bb66, label %bb67
bb66:
  br label %bb76
bb67:
  %t229 = load i32, ptr %l1
  %t231 = trunc i64 4 to i32
  %t232 = icmp eq i32 %t229, %t231
  br i1 %t232, label %bb68, label %bb69
bb68:
  br label %bb76
bb69:
  %t234 = load i32, ptr %l1
  %t236 = trunc i64 5 to i32
  %t237 = icmp eq i32 %t234, %t236
  br i1 %t237, label %bb70, label %bb71
bb70:
  br label %bb76
bb71:
  %t239 = load i32, ptr %l1
  %t241 = trunc i64 6 to i32
  %t242 = icmp eq i32 %t239, %t241
  br i1 %t242, label %bb72, label %bb73
bb72:
  br label %bb76
bb73:
  %t244 = load i32, ptr %l1
  %t246 = trunc i64 7 to i32
  %t247 = icmp eq i32 %t244, %t246
  br i1 %t247, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb86
bb76:
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t250 = load i32, ptr %l8, !tbaa !23
  %t253 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t249, i32 %t250)
  store i1 %t253, ptr %l110
  br label %bb77
bb77:
  %t254 = load i1, ptr %l110, !tbaa !21
  %t255 = xor i1 %t254, true
  br i1 %t255, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s15
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l112, !tbaa !29
  %t258 = load i32, ptr %l1
  store i32 %t258, ptr %l113
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s16
  store ptr %s16room, ptr %s16
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s16, ptr %l113, i64 0)
  br label %bb80
bb79:
  br label %bb84
bb80:
  %t260 = load ptr, ptr %s16
  %t261 = getelementptr %olang.builder, ptr %s16, i32 0, i32 1
  %t262 = load i64, ptr %t261
  %t263 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t262)
  call void @olang_textcopy(ptr %t263, ptr %t260, i64 %t262)
  %t264 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  store { i64, ptr } %t265, ptr %l115, !tbaa !27
  %t266 = getelementptr %olang.builder, ptr %s16, i32 0, i32 3
  %t267 = load ptr, ptr %t266
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %sbgrew.269, label %sbdone.270
sbgrew.269:
  call void @__olang_sb_done(ptr %s16)
  br label %sbdone.270
sbdone.270:
  %t271 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  %t273 = extractvalue { i64, ptr } %t271, 1
  %t274 = mul i64 %t272, 1
  %t275 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t274)
  call void @llvm.memcpy.p0.p0.i64(ptr %t275, ptr %t273, i64 %t274, i1 false)
  %t276 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  %t279 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s15, { i64, ptr } %t277)
  store { i64, ptr } %t279, ptr %l117
  br label %bb81
bb81:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i32, ptr %l7, !tbaa !23
  %t284 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s15, ptr %t280, i32 %t281)
  store { i64, ptr } %t284, ptr %l120
  br label %bb82
bb82:
  %t285 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 1
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t288 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t289 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t290 = add i64 %t287, %t289
  %t291 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t291, 1
  %t293 = extractvalue { i64, ptr } %t291, 0
  %t294 = add i64 %t290, %t293
  %t295 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t294)
  call void @olang_textcopy(ptr %t295, ptr %t286, i64 %t287)
  %t296 = getelementptr i8, ptr %t295, i64 %t287
  call void @olang_textcopy(ptr %t296, ptr %t288, i64 %t289)
  %t297 = getelementptr i8, ptr %t296, i64 %t289
  call void @olang_textcopy(ptr %t297, ptr %t292, i64 %t293)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t295, 1
  %t301 = extractvalue { i64, ptr } %t299, 0
  %t302 = extractvalue { i64, ptr } %t299, 1
  %t303 = mul i64 %t301, 1
  %t304 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t303)
  call void @llvm.memcpy.p0.p0.i64(ptr %t304, ptr %t302, i64 %t303, i1 false)
  %t305 = insertvalue { i64, ptr } undef, i64 %t301, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  %t307 = load ptr, ptr %l112, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s15, ptr %t307, { i64, ptr } %t306)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s15)
  br label %bb84
bb84:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load i32, ptr %l1
  %t311 = load %"compiler/mir:Range", ptr %l3
  %t312 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %t309, i32 %t310, %"compiler/mir:Range" %t311, i32 %t312)
  br label %bb85
bb85:
  br label %bb475
bb86:
  %t317 = load i32, ptr %l1
  %t319 = trunc i64 1 to i32
  %t320 = icmp eq i32 %t317, %t319
  br i1 %t320, label %bb87, label %bb88
bb87:
  br label %bb95
bb88:
  %t322 = load i32, ptr %l1
  %t324 = trunc i64 10 to i32
  %t325 = icmp eq i32 %t322, %t324
  br i1 %t325, label %bb89, label %bb90
bb89:
  br label %bb95
bb90:
  %t327 = load i32, ptr %l1
  %t329 = trunc i64 11 to i32
  %t330 = icmp eq i32 %t327, %t329
  br i1 %t330, label %bb91, label %bb92
bb91:
  br label %bb95
bb92:
  %t332 = load i32, ptr %l1
  %t334 = trunc i64 12 to i32
  %t335 = icmp eq i32 %t332, %t334
  br i1 %t335, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb108
bb95:
  %t337 = load ptr, ptr %l4, !tbaa !29
  %t338 = load i32, ptr %l8, !tbaa !23
  %t341 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t337, i32 %t338)
  store i1 %t341, ptr %l137
  br label %bb96
bb96:
  %t342 = load i1, ptr %l137, !tbaa !21
  %t343 = xor i1 %t342, true
  br i1 %t343, label %bb97, label %bb98
bb97:
  %t345 = load i32, ptr %l8, !tbaa !23
  %t346 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t349 = icmp ne i32 %t345, %t346
  store i1 %t349, ptr %l139, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb99
bb99:
  %t351 = load i1, ptr %l139, !tbaa !21
  br i1 %t351, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s19
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l143, !tbaa !29
  %t353 = load i32, ptr %l1
  store i32 %t353, ptr %l144
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s20
  store ptr %s20room, ptr %s20
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s20, ptr %l144, i64 0)
  br label %bb102
bb101:
  br label %bb106
bb102:
  %t355 = load ptr, ptr %s20
  %t356 = getelementptr %olang.builder, ptr %s20, i32 0, i32 1
  %t357 = load i64, ptr %t356
  %t358 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t357)
  call void @olang_textcopy(ptr %t358, ptr %t355, i64 %t357)
  %t359 = insertvalue { i64, ptr } undef, i64 %t357, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  store { i64, ptr } %t360, ptr %l146, !tbaa !27
  %t361 = getelementptr %olang.builder, ptr %s20, i32 0, i32 3
  %t362 = load ptr, ptr %t361
  %t363 = icmp ne ptr %t362, null
  br i1 %t363, label %sbgrew.364, label %sbdone.365
sbgrew.364:
  call void @__olang_sb_done(ptr %s20)
  br label %sbdone.365
sbdone.365:
  %t366 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 0
  %t368 = extractvalue { i64, ptr } %t366, 1
  %t369 = mul i64 %t367, 1
  %t370 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t370, ptr %t368, i64 %t369, i1 false)
  %t371 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  %t374 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s19, { i64, ptr } %t372)
  store { i64, ptr } %t374, ptr %l148
  br label %bb103
bb103:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load i32, ptr %l7, !tbaa !23
  %t379 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s19, ptr %t375, i32 %t376)
  store { i64, ptr } %t379, ptr %l151
  br label %bb104
bb104:
  %t380 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t380, 1
  %t382 = extractvalue { i64, ptr } %t380, 0
  %t383 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t384 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t385 = add i64 %t382, %t384
  %t386 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t386, 1
  %t388 = extractvalue { i64, ptr } %t386, 0
  %t389 = add i64 %t385, %t388
  %t390 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t389)
  call void @olang_textcopy(ptr %t390, ptr %t381, i64 %t382)
  %t391 = getelementptr i8, ptr %t390, i64 %t382
  call void @olang_textcopy(ptr %t391, ptr %t383, i64 %t384)
  %t392 = getelementptr i8, ptr %t391, i64 %t384
  call void @olang_textcopy(ptr %t392, ptr %t387, i64 %t388)
  %t393 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t390, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = extractvalue { i64, ptr } %t394, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  %t402 = load ptr, ptr %l143, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s19, ptr %t402, { i64, ptr } %t401)
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s19)
  br label %bb106
bb106:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load i32, ptr %l1
  %t406 = load %"compiler/mir:Range", ptr %l3
  %t407 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %t404, i32 %t405, %"compiler/mir:Range" %t406, i32 %t407)
  br label %bb107
bb107:
  br label %bb475
bb108:
  %t412 = load i32, ptr %l1
  %t414 = trunc i64 8 to i32
  %t415 = icmp eq i32 %t412, %t414
  br i1 %t415, label %bb109, label %bb110
bb109:
  br label %bb113
bb110:
  %t417 = load i32, ptr %l1
  %t419 = trunc i64 9 to i32
  %t420 = icmp eq i32 %t417, %t419
  br i1 %t420, label %bb111, label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb138
bb113:
  %t422 = load ptr, ptr %l4, !tbaa !29
  %t423 = load i32, ptr %l8, !tbaa !23
  %t426 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t422, i32 %t423)
  store i1 %t426, ptr %l164
  br label %bb114
bb114:
  %t427 = load i1, ptr %l164, !tbaa !21
  %t428 = xor i1 %t427, true
  br i1 %t428, label %bb115, label %bb116
bb115:
  store i1 true, ptr %l166, !tbaa !21
  br label %bb121
bb116:
  %t430 = load ptr, ptr %l4, !tbaa !29
  store ptr %t430, ptr %l167, !tbaa !29
  %t431 = load ptr, ptr %l4, !tbaa !29
  store ptr %t431, ptr %l168, !tbaa !29
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l169, !tbaa !29
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load %"compiler/mir:Range", ptr %l3
  %t437 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t433, %"compiler/mir:Range" %t434, i64 1)
  store { i64, [4 x i64] } %t437, ptr %l172
  br label %bb117
bb117:
  %t438 = load ptr, ptr %l169, !tbaa !29
  %t439 = load { i64, [4 x i64] }, ptr %l172
  %t440 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t438, { i64, [4 x i64] } %t439)
  store i32 %t440, ptr %l173
  br label %bb118
bb118:
  %t441 = load ptr, ptr %l168, !tbaa !29
  %t442 = load i32, ptr %l173, !tbaa !23
  %t443 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t441, i32 %t442)
  store i32 %t443, ptr %l174
  br label %bb119
bb119:
  %t444 = load ptr, ptr %l167, !tbaa !29
  %t445 = load i32, ptr %l174, !tbaa !23
  %t446 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t444, i32 %t445)
  store i1 %t446, ptr %l175
  br label %bb120
bb120:
  %t447 = load i1, ptr %l175, !tbaa !21
  %t448 = xor i1 %t447, true
  store i1 %t448, ptr %l166, !tbaa !21
  br label %bb121
bb121:
  %t450 = load i1, ptr %l166, !tbaa !21
  br i1 %t450, label %bb122, label %bb123
bb122:
  store %olang.scope zeroinitializer, ptr %s23
  %t451 = load ptr, ptr %l0, !tbaa !29
  store ptr %t451, ptr %l177, !tbaa !29
  %t452 = load i32, ptr %l1
  store i32 %t452, ptr %l178
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s24, ptr %l178, i64 0)
  br label %bb124
bb123:
  br label %bb128
bb124:
  %t454 = load ptr, ptr %s24
  %t455 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t456 = load i64, ptr %t455
  %t457 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t456)
  call void @olang_textcopy(ptr %t457, ptr %t454, i64 %t456)
  %t458 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t457, 1
  store { i64, ptr } %t459, ptr %l180, !tbaa !27
  %t460 = getelementptr %olang.builder, ptr %s24, i32 0, i32 3
  %t461 = load ptr, ptr %t460
  %t462 = icmp ne ptr %t461, null
  br i1 %t462, label %sbgrew.463, label %sbdone.464
sbgrew.463:
  call void @__olang_sb_done(ptr %s24)
  br label %sbdone.464
sbdone.464:
  %t465 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 0
  %t467 = extractvalue { i64, ptr } %t465, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  %t473 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s23, { i64, ptr } %t471)
  store { i64, ptr } %t473, ptr %l182
  br label %bb125
bb125:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load i32, ptr %l7, !tbaa !23
  %t478 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s23, ptr %t474, i32 %t475)
  store { i64, ptr } %t478, ptr %l185
  br label %bb126
bb126:
  %t479 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t479, 1
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t482 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t483 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t484 = add i64 %t481, %t483
  %t485 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t485, 1
  %t487 = extractvalue { i64, ptr } %t485, 0
  %t488 = add i64 %t484, %t487
  %t489 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t488)
  call void @olang_textcopy(ptr %t489, ptr %t480, i64 %t481)
  %t490 = getelementptr i8, ptr %t489, i64 %t481
  call void @olang_textcopy(ptr %t490, ptr %t482, i64 %t483)
  %t491 = getelementptr i8, ptr %t490, i64 %t483
  call void @olang_textcopy(ptr %t491, ptr %t486, i64 %t487)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t489, 1
  %t495 = extractvalue { i64, ptr } %t493, 0
  %t496 = extractvalue { i64, ptr } %t493, 1
  %t497 = mul i64 %t495, 1
  %t498 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t497)
  call void @llvm.memcpy.p0.p0.i64(ptr %t498, ptr %t496, i64 %t497, i1 false)
  %t499 = insertvalue { i64, ptr } undef, i64 %t495, 0
  %t500 = insertvalue { i64, ptr } %t499, ptr %t498, 1
  %t501 = load ptr, ptr %l177, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s23, ptr %t501, { i64, ptr } %t500)
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s23)
  br label %bb128
bb128:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load i32, ptr %l7, !tbaa !23
  %t505 = load i32, ptr %l2, !tbaa !23
  %t509 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t503, i32 %t504, i32 %t505)
  store i1 %t509, ptr %l191
  br label %bb129
bb129:
  %t510 = load i1, ptr %l191, !tbaa !21
  %t511 = xor i1 %t510, true
  br i1 %t511, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s26
  %t513 = load ptr, ptr %l0, !tbaa !29
  store ptr %t513, ptr %l193, !tbaa !29
  %t514 = load i32, ptr %l1
  store i32 %t514, ptr %l194
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s27
  store ptr %s27room, ptr %s27
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s27, ptr %l194, i64 0)
  br label %bb132
bb131:
  br label %bb137
bb132:
  %t516 = load ptr, ptr %s27
  %t517 = getelementptr %olang.builder, ptr %s27, i32 0, i32 1
  %t518 = load i64, ptr %t517
  %t519 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t518)
  call void @olang_textcopy(ptr %t519, ptr %t516, i64 %t518)
  %t520 = insertvalue { i64, ptr } undef, i64 %t518, 0
  %t521 = insertvalue { i64, ptr } %t520, ptr %t519, 1
  store { i64, ptr } %t521, ptr %l196, !tbaa !27
  %t522 = getelementptr %olang.builder, ptr %s27, i32 0, i32 3
  %t523 = load ptr, ptr %t522
  %t524 = icmp ne ptr %t523, null
  br i1 %t524, label %sbgrew.525, label %sbdone.526
sbgrew.525:
  call void @__olang_sb_done(ptr %s27)
  br label %sbdone.526
sbdone.526:
  %t527 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t527, 0
  %t529 = extractvalue { i64, ptr } %t527, 1
  %t530 = mul i64 %t528, 1
  %t531 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t530)
  call void @llvm.memcpy.p0.p0.i64(ptr %t531, ptr %t529, i64 %t530, i1 false)
  %t532 = insertvalue { i64, ptr } undef, i64 %t528, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t531, 1
  %t535 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s26, { i64, ptr } %t533)
  store { i64, ptr } %t535, ptr %l198
  br label %bb133
bb133:
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load i32, ptr %l7, !tbaa !23
  %t540 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s26, ptr %t536, i32 %t537)
  store { i64, ptr } %t540, ptr %l201
  br label %bb134
bb134:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load i32, ptr %l2, !tbaa !23
  %t545 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s26, ptr %t541, i32 %t542)
  store { i64, ptr } %t545, ptr %l204
  br label %bb135
bb135:
  %t546 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t546, 1
  %t548 = extractvalue { i64, ptr } %t546, 0
  %t549 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t550 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t551 = add i64 %t548, %t550
  %t552 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t553 = extractvalue { i64, ptr } %t552, 1
  %t554 = extractvalue { i64, ptr } %t552, 0
  %t555 = add i64 %t551, %t554
  %t556 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t557 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t558 = add i64 %t555, %t557
  %t559 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t560 = extractvalue { i64, ptr } %t559, 1
  %t561 = extractvalue { i64, ptr } %t559, 0
  %t562 = add i64 %t558, %t561
  %t563 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t562)
  call void @olang_textcopy(ptr %t563, ptr %t547, i64 %t548)
  %t564 = getelementptr i8, ptr %t563, i64 %t548
  call void @olang_textcopy(ptr %t564, ptr %t549, i64 %t550)
  %t565 = getelementptr i8, ptr %t564, i64 %t550
  call void @olang_textcopy(ptr %t565, ptr %t553, i64 %t554)
  %t566 = getelementptr i8, ptr %t565, i64 %t554
  call void @olang_textcopy(ptr %t566, ptr %t556, i64 %t557)
  %t567 = getelementptr i8, ptr %t566, i64 %t557
  call void @olang_textcopy(ptr %t567, ptr %t560, i64 %t561)
  %t568 = insertvalue { i64, ptr } undef, i64 %t562, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t563, 1
  %t571 = extractvalue { i64, ptr } %t569, 0
  %t572 = extractvalue { i64, ptr } %t569, 1
  %t573 = mul i64 %t571, 1
  %t574 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t573)
  call void @llvm.memcpy.p0.p0.i64(ptr %t574, ptr %t572, i64 %t573, i1 false)
  %t575 = insertvalue { i64, ptr } undef, i64 %t571, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t574, 1
  %t577 = load ptr, ptr %l193, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s26, ptr %t577, { i64, ptr } %t576)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s26)
  br label %bb137
bb137:
  br label %bb475
bb138:
  %t579 = load i32, ptr %l1
  %t581 = trunc i64 2 to i32
  %t582 = icmp eq i32 %t579, %t581
  br i1 %t582, label %bb139, label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb148
bb141:
  %t584 = load i32, ptr %l8, !tbaa !23
  %t585 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t588 = icmp ne i32 %t584, %t585
  br i1 %t588, label %bb142, label %bb143
bb142:
  store %olang.scope zeroinitializer, ptr %s30
  %t590 = load ptr, ptr %l0, !tbaa !29
  store ptr %t590, ptr %l212, !tbaa !29
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t592 = load i32, ptr %l7, !tbaa !23
  %t595 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s30, ptr %t591, i32 %t592)
  store { i64, ptr } %t595, ptr %l215
  br label %bb144
bb143:
  br label %bb146
bb144:
  %t596 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t597 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t598 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t598, 1
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t601 = add i64 %t597, %t600
  %t602 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t601)
  call void @olang_textcopy(ptr %t602, ptr %t596, i64 %t597)
  %t603 = getelementptr i8, ptr %t602, i64 %t597
  call void @olang_textcopy(ptr %t603, ptr %t599, i64 %t600)
  %t604 = insertvalue { i64, ptr } undef, i64 %t601, 0
  %t605 = insertvalue { i64, ptr } %t604, ptr %t602, 1
  %t607 = extractvalue { i64, ptr } %t605, 0
  %t608 = extractvalue { i64, ptr } %t605, 1
  %t609 = mul i64 %t607, 1
  %t610 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t609)
  call void @llvm.memcpy.p0.p0.i64(ptr %t610, ptr %t608, i64 %t609, i1 false)
  %t611 = insertvalue { i64, ptr } undef, i64 %t607, 0
  %t612 = insertvalue { i64, ptr } %t611, ptr %t610, 1
  %t613 = load ptr, ptr %l212, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s30, ptr %t613, { i64, ptr } %t612)
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s30)
  br label %bb146
bb146:
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t616 = load i32, ptr %l1
  %t617 = load %"compiler/mir:Range", ptr %l3
  %t618 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %t615, i32 %t616, %"compiler/mir:Range" %t617, i32 %t618)
  br label %bb147
bb147:
  br label %bb475
bb148:
  %t623 = load i32, ptr %l1
  %t625 = trunc i64 13 to i32
  %t626 = icmp eq i32 %t623, %t625
  br i1 %t626, label %bb149, label %bb150
bb149:
  br label %bb161
bb150:
  %t628 = load i32, ptr %l1
  %t630 = trunc i64 14 to i32
  %t631 = icmp eq i32 %t628, %t630
  br i1 %t631, label %bb151, label %bb152
bb151:
  br label %bb161
bb152:
  %t633 = load i32, ptr %l1
  %t635 = trunc i64 15 to i32
  %t636 = icmp eq i32 %t633, %t635
  br i1 %t636, label %bb153, label %bb154
bb153:
  br label %bb161
bb154:
  %t638 = load i32, ptr %l1
  %t640 = trunc i64 16 to i32
  %t641 = icmp eq i32 %t638, %t640
  br i1 %t641, label %bb155, label %bb156
bb155:
  br label %bb161
bb156:
  %t643 = load i32, ptr %l1
  %t645 = trunc i64 17 to i32
  %t646 = icmp eq i32 %t643, %t645
  br i1 %t646, label %bb157, label %bb158
bb157:
  br label %bb161
bb158:
  %t648 = load i32, ptr %l1
  %t650 = trunc i64 18 to i32
  %t651 = icmp eq i32 %t648, %t650
  br i1 %t651, label %bb159, label %bb160
bb159:
  br label %bb161
bb160:
  br label %bb198
bb161:
  %t653 = load ptr, ptr %l0, !tbaa !29
  store ptr %t653, ptr %l234, !tbaa !29
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t655 = load %"compiler/mir:Range", ptr %l3
  %t658 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t654, %"compiler/mir:Range" %t655, i64 1)
  store { i64, [4 x i64] } %t658, ptr %l237
  br label %bb162
bb162:
  %t659 = load ptr, ptr %l234, !tbaa !29
  %t660 = load { i64, [4 x i64] }, ptr %l237
  %t661 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t659, { i64, [4 x i64] } %t660)
  store i32 %t661, ptr %l238
  br label %bb163
bb163:
  %t662 = load i32, ptr %l238, !tbaa !23
  store i32 %t662, ptr %l9, !tbaa !23
  %t663 = load ptr, ptr %l4, !tbaa !29
  store ptr %t663, ptr %l239, !tbaa !29
  %t664 = load i32, ptr %l8, !tbaa !23
  store i32 %t664, ptr %l240, !tbaa !23
  %t665 = load ptr, ptr %l4, !tbaa !29
  %t666 = load i32, ptr %l9, !tbaa !23
  %t669 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t665, i32 %t666)
  store i32 %t669, ptr %l243
  br label %bb164
bb164:
  %t670 = load ptr, ptr %l239, !tbaa !29
  %t671 = load i32, ptr %l240, !tbaa !23
  %t672 = load i32, ptr %l243, !tbaa !23
  %t673 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t670, i32 %t671, i32 %t672)
  store i1 %t673, ptr %l244
  br label %bb165
bb165:
  %t674 = load i1, ptr %l244, !tbaa !21
  %t675 = xor i1 %t674, true
  br i1 %t675, label %bb166, label %bb167
bb166:
  store %olang.scope zeroinitializer, ptr %s33
  %t677 = load ptr, ptr %l0, !tbaa !29
  store ptr %t677, ptr %l246, !tbaa !29
  %t678 = load i32, ptr %l1
  store i32 %t678, ptr %l247
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s34
  store ptr %s34room, ptr %s34
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s34, ptr %l247, i64 0)
  br label %bb168
bb167:
  br label %bb173
bb168:
  %t680 = load ptr, ptr %s34
  %t681 = getelementptr %olang.builder, ptr %s34, i32 0, i32 1
  %t682 = load i64, ptr %t681
  %t683 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t682)
  call void @olang_textcopy(ptr %t683, ptr %t680, i64 %t682)
  %t684 = insertvalue { i64, ptr } undef, i64 %t682, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t683, 1
  store { i64, ptr } %t685, ptr %l249, !tbaa !27
  %t686 = getelementptr %olang.builder, ptr %s34, i32 0, i32 3
  %t687 = load ptr, ptr %t686
  %t688 = icmp ne ptr %t687, null
  br i1 %t688, label %sbgrew.689, label %sbdone.690
sbgrew.689:
  call void @__olang_sb_done(ptr %s34)
  br label %sbdone.690
sbdone.690:
  %t691 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t692 = extractvalue { i64, ptr } %t691, 0
  %t693 = extractvalue { i64, ptr } %t691, 1
  %t694 = mul i64 %t692, 1
  %t695 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t694)
  call void @llvm.memcpy.p0.p0.i64(ptr %t695, ptr %t693, i64 %t694, i1 false)
  %t696 = insertvalue { i64, ptr } undef, i64 %t692, 0
  %t697 = insertvalue { i64, ptr } %t696, ptr %t695, 1
  %t699 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s33, { i64, ptr } %t697)
  store { i64, ptr } %t699, ptr %l251
  br label %bb169
bb169:
  %t700 = load ptr, ptr %l0, !tbaa !29
  %t701 = load i32, ptr %l7, !tbaa !23
  %t704 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s33, ptr %t700, i32 %t701)
  store { i64, ptr } %t704, ptr %l254
  br label %bb170
bb170:
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load i32, ptr %l9, !tbaa !23
  %t709 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s33, ptr %t705, i32 %t706)
  store { i64, ptr } %t709, ptr %l257
  br label %bb171
bb171:
  %t710 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t711 = extractvalue { i64, ptr } %t710, 1
  %t712 = extractvalue { i64, ptr } %t710, 0
  %t713 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t714 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t715 = add i64 %t712, %t714
  %t716 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t717 = extractvalue { i64, ptr } %t716, 1
  %t718 = extractvalue { i64, ptr } %t716, 0
  %t719 = add i64 %t715, %t718
  %t720 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t721 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t722 = add i64 %t719, %t721
  %t723 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t724 = extractvalue { i64, ptr } %t723, 1
  %t725 = extractvalue { i64, ptr } %t723, 0
  %t726 = add i64 %t722, %t725
  %t727 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t726)
  call void @olang_textcopy(ptr %t727, ptr %t711, i64 %t712)
  %t728 = getelementptr i8, ptr %t727, i64 %t712
  call void @olang_textcopy(ptr %t728, ptr %t713, i64 %t714)
  %t729 = getelementptr i8, ptr %t728, i64 %t714
  call void @olang_textcopy(ptr %t729, ptr %t717, i64 %t718)
  %t730 = getelementptr i8, ptr %t729, i64 %t718
  call void @olang_textcopy(ptr %t730, ptr %t720, i64 %t721)
  %t731 = getelementptr i8, ptr %t730, i64 %t721
  call void @olang_textcopy(ptr %t731, ptr %t724, i64 %t725)
  %t732 = insertvalue { i64, ptr } undef, i64 %t726, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t727, 1
  %t735 = extractvalue { i64, ptr } %t733, 0
  %t736 = extractvalue { i64, ptr } %t733, 1
  %t737 = mul i64 %t735, 1
  %t738 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t737)
  call void @llvm.memcpy.p0.p0.i64(ptr %t738, ptr %t736, i64 %t737, i1 false)
  %t739 = insertvalue { i64, ptr } undef, i64 %t735, 0
  %t740 = insertvalue { i64, ptr } %t739, ptr %t738, 1
  %t741 = load ptr, ptr %l246, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s33, ptr %t741, { i64, ptr } %t740)
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s33)
  br label %bb173
bb173:
  %t743 = load ptr, ptr %l4, !tbaa !29
  %t744 = load i32, ptr %l8, !tbaa !23
  %t747 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t743, i32 %t744)
  store i1 %t747, ptr %l262
  br label %bb174
bb174:
  %t748 = load i1, ptr %l262, !tbaa !21
  %t749 = xor i1 %t748, true
  br i1 %t749, label %bb175, label %bb176
bb175:
  %t751 = load i32, ptr %l8, !tbaa !23
  %t752 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t755 = icmp ne i32 %t751, %t752
  store i1 %t755, ptr %l264, !tbaa !21
  br label %bb177
bb176:
  store i1 false, ptr %l264, !tbaa !21
  br label %bb177
bb177:
  %t757 = load i1, ptr %l264, !tbaa !21
  br i1 %t757, label %bb178, label %bb179
bb178:
  %t758 = load i32, ptr %l1
  %t760 = trunc i64 13 to i32
  %t761 = icmp eq i32 %t758, %t760
  %t763 = xor i1 %t761, true
  store i1 %t763, ptr %l268, !tbaa !21
  br label %bb180
bb179:
  store i1 false, ptr %l268, !tbaa !21
  br label %bb180
bb180:
  %t765 = load i1, ptr %l268, !tbaa !21
  br i1 %t765, label %bb181, label %bb182
bb181:
  %t766 = load i32, ptr %l1
  %t768 = trunc i64 14 to i32
  %t769 = icmp eq i32 %t766, %t768
  %t771 = xor i1 %t769, true
  store i1 %t771, ptr %l272, !tbaa !21
  br label %bb183
bb182:
  store i1 false, ptr %l272, !tbaa !21
  br label %bb183
bb183:
  %t773 = load i1, ptr %l272, !tbaa !21
  br i1 %t773, label %bb184, label %bb185
bb184:
  store %olang.scope zeroinitializer, ptr %s36
  %t774 = load ptr, ptr %l0, !tbaa !29
  store ptr %t774, ptr %l276, !tbaa !29
  %t775 = load i32, ptr %l1
  store i32 %t775, ptr %l277
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s37
  store ptr %s37room, ptr %s37
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s37, ptr %l277, i64 0)
  br label %bb186
bb185:
  br label %bb190
bb186:
  %t777 = load ptr, ptr %s37
  %t778 = getelementptr %olang.builder, ptr %s37, i32 0, i32 1
  %t779 = load i64, ptr %t778
  %t780 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t779)
  call void @olang_textcopy(ptr %t780, ptr %t777, i64 %t779)
  %t781 = insertvalue { i64, ptr } undef, i64 %t779, 0
  %t782 = insertvalue { i64, ptr } %t781, ptr %t780, 1
  store { i64, ptr } %t782, ptr %l279, !tbaa !27
  %t783 = getelementptr %olang.builder, ptr %s37, i32 0, i32 3
  %t784 = load ptr, ptr %t783
  %t785 = icmp ne ptr %t784, null
  br i1 %t785, label %sbgrew.786, label %sbdone.787
sbgrew.786:
  call void @__olang_sb_done(ptr %s37)
  br label %sbdone.787
sbdone.787:
  %t788 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t789 = extractvalue { i64, ptr } %t788, 0
  %t790 = extractvalue { i64, ptr } %t788, 1
  %t791 = mul i64 %t789, 1
  %t792 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t791)
  call void @llvm.memcpy.p0.p0.i64(ptr %t792, ptr %t790, i64 %t791, i1 false)
  %t793 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t792, 1
  %t796 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s36, { i64, ptr } %t794)
  store { i64, ptr } %t796, ptr %l281
  br label %bb187
bb187:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t798 = load i32, ptr %l7, !tbaa !23
  %t801 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s36, ptr %t797, i32 %t798)
  store { i64, ptr } %t801, ptr %l284
  br label %bb188
bb188:
  %t802 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t803 = extractvalue { i64, ptr } %t802, 1
  %t804 = extractvalue { i64, ptr } %t802, 0
  %t805 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t806 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t807 = add i64 %t804, %t806
  %t808 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t809 = extractvalue { i64, ptr } %t808, 1
  %t810 = extractvalue { i64, ptr } %t808, 0
  %t811 = add i64 %t807, %t810
  %t812 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t811)
  call void @olang_textcopy(ptr %t812, ptr %t803, i64 %t804)
  %t813 = getelementptr i8, ptr %t812, i64 %t804
  call void @olang_textcopy(ptr %t813, ptr %t805, i64 %t806)
  %t814 = getelementptr i8, ptr %t813, i64 %t806
  call void @olang_textcopy(ptr %t814, ptr %t809, i64 %t810)
  %t815 = insertvalue { i64, ptr } undef, i64 %t811, 0
  %t816 = insertvalue { i64, ptr } %t815, ptr %t812, 1
  %t818 = extractvalue { i64, ptr } %t816, 0
  %t819 = extractvalue { i64, ptr } %t816, 1
  %t820 = mul i64 %t818, 1
  %t821 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t820)
  call void @llvm.memcpy.p0.p0.i64(ptr %t821, ptr %t819, i64 %t820, i1 false)
  %t822 = insertvalue { i64, ptr } undef, i64 %t818, 0
  %t823 = insertvalue { i64, ptr } %t822, ptr %t821, 1
  %t824 = load ptr, ptr %l276, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s36, ptr %t824, { i64, ptr } %t823)
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s36)
  br label %bb190
bb190:
  %t826 = load i32, ptr %l2, !tbaa !23
  %t827 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t830 = icmp ne i32 %t826, %t827
  br i1 %t830, label %bb191, label %bb192
bb191:
  store %olang.scope zeroinitializer, ptr %s39
  %t832 = load ptr, ptr %l0, !tbaa !29
  store ptr %t832, ptr %l290, !tbaa !29
  %t833 = load i32, ptr %l1
  store i32 %t833, ptr %l291
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s40
  store ptr %s40room, ptr %s40
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s40, ptr %l291, i64 0)
  br label %bb193
bb192:
  br label %bb197
bb193:
  %t835 = load ptr, ptr %s40
  %t836 = getelementptr %olang.builder, ptr %s40, i32 0, i32 1
  %t837 = load i64, ptr %t836
  %t838 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t837)
  call void @olang_textcopy(ptr %t838, ptr %t835, i64 %t837)
  %t839 = insertvalue { i64, ptr } undef, i64 %t837, 0
  %t840 = insertvalue { i64, ptr } %t839, ptr %t838, 1
  store { i64, ptr } %t840, ptr %l293, !tbaa !27
  %t841 = getelementptr %olang.builder, ptr %s40, i32 0, i32 3
  %t842 = load ptr, ptr %t841
  %t843 = icmp ne ptr %t842, null
  br i1 %t843, label %sbgrew.844, label %sbdone.845
sbgrew.844:
  call void @__olang_sb_done(ptr %s40)
  br label %sbdone.845
sbdone.845:
  %t846 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t847 = extractvalue { i64, ptr } %t846, 0
  %t848 = extractvalue { i64, ptr } %t846, 1
  %t849 = mul i64 %t847, 1
  %t850 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t849)
  call void @llvm.memcpy.p0.p0.i64(ptr %t850, ptr %t848, i64 %t849, i1 false)
  %t851 = insertvalue { i64, ptr } undef, i64 %t847, 0
  %t852 = insertvalue { i64, ptr } %t851, ptr %t850, 1
  %t854 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s39, { i64, ptr } %t852)
  store { i64, ptr } %t854, ptr %l295
  br label %bb194
bb194:
  %t855 = load ptr, ptr %l0, !tbaa !29
  %t856 = load i32, ptr %l2, !tbaa !23
  %t859 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s39, ptr %t855, i32 %t856)
  store { i64, ptr } %t859, ptr %l298
  br label %bb195
bb195:
  %t860 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t861 = extractvalue { i64, ptr } %t860, 1
  %t862 = extractvalue { i64, ptr } %t860, 0
  %t863 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t864 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t865 = add i64 %t862, %t864
  %t866 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 1
  %t868 = extractvalue { i64, ptr } %t866, 0
  %t869 = add i64 %t865, %t868
  %t870 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t869)
  call void @olang_textcopy(ptr %t870, ptr %t861, i64 %t862)
  %t871 = getelementptr i8, ptr %t870, i64 %t862
  call void @olang_textcopy(ptr %t871, ptr %t863, i64 %t864)
  %t872 = getelementptr i8, ptr %t871, i64 %t864
  call void @olang_textcopy(ptr %t872, ptr %t867, i64 %t868)
  %t873 = insertvalue { i64, ptr } undef, i64 %t869, 0
  %t874 = insertvalue { i64, ptr } %t873, ptr %t870, 1
  %t876 = extractvalue { i64, ptr } %t874, 0
  %t877 = extractvalue { i64, ptr } %t874, 1
  %t878 = mul i64 %t876, 1
  %t879 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t878)
  call void @llvm.memcpy.p0.p0.i64(ptr %t879, ptr %t877, i64 %t878, i1 false)
  %t880 = insertvalue { i64, ptr } undef, i64 %t876, 0
  %t881 = insertvalue { i64, ptr } %t880, ptr %t879, 1
  %t882 = load ptr, ptr %l290, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s39, ptr %t882, { i64, ptr } %t881)
  br label %bb196
bb196:
  call void @__olang_scope_close(ptr %s39)
  br label %bb197
bb197:
  br label %bb475
bb198:
  %t884 = load i32, ptr %l1
  %t886 = trunc i64 19 to i32
  %t887 = icmp eq i32 %t884, %t886
  br i1 %t887, label %bb199, label %bb200
bb199:
  br label %bb201
bb200:
  br label %bb234
bb201:
  %t889 = load ptr, ptr %l0, !tbaa !29
  store ptr %t889, ptr %l303, !tbaa !29
  %t890 = load ptr, ptr %l0, !tbaa !29
  %t891 = load %"compiler/mir:Range", ptr %l3
  %t894 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t890, %"compiler/mir:Range" %t891, i64 1)
  store { i64, [4 x i64] } %t894, ptr %l306
  br label %bb202
bb202:
  %t895 = load ptr, ptr %l303, !tbaa !29
  %t896 = load { i64, [4 x i64] }, ptr %l306
  %t897 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t895, { i64, [4 x i64] } %t896)
  store i32 %t897, ptr %l307
  br label %bb203
bb203:
  %t898 = load i32, ptr %l307, !tbaa !23
  store i32 %t898, ptr %l10, !tbaa !23
  %t899 = load ptr, ptr %l4, !tbaa !29
  %t900 = load i32, ptr %l8, !tbaa !23
  %t903 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t899, i32 %t900)
  store i32 %t903, ptr %l310
  br label %bb204
bb204:
  %t904 = load i32, ptr %l310
  store i32 %t904, ptr %l11
  %t905 = load ptr, ptr %l4, !tbaa !29
  %t906 = load i32, ptr %l10, !tbaa !23
  %t909 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t905, i32 %t906)
  store i32 %t909, ptr %l313
  br label %bb205
bb205:
  %t910 = load i32, ptr %l313, !tbaa !23
  store i32 %t910, ptr %l12, !tbaa !23
  %t911 = load ptr, ptr %l4, !tbaa !29
  %t912 = load i32, ptr %l12, !tbaa !23
  %t913 = load i32, ptr %l8, !tbaa !23
  %t917 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t911, i32 %t912, i32 %t913)
  store i1 %t917, ptr %l317
  br label %bb206
bb206:
  %t918 = load i1, ptr %l317, !tbaa !21
  store i1 %t918, ptr %l13, !tbaa !21
  %t919 = load i32, ptr %l11
  %t921 = trunc i64 20 to i32
  %t922 = icmp eq i32 %t919, %t921
  br i1 %t922, label %bb207, label %bb208
bb207:
  %t924 = load ptr, ptr %l4, !tbaa !29
  %t925 = load i32, ptr %l12, !tbaa !23
  %t928 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t924, i32 %t925)
  store i1 %t928, ptr %l323
  br label %bb209
bb208:
  store i1 false, ptr %l320, !tbaa !21
  br label %bb210
bb209:
  %t929 = load i1, ptr %l323, !tbaa !21
  store i1 %t929, ptr %l320, !tbaa !21
  br label %bb210
bb210:
  %t930 = load i1, ptr %l320, !tbaa !21
  br i1 %t930, label %bb211, label %bb212
bb211:
  %t931 = load ptr, ptr %l0, !tbaa !29
  store ptr %t931, ptr %l324, !tbaa !29
  %t932 = load ptr, ptr %l4, !tbaa !29
  %t933 = load i32, ptr %l8, !tbaa !23
  %t936 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t932, i32 %t933)
  store i32 %t936, ptr %l327
  br label %bb213
bb212:
  br label %bb216
bb213:
  %t937 = load ptr, ptr %l4, !tbaa !29
  %t938 = load i32, ptr %l12, !tbaa !23
  %t941 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t937, i32 %t938)
  store i32 %t941, ptr %l330
  br label %bb214
bb214:
  %t942 = load ptr, ptr %l324, !tbaa !29
  %t943 = load i32, ptr %l327, !tbaa !23
  %t944 = load i32, ptr %l330, !tbaa !23
  %t945 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t942, i32 %t943, i32 %t944)
  store i1 %t945, ptr %l331
  br label %bb215
bb215:
  %t946 = load i1, ptr %l331, !tbaa !21
  store i1 %t946, ptr %l13, !tbaa !21
  br label %bb216
bb216:
  %t947 = load i32, ptr %l11
  %t949 = trunc i64 20 to i32
  %t950 = icmp eq i32 %t947, %t949
  %t952 = xor i1 %t950, true
  br i1 %t952, label %bb217, label %bb218
bb217:
  %t954 = load i32, ptr %l11
  %t956 = trunc i64 21 to i32
  %t957 = icmp eq i32 %t954, %t956
  %t959 = xor i1 %t957, true
  store i1 %t959, ptr %l335, !tbaa !21
  br label %bb219
bb218:
  store i1 false, ptr %l335, !tbaa !21
  br label %bb219
bb219:
  %t961 = load i1, ptr %l335, !tbaa !21
  br i1 %t961, label %bb220, label %bb221
bb220:
  store i1 true, ptr %l339, !tbaa !21
  br label %bb222
bb221:
  %t962 = load i1, ptr %l13, !tbaa !21
  %t964 = xor i1 %t962, true
  store i1 %t964, ptr %l339, !tbaa !21
  br label %bb222
bb222:
  %t966 = load i1, ptr %l339, !tbaa !21
  br i1 %t966, label %bb223, label %bb224
bb223:
  store %olang.scope zeroinitializer, ptr %s44
  %t967 = load ptr, ptr %l0, !tbaa !29
  store ptr %t967, ptr %l342, !tbaa !29
  %t968 = load ptr, ptr %l0, !tbaa !29
  %t969 = load i32, ptr %l7, !tbaa !23
  %t972 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s44, ptr %t968, i32 %t969)
  store { i64, ptr } %t972, ptr %l345
  br label %bb225
bb224:
  br label %bb228
bb225:
  %t973 = load ptr, ptr %l0, !tbaa !29
  %t974 = load i32, ptr %l10, !tbaa !23
  %t977 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s44, ptr %t973, i32 %t974)
  store { i64, ptr } %t977, ptr %l348
  br label %bb226
bb226:
  %t978 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t979 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t980 = load { i64, ptr }, ptr %l345, !tbaa !27
  %t981 = extractvalue { i64, ptr } %t980, 1
  %t982 = extractvalue { i64, ptr } %t980, 0
  %t983 = add i64 %t979, %t982
  %t984 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t985 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t986 = add i64 %t983, %t985
  %t987 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t988 = extractvalue { i64, ptr } %t987, 1
  %t989 = extractvalue { i64, ptr } %t987, 0
  %t990 = add i64 %t986, %t989
  %t991 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t990)
  call void @olang_textcopy(ptr %t991, ptr %t978, i64 %t979)
  %t992 = getelementptr i8, ptr %t991, i64 %t979
  call void @olang_textcopy(ptr %t992, ptr %t981, i64 %t982)
  %t993 = getelementptr i8, ptr %t992, i64 %t982
  call void @olang_textcopy(ptr %t993, ptr %t984, i64 %t985)
  %t994 = getelementptr i8, ptr %t993, i64 %t985
  call void @olang_textcopy(ptr %t994, ptr %t988, i64 %t989)
  %t995 = insertvalue { i64, ptr } undef, i64 %t990, 0
  %t996 = insertvalue { i64, ptr } %t995, ptr %t991, 1
  %t998 = extractvalue { i64, ptr } %t996, 0
  %t999 = extractvalue { i64, ptr } %t996, 1
  %t1000 = mul i64 %t998, 1
  %t1001 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1000)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1001, ptr %t999, i64 %t1000, i1 false)
  %t1002 = insertvalue { i64, ptr } undef, i64 %t998, 0
  %t1003 = insertvalue { i64, ptr } %t1002, ptr %t1001, 1
  %t1004 = load ptr, ptr %l342, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s44, ptr %t1004, { i64, ptr } %t1003)
  br label %bb227
bb227:
  call void @__olang_scope_close(ptr %s44)
  br label %bb228
bb228:
  %t1006 = load i32, ptr %l2, !tbaa !23
  %t1007 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1010 = icmp ne i32 %t1006, %t1007
  br i1 %t1010, label %bb229, label %bb230
bb229:
  store %olang.scope zeroinitializer, ptr %s46
  %t1012 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1012, ptr %l354, !tbaa !29
  %t1013 = load ptr, ptr %l0, !tbaa !29
  %t1014 = load i32, ptr %l2, !tbaa !23
  %t1017 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s46, ptr %t1013, i32 %t1014)
  store { i64, ptr } %t1017, ptr %l357
  br label %bb231
bb230:
  br label %bb233
bb231:
  %t1018 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t1019 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t1020 = load { i64, ptr }, ptr %l357, !tbaa !27
  %t1021 = extractvalue { i64, ptr } %t1020, 1
  %t1022 = extractvalue { i64, ptr } %t1020, 0
  %t1023 = add i64 %t1019, %t1022
  %t1024 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1023)
  call void @olang_textcopy(ptr %t1024, ptr %t1018, i64 %t1019)
  %t1025 = getelementptr i8, ptr %t1024, i64 %t1019
  call void @olang_textcopy(ptr %t1025, ptr %t1021, i64 %t1022)
  %t1026 = insertvalue { i64, ptr } undef, i64 %t1023, 0
  %t1027 = insertvalue { i64, ptr } %t1026, ptr %t1024, 1
  %t1029 = extractvalue { i64, ptr } %t1027, 0
  %t1030 = extractvalue { i64, ptr } %t1027, 1
  %t1031 = mul i64 %t1029, 1
  %t1032 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1031)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1032, ptr %t1030, i64 %t1031, i1 false)
  %t1033 = insertvalue { i64, ptr } undef, i64 %t1029, 0
  %t1034 = insertvalue { i64, ptr } %t1033, ptr %t1032, 1
  %t1035 = load ptr, ptr %l354, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s46, ptr %t1035, { i64, ptr } %t1034)
  br label %bb232
bb232:
  call void @__olang_scope_close(ptr %s46)
  br label %bb233
bb233:
  br label %bb475
bb234:
  %t1037 = load i32, ptr %l1
  %t1039 = trunc i64 20 to i32
  %t1040 = icmp eq i32 %t1037, %t1039
  br i1 %t1040, label %bb235, label %bb236
bb235:
  br label %bb239
bb236:
  %t1042 = load i32, ptr %l1
  %t1044 = trunc i64 21 to i32
  %t1045 = icmp eq i32 %t1042, %t1044
  br i1 %t1045, label %bb237, label %bb238
bb237:
  br label %bb239
bb238:
  br label %bb240
bb239:
  br label %bb475
bb240:
  %t1047 = load i32, ptr %l1
  %t1049 = trunc i64 22 to i32
  %t1050 = icmp eq i32 %t1047, %t1049
  br i1 %t1050, label %bb241, label %bb242
bb241:
  br label %bb243
bb242:
  br label %bb260
bb243:
  %t1052 = load ptr, ptr %l4, !tbaa !29
  %t1053 = load i32, ptr %l8, !tbaa !23
  %t1056 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t1052, i32 %t1053)
  store i1 %t1056, ptr %l368
  br label %bb244
bb244:
  %t1057 = load i1, ptr %l368, !tbaa !21
  br i1 %t1057, label %bb245, label %bb246
bb245:
  %t1058 = load ptr, ptr %l4, !tbaa !29
  %t1059 = load i32, ptr %l8, !tbaa !23
  %t1062 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1058, i32 %t1059)
  store i32 %t1062, ptr %l372
  br label %bb247
bb246:
  %t1063 = load i32, ptr %l7, !tbaa !23
  store i32 %t1063, ptr %l369, !tbaa !23
  br label %bb248
bb247:
  %t1065 = load i32, ptr %l372, !tbaa !23
  store i32 %t1065, ptr %l369, !tbaa !23
  br label %bb248
bb248:
  %t1066 = load i32, ptr %l369, !tbaa !23
  %t1067 = load ptr, ptr %l0, !tbaa !29
  %t1071 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t1067, i32 %t1066)
  store i32 %t1071, ptr %l376
  br label %bb249
bb249:
  %t1072 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1073 = load i32, ptr %l376, !tbaa !23
  %t1075 = icmp eq i32 %t1073, %t1072
  br i1 %t1075, label %bb250, label %bb251
bb250:
  store %olang.scope zeroinitializer, ptr %s50
  %t1077 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1077, ptr %l379, !tbaa !29
  %t1078 = load ptr, ptr %l0, !tbaa !29
  %t1079 = load i32, ptr %l7, !tbaa !23
  %t1082 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s50, ptr %t1078, i32 %t1079)
  store { i64, ptr } %t1082, ptr %l382
  br label %bb252
bb251:
  br label %bb254
bb252:
  %t1083 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t1084 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t1085 = load { i64, ptr }, ptr %l382, !tbaa !27
  %t1086 = extractvalue { i64, ptr } %t1085, 1
  %t1087 = extractvalue { i64, ptr } %t1085, 0
  %t1088 = add i64 %t1084, %t1087
  %t1089 = call ptr @__olang_scope_alloc(ptr %s50, i64 %t1088)
  call void @olang_textcopy(ptr %t1089, ptr %t1083, i64 %t1084)
  %t1090 = getelementptr i8, ptr %t1089, i64 %t1084
  call void @olang_textcopy(ptr %t1090, ptr %t1086, i64 %t1087)
  %t1091 = insertvalue { i64, ptr } undef, i64 %t1088, 0
  %t1092 = insertvalue { i64, ptr } %t1091, ptr %t1089, 1
  %t1094 = extractvalue { i64, ptr } %t1092, 0
  %t1095 = extractvalue { i64, ptr } %t1092, 1
  %t1096 = mul i64 %t1094, 1
  %t1097 = call ptr @__olang_scope_alloc(ptr %s50, i64 %t1096)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1097, ptr %t1095, i64 %t1096, i1 false)
  %t1098 = insertvalue { i64, ptr } undef, i64 %t1094, 0
  %t1099 = insertvalue { i64, ptr } %t1098, ptr %t1097, 1
  %t1100 = load ptr, ptr %l379, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s50, ptr %t1100, { i64, ptr } %t1099)
  br label %bb253
bb253:
  call void @__olang_scope_close(ptr %s50)
  br label %bb254
bb254:
  %t1102 = load i32, ptr %l2, !tbaa !23
  %t1103 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1106 = icmp ne i32 %t1102, %t1103
  br i1 %t1106, label %bb255, label %bb256
bb255:
  store %olang.scope zeroinitializer, ptr %s52
  %t1108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1108, ptr %l388, !tbaa !29
  %t1109 = load ptr, ptr %l0, !tbaa !29
  %t1110 = load i32, ptr %l2, !tbaa !23
  %t1113 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s52, ptr %t1109, i32 %t1110)
  store { i64, ptr } %t1113, ptr %l391
  br label %bb257
bb256:
  br label %bb259
bb257:
  %t1114 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t1115 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t1116 = load { i64, ptr }, ptr %l391, !tbaa !27
  %t1117 = extractvalue { i64, ptr } %t1116, 1
  %t1118 = extractvalue { i64, ptr } %t1116, 0
  %t1119 = add i64 %t1115, %t1118
  %t1120 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1119)
  call void @olang_textcopy(ptr %t1120, ptr %t1114, i64 %t1115)
  %t1121 = getelementptr i8, ptr %t1120, i64 %t1115
  call void @olang_textcopy(ptr %t1121, ptr %t1117, i64 %t1118)
  %t1122 = insertvalue { i64, ptr } undef, i64 %t1119, 0
  %t1123 = insertvalue { i64, ptr } %t1122, ptr %t1120, 1
  %t1125 = extractvalue { i64, ptr } %t1123, 0
  %t1126 = extractvalue { i64, ptr } %t1123, 1
  %t1127 = mul i64 %t1125, 1
  %t1128 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1128, ptr %t1126, i64 %t1127, i1 false)
  %t1129 = insertvalue { i64, ptr } undef, i64 %t1125, 0
  %t1130 = insertvalue { i64, ptr } %t1129, ptr %t1128, 1
  %t1131 = load ptr, ptr %l388, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s52, ptr %t1131, { i64, ptr } %t1130)
  br label %bb258
bb258:
  call void @__olang_scope_close(ptr %s52)
  br label %bb259
bb259:
  br label %bb475
bb260:
  %t1133 = load i32, ptr %l1
  %t1135 = trunc i64 31 to i32
  %t1136 = icmp eq i32 %t1133, %t1135
  br i1 %t1136, label %bb261, label %bb262
bb261:
  br label %bb267
bb262:
  %t1138 = load i32, ptr %l1
  %t1140 = trunc i64 32 to i32
  %t1141 = icmp eq i32 %t1138, %t1140
  br i1 %t1141, label %bb263, label %bb264
bb263:
  br label %bb267
bb264:
  %t1143 = load i32, ptr %l1
  %t1145 = trunc i64 33 to i32
  %t1146 = icmp eq i32 %t1143, %t1145
  br i1 %t1146, label %bb265, label %bb266
bb265:
  br label %bb267
bb266:
  br label %bb283
bb267:
  %t1148 = load ptr, ptr %l4, !tbaa !29
  %t1149 = load i32, ptr %l8, !tbaa !23
  %t1152 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t1148, i32 %t1149)
  store i1 %t1152, ptr %l402
  br label %bb268
bb268:
  %t1153 = load i1, ptr %l402, !tbaa !21
  %t1154 = xor i1 %t1153, true
  br i1 %t1154, label %bb269, label %bb270
bb269:
  store %olang.scope zeroinitializer, ptr %s55
  %t1156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1156, ptr %l404, !tbaa !29
  %t1157 = load i32, ptr %l1
  store i32 %t1157, ptr %l405
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s56
  store ptr %s56room, ptr %s56
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s56, ptr %l405, i64 0)
  br label %bb271
bb270:
  br label %bb275
bb271:
  %t1159 = load ptr, ptr %s56
  %t1160 = getelementptr %olang.builder, ptr %s56, i32 0, i32 1
  %t1161 = load i64, ptr %t1160
  %t1162 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1161)
  call void @olang_textcopy(ptr %t1162, ptr %t1159, i64 %t1161)
  %t1163 = insertvalue { i64, ptr } undef, i64 %t1161, 0
  %t1164 = insertvalue { i64, ptr } %t1163, ptr %t1162, 1
  store { i64, ptr } %t1164, ptr %l407, !tbaa !27
  %t1165 = getelementptr %olang.builder, ptr %s56, i32 0, i32 3
  %t1166 = load ptr, ptr %t1165
  %t1167 = icmp ne ptr %t1166, null
  br i1 %t1167, label %sbgrew.1168, label %sbdone.1169
sbgrew.1168:
  call void @__olang_sb_done(ptr %s56)
  br label %sbdone.1169
sbdone.1169:
  %t1170 = load { i64, ptr }, ptr %l407, !tbaa !27
  %t1171 = extractvalue { i64, ptr } %t1170, 0
  %t1172 = extractvalue { i64, ptr } %t1170, 1
  %t1173 = mul i64 %t1171, 1
  %t1174 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1174, ptr %t1172, i64 %t1173, i1 false)
  %t1175 = insertvalue { i64, ptr } undef, i64 %t1171, 0
  %t1176 = insertvalue { i64, ptr } %t1175, ptr %t1174, 1
  %t1178 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s55, { i64, ptr } %t1176)
  store { i64, ptr } %t1178, ptr %l409
  br label %bb272
bb272:
  %t1179 = load ptr, ptr %l0, !tbaa !29
  %t1180 = load i32, ptr %l7, !tbaa !23
  %t1183 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s55, ptr %t1179, i32 %t1180)
  store { i64, ptr } %t1183, ptr %l412
  br label %bb273
bb273:
  %t1184 = load { i64, ptr }, ptr %l409, !tbaa !27
  %t1185 = extractvalue { i64, ptr } %t1184, 1
  %t1186 = extractvalue { i64, ptr } %t1184, 0
  %t1187 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t1188 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t1189 = add i64 %t1186, %t1188
  %t1190 = load { i64, ptr }, ptr %l412, !tbaa !27
  %t1191 = extractvalue { i64, ptr } %t1190, 1
  %t1192 = extractvalue { i64, ptr } %t1190, 0
  %t1193 = add i64 %t1189, %t1192
  %t1194 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1193)
  call void @olang_textcopy(ptr %t1194, ptr %t1185, i64 %t1186)
  %t1195 = getelementptr i8, ptr %t1194, i64 %t1186
  call void @olang_textcopy(ptr %t1195, ptr %t1187, i64 %t1188)
  %t1196 = getelementptr i8, ptr %t1195, i64 %t1188
  call void @olang_textcopy(ptr %t1196, ptr %t1191, i64 %t1192)
  %t1197 = insertvalue { i64, ptr } undef, i64 %t1193, 0
  %t1198 = insertvalue { i64, ptr } %t1197, ptr %t1194, 1
  %t1200 = extractvalue { i64, ptr } %t1198, 0
  %t1201 = extractvalue { i64, ptr } %t1198, 1
  %t1202 = mul i64 %t1200, 1
  %t1203 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1202)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1203, ptr %t1201, i64 %t1202, i1 false)
  %t1204 = insertvalue { i64, ptr } undef, i64 %t1200, 0
  %t1205 = insertvalue { i64, ptr } %t1204, ptr %t1203, 1
  %t1206 = load ptr, ptr %l404, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s55, ptr %t1206, { i64, ptr } %t1205)
  br label %bb274
bb274:
  call void @__olang_scope_close(ptr %s55)
  br label %bb275
bb275:
  %t1208 = load i32, ptr %l2, !tbaa !23
  %t1209 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1212 = icmp ne i32 %t1208, %t1209
  br i1 %t1212, label %bb276, label %bb277
bb276:
  store %olang.scope zeroinitializer, ptr %s58
  %t1214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1214, ptr %l418, !tbaa !29
  %t1215 = load i32, ptr %l1
  store i32 %t1215, ptr %l419
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s59
  store ptr %s59room, ptr %s59
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s59, ptr %l419, i64 0)
  br label %bb278
bb277:
  br label %bb282
bb278:
  %t1217 = load ptr, ptr %s59
  %t1218 = getelementptr %olang.builder, ptr %s59, i32 0, i32 1
  %t1219 = load i64, ptr %t1218
  %t1220 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t1219)
  call void @olang_textcopy(ptr %t1220, ptr %t1217, i64 %t1219)
  %t1221 = insertvalue { i64, ptr } undef, i64 %t1219, 0
  %t1222 = insertvalue { i64, ptr } %t1221, ptr %t1220, 1
  store { i64, ptr } %t1222, ptr %l421, !tbaa !27
  %t1223 = getelementptr %olang.builder, ptr %s59, i32 0, i32 3
  %t1224 = load ptr, ptr %t1223
  %t1225 = icmp ne ptr %t1224, null
  br i1 %t1225, label %sbgrew.1226, label %sbdone.1227
sbgrew.1226:
  call void @__olang_sb_done(ptr %s59)
  br label %sbdone.1227
sbdone.1227:
  %t1228 = load { i64, ptr }, ptr %l421, !tbaa !27
  %t1229 = extractvalue { i64, ptr } %t1228, 0
  %t1230 = extractvalue { i64, ptr } %t1228, 1
  %t1231 = mul i64 %t1229, 1
  %t1232 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t1231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1232, ptr %t1230, i64 %t1231, i1 false)
  %t1233 = insertvalue { i64, ptr } undef, i64 %t1229, 0
  %t1234 = insertvalue { i64, ptr } %t1233, ptr %t1232, 1
  %t1236 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s58, { i64, ptr } %t1234)
  store { i64, ptr } %t1236, ptr %l423
  br label %bb279
bb279:
  %t1237 = load ptr, ptr %l0, !tbaa !29
  %t1238 = load i32, ptr %l2, !tbaa !23
  %t1241 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s58, ptr %t1237, i32 %t1238)
  store { i64, ptr } %t1241, ptr %l426
  br label %bb280
bb280:
  %t1242 = load { i64, ptr }, ptr %l423, !tbaa !27
  %t1243 = extractvalue { i64, ptr } %t1242, 1
  %t1244 = extractvalue { i64, ptr } %t1242, 0
  %t1245 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t1246 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t1247 = add i64 %t1244, %t1246
  %t1248 = load { i64, ptr }, ptr %l426, !tbaa !27
  %t1249 = extractvalue { i64, ptr } %t1248, 1
  %t1250 = extractvalue { i64, ptr } %t1248, 0
  %t1251 = add i64 %t1247, %t1250
  %t1252 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t1251)
  call void @olang_textcopy(ptr %t1252, ptr %t1243, i64 %t1244)
  %t1253 = getelementptr i8, ptr %t1252, i64 %t1244
  call void @olang_textcopy(ptr %t1253, ptr %t1245, i64 %t1246)
  %t1254 = getelementptr i8, ptr %t1253, i64 %t1246
  call void @olang_textcopy(ptr %t1254, ptr %t1249, i64 %t1250)
  %t1255 = insertvalue { i64, ptr } undef, i64 %t1251, 0
  %t1256 = insertvalue { i64, ptr } %t1255, ptr %t1252, 1
  %t1258 = extractvalue { i64, ptr } %t1256, 0
  %t1259 = extractvalue { i64, ptr } %t1256, 1
  %t1260 = mul i64 %t1258, 1
  %t1261 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t1260)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1261, ptr %t1259, i64 %t1260, i1 false)
  %t1262 = insertvalue { i64, ptr } undef, i64 %t1258, 0
  %t1263 = insertvalue { i64, ptr } %t1262, ptr %t1261, 1
  %t1264 = load ptr, ptr %l418, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s58, ptr %t1264, { i64, ptr } %t1263)
  br label %bb281
bb281:
  call void @__olang_scope_close(ptr %s58)
  br label %bb282
bb282:
  br label %bb475
bb283:
  %t1266 = load i32, ptr %l1
  %t1268 = trunc i64 36 to i32
  %t1269 = icmp eq i32 %t1266, %t1268
  br i1 %t1269, label %bb284, label %bb285
bb284:
  br label %bb286
bb285:
  br label %bb294
bb286:
  %t1271 = load ptr, ptr %l4, !tbaa !29
  %t1272 = load i32, ptr %l8, !tbaa !23
  %t1275 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t1271, i32 %t1272)
  store i1 %t1275, ptr %l433
  br label %bb287
bb287:
  %t1276 = load i1, ptr %l433, !tbaa !21
  %t1277 = xor i1 %t1276, true
  br i1 %t1277, label %bb288, label %bb289
bb288:
  store %olang.scope zeroinitializer, ptr %s62
  %t1279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1279, ptr %l435, !tbaa !29
  %t1280 = load ptr, ptr %l0, !tbaa !29
  %t1281 = load i32, ptr %l7, !tbaa !23
  %t1284 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s62, ptr %t1280, i32 %t1281)
  store { i64, ptr } %t1284, ptr %l438
  br label %bb290
bb289:
  br label %bb292
bb290:
  %t1285 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t1286 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t1287 = load { i64, ptr }, ptr %l438, !tbaa !27
  %t1288 = extractvalue { i64, ptr } %t1287, 1
  %t1289 = extractvalue { i64, ptr } %t1287, 0
  %t1290 = add i64 %t1286, %t1289
  %t1291 = call ptr @__olang_scope_alloc(ptr %s62, i64 %t1290)
  call void @olang_textcopy(ptr %t1291, ptr %t1285, i64 %t1286)
  %t1292 = getelementptr i8, ptr %t1291, i64 %t1286
  call void @olang_textcopy(ptr %t1292, ptr %t1288, i64 %t1289)
  %t1293 = insertvalue { i64, ptr } undef, i64 %t1290, 0
  %t1294 = insertvalue { i64, ptr } %t1293, ptr %t1291, 1
  %t1296 = extractvalue { i64, ptr } %t1294, 0
  %t1297 = extractvalue { i64, ptr } %t1294, 1
  %t1298 = mul i64 %t1296, 1
  %t1299 = call ptr @__olang_scope_alloc(ptr %s62, i64 %t1298)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1299, ptr %t1297, i64 %t1298, i1 false)
  %t1300 = insertvalue { i64, ptr } undef, i64 %t1296, 0
  %t1301 = insertvalue { i64, ptr } %t1300, ptr %t1299, 1
  %t1302 = load ptr, ptr %l435, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s62, ptr %t1302, { i64, ptr } %t1301)
  br label %bb291
bb291:
  call void @__olang_scope_close(ptr %s62)
  br label %bb292
bb292:
  %t1304 = load ptr, ptr %l0, !tbaa !29
  %t1305 = load i32, ptr %l1
  %t1306 = load %"compiler/mir:Range", ptr %l3
  %t1307 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %t1304, i32 %t1305, %"compiler/mir:Range" %t1306, i32 %t1307)
  br label %bb293
bb293:
  br label %bb475
bb294:
  %t1312 = load i32, ptr %l1
  %t1314 = trunc i64 34 to i32
  %t1315 = icmp eq i32 %t1312, %t1314
  br i1 %t1315, label %bb295, label %bb296
bb295:
  br label %bb299
bb296:
  %t1317 = load i32, ptr %l1
  %t1319 = trunc i64 35 to i32
  %t1320 = icmp eq i32 %t1317, %t1319
  br i1 %t1320, label %bb297, label %bb298
bb297:
  br label %bb299
bb298:
  br label %bb323
bb299:
  %t1322 = load ptr, ptr %l4, !tbaa !29
  %t1323 = load i32, ptr %l8, !tbaa !23
  %t1326 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t1322, i32 %t1323)
  store i1 %t1326, ptr %l451
  br label %bb300
bb300:
  %t1327 = load i1, ptr %l451, !tbaa !21
  %t1328 = xor i1 %t1327, true
  br i1 %t1328, label %bb301, label %bb302
bb301:
  store i1 true, ptr %l453, !tbaa !21
  br label %bb306
bb302:
  %t1330 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1330, ptr %l454, !tbaa !29
  %t1331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1331, ptr %l455, !tbaa !29
  %t1332 = load ptr, ptr %l0, !tbaa !29
  %t1333 = load %"compiler/mir:Range", ptr %l3
  %t1336 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t1332, %"compiler/mir:Range" %t1333, i64 1)
  store { i64, [4 x i64] } %t1336, ptr %l458
  br label %bb303
bb303:
  %t1337 = load ptr, ptr %l455, !tbaa !29
  %t1338 = load { i64, [4 x i64] }, ptr %l458
  %t1339 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t1337, { i64, [4 x i64] } %t1338)
  store i32 %t1339, ptr %l459
  br label %bb304
bb304:
  %t1340 = load ptr, ptr %l454, !tbaa !29
  %t1341 = load i32, ptr %l459, !tbaa !23
  %t1342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1340, i32 %t1341)
  store i32 %t1342, ptr %l460
  br label %bb305
bb305:
  %t1343 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1344 = load i32, ptr %l460, !tbaa !23
  %t1346 = icmp ne i32 %t1344, %t1343
  store i1 %t1346, ptr %l453, !tbaa !21
  br label %bb306
bb306:
  %t1348 = load i1, ptr %l453, !tbaa !21
  br i1 %t1348, label %bb307, label %bb308
bb307:
  store %olang.scope zeroinitializer, ptr %s65
  %t1349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1349, ptr %l463, !tbaa !29
  %t1350 = load i32, ptr %l1
  store i32 %t1350, ptr %l464
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s66
  store ptr %s66room, ptr %s66
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s66, ptr %l464, i64 0)
  br label %bb309
bb308:
  br label %bb313
bb309:
  %t1352 = load ptr, ptr %s66
  %t1353 = getelementptr %olang.builder, ptr %s66, i32 0, i32 1
  %t1354 = load i64, ptr %t1353
  %t1355 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1354)
  call void @olang_textcopy(ptr %t1355, ptr %t1352, i64 %t1354)
  %t1356 = insertvalue { i64, ptr } undef, i64 %t1354, 0
  %t1357 = insertvalue { i64, ptr } %t1356, ptr %t1355, 1
  store { i64, ptr } %t1357, ptr %l466, !tbaa !27
  %t1358 = getelementptr %olang.builder, ptr %s66, i32 0, i32 3
  %t1359 = load ptr, ptr %t1358
  %t1360 = icmp ne ptr %t1359, null
  br i1 %t1360, label %sbgrew.1361, label %sbdone.1362
sbgrew.1361:
  call void @__olang_sb_done(ptr %s66)
  br label %sbdone.1362
sbdone.1362:
  %t1363 = load { i64, ptr }, ptr %l466, !tbaa !27
  %t1364 = extractvalue { i64, ptr } %t1363, 0
  %t1365 = extractvalue { i64, ptr } %t1363, 1
  %t1366 = mul i64 %t1364, 1
  %t1367 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1366)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1367, ptr %t1365, i64 %t1366, i1 false)
  %t1368 = insertvalue { i64, ptr } undef, i64 %t1364, 0
  %t1369 = insertvalue { i64, ptr } %t1368, ptr %t1367, 1
  %t1371 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s65, { i64, ptr } %t1369)
  store { i64, ptr } %t1371, ptr %l468
  br label %bb310
bb310:
  %t1372 = load ptr, ptr %l0, !tbaa !29
  %t1373 = load i32, ptr %l7, !tbaa !23
  %t1376 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s65, ptr %t1372, i32 %t1373)
  store { i64, ptr } %t1376, ptr %l471
  br label %bb311
bb311:
  %t1377 = load { i64, ptr }, ptr %l468, !tbaa !27
  %t1378 = extractvalue { i64, ptr } %t1377, 1
  %t1379 = extractvalue { i64, ptr } %t1377, 0
  %t1380 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t1381 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t1382 = add i64 %t1379, %t1381
  %t1383 = load { i64, ptr }, ptr %l471, !tbaa !27
  %t1384 = extractvalue { i64, ptr } %t1383, 1
  %t1385 = extractvalue { i64, ptr } %t1383, 0
  %t1386 = add i64 %t1382, %t1385
  %t1387 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1386)
  call void @olang_textcopy(ptr %t1387, ptr %t1378, i64 %t1379)
  %t1388 = getelementptr i8, ptr %t1387, i64 %t1379
  call void @olang_textcopy(ptr %t1388, ptr %t1380, i64 %t1381)
  %t1389 = getelementptr i8, ptr %t1388, i64 %t1381
  call void @olang_textcopy(ptr %t1389, ptr %t1384, i64 %t1385)
  %t1390 = insertvalue { i64, ptr } undef, i64 %t1386, 0
  %t1391 = insertvalue { i64, ptr } %t1390, ptr %t1387, 1
  %t1393 = extractvalue { i64, ptr } %t1391, 0
  %t1394 = extractvalue { i64, ptr } %t1391, 1
  %t1395 = mul i64 %t1393, 1
  %t1396 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1395)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1396, ptr %t1394, i64 %t1395, i1 false)
  %t1397 = insertvalue { i64, ptr } undef, i64 %t1393, 0
  %t1398 = insertvalue { i64, ptr } %t1397, ptr %t1396, 1
  %t1399 = load ptr, ptr %l463, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s65, ptr %t1399, { i64, ptr } %t1398)
  br label %bb312
bb312:
  call void @__olang_scope_close(ptr %s65)
  br label %bb313
bb313:
  %t1401 = load ptr, ptr %l0, !tbaa !29
  %t1402 = load i32, ptr %l7, !tbaa !23
  %t1403 = load i32, ptr %l2, !tbaa !23
  %t1407 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t1401, i32 %t1402, i32 %t1403)
  store i1 %t1407, ptr %l477
  br label %bb314
bb314:
  %t1408 = load i1, ptr %l477, !tbaa !21
  %t1409 = xor i1 %t1408, true
  br i1 %t1409, label %bb315, label %bb316
bb315:
  store %olang.scope zeroinitializer, ptr %s68
  %t1411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1411, ptr %l479, !tbaa !29
  %t1412 = load i32, ptr %l1
  store i32 %t1412, ptr %l480
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s69
  store ptr %s69room, ptr %s69
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s69, ptr %l480, i64 0)
  br label %bb317
bb316:
  br label %bb322
bb317:
  %t1414 = load ptr, ptr %s69
  %t1415 = getelementptr %olang.builder, ptr %s69, i32 0, i32 1
  %t1416 = load i64, ptr %t1415
  %t1417 = call ptr @__olang_scope_alloc(ptr %s68, i64 %t1416)
  call void @olang_textcopy(ptr %t1417, ptr %t1414, i64 %t1416)
  %t1418 = insertvalue { i64, ptr } undef, i64 %t1416, 0
  %t1419 = insertvalue { i64, ptr } %t1418, ptr %t1417, 1
  store { i64, ptr } %t1419, ptr %l482, !tbaa !27
  %t1420 = getelementptr %olang.builder, ptr %s69, i32 0, i32 3
  %t1421 = load ptr, ptr %t1420
  %t1422 = icmp ne ptr %t1421, null
  br i1 %t1422, label %sbgrew.1423, label %sbdone.1424
sbgrew.1423:
  call void @__olang_sb_done(ptr %s69)
  br label %sbdone.1424
sbdone.1424:
  %t1425 = load { i64, ptr }, ptr %l482, !tbaa !27
  %t1426 = extractvalue { i64, ptr } %t1425, 0
  %t1427 = extractvalue { i64, ptr } %t1425, 1
  %t1428 = mul i64 %t1426, 1
  %t1429 = call ptr @__olang_scope_alloc(ptr %s68, i64 %t1428)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1429, ptr %t1427, i64 %t1428, i1 false)
  %t1430 = insertvalue { i64, ptr } undef, i64 %t1426, 0
  %t1431 = insertvalue { i64, ptr } %t1430, ptr %t1429, 1
  %t1433 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s68, { i64, ptr } %t1431)
  store { i64, ptr } %t1433, ptr %l484
  br label %bb318
bb318:
  %t1434 = load ptr, ptr %l0, !tbaa !29
  %t1435 = load i32, ptr %l7, !tbaa !23
  %t1438 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s68, ptr %t1434, i32 %t1435)
  store { i64, ptr } %t1438, ptr %l487
  br label %bb319
bb319:
  %t1439 = load ptr, ptr %l0, !tbaa !29
  %t1440 = load i32, ptr %l2, !tbaa !23
  %t1443 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s68, ptr %t1439, i32 %t1440)
  store { i64, ptr } %t1443, ptr %l490
  br label %bb320
bb320:
  %t1444 = load { i64, ptr }, ptr %l484, !tbaa !27
  %t1445 = extractvalue { i64, ptr } %t1444, 1
  %t1446 = extractvalue { i64, ptr } %t1444, 0
  %t1447 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t1448 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t1449 = add i64 %t1446, %t1448
  %t1450 = load { i64, ptr }, ptr %l487, !tbaa !27
  %t1451 = extractvalue { i64, ptr } %t1450, 1
  %t1452 = extractvalue { i64, ptr } %t1450, 0
  %t1453 = add i64 %t1449, %t1452
  %t1454 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t1455 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t1456 = add i64 %t1453, %t1455
  %t1457 = load { i64, ptr }, ptr %l490, !tbaa !27
  %t1458 = extractvalue { i64, ptr } %t1457, 1
  %t1459 = extractvalue { i64, ptr } %t1457, 0
  %t1460 = add i64 %t1456, %t1459
  %t1461 = call ptr @__olang_scope_alloc(ptr %s68, i64 %t1460)
  call void @olang_textcopy(ptr %t1461, ptr %t1445, i64 %t1446)
  %t1462 = getelementptr i8, ptr %t1461, i64 %t1446
  call void @olang_textcopy(ptr %t1462, ptr %t1447, i64 %t1448)
  %t1463 = getelementptr i8, ptr %t1462, i64 %t1448
  call void @olang_textcopy(ptr %t1463, ptr %t1451, i64 %t1452)
  %t1464 = getelementptr i8, ptr %t1463, i64 %t1452
  call void @olang_textcopy(ptr %t1464, ptr %t1454, i64 %t1455)
  %t1465 = getelementptr i8, ptr %t1464, i64 %t1455
  call void @olang_textcopy(ptr %t1465, ptr %t1458, i64 %t1459)
  %t1466 = insertvalue { i64, ptr } undef, i64 %t1460, 0
  %t1467 = insertvalue { i64, ptr } %t1466, ptr %t1461, 1
  %t1469 = extractvalue { i64, ptr } %t1467, 0
  %t1470 = extractvalue { i64, ptr } %t1467, 1
  %t1471 = mul i64 %t1469, 1
  %t1472 = call ptr @__olang_scope_alloc(ptr %s68, i64 %t1471)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1472, ptr %t1470, i64 %t1471, i1 false)
  %t1473 = insertvalue { i64, ptr } undef, i64 %t1469, 0
  %t1474 = insertvalue { i64, ptr } %t1473, ptr %t1472, 1
  %t1475 = load ptr, ptr %l479, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s68, ptr %t1475, { i64, ptr } %t1474)
  br label %bb321
bb321:
  call void @__olang_scope_close(ptr %s68)
  br label %bb322
bb322:
  br label %bb475
bb323:
  %t1477 = load i32, ptr %l1
  %t1479 = trunc i64 29 to i32
  %t1480 = icmp eq i32 %t1477, %t1479
  br i1 %t1480, label %bb324, label %bb325
bb324:
  br label %bb326
bb325:
  br label %bb343
bb326:
  %t1482 = load ptr, ptr %l4, !tbaa !29
  %t1483 = load i32, ptr %l8, !tbaa !23
  %t1486 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t1482, i32 %t1483)
  store i1 %t1486, ptr %l497
  br label %bb327
bb327:
  %t1487 = load i1, ptr %l497, !tbaa !21
  br i1 %t1487, label %bb328, label %bb329
bb328:
  %t1488 = load ptr, ptr %l4, !tbaa !29
  %t1489 = load i32, ptr %l8, !tbaa !23
  %t1492 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1488, i32 %t1489)
  store i32 %t1492, ptr %l501
  br label %bb330
bb329:
  %t1493 = load i32, ptr %l7, !tbaa !23
  store i32 %t1493, ptr %l498, !tbaa !23
  br label %bb331
bb330:
  %t1495 = load i32, ptr %l501, !tbaa !23
  store i32 %t1495, ptr %l498, !tbaa !23
  br label %bb331
bb331:
  %t1496 = load i32, ptr %l498, !tbaa !23
  %t1497 = load ptr, ptr %l0, !tbaa !29
  %t1501 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t1497, i32 %t1496)
  store i32 %t1501, ptr %l505
  br label %bb332
bb332:
  %t1502 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1503 = load i32, ptr %l505, !tbaa !23
  %t1505 = icmp eq i32 %t1503, %t1502
  br i1 %t1505, label %bb333, label %bb334
bb333:
  store %olang.scope zeroinitializer, ptr %s72
  %t1507 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1507, ptr %l508, !tbaa !29
  %t1508 = load ptr, ptr %l0, !tbaa !29
  %t1509 = load i32, ptr %l7, !tbaa !23
  %t1512 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s72, ptr %t1508, i32 %t1509)
  store { i64, ptr } %t1512, ptr %l511
  br label %bb335
bb334:
  br label %bb337
bb335:
  %t1513 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t1514 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t1515 = load { i64, ptr }, ptr %l511, !tbaa !27
  %t1516 = extractvalue { i64, ptr } %t1515, 1
  %t1517 = extractvalue { i64, ptr } %t1515, 0
  %t1518 = add i64 %t1514, %t1517
  %t1519 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1518)
  call void @olang_textcopy(ptr %t1519, ptr %t1513, i64 %t1514)
  %t1520 = getelementptr i8, ptr %t1519, i64 %t1514
  call void @olang_textcopy(ptr %t1520, ptr %t1516, i64 %t1517)
  %t1521 = insertvalue { i64, ptr } undef, i64 %t1518, 0
  %t1522 = insertvalue { i64, ptr } %t1521, ptr %t1519, 1
  %t1524 = extractvalue { i64, ptr } %t1522, 0
  %t1525 = extractvalue { i64, ptr } %t1522, 1
  %t1526 = mul i64 %t1524, 1
  %t1527 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1526)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1527, ptr %t1525, i64 %t1526, i1 false)
  %t1528 = insertvalue { i64, ptr } undef, i64 %t1524, 0
  %t1529 = insertvalue { i64, ptr } %t1528, ptr %t1527, 1
  %t1530 = load ptr, ptr %l508, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s72, ptr %t1530, { i64, ptr } %t1529)
  br label %bb336
bb336:
  call void @__olang_scope_close(ptr %s72)
  br label %bb337
bb337:
  %t1532 = load i32, ptr %l2, !tbaa !23
  %t1533 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1536 = icmp ne i32 %t1532, %t1533
  br i1 %t1536, label %bb338, label %bb339
bb338:
  store %olang.scope zeroinitializer, ptr %s74
  %t1538 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1538, ptr %l517, !tbaa !29
  %t1539 = load ptr, ptr %l0, !tbaa !29
  %t1540 = load i32, ptr %l2, !tbaa !23
  %t1543 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s74, ptr %t1539, i32 %t1540)
  store { i64, ptr } %t1543, ptr %l520
  br label %bb340
bb339:
  br label %bb342
bb340:
  %t1544 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t1545 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t1546 = load { i64, ptr }, ptr %l520, !tbaa !27
  %t1547 = extractvalue { i64, ptr } %t1546, 1
  %t1548 = extractvalue { i64, ptr } %t1546, 0
  %t1549 = add i64 %t1545, %t1548
  %t1550 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1549)
  call void @olang_textcopy(ptr %t1550, ptr %t1544, i64 %t1545)
  %t1551 = getelementptr i8, ptr %t1550, i64 %t1545
  call void @olang_textcopy(ptr %t1551, ptr %t1547, i64 %t1548)
  %t1552 = insertvalue { i64, ptr } undef, i64 %t1549, 0
  %t1553 = insertvalue { i64, ptr } %t1552, ptr %t1550, 1
  %t1555 = extractvalue { i64, ptr } %t1553, 0
  %t1556 = extractvalue { i64, ptr } %t1553, 1
  %t1557 = mul i64 %t1555, 1
  %t1558 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1557)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1558, ptr %t1556, i64 %t1557, i1 false)
  %t1559 = insertvalue { i64, ptr } undef, i64 %t1555, 0
  %t1560 = insertvalue { i64, ptr } %t1559, ptr %t1558, 1
  %t1561 = load ptr, ptr %l517, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s74, ptr %t1561, { i64, ptr } %t1560)
  br label %bb341
bb341:
  call void @__olang_scope_close(ptr %s74)
  br label %bb342
bb342:
  br label %bb475
bb343:
  %t1563 = load i32, ptr %l1
  %t1565 = trunc i64 23 to i32
  %t1566 = icmp eq i32 %t1563, %t1565
  br i1 %t1566, label %bb344, label %bb345
bb344:
  br label %bb346
bb345:
  br label %bb358
bb346:
  %t1568 = load ptr, ptr %l0, !tbaa !29
  %t1569 = load i32, ptr %l7, !tbaa !23
  %t1572 = call { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOf(ptr %v0, ptr %t1568, i32 %t1569)
  store { i32, i1 } %t1572, ptr %l527
  br label %bb347
bb347:
  %t1573 = load { i32, i1 }, ptr %l527
  store { i32, i1 } %t1573, ptr %l16
  %t1574 = getelementptr { i32, i1 }, ptr %l16, i32 0, i32 1
  %t1575 = load i1, ptr %t1574, !tbaa !21
  %t1579 = xor i1 %t1575, true
  br i1 %t1579, label %bb348, label %bb349
bb348:
  store %olang.scope zeroinitializer, ptr %s77
  %t1581 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1581, ptr %l531, !tbaa !29
  %t1582 = load ptr, ptr %l0, !tbaa !29
  %t1583 = load i32, ptr %l7, !tbaa !23
  %t1586 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s77, ptr %t1582, i32 %t1583)
  store { i64, ptr } %t1586, ptr %l534
  br label %bb350
bb349:
  br label %bb352
bb350:
  %t1587 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t1588 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t1589 = load { i64, ptr }, ptr %l534, !tbaa !27
  %t1590 = extractvalue { i64, ptr } %t1589, 1
  %t1591 = extractvalue { i64, ptr } %t1589, 0
  %t1592 = add i64 %t1588, %t1591
  %t1593 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1592)
  call void @olang_textcopy(ptr %t1593, ptr %t1587, i64 %t1588)
  %t1594 = getelementptr i8, ptr %t1593, i64 %t1588
  call void @olang_textcopy(ptr %t1594, ptr %t1590, i64 %t1591)
  %t1595 = insertvalue { i64, ptr } undef, i64 %t1592, 0
  %t1596 = insertvalue { i64, ptr } %t1595, ptr %t1593, 1
  %t1598 = extractvalue { i64, ptr } %t1596, 0
  %t1599 = extractvalue { i64, ptr } %t1596, 1
  %t1600 = mul i64 %t1598, 1
  %t1601 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1600)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1601, ptr %t1599, i64 %t1600, i1 false)
  %t1602 = insertvalue { i64, ptr } undef, i64 %t1598, 0
  %t1603 = insertvalue { i64, ptr } %t1602, ptr %t1601, 1
  %t1604 = load ptr, ptr %l531, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s77, ptr %t1604, { i64, ptr } %t1603)
  br label %bb351
bb351:
  call void @__olang_scope_close(ptr %s77)
  br label %bb352
bb352:
  %t1606 = load i32, ptr %l2, !tbaa !23
  %t1607 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1610 = icmp ne i32 %t1606, %t1607
  br i1 %t1610, label %bb353, label %bb354
bb353:
  store %olang.scope zeroinitializer, ptr %s79
  %t1612 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1612, ptr %l540, !tbaa !29
  %t1613 = load ptr, ptr %l0, !tbaa !29
  %t1614 = load i32, ptr %l2, !tbaa !23
  %t1617 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s79, ptr %t1613, i32 %t1614)
  store { i64, ptr } %t1617, ptr %l543
  br label %bb355
bb354:
  br label %bb357
bb355:
  %t1618 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t1619 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t1620 = load { i64, ptr }, ptr %l543, !tbaa !27
  %t1621 = extractvalue { i64, ptr } %t1620, 1
  %t1622 = extractvalue { i64, ptr } %t1620, 0
  %t1623 = add i64 %t1619, %t1622
  %t1624 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t1623)
  call void @olang_textcopy(ptr %t1624, ptr %t1618, i64 %t1619)
  %t1625 = getelementptr i8, ptr %t1624, i64 %t1619
  call void @olang_textcopy(ptr %t1625, ptr %t1621, i64 %t1622)
  %t1626 = insertvalue { i64, ptr } undef, i64 %t1623, 0
  %t1627 = insertvalue { i64, ptr } %t1626, ptr %t1624, 1
  %t1629 = extractvalue { i64, ptr } %t1627, 0
  %t1630 = extractvalue { i64, ptr } %t1627, 1
  %t1631 = mul i64 %t1629, 1
  %t1632 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t1631)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1632, ptr %t1630, i64 %t1631, i1 false)
  %t1633 = insertvalue { i64, ptr } undef, i64 %t1629, 0
  %t1634 = insertvalue { i64, ptr } %t1633, ptr %t1632, 1
  %t1635 = load ptr, ptr %l540, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s79, ptr %t1635, { i64, ptr } %t1634)
  br label %bb356
bb356:
  call void @__olang_scope_close(ptr %s79)
  br label %bb357
bb357:
  br label %bb475
bb358:
  %t1637 = load i32, ptr %l1
  %t1639 = trunc i64 40 to i32
  %t1640 = icmp eq i32 %t1637, %t1639
  br i1 %t1640, label %bb359, label %bb360
bb359:
  br label %bb361
bb360:
  br label %bb386
bb361:
  %t1642 = load ptr, ptr %l4, !tbaa !29
  %t1643 = load i32, ptr %l8, !tbaa !23
  %t1646 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t1642, i32 %t1643)
  store i1 %t1646, ptr %l550
  br label %bb362
bb362:
  %t1647 = load i1, ptr %l550, !tbaa !21
  %t1648 = xor i1 %t1647, true
  br i1 %t1648, label %bb363, label %bb364
bb363:
  store i1 true, ptr %l552, !tbaa !21
  br label %bb366
bb364:
  %t1650 = load ptr, ptr %l4, !tbaa !29
  %t1651 = load i32, ptr %l8, !tbaa !23
  %t1654 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t1650, i32 %t1651)
  store i1 %t1654, ptr %l555
  br label %bb365
bb365:
  %t1655 = load i1, ptr %l555, !tbaa !21
  store i1 %t1655, ptr %l552, !tbaa !21
  br label %bb366
bb366:
  %t1656 = load i1, ptr %l552, !tbaa !21
  br i1 %t1656, label %bb367, label %bb368
bb367:
  store %olang.scope zeroinitializer, ptr %s82
  %t1657 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1657, ptr %l556, !tbaa !29
  %t1658 = load ptr, ptr %l0, !tbaa !29
  %t1659 = load i32, ptr %l7, !tbaa !23
  %t1662 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s82, ptr %t1658, i32 %t1659)
  store { i64, ptr } %t1662, ptr %l559
  br label %bb369
bb368:
  br label %bb371
bb369:
  %t1663 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t1664 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t1665 = load { i64, ptr }, ptr %l559, !tbaa !27
  %t1666 = extractvalue { i64, ptr } %t1665, 1
  %t1667 = extractvalue { i64, ptr } %t1665, 0
  %t1668 = add i64 %t1664, %t1667
  %t1669 = call ptr @__olang_scope_alloc(ptr %s82, i64 %t1668)
  call void @olang_textcopy(ptr %t1669, ptr %t1663, i64 %t1664)
  %t1670 = getelementptr i8, ptr %t1669, i64 %t1664
  call void @olang_textcopy(ptr %t1670, ptr %t1666, i64 %t1667)
  %t1671 = insertvalue { i64, ptr } undef, i64 %t1668, 0
  %t1672 = insertvalue { i64, ptr } %t1671, ptr %t1669, 1
  %t1674 = extractvalue { i64, ptr } %t1672, 0
  %t1675 = extractvalue { i64, ptr } %t1672, 1
  %t1676 = mul i64 %t1674, 1
  %t1677 = call ptr @__olang_scope_alloc(ptr %s82, i64 %t1676)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1677, ptr %t1675, i64 %t1676, i1 false)
  %t1678 = insertvalue { i64, ptr } undef, i64 %t1674, 0
  %t1679 = insertvalue { i64, ptr } %t1678, ptr %t1677, 1
  %t1680 = load ptr, ptr %l556, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s82, ptr %t1680, { i64, ptr } %t1679)
  br label %bb370
bb370:
  call void @__olang_scope_close(ptr %s82)
  br label %bb371
bb371:
  %t1682 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1682, ptr %l562, !tbaa !29
  %t1683 = load ptr, ptr %l4, !tbaa !29
  %t1684 = load i32, ptr %l2, !tbaa !23
  %t1687 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1683, i32 %t1684)
  store i32 %t1687, ptr %l565
  br label %bb372
bb372:
  %t1688 = load ptr, ptr %l562, !tbaa !29
  %t1689 = load i32, ptr %l565, !tbaa !23
  %t1690 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t1688, i32 %t1689)
  store i1 %t1690, ptr %l566
  br label %bb373
bb373:
  %t1691 = load i1, ptr %l566, !tbaa !21
  %t1692 = xor i1 %t1691, true
  br i1 %t1692, label %bb374, label %bb375
bb374:
  store %olang.scope zeroinitializer, ptr %s84
  %t1694 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1694, ptr %l568, !tbaa !29
  %t1695 = load ptr, ptr %l0, !tbaa !29
  %t1696 = load i32, ptr %l2, !tbaa !23
  %t1699 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s84, ptr %t1695, i32 %t1696)
  store { i64, ptr } %t1699, ptr %l571
  br label %bb376
bb375:
  br label %bb378
bb376:
  %t1700 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t1701 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t1702 = load { i64, ptr }, ptr %l571, !tbaa !27
  %t1703 = extractvalue { i64, ptr } %t1702, 1
  %t1704 = extractvalue { i64, ptr } %t1702, 0
  %t1705 = add i64 %t1701, %t1704
  %t1706 = call ptr @__olang_scope_alloc(ptr %s84, i64 %t1705)
  call void @olang_textcopy(ptr %t1706, ptr %t1700, i64 %t1701)
  %t1707 = getelementptr i8, ptr %t1706, i64 %t1701
  call void @olang_textcopy(ptr %t1707, ptr %t1703, i64 %t1704)
  %t1708 = insertvalue { i64, ptr } undef, i64 %t1705, 0
  %t1709 = insertvalue { i64, ptr } %t1708, ptr %t1706, 1
  %t1711 = extractvalue { i64, ptr } %t1709, 0
  %t1712 = extractvalue { i64, ptr } %t1709, 1
  %t1713 = mul i64 %t1711, 1
  %t1714 = call ptr @__olang_scope_alloc(ptr %s84, i64 %t1713)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1714, ptr %t1712, i64 %t1713, i1 false)
  %t1715 = insertvalue { i64, ptr } undef, i64 %t1711, 0
  %t1716 = insertvalue { i64, ptr } %t1715, ptr %t1714, 1
  %t1717 = load ptr, ptr %l568, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s84, ptr %t1717, { i64, ptr } %t1716)
  br label %bb377
bb377:
  call void @__olang_scope_close(ptr %s84)
  br label %bb378
bb378:
  %t1719 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1719, ptr %l574, !tbaa !29
  %t1720 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1720, ptr %l575, !tbaa !29
  %t1721 = load ptr, ptr %l0, !tbaa !29
  %t1722 = load %"compiler/mir:Range", ptr %l3
  %t1725 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t1721, %"compiler/mir:Range" %t1722, i64 1)
  store { i64, [4 x i64] } %t1725, ptr %l578
  br label %bb379
bb379:
  %t1726 = load ptr, ptr %l575, !tbaa !29
  %t1727 = load { i64, [4 x i64] }, ptr %l578
  %t1728 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t1726, { i64, [4 x i64] } %t1727)
  store i32 %t1728, ptr %l579
  br label %bb380
bb380:
  %t1729 = load ptr, ptr %l574, !tbaa !29
  %t1730 = load i32, ptr %l579, !tbaa !23
  %t1731 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1729, i32 %t1730)
  store i32 %t1731, ptr %l580
  br label %bb381
bb381:
  %t1732 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1733 = load i32, ptr %l580, !tbaa !23
  %t1735 = icmp ne i32 %t1733, %t1732
  br i1 %t1735, label %bb382, label %bb383
bb382:
  store %olang.scope zeroinitializer, ptr %s86
  %t1737 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s86, ptr %t1737, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d193, i32 0, i32 1) })
  br label %bb384
bb383:
  br label %bb385
bb384:
  call void @__olang_scope_close(ptr %s86)
  br label %bb385
bb385:
  br label %bb475
bb386:
  %t1739 = load i32, ptr %l1
  %t1741 = trunc i64 41 to i32
  %t1742 = icmp eq i32 %t1739, %t1741
  br i1 %t1742, label %bb387, label %bb388
bb387:
  br label %bb389
bb388:
  br label %bb403
bb389:
  %t1744 = load ptr, ptr %l4, !tbaa !29
  %t1745 = load i32, ptr %l8, !tbaa !23
  %t1748 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t1744, i32 %t1745)
  store i1 %t1748, ptr %l588
  br label %bb390
bb390:
  %t1749 = load i1, ptr %l588, !tbaa !21
  %t1750 = xor i1 %t1749, true
  br i1 %t1750, label %bb391, label %bb392
bb391:
  store %olang.scope zeroinitializer, ptr %s88
  %t1752 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1752, ptr %l590, !tbaa !29
  %t1753 = load ptr, ptr %l0, !tbaa !29
  %t1754 = load i32, ptr %l7, !tbaa !23
  %t1757 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s88, ptr %t1753, i32 %t1754)
  store { i64, ptr } %t1757, ptr %l593
  br label %bb393
bb392:
  br label %bb395
bb393:
  %t1758 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t1759 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t1760 = load { i64, ptr }, ptr %l593, !tbaa !27
  %t1761 = extractvalue { i64, ptr } %t1760, 1
  %t1762 = extractvalue { i64, ptr } %t1760, 0
  %t1763 = add i64 %t1759, %t1762
  %t1764 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t1763)
  call void @olang_textcopy(ptr %t1764, ptr %t1758, i64 %t1759)
  %t1765 = getelementptr i8, ptr %t1764, i64 %t1759
  call void @olang_textcopy(ptr %t1765, ptr %t1761, i64 %t1762)
  %t1766 = insertvalue { i64, ptr } undef, i64 %t1763, 0
  %t1767 = insertvalue { i64, ptr } %t1766, ptr %t1764, 1
  %t1769 = extractvalue { i64, ptr } %t1767, 0
  %t1770 = extractvalue { i64, ptr } %t1767, 1
  %t1771 = mul i64 %t1769, 1
  %t1772 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t1771)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1772, ptr %t1770, i64 %t1771, i1 false)
  %t1773 = insertvalue { i64, ptr } undef, i64 %t1769, 0
  %t1774 = insertvalue { i64, ptr } %t1773, ptr %t1772, 1
  %t1775 = load ptr, ptr %l590, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s88, ptr %t1775, { i64, ptr } %t1774)
  br label %bb394
bb394:
  call void @__olang_scope_close(ptr %s88)
  br label %bb395
bb395:
  %t1777 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1777, ptr %l596, !tbaa !29
  %t1778 = load ptr, ptr %l4, !tbaa !29
  %t1779 = load i32, ptr %l2, !tbaa !23
  %t1782 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1778, i32 %t1779)
  store i32 %t1782, ptr %l599
  br label %bb396
bb396:
  %t1783 = load ptr, ptr %l596, !tbaa !29
  %t1784 = load i32, ptr %l599, !tbaa !23
  %t1785 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t1783, i32 %t1784)
  store i1 %t1785, ptr %l600
  br label %bb397
bb397:
  %t1786 = load i1, ptr %l600, !tbaa !21
  %t1787 = xor i1 %t1786, true
  br i1 %t1787, label %bb398, label %bb399
bb398:
  store %olang.scope zeroinitializer, ptr %s90
  %t1789 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1789, ptr %l602, !tbaa !29
  %t1790 = load ptr, ptr %l0, !tbaa !29
  %t1791 = load i32, ptr %l2, !tbaa !23
  %t1794 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s90, ptr %t1790, i32 %t1791)
  store { i64, ptr } %t1794, ptr %l605
  br label %bb400
bb399:
  br label %bb402
bb400:
  %t1795 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t1796 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t1797 = load { i64, ptr }, ptr %l605, !tbaa !27
  %t1798 = extractvalue { i64, ptr } %t1797, 1
  %t1799 = extractvalue { i64, ptr } %t1797, 0
  %t1800 = add i64 %t1796, %t1799
  %t1801 = call ptr @__olang_scope_alloc(ptr %s90, i64 %t1800)
  call void @olang_textcopy(ptr %t1801, ptr %t1795, i64 %t1796)
  %t1802 = getelementptr i8, ptr %t1801, i64 %t1796
  call void @olang_textcopy(ptr %t1802, ptr %t1798, i64 %t1799)
  %t1803 = insertvalue { i64, ptr } undef, i64 %t1800, 0
  %t1804 = insertvalue { i64, ptr } %t1803, ptr %t1801, 1
  %t1806 = extractvalue { i64, ptr } %t1804, 0
  %t1807 = extractvalue { i64, ptr } %t1804, 1
  %t1808 = mul i64 %t1806, 1
  %t1809 = call ptr @__olang_scope_alloc(ptr %s90, i64 %t1808)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1809, ptr %t1807, i64 %t1808, i1 false)
  %t1810 = insertvalue { i64, ptr } undef, i64 %t1806, 0
  %t1811 = insertvalue { i64, ptr } %t1810, ptr %t1809, 1
  %t1812 = load ptr, ptr %l602, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s90, ptr %t1812, { i64, ptr } %t1811)
  br label %bb401
bb401:
  call void @__olang_scope_close(ptr %s90)
  br label %bb402
bb402:
  br label %bb475
bb403:
  %t1814 = load i32, ptr %l1
  %t1816 = trunc i64 42 to i32
  %t1817 = icmp eq i32 %t1814, %t1816
  br i1 %t1817, label %bb404, label %bb405
bb404:
  br label %bb406
bb405:
  br label %bb418
bb406:
  %t1819 = load ptr, ptr %l4, !tbaa !29
  %t1820 = load i32, ptr %l8, !tbaa !23
  %t1823 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t1819, i32 %t1820)
  store i1 %t1823, ptr %l612
  br label %bb407
bb407:
  %t1824 = load i1, ptr %l612, !tbaa !21
  %t1825 = xor i1 %t1824, true
  br i1 %t1825, label %bb408, label %bb409
bb408:
  store %olang.scope zeroinitializer, ptr %s93
  %t1827 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1827, ptr %l614, !tbaa !29
  %t1828 = load ptr, ptr %l0, !tbaa !29
  %t1829 = load i32, ptr %l7, !tbaa !23
  %t1832 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s93, ptr %t1828, i32 %t1829)
  store { i64, ptr } %t1832, ptr %l617
  br label %bb410
bb409:
  br label %bb412
bb410:
  %t1833 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t1834 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t1835 = load { i64, ptr }, ptr %l617, !tbaa !27
  %t1836 = extractvalue { i64, ptr } %t1835, 1
  %t1837 = extractvalue { i64, ptr } %t1835, 0
  %t1838 = add i64 %t1834, %t1837
  %t1839 = call ptr @__olang_scope_alloc(ptr %s93, i64 %t1838)
  call void @olang_textcopy(ptr %t1839, ptr %t1833, i64 %t1834)
  %t1840 = getelementptr i8, ptr %t1839, i64 %t1834
  call void @olang_textcopy(ptr %t1840, ptr %t1836, i64 %t1837)
  %t1841 = insertvalue { i64, ptr } undef, i64 %t1838, 0
  %t1842 = insertvalue { i64, ptr } %t1841, ptr %t1839, 1
  %t1844 = extractvalue { i64, ptr } %t1842, 0
  %t1845 = extractvalue { i64, ptr } %t1842, 1
  %t1846 = mul i64 %t1844, 1
  %t1847 = call ptr @__olang_scope_alloc(ptr %s93, i64 %t1846)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1847, ptr %t1845, i64 %t1846, i1 false)
  %t1848 = insertvalue { i64, ptr } undef, i64 %t1844, 0
  %t1849 = insertvalue { i64, ptr } %t1848, ptr %t1847, 1
  %t1850 = load ptr, ptr %l614, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s93, ptr %t1850, { i64, ptr } %t1849)
  br label %bb411
bb411:
  call void @__olang_scope_close(ptr %s93)
  br label %bb412
bb412:
  %t1852 = load i32, ptr %l2, !tbaa !23
  %t1853 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1856 = icmp ne i32 %t1852, %t1853
  br i1 %t1856, label %bb413, label %bb414
bb413:
  store %olang.scope zeroinitializer, ptr %s95
  %t1858 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1858, ptr %l623, !tbaa !29
  %t1859 = load ptr, ptr %l0, !tbaa !29
  %t1860 = load i32, ptr %l2, !tbaa !23
  %t1863 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s95, ptr %t1859, i32 %t1860)
  store { i64, ptr } %t1863, ptr %l626
  br label %bb415
bb414:
  br label %bb417
bb415:
  %t1864 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t1865 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t1866 = load { i64, ptr }, ptr %l626, !tbaa !27
  %t1867 = extractvalue { i64, ptr } %t1866, 1
  %t1868 = extractvalue { i64, ptr } %t1866, 0
  %t1869 = add i64 %t1865, %t1868
  %t1870 = call ptr @__olang_scope_alloc(ptr %s95, i64 %t1869)
  call void @olang_textcopy(ptr %t1870, ptr %t1864, i64 %t1865)
  %t1871 = getelementptr i8, ptr %t1870, i64 %t1865
  call void @olang_textcopy(ptr %t1871, ptr %t1867, i64 %t1868)
  %t1872 = insertvalue { i64, ptr } undef, i64 %t1869, 0
  %t1873 = insertvalue { i64, ptr } %t1872, ptr %t1870, 1
  %t1875 = extractvalue { i64, ptr } %t1873, 0
  %t1876 = extractvalue { i64, ptr } %t1873, 1
  %t1877 = mul i64 %t1875, 1
  %t1878 = call ptr @__olang_scope_alloc(ptr %s95, i64 %t1877)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1878, ptr %t1876, i64 %t1877, i1 false)
  %t1879 = insertvalue { i64, ptr } undef, i64 %t1875, 0
  %t1880 = insertvalue { i64, ptr } %t1879, ptr %t1878, 1
  %t1881 = load ptr, ptr %l623, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s95, ptr %t1881, { i64, ptr } %t1880)
  br label %bb416
bb416:
  call void @__olang_scope_close(ptr %s95)
  br label %bb417
bb417:
  br label %bb475
bb418:
  br i1 true, label %bb419, label %bb420
bb419:
  br label %bb421
bb420:
  br label %bb474
bb421:
  %t1883 = load ptr, ptr %l4, !tbaa !29
  %t1884 = load i32, ptr %l8, !tbaa !23
  %t1887 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t1883, i32 %t1884)
  store i1 %t1887, ptr %l631
  br label %bb422
bb422:
  %t1888 = load i1, ptr %l631, !tbaa !21
  %t1889 = xor i1 %t1888, true
  br i1 %t1889, label %bb423, label %bb424
bb423:
  store i1 true, ptr %l633, !tbaa !21
  br label %bb428
bb424:
  %t1891 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1891, ptr %l634, !tbaa !29
  %t1892 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1892, ptr %l635, !tbaa !29
  %t1893 = load ptr, ptr %l4, !tbaa !29
  %t1894 = load i32, ptr %l8, !tbaa !23
  %t1897 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1893, i32 %t1894)
  store i32 %t1897, ptr %l638
  br label %bb425
bb425:
  %t1898 = load ptr, ptr %l635, !tbaa !29
  %t1899 = load i32, ptr %l638, !tbaa !23
  %t1900 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1898, i32 %t1899)
  store i32 %t1900, ptr %l639
  br label %bb426
bb426:
  %t1901 = load ptr, ptr %l634, !tbaa !29
  %t1902 = load i32, ptr %l639, !tbaa !23
  %t1903 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t1901, i32 %t1902)
  store i1 %t1903, ptr %l640
  br label %bb427
bb427:
  %t1904 = load i1, ptr %l640, !tbaa !21
  %t1905 = xor i1 %t1904, true
  store i1 %t1905, ptr %l633, !tbaa !21
  br label %bb428
bb428:
  %t1907 = load i1, ptr %l633, !tbaa !21
  br i1 %t1907, label %bb429, label %bb430
bb429:
  store i1 true, ptr %l642, !tbaa !21
  br label %bb432
bb430:
  %t1908 = load ptr, ptr %l4, !tbaa !29
  %t1909 = load i32, ptr %l8, !tbaa !23
  %t1912 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1908, i32 %t1909)
  store i64 %t1912, ptr %l645
  br label %bb431
bb431:
  %t1913 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1914 = load i64, ptr %l645, !tbaa !24
  %t1916 = and i64 %t1914, %t1913
  %t1918 = icmp eq i64 %t1916, 0
  store i1 %t1918, ptr %l642, !tbaa !21
  br label %bb432
bb432:
  %t1920 = load i1, ptr %l642, !tbaa !21
  br i1 %t1920, label %bb433, label %bb434
bb433:
  store %olang.scope zeroinitializer, ptr %s98
  %t1921 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1921, ptr %l649, !tbaa !29
  %t1922 = load i32, ptr %l1
  store i32 %t1922, ptr %l650
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s99
  store ptr %s99room, ptr %s99
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s99, ptr %l650, i64 0)
  br label %bb435
bb434:
  %t1924 = load ptr, ptr %l4, !tbaa !29
  %t1925 = load i32, ptr %l8, !tbaa !23
  %t1928 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1924, i32 %t1925)
  store i32 %t1928, ptr %l662
  br label %bb439
bb435:
  %t1929 = load ptr, ptr %s99
  %t1930 = getelementptr %olang.builder, ptr %s99, i32 0, i32 1
  %t1931 = load i64, ptr %t1930
  %t1932 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t1931)
  call void @olang_textcopy(ptr %t1932, ptr %t1929, i64 %t1931)
  %t1933 = insertvalue { i64, ptr } undef, i64 %t1931, 0
  %t1934 = insertvalue { i64, ptr } %t1933, ptr %t1932, 1
  store { i64, ptr } %t1934, ptr %l652, !tbaa !27
  %t1935 = getelementptr %olang.builder, ptr %s99, i32 0, i32 3
  %t1936 = load ptr, ptr %t1935
  %t1937 = icmp ne ptr %t1936, null
  br i1 %t1937, label %sbgrew.1938, label %sbdone.1939
sbgrew.1938:
  call void @__olang_sb_done(ptr %s99)
  br label %sbdone.1939
sbdone.1939:
  %t1940 = load { i64, ptr }, ptr %l652, !tbaa !27
  %t1941 = extractvalue { i64, ptr } %t1940, 0
  %t1942 = extractvalue { i64, ptr } %t1940, 1
  %t1943 = mul i64 %t1941, 1
  %t1944 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t1943)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1944, ptr %t1942, i64 %t1943, i1 false)
  %t1945 = insertvalue { i64, ptr } undef, i64 %t1941, 0
  %t1946 = insertvalue { i64, ptr } %t1945, ptr %t1944, 1
  %t1948 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s98, { i64, ptr } %t1946)
  store { i64, ptr } %t1948, ptr %l654
  br label %bb436
bb436:
  %t1949 = load ptr, ptr %l0, !tbaa !29
  %t1950 = load i32, ptr %l7, !tbaa !23
  %t1953 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s98, ptr %t1949, i32 %t1950)
  store { i64, ptr } %t1953, ptr %l657
  br label %bb437
bb437:
  %t1954 = load { i64, ptr }, ptr %l654, !tbaa !27
  %t1955 = extractvalue { i64, ptr } %t1954, 1
  %t1956 = extractvalue { i64, ptr } %t1954, 0
  %t1957 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t1958 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t1959 = add i64 %t1956, %t1958
  %t1960 = load { i64, ptr }, ptr %l657, !tbaa !27
  %t1961 = extractvalue { i64, ptr } %t1960, 1
  %t1962 = extractvalue { i64, ptr } %t1960, 0
  %t1963 = add i64 %t1959, %t1962
  %t1964 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t1965 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t1966 = add i64 %t1963, %t1965
  %t1967 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t1966)
  call void @olang_textcopy(ptr %t1967, ptr %t1955, i64 %t1956)
  %t1968 = getelementptr i8, ptr %t1967, i64 %t1956
  call void @olang_textcopy(ptr %t1968, ptr %t1957, i64 %t1958)
  %t1969 = getelementptr i8, ptr %t1968, i64 %t1958
  call void @olang_textcopy(ptr %t1969, ptr %t1961, i64 %t1962)
  %t1970 = getelementptr i8, ptr %t1969, i64 %t1962
  call void @olang_textcopy(ptr %t1970, ptr %t1964, i64 %t1965)
  %t1971 = insertvalue { i64, ptr } undef, i64 %t1966, 0
  %t1972 = insertvalue { i64, ptr } %t1971, ptr %t1967, 1
  %t1974 = extractvalue { i64, ptr } %t1972, 0
  %t1975 = extractvalue { i64, ptr } %t1972, 1
  %t1976 = mul i64 %t1974, 1
  %t1977 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t1976)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1977, ptr %t1975, i64 %t1976, i1 false)
  %t1978 = insertvalue { i64, ptr } undef, i64 %t1974, 0
  %t1979 = insertvalue { i64, ptr } %t1978, ptr %t1977, 1
  %t1980 = load ptr, ptr %l649, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s98, ptr %t1980, { i64, ptr } %t1979)
  br label %bb438
bb438:
  call void @__olang_scope_close(ptr %s98)
  br label %bb473
bb439:
  %t1982 = load i32, ptr %l662, !tbaa !23
  store i32 %t1982, ptr %l18, !tbaa !23
  store i64 1, ptr %l19, !tbaa !24
  %t1983 = load i64, ptr %l5, !tbaa !24
  store i64 %t1983, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t1985 = load i64, ptr %l20, !tbaa !24
  %t1986 = load i64, ptr %l19, !tbaa !24
  %t1989 = icmp sgt i64 %t1985, %t1986
  br i1 %t1989, label %bb440, label %bb441
bb440:
  %t1991 = load i64, ptr %l21, !tbaa !24
  %t1993 = icmp sgt i64 %t1991, 0
  br i1 %t1993, label %bb442, label %bb443
bb441:
  store i64 0, ptr %l667, !tbaa !24
  br label %bb445
bb442:
  %t1995 = load i64, ptr %l20, !tbaa !24
  %t1996 = load i64, ptr %l19, !tbaa !24
  %t1999 = sub i64 %t1995, %t1996
  %t2000 = load i64, ptr %l21, !tbaa !24
  %t2003 = add i64 %t1999, %t2000
  %t2005 = sub i64 %t2003, 1
  %t2006 = load i64, ptr %l21, !tbaa !24
  %t2009 = sdiv i64 %t2005, %t2006
  store i64 %t2009, ptr %l670, !tbaa !24
  br label %bb444
bb443:
  store i64 0, ptr %l670, !tbaa !24
  br label %bb444
bb444:
  %t2011 = load i64, ptr %l670, !tbaa !24
  store i64 %t2011, ptr %l667, !tbaa !24
  br label %bb445
bb445:
  %t2012 = load i64, ptr %l667, !tbaa !24
  store i64 %t2012, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb446
bb446:
  store %olang.scope zeroinitializer, ptr %s103
  %t2013 = load i64, ptr %l23, !tbaa !24
  %t2014 = load i64, ptr %l22, !tbaa !24
  %t2017 = icmp slt i64 %t2013, %t2014
  %t2019 = xor i1 %t2017, true
  br i1 %t2019, label %bb447, label %bb448
bb447:
  call void @__olang_scope_close(ptr %s103)
  br label %bb456
bb448:
  br label %bb449
bb449:
  %t2021 = load i64, ptr %l19, !tbaa !24
  %t2022 = load i64, ptr %l23, !tbaa !24
  %t2023 = load i64, ptr %l21, !tbaa !24
  %t2026 = mul i64 %t2022, %t2023
  %t2029 = add i64 %t2021, %t2026
  store i64 %t2029, ptr %l24, !tbaa !24
  %t2031 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2031, ptr %l688, !tbaa !29
  %t2032 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2032, ptr %l689, !tbaa !29
  %t2033 = load ptr, ptr %l0, !tbaa !29
  %t2034 = load %"compiler/mir:Range", ptr %l3
  %t2035 = load i64, ptr %l24, !tbaa !24
  %t2039 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t2033, %"compiler/mir:Range" %t2034, i64 %t2035)
  store { i64, [4 x i64] } %t2039, ptr %l693
  br label %bb450
bb450:
  %t2040 = load ptr, ptr %l689, !tbaa !29
  %t2041 = load { i64, [4 x i64] }, ptr %l693
  %t2042 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t2040, { i64, [4 x i64] } %t2041)
  store i32 %t2042, ptr %l694
  br label %bb451
bb451:
  %t2043 = load i32, ptr %l18, !tbaa !23
  store i32 %t2043, ptr %l695, !tbaa !23
  %t2044 = load i32, ptr %l1
  store i32 %t2044, ptr %l696
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s104
  store ptr %s104room, ptr %s104
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s104, ptr %l696, i64 0)
  br label %bb452
bb452:
  %t2046 = load ptr, ptr %s104
  %t2047 = getelementptr %olang.builder, ptr %s104, i32 0, i32 1
  %t2048 = load i64, ptr %t2047
  %t2049 = call ptr @__olang_scope_alloc(ptr %s103, i64 %t2048)
  call void @olang_textcopy(ptr %t2049, ptr %t2046, i64 %t2048)
  %t2050 = insertvalue { i64, ptr } undef, i64 %t2048, 0
  %t2051 = insertvalue { i64, ptr } %t2050, ptr %t2049, 1
  store { i64, ptr } %t2051, ptr %l698, !tbaa !27
  %t2052 = getelementptr %olang.builder, ptr %s104, i32 0, i32 3
  %t2053 = load ptr, ptr %t2052
  %t2054 = icmp ne ptr %t2053, null
  br i1 %t2054, label %sbgrew.2055, label %sbdone.2056
sbgrew.2055:
  call void @__olang_sb_done(ptr %s104)
  br label %sbdone.2056
sbdone.2056:
  %t2057 = load { i64, ptr }, ptr %l698, !tbaa !27
  %t2058 = extractvalue { i64, ptr } %t2057, 0
  %t2059 = extractvalue { i64, ptr } %t2057, 1
  %t2060 = mul i64 %t2058, 1
  %t2061 = call ptr @__olang_scope_alloc(ptr %s103, i64 %t2060)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2061, ptr %t2059, i64 %t2060, i1 false)
  %t2062 = insertvalue { i64, ptr } undef, i64 %t2058, 0
  %t2063 = insertvalue { i64, ptr } %t2062, ptr %t2061, 1
  %t2065 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s103, { i64, ptr } %t2063)
  store { i64, ptr } %t2065, ptr %l700
  br label %bb453
bb453:
  %t2066 = load i64, ptr %l24, !tbaa !24
  %t2067 = load { i64, ptr }, ptr %l700, !tbaa !27
  %t2068 = extractvalue { i64, ptr } %t2067, 1
  %t2069 = extractvalue { i64, ptr } %t2067, 0
  %t2070 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t2071 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t2072 = add i64 %t2069, %t2071
  %t2074 = call i64 @__olang_fmt_i64(ptr null, i64 %t2066)
  %t2075 = add i64 %t2072, %t2074
  %t2076 = call ptr @__olang_scope_alloc(ptr %s103, i64 %t2075)
  call void @olang_textcopy(ptr %t2076, ptr %t2068, i64 %t2069)
  %t2077 = getelementptr i8, ptr %t2076, i64 %t2069
  call void @olang_textcopy(ptr %t2077, ptr %t2070, i64 %t2071)
  %t2078 = getelementptr i8, ptr %t2077, i64 %t2071
  %t2079 = call i64 @__olang_fmt_i64(ptr %t2078, i64 %t2066)
  %t2080 = insertvalue { i64, ptr } undef, i64 %t2075, 0
  %t2081 = insertvalue { i64, ptr } %t2080, ptr %t2076, 1
  %t2083 = extractvalue { i64, ptr } %t2081, 0
  %t2084 = extractvalue { i64, ptr } %t2081, 1
  %t2085 = mul i64 %t2083, 1
  %t2086 = call ptr @__olang_scope_alloc(ptr %s103, i64 %t2085)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2086, ptr %t2084, i64 %t2085, i1 false)
  %t2087 = insertvalue { i64, ptr } undef, i64 %t2083, 0
  %t2088 = insertvalue { i64, ptr } %t2087, ptr %t2086, 1
  %t2089 = load ptr, ptr %l688, !tbaa !29
  %t2090 = load i32, ptr %l694, !tbaa !23
  %t2091 = load i32, ptr %l695, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s103, ptr %t2089, i32 %t2090, i32 %t2091, { i64, ptr } %t2088)
  br label %bb454
bb454:
  call void @__olang_scope_close(ptr %s103)
  br label %bb455
bb455:
  %t2093 = load i64, ptr %l23, !tbaa !24
  %t2095 = add i64 %t2093, 1
  store i64 %t2095, ptr %l23, !tbaa !24
  br label %bb446
bb456:
  %t2097 = load i32, ptr %l1
  %t2099 = trunc i64 25 to i32
  %t2100 = icmp eq i32 %t2097, %t2099
  br i1 %t2100, label %bb457, label %bb458
bb457:
  %t2102 = load i32, ptr %l2, !tbaa !23
  %t2103 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t2106 = icmp ne i32 %t2102, %t2103
  br i1 %t2106, label %bb459, label %bb460
bb458:
  %t2108 = load ptr, ptr %l0, !tbaa !29
  %t2109 = load i32, ptr %l18, !tbaa !23
  %t2110 = load i32, ptr %l2, !tbaa !23
  %t2114 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t2108, i32 %t2109, i32 %t2110)
  store i1 %t2114, ptr %l720
  br label %bb464
bb459:
  store %olang.scope zeroinitializer, ptr %s108
  %t2115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2115, ptr %l711, !tbaa !29
  %t2116 = load ptr, ptr %l0, !tbaa !29
  %t2117 = load i32, ptr %l2, !tbaa !23
  %t2120 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s108, ptr %t2116, i32 %t2117)
  store { i64, ptr } %t2120, ptr %l714
  br label %bb461
bb460:
  br label %bb463
bb461:
  %t2121 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t2122 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t2123 = load { i64, ptr }, ptr %l714, !tbaa !27
  %t2124 = extractvalue { i64, ptr } %t2123, 1
  %t2125 = extractvalue { i64, ptr } %t2123, 0
  %t2126 = add i64 %t2122, %t2125
  %t2127 = call ptr @__olang_scope_alloc(ptr %s108, i64 %t2126)
  call void @olang_textcopy(ptr %t2127, ptr %t2121, i64 %t2122)
  %t2128 = getelementptr i8, ptr %t2127, i64 %t2122
  call void @olang_textcopy(ptr %t2128, ptr %t2124, i64 %t2125)
  %t2129 = insertvalue { i64, ptr } undef, i64 %t2126, 0
  %t2130 = insertvalue { i64, ptr } %t2129, ptr %t2127, 1
  %t2132 = extractvalue { i64, ptr } %t2130, 0
  %t2133 = extractvalue { i64, ptr } %t2130, 1
  %t2134 = mul i64 %t2132, 1
  %t2135 = call ptr @__olang_scope_alloc(ptr %s108, i64 %t2134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2135, ptr %t2133, i64 %t2134, i1 false)
  %t2136 = insertvalue { i64, ptr } undef, i64 %t2132, 0
  %t2137 = insertvalue { i64, ptr } %t2136, ptr %t2135, 1
  %t2138 = load ptr, ptr %l711, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s108, ptr %t2138, { i64, ptr } %t2137)
  br label %bb462
bb462:
  call void @__olang_scope_close(ptr %s108)
  br label %bb463
bb463:
  br label %bb472
bb464:
  %t2140 = load i1, ptr %l720, !tbaa !21
  %t2141 = xor i1 %t2140, true
  br i1 %t2141, label %bb465, label %bb466
bb465:
  store %olang.scope zeroinitializer, ptr %s111
  %t2143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2143, ptr %l722, !tbaa !29
  %t2144 = load i32, ptr %l1
  store i32 %t2144, ptr %l723
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s112
  store ptr %s112room, ptr %s112
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s112, ptr %l723, i64 0)
  br label %bb467
bb466:
  br label %bb471
bb467:
  %t2146 = load ptr, ptr %s112
  %t2147 = getelementptr %olang.builder, ptr %s112, i32 0, i32 1
  %t2148 = load i64, ptr %t2147
  %t2149 = call ptr @__olang_scope_alloc(ptr %s111, i64 %t2148)
  call void @olang_textcopy(ptr %t2149, ptr %t2146, i64 %t2148)
  %t2150 = insertvalue { i64, ptr } undef, i64 %t2148, 0
  %t2151 = insertvalue { i64, ptr } %t2150, ptr %t2149, 1
  store { i64, ptr } %t2151, ptr %l725, !tbaa !27
  %t2152 = getelementptr %olang.builder, ptr %s112, i32 0, i32 3
  %t2153 = load ptr, ptr %t2152
  %t2154 = icmp ne ptr %t2153, null
  br i1 %t2154, label %sbgrew.2155, label %sbdone.2156
sbgrew.2155:
  call void @__olang_sb_done(ptr %s112)
  br label %sbdone.2156
sbdone.2156:
  %t2157 = load { i64, ptr }, ptr %l725, !tbaa !27
  %t2158 = extractvalue { i64, ptr } %t2157, 0
  %t2159 = extractvalue { i64, ptr } %t2157, 1
  %t2160 = mul i64 %t2158, 1
  %t2161 = call ptr @__olang_scope_alloc(ptr %s111, i64 %t2160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2161, ptr %t2159, i64 %t2160, i1 false)
  %t2162 = insertvalue { i64, ptr } undef, i64 %t2158, 0
  %t2163 = insertvalue { i64, ptr } %t2162, ptr %t2161, 1
  %t2165 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s111, { i64, ptr } %t2163)
  store { i64, ptr } %t2165, ptr %l727
  br label %bb468
bb468:
  %t2166 = load ptr, ptr %l0, !tbaa !29
  %t2167 = load i32, ptr %l2, !tbaa !23
  %t2170 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s111, ptr %t2166, i32 %t2167)
  store { i64, ptr } %t2170, ptr %l730
  br label %bb469
bb469:
  %t2171 = load { i64, ptr }, ptr %l727, !tbaa !27
  %t2172 = extractvalue { i64, ptr } %t2171, 1
  %t2173 = extractvalue { i64, ptr } %t2171, 0
  %t2174 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t2175 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t2176 = add i64 %t2173, %t2175
  %t2177 = load { i64, ptr }, ptr %l730, !tbaa !27
  %t2178 = extractvalue { i64, ptr } %t2177, 1
  %t2179 = extractvalue { i64, ptr } %t2177, 0
  %t2180 = add i64 %t2176, %t2179
  %t2181 = call ptr @__olang_scope_alloc(ptr %s111, i64 %t2180)
  call void @olang_textcopy(ptr %t2181, ptr %t2172, i64 %t2173)
  %t2182 = getelementptr i8, ptr %t2181, i64 %t2173
  call void @olang_textcopy(ptr %t2182, ptr %t2174, i64 %t2175)
  %t2183 = getelementptr i8, ptr %t2182, i64 %t2175
  call void @olang_textcopy(ptr %t2183, ptr %t2178, i64 %t2179)
  %t2184 = insertvalue { i64, ptr } undef, i64 %t2180, 0
  %t2185 = insertvalue { i64, ptr } %t2184, ptr %t2181, 1
  %t2187 = extractvalue { i64, ptr } %t2185, 0
  %t2188 = extractvalue { i64, ptr } %t2185, 1
  %t2189 = mul i64 %t2187, 1
  %t2190 = call ptr @__olang_scope_alloc(ptr %s111, i64 %t2189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2190, ptr %t2188, i64 %t2189, i1 false)
  %t2191 = insertvalue { i64, ptr } undef, i64 %t2187, 0
  %t2192 = insertvalue { i64, ptr } %t2191, ptr %t2190, 1
  %t2193 = load ptr, ptr %l722, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s111, ptr %t2193, { i64, ptr } %t2192)
  br label %bb470
bb470:
  call void @__olang_scope_close(ptr %s111)
  br label %bb471
bb471:
  br label %bb472
bb472:
  br label %bb473
bb473:
  br label %bb475
bb474:
  call void @__olang_check_failed(ptr @olang_loc_7968c2a45e42402b_522993cc8bbef1e7)
  unreachable
bb475:
  %t2195 = load i32, ptr %l2, !tbaa !23
  store i32 %t2195, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Range"
  %l7 = alloca i64
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store %"compiler/mir:Range" %a1, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/mir:verifier", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 12
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load %"compiler/mir:Range", ptr %l3
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s0, ptr %t11, %"compiler/mir:Range" %t12, i64 %t13, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d203, i32 0, i32 1) })
  store i1 %t14, ptr %l8
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueShape(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Place"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [1 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Place"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca %"compiler/mir:Range"
  %l15 = alloca %"compiler/mir:Range"
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca { i64, [1 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t10, { i64, [4 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb73
bb5:
  %t14 = load { i64, [15 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [15 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t19, i32 0, i32 0
  %t21 = load %"compiler/mir:Place", ptr %t20
  store %"compiler/mir:Place" %t21, ptr %l3
  br label %bb12
bb7:
  %t23 = load { i64, [15 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [15 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { %"compiler/mir:Place" }, ptr %t28, i32 0, i32 0
  %t30 = load %"compiler/mir:Place", ptr %t29
  store %"compiler/mir:Place" %t30, ptr %l3
  br label %bb12
bb9:
  %t32 = load { i64, [15 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [15 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 5
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { %"compiler/mir:Place" }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/mir:Place", ptr %t38
  store %"compiler/mir:Place" %t39, ptr %l3
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/mir:Place", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t41, %"compiler/mir:Place" %t42)
  br label %bb13
bb13:
  br label %bb73
bb14:
  %t45 = load { i64, [15 x i64] }, ptr %l1
  %t47 = extractvalue { i64, [15 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 3
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t51 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t50, i32 0, i32 2
  %t52 = load %"compiler/mir:Range", ptr %t51
  store %"compiler/mir:Range" %t52, ptr %l4
  br label %bb21
bb16:
  %t54 = load { i64, [15 x i64] }, ptr %l1
  %t56 = extractvalue { i64, [15 x i64] } %t54, 0
  %t57 = icmp eq i64 %t56, 4
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t60 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t59, i32 0, i32 2
  %t61 = load %"compiler/mir:Range", ptr %t60
  store %"compiler/mir:Range" %t61, ptr %l4
  br label %bb21
bb18:
  %t63 = load { i64, [15 x i64] }, ptr %l1
  %t65 = extractvalue { i64, [15 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 6
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t69 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t68, i32 0, i32 2
  %t70 = load %"compiler/mir:Range", ptr %t69
  store %"compiler/mir:Range" %t70, ptr %l4
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load %"compiler/mir:Range", ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t72, %"compiler/mir:Range" %t73)
  br label %bb22
bb22:
  br label %bb73
bb23:
  %t76 = load { i64, [15 x i64] }, ptr %l1
  %t78 = extractvalue { i64, [15 x i64] } %t76, 0
  %t79 = icmp eq i64 %t78, 7
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t81 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t82 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t81, i32 0, i32 0
  %t83 = load { i64, [1 x i64] }, ptr %t82
  store { i64, [1 x i64] } %t83, ptr %l5
  %t85 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t86 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t85, i32 0, i32 1
  %t87 = load { i64, [4 x i64] }, ptr %t86
  store { i64, [4 x i64] } %t87, ptr %l6
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load { i64, [1 x i64] }, ptr %l5
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t89, { i64, [1 x i64] } %t90)
  br label %bb27
bb27:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t93, { i64, [4 x i64] } %t94)
  br label %bb28
bb28:
  br label %bb73
bb29:
  %t97 = load { i64, [15 x i64] }, ptr %l1
  %t99 = extractvalue { i64, [15 x i64] } %t97, 0
  %t100 = icmp eq i64 %t99, 8
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t102 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t103 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t102, i32 0, i32 0
  %t104 = load { i64, [1 x i64] }, ptr %t103
  store { i64, [1 x i64] } %t104, ptr %l7
  %t106 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t107 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t106, i32 0, i32 2
  %t108 = load { i64, [4 x i64] }, ptr %t107
  store { i64, [4 x i64] } %t108, ptr %l8
  %t110 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t111 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t110, i32 0, i32 3
  %t112 = load { i64, [4 x i64] }, ptr %t111
  store { i64, [4 x i64] } %t112, ptr %l9
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load { i64, [1 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t114, { i64, [1 x i64] } %t115)
  br label %bb33
bb33:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, [4 x i64] }, ptr %l8
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t118, { i64, [4 x i64] } %t119)
  br label %bb34
bb34:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, [4 x i64] }, ptr %l9
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t122, { i64, [4 x i64] } %t123)
  br label %bb35
bb35:
  br label %bb73
bb36:
  %t126 = load { i64, [15 x i64] }, ptr %l1
  %t128 = extractvalue { i64, [15 x i64] } %t126, 0
  %t129 = icmp eq i64 %t128, 9
  br i1 %t129, label %bb37, label %bb38
bb37:
  %t131 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t132 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t131, i32 0, i32 0
  %t133 = load %"compiler/mir:Place", ptr %t132
  store %"compiler/mir:Place" %t133, ptr %l10
  %t135 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t136 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t135, i32 0, i32 1
  %t137 = load { i64, [4 x i64] }, ptr %t136
  store { i64, [4 x i64] } %t137, ptr %l11
  %t139 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t140 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t139, i32 0, i32 2
  %t141 = load { i64, [4 x i64] }, ptr %t140
  store { i64, [4 x i64] } %t141, ptr %l12
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load %"compiler/mir:Place", ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t143, %"compiler/mir:Place" %t144)
  br label %bb40
bb40:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load { i64, [4 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t147, { i64, [4 x i64] } %t148)
  br label %bb41
bb41:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load { i64, [4 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t151, { i64, [4 x i64] } %t152)
  br label %bb42
bb42:
  br label %bb73
bb43:
  %t155 = load { i64, [15 x i64] }, ptr %l1
  %t157 = extractvalue { i64, [15 x i64] } %t155, 0
  %t158 = icmp eq i64 %t157, 10
  br i1 %t158, label %bb44, label %bb45
bb44:
  %t160 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t161 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t160, i32 0, i32 2
  %t162 = load { i64, [1 x i64] }, ptr %t161
  store { i64, [1 x i64] } %t162, ptr %l13
  %t164 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t165 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t164, i32 0, i32 3
  %t166 = load %"compiler/mir:Range", ptr %t165
  store %"compiler/mir:Range" %t166, ptr %l14
  %t168 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t169 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t168, i32 0, i32 4
  %t170 = load %"compiler/mir:Range", ptr %t169
  store %"compiler/mir:Range" %t170, ptr %l15
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load { i64, [1 x i64] }, ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t172, { i64, [1 x i64] } %t173)
  br label %bb47
bb47:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load %"compiler/mir:Range", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t176, %"compiler/mir:Range" %t177)
  br label %bb48
bb48:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load %"compiler/mir:Range", ptr %l15
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %t180, %"compiler/mir:Range" %t181)
  br label %bb49
bb49:
  br label %bb73
bb50:
  %t184 = load { i64, [15 x i64] }, ptr %l1
  %t186 = extractvalue { i64, [15 x i64] } %t184, 0
  %t187 = icmp eq i64 %t186, 11
  br i1 %t187, label %bb51, label %bb52
bb51:
  %t189 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t190 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t189, i32 0, i32 0
  %t191 = load { i64, [4 x i64] }, ptr %t190
  store { i64, [4 x i64] } %t191, ptr %l16
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, [4 x i64] }, ptr %l16
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t193, { i64, [4 x i64] } %t194)
  br label %bb54
bb54:
  br label %bb73
bb55:
  %t197 = load { i64, [15 x i64] }, ptr %l1
  %t199 = extractvalue { i64, [15 x i64] } %t197, 0
  %t200 = icmp eq i64 %t199, 12
  br i1 %t200, label %bb56, label %bb57
bb56:
  %t202 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t203 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t202, i32 0, i32 0
  %t204 = load { i64, [1 x i64] }, ptr %t203
  store { i64, [1 x i64] } %t204, ptr %l17
  %t206 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t207 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t206, i32 0, i32 1
  %t208 = load { i64, [1 x i64] }, ptr %t207
  store { i64, [1 x i64] } %t208, ptr %l18
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load { i64, [1 x i64] }, ptr %l17
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t210, { i64, [1 x i64] } %t211)
  br label %bb59
bb59:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load { i64, [1 x i64] }, ptr %l18
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t214, { i64, [1 x i64] } %t215)
  br label %bb60
bb60:
  br label %bb73
bb61:
  %t218 = load { i64, [15 x i64] }, ptr %l1
  %t220 = extractvalue { i64, [15 x i64] } %t218, 0
  %t221 = icmp eq i64 %t220, 13
  br i1 %t221, label %bb62, label %bb63
bb62:
  %t223 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t224 = getelementptr { { i64, [1 x i64] } }, ptr %t223, i32 0, i32 0
  %t225 = load { i64, [1 x i64] }, ptr %t224
  store { i64, [1 x i64] } %t225, ptr %l19
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, [1 x i64] }, ptr %l19
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t227, { i64, [1 x i64] } %t228)
  br label %bb65
bb65:
  br label %bb73
bb66:
  %t231 = load { i64, [15 x i64] }, ptr %l1
  %t233 = extractvalue { i64, [15 x i64] } %t231, 0
  %t234 = icmp eq i64 %t233, 14
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t237 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t236, i32 0, i32 0
  %t238 = load { i64, [4 x i64] }, ptr %t237
  store { i64, [4 x i64] } %t238, ptr %l20
  %t240 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t241 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t240, i32 0, i32 1
  %t242 = load { i64, [1 x i64] }, ptr %t241
  store { i64, [1 x i64] } %t242, ptr %l21
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load { i64, [4 x i64] }, ptr %l20
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t244, { i64, [4 x i64] } %t245)
  br label %bb70
bb70:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load { i64, [1 x i64] }, ptr %l21
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t248, { i64, [1 x i64] } %t249)
  br label %bb71
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_d06e38c3720099d6_401a7f863dec038a)
  unreachable
bb73:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i64
  %l10 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 8
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l4, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t26 = sext i32 %t22 to i64
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t26)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } %t40)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb8:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esliceType(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i32
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca i32
  %l80 = alloca i1
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load i32, ptr %l16, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l5, !tbaa !29
  store ptr %t12, ptr %l17, !tbaa !29
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t14 = load i32, ptr %l4, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l20
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l17, !tbaa !29
  %t19 = load i32, ptr %l20, !tbaa !23
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t20, ptr %l21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l21, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l23, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l24, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l27
  br label %bb6
bb5:
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t29, ptr %l22, !tbaa !23
  br label %bb9
bb6:
  %t31 = load ptr, ptr %l24, !tbaa !29
  %t32 = load i32, ptr %l27, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t33, ptr %l28
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t35 = load i32, ptr %l28, !tbaa !23
  %t36 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l29
  br label %bb8
bb8:
  %t37 = load i32, ptr %l29, !tbaa !23
  store i32 %t37, ptr %l22, !tbaa !23
  br label %bb9
bb9:
  %t38 = load i32, ptr %l22, !tbaa !23
  store i32 %t38, ptr %l7, !tbaa !23
  %t39 = load i32, ptr %l6, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp eq i32 %t39, %t40
  br i1 %t43, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb12
bb11:
  %t45 = load i32, ptr %l7, !tbaa !23
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t49 = icmp eq i32 %t45, %t46
  store i1 %t49, ptr %l34, !tbaa !21
  br label %bb12
bb12:
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb20
bb14:
  %t52 = load ptr, ptr %l5, !tbaa !29
  store ptr %t52, ptr %l39, !tbaa !29
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l40, !tbaa !29
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t55 = load i32, ptr %l6, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l43
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l40, !tbaa !29
  %t60 = load i32, ptr %l43, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t61, ptr %l44
  br label %bb16
bb16:
  %t62 = load ptr, ptr %l5, !tbaa !29
  store ptr %t62, ptr %l45, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t64 = load i32, ptr %l7, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l48
  br label %bb17
bb17:
  %t68 = load ptr, ptr %l45, !tbaa !29
  %t69 = load i32, ptr %l48, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t70, ptr %l49
  br label %bb18
bb18:
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = load i32, ptr %l44, !tbaa !23
  %t73 = load i32, ptr %l49, !tbaa !23
  %t74 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t71, i32 %t72, i32 %t73)
  store i1 %t74, ptr %l50
  br label %bb19
bb19:
  %t75 = load i1, ptr %l50, !tbaa !21
  %t76 = xor i1 %t75, true
  store i1 %t76, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t78 = load i1, ptr %l38, !tbaa !21
  br i1 %t78, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s1
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l52, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l4, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t80, i32 %t81)
  store { i64, ptr } %t84, ptr %l55
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l1, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t85, i32 %t86)
  store { i64, ptr } %t89, ptr %l58
  br label %bb24
bb24:
  %t90 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t92 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t99 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = add i64 %t98, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t90, i64 %t91)
  %t104 = getelementptr i8, ptr %t103, i64 %t91
  call void @olang_textcopy(ptr %t104, ptr %t93, i64 %t94)
  %t105 = getelementptr i8, ptr %t104, i64 %t94
  call void @olang_textcopy(ptr %t105, ptr %t96, i64 %t97)
  %t106 = getelementptr i8, ptr %t105, i64 %t97
  call void @olang_textcopy(ptr %t106, ptr %t100, i64 %t101)
  %t107 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t103, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = extractvalue { i64, ptr } %t108, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t116 = load ptr, ptr %l52, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t116, { i64, ptr } %t115)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t121 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %a2, 0
  %t123 = insertvalue [2 x { i64, [4 x i64] }] %t121, { i64, [4 x i64] } %a3, 1
  %t125 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 80, i64 8)
  store [2 x { i64, [4 x i64] }] %t123, ptr %t125
  store ptr %t125, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t127 = load ptr, ptr %l8
  store i64 2, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t130 = load i64, ptr %l9, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb28, label %bb29
bb28:
  br label %bb39
bb29:
  br label %bb30
bb30:
  %t138 = load ptr, ptr %l8
  %t139 = load i64, ptr %l9, !tbaa !24
  %t142 = getelementptr [2 x { i64, [4 x i64] }], ptr %t138, i64 0, i64 %t139
  %t143 = load { i64, [4 x i64] }, ptr %t142
  %t145 = load ptr, ptr %l5, !tbaa !29
  store ptr %t145, ptr %l74, !tbaa !29
  %t146 = load ptr, ptr %l5, !tbaa !29
  store ptr %t146, ptr %l75, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t151 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t147, { i64, [4 x i64] } %t143)
  store i32 %t151, ptr %l78
  br label %bb31
bb31:
  %t152 = load ptr, ptr %l75, !tbaa !29
  %t153 = load i32, ptr %l78, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t154, ptr %l79
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l74, !tbaa !29
  %t156 = load i32, ptr %l79, !tbaa !23
  %t157 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t155, i32 %t156)
  store i1 %t157, ptr %l80
  br label %bb33
bb33:
  %t158 = load i1, ptr %l80, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t161 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t161, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d207, i32 0, i32 1) })
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t163 = load i64, ptr %l9, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l9, !tbaa !24
  br label %bb27
bb39:
  call void @__olang_scope_close(ptr %s3)
  %t167 = load i32, ptr %l4, !tbaa !23
  store i32 %t167, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtFlow(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Place"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca %"compiler/mir:Place"
  %l17 = alloca %"compiler/mir:Place"
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca %"compiler/mir:Place"
  %l21 = alloca %"compiler/mir:Place"
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca %"compiler/mir:Task"
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l44 = alloca { i64, [1 x i64] }
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l51 = alloca i32
  %l52 = alloca i32
  %l55 = alloca ptr
  %l56 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l77 = alloca %"compiler/mir:Local"
  %l85 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca i1
  %l99 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l110 = alloca %"compiler/mir:Local"
  %l113 = alloca ptr
  %l114 = alloca i1
  %l121 = alloca i1
  %l128 = alloca i64
  %l130 = alloca i32
  %l132 = alloca ptr
  %l135 = alloca i64
  %l137 = alloca i32
  %l143 = alloca %"compiler/mir:ScopeInfo"
  %l148 = alloca ptr
  %l149 = alloca i32
  %l152 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l166 = alloca i1
  %l174 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l183 = alloca i1
  %l192 = alloca %"compiler/mir:ScopeInfo"
  %l202 = alloca ptr
  %l203 = alloca i1
  %l214 = alloca ptr
  %l215 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca i1
  %l246 = alloca ptr
  %l247 = alloca i1
  %l262 = alloca ptr
  %l263 = alloca i1
  %l272 = alloca i1
  %l282 = alloca %"compiler/mir:Task"
  %l287 = alloca i32
  %l290 = alloca i32
  %l308 = alloca ptr
  %l316 = alloca %"compiler/mir:Place"
  %l327 = alloca i32
  %l330 = alloca i32
  %l348 = alloca ptr
  %l356 = alloca { i64, [1 x i64] }
  %l363 = alloca i32
  %l366 = alloca i32
  %l391 = alloca { i64, [1 x i64] }
  %l403 = alloca i32
  %l406 = alloca i32
  %l424 = alloca ptr
  %l432 = alloca %"compiler/mir:TaskClause"
  %l437 = alloca { i64, ptr }
  %l440 = alloca ptr
  %l441 = alloca i1
  %l444 = alloca ptr
  %l445 = alloca i1
  %l454 = alloca i1
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s39 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t7 = load ptr, ptr %l55, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l55, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l56, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l56, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t17, i32 0, i32 1
  %t19 = load %"compiler/mir:Place", ptr %t18
  store %"compiler/mir:Place" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t23, i32 0, i32 2
  %t25 = load { i64, [15 x i64] }, ptr %t24
  store { i64, [15 x i64] } %t25, ptr %l4
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, [15 x i64] }, ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueFlow(ptr %v0, ptr %t27, { i64, [15 x i64] } %t28)
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/mir:Place", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estores(ptr %v0, ptr %t31, %"compiler/mir:Place" %t32)
  br label %bb7
bb7:
  br label %bb209
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t36 = load ptr, ptr %l67, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l67, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 1
  store i1 %t42, ptr %l68, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l68, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [21 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32 }, ptr %t46, i32 0, i32 1
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/mir:Fn", ptr %t50, i32 0, i32 7
  %t53 = load i32, ptr %l5, !tbaa !23
  %t55 = sext i32 %t53 to i64
  %t58 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t52, i64 %t55)
  store %"compiler/mir:Local" %t58, ptr %l77
  br label %bb14
bb14:
  %t59 = getelementptr %"compiler/mir:Local", ptr %l77, i32 0, i32 4
  %t60 = load { i64, [1 x i64] }, ptr %t59
  store { i64, [1 x i64] } %t60, ptr %l6
  %t62 = load { i64, [1 x i64] }, ptr %l6
  %t64 = extractvalue { i64, [1 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 3
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load { i64, [1 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t69, { i64, [1 x i64] } %t70)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/mir:verifier", ptr %t73, i32 0, i32 15
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l85, !tbaa !27
  %t77 = load i32, ptr %l5, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t81 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i1, ptr %t82, i64 %t79
  store i1 true, ptr %t83, !tbaa !31
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/mir:verifier", ptr %t84, i32 0, i32 14
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l89, !tbaa !27
  %t88 = load i32, ptr %l5, !tbaa !23
  %t90 = sext i32 %t88 to i64
  %t92 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i1, ptr %t93, i64 %t90
  store i1 false, ptr %t94, !tbaa !31
  br label %bb209
bb19:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t96 = load ptr, ptr %l92, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb20, label %bb21
bb20:
  %t99 = load ptr, ptr %l92, !tbaa !29
  %t100 = load i64, ptr %t99
  %t102 = icmp eq i64 %t100, 2
  store i1 %t102, ptr %l93, !tbaa !21
  br label %bb21
bb21:
  %t103 = load i1, ptr %l93, !tbaa !21
  br i1 %t103, label %bb22, label %bb23
bb22:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [21 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32 }, ptr %t106, i32 0, i32 1
  %t108 = load i32, ptr %t107
  store i32 %t108, ptr %l7, !tbaa !23
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/mir:verifier", ptr %t110, i32 0, i32 14
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l99, !tbaa !27
  %t114 = load i32, ptr %l7, !tbaa !23
  %t116 = sext i32 %t114 to i64
  %t118 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i1, ptr %t119, i64 %t116
  store i1 false, ptr %t120, !tbaa !31
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/mir:verifier", ptr %t121, i32 0, i32 15
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l103, !tbaa !27
  %t125 = load i32, ptr %l7, !tbaa !23
  %t127 = sext i32 %t125 to i64
  store i64 %t127, ptr %l105, !tbaa !24
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t130 = getelementptr %"compiler/mir:Fn", ptr %t128, i32 0, i32 7
  %t131 = load i32, ptr %l7, !tbaa !23
  %t133 = sext i32 %t131 to i64
  %t136 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t130, i64 %t133)
  store %"compiler/mir:Local" %t136, ptr %l110
  br label %bb25
bb25:
  %t137 = getelementptr %"compiler/mir:Local", ptr %l110, i32 0, i32 4
  %t138 = load { i64, [1 x i64] }, ptr %t137
  %t140 = extractvalue { i64, [1 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 3
  %t143 = load i64, ptr %l105, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i1, ptr %t145, i64 %t143
  store i1 %t141, ptr %t146, !tbaa !31
  br label %bb209
bb26:
  %t147 = load ptr, ptr %l1, !tbaa !29
  store ptr %t147, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t148 = load ptr, ptr %l113, !tbaa !29
  %t149 = icmp ne ptr %t148, null
  br i1 %t149, label %bb27, label %bb28
bb27:
  %t151 = load ptr, ptr %l113, !tbaa !29
  %t152 = load i64, ptr %t151
  %t154 = icmp eq i64 %t152, 3
  store i1 %t154, ptr %l114, !tbaa !21
  br label %bb28
bb28:
  %t155 = load i1, ptr %l114, !tbaa !21
  br i1 %t155, label %bb29, label %bb30
bb29:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr { i64, [21 x i64] }, ptr %t156, i32 0, i32 1
  %t159 = getelementptr { %"compiler/source:Span", i32 }, ptr %t158, i32 0, i32 1
  %t160 = load i32, ptr %t159
  store i32 %t160, ptr %l8, !tbaa !23
  br label %bb31
bb30:
  br label %bb51
bb31:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l8, !tbaa !23
  %t166 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t162, i32 %t163)
  store i1 %t166, ptr %l121
  br label %bb32
bb32:
  %t167 = load i1, ptr %l121, !tbaa !21
  br i1 %t167, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l8, !tbaa !23
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t173 = sext i32 %t169 to i64
  %t174 = call i64 @__olang_fmt_i64(ptr null, i64 %t173)
  %t175 = add i64 %t171, %t174
  %t176 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t178 = add i64 %t175, %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t170, i64 %t171)
  %t180 = getelementptr i8, ptr %t179, i64 %t171
  %t181 = call i64 @__olang_fmt_i64(ptr %t180, i64 %t173)
  %t182 = getelementptr i8, ptr %t180, i64 %t174
  call void @olang_textcopy(ptr %t182, ptr %t176, i64 %t177)
  %t183 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t179, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = extractvalue { i64, ptr } %t184, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s6, ptr %t168, { i64, ptr } %t191)
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb36:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/mir:verifier", ptr %t194, i32 0, i32 17
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t196)
  store i64 %t198, ptr %l128
  br label %bb37
bb37:
  %t199 = load i64, ptr %l128, !tbaa !24
  %t200 = icmp sgt i64 %t199, 0
  br i1 %t200, label %bb38, label %bb39
bb38:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/mir:verifier", ptr %t202, i32 0, i32 17
  store ptr %t204, ptr %l132, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/mir:verifier", ptr %t205, i32 0, i32 17
  %t209 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t207)
  store i64 %t209, ptr %l135
  br label %bb40
bb39:
  %t210 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  store i32 %t210, ptr %l130, !tbaa !23
  br label %bb42
bb40:
  %t212 = load i64, ptr %l135, !tbaa !24
  %t213 = sub i64 %t212, 1
  %t214 = load ptr, ptr %l132, !tbaa !29
  %t216 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t214, i64 %t213)
  store i32 %t216, ptr %l137
  br label %bb41
bb41:
  %t217 = load i32, ptr %l137, !tbaa !23
  store i32 %t217, ptr %l130, !tbaa !23
  br label %bb42
bb42:
  %t218 = load i32, ptr %l130, !tbaa !23
  store i32 %t218, ptr %l9, !tbaa !23
  %t219 = load ptr, ptr %l2, !tbaa !29
  %t221 = getelementptr %"compiler/mir:Fn", ptr %t219, i32 0, i32 8
  %t222 = load i32, ptr %l8, !tbaa !23
  %t224 = sext i32 %t222 to i64
  %t227 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t221, i64 %t224)
  store %"compiler/mir:ScopeInfo" %t227, ptr %l143
  br label %bb43
bb43:
  %t228 = getelementptr %"compiler/mir:ScopeInfo", ptr %l143, i32 0, i32 1
  %t229 = load i32, ptr %t228, !tbaa !23
  store i32 %t229, ptr %l10, !tbaa !23
  %t231 = load i32, ptr %l10, !tbaa !23
  %t232 = load i32, ptr %l9, !tbaa !23
  %t235 = icmp ne i32 %t231, %t232
  br i1 %t235, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l148, !tbaa !29
  %t238 = load i32, ptr %l8, !tbaa !23
  store i32 %t238, ptr %l149, !tbaa !23
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l9, !tbaa !23
  %t243 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %s8, ptr %t239, i32 %t240)
  store { i64, ptr } %t243, ptr %l152
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i32, ptr %l10, !tbaa !23
  %t248 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %s8, ptr %t244, i32 %t245)
  store { i64, ptr } %t248, ptr %l155
  br label %bb47
bb47:
  %t249 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t251 = load i32, ptr %l149, !tbaa !23
  %t252 = sext i32 %t251 to i64
  %t253 = call i64 @__olang_fmt_i64(ptr null, i64 %t252)
  %t254 = add i64 %t250, %t253
  %t255 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t257 = add i64 %t254, %t256
  %t258 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = add i64 %t257, %t260
  %t262 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t264 = add i64 %t261, %t263
  %t265 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = add i64 %t264, %t267
  %t269 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t268)
  call void @olang_textcopy(ptr %t269, ptr %t249, i64 %t250)
  %t270 = getelementptr i8, ptr %t269, i64 %t250
  %t271 = call i64 @__olang_fmt_i64(ptr %t270, i64 %t252)
  %t272 = getelementptr i8, ptr %t270, i64 %t253
  call void @olang_textcopy(ptr %t272, ptr %t255, i64 %t256)
  %t273 = getelementptr i8, ptr %t272, i64 %t256
  call void @olang_textcopy(ptr %t273, ptr %t259, i64 %t260)
  %t274 = getelementptr i8, ptr %t273, i64 %t260
  call void @olang_textcopy(ptr %t274, ptr %t262, i64 %t263)
  %t275 = getelementptr i8, ptr %t274, i64 %t263
  call void @olang_textcopy(ptr %t275, ptr %t266, i64 %t267)
  %t276 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t269, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = extractvalue { i64, ptr } %t277, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  %t285 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t285, { i64, ptr } %t284)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb49:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/mir:verifier", ptr %t287, i32 0, i32 17
  %t290 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t289, i32 %t290)
  br label %bb50
bb50:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/mir:verifier", ptr %t293, i32 0, i32 16
  %t296 = load { i64, ptr }, ptr %t295, !tbaa !27
  store { i64, ptr } %t296, ptr %l162, !tbaa !27
  %t297 = load i32, ptr %l8, !tbaa !23
  %t299 = sext i32 %t297 to i64
  %t301 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr i1, ptr %t302, i64 %t299
  store i1 false, ptr %t303, !tbaa !31
  br label %bb209
bb51:
  %t304 = load ptr, ptr %l1, !tbaa !29
  store ptr %t304, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t305 = load ptr, ptr %l165, !tbaa !29
  %t306 = icmp ne ptr %t305, null
  br i1 %t306, label %bb52, label %bb53
bb52:
  %t308 = load ptr, ptr %l165, !tbaa !29
  %t309 = load i64, ptr %t308
  %t311 = icmp eq i64 %t309, 4
  store i1 %t311, ptr %l166, !tbaa !21
  br label %bb53
bb53:
  %t312 = load i1, ptr %l166, !tbaa !21
  br i1 %t312, label %bb54, label %bb55
bb54:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [21 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", i32 }, ptr %t315, i32 0, i32 1
  %t317 = load i32, ptr %t316
  store i32 %t317, ptr %l11, !tbaa !23
  br label %bb56
bb55:
  br label %bb62
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %s10, ptr %t319, i32 %t320, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d213, i32 0, i32 1) })
  br label %bb57
bb57:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/mir:verifier", ptr %t323, i32 0, i32 16
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l174, !tbaa !27
  %t327 = load i32, ptr %l11, !tbaa !23
  %t329 = sext i32 %t327 to i64
  %t331 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr i1, ptr %t332, i64 %t329
  %t334 = load i1, ptr %t333, !tbaa !31
  br i1 %t334, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i32, ptr %l11, !tbaa !23
  %t338 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t341 = sext i32 %t337 to i64
  %t342 = call i64 @__olang_fmt_i64(ptr null, i64 %t341)
  %t343 = add i64 %t339, %t342
  %t344 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t345 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t346 = add i64 %t343, %t345
  %t347 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t346)
  call void @olang_textcopy(ptr %t347, ptr %t338, i64 %t339)
  %t348 = getelementptr i8, ptr %t347, i64 %t339
  %t349 = call i64 @__olang_fmt_i64(ptr %t348, i64 %t341)
  %t350 = getelementptr i8, ptr %t348, i64 %t342
  call void @olang_textcopy(ptr %t350, ptr %t344, i64 %t345)
  %t351 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t347, 1
  %t354 = extractvalue { i64, ptr } %t352, 0
  %t355 = extractvalue { i64, ptr } %t352, 1
  %t356 = mul i64 %t354, 1
  %t357 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t356)
  call void @llvm.memcpy.p0.p0.i64(ptr %t357, ptr %t355, i64 %t356, i1 false)
  %t358 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t336, { i64, ptr } %t359)
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s11)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  br label %bb209
bb62:
  %t362 = load ptr, ptr %l1, !tbaa !29
  store ptr %t362, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t363 = load ptr, ptr %l182, !tbaa !29
  %t364 = icmp ne ptr %t363, null
  br i1 %t364, label %bb63, label %bb64
bb63:
  %t366 = load ptr, ptr %l182, !tbaa !29
  %t367 = load i64, ptr %t366
  %t369 = icmp eq i64 %t367, 5
  store i1 %t369, ptr %l183, !tbaa !21
  br label %bb64
bb64:
  %t370 = load i1, ptr %l183, !tbaa !21
  br i1 %t370, label %bb65, label %bb66
bb65:
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [21 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", i32 }, ptr %t373, i32 0, i32 1
  %t375 = load i32, ptr %t374
  store i32 %t375, ptr %l12, !tbaa !23
  br label %bb67
bb66:
  br label %bb74
bb67:
  store %olang.scope zeroinitializer, ptr %s13
  %t377 = load ptr, ptr %l2, !tbaa !29
  %t379 = getelementptr %"compiler/mir:Fn", ptr %t377, i32 0, i32 8
  %t380 = load i32, ptr %l12, !tbaa !23
  %t382 = sext i32 %t380 to i64
  %t385 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t379, i64 %t382)
  store %"compiler/mir:ScopeInfo" %t385, ptr %l192
  br label %bb68
bb68:
  %t386 = getelementptr %"compiler/mir:ScopeInfo", ptr %l192, i32 0, i32 0
  %t387 = load i32, ptr %t386
  %t389 = trunc i64 4 to i32
  %t390 = icmp eq i32 %t387, %t389
  %t392 = xor i1 %t390, true
  br i1 %t392, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s14
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load i32, ptr %l12, !tbaa !23
  %t396 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t397 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t399 = sext i32 %t395 to i64
  %t400 = call i64 @__olang_fmt_i64(ptr null, i64 %t399)
  %t401 = add i64 %t397, %t400
  %t402 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t403 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t404 = add i64 %t401, %t403
  %t405 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t404)
  call void @olang_textcopy(ptr %t405, ptr %t396, i64 %t397)
  %t406 = getelementptr i8, ptr %t405, i64 %t397
  %t407 = call i64 @__olang_fmt_i64(ptr %t406, i64 %t399)
  %t408 = getelementptr i8, ptr %t406, i64 %t400
  call void @olang_textcopy(ptr %t408, ptr %t402, i64 %t403)
  %t409 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t405, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = extractvalue { i64, ptr } %t410, 1
  %t414 = mul i64 %t412, 1
  %t415 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t414)
  call void @llvm.memcpy.p0.p0.i64(ptr %t415, ptr %t413, i64 %t414, i1 false)
  %t416 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t415, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s14, ptr %t394, { i64, ptr } %t417)
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s14)
  br label %bb72
bb72:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %s13, ptr %t420, i32 %t421, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d218, i32 0, i32 1) })
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s13)
  br label %bb209
bb74:
  %t424 = load ptr, ptr %l1, !tbaa !29
  store ptr %t424, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t425 = load ptr, ptr %l202, !tbaa !29
  %t426 = icmp ne ptr %t425, null
  br i1 %t426, label %bb75, label %bb76
bb75:
  %t428 = load ptr, ptr %l202, !tbaa !29
  %t429 = load i64, ptr %t428
  %t431 = icmp eq i64 %t429, 6
  store i1 %t431, ptr %l203, !tbaa !21
  br label %bb76
bb76:
  %t432 = load i1, ptr %l203, !tbaa !21
  br i1 %t432, label %bb77, label %bb78
bb77:
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t435 = getelementptr { i64, [21 x i64] }, ptr %t433, i32 0, i32 1
  %t436 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t435, i32 0, i32 1
  %t437 = load { i64, [1 x i64] }, ptr %t436
  store { i64, [1 x i64] } %t437, ptr %l13
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr { i64, [21 x i64] }, ptr %t439, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t441, i32 0, i32 3
  %t443 = load { i64, [4 x i64] }, ptr %t442
  store { i64, [4 x i64] } %t443, ptr %l14
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load { i64, [1 x i64] }, ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t445, { i64, [1 x i64] } %t446)
  br label %bb80
bb80:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t450 = load { i64, [4 x i64] }, ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t449, { i64, [4 x i64] } %t450)
  br label %bb81
bb81:
  br label %bb209
bb82:
  %t453 = load ptr, ptr %l1, !tbaa !29
  store ptr %t453, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t454 = load ptr, ptr %l214, !tbaa !29
  %t455 = icmp ne ptr %t454, null
  br i1 %t455, label %bb83, label %bb84
bb83:
  %t457 = load ptr, ptr %l214, !tbaa !29
  %t458 = load i64, ptr %t457
  %t460 = icmp eq i64 %t458, 7
  store i1 %t460, ptr %l215, !tbaa !21
  br label %bb84
bb84:
  %t461 = load i1, ptr %l215, !tbaa !21
  br i1 %t461, label %bb85, label %bb86
bb85:
  %t462 = load ptr, ptr %l1, !tbaa !29
  %t464 = getelementptr { i64, [21 x i64] }, ptr %t462, i32 0, i32 1
  %t465 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t464, i32 0, i32 1
  %t466 = load { i64, [1 x i64] }, ptr %t465
  store { i64, [1 x i64] } %t466, ptr %l15
  %t468 = load ptr, ptr %l1, !tbaa !29
  %t470 = getelementptr { i64, [21 x i64] }, ptr %t468, i32 0, i32 1
  %t471 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t470, i32 0, i32 2
  %t472 = load %"compiler/mir:Place", ptr %t471
  store %"compiler/mir:Place" %t472, ptr %l16
  br label %bb87
bb86:
  br label %bb90
bb87:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load { i64, [1 x i64] }, ptr %l15
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t474, { i64, [1 x i64] } %t475)
  br label %bb88
bb88:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/mir:Place", ptr %l16
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t478, %"compiler/mir:Place" %t479)
  br label %bb89
bb89:
  br label %bb209
bb90:
  %t482 = load ptr, ptr %l1, !tbaa !29
  store ptr %t482, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t483 = load ptr, ptr %l226, !tbaa !29
  %t484 = icmp ne ptr %t483, null
  br i1 %t484, label %bb91, label %bb92
bb91:
  %t486 = load ptr, ptr %l226, !tbaa !29
  %t487 = load i64, ptr %t486
  %t489 = icmp eq i64 %t487, 8
  store i1 %t489, ptr %l227, !tbaa !21
  br label %bb92
bb92:
  %t490 = load i1, ptr %l227, !tbaa !21
  br i1 %t490, label %bb93, label %bb94
bb93:
  %t491 = load ptr, ptr %l1, !tbaa !29
  %t493 = getelementptr { i64, [21 x i64] }, ptr %t491, i32 0, i32 1
  %t494 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place" }, ptr %t493, i32 0, i32 1
  %t495 = load %"compiler/mir:Place", ptr %t494
  store %"compiler/mir:Place" %t495, ptr %l17
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load %"compiler/mir:Place", ptr %l17
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t497, %"compiler/mir:Place" %t498)
  br label %bb96
bb96:
  br label %bb209
bb97:
  %t501 = load ptr, ptr %l1, !tbaa !29
  store ptr %t501, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t502 = load ptr, ptr %l234, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb98, label %bb99
bb98:
  %t505 = load ptr, ptr %l234, !tbaa !29
  %t506 = load i64, ptr %t505
  %t508 = icmp eq i64 %t506, 9
  store i1 %t508, ptr %l235, !tbaa !21
  br label %bb99
bb99:
  %t509 = load i1, ptr %l235, !tbaa !21
  br i1 %t509, label %bb100, label %bb101
bb100:
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [21 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t512, i32 0, i32 1
  %t514 = load { i64, [1 x i64] }, ptr %t513
  store { i64, [1 x i64] } %t514, ptr %l18
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr { i64, [21 x i64] }, ptr %t516, i32 0, i32 1
  %t519 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t518, i32 0, i32 3
  %t520 = load { i64, [4 x i64] }, ptr %t519
  store { i64, [4 x i64] } %t520, ptr %l19
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load { i64, [1 x i64] }, ptr %l18
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t522, { i64, [1 x i64] } %t523)
  br label %bb103
bb103:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load { i64, [4 x i64] }, ptr %l19
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t526, { i64, [4 x i64] } %t527)
  br label %bb104
bb104:
  br label %bb209
bb105:
  %t530 = load ptr, ptr %l1, !tbaa !29
  store ptr %t530, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t531 = load ptr, ptr %l246, !tbaa !29
  %t532 = icmp ne ptr %t531, null
  br i1 %t532, label %bb106, label %bb107
bb106:
  %t534 = load ptr, ptr %l246, !tbaa !29
  %t535 = load i64, ptr %t534
  %t537 = icmp eq i64 %t535, 10
  store i1 %t537, ptr %l247, !tbaa !21
  br label %bb107
bb107:
  %t538 = load i1, ptr %l247, !tbaa !21
  br i1 %t538, label %bb108, label %bb109
bb108:
  %t539 = load ptr, ptr %l1, !tbaa !29
  %t541 = getelementptr { i64, [21 x i64] }, ptr %t539, i32 0, i32 1
  %t542 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t541, i32 0, i32 1
  %t543 = load %"compiler/mir:Place", ptr %t542
  store %"compiler/mir:Place" %t543, ptr %l20
  %t545 = load ptr, ptr %l1, !tbaa !29
  %t547 = getelementptr { i64, [21 x i64] }, ptr %t545, i32 0, i32 1
  %t548 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t547, i32 0, i32 2
  %t549 = load %"compiler/mir:Place", ptr %t548
  store %"compiler/mir:Place" %t549, ptr %l21
  %t551 = load ptr, ptr %l1, !tbaa !29
  %t553 = getelementptr { i64, [21 x i64] }, ptr %t551, i32 0, i32 1
  %t554 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t553, i32 0, i32 3
  %t555 = load { i64, [4 x i64] }, ptr %t554
  store { i64, [4 x i64] } %t555, ptr %l22
  br label %bb110
bb109:
  br label %bb114
bb110:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load %"compiler/mir:Place", ptr %l21
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t557, %"compiler/mir:Place" %t558)
  br label %bb111
bb111:
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t562 = load { i64, [4 x i64] }, ptr %l22
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t561, { i64, [4 x i64] } %t562)
  br label %bb112
bb112:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load %"compiler/mir:Place", ptr %l20
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t565, %"compiler/mir:Place" %t566)
  br label %bb113
bb113:
  br label %bb209
bb114:
  %t569 = load ptr, ptr %l1, !tbaa !29
  store ptr %t569, ptr %l262, !tbaa !29
  store i1 false, ptr %l263, !tbaa !21
  %t570 = load ptr, ptr %l262, !tbaa !29
  %t571 = icmp ne ptr %t570, null
  br i1 %t571, label %bb115, label %bb116
bb115:
  %t573 = load ptr, ptr %l262, !tbaa !29
  %t574 = load i64, ptr %t573
  %t576 = icmp eq i64 %t574, 11
  store i1 %t576, ptr %l263, !tbaa !21
  br label %bb116
bb116:
  %t577 = load i1, ptr %l263, !tbaa !21
  br i1 %t577, label %bb117, label %bb118
bb117:
  %t578 = load ptr, ptr %l1, !tbaa !29
  %t580 = getelementptr { i64, [21 x i64] }, ptr %t578, i32 0, i32 1
  %t581 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t580, i32 0, i32 1
  %t582 = load i32, ptr %t581
  store i32 %t582, ptr %l23, !tbaa !23
  %t584 = load ptr, ptr %l1, !tbaa !29
  %t586 = getelementptr { i64, [21 x i64] }, ptr %t584, i32 0, i32 1
  %t587 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t586, i32 0, i32 2
  %t588 = load i32, ptr %t587
  store i32 %t588, ptr %l24, !tbaa !23
  br label %bb119
bb118:
  br label %bb187
bb119:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load i32, ptr %l23, !tbaa !23
  %t594 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t590, i32 %t591)
  store i1 %t594, ptr %l272
  br label %bb120
bb120:
  %t595 = load i1, ptr %l272, !tbaa !21
  %t596 = xor i1 %t595, true
  br i1 %t596, label %bb121, label %bb122
bb121:
  store %olang.scope zeroinitializer, ptr %s22
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load i32, ptr %l23, !tbaa !23
  %t600 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t601 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t603 = sext i32 %t599 to i64
  %t604 = call i64 @__olang_fmt_i64(ptr null, i64 %t603)
  %t605 = add i64 %t601, %t604
  %t606 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t607 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t608 = add i64 %t605, %t607
  %t609 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t608)
  call void @olang_textcopy(ptr %t609, ptr %t600, i64 %t601)
  %t610 = getelementptr i8, ptr %t609, i64 %t601
  %t611 = call i64 @__olang_fmt_i64(ptr %t610, i64 %t603)
  %t612 = getelementptr i8, ptr %t610, i64 %t604
  call void @olang_textcopy(ptr %t612, ptr %t606, i64 %t607)
  %t613 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t614 = insertvalue { i64, ptr } %t613, ptr %t609, 1
  %t616 = extractvalue { i64, ptr } %t614, 0
  %t617 = extractvalue { i64, ptr } %t614, 1
  %t618 = mul i64 %t616, 1
  %t619 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t618)
  call void @llvm.memcpy.p0.p0.i64(ptr %t619, ptr %t617, i64 %t618, i1 false)
  %t620 = insertvalue { i64, ptr } undef, i64 %t616, 0
  %t621 = insertvalue { i64, ptr } %t620, ptr %t619, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s22, ptr %t598, { i64, ptr } %t621)
  br label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_scope_close(ptr %s22)
  br label %bb124
bb124:
  %t624 = load ptr, ptr %l2, !tbaa !29
  %t626 = getelementptr %"compiler/mir:Fn", ptr %t624, i32 0, i32 16
  %t627 = load i32, ptr %l24, !tbaa !23
  %t629 = sext i32 %t627 to i64
  %t632 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t626, i64 %t629)
  store %"compiler/mir:Task" %t632, ptr %l282
  br label %bb125
bb125:
  %t633 = load %"compiler/mir:Task", ptr %l282
  store %"compiler/mir:Task" %t633, ptr %l25
  store i32 0, ptr %l26, !tbaa !23
  %t634 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 3
  %t635 = getelementptr %"compiler/mir:Range", ptr %t634, i32 0, i32 1
  %t636 = load i32, ptr %t635, !tbaa !23
  store i32 %t636, ptr %l27, !tbaa !23
  store i32 1, ptr %l28, !tbaa !23
  %t638 = load i32, ptr %l27, !tbaa !23
  %t639 = load i32, ptr %l26, !tbaa !23
  %t642 = icmp sgt i32 %t638, %t639
  br i1 %t642, label %bb126, label %bb127
bb126:
  %t644 = load i32, ptr %l28, !tbaa !23
  %t646 = icmp sgt i32 %t644, 0
  br i1 %t646, label %bb128, label %bb129
bb127:
  store i32 0, ptr %l287, !tbaa !23
  br label %bb131
bb128:
  %t648 = load i32, ptr %l27, !tbaa !23
  %t649 = load i32, ptr %l26, !tbaa !23
  %t652 = sub i32 %t648, %t649
  %t653 = load i32, ptr %l28, !tbaa !23
  %t656 = add i32 %t652, %t653
  %t658 = sub i32 %t656, 1
  %t659 = load i32, ptr %l28, !tbaa !23
  %t662 = sdiv i32 %t658, %t659
  store i32 %t662, ptr %l290, !tbaa !23
  br label %bb130
bb129:
  store i32 0, ptr %l290, !tbaa !23
  br label %bb130
bb130:
  %t664 = load i32, ptr %l290, !tbaa !23
  store i32 %t664, ptr %l287, !tbaa !23
  br label %bb131
bb131:
  %t665 = load i32, ptr %l287, !tbaa !23
  store i32 %t665, ptr %l29, !tbaa !23
  store i32 0, ptr %l30, !tbaa !23
  br label %bb132
bb132:
  %t666 = load i32, ptr %l30, !tbaa !23
  %t667 = load i32, ptr %l29, !tbaa !23
  %t670 = icmp slt i32 %t666, %t667
  %t672 = xor i1 %t670, true
  br i1 %t672, label %bb133, label %bb134
bb133:
  br label %bb139
bb134:
  br label %bb135
bb135:
  %t674 = load i32, ptr %l26, !tbaa !23
  %t675 = load i32, ptr %l30, !tbaa !23
  %t676 = load i32, ptr %l28, !tbaa !23
  %t679 = mul i32 %t675, %t676
  %t682 = add i32 %t674, %t679
  %t684 = load ptr, ptr %l0, !tbaa !29
  store ptr %t684, ptr %l308, !tbaa !29
  %t685 = load ptr, ptr %l2, !tbaa !29
  %t687 = getelementptr %"compiler/mir:Fn", ptr %t685, i32 0, i32 13
  %t688 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 3
  %t689 = getelementptr %"compiler/mir:Range", ptr %t688, i32 0, i32 0
  %t690 = load i32, ptr %t689, !tbaa !23
  %t692 = sext i32 %t690 to i64
  %t695 = sext i32 %t682 to i64
  %t698 = add i64 %t692, %t695
  %t701 = call %"compiler/mir:Place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t687, i64 %t698)
  store %"compiler/mir:Place" %t701, ptr %l316
  br label %bb136
bb136:
  %t702 = load ptr, ptr %l308, !tbaa !29
  %t703 = load %"compiler/mir:Place", ptr %l316
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t702, %"compiler/mir:Place" %t703)
  br label %bb137
bb137:
  br label %bb138
bb138:
  %t704 = load i32, ptr %l30, !tbaa !23
  %t706 = add i32 %t704, 1
  store i32 %t706, ptr %l30, !tbaa !23
  br label %bb132
bb139:
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t709 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 0
  %t710 = load { i64, [7 x i64] }, ptr %t709
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %t708, { i64, [7 x i64] } %t710)
  br label %bb140
bb140:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 1
  %t715 = load %"compiler/mir:Range", ptr %t714
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t713, %"compiler/mir:Range" %t715)
  br label %bb141
bb141:
  store i32 0, ptr %l32, !tbaa !23
  %t718 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 2
  %t719 = getelementptr %"compiler/mir:Range", ptr %t718, i32 0, i32 1
  %t720 = load i32, ptr %t719, !tbaa !23
  store i32 %t720, ptr %l33, !tbaa !23
  store i32 1, ptr %l34, !tbaa !23
  %t722 = load i32, ptr %l33, !tbaa !23
  %t723 = load i32, ptr %l32, !tbaa !23
  %t726 = icmp sgt i32 %t722, %t723
  br i1 %t726, label %bb142, label %bb143
bb142:
  %t728 = load i32, ptr %l34, !tbaa !23
  %t730 = icmp sgt i32 %t728, 0
  br i1 %t730, label %bb144, label %bb145
bb143:
  store i32 0, ptr %l327, !tbaa !23
  br label %bb147
bb144:
  %t732 = load i32, ptr %l33, !tbaa !23
  %t733 = load i32, ptr %l32, !tbaa !23
  %t736 = sub i32 %t732, %t733
  %t737 = load i32, ptr %l34, !tbaa !23
  %t740 = add i32 %t736, %t737
  %t742 = sub i32 %t740, 1
  %t743 = load i32, ptr %l34, !tbaa !23
  %t746 = sdiv i32 %t742, %t743
  store i32 %t746, ptr %l330, !tbaa !23
  br label %bb146
bb145:
  store i32 0, ptr %l330, !tbaa !23
  br label %bb146
bb146:
  %t748 = load i32, ptr %l330, !tbaa !23
  store i32 %t748, ptr %l327, !tbaa !23
  br label %bb147
bb147:
  %t749 = load i32, ptr %l327, !tbaa !23
  store i32 %t749, ptr %l35, !tbaa !23
  store i32 0, ptr %l36, !tbaa !23
  br label %bb148
bb148:
  %t750 = load i32, ptr %l36, !tbaa !23
  %t751 = load i32, ptr %l35, !tbaa !23
  %t754 = icmp slt i32 %t750, %t751
  %t756 = xor i1 %t754, true
  br i1 %t756, label %bb149, label %bb150
bb149:
  br label %bb155
bb150:
  br label %bb151
bb151:
  %t758 = load i32, ptr %l32, !tbaa !23
  %t759 = load i32, ptr %l36, !tbaa !23
  %t760 = load i32, ptr %l34, !tbaa !23
  %t763 = mul i32 %t759, %t760
  %t766 = add i32 %t758, %t763
  %t768 = load ptr, ptr %l0, !tbaa !29
  store ptr %t768, ptr %l348, !tbaa !29
  %t769 = load ptr, ptr %l2, !tbaa !29
  %t771 = getelementptr %"compiler/mir:Fn", ptr %t769, i32 0, i32 12
  %t772 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 2
  %t773 = getelementptr %"compiler/mir:Range", ptr %t772, i32 0, i32 0
  %t774 = load i32, ptr %t773, !tbaa !23
  %t776 = sext i32 %t774 to i64
  %t779 = sext i32 %t766 to i64
  %t782 = add i64 %t776, %t779
  %t785 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t771, i64 %t782)
  store { i64, [1 x i64] } %t785, ptr %l356
  br label %bb152
bb152:
  %t786 = load ptr, ptr %l348, !tbaa !29
  %t787 = load { i64, [1 x i64] }, ptr %l356
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t786, { i64, [1 x i64] } %t787)
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t788 = load i32, ptr %l36, !tbaa !23
  %t790 = add i32 %t788, 1
  store i32 %t790, ptr %l36, !tbaa !23
  br label %bb148
bb155:
  store i32 0, ptr %l38, !tbaa !23
  %t792 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 7
  %t793 = getelementptr %"compiler/mir:Range", ptr %t792, i32 0, i32 1
  %t794 = load i32, ptr %t793, !tbaa !23
  store i32 %t794, ptr %l39, !tbaa !23
  store i32 1, ptr %l40, !tbaa !23
  %t796 = load i32, ptr %l39, !tbaa !23
  %t797 = load i32, ptr %l38, !tbaa !23
  %t800 = icmp sgt i32 %t796, %t797
  br i1 %t800, label %bb156, label %bb157
bb156:
  %t802 = load i32, ptr %l40, !tbaa !23
  %t804 = icmp sgt i32 %t802, 0
  br i1 %t804, label %bb158, label %bb159
bb157:
  store i32 0, ptr %l363, !tbaa !23
  br label %bb161
bb158:
  %t806 = load i32, ptr %l39, !tbaa !23
  %t807 = load i32, ptr %l38, !tbaa !23
  %t810 = sub i32 %t806, %t807
  %t811 = load i32, ptr %l40, !tbaa !23
  %t814 = add i32 %t810, %t811
  %t816 = sub i32 %t814, 1
  %t817 = load i32, ptr %l40, !tbaa !23
  %t820 = sdiv i32 %t816, %t817
  store i32 %t820, ptr %l366, !tbaa !23
  br label %bb160
bb159:
  store i32 0, ptr %l366, !tbaa !23
  br label %bb160
bb160:
  %t822 = load i32, ptr %l366, !tbaa !23
  store i32 %t822, ptr %l363, !tbaa !23
  br label %bb161
bb161:
  %t823 = load i32, ptr %l363, !tbaa !23
  store i32 %t823, ptr %l41, !tbaa !23
  store i32 0, ptr %l42, !tbaa !23
  br label %bb162
bb162:
  %t824 = load i32, ptr %l42, !tbaa !23
  %t825 = load i32, ptr %l41, !tbaa !23
  %t828 = icmp slt i32 %t824, %t825
  %t830 = xor i1 %t828, true
  br i1 %t830, label %bb163, label %bb164
bb163:
  br label %bb172
bb164:
  br label %bb165
bb165:
  %t832 = load i32, ptr %l38, !tbaa !23
  %t833 = load i32, ptr %l42, !tbaa !23
  %t834 = load i32, ptr %l40, !tbaa !23
  %t837 = mul i32 %t833, %t834
  %t840 = add i32 %t832, %t837
  %t842 = load ptr, ptr %l2, !tbaa !29
  %t844 = getelementptr %"compiler/mir:Fn", ptr %t842, i32 0, i32 12
  %t845 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 7
  %t846 = getelementptr %"compiler/mir:Range", ptr %t845, i32 0, i32 0
  %t847 = load i32, ptr %t846, !tbaa !23
  %t849 = sext i32 %t847 to i64
  %t852 = sext i32 %t840 to i64
  %t855 = add i64 %t849, %t852
  %t858 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t844, i64 %t855)
  store { i64, [1 x i64] } %t858, ptr %l391
  br label %bb166
bb166:
  %t859 = load { i64, [1 x i64] }, ptr %l391
  store { i64, [1 x i64] } %t859, ptr %l44
  %t860 = load { i64, [1 x i64] }, ptr %l44
  %t862 = extractvalue { i64, [1 x i64] } %t860, 0
  %t863 = icmp eq i64 %t862, 3
  %t865 = xor i1 %t863, true
  br i1 %t865, label %bb167, label %bb168
bb167:
  %t867 = load ptr, ptr %l0, !tbaa !29
  %t868 = load { i64, [1 x i64] }, ptr %l44
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t867, { i64, [1 x i64] } %t868)
  br label %bb169
bb168:
  br label %bb170
bb169:
  br label %bb170
bb170:
  br label %bb171
bb171:
  %t871 = load i32, ptr %l42, !tbaa !23
  %t873 = add i32 %t871, 1
  store i32 %t873, ptr %l42, !tbaa !23
  br label %bb162
bb172:
  store i32 0, ptr %l45, !tbaa !23
  %t875 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 4
  %t876 = getelementptr %"compiler/mir:Range", ptr %t875, i32 0, i32 1
  %t877 = load i32, ptr %t876, !tbaa !23
  store i32 %t877, ptr %l46, !tbaa !23
  store i32 1, ptr %l47, !tbaa !23
  %t879 = load i32, ptr %l46, !tbaa !23
  %t880 = load i32, ptr %l45, !tbaa !23
  %t883 = icmp sgt i32 %t879, %t880
  br i1 %t883, label %bb173, label %bb174
bb173:
  %t885 = load i32, ptr %l47, !tbaa !23
  %t887 = icmp sgt i32 %t885, 0
  br i1 %t887, label %bb175, label %bb176
bb174:
  store i32 0, ptr %l403, !tbaa !23
  br label %bb178
bb175:
  %t889 = load i32, ptr %l46, !tbaa !23
  %t890 = load i32, ptr %l45, !tbaa !23
  %t893 = sub i32 %t889, %t890
  %t894 = load i32, ptr %l47, !tbaa !23
  %t897 = add i32 %t893, %t894
  %t899 = sub i32 %t897, 1
  %t900 = load i32, ptr %l47, !tbaa !23
  %t903 = sdiv i32 %t899, %t900
  store i32 %t903, ptr %l406, !tbaa !23
  br label %bb177
bb176:
  store i32 0, ptr %l406, !tbaa !23
  br label %bb177
bb177:
  %t905 = load i32, ptr %l406, !tbaa !23
  store i32 %t905, ptr %l403, !tbaa !23
  br label %bb178
bb178:
  %t906 = load i32, ptr %l403, !tbaa !23
  store i32 %t906, ptr %l48, !tbaa !23
  store i32 0, ptr %l49, !tbaa !23
  br label %bb179
bb179:
  %t907 = load i32, ptr %l49, !tbaa !23
  %t908 = load i32, ptr %l48, !tbaa !23
  %t911 = icmp slt i32 %t907, %t908
  %t913 = xor i1 %t911, true
  br i1 %t913, label %bb180, label %bb181
bb180:
  br label %bb186
bb181:
  br label %bb182
bb182:
  %t915 = load i32, ptr %l45, !tbaa !23
  %t916 = load i32, ptr %l49, !tbaa !23
  %t917 = load i32, ptr %l47, !tbaa !23
  %t920 = mul i32 %t916, %t917
  %t923 = add i32 %t915, %t920
  %t925 = load ptr, ptr %l0, !tbaa !29
  store ptr %t925, ptr %l424, !tbaa !29
  %t926 = load ptr, ptr %l2, !tbaa !29
  %t928 = getelementptr %"compiler/mir:Fn", ptr %t926, i32 0, i32 17
  %t929 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 4
  %t930 = getelementptr %"compiler/mir:Range", ptr %t929, i32 0, i32 0
  %t931 = load i32, ptr %t930, !tbaa !23
  %t933 = sext i32 %t931 to i64
  %t936 = sext i32 %t923 to i64
  %t939 = add i64 %t933, %t936
  %t942 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t928, i64 %t939)
  store %"compiler/mir:TaskClause" %t942, ptr %l432
  br label %bb183
bb183:
  %t943 = getelementptr %"compiler/mir:TaskClause", ptr %l432, i32 0, i32 2
  %t944 = load { i64, [4 x i64] }, ptr %t943
  %t945 = load ptr, ptr %l424, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t945, { i64, [4 x i64] } %t944)
  br label %bb184
bb184:
  br label %bb185
bb185:
  %t947 = load i32, ptr %l49, !tbaa !23
  %t949 = add i32 %t947, 1
  store i32 %t949, ptr %l49, !tbaa !23
  br label %bb179
bb186:
  %t951 = load ptr, ptr %l0, !tbaa !29
  %t953 = getelementptr %"compiler/mir:verifier", ptr %t951, i32 0, i32 16
  %t954 = load { i64, ptr }, ptr %t953, !tbaa !27
  store { i64, ptr } %t954, ptr %l437, !tbaa !27
  %t955 = load i32, ptr %l23, !tbaa !23
  %t957 = sext i32 %t955 to i64
  %t959 = getelementptr { i64, ptr }, ptr %l437, i32 0, i32 1
  %t960 = load ptr, ptr %t959, !tbaa !27
  %t961 = getelementptr i1, ptr %t960, i64 %t957
  store i1 true, ptr %t961, !tbaa !31
  br label %bb209
bb187:
  %t962 = load ptr, ptr %l1, !tbaa !29
  store ptr %t962, ptr %l440, !tbaa !29
  store i1 false, ptr %l441, !tbaa !21
  %t963 = load ptr, ptr %l440, !tbaa !29
  %t964 = icmp ne ptr %t963, null
  br i1 %t964, label %bb188, label %bb189
bb188:
  %t966 = load ptr, ptr %l440, !tbaa !29
  %t967 = load i64, ptr %t966
  %t969 = icmp eq i64 %t967, 12
  store i1 %t969, ptr %l441, !tbaa !21
  br label %bb189
bb189:
  %t970 = load i1, ptr %l441, !tbaa !21
  br i1 %t970, label %bb190, label %bb191
bb190:
  br label %bb192
bb191:
  br label %bb193
bb192:
  br label %bb209
bb193:
  %t971 = load ptr, ptr %l1, !tbaa !29
  store ptr %t971, ptr %l444, !tbaa !29
  store i1 false, ptr %l445, !tbaa !21
  %t972 = load ptr, ptr %l444, !tbaa !29
  %t973 = icmp ne ptr %t972, null
  br i1 %t973, label %bb194, label %bb195
bb194:
  %t975 = load ptr, ptr %l444, !tbaa !29
  %t976 = load i64, ptr %t975
  %t978 = icmp eq i64 %t976, 13
  store i1 %t978, ptr %l445, !tbaa !21
  br label %bb195
bb195:
  %t979 = load i1, ptr %l445, !tbaa !21
  br i1 %t979, label %bb196, label %bb197
bb196:
  %t980 = load ptr, ptr %l1, !tbaa !29
  %t982 = getelementptr { i64, [21 x i64] }, ptr %t980, i32 0, i32 1
  %t983 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t982, i32 0, i32 1
  %t984 = load i32, ptr %t983
  store i32 %t984, ptr %l51, !tbaa !23
  %t986 = load ptr, ptr %l1, !tbaa !29
  %t988 = getelementptr { i64, [21 x i64] }, ptr %t986, i32 0, i32 1
  %t989 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t988, i32 0, i32 2
  %t990 = load i32, ptr %t989
  store i32 %t990, ptr %l52, !tbaa !23
  br label %bb198
bb197:
  br label %bb208
bb198:
  %t992 = load ptr, ptr %l0, !tbaa !29
  %t993 = load i32, ptr %l51, !tbaa !23
  %t996 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t992, i32 %t993)
  store i1 %t996, ptr %l454
  br label %bb199
bb199:
  %t997 = load i1, ptr %l454, !tbaa !21
  %t998 = xor i1 %t997, true
  br i1 %t998, label %bb200, label %bb201
bb200:
  store %olang.scope zeroinitializer, ptr %s39
  %t1000 = load ptr, ptr %l0, !tbaa !29
  %t1001 = load i32, ptr %l51, !tbaa !23
  %t1002 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t1003 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t1005 = sext i32 %t1001 to i64
  %t1006 = call i64 @__olang_fmt_i64(ptr null, i64 %t1005)
  %t1007 = add i64 %t1003, %t1006
  %t1008 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t1009 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t1010 = add i64 %t1007, %t1009
  %t1011 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1010)
  call void @olang_textcopy(ptr %t1011, ptr %t1002, i64 %t1003)
  %t1012 = getelementptr i8, ptr %t1011, i64 %t1003
  %t1013 = call i64 @__olang_fmt_i64(ptr %t1012, i64 %t1005)
  %t1014 = getelementptr i8, ptr %t1012, i64 %t1006
  call void @olang_textcopy(ptr %t1014, ptr %t1008, i64 %t1009)
  %t1015 = insertvalue { i64, ptr } undef, i64 %t1010, 0
  %t1016 = insertvalue { i64, ptr } %t1015, ptr %t1011, 1
  %t1018 = extractvalue { i64, ptr } %t1016, 0
  %t1019 = extractvalue { i64, ptr } %t1016, 1
  %t1020 = mul i64 %t1018, 1
  %t1021 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1020)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1021, ptr %t1019, i64 %t1020, i1 false)
  %t1022 = insertvalue { i64, ptr } undef, i64 %t1018, 0
  %t1023 = insertvalue { i64, ptr } %t1022, ptr %t1021, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s39, ptr %t1000, { i64, ptr } %t1023)
  br label %bb202
bb201:
  br label %bb203
bb202:
  call void @__olang_scope_close(ptr %s39)
  br label %bb203
bb203:
  %t1026 = load i32, ptr %l52, !tbaa !23
  %t1027 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t1030 = icmp ne i32 %t1026, %t1027
  br i1 %t1030, label %bb204, label %bb205
bb204:
  %t1032 = load ptr, ptr %l0, !tbaa !29
  %t1033 = load i32, ptr %l52, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t1032, i32 %t1033)
  br label %bb206
bb205:
  br label %bb207
bb206:
  br label %bb207
bb207:
  br label %bb209
bb208:
  call void @__olang_check_failed(ptr @olang_loc_30c75e8686103aec_2a803509807dc2e8)
  unreachable
bb209:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estores(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l9 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/mir:verifier", ptr %t13, i32 0, i32 15
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = load i32, ptr %l3, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t21 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i1, ptr %t22, i64 %t19
  %t24 = load i1, ptr %t23, !tbaa !31
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t33 = sext i32 %t29 to i64
  %t34 = call i64 @__olang_fmt_i64(ptr null, i64 %t33)
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  %t41 = call i64 @__olang_fmt_i64(ptr %t40, i64 %t33)
  %t42 = getelementptr i8, ptr %t40, i64 %t34
  call void @olang_textcopy(ptr %t42, ptr %t36, i64 %t37)
  %t43 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t39, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t28, { i64, ptr } %t51)
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t54 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t55 = getelementptr %"compiler/mir:Range", ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55, !tbaa !23
  %t58 = icmp eq i32 %t56, 0
  br i1 %t58, label %bb8, label %bb9
bb8:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/mir:verifier", ptr %t60, i32 0, i32 14
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l21, !tbaa !27
  %t64 = load i32, ptr %l3, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t68 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i1, ptr %t69, i64 %t66
  store i1 true, ptr %t70, !tbaa !31
  br label %bb11
bb9:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/mir:Place", ptr %l1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t71, %"compiler/mir:Place" %t72)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb18
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load %"compiler/mir:Place", ptr %l1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t75, %"compiler/mir:Place" %t76)
  br label %bb16
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8c773ec7d9409528_6b556770aed18854)
  unreachable
bb18:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etagType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i32, i1 }
  %l3 = alloca i1
  %l6 = alloca { i32, i1 }
  %l11 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOf(ptr %v0, ptr %t1, i32 %t2)
  store { i32, i1 } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i32, i1 }, ptr %l6
  store { i32, i1 } %t6, ptr %l2
  %t7 = getelementptr { i32, i1 }, ptr %l2, i32 0, i32 1
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  %t10 = load i32, ptr %l1, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp ne i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i1, ptr %l3, !tbaa !21
  %t18 = xor i1 %t16, true
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l11, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l17
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t27 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t29 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  call void @olang_textcopy(ptr %t37, ptr %t30, i64 %t31)
  %t38 = getelementptr i8, ptr %t37, i64 %t31
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t36, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t48 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t48, { i64, ptr } %t47)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t50 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermFlow(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l16 = alloca i32
  %l17 = alloca %"compiler/mir:Call"
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i1
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca { i64, [4 x i64] }
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i1
  %l63 = alloca i32
  %l66 = alloca i32
  %l84 = alloca ptr
  %l92 = alloca %"compiler/mir:Case"
  %l105 = alloca %"compiler/mir:Call"
  %l114 = alloca i32
  %l117 = alloca i32
  %l135 = alloca ptr
  %l143 = alloca { i64, [1 x i64] }
  %l150 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l189 = alloca i64
  %l191 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l217 = alloca i1
  %l224 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [8 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [8 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t15, i32 %t16)
  br label %bb4
bb4:
  br label %bb109
bb5:
  %t19 = load { i64, [8 x i64] }, ptr %l1
  %t21 = extractvalue { i64, [8 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 2
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t25 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t24, i32 0, i32 0
  %t26 = load { i64, [4 x i64] }, ptr %t25
  store { i64, [4 x i64] } %t26, ptr %l4
  %t28 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l5, !tbaa !23
  %t32 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t33 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t32, i32 0, i32 2
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l6, !tbaa !23
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, [4 x i64] }, ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t36, { i64, [4 x i64] } %t37)
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t40, i32 %t41)
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t44, i32 %t45)
  br label %bb11
bb11:
  br label %bb109
bb12:
  %t48 = load { i64, [8 x i64] }, ptr %l1
  %t50 = extractvalue { i64, [8 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 3
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t54 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t53, i32 0, i32 0
  %t55 = load { i64, [4 x i64] }, ptr %t54
  store { i64, [4 x i64] } %t55, ptr %l7
  %t57 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t58 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t57, i32 0, i32 1
  %t59 = load %"compiler/mir:Range", ptr %t58
  store %"compiler/mir:Range" %t59, ptr %l8
  %t61 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t61, i32 0, i32 2
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l9, !tbaa !23
  br label %bb15
bb14:
  br label %bb32
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, [4 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t65, { i64, [4 x i64] } %t66)
  br label %bb16
bb16:
  store i32 0, ptr %l10, !tbaa !23
  %t69 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 1
  %t70 = load i32, ptr %t69, !tbaa !23
  store i32 %t70, ptr %l11, !tbaa !23
  store i32 1, ptr %l12, !tbaa !23
  %t72 = load i32, ptr %l11, !tbaa !23
  %t73 = load i32, ptr %l10, !tbaa !23
  %t76 = icmp sgt i32 %t72, %t73
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load i32, ptr %l12, !tbaa !23
  %t80 = icmp sgt i32 %t78, 0
  br i1 %t80, label %bb19, label %bb20
bb18:
  store i32 0, ptr %l63, !tbaa !23
  br label %bb22
bb19:
  %t82 = load i32, ptr %l11, !tbaa !23
  %t83 = load i32, ptr %l10, !tbaa !23
  %t86 = sub i32 %t82, %t83
  %t87 = load i32, ptr %l12, !tbaa !23
  %t90 = add i32 %t86, %t87
  %t92 = sub i32 %t90, 1
  %t93 = load i32, ptr %l12, !tbaa !23
  %t96 = sdiv i32 %t92, %t93
  store i32 %t96, ptr %l66, !tbaa !23
  br label %bb21
bb20:
  store i32 0, ptr %l66, !tbaa !23
  br label %bb21
bb21:
  %t98 = load i32, ptr %l66, !tbaa !23
  store i32 %t98, ptr %l63, !tbaa !23
  br label %bb22
bb22:
  %t99 = load i32, ptr %l63, !tbaa !23
  store i32 %t99, ptr %l13, !tbaa !23
  store i32 0, ptr %l14, !tbaa !23
  br label %bb23
bb23:
  %t100 = load i32, ptr %l14, !tbaa !23
  %t101 = load i32, ptr %l13, !tbaa !23
  %t104 = icmp slt i32 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t108 = load i32, ptr %l10, !tbaa !23
  %t109 = load i32, ptr %l14, !tbaa !23
  %t110 = load i32, ptr %l12, !tbaa !23
  %t113 = mul i32 %t109, %t110
  %t116 = add i32 %t108, %t113
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l84, !tbaa !29
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = getelementptr %"compiler/mir:Fn", ptr %t119, i32 0, i32 15
  %t122 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t123 = load i32, ptr %t122, !tbaa !23
  %t125 = sext i32 %t123 to i64
  %t128 = sext i32 %t116 to i64
  %t131 = add i64 %t125, %t128
  %t134 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t121, i64 %t131)
  store %"compiler/mir:Case" %t134, ptr %l92
  br label %bb27
bb27:
  %t135 = getelementptr %"compiler/mir:Case", ptr %l92, i32 0, i32 1
  %t136 = load i32, ptr %t135, !tbaa !23
  %t137 = load ptr, ptr %l84, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t137, i32 %t136)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t139 = load i32, ptr %l14, !tbaa !23
  %t141 = add i32 %t139, 1
  store i32 %t141, ptr %l14, !tbaa !23
  br label %bb23
bb30:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t143, i32 %t144)
  br label %bb31
bb31:
  br label %bb109
bb32:
  %t147 = load { i64, [8 x i64] }, ptr %l1
  %t149 = extractvalue { i64, [8 x i64] } %t147, 0
  %t150 = icmp eq i64 %t149, 4
  br i1 %t150, label %bb33, label %bb34
bb33:
  %t152 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", i32 }, ptr %t152, i32 0, i32 1
  %t154 = load i32, ptr %t153
  store i32 %t154, ptr %l16, !tbaa !23
  br label %bb35
bb34:
  br label %bb66
bb35:
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t158 = getelementptr %"compiler/mir:Fn", ptr %t156, i32 0, i32 14
  %t159 = load i32, ptr %l16, !tbaa !23
  %t161 = sext i32 %t159 to i64
  %t164 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t158, i64 %t161)
  store %"compiler/mir:Call" %t164, ptr %l105
  br label %bb36
bb36:
  %t165 = load %"compiler/mir:Call", ptr %l105
  store %"compiler/mir:Call" %t165, ptr %l17
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 0
  %t168 = load { i64, [7 x i64] }, ptr %t167
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %t166, { i64, [7 x i64] } %t168)
  br label %bb37
bb37:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 1
  %t173 = load %"compiler/mir:Range", ptr %t172
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t171, %"compiler/mir:Range" %t173)
  br label %bb38
bb38:
  store i32 0, ptr %l18, !tbaa !23
  %t176 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 2
  %t177 = getelementptr %"compiler/mir:Range", ptr %t176, i32 0, i32 1
  %t178 = load i32, ptr %t177, !tbaa !23
  store i32 %t178, ptr %l19, !tbaa !23
  store i32 1, ptr %l20, !tbaa !23
  %t180 = load i32, ptr %l19, !tbaa !23
  %t181 = load i32, ptr %l18, !tbaa !23
  %t184 = icmp sgt i32 %t180, %t181
  br i1 %t184, label %bb39, label %bb40
bb39:
  %t186 = load i32, ptr %l20, !tbaa !23
  %t188 = icmp sgt i32 %t186, 0
  br i1 %t188, label %bb41, label %bb42
bb40:
  store i32 0, ptr %l114, !tbaa !23
  br label %bb44
bb41:
  %t190 = load i32, ptr %l19, !tbaa !23
  %t191 = load i32, ptr %l18, !tbaa !23
  %t194 = sub i32 %t190, %t191
  %t195 = load i32, ptr %l20, !tbaa !23
  %t198 = add i32 %t194, %t195
  %t200 = sub i32 %t198, 1
  %t201 = load i32, ptr %l20, !tbaa !23
  %t204 = sdiv i32 %t200, %t201
  store i32 %t204, ptr %l117, !tbaa !23
  br label %bb43
bb42:
  store i32 0, ptr %l117, !tbaa !23
  br label %bb43
bb43:
  %t206 = load i32, ptr %l117, !tbaa !23
  store i32 %t206, ptr %l114, !tbaa !23
  br label %bb44
bb44:
  %t207 = load i32, ptr %l114, !tbaa !23
  store i32 %t207, ptr %l21, !tbaa !23
  store i32 0, ptr %l22, !tbaa !23
  br label %bb45
bb45:
  %t208 = load i32, ptr %l22, !tbaa !23
  %t209 = load i32, ptr %l21, !tbaa !23
  %t212 = icmp slt i32 %t208, %t209
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  br label %bb48
bb48:
  %t216 = load i32, ptr %l18, !tbaa !23
  %t217 = load i32, ptr %l22, !tbaa !23
  %t218 = load i32, ptr %l20, !tbaa !23
  %t221 = mul i32 %t217, %t218
  %t224 = add i32 %t216, %t221
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l135, !tbaa !29
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t229 = getelementptr %"compiler/mir:Fn", ptr %t227, i32 0, i32 12
  %t230 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 2
  %t231 = getelementptr %"compiler/mir:Range", ptr %t230, i32 0, i32 0
  %t232 = load i32, ptr %t231, !tbaa !23
  %t234 = sext i32 %t232 to i64
  %t237 = sext i32 %t224 to i64
  %t240 = add i64 %t234, %t237
  %t243 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t229, i64 %t240)
  store { i64, [1 x i64] } %t243, ptr %l143
  br label %bb49
bb49:
  %t244 = load ptr, ptr %l135, !tbaa !29
  %t245 = load { i64, [1 x i64] }, ptr %l143
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t244, { i64, [1 x i64] } %t245)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t246 = load i32, ptr %l22, !tbaa !23
  %t248 = add i32 %t246, 1
  store i32 %t248, ptr %l22, !tbaa !23
  br label %bb45
bb52:
  %t250 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 7
  %t251 = load i32, ptr %t250, !tbaa !23
  %t252 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t255 = icmp ne i32 %t251, %t252
  br i1 %t255, label %bb53, label %bb54
bb53:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/mir:verifier", ptr %t257, i32 0, i32 15
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  store { i64, ptr } %t260, ptr %l150, !tbaa !27
  %t261 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t262 = load i32, ptr %t261, !tbaa !23
  %t264 = sext i32 %t262 to i64
  %t266 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i1, ptr %t267, i64 %t264
  %t269 = load i1, ptr %t268, !tbaa !31
  br i1 %t269, label %bb55, label %bb56
bb54:
  br label %bb60
bb55:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/mir:verifier", ptr %t271, i32 0, i32 14
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  store { i64, ptr } %t274, ptr %l155, !tbaa !27
  %t275 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t276 = load i32, ptr %t275, !tbaa !23
  %t278 = sext i32 %t276 to i64
  %t280 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr i1, ptr %t281, i64 %t278
  %t283 = load i1, ptr %t282, !tbaa !31
  store i1 %t283, ptr %l24, !tbaa !21
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/mir:verifier", ptr %t285, i32 0, i32 14
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  store { i64, ptr } %t288, ptr %l160, !tbaa !27
  %t289 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t290 = load i32, ptr %t289, !tbaa !23
  %t292 = sext i32 %t290 to i64
  %t294 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr i1, ptr %t295, i64 %t292
  store i1 true, ptr %t296, !tbaa !31
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 7
  %t299 = load i32, ptr %t298, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t297, i32 %t299)
  br label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s13
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t304 = load i32, ptr %t303, !tbaa !23
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t308 = sext i32 %t304 to i64
  %t309 = call i64 @__olang_fmt_i64(ptr null, i64 %t308)
  %t310 = add i64 %t306, %t309
  %t311 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t312 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t313 = add i64 %t310, %t312
  %t314 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t313)
  call void @olang_textcopy(ptr %t314, ptr %t305, i64 %t306)
  %t315 = getelementptr i8, ptr %t314, i64 %t306
  %t316 = call i64 @__olang_fmt_i64(ptr %t315, i64 %t308)
  %t317 = getelementptr i8, ptr %t315, i64 %t309
  call void @olang_textcopy(ptr %t317, ptr %t311, i64 %t312)
  %t318 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t314, 1
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t322 = extractvalue { i64, ptr } %t319, 1
  %t323 = mul i64 %t321, 1
  %t324 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t323)
  call void @llvm.memcpy.p0.p0.i64(ptr %t324, ptr %t322, i64 %t323, i1 false)
  %t325 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t324, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s13, ptr %t302, { i64, ptr } %t326)
  br label %bb58
bb57:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/mir:verifier", ptr %t329, i32 0, i32 14
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  store { i64, ptr } %t332, ptr %l166, !tbaa !27
  %t333 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t334 = load i32, ptr %t333, !tbaa !23
  %t336 = sext i32 %t334 to i64
  %t337 = load i1, ptr %l24, !tbaa !21
  %t340 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr i1, ptr %t341, i64 %t336
  store i1 %t337, ptr %t342, !tbaa !31
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s13)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t343 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 4
  %t344 = load i1, ptr %t343, !tbaa !21
  br i1 %t344, label %bb61, label %bb62
bb61:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 3
  %t348 = load %"compiler/mir:Place", ptr %t347
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estores(ptr %v0, ptr %t346, %"compiler/mir:Place" %t348)
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 5
  %t353 = load i32, ptr %t352, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t351, i32 %t353)
  br label %bb65
bb65:
  br label %bb109
bb66:
  %t356 = load { i64, [8 x i64] }, ptr %l1
  %t358 = extractvalue { i64, [8 x i64] } %t356, 0
  %t359 = icmp eq i64 %t358, 5
  br i1 %t359, label %bb67, label %bb68
bb67:
  %t361 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t362 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t361, i32 0, i32 1
  %t363 = load { i64, [4 x i64] }, ptr %t362
  store { i64, [4 x i64] } %t363, ptr %l25
  br label %bb71
bb68:
  %t365 = load { i64, [8 x i64] }, ptr %l1
  %t367 = extractvalue { i64, [8 x i64] } %t365, 0
  %t368 = icmp eq i64 %t367, 6
  br i1 %t368, label %bb69, label %bb70
bb69:
  %t370 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t371 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t370, i32 0, i32 1
  %t372 = load { i64, [4 x i64] }, ptr %t371
  store { i64, [4 x i64] } %t372, ptr %l25
  br label %bb71
bb70:
  br label %bb79
bb71:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load { i64, [4 x i64] }, ptr %l25
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t374, { i64, [4 x i64] } %t375)
  br label %bb72
bb72:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/mir:verifier", ptr %t378, i32 0, i32 17
  %t382 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t380)
  store i64 %t382, ptr %l189
  br label %bb73
bb73:
  %t383 = load i64, ptr %l189, !tbaa !24
  %t384 = icmp sgt i64 %t383, 0
  br i1 %t384, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s17
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l191, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %s17, ptr %t387)
  store { i64, ptr } %t389, ptr %l193
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t390 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t391 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t392 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = add i64 %t391, %t394
  %t396 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t397 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t398 = add i64 %t395, %t397
  %t399 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t398)
  call void @olang_textcopy(ptr %t399, ptr %t390, i64 %t391)
  %t400 = getelementptr i8, ptr %t399, i64 %t391
  call void @olang_textcopy(ptr %t400, ptr %t393, i64 %t394)
  %t401 = getelementptr i8, ptr %t400, i64 %t394
  call void @olang_textcopy(ptr %t401, ptr %t396, i64 %t397)
  %t402 = insertvalue { i64, ptr } undef, i64 %t398, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t399, 1
  %t405 = extractvalue { i64, ptr } %t403, 0
  %t406 = extractvalue { i64, ptr } %t403, 1
  %t407 = mul i64 %t405, 1
  %t408 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t407)
  call void @llvm.memcpy.p0.p0.i64(ptr %t408, ptr %t406, i64 %t407, i1 false)
  %t409 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t408, 1
  %t411 = load ptr, ptr %l191, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s17, ptr %t411, { i64, ptr } %t410)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s17)
  br label %bb78
bb78:
  br label %bb109
bb79:
  %t413 = load { i64, [8 x i64] }, ptr %l1
  %t415 = extractvalue { i64, [8 x i64] } %t413, 0
  %t416 = icmp eq i64 %t415, 10
  br i1 %t416, label %bb80, label %bb81
bb80:
  %t418 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t419 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t418, i32 0, i32 1
  %t420 = load { i64, [4 x i64] }, ptr %t419
  store { i64, [4 x i64] } %t420, ptr %l26
  %t422 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t423 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t422, i32 0, i32 2
  %t424 = load i32, ptr %t423
  store i32 %t424, ptr %l27, !tbaa !23
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load { i64, [4 x i64] }, ptr %l26
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t426, { i64, [4 x i64] } %t427)
  br label %bb83
bb83:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load i32, ptr %l27, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t430, i32 %t431)
  br label %bb84
bb84:
  br label %bb109
bb85:
  %t434 = load { i64, [8 x i64] }, ptr %l1
  %t436 = extractvalue { i64, [8 x i64] } %t434, 0
  %t437 = icmp eq i64 %t436, 8
  br i1 %t437, label %bb86, label %bb87
bb86:
  %t439 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t440 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t439, i32 0, i32 2
  %t441 = load { i64, [4 x i64] }, ptr %t440
  store { i64, [4 x i64] } %t441, ptr %l28
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load { i64, [4 x i64] }, ptr %l28
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t443, { i64, [4 x i64] } %t444)
  br label %bb89
bb89:
  br label %bb109
bb90:
  %t447 = load { i64, [8 x i64] }, ptr %l1
  %t449 = extractvalue { i64, [8 x i64] } %t447, 0
  %t450 = icmp eq i64 %t449, 7
  br i1 %t450, label %bb91, label %bb92
bb91:
  %t452 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t453 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t452, i32 0, i32 1
  %t454 = load i32, ptr %t453
  store i32 %t454, ptr %l29, !tbaa !23
  %t456 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t457 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t456, i32 0, i32 2
  %t458 = load i32, ptr %t457
  store i32 %t458, ptr %l30, !tbaa !23
  %t460 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t461 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t460, i32 0, i32 3
  %t462 = load i32, ptr %t461
  store i32 %t462, ptr %l31, !tbaa !23
  %t464 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t465 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t464, i32 0, i32 4
  %t466 = load i32, ptr %t465
  store i32 %t466, ptr %l32, !tbaa !23
  br label %bb93
bb92:
  br label %bb104
bb93:
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t469 = load i32, ptr %l29, !tbaa !23
  %t472 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t468, i32 %t469)
  store i1 %t472, ptr %l217
  br label %bb94
bb94:
  %t473 = load i1, ptr %l217, !tbaa !21
  %t474 = xor i1 %t473, true
  br i1 %t474, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s22
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load i32, ptr %l29, !tbaa !23
  %t478 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t479 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t481 = sext i32 %t477 to i64
  %t482 = call i64 @__olang_fmt_i64(ptr null, i64 %t481)
  %t483 = add i64 %t479, %t482
  %t484 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t486 = add i64 %t483, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t478, i64 %t479)
  %t488 = getelementptr i8, ptr %t487, i64 %t479
  %t489 = call i64 @__olang_fmt_i64(ptr %t488, i64 %t481)
  %t490 = getelementptr i8, ptr %t488, i64 %t482
  call void @olang_textcopy(ptr %t490, ptr %t484, i64 %t485)
  %t491 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t487, 1
  %t494 = extractvalue { i64, ptr } %t492, 0
  %t495 = extractvalue { i64, ptr } %t492, 1
  %t496 = mul i64 %t494, 1
  %t497 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t496)
  call void @llvm.memcpy.p0.p0.i64(ptr %t497, ptr %t495, i64 %t496, i1 false)
  %t498 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr %t497, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s22, ptr %t476, { i64, ptr } %t499)
  br label %bb97
bb96:
  br label %bb98
bb97:
  call void @__olang_scope_close(ptr %s22)
  br label %bb98
bb98:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = getelementptr %"compiler/mir:verifier", ptr %t502, i32 0, i32 16
  %t505 = load { i64, ptr }, ptr %t504, !tbaa !27
  store { i64, ptr } %t505, ptr %l224, !tbaa !27
  %t506 = load i32, ptr %l29, !tbaa !23
  %t508 = sext i32 %t506 to i64
  %t510 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = getelementptr i1, ptr %t511, i64 %t508
  store i1 false, ptr %t512, !tbaa !31
  %t513 = load i32, ptr %l32, !tbaa !23
  %t514 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t517 = icmp ne i32 %t513, %t514
  br i1 %t517, label %bb99, label %bb100
bb99:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/mir:verifier", ptr %t519, i32 0, i32 14
  %t522 = load { i64, ptr }, ptr %t521, !tbaa !27
  store { i64, ptr } %t522, ptr %l231, !tbaa !27
  %t523 = load i32, ptr %l31, !tbaa !23
  %t525 = sext i32 %t523 to i64
  %t527 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = getelementptr i1, ptr %t528, i64 %t525
  %t530 = load i1, ptr %t529, !tbaa !31
  store i1 %t530, ptr %l33, !tbaa !21
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t534 = getelementptr %"compiler/mir:verifier", ptr %t532, i32 0, i32 14
  %t535 = load { i64, ptr }, ptr %t534, !tbaa !27
  store { i64, ptr } %t535, ptr %l236, !tbaa !27
  %t536 = load i32, ptr %l31, !tbaa !23
  %t538 = sext i32 %t536 to i64
  %t540 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr i1, ptr %t541, i64 %t538
  store i1 true, ptr %t542, !tbaa !31
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load i32, ptr %l32, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t543, i32 %t544)
  br label %bb101
bb100:
  br label %bb102
bb101:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t549 = getelementptr %"compiler/mir:verifier", ptr %t547, i32 0, i32 14
  %t550 = load { i64, ptr }, ptr %t549, !tbaa !27
  store { i64, ptr } %t550, ptr %l242, !tbaa !27
  %t551 = load i32, ptr %l31, !tbaa !23
  %t553 = sext i32 %t551 to i64
  %t554 = load i1, ptr %l33, !tbaa !21
  %t557 = getelementptr { i64, ptr }, ptr %l242, i32 0, i32 1
  %t558 = load ptr, ptr %t557, !tbaa !27
  %t559 = getelementptr i1, ptr %t558, i64 %t553
  store i1 %t554, ptr %t559, !tbaa !31
  br label %bb102
bb102:
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t561 = load i32, ptr %l30, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t560, i32 %t561)
  br label %bb103
bb103:
  br label %bb109
bb104:
  br i1 true, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb109
bb108:
  call void @__olang_check_failed(ptr @olang_loc_d66c95c574566df8_862c2f5cde7f4614)
  unreachable
bb109:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l9 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l9
  br label %bb4
bb4:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t23 = sext i32 %t19 to i64
  %t24 = call i64 @__olang_fmt_i64(ptr null, i64 %t23)
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t23)
  %t32 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t32, ptr %t26, i64 %t27)
  %t33 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t29, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t18, { i64, ptr } %t41)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  br label %bb19
bb9:
  %t44 = load { i64, [1 x i64] }, ptr %l1
  %t46 = extractvalue { i64, [1 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 4
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t50 = getelementptr { i32 }, ptr %t49, i32 0, i32 0
  %t51 = load i32, ptr %t50
  store i32 %t51, ptr %l3, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t53, i32 %t54)
  br label %bb13
bb13:
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_587900af1cc61a9a_48225b2d2b7d46c6)
  unreachable
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t1, i32 %t2, i32 %t3)
  store i1 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l9, !tbaa !29
  store { i64, ptr } %a3, ptr %l10, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t13, i32 %t14)
  store { i64, ptr } %t17, ptr %l13
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l16
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t24, i64 %t25)
  %t44 = getelementptr i8, ptr %t43, i64 %t25
  call void @olang_textcopy(ptr %t44, ptr %t26, i64 %t27)
  %t45 = getelementptr i8, ptr %t44, i64 %t27
  call void @olang_textcopy(ptr %t45, ptr %t30, i64 %t31)
  %t46 = getelementptr i8, ptr %t45, i64 %t31
  call void @olang_textcopy(ptr %t46, ptr %t33, i64 %t34)
  %t47 = getelementptr i8, ptr %t46, i64 %t34
  call void @olang_textcopy(ptr %t47, ptr %t37, i64 %t38)
  %t48 = getelementptr i8, ptr %t47, i64 %t38
  call void @olang_textcopy(ptr %t48, ptr %t40, i64 %t41)
  %t49 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t43, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t58 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t58, { i64, ptr } %t57)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eexpect(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v0, ptr %s0, ptr %a1, ptr %a0)
  store { i64, ptr } %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %v1, { i64, ptr } %t7, { i64, ptr } %t8)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l12
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15
ok.15:
  store i64 %t12, ptr %l11
  br label %bb2
bb2:
  %t16 = load i64, ptr %l11, !tbaa !24
  store i64 %t16, ptr %l8, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t20 = icmp sge i64 %t17, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t24 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t27 = extractvalue { i64, ptr } %t22, 1
  %t28 = extractvalue { i64, ptr } %t22, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t34 = extractvalue { i64, ptr } %t23, 1
  %t35 = extractvalue { i64, ptr } %t23, 0
  %t36 = add i64 %t32, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t24, i64 %t25)
  %t38 = getelementptr i8, ptr %t37, i64 %t25
  call void @olang_textcopy(ptr %t38, ptr %t27, i64 %t28)
  %t39 = getelementptr i8, ptr %t38, i64 %t28
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t40, ptr %t34, i64 %t35)
  %t41 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t37, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = extractvalue { i64, ptr } %t49, 0
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  call void @__olang_check_failed_text(ptr @olang_loc_2787a88b0b468961_ce97027662ecd8ed, { i64, ptr } %t54)
  unreachable
ret:
  ret void
}

define dso_local %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Place" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7) #0 {
entry:
  %rv = alloca %"compiler/mir:Call"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/mir:Call" undef, { i64, [7 x i64] } %a0, 0
  %t20 = insertvalue %"compiler/mir:Call" %t18, %"compiler/mir:Range" %a1, 1
  %t22 = insertvalue %"compiler/mir:Call" %t20, %"compiler/mir:Range" %a2, 2
  %t24 = insertvalue %"compiler/mir:Call" %t22, %"compiler/mir:Place" %a3, 3
  %t26 = insertvalue %"compiler/mir:Call" %t24, i1 %a4, 4
  %t28 = insertvalue %"compiler/mir:Call" %t26, i32 %a5, 5
  %t30 = insertvalue %"compiler/mir:Call" %t28, i32 %a6, 6
  %t32 = insertvalue %"compiler/mir:Call" %t30, i32 %a7, 7
  store %"compiler/mir:Call" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Call", ptr %rv
  ret %"compiler/mir:Call" %rr
}

define dso_local %"compiler/mir:Case" @compiler_2fmir_3aCase_2ector(ptr %v0, i64 %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/mir:Case"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/mir:Case" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/mir:Case" %t6, i32 %a1, 1
  store %"compiler/mir:Case" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Case", ptr %rv
  ret %"compiler/mir:Case" %rr
}

define dso_local void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"compiler/mir:Fn"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } %a0, ptr %l4
  store i32 %a1, ptr %l5, !tbaa !23
  store i64 %a2, ptr %l6, !tbaa !24
  store %"compiler/source:Span" %a3, ptr %l7
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l37
  br label %bb1
bb1:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l8
  %t11 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l38
  br label %bb2
bb2:
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l9
  %t13 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l39
  br label %bb3
bb3:
  %t14 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l10
  %t15 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l40
  br label %bb4
bb4:
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l11
  %t17 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l41
  br label %bb5
bb5:
  %t18 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l12
  %t19 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l42
  br label %bb6
bb6:
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l13
  %t21 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l43
  br label %bb7
bb7:
  %t22 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l14
  %t23 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l44
  br label %bb8
bb8:
  %t24 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l15
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l45
  br label %bb9
bb9:
  %t26 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l16
  %t27 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l46
  br label %bb10
bb10:
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l17
  %t29 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l47
  br label %bb11
bb11:
  %t30 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l18
  %t31 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l48
  br label %bb12
bb12:
  %t32 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l19
  %t33 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l49
  br label %bb13
bb13:
  %t34 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l20
  %t35 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l50
  br label %bb14
bb14:
  %t36 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l21
  %t37 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l51
  br label %bb15
bb15:
  %t38 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l22
  %t39 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l52
  br label %bb16
bb16:
  %t40 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l23
  %t41 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l53
  br label %bb17
bb17:
  %t42 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l24
  %t43 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l54
  br label %bb18
bb18:
  %t44 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l25
  %t45 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l55
  br label %bb19
bb19:
  %t46 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l26
  %t47 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l56
  br label %bb20
bb20:
  %t48 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %l27
  %t49 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l57
  br label %bb21
bb21:
  %t50 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l28
  store i1 false, ptr %l29, !tbaa !21
  store i64 0, ptr %l30, !tbaa !24
  %t51 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %l58
  br label %bb22
bb22:
  %t52 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l31
  %t53 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l59
  br label %bb23
bb23:
  %t54 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  %t55 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 0
  %t56 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t56, ptr %t55
  %t57 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 1
  %t58 = load i32, ptr %l5, !tbaa !23
  store i32 %t58, ptr %t57, !tbaa !23
  %t59 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 2
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %t59, !tbaa !24
  %t61 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 3
  %t62 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t62, ptr %t61
  %t63 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 4
  %t64 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %t63
  %t65 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 5
  %t66 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %t65
  %t67 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 6
  %t68 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %t67
  %t69 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 7
  %t70 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %t69
  %t71 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 8
  %t72 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %t71
  %t73 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 9
  %t74 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %t73
  %t75 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 10
  %t76 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %t75
  %t77 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 11
  %t78 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %t77
  %t79 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 12
  %t80 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %t79
  %t81 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 13
  %t82 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %t81
  %t83 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 14
  %t84 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %t83
  %t85 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 15
  %t86 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %t85
  %t87 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 16
  %t88 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %t87
  %t89 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 17
  %t90 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %t89
  %t91 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 18
  %t92 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t92, ptr %t91
  %t93 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 19
  %t94 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %t93
  %t95 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 20
  %t96 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %t95
  %t97 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 21
  %t98 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %t97
  %t99 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 22
  %t100 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %t99
  %t101 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 23
  %t102 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %t101
  %t103 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 24
  %t104 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %t103
  %t105 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 25
  %t106 = load i1, ptr %l29, !tbaa !21
  store i1 %t106, ptr %t105, !tbaa !21
  %t107 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 26
  %t108 = load i64, ptr %l30, !tbaa !24
  store i64 %t108, ptr %t107, !tbaa !24
  %t109 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 27
  %t110 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %t109
  %t111 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 28
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %t111
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l60, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:ScopeInfo" @compiler_2fmir_3aScopeInfo_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4) #0 {
entry:
  %rv = alloca %"compiler/mir:ScopeInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/mir:ScopeInfo" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/mir:ScopeInfo" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/mir:ScopeInfo" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/mir:ScopeInfo" %t16, %"compiler/source:Span" %a3, 3
  %t20 = insertvalue %"compiler/mir:ScopeInfo" %t18, i32 %a4, 4
  store %"compiler/mir:ScopeInfo" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:ScopeInfo", ptr %rv
  ret %"compiler/mir:ScopeInfo" %rr
}

define dso_local %"compiler/mir:TaskClause" @compiler_2fmir_3aTaskClause_2ector(ptr %v0, %"compiler/mir:Range" %a0, i1 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %rv = alloca %"compiler/mir:TaskClause"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/mir:TaskClause" undef, %"compiler/mir:Range" %a0, 0
  %t10 = insertvalue %"compiler/mir:TaskClause" %t8, i1 %a1, 1
  %t12 = insertvalue %"compiler/mir:TaskClause" %t10, { i64, [4 x i64] } %a2, 2
  store %"compiler/mir:TaskClause" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:TaskClause", ptr %rv
  ret %"compiler/mir:TaskClause" %rr
}

define dso_local void @compiler_2fmir_3averifier_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l38 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"compiler/mir:verifier"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  %t5 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t5, ptr %l23
  br label %bb1
bb1:
  %t6 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t6, ptr %l4
  store i64 -1, ptr %l5, !tbaa !24
  store i64 -1, ptr %l6, !tbaa !24
  store i1 true, ptr %l7, !tbaa !21
  %t7 = icmp sge i64 0, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = mul i64 0, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 0, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t14 = icmp sge i64 0, 0
  br i1 %t14, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_5380db3ec2a99a3_371ccfada9fdfeef)
  unreachable
bb4:
  %t16 = mul i64 0, 1
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 0, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l9, !tbaa !27
  %t21 = icmp sge i64 0, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5983d076d5883d2e_1665ff00cbce2e1a)
  unreachable
bb6:
  %t23 = mul i64 0, 1
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 0, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l10, !tbaa !27
  %t28 = icmp sge i64 0, 0
  br i1 %t28, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_910dd2c5a789172d_f03cfbb9736a8799)
  unreachable
bb8:
  %t30 = mul i64 0, 1
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 0, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l11, !tbaa !27
  %t35 = icmp sge i64 0, 0
  br i1 %t35, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2a1e3324a3ced000_b715b4216485c88c)
  unreachable
bb10:
  %t37 = icmp sle i64 0, 1152921504606846975
  br i1 %t37, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_424aba850193e62f_5d41a9f8bd7e1e63)
  unreachable
bb12:
  %t39 = mul i64 0, 8
  %t40 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 0, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l12, !tbaa !27
  %t44 = icmp sge i64 0, 0
  br i1 %t44, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_424aba850193e62f_5d41a9f8bd7e1e63)
  unreachable
bb14:
  %t46 = icmp sle i64 0, 1152921504606846975
  br i1 %t46, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_26e15834dfadce5a_40849b88d9a51eee)
  unreachable
bb16:
  %t48 = mul i64 0, 8
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 0, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l13, !tbaa !27
  %t53 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l38
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_26e15834dfadce5a_40849b88d9a51eee)
  unreachable
bb18:
  %t54 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l14
  %t55 = icmp sge i64 0, 0
  br i1 %t55, label %bb19, label %bb20
bb19:
  %t57 = mul i64 0, 1
  %t58 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 0, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l15, !tbaa !27
  %t62 = icmp sge i64 0, 0
  br i1 %t62, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_390ccbe637d1d3d9_30a6ef9f1a3ec7ed)
  unreachable
bb21:
  %t64 = mul i64 0, 1
  %t65 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 0, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l16, !tbaa !27
  %t69 = icmp sge i64 0, 0
  br i1 %t69, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_1f26baa5abf820cc_81869963bb6d62c0)
  unreachable
bb23:
  %t71 = mul i64 0, 1
  %t72 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 0, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l17, !tbaa !27
  %t76 = icmp sge i64 0, 0
  br i1 %t76, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_200617782b41aa6b_62fe98f9543f67b7)
  unreachable
bb25:
  %t78 = mul i64 0, 1
  %t79 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 0, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l18, !tbaa !27
  %t83 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %l47
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_d8b0f1b6ba5e5556_5a69466de52f9302)
  unreachable
bb27:
  %t84 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  %t85 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 0
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %t85, !tbaa !29
  %t87 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 1
  %t88 = load ptr, ptr %l3, !tbaa !29
  store ptr %t88, ptr %t87, !tbaa !29
  %t89 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 2
  %t90 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t90, ptr %t89
  %t91 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 3
  %t92 = load i64, ptr %l5, !tbaa !24
  store i64 %t92, ptr %t91, !tbaa !24
  %t93 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 4
  %t94 = load i64, ptr %l6, !tbaa !24
  store i64 %t94, ptr %t93, !tbaa !24
  %t95 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 5
  %t96 = load i1, ptr %l7, !tbaa !21
  store i1 %t96, ptr %t95, !tbaa !21
  %t97 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 6
  %t98 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t98, ptr %t97, !tbaa !27
  %t99 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 7
  %t100 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t100, ptr %t99, !tbaa !27
  %t101 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 8
  %t102 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t102, ptr %t101, !tbaa !27
  %t103 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 9
  %t104 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t104, ptr %t103, !tbaa !27
  %t105 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 10
  %t106 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t106, ptr %t105, !tbaa !27
  %t107 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 11
  %t108 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t108, ptr %t107, !tbaa !27
  %t109 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 12
  %t110 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %t109
  %t111 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 13
  %t112 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t112, ptr %t111, !tbaa !27
  %t113 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 14
  %t114 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t114, ptr %t113, !tbaa !27
  %t115 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 15
  %t116 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t116, ptr %t115, !tbaa !27
  %t117 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 16
  %t118 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t118, ptr %t117, !tbaa !27
  %t119 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 17
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %t119
  %t121 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 18
  store i1 false, ptr %t121, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l48, i64 232, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2ecompiler_2fmir() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fmir_2eNoBlock_2einit()
  br label %bb1
bb1:
  call void @compiler_2fmir_2eNoLocal_2einit()
  br label %bb2
bb2:
  call void @compiler_2fmir_2eNoScope_2einit()
  br label %bb3
bb3:
  call void @compiler_2fmir_2eEmpty_2einit()
  br label %bb4
bb4:
  call void @compiler_2fmir_2eNoPlace_2einit()
  br label %bb5
bb5:
  call void @compiler_2fmir_2eI32T_2einit()
  br label %bb6
bb6:
  call void @compiler_2fmir_2eI64T_2einit()
  br label %bb7
bb7:
  call void @compiler_2fmir_2eSp0_2einit()
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aborted" }>, align 8
@.d2 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"unreachable reached" }>, align 8
@.d3 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"null reached" }>, align 8
@.d4 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"raised a null error" }>, align 8
@.d5 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"assertion failed" }>, align 8
@.d6 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"slice bounds out of range" }>, align 8
@.d7 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"array length out of range" }>, align 8
@.d8 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"'as' named what the value is not" }>, align 8
@.d9 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"array length does not match its fixed storage" }>, align 8
@.d10 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"lane lengths differ" }>, align 8
@.d11 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c"a generator asked for its next value inside its own walk" }>, align 8
declare void @__olang_check_failed(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"b" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d16 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"assert B" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d19 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"global " }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d21 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"literal B" }>, align 8
@.d22 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d23 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"zero T" }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d25 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"V" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d30 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"vars " }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aLocalKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d37 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" in S" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" block " }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" fails " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aScopeKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
ret:
  ret void
}

@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d46 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"bb" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d48 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" bb" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"B" }>, align 8
@.d54 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"adapter B" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
ret:
  ret void
}

@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d56 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"init " }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" top" }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"any render table " }>, align 8
@.d60 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@.d61 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"copy " }>, align 8
@.d62 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"const " }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d64 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"data " }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d66 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"G" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d73 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[L" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d76 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d77 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".*" }>, align 8
@.d78 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" as " }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"V" }>, align 8
@.d81 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"program" }>, align 8
@.d82 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"frame" }>, align 8
@.d83 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"held(L" }>, align 8
@.d84 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d85 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ref " }>, align 8
@.d86 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d87 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"take " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 i64 39, label %bb41 i64 40, label %bb42 i64 41, label %bb43 i64 42, label %bb44 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
bb41:
  %t83 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t83, i64 %t84)
  br label %bb1
bb42:
  %t85 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t85, i64 %t86)
  br label %bb1
bb43:
  %t87 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t87, i64 %t88)
  br label %bb1
bb44:
  %t89 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t89, i64 %t90)
  br label %bb1
ret:
  ret void
}

@.d88 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d91 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"overflows " }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d94 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d95 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"tag " }>, align 8
@.d96 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" #" }>, align 8
@.d97 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d98 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"make " }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d101 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"new in " }>, align 8
@.d102 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d103 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d104 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"newarray in " }>, align 8
@.d105 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d106 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d107 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d109 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"slice " }>, align 8
@.d110 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d111 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" : " }>, align 8
@.d112 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"]: " }>, align 8
@.d113 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d114 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" captures " }>, align 8
@.d115 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"closure " }>, align 8
@.d116 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d119 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d120 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"recode " }>, align 8
@.d121 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" from " }>, align 8
@.d122 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d123 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"text " }>, align 8
@.d124 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d125 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d126 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"region in " }>, align 8
@.d127 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"region of " }>, align 8
@.d128 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" or " }>, align 8
@.d129 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d130 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d131 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d132 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d133 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d134 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d136 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" copies [" }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d138 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" catch" }>, align 8
@.d139 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" all" }>, align 8
@.d140 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d141 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d142 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d143 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" -> " }>, align 8
@.d144 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"param " }>, align 8
@.d145 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"capture " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aVarKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 1
  %t10 = getelementptr { i64 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  %t13 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t14 = call i64 @__olang_fmt_i64(ptr %t13, i64 %t11)
  call void @__olang_sb_add(ptr %v0, i64 %t14)
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb3:
  %t17 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb4:
  %t19 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb5:
  %t21 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb6:
  %t23 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr { i64, [1 x i64] }, ptr %t27, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  %t32 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t33 = call i64 @__olang_fmt_i64(ptr %t32, i64 %t30)
  call void @__olang_sb_add(ptr %v0, i64 %t33)
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t34, i64 %t35)
  br label %bb1
bb7:
  %t36 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t36, i64 %t37)
  br label %bb1
ret:
  ret void
}

@.d146 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"built in S" }>, align 8
@.d147 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c", which is not open" }>, align 8
@.d148 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"built in S" }>, align 8
@.d149 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", which is inert" }>, align 8
@.d150 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"a dispatch through a " }>, align 8
@.d151 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a call of a " }>, align 8
@.d152 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", not a function" }>, align 8
@.d153 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"enters bb" }>, align 8
@.d154 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" with scopes " }>, align 8
@.d155 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", where another path has " }>, align 8
@.d156 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" is a " }>, align 8
@.d157 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", not a " }>, align 8
@.d158 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"operands" }>, align 8
@.d159 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d160 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d161 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" parts made of " }>, align 8
@.d162 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"part " }>, align 8
@.d163 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" is a check: a test and a branch in MIR" }>, align 8
@.d164 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d165 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" operands" }>, align 8
@.d166 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d167 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d168 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d169 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d170 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d171 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Not of a " }>, align 8
@.d172 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d173 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" and a " }>, align 8
@.d174 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d175 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d176 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Same of a " }>, align 8
@.d177 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" and a " }>, align 8
@.d178 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Same typed " }>, align 8
@.d179 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Len of a " }>, align 8
@.d180 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Len typed " }>, align 8
@.d181 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d182 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d183 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ByteSwap of a " }>, align 8
@.d184 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d185 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d186 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d187 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"Retire of a " }>, align 8
@.d188 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"Retire typed " }>, align 8
@.d189 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"IsCase of a " }>, align 8
@.d190 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"IsCase typed " }>, align 8
@.d191 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"AnyMake of a " }>, align 8
@.d192 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"AnyMake typed " }>, align 8
@.d193 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"AnyMake's table not an I64" }>, align 8
@.d194 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"AnyInstance of a " }>, align 8
@.d195 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"AnyInstance typed " }>, align 8
@.d196 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"AnyIs of a " }>, align 8
@.d197 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"AnyIs typed " }>, align 8
@.d198 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d199 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c", not a writable reference to an integer" }>, align 8
@.d200 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"'s operand " }>, align 8
@.d201 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"AtomicStore typed " }>, align 8
@.d202 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d203 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"scopes" }>, align 8
@.d204 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"no scope S" }>, align 8
@.d205 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"a slice " }>, align 8
@.d206 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d207 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"a slice's bound that is no integer" }>, align 8
@.d208 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d209 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" opened while it is open" }>, align 8
@.d210 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d211 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" opened in " }>, align 8
@.d212 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", not in its parent " }>, align 8
@.d213 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"closed" }>, align 8
@.d214 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"join S" }>, align 8
@.d215 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" closed with tasks not waited for" }>, align 8
@.d216 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d217 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" given away, but it is no region" }>, align 8
@.d218 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"given away" }>, align 8
@.d219 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a spawn into S" }>, align 8
@.d220 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c", which is not open" }>, align 8
@.d221 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"deferred code registered at S" }>, align 8
@.d222 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c", which is not open" }>, align 8
@.d223 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d224 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c" stored into with no storage: its Live not reached" }>, align 8
@.d225 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"the case of a " }>, align 8
@.d226 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", not an enum" }>, align 8
@.d227 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d228 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c" given an error code with no storage" }>, align 8
@.d229 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"leaves the function with " }>, align 8
@.d230 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" open" }>, align 8
@.d231 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a wait for S" }>, align 8
@.d232 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c", which is not open" }>, align 8
@.d233 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d234 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" used where it is not open" }>, align 8
@.d235 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" is a " }>, align 8
@.d236 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", where a " }>, align 8
@.d237 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" is wanted" }>, align 8
declare void @__olang_ert_req_clear()
@.d238 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"wanted '" }>, align 8
@.d239 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"' among:\0A" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr })
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d240 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"LocalKind.Param" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d241 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"LocalKind.Capture" }>, align 8
@.d242 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"LocalKind.Var" }>, align 8
@.d243 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"LocalKind.Temp" }>, align 8
@.d244 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"ScopeKind.Frame" }>, align 8
@.d245 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"ScopeKind.Block" }>, align 8
@.d246 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ScopeKind.Loop" }>, align 8
@.d247 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ScopeKind.Join" }>, align 8
@.d248 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"ScopeKind.Region" }>, align 8
@.d249 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"ScopeKind.Inert" }>, align 8
@.d250 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"ScopeKind.Builder" }>, align 8
@.d251 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"HelperKind.Render" }>, align 8
@.d252 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"HelperKind.Equal" }>, align 8
@.d253 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"HelperKind.Hash" }>, align 8
@.d254 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"HelperKind.Zero" }>, align 8
@.d255 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Neg" }>, align 8
@.d256 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitNot" }>, align 8
@.d257 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Not" }>, align 8
@.d258 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Add" }>, align 8
@.d259 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Sub" }>, align 8
@.d260 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Mul" }>, align 8
@.d261 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Div" }>, align 8
@.d262 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Rem" }>, align 8
@.d263 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Shl" }>, align 8
@.d264 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Shr" }>, align 8
@.d265 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitAnd" }>, align 8
@.d266 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.BitOr" }>, align 8
@.d267 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitXor" }>, align 8
@.d268 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Eq" }>, align 8
@.d269 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Ne" }>, align 8
@.d270 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Lt" }>, align 8
@.d271 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Le" }>, align 8
@.d272 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Gt" }>, align 8
@.d273 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Ge" }>, align 8
@.d274 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"PrimOp.Same" }>, align 8
@.d275 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Convert" }>, align 8
@.d276 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Bitcast" }>, align 8
@.d277 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Len" }>, align 8
@.d278 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.IsCase" }>, align 8
@.d279 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.AtomicLoad" }>, align 8
@.d280 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.AtomicStore" }>, align 8
@.d281 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"PrimOp.AtomicAdd" }>, align 8
@.d282 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.AtomicSwap" }>, align 8
@.d283 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"PrimOp.AtomicCompareSwap" }>, align 8
@.d284 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.Retire" }>, align 8
@.d285 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Destroy" }>, align 8
@.d286 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"PrimOp.LeadingZeros" }>, align 8
@.d287 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"PrimOp.TrailingZeros" }>, align 8
@.d288 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.PopCount" }>, align 8
@.d289 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.RotateLeft" }>, align 8
@.d290 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.RotateRight" }>, align 8
@.d291 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.ByteSwap" }>, align 8
@.d292 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.Holds" }>, align 8
@.d293 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.LaneLen" }>, align 8
@.d294 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.NonEmpty" }>, align 8
@.d295 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.AnyMake" }>, align 8
@.d296 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.AnyInstance" }>, align 8
@.d297 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.AnyIs" }>, align 8
@.d298 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"VarKind.Param" }>, align 8
@.d299 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d300 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d301 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"VarKind.Result" }>, align 8
@.d302 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"VarKind.Instance" }>, align 8
@.d303 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"VarKind.Closing" }>, align 8
@.d304 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"VarKind.Capture" }>, align 8
@.d305 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"VarKind.Builder" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@olang_loc_84efd3c782aef4d6_8c92393edf5749f2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_419ac27aa82c7b2c_45256e944a6f3408 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare void @compiler_2fmir_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eSetAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Local" %a2)
declare %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %a0)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2ePush_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, %"compiler/mir:Case" %a1)
@olang_loc_f17cf97eff0353b6_fea489b4a6f80ab2 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2ePush_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2ePush_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2eLen_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2ePush_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eLen_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2ePush_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, %"compiler/mir:TaskClause" %a1)
declare %"compiler/mir:Task" @compiler_2fmir_3aTask_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4, %"compiler/mir:Range" %a5, %"compiler/source:Span" %a6, %"compiler/mir:Range" %a7)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2ePush_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, %"compiler/mir:Task" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:dumper" @compiler_2fmir_3adumper_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ePush_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_5b04576c3a0c01b1_2f8c01babecc81b5 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_14ebfa33b1d03356_270fe526a4636ad2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmir_2eshort(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eterm(ptr %v0, ptr %v1, ptr %a0, { i64, [8 x i64] } %a1)
declare %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_792180efaebdc40a_e488d776d0fba16e = external constant [0 x i8]
@olang_loc_4b3ff56260a2bca0_3dcb0434d488ed4c = external constant [0 x i8]
@olang_loc_2f605f8b851f9dfa_b0e742a1ba211956 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ddfec86899b5c27b_91be796056af7d77 = external constant [0 x i8]
@olang_loc_3c759898227385e0_43502750c3b6307c = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
@olang_loc_55b2be13c853614c_e5b496909f3a0f10 = external constant [0 x i8]
declare %"compiler/mir:Place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %v1, ptr %a0, { i64, [7 x i64] } %a1)
declare %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6326b544498e75fa_e53a2c99f88826ee = external constant [0 x i8]
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a15aa4830130cc38_9fcdb454ad4b970c = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
@olang_loc_43daeee16a7347fc_3936ff71893c42a0 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
@olang_loc_690174ade0b6e824_1aa5c898f3f73ab8 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b20acbf668615715_202a9ab5dba06089 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3fc64ab4d22c7cd1_9c9bbb4060ef765d = external constant [0 x i8]
@olang_loc_82a5970c46c34ec4_64144421b638a2b0 = external constant [0 x i8]
@olang_loc_2ac31f2db6082ba7_5ac69b59325af853 = external constant [0 x i8]
@olang_loc_397ae699ba890fb2_f6680c8259f4281e = external constant [0 x i8]
@olang_loc_2836fb8ea59de3a5_79eeb5d0a68fc1c9 = external constant [0 x i8]
@olang_loc_13b0920ad4a1e938_72d556b41507b57c = external constant [0 x i8]
@olang_loc_f0f79482ff998b1b_575016ccefde52df = external constant [0 x i8]
@olang_loc_a4c79ab2e91ac186_f4797f1baf8f450a = external constant [0 x i8]
@olang_loc_2c486f9205676389_1881cd4b4e7e41e5 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_d0c28dbd82f4c36a_9dd446291f7ee706 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %a0, i32 %a1, %"compiler/mir:Range" %a2, i32 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_7968c2a45e42402b_522993cc8bbef1e7 = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_d06e38c3720099d6_401a7f863dec038a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueFlow(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
declare %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_30c75e8686103aec_2a803509807dc2e8 = external constant [0 x i8]
@olang_loc_8c773ec7d9409528_6b556770aed18854 = external constant [0 x i8]
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d66c95c574566df8_862c2f5cde7f4614 = external constant [0 x i8]
@olang_loc_587900af1cc61a9a_48225b2d2b7d46c6 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2787a88b0b468961_ce97027662ecd8ed = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_5380db3ec2a99a3_371ccfada9fdfeef = external constant [0 x i8]
@olang_loc_5983d076d5883d2e_1665ff00cbce2e1a = external constant [0 x i8]
@olang_loc_910dd2c5a789172d_f03cfbb9736a8799 = external constant [0 x i8]
@olang_loc_2a1e3324a3ced000_b715b4216485c88c = external constant [0 x i8]
@olang_loc_424aba850193e62f_5d41a9f8bd7e1e63 = external constant [0 x i8]
@olang_loc_26e15834dfadce5a_40849b88d9a51eee = external constant [0 x i8]
@olang_loc_390ccbe637d1d3d9_30a6ef9f1a3ec7ed = external constant [0 x i8]
@olang_loc_1f26baa5abf820cc_81869963bb6d62c0 = external constant [0 x i8]
@olang_loc_200617782b41aa6b_62fe98f9543f67b7 = external constant [0 x i8]
@olang_loc_d8b0f1b6ba5e5556_5a69466de52f9302 = external constant [0 x i8]
declare void @compiler_2fmir_2eNoBlock_2einit()
declare void @compiler_2fmir_2eNoLocal_2einit()
declare void @compiler_2fmir_2eNoPlace_2einit()
declare void @compiler_2fmir_2eI32T_2einit()

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
