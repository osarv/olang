; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/mir:dumper" = type { ptr, ptr, %"std/prelude/text:StringBuilder" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [8 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/mir:verifier" = type { ptr, ptr, %"std/prelude/text:StringBuilder", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
@G_2ecompiler_2fmir_2eEmpty = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eI32T = constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eI64T = constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoLocal = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoPlace = constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2fmir_2eNoScope = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eSp0 = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
define dso_local i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l51 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i1
  %l68 = alloca i64
  %l71 = alloca i64
  %l89 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l28, !tbaa !24
  store i64 %t37, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l25, !tbaa !24
  store i64 %t38, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l10, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l46, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t59, ptr %l48, !tbaa !27
  %t60 = load i64, ptr %l10, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i32, ptr %t63, i64 %t60
  %t65 = load i32, ptr %t64, !tbaa !33
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t58, i32 %t65)
  store i32 %t68, ptr %l51
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t69, i32 %a2)
  store i32 %t73, ptr %l54
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l46, !tbaa !29
  %t75 = load i32, ptr %l51, !tbaa !23
  %t76 = load i32, ptr %l54, !tbaa !23
  %t77 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t74, i32 %t75, i32 %t76)
  store i1 %t77, ptr %l55
  br label %bb14
bb14:
  %t78 = load i1, ptr %l55, !tbaa !21
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t81 = add i64 %t79, 1
  %t83 = shl i64 %t81, 16
  %t87 = or i64 %t83, %a3
  store i64 %t87, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb8
bb19:
  store i64 0, ptr %l11, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t97 = load i64, ptr %l12, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb20, label %bb21
bb20:
  %t103 = load i64, ptr %l13, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb25
bb22:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l13, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l71, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb24
bb24:
  %t123 = load i64, ptr %l71, !tbaa !24
  store i64 %t123, ptr %l68, !tbaa !24
  br label %bb25
bb25:
  %t124 = load i64, ptr %l68, !tbaa !24
  store i64 %t124, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb26
bb26:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb27, label %bb28
bb27:
  br label %bb34
bb28:
  br label %bb29
bb29:
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l16, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t143, ptr %l89, !tbaa !27
  %t144 = load i64, ptr %l16, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 %t144
  %t149 = load i32, ptr %t148, !tbaa !33
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb30, label %bb31
bb30:
  %t155 = load i64, ptr %l16, !tbaa !24
  %t157 = add i64 %t155, 1
  %t159 = shl i64 %t157, 16
  store i64 %t159, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t161 = load i64, ptr %l15, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l15, !tbaa !24
  br label %bb26
bb34:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2eExitText(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb11
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t8 = trunc i64 1 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t13 = trunc i64 14 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t18 = trunc i64 15 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t23 = trunc i64 6 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb12:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t28 = trunc i64 2 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb16:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t33 = trunc i64 3 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb20:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb24:
  %t41 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t43 = trunc i64 5 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb28:
  %t46 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t48 = trunc i64 7 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb32:
  %t51 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t53 = trunc i64 8 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb36:
  %t56 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t58 = trunc i64 9 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb40:
  %t61 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t63 = trunc i64 10 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb44:
  %t66 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t68 = trunc i64 11 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb48:
  %t71 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t73 = trunc i64 12 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb52:
  %t76 = load i32, ptr %l0, !range !{i32 0, i32 16}
  %t78 = trunc i64 13 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_84efd3c782aef4d6_8c92393edf5749f2)
  unreachable
bb57:
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t81, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2eFn_2eadd(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l15 = alloca i32
  %l16 = alloca %"compiler/mir:Fn"
  %l17 = alloca ptr
  %l20 = alloca i32
  %l25 = alloca %"compiler/mir:Local"
  %l26 = alloca ptr
  %l29 = alloca i32
  %l34 = alloca %"compiler/mir:Local"
  %l35 = alloca ptr
  %l38 = alloca i32
  %l43 = alloca %"compiler/mir:Local"
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca %"compiler/source:Span"
  %l49 = alloca %"compiler/mir:Lvalue"
  %l50 = alloca i32
  %l51 = alloca i32
  %l52 = alloca ptr
  %l53 = alloca %"compiler/mir:Lvalue"
  %l54 = alloca { i64, [4 x i64] }
  %l55 = alloca %"compiler/mir:Lvalue"
  %l57 = alloca { i64, ptr }
  %l58 = alloca %"compiler/mir:Range"
  %l60 = alloca { i64, [21 x i64] }
  %l65 = alloca { i64, [21 x i64] }
  %l67 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca %"compiler/source:Span"
  %l71 = alloca %"compiler/mir:Lvalue"
  %l74 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t30 = alloca %"compiler/mir:Fn", align 8
  %t46 = alloca { i64, [1 x i64] }, align 8
  %t68 = alloca { i64, [1 x i64] }, align 8
  %t89 = alloca { i64, [1 x i64] }, align 8
  %t111 = alloca { i64, [4 x i64] }, align 8
  %t118 = alloca { i64, [4 x i64] }, align 8
  %t139 = alloca { i64, [15 x i64] }, align 8
  %t149 = alloca { i64, [21 x i64] }, align 8
  %t165 = alloca { i64, [21 x i64] }, align 8
  %t181 = alloca { i64, [4 x i64] }, align 8
  %t187 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i32 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i32, ptr %l6, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t9 = load i32, ptr %l1, !tbaa !23
  %t10 = mul i64 2, 4
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 2, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l12, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i32, ptr %t16, i64 0
  store i32 %t8, ptr %t17, !tbaa !33
  %t19 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 1
  store i32 %t9, ptr %t21, !tbaa !33
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t7, { i64, ptr } %t23)
  store i32 %t24, ptr %l13
  br label %bb2
bb2:
  %t25 = load i32, ptr %l1, !tbaa !23
  %t26 = load ptr, ptr %l8, !tbaa !29
  %t27 = load i32, ptr %l13, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t26, i32 %t27, i32 %t25, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t29, ptr %l15
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l7, !tbaa !29
  %t32 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fmir_2eFn_2etfn(ptr %t30, ptr %v0, ptr %v1, ptr %t31, i32 %t32)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t30, i64 800, i1 false)
  br label %bb4
bb4:
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 800, i64 8)
  store ptr %t33, ptr %lp2
  %t34 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t34, ptr %l16, i64 800, i1 false)
  %t35 = load ptr, ptr %lp2
  %t36 = getelementptr %"compiler/mir:Fn", ptr %t35, i32 0, i32 7
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/types:Table", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load ptr, ptr @__olang_prog_scope
  %t43 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t41, ptr %s0, ptr %t40, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i32 %t43, ptr %l20
  br label %bb5
bb5:
  %t44 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t45 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [1 x i64] }, ptr %t46, i32 0, i32 0
  store i64 3, ptr %t47
  %t48 = load { i64, [1 x i64] }, ptr %t46
  %t49 = load i32, ptr %l20, !tbaa !23
  %t54 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t49, %"compiler/source:Span" %t44, i32 %t45, i32 0, { i64, [1 x i64] } %t48)
  store %"compiler/mir:Local" %t54, ptr %l25
  br label %bb6
bb6:
  %t55 = load ptr, ptr %l17, !tbaa !29
  %t56 = load %"compiler/mir:Local", ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eSetAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t55, i64 0, %"compiler/mir:Local" %t56)
  br label %bb7
bb7:
  %t57 = load ptr, ptr %lp2
  %t58 = getelementptr %"compiler/mir:Fn", ptr %t57, i32 0, i32 7
  store ptr %t58, ptr %l26, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/types:Table", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load ptr, ptr @__olang_prog_scope
  %t65 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t63, ptr %s0, ptr %t62, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i32 %t65, ptr %l29
  br label %bb8
bb8:
  %t66 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t67 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [1 x i64] }, ptr %t68, i32 0, i32 0
  store i64 3, ptr %t69
  %t70 = load { i64, [1 x i64] }, ptr %t68
  %t71 = load i32, ptr %l29, !tbaa !23
  %t76 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t71, %"compiler/source:Span" %t66, i32 %t67, i32 0, { i64, [1 x i64] } %t70)
  store %"compiler/mir:Local" %t76, ptr %l34
  br label %bb9
bb9:
  %t77 = load ptr, ptr %l26, !tbaa !29
  %t78 = load %"compiler/mir:Local", ptr %l34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eSetAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t77, i64 1, %"compiler/mir:Local" %t78)
  br label %bb10
bb10:
  %t79 = load ptr, ptr %lp2
  store ptr %t79, ptr %l35, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/types:Table", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load ptr, ptr @__olang_prog_scope
  %t86 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t84, ptr %s0, ptr %t83, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i32 %t86, ptr %l38
  br label %bb11
bb11:
  %t87 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t88 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [1 x i64] }, ptr %t89, i32 0, i32 0
  store i64 3, ptr %t90
  %t91 = load { i64, [1 x i64] }, ptr %t89
  %t92 = load i32, ptr %l38, !tbaa !23
  %t97 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t92, %"compiler/source:Span" %t87, i32 %t88, i32 2, { i64, [1 x i64] } %t91)
  store %"compiler/mir:Local" %t97, ptr %l43
  br label %bb12
bb12:
  %t98 = load ptr, ptr %l35, !tbaa !29
  %t99 = load %"compiler/mir:Local", ptr %l43
  %t100 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v1, ptr %t98, %"compiler/mir:Local" %t99)
  store i32 %t100, ptr %l44
  br label %bb13
bb13:
  %t101 = load i32, ptr %l44, !tbaa !23
  store i32 %t101, ptr %l3, !tbaa !23
  store i32 0, ptr %l4, !tbaa !23
  %t102 = load ptr, ptr %lp2
  store ptr %t102, ptr %l45, !tbaa !29
  %t103 = load i32, ptr %l4, !tbaa !23
  store i32 %t103, ptr %l46, !tbaa !23
  %t104 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t104, ptr %l47
  %t105 = load i32, ptr %l3, !tbaa !23
  %t107 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t105)
  store %"compiler/mir:Lvalue" %t107, ptr %l49
  br label %bb14
bb14:
  store i32 3, ptr %l50
  %t108 = load i32, ptr %l1, !tbaa !23
  store i32 %t108, ptr %l51, !tbaa !23
  %t109 = load ptr, ptr %lp2
  store ptr %t109, ptr %l52, !tbaa !29
  %t110 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 0)
  store %"compiler/mir:Lvalue" %t110, ptr %l53
  br label %bb15
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 0
  store i64 1, ptr %t112
  %t113 = load %"compiler/mir:Lvalue", ptr %l53
  %t114 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t113, 0
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t114, ptr %t115
  %t116 = load { i64, [4 x i64] }, ptr %t111
  store { i64, [4 x i64] } %t116, ptr %l54
  %t117 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 1)
  store %"compiler/mir:Lvalue" %t117, ptr %l55
  br label %bb16
bb16:
  store { i64, [4 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 0
  store i64 1, ptr %t119
  %t120 = load %"compiler/mir:Lvalue", ptr %l55
  %t121 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t120, 0
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t121, ptr %t122
  %t123 = load { i64, [4 x i64] }, ptr %t118
  %t124 = mul i64 2, 40
  %t125 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 2, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l57, !tbaa !27
  %t128 = load { i64, [4 x i64] }, ptr %l54
  %t129 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t130, i64 0
  store { i64, [4 x i64] } %t128, ptr %t131
  %t133 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t134, i64 1
  store { i64, [4 x i64] } %t123, ptr %t135
  %t136 = load ptr, ptr %l52, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t138 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t136, { i64, ptr } %t137)
  store %"compiler/mir:Range" %t138, ptr %l58
  br label %bb17
bb17:
  store { i64, [15 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [15 x i64] }, ptr %t139, i32 0, i32 0
  store i64 3, ptr %t140
  %t141 = load i32, ptr %l50, !range !{i32 0, i32 49}
  %t142 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t141, 0
  %t143 = load i32, ptr %l51, !tbaa !23
  %t144 = insertvalue { i32, i32, %"compiler/mir:Range" } %t142, i32 %t143, 1
  %t145 = load %"compiler/mir:Range", ptr %l58
  %t146 = insertvalue { i32, i32, %"compiler/mir:Range" } %t144, %"compiler/mir:Range" %t145, 2
  %t147 = getelementptr { i64, [15 x i64] }, ptr %t139, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t146, ptr %t147
  %t148 = load { i64, [15 x i64] }, ptr %t139
  store { i64, [21 x i64] } zeroinitializer, ptr %t149
  %t150 = getelementptr { i64, [21 x i64] }, ptr %t149, i32 0, i32 0
  store i64 0, ptr %t150
  %t151 = load %"compiler/source:Span", ptr %l47
  %t152 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t151, 0
  %t153 = load %"compiler/mir:Lvalue", ptr %l49
  %t154 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t152, %"compiler/mir:Lvalue" %t153, 1
  %t156 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t154, { i64, [15 x i64] } %t148, 2
  %t157 = getelementptr { i64, [21 x i64] }, ptr %t149, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t156, ptr %t157
  %t158 = load { i64, [21 x i64] }, ptr %t149
  store { i64, [21 x i64] } %t158, ptr %l60
  %t159 = load ptr, ptr %l45, !tbaa !29
  %t160 = load i32, ptr %l46, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t159, i32 %t160, ptr %l60)
  br label %bb18
bb18:
  %t162 = load ptr, ptr %lp2
  %t163 = load i32, ptr %l4, !tbaa !23
  %t164 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [21 x i64] }, ptr %t165, i32 0, i32 0
  store i64 4, ptr %t166
  %t168 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t164, 0
  %t169 = insertvalue { %"compiler/source:Span", i32 } %t168, i32 0, 1
  %t170 = getelementptr { i64, [21 x i64] }, ptr %t165, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t169, ptr %t170
  %t171 = load { i64, [21 x i64] }, ptr %t165
  store { i64, [21 x i64] } %t171, ptr %l65
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t162, i32 %t163, ptr %l65)
  br label %bb19
bb19:
  %t175 = load ptr, ptr %lp2
  store ptr %t175, ptr %l67, !tbaa !29
  %t176 = load i32, ptr %l4, !tbaa !23
  store i32 %t176, ptr %l68, !tbaa !23
  %t177 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t177, ptr %l69
  %t178 = load i32, ptr %l3, !tbaa !23
  %t180 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t178)
  store %"compiler/mir:Lvalue" %t180, ptr %l71
  br label %bb20
bb20:
  store { i64, [4 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 0
  store i64 1, ptr %t182
  %t183 = load %"compiler/mir:Lvalue", ptr %l71
  %t184 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t183, 0
  %t185 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t184, ptr %t185
  %t186 = load { i64, [4 x i64] }, ptr %t181
  store { i64, [8 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [8 x i64] }, ptr %t187, i32 0, i32 0
  store i64 5, ptr %t188
  %t189 = load %"compiler/source:Span", ptr %l69
  %t190 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t189, 0
  %t192 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t190, { i64, [4 x i64] } %t186, 1
  %t193 = getelementptr { i64, [8 x i64] }, ptr %t187, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t192, ptr %t193
  %t194 = load { i64, [8 x i64] }, ptr %t187
  %t195 = load ptr, ptr %l67, !tbaa !29
  %t196 = load i32, ptr %l68, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t195, i32 %t196, { i64, [8 x i64] } %t194)
  br label %bb21
bb21:
  %t198 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %t198, i64 800, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l74, i64 800, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2eGuardType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l14 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l3, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t5 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t3, i32 %t4, i64 %t5)
  store i32 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t10, i32 %a1, i64 %t12)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = mul i64 2, 4
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 2, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l12, !tbaa !27
  %t21 = load i32, ptr %l7, !tbaa !23
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 0
  store i32 %t21, ptr %t24, !tbaa !33
  %t25 = load i32, ptr %l11, !tbaa !23
  %t26 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 1
  store i32 %t25, ptr %t28, !tbaa !33
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t30 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t29, { i64, ptr } %t30)
  store i32 %t31, ptr %l13
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t33 = load i32, ptr %l13, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t34, ptr %l14
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load i32, ptr %l14, !tbaa !23
  store i32 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l14 = alloca i32
  %l17 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t14 = trunc i64 24 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb15
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb5
bb5:
  %t22 = load i32, ptr %l14, !range !{i32 0, i32 33}
  %t24 = trunc i64 18 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb10
bb8:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i32, ptr %l21, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t35, ptr %l22
  br label %bb9
bb9:
  %t36 = load i32, ptr %l22, !range !{i32 0, i32 6}
  %t38 = trunc i64 1 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t41 = load i1, ptr %l17, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l28
  br label %bb13
bb12:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb14
bb13:
  %t47 = load i1, ptr %l28, !tbaa !21
  store i1 %t47, ptr %l25, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l25, !tbaa !21
  store i1 %t48, ptr %l11, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l11, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l29 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i32, ptr %l9, !range !{i32 0, i32 33}
  store i32 %t12, ptr %l3
  %t13 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t15 = trunc i64 22 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t20 = trunc i64 23 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb17
bb7:
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t26 = trunc i64 18 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l2, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l22
  br label %bb10
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb12
bb10:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i32, ptr %l22, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t37, ptr %l23
  br label %bb11
bb11:
  %t38 = load i32, ptr %l23, !range !{i32 0, i32 6}
  %t40 = trunc i64 0 to i32
  %t41 = icmp eq i32 %t38, %t40
  store i1 %t41, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l18, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l29
  br label %bb15
bb14:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb16
bb15:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l26, !tbaa !21
  store i1 %t50, ptr %l15, !tbaa !21
  br label %bb17
bb17:
  %t51 = load i1, ptr %l15, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0) #0 {
entry:
  %l4 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Lvalue"
  %t2 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [2 x i64] }, ptr %t2, i32 0, i32 0
  store i64 1, ptr %t3
  %t5 = insertvalue { i32 } undef, i32 %a0, 0
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t2, i32 0, i32 1
  store { i32 } %t5, ptr %t6
  %t7 = load { i64, [2 x i64] }, ptr %t2
  %t8 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  %t11 = call %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %s0, { i64, [2 x i64] } %t7, %"compiler/mir:Range" %t8)
  store %"compiler/mir:Lvalue" %t11, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"compiler/mir:Lvalue", ptr %l4
  store %"compiler/mir:Lvalue" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2) #0 {
entry:
  %l1 = alloca { i64, [7 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l52 = alloca i1
  %l55 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l75 = alloca { i64, ptr }
  %s7 = alloca %olang.scope
  %rv = alloca i64
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [2 x i64] }, ptr %t7
  %t10 = extractvalue { i64, [2 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 3
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb3:
  %t13 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t13, i32 0, i32 0
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32, i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16, !range !{i32 0, i32 8}
  %t19 = trunc i64 0 to i32
  %t20 = icmp eq i32 %t17, %t19
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l10, !tbaa !21
  store i1 %t22, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l7, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb14
bb8:
  %t24 = load { i64, [7 x i64] }, ptr %l1
  %t26 = extractvalue { i64, [7 x i64] } %t24, 0
  %t27 = icmp eq i64 %t26, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t30 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t29, i32 0, i32 0
  %t31 = load { i64, [2 x i64] }, ptr %t30
  %t33 = extractvalue { i64, [2 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 5
  store i1 %t34, ptr %l15, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l15, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 1, ptr %l4, !tbaa !24
  br label %bb85
bb15:
  %t37 = load { i64, [7 x i64] }, ptr %l1
  %t39 = extractvalue { i64, [7 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 0
  br i1 %t40, label %bb16, label %bb17
bb16:
  %t42 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t42, i32 0, i32 0
  %t44 = load { i64, [2 x i64] }, ptr %t43
  %t46 = extractvalue { i64, [2 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 3
  br i1 %t47, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb21
bb18:
  %t49 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t50 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t49, i32 0, i32 0
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52, !range !{i32 0, i32 8}
  %t55 = trunc i64 4 to i32
  %t56 = icmp eq i32 %t53, %t55
  store i1 %t56, ptr %l23, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l23, !tbaa !21
  store i1 %t58, ptr %l20, !tbaa !21
  br label %bb21
bb21:
  %t59 = load i1, ptr %l20, !tbaa !21
  br i1 %t59, label %bb22, label %bb23
bb22:
  br label %bb32
bb23:
  %t60 = load { i64, [7 x i64] }, ptr %l1
  %t62 = extractvalue { i64, [7 x i64] } %t60, 0
  %t63 = icmp eq i64 %t62, 0
  br i1 %t63, label %bb24, label %bb25
bb24:
  %t65 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t66 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t65, i32 0, i32 0
  %t67 = load { i64, [2 x i64] }, ptr %t66
  %t69 = extractvalue { i64, [2 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 3
  br i1 %t70, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb29
bb26:
  %t72 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t73 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t72, i32 0, i32 0
  %t74 = getelementptr { i64, [2 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { i32, i32 }, ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !range !{i32 0, i32 8}
  %t78 = trunc i64 5 to i32
  %t79 = icmp eq i32 %t76, %t78
  store i1 %t79, ptr %l31, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb28
bb28:
  %t81 = load i1, ptr %l31, !tbaa !21
  store i1 %t81, ptr %l28, !tbaa !21
  br label %bb29
bb29:
  %t82 = load i1, ptr %l28, !tbaa !21
  br i1 %t82, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i64 1, ptr %l4, !tbaa !24
  br label %bb85
bb33:
  %t83 = load { i64, [7 x i64] }, ptr %l1
  %t85 = extractvalue { i64, [7 x i64] } %t83, 0
  %t86 = icmp eq i64 %t85, 0
  br i1 %t86, label %bb34, label %bb35
bb34:
  %t88 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t89 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t88, i32 0, i32 0
  %t90 = load { i64, [2 x i64] }, ptr %t89
  %t92 = extractvalue { i64, [2 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 3
  br i1 %t93, label %bb36, label %bb37
bb35:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb39
bb36:
  %t95 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t96 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t95, i32 0, i32 0
  %t97 = getelementptr { i64, [2 x i64] }, ptr %t96, i32 0, i32 1
  %t98 = getelementptr { i32, i32 }, ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 8}
  %t101 = trunc i64 6 to i32
  %t102 = icmp eq i32 %t99, %t101
  store i1 %t102, ptr %l39, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb38
bb38:
  %t104 = load i1, ptr %l39, !tbaa !21
  store i1 %t104, ptr %l36, !tbaa !21
  br label %bb39
bb39:
  %t105 = load i1, ptr %l36, !tbaa !21
  br i1 %t105, label %bb40, label %bb41
bb40:
  br label %bb50
bb41:
  %t106 = load { i64, [7 x i64] }, ptr %l1
  %t108 = extractvalue { i64, [7 x i64] } %t106, 0
  %t109 = icmp eq i64 %t108, 0
  br i1 %t109, label %bb42, label %bb43
bb42:
  %t111 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t112 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t111, i32 0, i32 0
  %t113 = load { i64, [2 x i64] }, ptr %t112
  %t115 = extractvalue { i64, [2 x i64] } %t113, 0
  %t116 = icmp eq i64 %t115, 3
  br i1 %t116, label %bb44, label %bb45
bb43:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb47
bb44:
  %t118 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t119 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t118, i32 0, i32 0
  %t120 = getelementptr { i64, [2 x i64] }, ptr %t119, i32 0, i32 1
  %t121 = getelementptr { i32, i32 }, ptr %t120, i32 0, i32 0
  %t122 = load i32, ptr %t121, !range !{i32 0, i32 8}
  %t124 = trunc i64 7 to i32
  %t125 = icmp eq i32 %t122, %t124
  store i1 %t125, ptr %l47, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb46
bb46:
  %t127 = load i1, ptr %l47, !tbaa !21
  store i1 %t127, ptr %l44, !tbaa !21
  br label %bb47
bb47:
  %t128 = load i1, ptr %l44, !tbaa !21
  br i1 %t128, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  store i64 1, ptr %l4, !tbaa !24
  br label %bb85
bb51:
  %t129 = load { i64, [7 x i64] }, ptr %l1
  %t131 = extractvalue { i64, [7 x i64] } %t129, 0
  %t132 = icmp eq i64 %t131, 0
  br i1 %t132, label %bb52, label %bb53
bb52:
  %t134 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t135 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t134, i32 0, i32 0
  %t136 = load { i64, [2 x i64] }, ptr %t135
  %t138 = extractvalue { i64, [2 x i64] } %t136, 0
  %t139 = icmp eq i64 %t138, 3
  br i1 %t139, label %bb54, label %bb55
bb53:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb57
bb54:
  %t141 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t142 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t141, i32 0, i32 0
  %t143 = getelementptr { i64, [2 x i64] }, ptr %t142, i32 0, i32 1
  %t144 = getelementptr { i32, i32 }, ptr %t143, i32 0, i32 0
  %t145 = load i32, ptr %t144, !range !{i32 0, i32 8}
  %t147 = trunc i64 1 to i32
  %t148 = icmp eq i32 %t145, %t147
  store i1 %t148, ptr %l55, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb56
bb56:
  %t150 = load i1, ptr %l55, !tbaa !21
  store i1 %t150, ptr %l52, !tbaa !21
  br label %bb57
bb57:
  %t151 = load i1, ptr %l52, !tbaa !21
  br i1 %t151, label %bb58, label %bb59
bb58:
  br label %bb68
bb59:
  %t152 = load { i64, [7 x i64] }, ptr %l1
  %t154 = extractvalue { i64, [7 x i64] } %t152, 0
  %t155 = icmp eq i64 %t154, 0
  br i1 %t155, label %bb60, label %bb61
bb60:
  %t157 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t158 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t157, i32 0, i32 0
  %t159 = load { i64, [2 x i64] }, ptr %t158
  %t161 = extractvalue { i64, [2 x i64] } %t159, 0
  %t162 = icmp eq i64 %t161, 3
  br i1 %t162, label %bb62, label %bb63
bb61:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb65
bb62:
  %t164 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t165 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t164, i32 0, i32 0
  %t166 = getelementptr { i64, [2 x i64] }, ptr %t165, i32 0, i32 1
  %t167 = getelementptr { i32, i32 }, ptr %t166, i32 0, i32 0
  %t168 = load i32, ptr %t167, !range !{i32 0, i32 8}
  %t170 = trunc i64 2 to i32
  %t171 = icmp eq i32 %t168, %t170
  store i1 %t171, ptr %l63, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb64
bb64:
  %t173 = load i1, ptr %l63, !tbaa !21
  store i1 %t173, ptr %l60, !tbaa !21
  br label %bb65
bb65:
  %t174 = load i1, ptr %l60, !tbaa !21
  br i1 %t174, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb85
bb69:
  %t175 = load { i64, [7 x i64] }, ptr %l1
  %t177 = extractvalue { i64, [7 x i64] } %t175, 0
  %t178 = icmp eq i64 %t177, 1
  br i1 %t178, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb85
bb73:
  %t180 = load { i64, [7 x i64] }, ptr %l1
  %t182 = extractvalue { i64, [7 x i64] } %t180, 0
  %t183 = icmp eq i64 %t182, 3
  br i1 %t183, label %bb74, label %bb75
bb74:
  %t185 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t186 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t185, i32 0, i32 1
  %t187 = load i64, ptr %t186
  store i64 %t187, ptr %l3, !tbaa !24
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t191 = icmp slt i64 %t189, 0
  br i1 %t191, label %bb77, label %bb78
bb77:
  store i64 1, ptr %l4, !tbaa !24
  br label %bb85
bb78:
  br label %bb79
bb79:
  br i1 true, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb84
bb82:
  store %olang.scope zeroinitializer, ptr %s7
  %t197 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s7, ptr %a0, i32 %a2)
  store { i64, ptr } %t197, ptr %l75
  br label %bb83
bb83:
  %t198 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  store i64 %t199, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_419ac27aa82c7b2c_45256e944a6f3408)
  unreachable
bb85:
  %t201 = load i64, ptr %l4, !tbaa !24
  store i64 %t201, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCases(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 15
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/mir:Case", ptr %t25, i64 %t22
  %t27 = load %"compiler/mir:Case", ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2ePush_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t31, %"compiler/mir:Case" %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca %"compiler/mir:Range"
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca %"compiler/mir:Range"
  %l40 = alloca i64
  %rv = alloca i32
  %t17 = alloca { i64, [1 x i64] }, align 8
  %t44 = alloca { i64, [1 x i64] }, align 8
  %t71 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l2, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i64, ptr %l2, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [1 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t20 = insertvalue { i64 } undef, i64 %t16, 0
  %t21 = getelementptr { i64, [1 x i64] }, ptr %t17, i32 0, i32 1
  store { i64 } %t20, ptr %t21
  %t22 = load { i64, [1 x i64] }, ptr %t17
  store { i64, [1 x i64] } %t22, ptr %l6
  br label %bb21
bb6:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 3}
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l16, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr } }, ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l3, !tbaa !27
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddBytes(ptr %v0, ptr %v1, ptr %t39, { i64, ptr } %t40)
  store %"compiler/mir:Range" %t43, ptr %l23
  br label %bb12
bb12:
  store { i64, [1 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [1 x i64] }, ptr %t44, i32 0, i32 0
  store i64 1, ptr %t45
  %t46 = load %"compiler/mir:Range", ptr %l23
  %t47 = insertvalue { %"compiler/mir:Range" } undef, %"compiler/mir:Range" %t46, 0
  %t48 = getelementptr { i64, [1 x i64] }, ptr %t44, i32 0, i32 1
  store { %"compiler/mir:Range" } %t47, ptr %t48
  %t49 = load { i64, [1 x i64] }, ptr %t44
  store { i64, [1 x i64] } %t49, ptr %l6
  br label %bb21
bb13:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l25, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 3}
  %t58 = icmp eq i64 %t56, 2
  store i1 %t58, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l26, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [2 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { { i64, ptr } }, ptr %t62, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  store { i64, ptr } %t64, ptr %l4, !tbaa !27
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddConstItems(ptr %v0, ptr %v1, ptr %t66, { i64, ptr } %t67)
  store %"compiler/mir:Range" %t70, ptr %l33
  br label %bb19
bb19:
  store { i64, [1 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [1 x i64] }, ptr %t71, i32 0, i32 0
  store i64 2, ptr %t72
  %t73 = load %"compiler/mir:Range", ptr %l33
  %t74 = insertvalue { %"compiler/mir:Range" } undef, %"compiler/mir:Range" %t73, 0
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t71, i32 0, i32 1
  store { %"compiler/mir:Range" } %t74, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t71
  store { i64, [1 x i64] } %t76, ptr %l6
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f17cf97eff0353b6_fea489b4a6f80ab2)
  unreachable
bb21:
  %t78 = load { i64, [1 x i64] }, ptr %l6
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/mir:Fn", ptr %t79, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2ePush_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t81, { i64, [1 x i64] } %t78)
  br label %bb22
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/mir:Fn", ptr %t85, i32 0, i32 19
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t87)
  store i64 %t89, ptr %l40
  br label %bb23
bb23:
  %t90 = load i64, ptr %l40, !tbaa !24
  %t91 = sub i64 %t90, 1
  %t93 = trunc i64 %t91 to i32
  store i32 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2ePush_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t3, %"compiler/mir:Local" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 7
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l11 = alloca %"compiler/mir:Local"
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t5 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 0
  store i64 3, ptr %t6
  %t7 = load { i64, [1 x i64] }, ptr %t5
  %t13 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 0, { i64, [1 x i64] } %t7)
  store %"compiler/mir:Local" %t13, ptr %l11
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = load %"compiler/mir:Local", ptr %l11
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %t14, %"compiler/mir:Local" %t15)
  store i32 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i32, ptr %l12, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/mir:Fn", ptr %t18, i32 0, i32 4
  %t21 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t20, i32 %t21)
  br label %bb3
bb3:
  %t24 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTask(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [7 x i64] } %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Range" %a3, { i64, ptr } %a4, { i64, ptr } %a5, %"compiler/mir:Range" %a6, %"compiler/source:Span" %a7, %"compiler/mir:Range" %a8) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l21 = alloca i64
  %l29 = alloca { i64, ptr }
  %l39 = alloca i64
  %l47 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca { i64, [7 x i64] }
  %l58 = alloca %"compiler/mir:Range"
  %l59 = alloca %"compiler/mir:Range"
  %l65 = alloca %"compiler/mir:Range"
  %l71 = alloca %"compiler/mir:Range"
  %l75 = alloca %"compiler/mir:Task"
  %l78 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eLen_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load i64, ptr %l21, !tbaa !24
  store i64 %t6, ptr %l9, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t7, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l12, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l12, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t21, ptr %l29, !tbaa !27
  %t22 = load i64, ptr %l11, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/mir:Lvalue", ptr %t25, i64 %t22
  %t27 = load %"compiler/mir:Lvalue", ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2ePush_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t31, %"compiler/mir:Lvalue" %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l11, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l11, !tbaa !24
  br label %bb2
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/mir:Fn", ptr %t39, i32 0, i32 17
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eLen_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l39
  br label %bb9
bb9:
  %t44 = load i64, ptr %l39, !tbaa !24
  store i64 %t44, ptr %l14, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t45, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l17, !tbaa !24
  br label %bb10
bb10:
  %t51 = load i64, ptr %l16, !tbaa !24
  %t52 = load i64, ptr %l17, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t59 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t59, ptr %l47, !tbaa !27
  %t60 = load i64, ptr %l16, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr %"compiler/mir:TaskClause", ptr %t63, i64 %t60
  %t65 = load %"compiler/mir:TaskClause", ptr %t64
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/mir:Fn", ptr %t67, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2ePush_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t69, %"compiler/mir:TaskClause" %t65)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t73 = load i64, ptr %l16, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l16, !tbaa !24
  br label %bb10
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/mir:Fn", ptr %t77, i32 0, i32 16
  store ptr %t79, ptr %l56, !tbaa !29
  store { i64, [7 x i64] } %a1, ptr %l57
  store %"compiler/mir:Range" %a2, ptr %l58
  store %"compiler/mir:Range" %a3, ptr %l59
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = trunc i64 %t83 to i32
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t90 = trunc i64 %t88 to i32
  %t93 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t85, i32 %t90)
  store %"compiler/mir:Range" %t93, ptr %l65
  br label %bb17
bb17:
  %t94 = load i64, ptr %l14, !tbaa !24
  %t96 = trunc i64 %t94 to i32
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t101 = trunc i64 %t99 to i32
  %t104 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t96, i32 %t101)
  store %"compiler/mir:Range" %t104, ptr %l71
  br label %bb18
bb18:
  %t108 = load { i64, [7 x i64] }, ptr %l57
  %t109 = load %"compiler/mir:Range", ptr %l58
  %t110 = load %"compiler/mir:Range", ptr %l59
  %t111 = load %"compiler/mir:Range", ptr %l65
  %t112 = load %"compiler/mir:Range", ptr %l71
  %t116 = call %"compiler/mir:Task" @compiler_2fmir_3aTask_2ector(ptr %s0, { i64, [7 x i64] } %t108, %"compiler/mir:Range" %t109, %"compiler/mir:Range" %t110, %"compiler/mir:Range" %t111, %"compiler/mir:Range" %t112, %"compiler/mir:Range" %a6, %"compiler/source:Span" %a7, %"compiler/mir:Range" %a8)
  store %"compiler/mir:Task" %t116, ptr %l75
  br label %bb19
bb19:
  %t117 = load ptr, ptr %l56, !tbaa !29
  %t118 = load %"compiler/mir:Task", ptr %l75
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2ePush_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t117, %"compiler/mir:Task" %t118)
  br label %bb20
bb20:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/mir:Fn", ptr %t119, i32 0, i32 16
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t121)
  store i64 %t123, ptr %l78
  br label %bb21
bb21:
  %t124 = load i64, ptr %l78, !tbaa !24
  %t125 = sub i64 %t124, 1
  %t127 = trunc i64 %t125 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t127, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca %"compiler/mir:dumper"
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call %"compiler/mir:dumper" @compiler_2fmir_3adumper_2ector(ptr %v0, ptr %v1, ptr %s0, ptr %a0, ptr %a1)
  store %"compiler/mir:dumper" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"compiler/mir:dumper", ptr %l5
  %t7 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 48, i64 8)
  store %"compiler/mir:dumper" %t6, ptr %t7
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eall(ptr %s0, ptr %t9)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/mir:dumper", ptr %t11, i32 0, i32 2
  %t15 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %t13)
  store { i64, ptr } %t15, ptr %l10
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t16, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 12
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [1 x i64] }, ptr %t25, i64 %t22
  %t27 = load { i64, [1 x i64] }, ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ePush_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t31, { i64, [1 x i64] } %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eWritesInto(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, [21 x i64] }
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca i64
  %l48 = alloca i64
  %l53 = alloca { i64, [21 x i64] }
  %l55 = alloca { i64, [21 x i64] }
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load i64, ptr %l15, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l22, !tbaa !24
  store i64 %t33, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb26
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/mir:Fn", ptr %t53, i32 0, i32 9
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t55, i64 %t51)
  store ptr %t59, ptr %l43
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l43, !tbaa !29
  %t63 = getelementptr %"compiler/mir:BasicBlock", ptr %t60, i32 0, i32 0
  store ptr %t63, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l11, !tbaa !24
  store i64 %t65, ptr %l46, !tbaa !24
  %t66 = load ptr, ptr %l10, !tbaa !29
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l48
  br label %bb14
bb14:
  %t69 = load i64, ptr %l46, !tbaa !24
  %t70 = load i64, ptr %l48, !tbaa !24
  %t71 = icmp slt i64 %t69, %t70
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb15, label %bb16
bb15:
  br label %bb24
bb16:
  br label %bb17
bb17:
  %t75 = load ptr, ptr %l10, !tbaa !29
  %t76 = load i64, ptr %l11, !tbaa !24
  %t79 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t75, i64 %t76)
  store { i64, [21 x i64] } %t79, ptr %l53
  br label %bb18
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l53, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %l12, i64 176, i1 false)
  %t83 = load { i64, [21 x i64] }, ptr %l55
  %t85 = call i1 @compiler_2fmir_2ewritesInto(ptr %v1, ptr %a1, { i64, [21 x i64] } %t83, i32 %a2)
  store i1 %t85, ptr %l57
  br label %bb19
bb19:
  %t86 = load i1, ptr %l57, !tbaa !21
  br i1 %t86, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t88 = load i64, ptr %l11, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l11, !tbaa !24
  br label %bb13
bb24:
  br label %bb25
bb25:
  %t92 = load i64, ptr %l7, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l7, !tbaa !24
  br label %bb8
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddBytes(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 21
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i8, ptr %t25, i64 %t22
  %t27 = load i8, ptr %t26, !tbaa !32
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t31, i8 %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eaddConstItems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca i32
  %l55 = alloca i64
  %l63 = alloca { i64, ptr }
  %l76 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l15, !tbaa !24
  %t4 = load i64, ptr %l15, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l15, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_5b04576c3a0c01b1_2f8c01babecc81b5)
  unreachable
bb3:
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5b04576c3a0c01b1_2f8c01babecc81b5)
  unreachable
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb10
bb7:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l27, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l27, !tbaa !24
  store i64 %t46, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l24, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  store i64 %t66, ptr %l45, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l47, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t77 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %t67, ptr %t74)
  store i32 %t77, ptr %l50
  br label %bb15
bb15:
  %t78 = load i32, ptr %l50, !tbaa !23
  %t79 = load i64, ptr %l45, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i32, ptr %t81, i64 %t79
  store i32 %t78, ptr %t82, !tbaa !33
  br label %bb16
bb16:
  %t83 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/mir:Fn", ptr %t87, i32 0, i32 20
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t89)
  store i64 %t91, ptr %l55
  br label %bb18
bb18:
  %t92 = load i64, ptr %l55, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l12, !tbaa !24
  br label %bb19
bb19:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t107, ptr %l63, !tbaa !27
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 %t108
  %t113 = load i32, ptr %t112, !tbaa !33
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/mir:Fn", ptr %t115, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t117, i32 %t113)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l11, !tbaa !24
  br label %bb19
bb25:
  %t125 = load i64, ptr %l9, !tbaa !24
  %t127 = trunc i64 %t125 to i32
  %t128 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t132 = trunc i64 %t130 to i32
  %t135 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t127, i32 %t132)
  store %"compiler/mir:Range" %t135, ptr %l76
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load %"compiler/mir:Range", ptr %l76
  store %"compiler/mir:Range" %t136, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aKey_2eText(ptr %v0, { i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t7 = getelementptr { i32, %"compiler/source:Span" }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l1, !tbaa !23
  %t10 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t11 = getelementptr { i32, %"compiler/source:Span" }, ptr %t10, i32 0, i32 1
  %t12 = load %"compiler/source:Span", ptr %t11
  store %"compiler/source:Span" %t12, ptr %l2
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t19 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t22 = sext i32 %t14 to i64
  %t23 = call i64 @__olang_fmt_i64(ptr null, i64 %t22)
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = sext i32 %t16 to i64
  %t30 = call i64 @__olang_fmt_i64(ptr null, i64 %t29)
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t36 = sext i32 %t18 to i64
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t36)
  %t38 = add i64 %t34, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t19, i64 %t20)
  %t40 = getelementptr i8, ptr %t39, i64 %t20
  %t41 = call i64 @__olang_fmt_i64(ptr %t40, i64 %t22)
  %t42 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t42, ptr %t25, i64 %t26)
  %t43 = getelementptr i8, ptr %t42, i64 %t26
  %t44 = call i64 @__olang_fmt_i64(ptr %t43, i64 %t29)
  %t45 = getelementptr i8, ptr %t43, i64 %t30
  call void @olang_textcopy(ptr %t45, ptr %t32, i64 %t33)
  %t46 = getelementptr i8, ptr %t45, i64 %t33
  %t47 = call i64 @__olang_fmt_i64(ptr %t46, i64 %t36)
  %t48 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t39, 1
  store { i64, ptr } %t49, ptr %l8, !tbaa !27
  br label %bb17
bb4:
  %t51 = load { i64, [2 x i64] }, ptr %l0
  %t53 = extractvalue { i64, [2 x i64] } %t51, 0
  %t54 = icmp eq i64 %t53, 1
  br i1 %t54, label %bb5, label %bb6
bb5:
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t57 = getelementptr { i64, i32 }, ptr %t56, i32 0, i32 0
  %t58 = load i64, ptr %t57
  store i64 %t58, ptr %l3, !tbaa !24
  %t60 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t61 = getelementptr { i64, i32 }, ptr %t60, i32 0, i32 1
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l4, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t65 = load i32, ptr %l4, !tbaa !23
  %t66 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t69 = call i64 @__olang_fmt_i64(ptr null, i64 %t64)
  %t70 = add i64 %t67, %t69
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t75 = sext i32 %t65 to i64
  %t76 = call i64 @__olang_fmt_i64(ptr null, i64 %t75)
  %t77 = add i64 %t73, %t76
  %t78 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t66, i64 %t67)
  %t79 = getelementptr i8, ptr %t78, i64 %t67
  %t80 = call i64 @__olang_fmt_i64(ptr %t79, i64 %t64)
  %t81 = getelementptr i8, ptr %t79, i64 %t69
  call void @olang_textcopy(ptr %t81, ptr %t71, i64 %t72)
  %t82 = getelementptr i8, ptr %t81, i64 %t72
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t75)
  %t84 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t78, 1
  store { i64, ptr } %t85, ptr %l8, !tbaa !27
  br label %bb17
bb8:
  %t87 = load { i64, [2 x i64] }, ptr %l0
  %t89 = extractvalue { i64, [2 x i64] } %t87, 0
  %t90 = icmp eq i64 %t89, 2
  br i1 %t90, label %bb9, label %bb10
bb9:
  %t92 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t93 = getelementptr { i32, i32 }, ptr %t92, i32 0, i32 0
  %t94 = load i32, ptr %t93
  store i32 %t94, ptr %l5, !tbaa !23
  %t96 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t97 = getelementptr { i32, i32 }, ptr %t96, i32 0, i32 1
  %t98 = load i32, ptr %t97
  store i32 %t98, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t100 = load i32, ptr %l5, !tbaa !23
  %t101 = load i32, ptr %l6, !tbaa !23
  %t102 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t105 = sext i32 %t100 to i64
  %t106 = call i64 @__olang_fmt_i64(ptr null, i64 %t105)
  %t107 = add i64 %t103, %t106
  %t108 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t110 = add i64 %t107, %t109
  %t112 = sext i32 %t101 to i64
  %t113 = call i64 @__olang_fmt_i64(ptr null, i64 %t112)
  %t114 = add i64 %t110, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t102, i64 %t103)
  %t116 = getelementptr i8, ptr %t115, i64 %t103
  %t117 = call i64 @__olang_fmt_i64(ptr %t116, i64 %t105)
  %t118 = getelementptr i8, ptr %t116, i64 %t106
  call void @olang_textcopy(ptr %t118, ptr %t108, i64 %t109)
  %t119 = getelementptr i8, ptr %t118, i64 %t109
  %t120 = call i64 @__olang_fmt_i64(ptr %t119, i64 %t112)
  %t121 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t115, 1
  store { i64, ptr } %t122, ptr %l8, !tbaa !27
  br label %bb17
bb12:
  %t124 = load { i64, [2 x i64] }, ptr %l0
  %t126 = extractvalue { i64, [2 x i64] } %t124, 0
  %t127 = icmp eq i64 %t126, 3
  br i1 %t127, label %bb13, label %bb14
bb13:
  %t129 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t130 = getelementptr { i32 }, ptr %t129, i32 0, i32 0
  %t131 = load i32, ptr %t130
  store i32 %t131, ptr %l7, !tbaa !23
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t133 = load i32, ptr %l7, !tbaa !23
  %t134 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t137 = sext i32 %t133 to i64
  %t138 = call i64 @__olang_fmt_i64(ptr null, i64 %t137)
  %t139 = add i64 %t135, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t134, i64 %t135)
  %t141 = getelementptr i8, ptr %t140, i64 %t135
  %t142 = call i64 @__olang_fmt_i64(ptr %t141, i64 %t137)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t140, 1
  store { i64, ptr } %t144, ptr %l8, !tbaa !27
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_14ebfa33b1d03356_270fe526a4636ad2)
  unreachable
bb17:
  %t146 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t146, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3aLvalue_2eBaseIs(%"compiler/mir:Lvalue" %a0, i32 %a1) #0 {
entry:
  %l0 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca i1
  %rv = alloca i1
  store %"compiler/mir:Lvalue" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l0, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  %t4 = extractvalue { i64, [2 x i64] } %t2, 0
  %t5 = icmp eq i64 %t4, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = getelementptr %"compiler/mir:Lvalue", ptr %l0, i32 0, i32 0
  %t8 = getelementptr { i64, [2 x i64] }, ptr %t7, i32 0, i32 1
  %t9 = getelementptr { i32 }, ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9
  %t14 = icmp eq i32 %t10, %a1
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l4, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/mir:Local"
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/mir:ScopeInfo"
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca { i64, [21 x i64] }
  %l40 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l54 = alloca i64
  %l56 = alloca %"std/prelude/text:StringBuilder"
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l84 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca ptr
  %l93 = alloca { i64, [1 x i64] }
  %l94 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l106 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i64
  %l134 = alloca %"compiler/mir:Local"
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca i64
  %l150 = alloca i32
  %l152 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l173 = alloca i64
  %l177 = alloca i64
  %l180 = alloca i64
  %l201 = alloca %"compiler/mir:ScopeInfo"
  %l205 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l223 = alloca ptr
  %l224 = alloca i64
  %l225 = alloca i32
  %l227 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l239 = alloca i64
  %l243 = alloca i64
  %l246 = alloca i64
  %l271 = alloca ptr
  %l274 = alloca i64
  %l276 = alloca i64
  %l281 = alloca { i64, [21 x i64] }
  %l282 = alloca ptr
  %l285 = alloca { i64, ptr }
  %l289 = alloca ptr
  %l293 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %s16 = alloca %olang.scope
  %s20 = alloca %olang.builder
  %s20room = alloca [64 x i8], align 8
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l40, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/mir:Fn", ptr %t8, i32 0, i32 0
  %t11 = load { i64, [2 x i64] }, ptr %t10
  %t14 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %s0, ptr %t7, { i64, [2 x i64] } %t11)
  store { i64, ptr } %t14, ptr %l44
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/mir:dumper", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/mir:Fn", ptr %t19, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  %t23 = load ptr, ptr @__olang_prog_scope
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t23, ptr %s0, ptr %t18, i32 %t22)
  store { i64, ptr } %t26, ptr %l49
  br label %bb2
bb2:
  %t27 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t29 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = add i64 %t35, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t27, i64 %t28)
  %t41 = getelementptr i8, ptr %t40, i64 %t28
  call void @olang_textcopy(ptr %t41, ptr %t30, i64 %t31)
  %t42 = getelementptr i8, ptr %t41, i64 %t31
  call void @olang_textcopy(ptr %t42, ptr %t33, i64 %t34)
  %t43 = getelementptr i8, ptr %t42, i64 %t34
  call void @olang_textcopy(ptr %t43, ptr %t37, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t40, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t53 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s0, ptr %t53, i64 0, { i64, ptr } %t52)
  br label %bb3
bb3:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/mir:Fn", ptr %t55, i32 0, i32 6
  %t58 = load ptr, ptr @__olang_prog_scope
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %t58, ptr %t57)
  store i64 %t60, ptr %l54
  br label %bb4
bb4:
  %t61 = load i64, ptr %l54, !tbaa !24
  %t62 = icmp sgt i64 %t61, 0
  br i1 %t62, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t64 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t64, ptr %l56
  br label %bb7
bb6:
  br label %bb29
bb7:
  %t65 = load %"std/prelude/text:StringBuilder", ptr %l56
  store %"std/prelude/text:StringBuilder" %t65, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/mir:Fn", ptr %t66, i32 0, i32 6
  %t69 = load ptr, ptr @__olang_prog_scope
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %t69, ptr %t68)
  store i64 %t71, ptr %l59
  br label %bb8
bb8:
  %t72 = load i64, ptr %l59, !tbaa !24
  store i64 %t72, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l4, !tbaa !24
  %t74 = load i64, ptr %l3, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb9, label %bb10
bb9:
  %t79 = load i64, ptr %l5, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb14
bb11:
  %t83 = load i64, ptr %l4, !tbaa !24
  %t84 = load i64, ptr %l3, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l5, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l66, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb13
bb13:
  %t99 = load i64, ptr %l66, !tbaa !24
  store i64 %t99, ptr %l63, !tbaa !24
  br label %bb14
bb14:
  %t100 = load i64, ptr %l63, !tbaa !24
  store i64 %t100, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t109 = load i64, ptr %l3, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t111 = load i64, ptr %l5, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l8, !tbaa !24
  store ptr %l2, ptr %l84, !tbaa !29
  %t119 = load i64, ptr %l8, !tbaa !24
  %t121 = icmp sgt i64 %t119, 0
  br i1 %t121, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb21
bb21:
  %t123 = load i64, ptr %l8, !tbaa !24
  store i64 %t123, ptr %l88, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l89, !tbaa !29
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr %"compiler/mir:Fn", ptr %t125, i32 0, i32 6
  %t128 = load i64, ptr %l8, !tbaa !24
  %t129 = load ptr, ptr @__olang_prog_scope
  %t132 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %t129, ptr %t127, i64 %t128)
  store { i64, [1 x i64] } %t132, ptr %l93
  br label %bb22
bb22:
  %t133 = load ptr, ptr %l89, !tbaa !29
  %t134 = load { i64, [1 x i64] }, ptr %l93
  %t135 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2evarKind(ptr %v0, ptr %s4, ptr %t133, { i64, [1 x i64] } %t134)
  store { i64, ptr } %t135, ptr %l94
  br label %bb23
bb23:
  %t136 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t142 = load i64, ptr %l88, !tbaa !24
  %t143 = call i64 @__olang_fmt_i64(ptr null, i64 %t142)
  %t144 = add i64 %t141, %t143
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = add i64 %t147, %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t137, i64 %t138)
  %t153 = getelementptr i8, ptr %t152, i64 %t138
  call void @olang_textcopy(ptr %t153, ptr %t139, i64 %t140)
  %t154 = getelementptr i8, ptr %t153, i64 %t140
  %t155 = call i64 @__olang_fmt_i64(ptr %t154, i64 %t142)
  %t156 = getelementptr i8, ptr %t154, i64 %t143
  call void @olang_textcopy(ptr %t156, ptr %t145, i64 %t146)
  %t157 = getelementptr i8, ptr %t156, i64 %t146
  call void @olang_textcopy(ptr %t157, ptr %t149, i64 %t150)
  %t158 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t152, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t167 = load ptr, ptr %l84, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s4, ptr %t167, { i64, ptr } %t166)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t169 = load i64, ptr %l7, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l7, !tbaa !24
  br label %bb15
bb26:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l99, !tbaa !29
  %t175 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l2)
  store { i64, ptr } %t175, ptr %l101
  br label %bb27
bb27:
  %t176 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t178 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = add i64 %t177, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t176, i64 %t177)
  %t183 = getelementptr i8, ptr %t182, i64 %t177
  call void @olang_textcopy(ptr %t183, ptr %t179, i64 %t180)
  %t184 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t182, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = extractvalue { i64, ptr } %t185, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  %t193 = load ptr, ptr %l99, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s2, ptr %t193, i64 1, { i64, ptr } %t192)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  store i64 0, ptr %l9, !tbaa !24
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/mir:Fn", ptr %t195, i32 0, i32 7
  %t198 = load ptr, ptr @__olang_prog_scope
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %t198, ptr %t197)
  store i64 %t200, ptr %l106
  br label %bb30
bb30:
  %t201 = load i64, ptr %l106, !tbaa !24
  store i64 %t201, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t202 = load i64, ptr %l10, !tbaa !24
  %t203 = load i64, ptr %l9, !tbaa !24
  %t206 = icmp sgt i64 %t202, %t203
  br i1 %t206, label %bb31, label %bb32
bb31:
  %t208 = load i64, ptr %l11, !tbaa !24
  %t210 = icmp sgt i64 %t208, 0
  br i1 %t210, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb36
bb33:
  %t212 = load i64, ptr %l10, !tbaa !24
  %t213 = load i64, ptr %l9, !tbaa !24
  %t216 = sub i64 %t212, %t213
  %t217 = load i64, ptr %l11, !tbaa !24
  %t220 = add i64 %t216, %t217
  %t222 = sub i64 %t220, 1
  %t223 = load i64, ptr %l11, !tbaa !24
  %t226 = sdiv i64 %t222, %t223
  store i64 %t226, ptr %l113, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb35
bb35:
  %t228 = load i64, ptr %l113, !tbaa !24
  store i64 %t228, ptr %l110, !tbaa !24
  br label %bb36
bb36:
  %t229 = load i64, ptr %l110, !tbaa !24
  store i64 %t229, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t230 = load i64, ptr %l13, !tbaa !24
  %t231 = load i64, ptr %l12, !tbaa !24
  %t234 = icmp slt i64 %t230, %t231
  %t236 = xor i1 %t234, true
  br i1 %t236, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb39:
  br label %bb40
bb40:
  %t238 = load i64, ptr %l9, !tbaa !24
  %t239 = load i64, ptr %l13, !tbaa !24
  %t240 = load i64, ptr %l11, !tbaa !24
  %t243 = mul i64 %t239, %t240
  %t246 = add i64 %t238, %t243
  store i64 %t246, ptr %l14, !tbaa !24
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr %"compiler/mir:Fn", ptr %t248, i32 0, i32 7
  %t251 = load i64, ptr %l14, !tbaa !24
  %t252 = load ptr, ptr @__olang_prog_scope
  %t255 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t252, ptr %t250, i64 %t251)
  store %"compiler/mir:Local" %t255, ptr %l134
  br label %bb41
bb41:
  %t256 = load %"compiler/mir:Local", ptr %l134
  store %"compiler/mir:Local" %t256, ptr %l15
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/mir:dumper", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/types:Table", ptr %t260, i32 0, i32 0
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t264 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 0
  %t265 = load i32, ptr %t264, !tbaa !23
  %t266 = load ptr, ptr @__olang_prog_scope
  %t269 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t266, ptr %s9, ptr %t263, i32 %t265)
  store { i64, ptr } %t269, ptr %l139
  br label %bb42
bb42:
  %t270 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t270, ptr %l16, !tbaa !27
  %t271 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 4
  %t272 = load { i64, [1 x i64] }, ptr %t271
  %t274 = extractvalue { i64, [1 x i64] } %t272, 0
  %t275 = icmp eq i64 %t274, 3
  br i1 %t275, label %bb43, label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l142, !tbaa !27
  br label %bb46
bb44:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 4
  %t279 = load { i64, [1 x i64] }, ptr %t278
  %t282 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s9, ptr %t277, { i64, [1 x i64] } %t279)
  store { i64, ptr } %t282, ptr %l145
  br label %bb45
bb45:
  %t283 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t285 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 1
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t288 = add i64 %t284, %t287
  %t289 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t288)
  call void @olang_textcopy(ptr %t289, ptr %t283, i64 %t284)
  %t290 = getelementptr i8, ptr %t289, i64 %t284
  call void @olang_textcopy(ptr %t290, ptr %t286, i64 %t287)
  %t291 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t289, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = extractvalue { i64, ptr } %t292, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  store { i64, ptr } %t299, ptr %l142, !tbaa !27
  br label %bb46
bb46:
  %t301 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t301, ptr %l17, !tbaa !27
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l148, !tbaa !29
  %t303 = load i64, ptr %l14, !tbaa !24
  store i64 %t303, ptr %l149, !tbaa !24
  %t304 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 3
  %t305 = load i32, ptr %t304, !range !{i32 0, i32 4}
  store i32 %t305, ptr %l150
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aLocalKind(ptr %s11, ptr %l150, i64 0)
  br label %bb47
bb47:
  %t307 = load ptr, ptr %s11
  %t308 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t309 = load i64, ptr %t308
  %t310 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t309)
  call void @olang_textcopy(ptr %t310, ptr %t307, i64 %t309)
  %t311 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  store { i64, ptr } %t312, ptr %l152, !tbaa !27
  %t313 = getelementptr %olang.builder, ptr %s11, i32 0, i32 3
  %t314 = load ptr, ptr %t313
  %t315 = icmp ne ptr %t314, null
  br i1 %t315, label %sbgrew.316, label %sbdone.317
sbgrew.316:
  call void @__olang_sb_done(ptr %s11)
  br label %sbdone.317
sbdone.317:
  %t318 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 0
  %t320 = extractvalue { i64, ptr } %t318, 1
  %t321 = mul i64 %t319, 1
  %t322 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t321)
  call void @llvm.memcpy.p0.p0.i64(ptr %t322, ptr %t320, i64 %t321, i1 false)
  %t323 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  %t326 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s9, ptr %s9, { i64, ptr } %t324)
  store { i64, ptr } %t326, ptr %l154
  br label %bb48
bb48:
  %t327 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t331 = icmp sgt i64 %t329, 0
  br i1 %t331, label %bb49, label %bb50
bb49:
  %t333 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t334 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t335 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t337 = extractvalue { i64, ptr } %t333, 1
  %t338 = extractvalue { i64, ptr } %t333, 0
  %t339 = add i64 %t335, %t338
  %t340 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t339)
  call void @olang_textcopy(ptr %t340, ptr %t334, i64 %t335)
  %t341 = getelementptr i8, ptr %t340, i64 %t335
  call void @olang_textcopy(ptr %t341, ptr %t337, i64 %t338)
  %t342 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t340, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = extractvalue { i64, ptr } %t343, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  store { i64, ptr } %t350, ptr %l158, !tbaa !27
  br label %bb51
bb50:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l158, !tbaa !27
  br label %bb51
bb51:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/mir:dumper", ptr %t352, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !29
  %t356 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 2
  %t357 = load i32, ptr %t356, !tbaa !23
  %t358 = load ptr, ptr @__olang_prog_scope
  %t361 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t358, ptr %s9, ptr %t355, i32 %t357)
  store { i64, ptr } %t361, ptr %l165
  br label %bb52
bb52:
  %t362 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t363 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t365 = load i64, ptr %l149, !tbaa !24
  %t366 = call i64 @__olang_fmt_i64(ptr null, i64 %t365)
  %t367 = add i64 %t364, %t366
  %t368 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t369 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t370 = add i64 %t367, %t369
  %t371 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t371, 1
  %t373 = extractvalue { i64, ptr } %t371, 0
  %t374 = add i64 %t370, %t373
  %t375 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t375, 1
  %t377 = extractvalue { i64, ptr } %t375, 0
  %t378 = add i64 %t374, %t377
  %t379 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t380 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t381 = add i64 %t378, %t380
  %t382 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t383 = extractvalue { i64, ptr } %t382, 1
  %t384 = extractvalue { i64, ptr } %t382, 0
  %t385 = add i64 %t381, %t384
  %t387 = extractvalue { i64, ptr } %t362, 1
  %t388 = extractvalue { i64, ptr } %t362, 0
  %t389 = add i64 %t385, %t388
  %t390 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t389)
  call void @olang_textcopy(ptr %t390, ptr %t363, i64 %t364)
  %t391 = getelementptr i8, ptr %t390, i64 %t364
  %t392 = call i64 @__olang_fmt_i64(ptr %t391, i64 %t365)
  %t393 = getelementptr i8, ptr %t391, i64 %t366
  call void @olang_textcopy(ptr %t393, ptr %t368, i64 %t369)
  %t394 = getelementptr i8, ptr %t393, i64 %t369
  call void @olang_textcopy(ptr %t394, ptr %t372, i64 %t373)
  %t395 = getelementptr i8, ptr %t394, i64 %t373
  call void @olang_textcopy(ptr %t395, ptr %t376, i64 %t377)
  %t396 = getelementptr i8, ptr %t395, i64 %t377
  call void @olang_textcopy(ptr %t396, ptr %t379, i64 %t380)
  %t397 = getelementptr i8, ptr %t396, i64 %t380
  call void @olang_textcopy(ptr %t397, ptr %t383, i64 %t384)
  %t398 = getelementptr i8, ptr %t397, i64 %t384
  call void @olang_textcopy(ptr %t398, ptr %t387, i64 %t388)
  %t399 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t390, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = extractvalue { i64, ptr } %t400, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  %t408 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s9, ptr %t408, i64 1, { i64, ptr } %t407)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t410 = load i64, ptr %l13, !tbaa !24
  %t412 = add i64 %t410, 1
  store i64 %t412, ptr %l13, !tbaa !24
  br label %bb37
bb55:
  store i64 0, ptr %l18, !tbaa !24
  %t414 = load ptr, ptr %l1, !tbaa !29
  %t416 = getelementptr %"compiler/mir:Fn", ptr %t414, i32 0, i32 8
  %t417 = load ptr, ptr @__olang_prog_scope
  %t419 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t417, ptr %t416)
  store i64 %t419, ptr %l173
  br label %bb56
bb56:
  %t420 = load i64, ptr %l173, !tbaa !24
  store i64 %t420, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t421 = load i64, ptr %l19, !tbaa !24
  %t422 = load i64, ptr %l18, !tbaa !24
  %t425 = icmp sgt i64 %t421, %t422
  br i1 %t425, label %bb57, label %bb58
bb57:
  %t427 = load i64, ptr %l20, !tbaa !24
  %t429 = icmp sgt i64 %t427, 0
  br i1 %t429, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l177, !tbaa !24
  br label %bb62
bb59:
  %t431 = load i64, ptr %l19, !tbaa !24
  %t432 = load i64, ptr %l18, !tbaa !24
  %t435 = sub i64 %t431, %t432
  %t436 = load i64, ptr %l20, !tbaa !24
  %t439 = add i64 %t435, %t436
  %t441 = sub i64 %t439, 1
  %t442 = load i64, ptr %l20, !tbaa !24
  %t445 = sdiv i64 %t441, %t442
  store i64 %t445, ptr %l180, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb61
bb61:
  %t447 = load i64, ptr %l180, !tbaa !24
  store i64 %t447, ptr %l177, !tbaa !24
  br label %bb62
bb62:
  %t448 = load i64, ptr %l177, !tbaa !24
  store i64 %t448, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s16
  %t449 = load i64, ptr %l22, !tbaa !24
  %t450 = load i64, ptr %l21, !tbaa !24
  %t453 = icmp slt i64 %t449, %t450
  %t455 = xor i1 %t453, true
  br i1 %t455, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s16)
  br label %bb82
bb65:
  br label %bb66
bb66:
  %t457 = load i64, ptr %l18, !tbaa !24
  %t458 = load i64, ptr %l22, !tbaa !24
  %t459 = load i64, ptr %l20, !tbaa !24
  %t462 = mul i64 %t458, %t459
  %t465 = add i64 %t457, %t462
  store i64 %t465, ptr %l23, !tbaa !24
  %t467 = load ptr, ptr %l1, !tbaa !29
  %t469 = getelementptr %"compiler/mir:Fn", ptr %t467, i32 0, i32 8
  %t470 = load i64, ptr %l23, !tbaa !24
  %t471 = load ptr, ptr @__olang_prog_scope
  %t474 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t471, ptr %t469, i64 %t470)
  store %"compiler/mir:ScopeInfo" %t474, ptr %l201
  br label %bb67
bb67:
  %t475 = load %"compiler/mir:ScopeInfo", ptr %l201
  store %"compiler/mir:ScopeInfo" %t475, ptr %l24
  %t476 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 1
  %t477 = load i32, ptr %t476, !tbaa !23
  %t478 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t481 = icmp eq i32 %t477, %t478
  br i1 %t481, label %bb68, label %bb69
bb68:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l205, !tbaa !27
  br label %bb70
bb69:
  %t483 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 1
  %t484 = load i32, ptr %t483, !tbaa !23
  %t485 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t486 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t488 = sext i32 %t484 to i64
  %t489 = call i64 @__olang_fmt_i64(ptr null, i64 %t488)
  %t490 = add i64 %t486, %t489
  %t491 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t490)
  call void @olang_textcopy(ptr %t491, ptr %t485, i64 %t486)
  %t492 = getelementptr i8, ptr %t491, i64 %t486
  %t493 = call i64 @__olang_fmt_i64(ptr %t492, i64 %t488)
  %t494 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t491, 1
  %t497 = extractvalue { i64, ptr } %t495, 0
  %t498 = extractvalue { i64, ptr } %t495, 1
  %t499 = mul i64 %t497, 1
  %t500 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t499)
  call void @llvm.memcpy.p0.p0.i64(ptr %t500, ptr %t498, i64 %t499, i1 false)
  %t501 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t500, 1
  store { i64, ptr } %t502, ptr %l205, !tbaa !27
  br label %bb70
bb70:
  %t504 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t504, ptr %l25, !tbaa !27
  %t505 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 2
  %t506 = load i32, ptr %t505, !tbaa !23
  %t508 = icmp slt i32 %t506, 0
  br i1 %t508, label %bb71, label %bb72
bb71:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l211, !tbaa !27
  br label %bb73
bb72:
  %t510 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 2
  %t511 = load i32, ptr %t510, !tbaa !23
  %t512 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t513 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t515 = sext i32 %t511 to i64
  %t516 = call i64 @__olang_fmt_i64(ptr null, i64 %t515)
  %t517 = add i64 %t513, %t516
  %t518 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t517)
  call void @olang_textcopy(ptr %t518, ptr %t512, i64 %t513)
  %t519 = getelementptr i8, ptr %t518, i64 %t513
  %t520 = call i64 @__olang_fmt_i64(ptr %t519, i64 %t515)
  %t521 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t518, 1
  %t524 = extractvalue { i64, ptr } %t522, 0
  %t525 = extractvalue { i64, ptr } %t522, 1
  %t526 = mul i64 %t524, 1
  %t527 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t526)
  call void @llvm.memcpy.p0.p0.i64(ptr %t527, ptr %t525, i64 %t526, i1 false)
  %t528 = insertvalue { i64, ptr } undef, i64 %t524, 0
  %t529 = insertvalue { i64, ptr } %t528, ptr %t527, 1
  store { i64, ptr } %t529, ptr %l211, !tbaa !27
  br label %bb73
bb73:
  %t531 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t531, ptr %l26, !tbaa !27
  %t532 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 4
  %t533 = load i32, ptr %t532, !tbaa !23
  %t535 = icmp eq i32 %t533, 0
  br i1 %t535, label %bb74, label %bb75
bb74:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l217, !tbaa !27
  br label %bb77
bb75:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 4
  %t539 = load i32, ptr %t538, !tbaa !23
  %t542 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %s16, ptr %t537, i32 %t539)
  store { i64, ptr } %t542, ptr %l220
  br label %bb76
bb76:
  %t543 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t544 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t545 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t546 = extractvalue { i64, ptr } %t545, 1
  %t547 = extractvalue { i64, ptr } %t545, 0
  %t548 = add i64 %t544, %t547
  %t549 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t548)
  call void @olang_textcopy(ptr %t549, ptr %t543, i64 %t544)
  %t550 = getelementptr i8, ptr %t549, i64 %t544
  call void @olang_textcopy(ptr %t550, ptr %t546, i64 %t547)
  %t551 = insertvalue { i64, ptr } undef, i64 %t548, 0
  %t552 = insertvalue { i64, ptr } %t551, ptr %t549, 1
  %t554 = extractvalue { i64, ptr } %t552, 0
  %t555 = extractvalue { i64, ptr } %t552, 1
  %t556 = mul i64 %t554, 1
  %t557 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t556)
  call void @llvm.memcpy.p0.p0.i64(ptr %t557, ptr %t555, i64 %t556, i1 false)
  %t558 = insertvalue { i64, ptr } undef, i64 %t554, 0
  %t559 = insertvalue { i64, ptr } %t558, ptr %t557, 1
  store { i64, ptr } %t559, ptr %l217, !tbaa !27
  br label %bb77
bb77:
  %t561 = load { i64, ptr }, ptr %l217, !tbaa !27
  store { i64, ptr } %t561, ptr %l27, !tbaa !27
  %t562 = load ptr, ptr %l0, !tbaa !29
  store ptr %t562, ptr %l223, !tbaa !29
  %t563 = load i64, ptr %l23, !tbaa !24
  store i64 %t563, ptr %l224, !tbaa !24
  %t564 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 0
  %t565 = load i32, ptr %t564, !range !{i32 0, i32 7}
  store i32 %t565, ptr %l225
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s20
  store ptr %s20room, ptr %s20
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aScopeKind(ptr %s20, ptr %l225, i64 0)
  br label %bb78
bb78:
  %t567 = load ptr, ptr %s20
  %t568 = getelementptr %olang.builder, ptr %s20, i32 0, i32 1
  %t569 = load i64, ptr %t568
  %t570 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t569)
  call void @olang_textcopy(ptr %t570, ptr %t567, i64 %t569)
  %t571 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t572 = insertvalue { i64, ptr } %t571, ptr %t570, 1
  store { i64, ptr } %t572, ptr %l227, !tbaa !27
  %t573 = getelementptr %olang.builder, ptr %s20, i32 0, i32 3
  %t574 = load ptr, ptr %t573
  %t575 = icmp ne ptr %t574, null
  br i1 %t575, label %sbgrew.576, label %sbdone.577
sbgrew.576:
  call void @__olang_sb_done(ptr %s20)
  br label %sbdone.577
sbdone.577:
  %t578 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t578, 0
  %t580 = extractvalue { i64, ptr } %t578, 1
  %t581 = mul i64 %t579, 1
  %t582 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t581)
  call void @llvm.memcpy.p0.p0.i64(ptr %t582, ptr %t580, i64 %t581, i1 false)
  %t583 = insertvalue { i64, ptr } undef, i64 %t579, 0
  %t584 = insertvalue { i64, ptr } %t583, ptr %t582, 1
  %t586 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s16, ptr %s16, { i64, ptr } %t584)
  store { i64, ptr } %t586, ptr %l229
  br label %bb79
bb79:
  %t587 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t588 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t589 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t590 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t591 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t592 = load i64, ptr %l224, !tbaa !24
  %t593 = call i64 @__olang_fmt_i64(ptr null, i64 %t592)
  %t594 = add i64 %t591, %t593
  %t595 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t596 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t597 = add i64 %t594, %t596
  %t598 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t598, 1
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t601 = add i64 %t597, %t600
  %t603 = extractvalue { i64, ptr } %t587, 1
  %t604 = extractvalue { i64, ptr } %t587, 0
  %t605 = add i64 %t601, %t604
  %t607 = extractvalue { i64, ptr } %t588, 1
  %t608 = extractvalue { i64, ptr } %t588, 0
  %t609 = add i64 %t605, %t608
  %t611 = extractvalue { i64, ptr } %t589, 1
  %t612 = extractvalue { i64, ptr } %t589, 0
  %t613 = add i64 %t609, %t612
  %t614 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t613)
  call void @olang_textcopy(ptr %t614, ptr %t590, i64 %t591)
  %t615 = getelementptr i8, ptr %t614, i64 %t591
  %t616 = call i64 @__olang_fmt_i64(ptr %t615, i64 %t592)
  %t617 = getelementptr i8, ptr %t615, i64 %t593
  call void @olang_textcopy(ptr %t617, ptr %t595, i64 %t596)
  %t618 = getelementptr i8, ptr %t617, i64 %t596
  call void @olang_textcopy(ptr %t618, ptr %t599, i64 %t600)
  %t619 = getelementptr i8, ptr %t618, i64 %t600
  call void @olang_textcopy(ptr %t619, ptr %t603, i64 %t604)
  %t620 = getelementptr i8, ptr %t619, i64 %t604
  call void @olang_textcopy(ptr %t620, ptr %t607, i64 %t608)
  %t621 = getelementptr i8, ptr %t620, i64 %t608
  call void @olang_textcopy(ptr %t621, ptr %t611, i64 %t612)
  %t622 = insertvalue { i64, ptr } undef, i64 %t613, 0
  %t623 = insertvalue { i64, ptr } %t622, ptr %t614, 1
  %t625 = extractvalue { i64, ptr } %t623, 0
  %t626 = extractvalue { i64, ptr } %t623, 1
  %t627 = mul i64 %t625, 1
  %t628 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t627)
  call void @llvm.memcpy.p0.p0.i64(ptr %t628, ptr %t626, i64 %t627, i1 false)
  %t629 = insertvalue { i64, ptr } undef, i64 %t625, 0
  %t630 = insertvalue { i64, ptr } %t629, ptr %t628, 1
  %t631 = load ptr, ptr %l223, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s16, ptr %t631, i64 1, { i64, ptr } %t630)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s16)
  br label %bb81
bb81:
  %t633 = load i64, ptr %l22, !tbaa !24
  %t635 = add i64 %t633, 1
  store i64 %t635, ptr %l22, !tbaa !24
  br label %bb63
bb82:
  store i64 0, ptr %l28, !tbaa !24
  %t637 = load ptr, ptr %l1, !tbaa !29
  %t639 = getelementptr %"compiler/mir:Fn", ptr %t637, i32 0, i32 9
  %t640 = load ptr, ptr @__olang_prog_scope
  %t642 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t640, ptr %t639)
  store i64 %t642, ptr %l239
  br label %bb83
bb83:
  %t643 = load i64, ptr %l239, !tbaa !24
  store i64 %t643, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t644 = load i64, ptr %l29, !tbaa !24
  %t645 = load i64, ptr %l28, !tbaa !24
  %t648 = icmp sgt i64 %t644, %t645
  br i1 %t648, label %bb84, label %bb85
bb84:
  %t650 = load i64, ptr %l30, !tbaa !24
  %t652 = icmp sgt i64 %t650, 0
  br i1 %t652, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l243, !tbaa !24
  br label %bb89
bb86:
  %t654 = load i64, ptr %l29, !tbaa !24
  %t655 = load i64, ptr %l28, !tbaa !24
  %t658 = sub i64 %t654, %t655
  %t659 = load i64, ptr %l30, !tbaa !24
  %t662 = add i64 %t658, %t659
  %t664 = sub i64 %t662, 1
  %t665 = load i64, ptr %l30, !tbaa !24
  %t668 = sdiv i64 %t664, %t665
  store i64 %t668, ptr %l246, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l246, !tbaa !24
  br label %bb88
bb88:
  %t670 = load i64, ptr %l246, !tbaa !24
  store i64 %t670, ptr %l243, !tbaa !24
  br label %bb89
bb89:
  %t671 = load i64, ptr %l243, !tbaa !24
  store i64 %t671, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb90
bb90:
  store %olang.scope zeroinitializer, ptr %s24
  %t672 = load i64, ptr %l32, !tbaa !24
  %t673 = load i64, ptr %l31, !tbaa !24
  %t676 = icmp slt i64 %t672, %t673
  %t678 = xor i1 %t676, true
  br i1 %t678, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s24)
  br label %bb109
bb92:
  br label %bb93
bb93:
  %t680 = load i64, ptr %l28, !tbaa !24
  %t681 = load i64, ptr %l32, !tbaa !24
  %t682 = load i64, ptr %l30, !tbaa !24
  %t685 = mul i64 %t681, %t682
  %t688 = add i64 %t680, %t685
  store i64 %t688, ptr %l33, !tbaa !24
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load i64, ptr %l33, !tbaa !24
  %t692 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t693 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t695 = call i64 @__olang_fmt_i64(ptr null, i64 %t691)
  %t696 = add i64 %t693, %t695
  %t697 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t698 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t699 = add i64 %t696, %t698
  %t700 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t699)
  call void @olang_textcopy(ptr %t700, ptr %t692, i64 %t693)
  %t701 = getelementptr i8, ptr %t700, i64 %t693
  %t702 = call i64 @__olang_fmt_i64(ptr %t701, i64 %t691)
  %t703 = getelementptr i8, ptr %t701, i64 %t695
  call void @olang_textcopy(ptr %t703, ptr %t697, i64 %t698)
  %t704 = insertvalue { i64, ptr } undef, i64 %t699, 0
  %t705 = insertvalue { i64, ptr } %t704, ptr %t700, 1
  %t707 = extractvalue { i64, ptr } %t705, 0
  %t708 = extractvalue { i64, ptr } %t705, 1
  %t709 = mul i64 %t707, 1
  %t710 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t709)
  call void @llvm.memcpy.p0.p0.i64(ptr %t710, ptr %t708, i64 %t709, i1 false)
  %t711 = insertvalue { i64, ptr } undef, i64 %t707, 0
  %t712 = insertvalue { i64, ptr } %t711, ptr %t710, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s24, ptr %t690, i64 0, { i64, ptr } %t712)
  br label %bb94
bb94:
  %t715 = load ptr, ptr %l1, !tbaa !29
  %t717 = getelementptr %"compiler/mir:Fn", ptr %t715, i32 0, i32 9
  %t718 = load i64, ptr %l33, !tbaa !24
  %t719 = load ptr, ptr @__olang_prog_scope
  %t722 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t719, ptr %s24, ptr %t717, i64 %t718)
  store ptr %t722, ptr %l271
  br label %bb95
bb95:
  %t723 = load ptr, ptr %l271, !tbaa !29
  store ptr %t723, ptr %l34, !tbaa !29
  %t724 = load ptr, ptr %l34, !tbaa !29
  %t726 = getelementptr %"compiler/mir:BasicBlock", ptr %t724, i32 0, i32 0
  store ptr %t726, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s27
  %t728 = load i64, ptr %l36, !tbaa !24
  store i64 %t728, ptr %l274, !tbaa !24
  %t729 = load ptr, ptr %l35, !tbaa !29
  %t731 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %s24, ptr %t729)
  store i64 %t731, ptr %l276
  br label %bb97
bb97:
  %t732 = load i64, ptr %l274, !tbaa !24
  %t733 = load i64, ptr %l276, !tbaa !24
  %t734 = icmp slt i64 %t732, %t733
  %t736 = xor i1 %t734, true
  br i1 %t736, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s27)
  br label %bb105
bb99:
  br label %bb100
bb100:
  %t738 = load ptr, ptr %l35, !tbaa !29
  %t739 = load i64, ptr %l36, !tbaa !24
  %t742 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %s24, ptr %t738, i64 %t739)
  store { i64, [21 x i64] } %t742, ptr %l281
  br label %bb101
bb101:
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %l281, i64 176, i1 false)
  %t743 = load ptr, ptr %l0, !tbaa !29
  store ptr %t743, ptr %l282, !tbaa !29
  %t744 = load ptr, ptr %l0, !tbaa !29
  %t747 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2estmt(ptr %v0, ptr %s27, ptr %s27, ptr %t744, ptr %l37)
  store { i64, ptr } %t747, ptr %l285
  br label %bb102
bb102:
  %t748 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t749 = extractvalue { i64, ptr } %t748, 0
  %t750 = extractvalue { i64, ptr } %t748, 1
  %t751 = mul i64 %t749, 1
  %t752 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t751)
  call void @llvm.memcpy.p0.p0.i64(ptr %t752, ptr %t750, i64 %t751, i1 false)
  %t753 = insertvalue { i64, ptr } undef, i64 %t749, 0
  %t754 = insertvalue { i64, ptr } %t753, ptr %t752, 1
  %t755 = load ptr, ptr %l282, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s27, ptr %t755, i64 1, { i64, ptr } %t754)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s27)
  br label %bb104
bb104:
  %t757 = load i64, ptr %l36, !tbaa !24
  %t759 = add i64 %t757, 1
  store i64 %t759, ptr %l36, !tbaa !24
  br label %bb96
bb105:
  %t761 = load ptr, ptr %l0, !tbaa !29
  store ptr %t761, ptr %l289, !tbaa !29
  %t762 = load ptr, ptr %l0, !tbaa !29
  %t763 = load ptr, ptr %l34, !tbaa !29
  %t765 = getelementptr %"compiler/mir:BasicBlock", ptr %t763, i32 0, i32 1
  %t766 = load { i64, [8 x i64] }, ptr %t765
  %t769 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eterm(ptr %v0, ptr %s24, ptr %t762, { i64, [8 x i64] } %t766)
  store { i64, ptr } %t769, ptr %l293
  br label %bb106
bb106:
  %t770 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t771 = extractvalue { i64, ptr } %t770, 0
  %t772 = extractvalue { i64, ptr } %t770, 1
  %t773 = mul i64 %t771, 1
  %t774 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t773)
  call void @llvm.memcpy.p0.p0.i64(ptr %t774, ptr %t772, i64 %t773, i1 false)
  %t775 = insertvalue { i64, ptr } undef, i64 %t771, 0
  %t776 = insertvalue { i64, ptr } %t775, ptr %t774, 1
  %t777 = load ptr, ptr %l289, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %s24, ptr %t777, i64 1, { i64, ptr } %t776)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s24)
  br label %bb108
bb108:
  %t779 = load i64, ptr %l32, !tbaa !24
  %t781 = add i64 %t779, 1
  store i64 %t781, ptr %l32, !tbaa !24
  br label %bb90
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecases(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Case"
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i32
  %l18 = alloca i32
  %l44 = alloca %"compiler/mir:Case"
  %l45 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i32 0, ptr %l3, !tbaa !23
  %t3 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = icmp sgt i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t14 = icmp sgt i32 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb7
bb4:
  %t16 = load i32, ptr %l4, !tbaa !23
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = sub i32 %t16, %t17
  %t21 = load i32, ptr %l5, !tbaa !23
  %t24 = add i32 %t20, %t21
  %t26 = sub i32 %t24, 1
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = sdiv i32 %t26, %t27
  store i32 %t30, ptr %l18, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l18, !tbaa !23
  store i32 %t32, ptr %l15, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l15, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i32, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l6, !tbaa !23
  %t38 = icmp slt i32 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = mul i32 %t43, %t44
  %t50 = add i32 %t42, %t47
  store i32 %t50, ptr %l8, !tbaa !23
  %t54 = getelementptr %"compiler/mir:dumper", ptr %a0, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/mir:Fn", ptr %t55, i32 0, i32 15
  %t58 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t62 = load i32, ptr %l8, !tbaa !23
  %t64 = sext i32 %t62 to i64
  %t67 = add i64 %t61, %t64
  %t68 = load ptr, ptr @__olang_prog_scope
  %t71 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %t68, ptr %t57, i64 %t67)
  store %"compiler/mir:Case" %t71, ptr %l44
  br label %bb12
bb12:
  %t72 = load %"compiler/mir:Case", ptr %l44
  store %"compiler/mir:Case" %t72, ptr %l9
  store ptr %l2, ptr %l45, !tbaa !29
  %t73 = load i32, ptr %l8, !tbaa !23
  %t75 = icmp sgt i32 %t73, 0
  br i1 %t75, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l48, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l48, !tbaa !27
  br label %bb15
bb15:
  %t77 = getelementptr %"compiler/mir:Case", ptr %l9, i32 0, i32 0
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = getelementptr %"compiler/mir:Case", ptr %l9, i32 0, i32 1
  %t80 = load i32, ptr %t79, !tbaa !23
  %t81 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t85 = call i64 @__olang_fmt_i64(ptr null, i64 %t78)
  %t86 = add i64 %t83, %t85
  %t87 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t91 = sext i32 %t80 to i64
  %t92 = call i64 @__olang_fmt_i64(ptr null, i64 %t91)
  %t93 = add i64 %t89, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t82, i64 %t83)
  %t95 = getelementptr i8, ptr %t94, i64 %t83
  %t96 = call i64 @__olang_fmt_i64(ptr %t95, i64 %t78)
  %t97 = getelementptr i8, ptr %t95, i64 %t85
  call void @olang_textcopy(ptr %t97, ptr %t87, i64 %t88)
  %t98 = getelementptr i8, ptr %t97, i64 %t88
  %t99 = call i64 @__olang_fmt_i64(ptr %t98, i64 %t91)
  %t100 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t94, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = extractvalue { i64, ptr } %t101, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t109, { i64, ptr } %t108)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t111 = load i32, ptr %l7, !tbaa !23
  %t113 = add i32 %t111, 1
  store i32 %t113, ptr %l7, !tbaa !23
  br label %bb8
bb18:
  %t116 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t116, ptr %l56
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i32
  %l18 = alloca i32
  %l36 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 91)
  br label %bb2
bb2:
  store i32 0, ptr %l3, !tbaa !23
  %t4 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = icmp sgt i32 %t7, %t8
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load i32, ptr %l5, !tbaa !23
  %t15 = icmp sgt i32 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb4:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb8
bb5:
  %t17 = load i32, ptr %l4, !tbaa !23
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = sub i32 %t17, %t18
  %t22 = load i32, ptr %l5, !tbaa !23
  %t25 = add i32 %t21, %t22
  %t27 = sub i32 %t25, 1
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = sdiv i32 %t27, %t28
  store i32 %t31, ptr %l18, !tbaa !23
  br label %bb7
bb6:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l18, !tbaa !23
  store i32 %t33, ptr %l15, !tbaa !23
  br label %bb8
bb8:
  %t34 = load i32, ptr %l15, !tbaa !23
  store i32 %t34, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i32, ptr %l7, !tbaa !23
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = icmp slt i32 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t43 = load i32, ptr %l3, !tbaa !23
  %t44 = load i32, ptr %l7, !tbaa !23
  %t45 = load i32, ptr %l5, !tbaa !23
  %t48 = mul i32 %t44, %t45
  %t51 = add i32 %t43, %t48
  store i32 %t51, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l36, !tbaa !29
  %t53 = load i32, ptr %l8, !tbaa !23
  %t55 = icmp sgt i32 %t53, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/mir:dumper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/mir:Fn", ptr %t61, i32 0, i32 20
  %t64 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t65 = load i32, ptr %t64, !tbaa !23
  %t67 = sext i32 %t65 to i64
  %t68 = load i32, ptr %l8, !tbaa !23
  %t70 = sext i32 %t68 to i64
  %t73 = add i64 %t67, %t70
  %t74 = load ptr, ptr @__olang_prog_scope
  %t77 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %t74, ptr %t63, i64 %t73)
  store i32 %t77, ptr %l49
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = load i32, ptr %l49, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %s2, ptr %t78, i32 %t79)
  store { i64, ptr } %t80, ptr %l50
  br label %bb17
bb17:
  %t81 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = add i64 %t83, %t86
  %t88 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t82, i64 %t83)
  %t89 = getelementptr i8, ptr %t88, i64 %t83
  call void @olang_textcopy(ptr %t89, ptr %t85, i64 %t86)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  %t99 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t99, { i64, ptr } %t98)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t101 = load i32, ptr %l7, !tbaa !23
  %t103 = add i32 %t101, 1
  store i32 %t103, ptr %l7, !tbaa !23
  br label %bb9
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 93)
  br label %bb21
bb21:
  %t107 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t107, ptr %l57
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t108 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l30 = alloca i32
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t14 = sext i32 %t10 to i64
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t14)
  %t16 = add i64 %t12, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = getelementptr i8, ptr %t17, i64 %t12
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  br label %bb31
bb4:
  %t23 = load { i64, [2 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 1
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l3, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t32 = load i32, ptr %l3, !tbaa !23
  %t33 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t36 = sext i32 %t32 to i64
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t36)
  %t38 = add i64 %t34, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t33, i64 %t34)
  %t40 = getelementptr i8, ptr %t39, i64 %t34
  %t41 = call i64 @__olang_fmt_i64(ptr %t40, i64 %t36)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  store { i64, ptr } %t43, ptr %l10, !tbaa !27
  br label %bb31
bb8:
  %t45 = load { i64, [2 x i64] }, ptr %l1
  %t47 = extractvalue { i64, [2 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 2
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t50 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t51 = getelementptr { i32 }, ptr %t50, i32 0, i32 0
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t54 = load i32, ptr %l4, !tbaa !23
  %t55 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t58 = sext i32 %t54 to i64
  %t59 = call i64 @__olang_fmt_i64(ptr null, i64 %t58)
  %t60 = add i64 %t56, %t59
  %t61 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t55, i64 %t56)
  %t62 = getelementptr i8, ptr %t61, i64 %t56
  %t63 = call i64 @__olang_fmt_i64(ptr %t62, i64 %t58)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t61, 1
  store { i64, ptr } %t65, ptr %l10, !tbaa !27
  br label %bb31
bb12:
  %t67 = load { i64, [2 x i64] }, ptr %l1
  %t69 = extractvalue { i64, [2 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 3
  br i1 %t70, label %bb13, label %bb14
bb13:
  %t72 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t73 = getelementptr { i32, i32 }, ptr %t72, i32 0, i32 0
  %t74 = load i32, ptr %t73, !range !{i32 0, i32 8}
  store i32 %t74, ptr %l5
  %t76 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t77 = getelementptr { i32, i32 }, ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l6, !tbaa !23
  br label %bb15
bb14:
  br label %bb19
bb15:
  store %olang.scope zeroinitializer, ptr %s7
  %t80 = load i32, ptr %l5, !range !{i32 0, i32 8}
  store i32 %t80, ptr %l30
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %s8, ptr %l30, i64 0)
  br label %bb16
bb16:
  %t82 = load ptr, ptr %s8
  %t83 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t84 = load i64, ptr %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t82, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  store { i64, ptr } %t87, ptr %l32, !tbaa !27
  %t88 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t89 = load ptr, ptr %t88
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %sbgrew.91, label %sbdone.92
sbgrew.91:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.92
sbdone.92:
  %t93 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t101 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s7, ptr %s7, { i64, ptr } %t99)
  store { i64, ptr } %t101, ptr %l34
  br label %bb17
bb17:
  %t104 = getelementptr %"compiler/mir:dumper", ptr %a0, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t106 = load i32, ptr %l6, !tbaa !23
  %t107 = load ptr, ptr @__olang_prog_scope
  %t110 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t107, ptr %s7, ptr %t105, i32 %t106)
  store { i64, ptr } %t110, ptr %l38
  br label %bb18
bb18:
  %t111 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t116 = add i64 %t113, %t115
  %t117 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = add i64 %t116, %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t112, i64 %t113)
  %t122 = getelementptr i8, ptr %t121, i64 %t113
  call void @olang_textcopy(ptr %t122, ptr %t114, i64 %t115)
  %t123 = getelementptr i8, ptr %t122, i64 %t115
  call void @olang_textcopy(ptr %t123, ptr %t118, i64 %t119)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t121, 1
  store { i64, ptr } %t125, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb19:
  %t127 = load { i64, [2 x i64] }, ptr %l1
  %t129 = extractvalue { i64, [2 x i64] } %t127, 0
  %t130 = icmp eq i64 %t129, 4
  br i1 %t130, label %bb20, label %bb21
bb20:
  %t132 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t133 = getelementptr { i64 }, ptr %t132, i32 0, i32 0
  %t134 = load i64, ptr %t133
  store i64 %t134, ptr %l7, !tbaa !24
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t136 = load i64, ptr %l7, !tbaa !24
  %t137 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t140 = call i64 @__olang_fmt_i64(ptr null, i64 %t136)
  %t141 = add i64 %t138, %t140
  %t142 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t141)
  call void @olang_textcopy(ptr %t142, ptr %t137, i64 %t138)
  %t143 = getelementptr i8, ptr %t142, i64 %t138
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t136)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t142, 1
  store { i64, ptr } %t146, ptr %l10, !tbaa !27
  br label %bb31
bb23:
  %t148 = load { i64, [2 x i64] }, ptr %l1
  %t150 = extractvalue { i64, [2 x i64] } %t148, 0
  %t151 = icmp eq i64 %t150, 5
  br i1 %t151, label %bb24, label %bb25
bb24:
  %t153 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t154 = getelementptr { i64, i1 }, ptr %t153, i32 0, i32 0
  %t155 = load i64, ptr %t154
  store i64 %t155, ptr %l8, !tbaa !24
  %t157 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t158 = getelementptr { i64, i1 }, ptr %t157, i32 0, i32 1
  %t159 = load i1, ptr %t158
  store i1 %t159, ptr %l9, !tbaa !21
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t161 = load i64, ptr %l8, !tbaa !24
  store i64 %t161, ptr %l49, !tbaa !24
  %t162 = load i1, ptr %l9, !tbaa !21
  br i1 %t162, label %bb27, label %bb28
bb27:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l51, !tbaa !27
  br label %bb29
bb28:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l51, !tbaa !27
  br label %bb29
bb29:
  %t164 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t166 = load i64, ptr %l49, !tbaa !24
  %t167 = call i64 @__olang_fmt_i64(ptr null, i64 %t166)
  %t168 = add i64 %t165, %t167
  %t169 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = add i64 %t168, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t164, i64 %t165)
  %t174 = getelementptr i8, ptr %t173, i64 %t165
  %t175 = call i64 @__olang_fmt_i64(ptr %t174, i64 %t166)
  %t176 = getelementptr i8, ptr %t174, i64 %t167
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t173, 1
  store { i64, ptr } %t178, ptr %l10, !tbaa !27
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_792180efaebdc40a_e488d776d0fba16e)
  unreachable
bb31:
  %t180 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t180, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l9, !tbaa !27
  br label %bb21
bb4:
  %t8 = load { i64, [4 x i64] }, ptr %l1
  %t10 = extractvalue { i64, [4 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t13, i32 0, i32 0
  %t15 = load %"compiler/mir:Lvalue", ptr %t14
  store %"compiler/mir:Lvalue" %t15, ptr %l2
  br label %bb7
bb6:
  br label %bb9
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load %"compiler/mir:Lvalue", ptr %l2
  %t21 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s2, ptr %t17, %"compiler/mir:Lvalue" %t18)
  store { i64, ptr } %t21, ptr %l19
  br label %bb8
bb8:
  %t22 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t24 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t22, i64 %t23)
  %t29 = getelementptr i8, ptr %t28, i64 %t23
  call void @olang_textcopy(ptr %t29, ptr %t25, i64 %t26)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  store { i64, ptr } %t31, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb9:
  %t33 = load { i64, [4 x i64] }, ptr %l1
  %t35 = extractvalue { i64, [4 x i64] } %t33, 0
  %t36 = icmp eq i64 %t35, 2
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t39 = getelementptr { i32, i64 }, ptr %t38, i32 0, i32 0
  %t40 = load i32, ptr %t39
  store i32 %t40, ptr %l3, !tbaa !23
  %t42 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { i32, i64 }, ptr %t42, i32 0, i32 1
  %t44 = load i64, ptr %t43
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/mir:dumper", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t51 = load ptr, ptr @__olang_prog_scope
  %t54 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t51, ptr %s4, ptr %t49, i32 %t50)
  store { i64, ptr } %t54, ptr %l28
  br label %bb13
bb13:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t56 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t58 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t66 = call i64 @__olang_fmt_i64(ptr null, i64 %t55)
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t56, i64 %t57)
  %t69 = getelementptr i8, ptr %t68, i64 %t57
  call void @olang_textcopy(ptr %t69, ptr %t59, i64 %t60)
  %t70 = getelementptr i8, ptr %t69, i64 %t60
  call void @olang_textcopy(ptr %t70, ptr %t62, i64 %t63)
  %t71 = getelementptr i8, ptr %t70, i64 %t63
  %t72 = call i64 @__olang_fmt_i64(ptr %t71, i64 %t55)
  %t73 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t68, 1
  store { i64, ptr } %t74, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb14:
  %t76 = load { i64, [4 x i64] }, ptr %l1
  %t78 = extractvalue { i64, [4 x i64] } %t76, 0
  %t79 = icmp eq i64 %t78, 3
  br i1 %t79, label %bb15, label %bb16
bb15:
  %t81 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t82 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82
  store i32 %t83, ptr %l5, !tbaa !23
  %t85 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t86 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t85, i32 0, i32 1
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l6, !tbaa !23
  %t89 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t90 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t89, i32 0, i32 2
  %t91 = load i64, ptr %t90
  store i64 %t91, ptr %l7, !tbaa !24
  %t93 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t94 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t93, i32 0, i32 3
  %t95 = load %"compiler/source:Span", ptr %t94
  store %"compiler/source:Span" %t95, ptr %l8
  br label %bb17
bb16:
  br label %bb20
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/mir:dumper", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t101 = load i32, ptr %l5, !tbaa !23
  %t102 = load ptr, ptr @__olang_prog_scope
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t102, ptr %s6, ptr %t100, i32 %t101)
  store { i64, ptr } %t105, ptr %l40
  br label %bb18
bb18:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l6, !tbaa !23
  %t110 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %s6, ptr %t106, i32 %t107)
  store { i64, ptr } %t110, ptr %l43
  br label %bb19
bb19:
  %t111 = load i64, ptr %l7, !tbaa !24
  %t112 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t113 = load i32, ptr %t112, !tbaa !23
  %t114 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t116 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = add i64 %t115, %t118
  %t120 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t122 = add i64 %t119, %t121
  %t123 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = add i64 %t122, %t125
  %t127 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t131 = call i64 @__olang_fmt_i64(ptr null, i64 %t111)
  %t132 = add i64 %t129, %t131
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t137 = sext i32 %t113 to i64
  %t138 = call i64 @__olang_fmt_i64(ptr null, i64 %t137)
  %t139 = add i64 %t135, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t114, i64 %t115)
  %t141 = getelementptr i8, ptr %t140, i64 %t115
  call void @olang_textcopy(ptr %t141, ptr %t117, i64 %t118)
  %t142 = getelementptr i8, ptr %t141, i64 %t118
  call void @olang_textcopy(ptr %t142, ptr %t120, i64 %t121)
  %t143 = getelementptr i8, ptr %t142, i64 %t121
  call void @olang_textcopy(ptr %t143, ptr %t124, i64 %t125)
  %t144 = getelementptr i8, ptr %t143, i64 %t125
  call void @olang_textcopy(ptr %t144, ptr %t127, i64 %t128)
  %t145 = getelementptr i8, ptr %t144, i64 %t128
  %t146 = call i64 @__olang_fmt_i64(ptr %t145, i64 %t111)
  %t147 = getelementptr i8, ptr %t145, i64 %t131
  call void @olang_textcopy(ptr %t147, ptr %t133, i64 %t134)
  %t148 = getelementptr i8, ptr %t147, i64 %t134
  %t149 = call i64 @__olang_fmt_i64(ptr %t148, i64 %t137)
  %t150 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t140, 1
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4b3ff56260a2bca0_3dcb0434d488ed4c)
  unreachable
bb21:
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  store i64 %t154, ptr %l47, !tbaa !24
  %t155 = load i64, ptr %l47, !tbaa !24
  %t156 = mul i64 %t155, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l48, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = load i64, ptr %l47, !tbaa !24
  %t165 = mul i64 %t164, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t161, ptr %t163, i64 %t165, i1 false)
  %t166 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t166, ptr %l9, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t167, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l40 = alloca { i64, ptr }
  %l47 = alloca i32
  %l50 = alloca i32
  %l76 = alloca { i64, [1 x i64] }
  %l111 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l3
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb6:
  %t12 = load { i64, [2 x i64] }, ptr %l3
  %t14 = extractvalue { i64, [2 x i64] } %t12, 0
  %t15 = icmp eq i64 %t14, 1
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t17 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l4, !tbaa !23
  br label %bb9
bb8:
  br label %bb11
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i32, ptr %l4, !tbaa !23
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t25 = sext i32 %t21 to i64
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t22, i64 %t23)
  %t29 = getelementptr i8, ptr %t28, i64 %t23
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %t25)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t28, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t39)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb11:
  %t42 = load { i64, [2 x i64] }, ptr %l3
  %t44 = extractvalue { i64, [2 x i64] } %t42, 0
  %t45 = icmp eq i64 %t44, 2
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t47 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t48 = getelementptr { i64, i32, i32 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  store i64 %t49, ptr %l5, !tbaa !24
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t52 = getelementptr { i64, i32, i32 }, ptr %t51, i32 0, i32 1
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb17
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l34, !tbaa !29
  %t55 = load i64, ptr %l5, !tbaa !24
  store i64 %t55, ptr %l35, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/mir:dumper", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/types:Table", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i32, ptr %l6, !tbaa !23
  %t64 = load ptr, ptr @__olang_prog_scope
  %t67 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t64, ptr %s4, ptr %t62, i32 %t63)
  store { i64, ptr } %t67, ptr %l40
  br label %bb15
bb15:
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t70 = load i64, ptr %l35, !tbaa !24
  %t71 = call i64 @__olang_fmt_i64(ptr null, i64 %t70)
  %t72 = add i64 %t69, %t71
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t76 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t68, i64 %t69)
  %t81 = getelementptr i8, ptr %t80, i64 %t69
  %t82 = call i64 @__olang_fmt_i64(ptr %t81, i64 %t70)
  %t83 = getelementptr i8, ptr %t81, i64 %t71
  call void @olang_textcopy(ptr %t83, ptr %t73, i64 %t74)
  %t84 = getelementptr i8, ptr %t83, i64 %t74
  call void @olang_textcopy(ptr %t84, ptr %t77, i64 %t78)
  %t85 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t80, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t94 = load ptr, ptr %l34, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t94, { i64, ptr } %t93)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2f605f8b851f9dfa_b0e742a1ba211956)
  unreachable
bb18:
  store i32 0, ptr %l7, !tbaa !23
  %t96 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t97 = getelementptr %"compiler/mir:Range", ptr %t96, i32 0, i32 1
  %t98 = load i32, ptr %t97, !tbaa !23
  store i32 %t98, ptr %l8, !tbaa !23
  store i32 1, ptr %l9, !tbaa !23
  %t100 = load i32, ptr %l8, !tbaa !23
  %t101 = load i32, ptr %l7, !tbaa !23
  %t104 = icmp sgt i32 %t100, %t101
  br i1 %t104, label %bb19, label %bb20
bb19:
  %t106 = load i32, ptr %l9, !tbaa !23
  %t108 = icmp sgt i32 %t106, 0
  br i1 %t108, label %bb21, label %bb22
bb20:
  store i32 0, ptr %l47, !tbaa !23
  br label %bb24
bb21:
  %t110 = load i32, ptr %l8, !tbaa !23
  %t111 = load i32, ptr %l7, !tbaa !23
  %t114 = sub i32 %t110, %t111
  %t115 = load i32, ptr %l9, !tbaa !23
  %t118 = add i32 %t114, %t115
  %t120 = sub i32 %t118, 1
  %t121 = load i32, ptr %l9, !tbaa !23
  %t124 = sdiv i32 %t120, %t121
  store i32 %t124, ptr %l50, !tbaa !23
  br label %bb23
bb22:
  store i32 0, ptr %l50, !tbaa !23
  br label %bb23
bb23:
  %t126 = load i32, ptr %l50, !tbaa !23
  store i32 %t126, ptr %l47, !tbaa !23
  br label %bb24
bb24:
  %t127 = load i32, ptr %l47, !tbaa !23
  store i32 %t127, ptr %l10, !tbaa !23
  store i32 0, ptr %l11, !tbaa !23
  br label %bb25
bb25:
  %t128 = load i32, ptr %l11, !tbaa !23
  %t129 = load i32, ptr %l10, !tbaa !23
  %t132 = icmp slt i32 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb26, label %bb27
bb26:
  br label %bb57
bb27:
  br label %bb28
bb28:
  %t136 = load i32, ptr %l7, !tbaa !23
  %t137 = load i32, ptr %l11, !tbaa !23
  %t138 = load i32, ptr %l9, !tbaa !23
  %t141 = mul i32 %t137, %t138
  %t144 = add i32 %t136, %t141
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/mir:dumper", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/mir:Fn", ptr %t149, i32 0, i32 10
  %t152 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t153 = getelementptr %"compiler/mir:Range", ptr %t152, i32 0, i32 0
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = sext i32 %t154 to i64
  %t159 = sext i32 %t144 to i64
  %t162 = add i64 %t156, %t159
  %t163 = load ptr, ptr @__olang_prog_scope
  %t166 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %t163, ptr %t151, i64 %t162)
  store { i64, [1 x i64] } %t166, ptr %l76
  br label %bb29
bb29:
  %t167 = load { i64, [1 x i64] }, ptr %l76
  store { i64, [1 x i64] } %t167, ptr %l13
  %t168 = load { i64, [1 x i64] }, ptr %l13
  %t170 = extractvalue { i64, [1 x i64] } %t168, 0
  %t171 = icmp eq i64 %t170, 0
  br i1 %t171, label %bb30, label %bb31
bb30:
  %t173 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t174 = getelementptr { i64 }, ptr %t173, i32 0, i32 0
  %t175 = load i64, ptr %t174
  store i64 %t175, ptr %l14, !tbaa !24
  br label %bb32
bb31:
  br label %bb34
bb32:
  store %olang.scope zeroinitializer, ptr %s8
  %t177 = load i64, ptr %l14, !tbaa !24
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t181 = call i64 @__olang_fmt_i64(ptr null, i64 %t177)
  %t182 = add i64 %t179, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t178, i64 %t179)
  %t184 = getelementptr i8, ptr %t183, i64 %t179
  %t185 = call i64 @__olang_fmt_i64(ptr %t184, i64 %t177)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t183, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = extractvalue { i64, ptr } %t187, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l2, { i64, ptr } %t194)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb34:
  %t197 = load { i64, [1 x i64] }, ptr %l13
  %t199 = extractvalue { i64, [1 x i64] } %t197, 0
  %t200 = icmp eq i64 %t199, 1
  br i1 %t200, label %bb35, label %bb36
bb35:
  %t202 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t203 = getelementptr { i32 }, ptr %t202, i32 0, i32 0
  %t204 = load i32, ptr %t203
  store i32 %t204, ptr %l15, !tbaa !23
  br label %bb37
bb36:
  br label %bb39
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t206 = load i32, ptr %l15, !tbaa !23
  %t207 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t210 = sext i32 %t206 to i64
  %t211 = call i64 @__olang_fmt_i64(ptr null, i64 %t210)
  %t212 = add i64 %t208, %t211
  %t213 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t216 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t215)
  call void @olang_textcopy(ptr %t216, ptr %t207, i64 %t208)
  %t217 = getelementptr i8, ptr %t216, i64 %t208
  %t218 = call i64 @__olang_fmt_i64(ptr %t217, i64 %t210)
  %t219 = getelementptr i8, ptr %t217, i64 %t211
  call void @olang_textcopy(ptr %t219, ptr %t213, i64 %t214)
  %t220 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t216, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = extractvalue { i64, ptr } %t221, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %l2, { i64, ptr } %t228)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb39:
  %t231 = load { i64, [1 x i64] }, ptr %l13
  %t233 = extractvalue { i64, [1 x i64] } %t231, 0
  %t234 = icmp eq i64 %t233, 2
  br i1 %t234, label %bb40, label %bb41
bb40:
  %t236 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t237 = getelementptr { i64 }, ptr %t236, i32 0, i32 0
  %t238 = load i64, ptr %t237
  store i64 %t238, ptr %l16, !tbaa !24
  br label %bb42
bb41:
  br label %bb44
bb42:
  store %olang.scope zeroinitializer, ptr %s12
  %t240 = load i64, ptr %l16, !tbaa !24
  %t241 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t244 = call i64 @__olang_fmt_i64(ptr null, i64 %t240)
  %t245 = add i64 %t242, %t244
  %t246 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t247 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t248 = add i64 %t245, %t247
  %t249 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t248)
  call void @olang_textcopy(ptr %t249, ptr %t241, i64 %t242)
  %t250 = getelementptr i8, ptr %t249, i64 %t242
  %t251 = call i64 @__olang_fmt_i64(ptr %t250, i64 %t240)
  %t252 = getelementptr i8, ptr %t250, i64 %t244
  call void @olang_textcopy(ptr %t252, ptr %t246, i64 %t247)
  %t253 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t249, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = extractvalue { i64, ptr } %t254, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } %t261)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s12)
  br label %bb55
bb44:
  %t264 = load { i64, [1 x i64] }, ptr %l13
  %t266 = extractvalue { i64, [1 x i64] } %t264, 0
  %t267 = icmp eq i64 %t266, 3
  br i1 %t267, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb49
bb47:
  store %olang.scope zeroinitializer, ptr %s14
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d78, i32 0, i32 1) })
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s14)
  br label %bb55
bb49:
  %t270 = load { i64, [1 x i64] }, ptr %l13
  %t272 = extractvalue { i64, [1 x i64] } %t270, 0
  %t273 = icmp eq i64 %t272, 4
  br i1 %t273, label %bb50, label %bb51
bb50:
  %t275 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t276 = getelementptr { i64 }, ptr %t275, i32 0, i32 0
  %t277 = load i64, ptr %t276
  store i64 %t277, ptr %l17, !tbaa !24
  br label %bb52
bb51:
  br label %bb54
bb52:
  store %olang.scope zeroinitializer, ptr %s15
  %t279 = load i64, ptr %l17, !tbaa !24
  %t280 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t283 = call i64 @__olang_fmt_i64(ptr null, i64 %t279)
  %t284 = add i64 %t281, %t283
  %t285 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t284)
  call void @olang_textcopy(ptr %t285, ptr %t280, i64 %t281)
  %t286 = getelementptr i8, ptr %t285, i64 %t281
  %t287 = call i64 @__olang_fmt_i64(ptr %t286, i64 %t279)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t285, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t292 = extractvalue { i64, ptr } %t289, 1
  %t293 = mul i64 %t291, 1
  %t294 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l2, { i64, ptr } %t296)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s15)
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_ddfec86899b5c27b_91be796056af7d77)
  unreachable
bb55:
  br label %bb56
bb56:
  %t299 = load i32, ptr %l11, !tbaa !23
  %t301 = add i32 %t299, 1
  store i32 %t301, ptr %l11, !tbaa !23
  br label %bb25
bb57:
  %t304 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t304, ptr %l111
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t305 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t305, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t14 = sext i32 %t10 to i64
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t14)
  %t16 = add i64 %t12, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = getelementptr i8, ptr %t17, i64 %t12
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  br label %bb21
bb4:
  %t23 = load { i64, [1 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [1 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 1
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t36 = call i64 @__olang_fmt_i64(ptr null, i64 %t32)
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = getelementptr i8, ptr %t38, i64 %t34
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t32)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t38, 1
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  br label %bb21
bb8:
  %t44 = load { i64, [1 x i64] }, ptr %l1
  %t46 = extractvalue { i64, [1 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 2
  br i1 %t47, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t49, ptr %l5, !tbaa !27
  br label %bb21
bb12:
  %t51 = load { i64, [1 x i64] }, ptr %l1
  %t53 = extractvalue { i64, [1 x i64] } %t51, 0
  %t54 = icmp eq i64 %t53, 3
  br i1 %t54, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t56, ptr %l5, !tbaa !27
  br label %bb21
bb16:
  %t58 = load { i64, [1 x i64] }, ptr %l1
  %t60 = extractvalue { i64, [1 x i64] } %t58, 0
  %t61 = icmp eq i64 %t60, 4
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t63 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { i32 }, ptr %t63, i32 0, i32 0
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l4, !tbaa !23
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t67 = load i32, ptr %l4, !tbaa !23
  %t68 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t71 = sext i32 %t67 to i64
  %t72 = call i64 @__olang_fmt_i64(ptr null, i64 %t71)
  %t73 = add i64 %t69, %t72
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = getelementptr i8, ptr %t77, i64 %t69
  %t79 = call i64 @__olang_fmt_i64(ptr %t78, i64 %t71)
  %t80 = getelementptr i8, ptr %t78, i64 %t72
  call void @olang_textcopy(ptr %t80, ptr %t74, i64 %t75)
  %t81 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t77, 1
  store { i64, ptr } %t82, ptr %l5, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_3c759898227385e0_43502750c3b6307c)
  unreachable
bb21:
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l29, !tbaa !24
  %t86 = load i64, ptr %l29, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l30, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l29, !tbaa !24
  %t96 = mul i64 %t95, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t92, ptr %t94, i64 %t96, i1 false)
  %t97 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t97, ptr %l5, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ervalue(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca %"compiler/mir:Lvalue"
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Lvalue"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Range"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Range"
  %l13 = alloca %"compiler/mir:Lvalue"
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca %"compiler/mir:Range"
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca i32
  %l20 = alloca { i64, [1 x i64] }
  %l21 = alloca i32
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca %"compiler/mir:Lvalue"
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca i32
  %l30 = alloca { i64, [1 x i64] }
  %l31 = alloca %"compiler/mir:Range"
  %l32 = alloca %"compiler/mir:Range"
  %l33 = alloca { i64, [4 x i64] }
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca { i64, [1 x i64] }
  %l37 = alloca { i64, [1 x i64] }
  %l38 = alloca i32
  %l39 = alloca { i64, [1 x i64] }
  %l40 = alloca { i64, [4 x i64] }
  %l41 = alloca { i64, [1 x i64] }
  %l42 = alloca i32
  %l45 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l75 = alloca i32
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l92 = alloca i32
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l269 = alloca i64
  %l270 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [15 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [15 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { { i64, [4 x i64] } }, ptr %t11, i32 0, i32 0
  %t13 = load { i64, [4 x i64] }, ptr %t12
  store { i64, [4 x i64] } %t13, ptr %l3
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [4 x i64] }, ptr %l3
  %t19 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %v1, ptr %t15, { i64, [4 x i64] } %t16)
  store { i64, ptr } %t19, ptr %l51
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t20, ptr %l45, !tbaa !27
  br label %bb116
bb5:
  %t21 = load { i64, [15 x i64] }, ptr %l1
  %t23 = extractvalue { i64, [15 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t27 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t26, i32 0, i32 0
  %t28 = load %"compiler/mir:Lvalue", ptr %t27
  store %"compiler/mir:Lvalue" %t28, ptr %l4
  %t30 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t31 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t30, i32 0, i32 1
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb11
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/mir:Lvalue", ptr %l4
  %t38 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s2, ptr %t34, %"compiler/mir:Lvalue" %t35)
  store { i64, ptr } %t38, ptr %l58
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t40 = load i32, ptr %l5, !tbaa !23
  %t41 = load ptr, ptr @__olang_prog_scope
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t41, ptr %s2, ptr %t39, i32 %t40)
  store { i64, ptr } %t44, ptr %l61
  br label %bb10
bb10:
  %t45 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t47 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = add i64 %t46, %t49
  %t51 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = add i64 %t53, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t45, i64 %t46)
  %t59 = getelementptr i8, ptr %t58, i64 %t46
  call void @olang_textcopy(ptr %t59, ptr %t48, i64 %t49)
  %t60 = getelementptr i8, ptr %t59, i64 %t49
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t55, i64 %t56)
  %t62 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t58, 1
  store { i64, ptr } %t63, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb116
bb11:
  %t65 = load { i64, [15 x i64] }, ptr %l1
  %t67 = extractvalue { i64, [15 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 2
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t71 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t70, i32 0, i32 0
  %t72 = load %"compiler/mir:Lvalue", ptr %t71
  store %"compiler/mir:Lvalue" %t72, ptr %l6
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/mir:Lvalue", ptr %l6
  %t78 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s4, ptr %t74, %"compiler/mir:Lvalue" %t75)
  store { i64, ptr } %t78, ptr %l68
  br label %bb15
bb15:
  %t79 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t81 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = add i64 %t80, %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t79, i64 %t80)
  %t86 = getelementptr i8, ptr %t85, i64 %t80
  call void @olang_textcopy(ptr %t86, ptr %t82, i64 %t83)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t85, 1
  store { i64, ptr } %t88, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb116
bb16:
  %t90 = load { i64, [15 x i64] }, ptr %l1
  %t92 = extractvalue { i64, [15 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 3
  br i1 %t93, label %bb17, label %bb18
bb17:
  %t95 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t96 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t95, i32 0, i32 0
  %t97 = load i32, ptr %t96, !range !{i32 0, i32 49}
  store i32 %t97, ptr %l7
  %t99 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100
  store i32 %t101, ptr %l8, !tbaa !23
  %t103 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t104 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t103, i32 0, i32 2
  %t105 = load %"compiler/mir:Range", ptr %t104
  store %"compiler/mir:Range" %t105, ptr %l9
  br label %bb19
bb18:
  br label %bb24
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load i32, ptr %l7, !range !{i32 0, i32 49}
  store i32 %t107, ptr %l75
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s7, ptr %l75, i64 0)
  br label %bb20
bb20:
  %t109 = load ptr, ptr %s7
  %t110 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t111 = load i64, ptr %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t109, i64 %t111)
  %t113 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l77, !tbaa !27
  %t115 = getelementptr %olang.builder, ptr %s7, i32 0, i32 3
  %t116 = load ptr, ptr %t115
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %sbgrew.118, label %sbdone.119
sbgrew.118:
  call void @__olang_sb_done(ptr %s7)
  br label %sbdone.119
sbdone.119:
  %t120 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s6, ptr %s6, { i64, ptr } %t126)
  store { i64, ptr } %t128, ptr %l79
  br label %bb21
bb21:
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t130 = load i32, ptr %l8, !tbaa !23
  %t131 = load ptr, ptr @__olang_prog_scope
  %t134 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t131, ptr %s6, ptr %t129, i32 %t130)
  store { i64, ptr } %t134, ptr %l82
  br label %bb22
bb22:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/mir:Range", ptr %l9
  %t139 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s6, ptr %t135, %"compiler/mir:Range" %t136)
  store { i64, ptr } %t139, ptr %l85
  br label %bb23
bb23:
  %t140 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t146 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = add i64 %t145, %t148
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t151 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t152 = add i64 %t149, %t151
  %t153 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = add i64 %t152, %t155
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t159 = add i64 %t156, %t158
  %t160 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t159)
  call void @olang_textcopy(ptr %t160, ptr %t141, i64 %t142)
  %t161 = getelementptr i8, ptr %t160, i64 %t142
  call void @olang_textcopy(ptr %t161, ptr %t143, i64 %t144)
  %t162 = getelementptr i8, ptr %t161, i64 %t144
  call void @olang_textcopy(ptr %t162, ptr %t147, i64 %t148)
  %t163 = getelementptr i8, ptr %t162, i64 %t148
  call void @olang_textcopy(ptr %t163, ptr %t150, i64 %t151)
  %t164 = getelementptr i8, ptr %t163, i64 %t151
  call void @olang_textcopy(ptr %t164, ptr %t154, i64 %t155)
  %t165 = getelementptr i8, ptr %t164, i64 %t155
  call void @olang_textcopy(ptr %t165, ptr %t157, i64 %t158)
  %t166 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t160, 1
  store { i64, ptr } %t167, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb116
bb24:
  %t169 = load { i64, [15 x i64] }, ptr %l1
  %t171 = extractvalue { i64, [15 x i64] } %t169, 0
  %t172 = icmp eq i64 %t171, 4
  br i1 %t172, label %bb25, label %bb26
bb25:
  %t174 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t175 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t174, i32 0, i32 0
  %t176 = load i32, ptr %t175, !range !{i32 0, i32 49}
  store i32 %t176, ptr %l10
  %t178 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t179 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t178, i32 0, i32 1
  %t180 = load i32, ptr %t179
  store i32 %t180, ptr %l11, !tbaa !23
  %t182 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t183 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t182, i32 0, i32 2
  %t184 = load %"compiler/mir:Range", ptr %t183
  store %"compiler/mir:Range" %t184, ptr %l12
  br label %bb27
bb26:
  br label %bb32
bb27:
  store %olang.scope zeroinitializer, ptr %s9
  %t186 = load i32, ptr %l10, !range !{i32 0, i32 49}
  store i32 %t186, ptr %l92
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s10, ptr %l92, i64 0)
  br label %bb28
bb28:
  %t188 = load ptr, ptr %s10
  %t189 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t190 = load i64, ptr %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t188, i64 %t190)
  %t192 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  store { i64, ptr } %t193, ptr %l94, !tbaa !27
  %t194 = getelementptr %olang.builder, ptr %s10, i32 0, i32 3
  %t195 = load ptr, ptr %t194
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %sbgrew.197, label %sbdone.198
sbgrew.197:
  call void @__olang_sb_done(ptr %s10)
  br label %sbdone.198
sbdone.198:
  %t199 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  %t202 = mul i64 %t200, 1
  %t203 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t202)
  call void @llvm.memcpy.p0.p0.i64(ptr %t203, ptr %t201, i64 %t202, i1 false)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  %t207 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s9, ptr %s9, { i64, ptr } %t205)
  store { i64, ptr } %t207, ptr %l96
  br label %bb29
bb29:
  %t208 = load ptr, ptr %l2, !tbaa !29
  %t209 = load i32, ptr %l11, !tbaa !23
  %t210 = load ptr, ptr @__olang_prog_scope
  %t213 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t210, ptr %s9, ptr %t208, i32 %t209)
  store { i64, ptr } %t213, ptr %l99
  br label %bb30
bb30:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load %"compiler/mir:Range", ptr %l12
  %t218 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s9, ptr %t214, %"compiler/mir:Range" %t215)
  store { i64, ptr } %t218, ptr %l102
  br label %bb31
bb31:
  %t219 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t221 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = add i64 %t220, %t223
  %t225 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t228 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 1
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t231 = add i64 %t227, %t230
  %t232 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t234 = add i64 %t231, %t233
  %t235 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = add i64 %t234, %t237
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t241 = add i64 %t238, %t240
  %t242 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t241)
  call void @olang_textcopy(ptr %t242, ptr %t219, i64 %t220)
  %t243 = getelementptr i8, ptr %t242, i64 %t220
  call void @olang_textcopy(ptr %t243, ptr %t222, i64 %t223)
  %t244 = getelementptr i8, ptr %t243, i64 %t223
  call void @olang_textcopy(ptr %t244, ptr %t225, i64 %t226)
  %t245 = getelementptr i8, ptr %t244, i64 %t226
  call void @olang_textcopy(ptr %t245, ptr %t229, i64 %t230)
  %t246 = getelementptr i8, ptr %t245, i64 %t230
  call void @olang_textcopy(ptr %t246, ptr %t232, i64 %t233)
  %t247 = getelementptr i8, ptr %t246, i64 %t233
  call void @olang_textcopy(ptr %t247, ptr %t236, i64 %t237)
  %t248 = getelementptr i8, ptr %t247, i64 %t237
  call void @olang_textcopy(ptr %t248, ptr %t239, i64 %t240)
  %t249 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t242, 1
  store { i64, ptr } %t250, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb116
bb32:
  %t252 = load { i64, [15 x i64] }, ptr %l1
  %t254 = extractvalue { i64, [15 x i64] } %t252, 0
  %t255 = icmp eq i64 %t254, 5
  br i1 %t255, label %bb33, label %bb34
bb33:
  %t257 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t258 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t257, i32 0, i32 0
  %t259 = load %"compiler/mir:Lvalue", ptr %t258
  store %"compiler/mir:Lvalue" %t259, ptr %l13
  br label %bb35
bb34:
  br label %bb37
bb35:
  store %olang.scope zeroinitializer, ptr %s12
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load %"compiler/mir:Lvalue", ptr %l13
  %t265 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s12, ptr %t261, %"compiler/mir:Lvalue" %t262)
  store { i64, ptr } %t265, ptr %l109
  br label %bb36
bb36:
  %t266 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t268 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = add i64 %t267, %t270
  %t272 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t271)
  call void @olang_textcopy(ptr %t272, ptr %t266, i64 %t267)
  %t273 = getelementptr i8, ptr %t272, i64 %t267
  call void @olang_textcopy(ptr %t273, ptr %t269, i64 %t270)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t272, 1
  store { i64, ptr } %t275, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb116
bb37:
  %t277 = load { i64, [15 x i64] }, ptr %l1
  %t279 = extractvalue { i64, [15 x i64] } %t277, 0
  %t280 = icmp eq i64 %t279, 6
  br i1 %t280, label %bb38, label %bb39
bb38:
  %t282 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t283 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t282, i32 0, i32 0
  %t284 = load i32, ptr %t283
  store i32 %t284, ptr %l14, !tbaa !23
  %t286 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t287 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t286, i32 0, i32 1
  %t288 = load i64, ptr %t287
  store i64 %t288, ptr %l15, !tbaa !24
  %t290 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t291 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t290, i32 0, i32 2
  %t292 = load %"compiler/mir:Range", ptr %t291
  store %"compiler/mir:Range" %t292, ptr %l16
  br label %bb40
bb39:
  br label %bb46
bb40:
  store %olang.scope zeroinitializer, ptr %s14
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t295 = load i32, ptr %l14, !tbaa !23
  %t296 = load ptr, ptr @__olang_prog_scope
  %t299 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t296, ptr %s14, ptr %t294, i32 %t295)
  store { i64, ptr } %t299, ptr %l118
  br label %bb41
bb41:
  %t300 = load i64, ptr %l15, !tbaa !24
  %t302 = icmp sgt i64 %t300, 0
  br i1 %t302, label %bb42, label %bb43
bb42:
  %t304 = load i64, ptr %l15, !tbaa !24
  %t305 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t308 = call i64 @__olang_fmt_i64(ptr null, i64 %t304)
  %t309 = add i64 %t306, %t308
  %t310 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t309)
  call void @olang_textcopy(ptr %t310, ptr %t305, i64 %t306)
  %t311 = getelementptr i8, ptr %t310, i64 %t306
  %t312 = call i64 @__olang_fmt_i64(ptr %t311, i64 %t304)
  %t313 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t310, 1
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t317 = extractvalue { i64, ptr } %t314, 1
  %t318 = mul i64 %t316, 1
  %t319 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t318)
  call void @llvm.memcpy.p0.p0.i64(ptr %t319, ptr %t317, i64 %t318, i1 false)
  %t320 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  store { i64, ptr } %t321, ptr %l121, !tbaa !27
  br label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l121, !tbaa !27
  br label %bb44
bb44:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load %"compiler/mir:Range", ptr %l16
  %t327 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s14, ptr %t323, %"compiler/mir:Range" %t324)
  store { i64, ptr } %t327, ptr %l127
  br label %bb45
bb45:
  %t328 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t329 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t330 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 1
  %t332 = extractvalue { i64, ptr } %t330, 0
  %t333 = add i64 %t329, %t332
  %t334 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 1
  %t336 = extractvalue { i64, ptr } %t334, 0
  %t337 = add i64 %t333, %t336
  %t338 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t340 = add i64 %t337, %t339
  %t341 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 1
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t344 = add i64 %t340, %t343
  %t345 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t346 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t347 = add i64 %t344, %t346
  %t348 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t347)
  call void @olang_textcopy(ptr %t348, ptr %t328, i64 %t329)
  %t349 = getelementptr i8, ptr %t348, i64 %t329
  call void @olang_textcopy(ptr %t349, ptr %t331, i64 %t332)
  %t350 = getelementptr i8, ptr %t349, i64 %t332
  call void @olang_textcopy(ptr %t350, ptr %t335, i64 %t336)
  %t351 = getelementptr i8, ptr %t350, i64 %t336
  call void @olang_textcopy(ptr %t351, ptr %t338, i64 %t339)
  %t352 = getelementptr i8, ptr %t351, i64 %t339
  call void @olang_textcopy(ptr %t352, ptr %t342, i64 %t343)
  %t353 = getelementptr i8, ptr %t352, i64 %t343
  call void @olang_textcopy(ptr %t353, ptr %t345, i64 %t346)
  %t354 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t348, 1
  store { i64, ptr } %t355, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb116
bb46:
  %t357 = load { i64, [15 x i64] }, ptr %l1
  %t359 = extractvalue { i64, [15 x i64] } %t357, 0
  %t360 = icmp eq i64 %t359, 7
  br i1 %t360, label %bb47, label %bb48
bb47:
  %t362 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t363 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t362, i32 0, i32 0
  %t364 = load { i64, [1 x i64] }, ptr %t363
  store { i64, [1 x i64] } %t364, ptr %l17
  %t366 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t367 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t366, i32 0, i32 1
  %t368 = load { i64, [4 x i64] }, ptr %t367
  store { i64, [4 x i64] } %t368, ptr %l18
  %t370 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t371 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t370, i32 0, i32 2
  %t372 = load i32, ptr %t371
  store i32 %t372, ptr %l19, !tbaa !23
  br label %bb49
bb48:
  br label %bb53
bb49:
  store %olang.scope zeroinitializer, ptr %s17
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load { i64, [1 x i64] }, ptr %l17
  %t378 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s17, ptr %t374, { i64, [1 x i64] } %t375)
  store { i64, ptr } %t378, ptr %l136
  br label %bb50
bb50:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load { i64, [4 x i64] }, ptr %l18
  %t383 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s17, ptr %t379, { i64, [4 x i64] } %t380)
  store { i64, ptr } %t383, ptr %l139
  br label %bb51
bb51:
  %t384 = load ptr, ptr %l2, !tbaa !29
  %t385 = load i32, ptr %l19, !tbaa !23
  %t386 = load ptr, ptr @__olang_prog_scope
  %t389 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t386, ptr %s17, ptr %t384, i32 %t385)
  store { i64, ptr } %t389, ptr %l142
  br label %bb52
bb52:
  %t390 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t391 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t392 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = add i64 %t391, %t394
  %t396 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t397 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t398 = add i64 %t395, %t397
  %t399 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t400 = extractvalue { i64, ptr } %t399, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = add i64 %t398, %t401
  %t403 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t405 = add i64 %t402, %t404
  %t406 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 1
  %t408 = extractvalue { i64, ptr } %t406, 0
  %t409 = add i64 %t405, %t408
  %t410 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t409)
  call void @olang_textcopy(ptr %t410, ptr %t390, i64 %t391)
  %t411 = getelementptr i8, ptr %t410, i64 %t391
  call void @olang_textcopy(ptr %t411, ptr %t393, i64 %t394)
  %t412 = getelementptr i8, ptr %t411, i64 %t394
  call void @olang_textcopy(ptr %t412, ptr %t396, i64 %t397)
  %t413 = getelementptr i8, ptr %t412, i64 %t397
  call void @olang_textcopy(ptr %t413, ptr %t400, i64 %t401)
  %t414 = getelementptr i8, ptr %t413, i64 %t401
  call void @olang_textcopy(ptr %t414, ptr %t403, i64 %t404)
  %t415 = getelementptr i8, ptr %t414, i64 %t404
  call void @olang_textcopy(ptr %t415, ptr %t407, i64 %t408)
  %t416 = insertvalue { i64, ptr } undef, i64 %t409, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t410, 1
  store { i64, ptr } %t417, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb116
bb53:
  %t419 = load { i64, [15 x i64] }, ptr %l1
  %t421 = extractvalue { i64, [15 x i64] } %t419, 0
  %t422 = icmp eq i64 %t421, 8
  br i1 %t422, label %bb54, label %bb55
bb54:
  %t424 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t425 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t424, i32 0, i32 0
  %t426 = load { i64, [1 x i64] }, ptr %t425
  store { i64, [1 x i64] } %t426, ptr %l20
  %t428 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t429 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t428, i32 0, i32 1
  %t430 = load i32, ptr %t429
  store i32 %t430, ptr %l21, !tbaa !23
  %t432 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t433 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t432, i32 0, i32 2
  %t434 = load { i64, [4 x i64] }, ptr %t433
  store { i64, [4 x i64] } %t434, ptr %l22
  %t436 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t437 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t436, i32 0, i32 3
  %t438 = load { i64, [4 x i64] }, ptr %t437
  store { i64, [4 x i64] } %t438, ptr %l23
  br label %bb56
bb55:
  br label %bb61
bb56:
  store %olang.scope zeroinitializer, ptr %s19
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load { i64, [1 x i64] }, ptr %l20
  %t444 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s19, ptr %t440, { i64, [1 x i64] } %t441)
  store { i64, ptr } %t444, ptr %l152
  br label %bb57
bb57:
  %t445 = load ptr, ptr %l2, !tbaa !29
  %t446 = load i32, ptr %l21, !tbaa !23
  %t447 = load ptr, ptr @__olang_prog_scope
  %t450 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t447, ptr %s19, ptr %t445, i32 %t446)
  store { i64, ptr } %t450, ptr %l155
  br label %bb58
bb58:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load { i64, [4 x i64] }, ptr %l22
  %t455 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s19, ptr %t451, { i64, [4 x i64] } %t452)
  store { i64, ptr } %t455, ptr %l158
  br label %bb59
bb59:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load { i64, [4 x i64] }, ptr %l23
  %t460 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s19, ptr %t456, { i64, [4 x i64] } %t457)
  store { i64, ptr } %t460, ptr %l161
  br label %bb60
bb60:
  %t461 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t463 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t463, 1
  %t465 = extractvalue { i64, ptr } %t463, 0
  %t466 = add i64 %t462, %t465
  %t467 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t468 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t469 = add i64 %t466, %t468
  %t470 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t471 = extractvalue { i64, ptr } %t470, 1
  %t472 = extractvalue { i64, ptr } %t470, 0
  %t473 = add i64 %t469, %t472
  %t474 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t475 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t476 = add i64 %t473, %t475
  %t477 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t477, 1
  %t479 = extractvalue { i64, ptr } %t477, 0
  %t480 = add i64 %t476, %t479
  %t481 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t482 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t483 = add i64 %t480, %t482
  %t484 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t484, 1
  %t486 = extractvalue { i64, ptr } %t484, 0
  %t487 = add i64 %t483, %t486
  %t488 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t489 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t490 = add i64 %t487, %t489
  %t491 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t490)
  call void @olang_textcopy(ptr %t491, ptr %t461, i64 %t462)
  %t492 = getelementptr i8, ptr %t491, i64 %t462
  call void @olang_textcopy(ptr %t492, ptr %t464, i64 %t465)
  %t493 = getelementptr i8, ptr %t492, i64 %t465
  call void @olang_textcopy(ptr %t493, ptr %t467, i64 %t468)
  %t494 = getelementptr i8, ptr %t493, i64 %t468
  call void @olang_textcopy(ptr %t494, ptr %t471, i64 %t472)
  %t495 = getelementptr i8, ptr %t494, i64 %t472
  call void @olang_textcopy(ptr %t495, ptr %t474, i64 %t475)
  %t496 = getelementptr i8, ptr %t495, i64 %t475
  call void @olang_textcopy(ptr %t496, ptr %t478, i64 %t479)
  %t497 = getelementptr i8, ptr %t496, i64 %t479
  call void @olang_textcopy(ptr %t497, ptr %t481, i64 %t482)
  %t498 = getelementptr i8, ptr %t497, i64 %t482
  call void @olang_textcopy(ptr %t498, ptr %t485, i64 %t486)
  %t499 = getelementptr i8, ptr %t498, i64 %t486
  call void @olang_textcopy(ptr %t499, ptr %t488, i64 %t489)
  %t500 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t491, 1
  store { i64, ptr } %t501, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb116
bb61:
  %t503 = load { i64, [15 x i64] }, ptr %l1
  %t505 = extractvalue { i64, [15 x i64] } %t503, 0
  %t506 = icmp eq i64 %t505, 9
  br i1 %t506, label %bb62, label %bb63
bb62:
  %t508 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t509 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t508, i32 0, i32 0
  %t510 = load %"compiler/mir:Lvalue", ptr %t509
  store %"compiler/mir:Lvalue" %t510, ptr %l24
  %t512 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t513 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t512, i32 0, i32 1
  %t514 = load { i64, [4 x i64] }, ptr %t513
  store { i64, [4 x i64] } %t514, ptr %l25
  %t516 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t517 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t516, i32 0, i32 2
  %t518 = load { i64, [4 x i64] }, ptr %t517
  store { i64, [4 x i64] } %t518, ptr %l26
  %t520 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t521 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t520, i32 0, i32 3
  %t522 = load i32, ptr %t521
  store i32 %t522, ptr %l27, !tbaa !23
  br label %bb64
bb63:
  br label %bb69
bb64:
  store %olang.scope zeroinitializer, ptr %s21
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load %"compiler/mir:Lvalue", ptr %l24
  %t528 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s21, ptr %t524, %"compiler/mir:Lvalue" %t525)
  store { i64, ptr } %t528, ptr %l171
  br label %bb65
bb65:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load { i64, [4 x i64] }, ptr %l25
  %t533 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s21, ptr %t529, { i64, [4 x i64] } %t530)
  store { i64, ptr } %t533, ptr %l174
  br label %bb66
bb66:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t535 = load { i64, [4 x i64] }, ptr %l26
  %t538 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s21, ptr %t534, { i64, [4 x i64] } %t535)
  store { i64, ptr } %t538, ptr %l177
  br label %bb67
bb67:
  %t539 = load ptr, ptr %l2, !tbaa !29
  %t540 = load i32, ptr %l27, !tbaa !23
  %t541 = load ptr, ptr @__olang_prog_scope
  %t544 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t541, ptr %s21, ptr %t539, i32 %t540)
  store { i64, ptr } %t544, ptr %l180
  br label %bb68
bb68:
  %t545 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t546 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t547 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t547, 1
  %t549 = extractvalue { i64, ptr } %t547, 0
  %t550 = add i64 %t546, %t549
  %t551 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t552 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t553 = add i64 %t550, %t552
  %t554 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t554, 1
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t557 = add i64 %t553, %t556
  %t558 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t560 = add i64 %t557, %t559
  %t561 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t562 = extractvalue { i64, ptr } %t561, 1
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t564 = add i64 %t560, %t563
  %t565 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t566 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t567 = add i64 %t564, %t566
  %t568 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 1
  %t570 = extractvalue { i64, ptr } %t568, 0
  %t571 = add i64 %t567, %t570
  %t572 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t571)
  call void @olang_textcopy(ptr %t572, ptr %t545, i64 %t546)
  %t573 = getelementptr i8, ptr %t572, i64 %t546
  call void @olang_textcopy(ptr %t573, ptr %t548, i64 %t549)
  %t574 = getelementptr i8, ptr %t573, i64 %t549
  call void @olang_textcopy(ptr %t574, ptr %t551, i64 %t552)
  %t575 = getelementptr i8, ptr %t574, i64 %t552
  call void @olang_textcopy(ptr %t575, ptr %t555, i64 %t556)
  %t576 = getelementptr i8, ptr %t575, i64 %t556
  call void @olang_textcopy(ptr %t576, ptr %t558, i64 %t559)
  %t577 = getelementptr i8, ptr %t576, i64 %t559
  call void @olang_textcopy(ptr %t577, ptr %t562, i64 %t563)
  %t578 = getelementptr i8, ptr %t577, i64 %t563
  call void @olang_textcopy(ptr %t578, ptr %t565, i64 %t566)
  %t579 = getelementptr i8, ptr %t578, i64 %t566
  call void @olang_textcopy(ptr %t579, ptr %t569, i64 %t570)
  %t580 = insertvalue { i64, ptr } undef, i64 %t571, 0
  %t581 = insertvalue { i64, ptr } %t580, ptr %t572, 1
  store { i64, ptr } %t581, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s21)
  br label %bb116
bb69:
  %t583 = load { i64, [15 x i64] }, ptr %l1
  %t585 = extractvalue { i64, [15 x i64] } %t583, 0
  %t586 = icmp eq i64 %t585, 10
  br i1 %t586, label %bb70, label %bb71
bb70:
  %t588 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t589 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t588, i32 0, i32 0
  %t590 = load { i64, [2 x i64] }, ptr %t589
  store { i64, [2 x i64] } %t590, ptr %l28
  %t592 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t593 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t592, i32 0, i32 1
  %t594 = load i32, ptr %t593
  store i32 %t594, ptr %l29, !tbaa !23
  %t596 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t597 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t596, i32 0, i32 2
  %t598 = load { i64, [1 x i64] }, ptr %t597
  store { i64, [1 x i64] } %t598, ptr %l30
  %t600 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t601 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t600, i32 0, i32 3
  %t602 = load %"compiler/mir:Range", ptr %t601
  store %"compiler/mir:Range" %t602, ptr %l31
  %t604 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t605 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t604, i32 0, i32 4
  %t606 = load %"compiler/mir:Range", ptr %t605
  store %"compiler/mir:Range" %t606, ptr %l32
  br label %bb72
bb71:
  br label %bb81
bb72:
  store %olang.scope zeroinitializer, ptr %s23
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t609 = load { i64, [2 x i64] }, ptr %l28
  %t612 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %s23, ptr %t608, { i64, [2 x i64] } %t609)
  store { i64, ptr } %t612, ptr %l191
  br label %bb73
bb73:
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t614 = load { i64, [1 x i64] }, ptr %l30
  %t617 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s23, ptr %t613, { i64, [1 x i64] } %t614)
  store { i64, ptr } %t617, ptr %l194
  br label %bb74
bb74:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t619 = load %"compiler/mir:Range", ptr %l31
  %t622 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s23, ptr %t618, %"compiler/mir:Range" %t619)
  store { i64, ptr } %t622, ptr %l197
  br label %bb75
bb75:
  %t623 = getelementptr %"compiler/mir:Range", ptr %l32, i32 0, i32 1
  %t624 = load i32, ptr %t623, !tbaa !23
  %t626 = icmp sgt i32 %t624, 0
  br i1 %t626, label %bb76, label %bb77
bb76:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load %"compiler/mir:Range", ptr %l32
  %t632 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s23, ptr %t628, %"compiler/mir:Range" %t629)
  store { i64, ptr } %t632, ptr %l203
  br label %bb78
bb77:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %l200, !tbaa !27
  br label %bb79
bb78:
  %t633 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t634 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t635 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t636 = extractvalue { i64, ptr } %t635, 1
  %t637 = extractvalue { i64, ptr } %t635, 0
  %t638 = add i64 %t634, %t637
  %t639 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t638)
  call void @olang_textcopy(ptr %t639, ptr %t633, i64 %t634)
  %t640 = getelementptr i8, ptr %t639, i64 %t634
  call void @olang_textcopy(ptr %t640, ptr %t636, i64 %t637)
  %t641 = insertvalue { i64, ptr } undef, i64 %t638, 0
  %t642 = insertvalue { i64, ptr } %t641, ptr %t639, 1
  %t644 = extractvalue { i64, ptr } %t642, 0
  %t645 = extractvalue { i64, ptr } %t642, 1
  %t646 = mul i64 %t644, 1
  %t647 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t646)
  call void @llvm.memcpy.p0.p0.i64(ptr %t647, ptr %t645, i64 %t646, i1 false)
  %t648 = insertvalue { i64, ptr } undef, i64 %t644, 0
  %t649 = insertvalue { i64, ptr } %t648, ptr %t647, 1
  store { i64, ptr } %t649, ptr %l200, !tbaa !27
  br label %bb79
bb79:
  %t651 = load ptr, ptr %l2, !tbaa !29
  %t652 = load i32, ptr %l29, !tbaa !23
  %t653 = load ptr, ptr @__olang_prog_scope
  %t656 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t653, ptr %s23, ptr %t651, i32 %t652)
  store { i64, ptr } %t656, ptr %l208
  br label %bb80
bb80:
  %t657 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t658 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t659 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t660 = extractvalue { i64, ptr } %t659, 1
  %t661 = extractvalue { i64, ptr } %t659, 0
  %t662 = add i64 %t658, %t661
  %t663 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t664 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t665 = add i64 %t662, %t664
  %t666 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t667 = extractvalue { i64, ptr } %t666, 1
  %t668 = extractvalue { i64, ptr } %t666, 0
  %t669 = add i64 %t665, %t668
  %t670 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t671 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t672 = add i64 %t669, %t671
  %t673 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t674 = extractvalue { i64, ptr } %t673, 1
  %t675 = extractvalue { i64, ptr } %t673, 0
  %t676 = add i64 %t672, %t675
  %t677 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t678 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t679 = add i64 %t676, %t678
  %t680 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t681 = extractvalue { i64, ptr } %t680, 1
  %t682 = extractvalue { i64, ptr } %t680, 0
  %t683 = add i64 %t679, %t682
  %t684 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t685 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t686 = add i64 %t683, %t685
  %t687 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t688 = extractvalue { i64, ptr } %t687, 1
  %t689 = extractvalue { i64, ptr } %t687, 0
  %t690 = add i64 %t686, %t689
  %t691 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t690)
  call void @olang_textcopy(ptr %t691, ptr %t657, i64 %t658)
  %t692 = getelementptr i8, ptr %t691, i64 %t658
  call void @olang_textcopy(ptr %t692, ptr %t660, i64 %t661)
  %t693 = getelementptr i8, ptr %t692, i64 %t661
  call void @olang_textcopy(ptr %t693, ptr %t663, i64 %t664)
  %t694 = getelementptr i8, ptr %t693, i64 %t664
  call void @olang_textcopy(ptr %t694, ptr %t667, i64 %t668)
  %t695 = getelementptr i8, ptr %t694, i64 %t668
  call void @olang_textcopy(ptr %t695, ptr %t670, i64 %t671)
  %t696 = getelementptr i8, ptr %t695, i64 %t671
  call void @olang_textcopy(ptr %t696, ptr %t674, i64 %t675)
  %t697 = getelementptr i8, ptr %t696, i64 %t675
  call void @olang_textcopy(ptr %t697, ptr %t677, i64 %t678)
  %t698 = getelementptr i8, ptr %t697, i64 %t678
  call void @olang_textcopy(ptr %t698, ptr %t681, i64 %t682)
  %t699 = getelementptr i8, ptr %t698, i64 %t682
  call void @olang_textcopy(ptr %t699, ptr %t684, i64 %t685)
  %t700 = getelementptr i8, ptr %t699, i64 %t685
  call void @olang_textcopy(ptr %t700, ptr %t688, i64 %t689)
  %t701 = insertvalue { i64, ptr } undef, i64 %t690, 0
  %t702 = insertvalue { i64, ptr } %t701, ptr %t691, 1
  store { i64, ptr } %t702, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s23)
  br label %bb116
bb81:
  %t704 = load { i64, [15 x i64] }, ptr %l1
  %t706 = extractvalue { i64, [15 x i64] } %t704, 0
  %t707 = icmp eq i64 %t706, 11
  br i1 %t707, label %bb82, label %bb83
bb82:
  %t709 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t710 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t709, i32 0, i32 0
  %t711 = load { i64, [4 x i64] }, ptr %t710
  store { i64, [4 x i64] } %t711, ptr %l33
  %t713 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t714 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t713, i32 0, i32 1
  %t715 = load i32, ptr %t714
  store i32 %t715, ptr %l34, !tbaa !23
  %t717 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t718 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t717, i32 0, i32 2
  %t719 = load i32, ptr %t718
  store i32 %t719, ptr %l35, !tbaa !23
  br label %bb84
bb83:
  br label %bb88
bb84:
  store %olang.scope zeroinitializer, ptr %s26
  %t721 = load ptr, ptr %l0, !tbaa !29
  %t722 = load { i64, [4 x i64] }, ptr %l33
  %t725 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s26, ptr %t721, { i64, [4 x i64] } %t722)
  store { i64, ptr } %t725, ptr %l217
  br label %bb85
bb85:
  %t726 = load ptr, ptr %l0, !tbaa !29
  %t727 = load i32, ptr %l34, !tbaa !23
  %t730 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %s26, ptr %t726, i32 %t727)
  store { i64, ptr } %t730, ptr %l220
  br label %bb86
bb86:
  %t731 = load ptr, ptr %l0, !tbaa !29
  %t732 = load i32, ptr %l35, !tbaa !23
  %t735 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %s26, ptr %t731, i32 %t732)
  store { i64, ptr } %t735, ptr %l223
  br label %bb87
bb87:
  %t736 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t737 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t738 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t739 = extractvalue { i64, ptr } %t738, 1
  %t740 = extractvalue { i64, ptr } %t738, 0
  %t741 = add i64 %t737, %t740
  %t742 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t743 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t744 = add i64 %t741, %t743
  %t745 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t746 = extractvalue { i64, ptr } %t745, 1
  %t747 = extractvalue { i64, ptr } %t745, 0
  %t748 = add i64 %t744, %t747
  %t749 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t750 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t751 = add i64 %t748, %t750
  %t752 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t753 = extractvalue { i64, ptr } %t752, 1
  %t754 = extractvalue { i64, ptr } %t752, 0
  %t755 = add i64 %t751, %t754
  %t756 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t755)
  call void @olang_textcopy(ptr %t756, ptr %t736, i64 %t737)
  %t757 = getelementptr i8, ptr %t756, i64 %t737
  call void @olang_textcopy(ptr %t757, ptr %t739, i64 %t740)
  %t758 = getelementptr i8, ptr %t757, i64 %t740
  call void @olang_textcopy(ptr %t758, ptr %t742, i64 %t743)
  %t759 = getelementptr i8, ptr %t758, i64 %t743
  call void @olang_textcopy(ptr %t759, ptr %t746, i64 %t747)
  %t760 = getelementptr i8, ptr %t759, i64 %t747
  call void @olang_textcopy(ptr %t760, ptr %t749, i64 %t750)
  %t761 = getelementptr i8, ptr %t760, i64 %t750
  call void @olang_textcopy(ptr %t761, ptr %t753, i64 %t754)
  %t762 = insertvalue { i64, ptr } undef, i64 %t755, 0
  %t763 = insertvalue { i64, ptr } %t762, ptr %t756, 1
  store { i64, ptr } %t763, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s26)
  br label %bb116
bb88:
  %t765 = load { i64, [15 x i64] }, ptr %l1
  %t767 = extractvalue { i64, [15 x i64] } %t765, 0
  %t768 = icmp eq i64 %t767, 12
  br i1 %t768, label %bb89, label %bb90
bb89:
  %t770 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t771 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t770, i32 0, i32 0
  %t772 = load { i64, [1 x i64] }, ptr %t771
  store { i64, [1 x i64] } %t772, ptr %l36
  %t774 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t775 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t774, i32 0, i32 1
  %t776 = load { i64, [1 x i64] }, ptr %t775
  store { i64, [1 x i64] } %t776, ptr %l37
  %t778 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t779 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t778, i32 0, i32 2
  %t780 = load i32, ptr %t779
  store i32 %t780, ptr %l38, !tbaa !23
  br label %bb91
bb90:
  br label %bb95
bb91:
  store %olang.scope zeroinitializer, ptr %s28
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t783 = load { i64, [1 x i64] }, ptr %l36
  %t786 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s28, ptr %t782, { i64, [1 x i64] } %t783)
  store { i64, ptr } %t786, ptr %l232
  br label %bb92
bb92:
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t788 = load { i64, [1 x i64] }, ptr %l37
  %t791 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s28, ptr %t787, { i64, [1 x i64] } %t788)
  store { i64, ptr } %t791, ptr %l235
  br label %bb93
bb93:
  %t792 = load ptr, ptr %l2, !tbaa !29
  %t793 = load i32, ptr %l38, !tbaa !23
  %t794 = load ptr, ptr @__olang_prog_scope
  %t797 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t794, ptr %s28, ptr %t792, i32 %t793)
  store { i64, ptr } %t797, ptr %l238
  br label %bb94
bb94:
  %t798 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t799 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t800 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t801 = extractvalue { i64, ptr } %t800, 1
  %t802 = extractvalue { i64, ptr } %t800, 0
  %t803 = add i64 %t799, %t802
  %t804 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t805 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t806 = add i64 %t803, %t805
  %t807 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t808 = extractvalue { i64, ptr } %t807, 1
  %t809 = extractvalue { i64, ptr } %t807, 0
  %t810 = add i64 %t806, %t809
  %t811 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t812 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t813 = add i64 %t810, %t812
  %t814 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t815 = extractvalue { i64, ptr } %t814, 1
  %t816 = extractvalue { i64, ptr } %t814, 0
  %t817 = add i64 %t813, %t816
  %t818 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t817)
  call void @olang_textcopy(ptr %t818, ptr %t798, i64 %t799)
  %t819 = getelementptr i8, ptr %t818, i64 %t799
  call void @olang_textcopy(ptr %t819, ptr %t801, i64 %t802)
  %t820 = getelementptr i8, ptr %t819, i64 %t802
  call void @olang_textcopy(ptr %t820, ptr %t804, i64 %t805)
  %t821 = getelementptr i8, ptr %t820, i64 %t805
  call void @olang_textcopy(ptr %t821, ptr %t808, i64 %t809)
  %t822 = getelementptr i8, ptr %t821, i64 %t809
  call void @olang_textcopy(ptr %t822, ptr %t811, i64 %t812)
  %t823 = getelementptr i8, ptr %t822, i64 %t812
  call void @olang_textcopy(ptr %t823, ptr %t815, i64 %t816)
  %t824 = insertvalue { i64, ptr } undef, i64 %t817, 0
  %t825 = insertvalue { i64, ptr } %t824, ptr %t818, 1
  store { i64, ptr } %t825, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s28)
  br label %bb116
bb95:
  %t827 = load { i64, [15 x i64] }, ptr %l1
  %t829 = extractvalue { i64, [15 x i64] } %t827, 0
  %t830 = icmp eq i64 %t829, 13
  br i1 %t830, label %bb96, label %bb97
bb96:
  %t832 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t833 = getelementptr { { i64, [1 x i64] } }, ptr %t832, i32 0, i32 0
  %t834 = load { i64, [1 x i64] }, ptr %t833
  store { i64, [1 x i64] } %t834, ptr %l39
  br label %bb98
bb97:
  br label %bb100
bb98:
  store %olang.scope zeroinitializer, ptr %s30
  %t836 = load ptr, ptr %l0, !tbaa !29
  %t837 = load { i64, [1 x i64] }, ptr %l39
  %t840 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s30, ptr %t836, { i64, [1 x i64] } %t837)
  store { i64, ptr } %t840, ptr %l245
  br label %bb99
bb99:
  %t841 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t842 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t843 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t844 = extractvalue { i64, ptr } %t843, 1
  %t845 = extractvalue { i64, ptr } %t843, 0
  %t846 = add i64 %t842, %t845
  %t847 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t846)
  call void @olang_textcopy(ptr %t847, ptr %t841, i64 %t842)
  %t848 = getelementptr i8, ptr %t847, i64 %t842
  call void @olang_textcopy(ptr %t848, ptr %t844, i64 %t845)
  %t849 = insertvalue { i64, ptr } undef, i64 %t846, 0
  %t850 = insertvalue { i64, ptr } %t849, ptr %t847, 1
  store { i64, ptr } %t850, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s30)
  br label %bb116
bb100:
  %t852 = load { i64, [15 x i64] }, ptr %l1
  %t854 = extractvalue { i64, [15 x i64] } %t852, 0
  %t855 = icmp eq i64 %t854, 14
  br i1 %t855, label %bb101, label %bb102
bb101:
  %t857 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t858 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t857, i32 0, i32 0
  %t859 = load { i64, [4 x i64] }, ptr %t858
  store { i64, [4 x i64] } %t859, ptr %l40
  %t861 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t862 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t861, i32 0, i32 1
  %t863 = load { i64, [1 x i64] }, ptr %t862
  store { i64, [1 x i64] } %t863, ptr %l41
  br label %bb103
bb102:
  br label %bb106
bb103:
  store %olang.scope zeroinitializer, ptr %s32
  %t865 = load ptr, ptr %l0, !tbaa !29
  %t866 = load { i64, [4 x i64] }, ptr %l40
  %t869 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s32, ptr %t865, { i64, [4 x i64] } %t866)
  store { i64, ptr } %t869, ptr %l253
  br label %bb104
bb104:
  %t870 = load ptr, ptr %l0, !tbaa !29
  %t871 = load { i64, [1 x i64] }, ptr %l41
  %t874 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s32, ptr %t870, { i64, [1 x i64] } %t871)
  store { i64, ptr } %t874, ptr %l256
  br label %bb105
bb105:
  %t875 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t876 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t877 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t878 = extractvalue { i64, ptr } %t877, 1
  %t879 = extractvalue { i64, ptr } %t877, 0
  %t880 = add i64 %t876, %t879
  %t881 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t882 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t883 = add i64 %t880, %t882
  %t884 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t885 = extractvalue { i64, ptr } %t884, 1
  %t886 = extractvalue { i64, ptr } %t884, 0
  %t887 = add i64 %t883, %t886
  %t888 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t887)
  call void @olang_textcopy(ptr %t888, ptr %t875, i64 %t876)
  %t889 = getelementptr i8, ptr %t888, i64 %t876
  call void @olang_textcopy(ptr %t889, ptr %t878, i64 %t879)
  %t890 = getelementptr i8, ptr %t889, i64 %t879
  call void @olang_textcopy(ptr %t890, ptr %t881, i64 %t882)
  %t891 = getelementptr i8, ptr %t890, i64 %t882
  call void @olang_textcopy(ptr %t891, ptr %t885, i64 %t886)
  %t892 = insertvalue { i64, ptr } undef, i64 %t887, 0
  %t893 = insertvalue { i64, ptr } %t892, ptr %t888, 1
  store { i64, ptr } %t893, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s32)
  br label %bb116
bb106:
  %t895 = load { i64, [15 x i64] }, ptr %l1
  %t897 = extractvalue { i64, [15 x i64] } %t895, 0
  %t898 = icmp eq i64 %t897, 15
  br i1 %t898, label %bb107, label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb110
bb109:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d130, i32 0, i32 1) }, ptr %l260, !tbaa !27
  %t900 = load { i64, ptr }, ptr %l260, !tbaa !27
  store { i64, ptr } %t900, ptr %l45, !tbaa !27
  br label %bb116
bb110:
  %t902 = load { i64, [15 x i64] }, ptr %l1
  %t904 = extractvalue { i64, [15 x i64] } %t902, 0
  %t905 = icmp eq i64 %t904, 16
  br i1 %t905, label %bb111, label %bb112
bb111:
  %t907 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t908 = getelementptr { i32 }, ptr %t907, i32 0, i32 0
  %t909 = load i32, ptr %t908
  store i32 %t909, ptr %l42, !tbaa !23
  br label %bb113
bb112:
  br label %bb115
bb113:
  store %olang.scope zeroinitializer, ptr %s35
  %t911 = load ptr, ptr %l2, !tbaa !29
  %t912 = load i32, ptr %l42, !tbaa !23
  %t913 = load ptr, ptr @__olang_prog_scope
  %t916 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t913, ptr %s35, ptr %t911, i32 %t912)
  store { i64, ptr } %t916, ptr %l267
  br label %bb114
bb114:
  %t917 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t918 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t919 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t920 = extractvalue { i64, ptr } %t919, 1
  %t921 = extractvalue { i64, ptr } %t919, 0
  %t922 = add i64 %t918, %t921
  %t923 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t922)
  call void @olang_textcopy(ptr %t923, ptr %t917, i64 %t918)
  %t924 = getelementptr i8, ptr %t923, i64 %t918
  call void @olang_textcopy(ptr %t924, ptr %t920, i64 %t921)
  %t925 = insertvalue { i64, ptr } undef, i64 %t922, 0
  %t926 = insertvalue { i64, ptr } %t925, ptr %t923, 1
  store { i64, ptr } %t926, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s35)
  br label %bb116
bb115:
  call void @__olang_check_failed(ptr @olang_loc_55b2be13c853614c_e5b496909f3a0f10)
  unreachable
bb116:
  %t928 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t929 = extractvalue { i64, ptr } %t928, 0
  store i64 %t929, ptr %l269, !tbaa !24
  %t930 = load i64, ptr %l269, !tbaa !24
  %t931 = mul i64 %t930, 1
  %t932 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t931)
  %t933 = insertvalue { i64, ptr } undef, i64 %t930, 0
  %t934 = insertvalue { i64, ptr } %t933, ptr %t932, 1
  store { i64, ptr } %t934, ptr %l270, !tbaa !27
  %t935 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t936 = load ptr, ptr %t935, !tbaa !27
  %t937 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t938 = load ptr, ptr %t937, !tbaa !27
  %t939 = load i64, ptr %l269, !tbaa !24
  %t940 = mul i64 %t939, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t936, ptr %t938, i64 %t940, i1 false)
  %t941 = load { i64, ptr }, ptr %l270, !tbaa !27
  store { i64, ptr } %t941, ptr %l45, !tbaa !27
  %t942 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t942, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2etask(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Task" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Task"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l15 = alloca %"compiler/mir:TaskClause"
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca %"compiler/typed:Item"
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l30 = alloca i32
  %l33 = alloca i32
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l64 = alloca %"compiler/mir:Lvalue"
  %l65 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l100 = alloca i32
  %l103 = alloca i32
  %l129 = alloca %"compiler/mir:TaskClause"
  %l137 = alloca i32
  %l140 = alloca i32
  %l166 = alloca %"compiler/typed:Item"
  %l167 = alloca ptr
  %l171 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Task" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l23
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 3
  %t4 = getelementptr %"compiler/mir:Range", ptr %t3, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = icmp sgt i32 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 0, ptr %l3, !tbaa !23
  %t9 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 3
  %t10 = getelementptr %"compiler/mir:Range", ptr %t9, i32 0, i32 1
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t13 = load i32, ptr %l4, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = icmp sgt i32 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb3:
  br label %bb23
bb4:
  %t19 = load i32, ptr %l5, !tbaa !23
  %t21 = icmp sgt i32 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i32 0, ptr %l30, !tbaa !23
  br label %bb9
bb6:
  %t23 = load i32, ptr %l4, !tbaa !23
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = sub i32 %t23, %t24
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = add i32 %t27, %t28
  %t33 = sub i32 %t31, 1
  %t34 = load i32, ptr %l5, !tbaa !23
  %t37 = sdiv i32 %t33, %t34
  store i32 %t37, ptr %l33, !tbaa !23
  br label %bb8
bb7:
  store i32 0, ptr %l33, !tbaa !23
  br label %bb8
bb8:
  %t39 = load i32, ptr %l33, !tbaa !23
  store i32 %t39, ptr %l30, !tbaa !23
  br label %bb9
bb9:
  %t40 = load i32, ptr %l30, !tbaa !23
  store i32 %t40, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load i32, ptr %l7, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = icmp slt i32 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t49 = load i32, ptr %l3, !tbaa !23
  %t50 = load i32, ptr %l7, !tbaa !23
  %t51 = load i32, ptr %l5, !tbaa !23
  %t54 = mul i32 %t50, %t51
  %t57 = add i32 %t49, %t54
  store i32 %t57, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l51, !tbaa !29
  %t59 = load i32, ptr %l8, !tbaa !23
  %t61 = icmp sgt i32 %t59, 0
  br i1 %t61, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d132, i32 0, i32 1) }, ptr %l54, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d133, i32 0, i32 1) }, ptr %l54, !tbaa !27
  br label %bb16
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l55, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/mir:dumper", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/mir:Fn", ptr %t67, i32 0, i32 13
  %t70 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 3
  %t71 = getelementptr %"compiler/mir:Range", ptr %t70, i32 0, i32 0
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  %t75 = load i32, ptr %l8, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t80 = add i64 %t74, %t77
  %t81 = load ptr, ptr @__olang_prog_scope
  %t84 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %t81, ptr %t69, i64 %t80)
  store %"compiler/mir:Lvalue" %t84, ptr %l64
  br label %bb17
bb17:
  %t85 = load ptr, ptr %l55, !tbaa !29
  %t86 = load %"compiler/mir:Lvalue", ptr %l64
  %t87 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s3, ptr %t85, %"compiler/mir:Lvalue" %t86)
  store { i64, ptr } %t87, ptr %l65
  br label %bb18
bb18:
  %t88 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = add i64 %t90, %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t89, i64 %t90)
  %t96 = getelementptr i8, ptr %t95, i64 %t90
  call void @olang_textcopy(ptr %t96, ptr %t92, i64 %t93)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t101 = extractvalue { i64, ptr } %t98, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  %t106 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t106, { i64, ptr } %t105)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t108 = load i32, ptr %l7, !tbaa !23
  %t110 = add i32 %t108, 1
  store i32 %t110, ptr %l7, !tbaa !23
  br label %bb10
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d134, i32 0, i32 1) })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb23:
  store ptr %l2, ptr %l71, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 0
  %t115 = load { i64, [7 x i64] }, ptr %t114
  %t118 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %s0, ptr %t113, { i64, [7 x i64] } %t115)
  store { i64, ptr } %t118, ptr %l74
  br label %bb24
bb24:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 1
  %t121 = load %"compiler/mir:Range", ptr %t120
  %t124 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s0, ptr %t119, %"compiler/mir:Range" %t121)
  store { i64, ptr } %t124, ptr %l77
  br label %bb25
bb25:
  %t125 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t131 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = add i64 %t130, %t133
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t126, i64 %t127)
  %t139 = getelementptr i8, ptr %t138, i64 %t127
  call void @olang_textcopy(ptr %t139, ptr %t128, i64 %t129)
  %t140 = getelementptr i8, ptr %t139, i64 %t129
  call void @olang_textcopy(ptr %t140, ptr %t132, i64 %t133)
  %t141 = getelementptr i8, ptr %t140, i64 %t133
  call void @olang_textcopy(ptr %t141, ptr %t135, i64 %t136)
  %t142 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t138, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  %t151 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t151, { i64, ptr } %t150)
  br label %bb26
bb26:
  %t153 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 2
  %t154 = getelementptr %"compiler/mir:Range", ptr %t153, i32 0, i32 1
  %t155 = load i32, ptr %t154, !tbaa !23
  %t157 = icmp sgt i32 %t155, 0
  br i1 %t157, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l2, ptr %l82, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 2
  %t161 = load %"compiler/mir:Range", ptr %t160
  %t164 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s7, ptr %t159, %"compiler/mir:Range" %t161)
  store { i64, ptr } %t164, ptr %l85
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t165 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t167 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = add i64 %t166, %t169
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t165, i64 %t166)
  %t175 = getelementptr i8, ptr %t174, i64 %t166
  call void @olang_textcopy(ptr %t175, ptr %t168, i64 %t169)
  %t176 = getelementptr i8, ptr %t175, i64 %t169
  call void @olang_textcopy(ptr %t176, ptr %t171, i64 %t172)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t174, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t186 = load ptr, ptr %l82, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t186, { i64, ptr } %t185)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb31:
  %t188 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 7
  %t189 = getelementptr %"compiler/mir:Range", ptr %t188, i32 0, i32 1
  %t190 = load i32, ptr %t189, !tbaa !23
  %t192 = icmp sgt i32 %t190, 0
  br i1 %t192, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  store ptr %l2, ptr %l90, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 7
  %t196 = load %"compiler/mir:Range", ptr %t195
  %t199 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s9, ptr %t194, %"compiler/mir:Range" %t196)
  store { i64, ptr } %t199, ptr %l93
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t200 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t202 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = add i64 %t201, %t204
  %t206 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t200, i64 %t201)
  %t210 = getelementptr i8, ptr %t209, i64 %t201
  call void @olang_textcopy(ptr %t210, ptr %t203, i64 %t204)
  %t211 = getelementptr i8, ptr %t210, i64 %t204
  call void @olang_textcopy(ptr %t211, ptr %t206, i64 %t207)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t209, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = mul i64 %t215, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  %t221 = load ptr, ptr %l90, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t221, { i64, ptr } %t220)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb36:
  store i32 0, ptr %l9, !tbaa !23
  %t223 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 4
  %t224 = getelementptr %"compiler/mir:Range", ptr %t223, i32 0, i32 1
  %t225 = load i32, ptr %t224, !tbaa !23
  store i32 %t225, ptr %l10, !tbaa !23
  store i32 1, ptr %l11, !tbaa !23
  %t227 = load i32, ptr %l10, !tbaa !23
  %t228 = load i32, ptr %l9, !tbaa !23
  %t231 = icmp sgt i32 %t227, %t228
  br i1 %t231, label %bb37, label %bb38
bb37:
  %t233 = load i32, ptr %l11, !tbaa !23
  %t235 = icmp sgt i32 %t233, 0
  br i1 %t235, label %bb39, label %bb40
bb38:
  store i32 0, ptr %l100, !tbaa !23
  br label %bb42
bb39:
  %t237 = load i32, ptr %l10, !tbaa !23
  %t238 = load i32, ptr %l9, !tbaa !23
  %t241 = sub i32 %t237, %t238
  %t242 = load i32, ptr %l11, !tbaa !23
  %t245 = add i32 %t241, %t242
  %t247 = sub i32 %t245, 1
  %t248 = load i32, ptr %l11, !tbaa !23
  %t251 = sdiv i32 %t247, %t248
  store i32 %t251, ptr %l103, !tbaa !23
  br label %bb41
bb40:
  store i32 0, ptr %l103, !tbaa !23
  br label %bb41
bb41:
  %t253 = load i32, ptr %l103, !tbaa !23
  store i32 %t253, ptr %l100, !tbaa !23
  br label %bb42
bb42:
  %t254 = load i32, ptr %l100, !tbaa !23
  store i32 %t254, ptr %l12, !tbaa !23
  store i32 0, ptr %l13, !tbaa !23
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s12
  %t255 = load i32, ptr %l13, !tbaa !23
  %t256 = load i32, ptr %l12, !tbaa !23
  %t259 = icmp slt i32 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s12)
  br label %bb77
bb45:
  br label %bb46
bb46:
  %t263 = load i32, ptr %l9, !tbaa !23
  %t264 = load i32, ptr %l13, !tbaa !23
  %t265 = load i32, ptr %l11, !tbaa !23
  %t268 = mul i32 %t264, %t265
  %t271 = add i32 %t263, %t268
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/mir:dumper", ptr %t273, i32 0, i32 0
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/mir:Fn", ptr %t276, i32 0, i32 17
  %t279 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 4
  %t280 = getelementptr %"compiler/mir:Range", ptr %t279, i32 0, i32 0
  %t281 = load i32, ptr %t280, !tbaa !23
  %t283 = sext i32 %t281 to i64
  %t286 = sext i32 %t271 to i64
  %t289 = add i64 %t283, %t286
  %t290 = load ptr, ptr @__olang_prog_scope
  %t293 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %t290, ptr %t278, i64 %t289)
  store %"compiler/mir:TaskClause" %t293, ptr %l129
  br label %bb47
bb47:
  %t294 = load %"compiler/mir:TaskClause", ptr %l129
  store %"compiler/mir:TaskClause" %t294, ptr %l15
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d141, i32 0, i32 1) })
  br label %bb48
bb48:
  %t296 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 1
  %t297 = load i1, ptr %t296, !tbaa !21
  br i1 %t297, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s13
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %l2, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d142, i32 0, i32 1) })
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s13)
  br label %bb52
bb52:
  store i32 0, ptr %l16, !tbaa !23
  %t300 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 0
  %t301 = getelementptr %"compiler/mir:Range", ptr %t300, i32 0, i32 1
  %t302 = load i32, ptr %t301, !tbaa !23
  store i32 %t302, ptr %l17, !tbaa !23
  store i32 1, ptr %l18, !tbaa !23
  %t304 = load i32, ptr %l17, !tbaa !23
  %t305 = load i32, ptr %l16, !tbaa !23
  %t308 = icmp sgt i32 %t304, %t305
  br i1 %t308, label %bb53, label %bb54
bb53:
  %t310 = load i32, ptr %l18, !tbaa !23
  %t312 = icmp sgt i32 %t310, 0
  br i1 %t312, label %bb55, label %bb56
bb54:
  store i32 0, ptr %l137, !tbaa !23
  br label %bb58
bb55:
  %t314 = load i32, ptr %l17, !tbaa !23
  %t315 = load i32, ptr %l16, !tbaa !23
  %t318 = sub i32 %t314, %t315
  %t319 = load i32, ptr %l18, !tbaa !23
  %t322 = add i32 %t318, %t319
  %t324 = sub i32 %t322, 1
  %t325 = load i32, ptr %l18, !tbaa !23
  %t328 = sdiv i32 %t324, %t325
  store i32 %t328, ptr %l140, !tbaa !23
  br label %bb57
bb56:
  store i32 0, ptr %l140, !tbaa !23
  br label %bb57
bb57:
  %t330 = load i32, ptr %l140, !tbaa !23
  store i32 %t330, ptr %l137, !tbaa !23
  br label %bb58
bb58:
  %t331 = load i32, ptr %l137, !tbaa !23
  store i32 %t331, ptr %l19, !tbaa !23
  store i32 0, ptr %l20, !tbaa !23
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s15
  %t332 = load i32, ptr %l20, !tbaa !23
  %t333 = load i32, ptr %l19, !tbaa !23
  %t336 = icmp slt i32 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s15)
  br label %bb70
bb61:
  br label %bb62
bb62:
  %t340 = load i32, ptr %l16, !tbaa !23
  %t341 = load i32, ptr %l20, !tbaa !23
  %t342 = load i32, ptr %l18, !tbaa !23
  %t345 = mul i32 %t341, %t342
  %t348 = add i32 %t340, %t345
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/mir:dumper", ptr %t350, i32 0, i32 0
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/mir:Fn", ptr %t353, i32 0, i32 18
  %t356 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 0
  %t357 = getelementptr %"compiler/mir:Range", ptr %t356, i32 0, i32 0
  %t358 = load i32, ptr %t357, !tbaa !23
  %t360 = sext i32 %t358 to i64
  %t363 = sext i32 %t348 to i64
  %t366 = add i64 %t360, %t363
  %t367 = load ptr, ptr @__olang_prog_scope
  %t370 = call %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %t367, ptr %t355, i64 %t366)
  store %"compiler/typed:Item" %t370, ptr %l166
  br label %bb63
bb63:
  %t371 = load %"compiler/typed:Item", ptr %l166
  store %"compiler/typed:Item" %t371, ptr %l22
  store ptr %l2, ptr %l167, !tbaa !29
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/mir:dumper", ptr %t372, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t376 = getelementptr %"compiler/typed:Item", ptr %l22, i32 0, i32 0
  %t377 = load i32, ptr %t376, !tbaa !23
  %t378 = load ptr, ptr @__olang_prog_scope
  %t381 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t378, ptr %s15, ptr %t375, i32 %t377)
  store { i64, ptr } %t381, ptr %l171
  br label %bb64
bb64:
  %t382 = getelementptr %"compiler/typed:Item", ptr %l22, i32 0, i32 1
  %t383 = load i64, ptr %t382, !tbaa !24
  %t385 = icmp slt i64 %t383, 0
  br i1 %t385, label %bb65, label %bb66
bb65:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d143, i32 0, i32 1) }, ptr %l174, !tbaa !27
  br label %bb67
bb66:
  %t387 = getelementptr %"compiler/typed:Item", ptr %l22, i32 0, i32 1
  %t388 = load i64, ptr %t387, !tbaa !24
  %t389 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t390 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t392 = call i64 @__olang_fmt_i64(ptr null, i64 %t388)
  %t393 = add i64 %t390, %t392
  %t394 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t393)
  call void @olang_textcopy(ptr %t394, ptr %t389, i64 %t390)
  %t395 = getelementptr i8, ptr %t394, i64 %t390
  %t396 = call i64 @__olang_fmt_i64(ptr %t395, i64 %t388)
  %t397 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t394, 1
  %t400 = extractvalue { i64, ptr } %t398, 0
  %t401 = extractvalue { i64, ptr } %t398, 1
  %t402 = mul i64 %t400, 1
  %t403 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t402)
  call void @llvm.memcpy.p0.p0.i64(ptr %t403, ptr %t401, i64 %t402, i1 false)
  %t404 = insertvalue { i64, ptr } undef, i64 %t400, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  store { i64, ptr } %t405, ptr %l174, !tbaa !27
  br label %bb67
bb67:
  %t407 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t408 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t409 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t409, 1
  %t411 = extractvalue { i64, ptr } %t409, 0
  %t412 = add i64 %t408, %t411
  %t413 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t414 = extractvalue { i64, ptr } %t413, 1
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t416 = add i64 %t412, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t407, i64 %t408)
  %t418 = getelementptr i8, ptr %t417, i64 %t408
  call void @olang_textcopy(ptr %t418, ptr %t410, i64 %t411)
  %t419 = getelementptr i8, ptr %t418, i64 %t411
  call void @olang_textcopy(ptr %t419, ptr %t414, i64 %t415)
  %t420 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t421 = insertvalue { i64, ptr } %t420, ptr %t417, 1
  %t423 = extractvalue { i64, ptr } %t421, 0
  %t424 = extractvalue { i64, ptr } %t421, 1
  %t425 = mul i64 %t423, 1
  %t426 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t425)
  call void @llvm.memcpy.p0.p0.i64(ptr %t426, ptr %t424, i64 %t425, i1 false)
  %t427 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t428 = insertvalue { i64, ptr } %t427, ptr %t426, 1
  %t429 = load ptr, ptr %l167, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %t429, { i64, ptr } %t428)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s15)
  br label %bb69
bb69:
  %t431 = load i32, ptr %l20, !tbaa !23
  %t433 = add i32 %t431, 1
  store i32 %t433, ptr %l20, !tbaa !23
  br label %bb59
bb70:
  %t435 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 2
  %t436 = load { i64, [4 x i64] }, ptr %t435
  %t438 = extractvalue { i64, [4 x i64] } %t436, 0
  %t439 = icmp eq i64 %t438, 0
  %t441 = xor i1 %t439, true
  br i1 %t441, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s19
  store ptr %l2, ptr %l185, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/mir:TaskClause", ptr %l15, i32 0, i32 2
  %t445 = load { i64, [4 x i64] }, ptr %t444
  %t448 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s19, ptr %t443, { i64, [4 x i64] } %t445)
  store { i64, ptr } %t448, ptr %l188
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t449 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t450 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t451 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 1
  %t453 = extractvalue { i64, ptr } %t451, 0
  %t454 = add i64 %t450, %t453
  %t455 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t454)
  call void @olang_textcopy(ptr %t455, ptr %t449, i64 %t450)
  %t456 = getelementptr i8, ptr %t455, i64 %t450
  call void @olang_textcopy(ptr %t456, ptr %t452, i64 %t453)
  %t457 = insertvalue { i64, ptr } undef, i64 %t454, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t455, 1
  %t460 = extractvalue { i64, ptr } %t458, 0
  %t461 = extractvalue { i64, ptr } %t458, 1
  %t462 = mul i64 %t460, 1
  %t463 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t462)
  call void @llvm.memcpy.p0.p0.i64(ptr %t463, ptr %t461, i64 %t462, i1 false)
  %t464 = insertvalue { i64, ptr } undef, i64 %t460, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t463, 1
  %t466 = load ptr, ptr %l185, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s19, ptr %t466, { i64, ptr } %t465)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s19)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s12)
  br label %bb76
bb76:
  %t468 = load i32, ptr %l13, !tbaa !23
  %t470 = add i32 %t468, 1
  store i32 %t470, ptr %l13, !tbaa !23
  br label %bb43
bb77:
  %t473 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t473, ptr %l194
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s0)
  %t474 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t474, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2evarKind(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l15 = alloca { i64, [1 x i64] }
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %t10)
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t11, i64 %t12)
  %t17 = getelementptr i8, ptr %t16, i64 %t12
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %t10)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t16, 1
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb15
bb4:
  %t22 = load { i64, [1 x i64] }, ptr %l1
  %t24 = extractvalue { i64, [1 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 4
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = getelementptr i8, ptr %t37, i64 %t33
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t31)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  store { i64, ptr } %t41, ptr %l4, !tbaa !27
  br label %bb15
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb14
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t43 = load { i64, [1 x i64] }, ptr %l1
  store { i64, [1 x i64] } %t43, ptr %l15
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aVarKind(ptr %s6, ptr %l15, i64 0)
  br label %bb12
bb12:
  %t45 = load ptr, ptr %s6
  %t46 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t47 = load i64, ptr %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t45, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l17, !tbaa !27
  %t51 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t52 = load ptr, ptr %t51
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %sbgrew.54, label %sbdone.55
sbgrew.54:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.55
sbdone.55:
  %t56 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  %t58 = extractvalue { i64, ptr } %t56, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t64 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s5, ptr %s5, { i64, ptr } %t62)
  store { i64, ptr } %t64, ptr %l19
  br label %bb13
bb13:
  %t65 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6326b544498e75fa_e53a2c99f88826ee)
  unreachable
bb15:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l10 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 11
  %t7 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t14 = add i64 %t10, %a2
  %t15 = load ptr, ptr @__olang_prog_scope
  %t18 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %t15, ptr %t6, i64 %t14)
  store { i64, [4 x i64] } %t18, ptr %l10
  br label %bb1
bb1:
  %t19 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load ptr, ptr @__olang_prog_scope
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t6, ptr %t4, i32 %a1)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %l2, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/mir:verifier", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr @__olang_prog_scope
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t16, ptr %t14, i32 %t15)
  store i32 %t19, ptr %l10
  br label %bb2
bb2:
  %t20 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t22 = trunc i64 19 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i32, ptr %l2, !tbaa !23
  store i32 %t25, ptr %l13, !tbaa !23
  br label %bb5
bb4:
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t27, ptr %l13, !tbaa !23
  br label %bb5
bb5:
  %t29 = load i32, ptr %l13, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l9 = alloca i1
  %l20 = alloca %"compiler/mir:ScopeInfo"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l9
  br label %bb4
bb4:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t23 = sext i32 %t19 to i64
  %t24 = call i64 @__olang_fmt_i64(ptr null, i64 %t23)
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t23)
  %t32 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t32, ptr %t26, i64 %t27)
  %t33 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t29, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t18, { i64, ptr } %t41)
  br label %bb7
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/mir:verifier", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/mir:Fn", ptr %t47, i32 0, i32 8
  %t50 = load i32, ptr %l2, !tbaa !23
  %t52 = sext i32 %t50 to i64
  %t53 = load ptr, ptr @__olang_prog_scope
  %t56 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t53, ptr %t49, i64 %t52)
  store %"compiler/mir:ScopeInfo" %t56, ptr %l20
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb8:
  %t57 = getelementptr %"compiler/mir:ScopeInfo", ptr %l20, i32 0, i32 0
  %t58 = load i32, ptr %t57, !range !{i32 0, i32 7}
  %t60 = trunc i64 5 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t65 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t68 = sext i32 %t64 to i64
  %t69 = call i64 @__olang_fmt_i64(ptr null, i64 %t68)
  %t70 = add i64 %t66, %t69
  %t71 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t65, i64 %t66)
  %t75 = getelementptr i8, ptr %t74, i64 %t66
  %t76 = call i64 @__olang_fmt_i64(ptr %t75, i64 %t68)
  %t77 = getelementptr i8, ptr %t75, i64 %t69
  call void @olang_textcopy(ptr %t77, ptr %t71, i64 %t72)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t74, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t63, { i64, ptr } %t86)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb24
bb14:
  %t89 = load { i64, [1 x i64] }, ptr %l1
  %t91 = extractvalue { i64, [1 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 4
  br i1 %t92, label %bb15, label %bb16
bb15:
  %t94 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t95 = getelementptr { i32 }, ptr %t94, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l3, !tbaa !23
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t98, i32 %t99)
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a15aa4830130cc38_9fcdb454ad4b970c)
  unreachable
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %a0, { i64, [4 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_43daeee16a7347fc_3936ff71893c42a0)
  unreachable
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca i32
  %l20 = alloca i32
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l53 = alloca i32
  %l57 = alloca ptr
  %l60 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 1
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb5
bb2:
  %t10 = load { i64, [7 x i64] }, ptr %l1
  %t12 = extractvalue { i64, [7 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { i64, i32 }, ptr %t15, i32 0, i32 1
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = load i32, ptr %l2, !tbaa !23
  store i32 %t19, ptr %l7, !tbaa !23
  br label %bb16
bb6:
  %t21 = load { i64, [7 x i64] }, ptr %l1
  %t23 = extractvalue { i64, [7 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 2
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t27 = getelementptr { { i64, [4 x i64] } }, ptr %t26, i32 0, i32 0
  %t28 = load { i64, [4 x i64] }, ptr %t27
  store { i64, [4 x i64] } %t28, ptr %l3
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, [4 x i64] }, ptr %l3
  %t34 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t30, { i64, [4 x i64] } %t31)
  store i32 %t34, ptr %l20
  br label %bb10
bb10:
  %t35 = load i32, ptr %l20, !tbaa !23
  store i32 %t35, ptr %l7, !tbaa !23
  br label %bb16
bb11:
  %t36 = load { i64, [7 x i64] }, ptr %l1
  %t38 = extractvalue { i64, [7 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 3
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t42 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t41, i32 0, i32 2
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l4, !tbaa !23
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t45 = load i32, ptr %l4, !tbaa !23
  store i32 %t45, ptr %l7, !tbaa !23
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_690174ade0b6e824_1aa5c898f3f73ab8)
  unreachable
bb16:
  %t47 = load i32, ptr %l7, !tbaa !23
  store i32 %t47, ptr %l5, !tbaa !23
  %t48 = load { i64, [7 x i64] }, ptr %l1
  %t50 = extractvalue { i64, [7 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 3
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t53 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t54 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load { i64, [4 x i64] }, ptr %t54
  store { i64, [4 x i64] } %t55, ptr %l6
  br label %bb19
bb18:
  br label %bb29
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:verifier", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l29, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/mir:verifier", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  store ptr %t64, ptr %l31, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, [4 x i64] }, ptr %l6
  %t69 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t65, { i64, [4 x i64] } %t66)
  store i32 %t69, ptr %l34
  br label %bb20
bb20:
  %t70 = load ptr, ptr @__olang_prog_scope
  %t71 = load ptr, ptr %l31, !tbaa !29
  %t72 = load i32, ptr %l34, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t70, ptr %t71, i32 %t72)
  store i32 %t73, ptr %l35
  br label %bb21
bb21:
  %t74 = load ptr, ptr @__olang_prog_scope
  %t75 = load ptr, ptr %l29, !tbaa !29
  %t76 = load i32, ptr %l35, !tbaa !23
  %t77 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %t74, ptr %t75, i32 %t76)
  store i1 %t77, ptr %l36
  br label %bb22
bb22:
  %t78 = load i1, ptr %l36, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l38, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l39, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load { i64, [4 x i64] }, ptr %l6
  %t87 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t83, { i64, [4 x i64] } %t84)
  store i32 %t87, ptr %l42
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t88 = load ptr, ptr %l39, !tbaa !29
  %t89 = load i32, ptr %l42, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t88, i32 %t89)
  store { i64, ptr } %t90, ptr %l43
  br label %bb26
bb26:
  %t91 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t93 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = add i64 %t92, %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t91, i64 %t92)
  %t98 = getelementptr i8, ptr %t97, i64 %t92
  call void @olang_textcopy(ptr %t98, ptr %t94, i64 %t95)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t108, { i64, ptr } %t107)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_b20acbf668615715_202a9ab5dba06089)
  unreachable
bb34:
  %t110 = load i32, ptr %l5, !tbaa !23
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t114 = icmp eq i32 %t110, %t111
  br i1 %t114, label %bb35, label %bb36
bb35:
  %t116 = load i32, ptr %l5, !tbaa !23
  store i32 %t116, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/mir:verifier", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load i32, ptr %l5, !tbaa !23
  %t123 = load ptr, ptr @__olang_prog_scope
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t123, ptr %t121, i32 %t122)
  store i32 %t126, ptr %l53
  br label %bb38
bb38:
  %t127 = load i32, ptr %l53, !range !{i32 0, i32 33}
  %t129 = trunc i64 21 to i32
  %t130 = icmp eq i32 %t127, %t129
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s9
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l57, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l5, !tbaa !23
  %t139 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s9, ptr %t135, i32 %t136)
  store { i64, ptr } %t139, ptr %l60
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t140 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t142 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = add i64 %t141, %t144
  %t146 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t140, i64 %t141)
  %t150 = getelementptr i8, ptr %t149, i64 %t141
  call void @olang_textcopy(ptr %t150, ptr %t143, i64 %t144)
  %t151 = getelementptr i8, ptr %t150, i64 %t144
  call void @olang_textcopy(ptr %t151, ptr %t146, i64 %t147)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t149, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t161 = load ptr, ptr %l57, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s9, ptr %t161, { i64, ptr } %t160)
  br label %bb42
bb42:
  %t163 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  store i32 %t163, ptr %rv
  br label %ret
bb43:
  %t165 = load i32, ptr %l5, !tbaa !23
  store i32 %t165, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOnce(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l21 = alloca i32
  %l24 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i32
  %l74 = alloca %"compiler/mir:Case"
  %l75 = alloca i64
  %l83 = alloca %"compiler/mir:Case"
  %l86 = alloca ptr
  %l94 = alloca %"compiler/mir:Case"
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i32 0, ptr %l3, !tbaa !23
  %t6 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = icmp sgt i32 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i32, ptr %l5, !tbaa !23
  %t17 = icmp sgt i32 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l21, !tbaa !23
  br label %bb6
bb3:
  %t19 = load i32, ptr %l4, !tbaa !23
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = sub i32 %t19, %t20
  %t24 = load i32, ptr %l5, !tbaa !23
  %t27 = add i32 %t23, %t24
  %t29 = sub i32 %t27, 1
  %t30 = load i32, ptr %l5, !tbaa !23
  %t33 = sdiv i32 %t29, %t30
  store i32 %t33, ptr %l24, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l24, !tbaa !23
  br label %bb5
bb5:
  %t35 = load i32, ptr %l24, !tbaa !23
  store i32 %t35, ptr %l21, !tbaa !23
  br label %bb6
bb6:
  %t36 = load i32, ptr %l21, !tbaa !23
  store i32 %t36, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb7
bb7:
  %t37 = load i32, ptr %l7, !tbaa !23
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = icmp slt i32 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb8, label %bb9
bb8:
  br label %bb31
bb9:
  br label %bb10
bb10:
  %t45 = load i32, ptr %l3, !tbaa !23
  %t46 = load i32, ptr %l7, !tbaa !23
  %t47 = load i32, ptr %l5, !tbaa !23
  %t50 = mul i32 %t46, %t47
  %t53 = add i32 %t45, %t50
  store i32 %t53, ptr %l8, !tbaa !23
  store i32 0, ptr %l9, !tbaa !23
  %t55 = load i32, ptr %l8, !tbaa !23
  store i32 %t55, ptr %l10, !tbaa !23
  store i32 1, ptr %l11, !tbaa !23
  %t57 = load i32, ptr %l10, !tbaa !23
  %t58 = load i32, ptr %l9, !tbaa !23
  %t61 = icmp sgt i32 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = load i32, ptr %l11, !tbaa !23
  %t65 = icmp sgt i32 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb12:
  store i32 0, ptr %l46, !tbaa !23
  br label %bb16
bb13:
  %t67 = load i32, ptr %l10, !tbaa !23
  %t68 = load i32, ptr %l9, !tbaa !23
  %t71 = sub i32 %t67, %t68
  %t72 = load i32, ptr %l11, !tbaa !23
  %t75 = add i32 %t71, %t72
  %t77 = sub i32 %t75, 1
  %t78 = load i32, ptr %l11, !tbaa !23
  %t81 = sdiv i32 %t77, %t78
  store i32 %t81, ptr %l49, !tbaa !23
  br label %bb15
bb14:
  store i32 0, ptr %l49, !tbaa !23
  br label %bb15
bb15:
  %t83 = load i32, ptr %l49, !tbaa !23
  store i32 %t83, ptr %l46, !tbaa !23
  br label %bb16
bb16:
  %t84 = load i32, ptr %l46, !tbaa !23
  store i32 %t84, ptr %l12, !tbaa !23
  store i32 0, ptr %l13, !tbaa !23
  br label %bb17
bb17:
  %t85 = load i32, ptr %l13, !tbaa !23
  %t86 = load i32, ptr %l12, !tbaa !23
  %t89 = icmp slt i32 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb18, label %bb19
bb18:
  br label %bb29
bb19:
  br label %bb20
bb20:
  %t93 = load i32, ptr %l9, !tbaa !23
  %t94 = load i32, ptr %l13, !tbaa !23
  %t95 = load i32, ptr %l11, !tbaa !23
  %t98 = mul i32 %t94, %t95
  %t101 = add i32 %t93, %t98
  store i32 %t101, ptr %l14, !tbaa !23
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = getelementptr %"compiler/mir:Fn", ptr %t103, i32 0, i32 15
  %t106 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = sext i32 %t107 to i64
  %t110 = load i32, ptr %l8, !tbaa !23
  %t112 = sext i32 %t110 to i64
  %t115 = add i64 %t109, %t112
  %t116 = load ptr, ptr @__olang_prog_scope
  %t119 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %t116, ptr %t105, i64 %t115)
  store %"compiler/mir:Case" %t119, ptr %l74
  br label %bb21
bb21:
  %t120 = getelementptr %"compiler/mir:Case", ptr %l74, i32 0, i32 0
  %t121 = load i64, ptr %t120, !tbaa !24
  store i64 %t121, ptr %l75, !tbaa !24
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t124 = getelementptr %"compiler/mir:Fn", ptr %t122, i32 0, i32 15
  %t125 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t126 = load i32, ptr %t125, !tbaa !23
  %t128 = sext i32 %t126 to i64
  %t129 = load i32, ptr %l14, !tbaa !23
  %t131 = sext i32 %t129 to i64
  %t134 = add i64 %t128, %t131
  %t135 = load ptr, ptr @__olang_prog_scope
  %t138 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %t135, ptr %t124, i64 %t134)
  store %"compiler/mir:Case" %t138, ptr %l83
  br label %bb22
bb22:
  %t139 = getelementptr %"compiler/mir:Case", ptr %l83, i32 0, i32 0
  %t140 = load i64, ptr %t139, !tbaa !24
  %t141 = load i64, ptr %l75, !tbaa !24
  %t143 = icmp eq i64 %t141, %t140
  br i1 %t143, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l86, !tbaa !29
  %t146 = load ptr, ptr %l2, !tbaa !29
  %t148 = getelementptr %"compiler/mir:Fn", ptr %t146, i32 0, i32 15
  %t149 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t150 = load i32, ptr %t149, !tbaa !23
  %t152 = sext i32 %t150 to i64
  %t153 = load i32, ptr %l8, !tbaa !23
  %t155 = sext i32 %t153 to i64
  %t158 = add i64 %t152, %t155
  %t159 = load ptr, ptr @__olang_prog_scope
  %t162 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %t159, ptr %t148, i64 %t158)
  store %"compiler/mir:Case" %t162, ptr %l94
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t163 = getelementptr %"compiler/mir:Case", ptr %l94, i32 0, i32 0
  %t164 = load i64, ptr %t163, !tbaa !24
  %t165 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t168 = call i64 @__olang_fmt_i64(ptr null, i64 %t164)
  %t169 = add i64 %t166, %t168
  %t170 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t165, i64 %t166)
  %t174 = getelementptr i8, ptr %t173, i64 %t166
  %t175 = call i64 @__olang_fmt_i64(ptr %t174, i64 %t164)
  %t176 = getelementptr i8, ptr %t174, i64 %t168
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t173, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t186 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t186, { i64, ptr } %t185)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t188 = load i32, ptr %l13, !tbaa !23
  %t190 = add i32 %t188, 1
  store i32 %t190, ptr %l13, !tbaa !23
  br label %bb17
bb29:
  br label %bb30
bb30:
  %t192 = load i32, ptr %l7, !tbaa !23
  %t194 = add i32 %t192, 1
  store i32 %t194, ptr %l7, !tbaa !23
  br label %bb7
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l51 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l63 = alloca i64
  %l66 = alloca i64
  %l85 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l112 = alloca i64
  %l115 = alloca i64
  %l134 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l148 = alloca i64
  %l151 = alloca i64
  %l153 = alloca { i64, ptr }
  %l154 = alloca i64
  %l157 = alloca i64
  %l160 = alloca i64
  %l162 = alloca i64
  %l167 = alloca i32
  %l177 = alloca i64
  %l180 = alloca i64
  %l199 = alloca { i64, ptr }
  %l206 = alloca i1
  %l208 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l228 = alloca i1
  %l230 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l248 = alloca i64
  %l251 = alloca i64
  %l270 = alloca { i64, ptr }
  %l273 = alloca i1
  %l275 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l294 = alloca { i64, ptr }
  %l296 = alloca i64
  %l299 = alloca i64
  %l304 = alloca i64
  %l308 = alloca i64
  %l311 = alloca i64
  %l330 = alloca i1
  %l334 = alloca { i64, ptr }
  %l339 = alloca i32
  %l343 = alloca i32
  %l349 = alloca ptr
  %l350 = alloca i32
  %l352 = alloca { i64, ptr }
  %l355 = alloca { i64, ptr }
  %s24 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 7
  %t9 = load ptr, ptr @__olang_prog_scope
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %t9, ptr %t8)
  store i64 %t11, ptr %l44
  br label %bb1
bb1:
  %t12 = load i64, ptr %l44, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 8
  %t16 = load ptr, ptr @__olang_prog_scope
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t16, ptr %t15)
  store i64 %t18, ptr %l47
  br label %bb2
bb2:
  %t19 = load i64, ptr %l47, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  %t20 = load i32, ptr %l1, !tbaa !23
  %t22 = sext i32 %t20 to i64
  store i64 %t22, ptr %l5, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/mir:verifier", ptr %t24, i32 0, i32 6
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l51, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i1, ptr %t31, i64 %t28
  %t33 = load i1, ptr %t32, !tbaa !31
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb3, label %bb4
bb3:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/mir:verifier", ptr %t37, i32 0, i32 6
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l56, !tbaa !27
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i1, ptr %t44, i64 %t41
  store i1 true, ptr %t45, !tbaa !31
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/mir:verifier", ptr %t46, i32 0, i32 18
  store i1 true, ptr %t48, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb5, label %bb6
bb4:
  br label %bb40
bb5:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb10
bb7:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l66, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb9
bb9:
  %t77 = load i64, ptr %l66, !tbaa !24
  store i64 %t77, ptr %l63, !tbaa !24
  br label %bb10
bb10:
  %t78 = load i64, ptr %l63, !tbaa !24
  store i64 %t78, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l11, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/mir:verifier", ptr %t97, i32 0, i32 7
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l85, !tbaa !27
  %t101 = load i64, ptr %l5, !tbaa !24
  %t102 = load i64, ptr %l3, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t106 = load i64, ptr %l11, !tbaa !24
  %t109 = add i64 %t105, %t106
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/mir:verifier", ptr %t110, i32 0, i32 14
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l92, !tbaa !27
  %t114 = load i64, ptr %l11, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i1, ptr %t117, i64 %t114
  %t119 = load i1, ptr %t118, !tbaa !31
  %t122 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i1, ptr %t123, i64 %t109
  store i1 %t119, ptr %t124, !tbaa !31
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/mir:verifier", ptr %t125, i32 0, i32 8
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l96, !tbaa !27
  %t129 = load i64, ptr %l5, !tbaa !24
  %t130 = load i64, ptr %l3, !tbaa !24
  %t133 = mul i64 %t129, %t130
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = add i64 %t133, %t134
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/mir:verifier", ptr %t138, i32 0, i32 15
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l103, !tbaa !27
  %t142 = load i64, ptr %l11, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i1, ptr %t145, i64 %t142
  %t147 = load i1, ptr %t146, !tbaa !31
  %t150 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i1, ptr %t151, i64 %t137
  store i1 %t147, ptr %t152, !tbaa !31
  br label %bb15
bb15:
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l10, !tbaa !24
  br label %bb11
bb16:
  store i64 0, ptr %l12, !tbaa !24
  %t157 = load i64, ptr %l4, !tbaa !24
  store i64 %t157, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t159 = load i64, ptr %l13, !tbaa !24
  %t160 = load i64, ptr %l12, !tbaa !24
  %t163 = icmp sgt i64 %t159, %t160
  br i1 %t163, label %bb17, label %bb18
bb17:
  %t165 = load i64, ptr %l14, !tbaa !24
  %t167 = icmp sgt i64 %t165, 0
  br i1 %t167, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb22
bb19:
  %t169 = load i64, ptr %l13, !tbaa !24
  %t170 = load i64, ptr %l12, !tbaa !24
  %t173 = sub i64 %t169, %t170
  %t174 = load i64, ptr %l14, !tbaa !24
  %t177 = add i64 %t173, %t174
  %t179 = sub i64 %t177, 1
  %t180 = load i64, ptr %l14, !tbaa !24
  %t183 = sdiv i64 %t179, %t180
  store i64 %t183, ptr %l115, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb21
bb21:
  %t185 = load i64, ptr %l115, !tbaa !24
  store i64 %t185, ptr %l112, !tbaa !24
  br label %bb22
bb22:
  %t186 = load i64, ptr %l112, !tbaa !24
  store i64 %t186, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb23
bb23:
  %t187 = load i64, ptr %l16, !tbaa !24
  %t188 = load i64, ptr %l15, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t195 = load i64, ptr %l12, !tbaa !24
  %t196 = load i64, ptr %l16, !tbaa !24
  %t197 = load i64, ptr %l14, !tbaa !24
  %t200 = mul i64 %t196, %t197
  %t203 = add i64 %t195, %t200
  store i64 %t203, ptr %l17, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/mir:verifier", ptr %t205, i32 0, i32 9
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l134, !tbaa !27
  %t209 = load i64, ptr %l5, !tbaa !24
  %t210 = load i64, ptr %l4, !tbaa !24
  %t213 = mul i64 %t209, %t210
  %t214 = load i64, ptr %l17, !tbaa !24
  %t217 = add i64 %t213, %t214
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/mir:verifier", ptr %t218, i32 0, i32 16
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  store { i64, ptr } %t221, ptr %l141, !tbaa !27
  %t222 = load i64, ptr %l17, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i1, ptr %t225, i64 %t222
  %t227 = load i1, ptr %t226, !tbaa !31
  %t230 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i1, ptr %t231, i64 %t217
  store i1 %t227, ptr %t232, !tbaa !31
  br label %bb27
bb27:
  %t233 = load i64, ptr %l16, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l16, !tbaa !24
  br label %bb23
bb28:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/mir:verifier", ptr %t237, i32 0, i32 10
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  store { i64, ptr } %t240, ptr %l147, !tbaa !27
  %t241 = load i64, ptr %l5, !tbaa !24
  store i64 %t241, ptr %l148, !tbaa !24
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/mir:verifier", ptr %t242, i32 0, i32 12
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t244)
  store i64 %t246, ptr %l151
  br label %bb29
bb29:
  %t247 = load i64, ptr %l151, !tbaa !24
  %t248 = load i64, ptr %l148, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i64, ptr %t250, i64 %t248
  store i64 %t247, ptr %t251, !tbaa !34
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/mir:verifier", ptr %t252, i32 0, i32 11
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  store { i64, ptr } %t255, ptr %l153, !tbaa !27
  %t256 = load i64, ptr %l5, !tbaa !24
  store i64 %t256, ptr %l154, !tbaa !24
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/mir:verifier", ptr %t257, i32 0, i32 17
  %t261 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t259)
  store i64 %t261, ptr %l157
  br label %bb30
bb30:
  %t262 = load i64, ptr %l157, !tbaa !24
  %t263 = load i64, ptr %l154, !tbaa !24
  %t264 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr i64, ptr %t265, i64 %t263
  store i64 %t262, ptr %t266, !tbaa !34
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/mir:verifier", ptr %t267, i32 0, i32 17
  store ptr %t269, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb31
bb31:
  %t271 = load i64, ptr %l19, !tbaa !24
  store i64 %t271, ptr %l160, !tbaa !24
  %t272 = load ptr, ptr %l18, !tbaa !29
  %t274 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t272)
  store i64 %t274, ptr %l162
  br label %bb32
bb32:
  %t275 = load i64, ptr %l160, !tbaa !24
  %t276 = load i64, ptr %l162, !tbaa !24
  %t277 = icmp slt i64 %t275, %t276
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb33, label %bb34
bb33:
  br label %bb39
bb34:
  br label %bb35
bb35:
  %t281 = load ptr, ptr %l18, !tbaa !29
  %t282 = load i64, ptr %l19, !tbaa !24
  %t285 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t281, i64 %t282)
  store i32 %t285, ptr %l167
  br label %bb36
bb36:
  %t286 = load i32, ptr %l167, !tbaa !23
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/mir:verifier", ptr %t287, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t289, i32 %t286)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t293 = load i64, ptr %l19, !tbaa !24
  %t295 = add i64 %t293, 1
  store i64 %t295, ptr %l19, !tbaa !24
  br label %bb31
bb39:
  br label %ret
bb40:
  store i64 0, ptr %l21, !tbaa !24
  %t297 = load i64, ptr %l3, !tbaa !24
  store i64 %t297, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t299 = load i64, ptr %l22, !tbaa !24
  %t300 = load i64, ptr %l21, !tbaa !24
  %t303 = icmp sgt i64 %t299, %t300
  br i1 %t303, label %bb41, label %bb42
bb41:
  %t305 = load i64, ptr %l23, !tbaa !24
  %t307 = icmp sgt i64 %t305, 0
  br i1 %t307, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l177, !tbaa !24
  br label %bb46
bb43:
  %t309 = load i64, ptr %l22, !tbaa !24
  %t310 = load i64, ptr %l21, !tbaa !24
  %t313 = sub i64 %t309, %t310
  %t314 = load i64, ptr %l23, !tbaa !24
  %t317 = add i64 %t313, %t314
  %t319 = sub i64 %t317, 1
  %t320 = load i64, ptr %l23, !tbaa !24
  %t323 = sdiv i64 %t319, %t320
  store i64 %t323, ptr %l180, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb45
bb45:
  %t325 = load i64, ptr %l180, !tbaa !24
  store i64 %t325, ptr %l177, !tbaa !24
  br label %bb46
bb46:
  %t326 = load i64, ptr %l177, !tbaa !24
  store i64 %t326, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb47
bb47:
  %t327 = load i64, ptr %l25, !tbaa !24
  %t328 = load i64, ptr %l24, !tbaa !24
  %t331 = icmp slt i64 %t327, %t328
  %t333 = xor i1 %t331, true
  br i1 %t333, label %bb48, label %bb49
bb48:
  br label %bb64
bb49:
  br label %bb50
bb50:
  %t335 = load i64, ptr %l21, !tbaa !24
  %t336 = load i64, ptr %l25, !tbaa !24
  %t337 = load i64, ptr %l23, !tbaa !24
  %t340 = mul i64 %t336, %t337
  %t343 = add i64 %t335, %t340
  store i64 %t343, ptr %l26, !tbaa !24
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/mir:verifier", ptr %t345, i32 0, i32 7
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !27
  store { i64, ptr } %t348, ptr %l199, !tbaa !27
  %t349 = load i64, ptr %l5, !tbaa !24
  %t350 = load i64, ptr %l3, !tbaa !24
  %t353 = mul i64 %t349, %t350
  %t354 = load i64, ptr %l26, !tbaa !24
  %t357 = add i64 %t353, %t354
  %t359 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !27
  %t361 = getelementptr i1, ptr %t360, i64 %t357
  %t362 = load i1, ptr %t361, !tbaa !31
  br i1 %t362, label %bb51, label %bb52
bb51:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/mir:verifier", ptr %t364, i32 0, i32 14
  %t367 = load { i64, ptr }, ptr %t366, !tbaa !27
  store { i64, ptr } %t367, ptr %l208, !tbaa !27
  %t368 = load i64, ptr %l26, !tbaa !24
  %t370 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr i1, ptr %t371, i64 %t368
  %t373 = load i1, ptr %t372, !tbaa !31
  %t375 = xor i1 %t373, true
  store i1 %t375, ptr %l206, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb53
bb53:
  %t377 = load i1, ptr %l206, !tbaa !21
  br i1 %t377, label %bb54, label %bb55
bb54:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/mir:verifier", ptr %t378, i32 0, i32 7
  %t381 = load { i64, ptr }, ptr %t380, !tbaa !27
  store { i64, ptr } %t381, ptr %l213, !tbaa !27
  %t382 = load i64, ptr %l5, !tbaa !24
  %t383 = load i64, ptr %l3, !tbaa !24
  %t386 = mul i64 %t382, %t383
  %t387 = load i64, ptr %l26, !tbaa !24
  %t390 = add i64 %t386, %t387
  %t392 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr i1, ptr %t393, i64 %t390
  store i1 false, ptr %t394, !tbaa !31
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/mir:verifier", ptr %t395, i32 0, i32 18
  store i1 true, ptr %t397, !tbaa !21
  br label %bb56
bb55:
  br label %bb56
bb56:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/mir:verifier", ptr %t398, i32 0, i32 8
  %t401 = load { i64, ptr }, ptr %t400, !tbaa !27
  store { i64, ptr } %t401, ptr %l221, !tbaa !27
  %t402 = load i64, ptr %l5, !tbaa !24
  %t403 = load i64, ptr %l3, !tbaa !24
  %t406 = mul i64 %t402, %t403
  %t407 = load i64, ptr %l26, !tbaa !24
  %t410 = add i64 %t406, %t407
  %t412 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr i1, ptr %t413, i64 %t410
  %t415 = load i1, ptr %t414, !tbaa !31
  br i1 %t415, label %bb57, label %bb58
bb57:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/mir:verifier", ptr %t417, i32 0, i32 15
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  store { i64, ptr } %t420, ptr %l230, !tbaa !27
  %t421 = load i64, ptr %l26, !tbaa !24
  %t423 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !27
  %t425 = getelementptr i1, ptr %t424, i64 %t421
  %t426 = load i1, ptr %t425, !tbaa !31
  %t428 = xor i1 %t426, true
  store i1 %t428, ptr %l228, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb59
bb59:
  %t430 = load i1, ptr %l228, !tbaa !21
  br i1 %t430, label %bb60, label %bb61
bb60:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/mir:verifier", ptr %t431, i32 0, i32 8
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  store { i64, ptr } %t434, ptr %l235, !tbaa !27
  %t435 = load i64, ptr %l5, !tbaa !24
  %t436 = load i64, ptr %l3, !tbaa !24
  %t439 = mul i64 %t435, %t436
  %t440 = load i64, ptr %l26, !tbaa !24
  %t443 = add i64 %t439, %t440
  %t445 = getelementptr { i64, ptr }, ptr %l235, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !27
  %t447 = getelementptr i1, ptr %t446, i64 %t443
  store i1 false, ptr %t447, !tbaa !31
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/mir:verifier", ptr %t448, i32 0, i32 18
  store i1 true, ptr %t450, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t451 = load i64, ptr %l25, !tbaa !24
  %t453 = add i64 %t451, 1
  store i64 %t453, ptr %l25, !tbaa !24
  br label %bb47
bb64:
  store i64 0, ptr %l27, !tbaa !24
  %t455 = load i64, ptr %l4, !tbaa !24
  store i64 %t455, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t457 = load i64, ptr %l28, !tbaa !24
  %t458 = load i64, ptr %l27, !tbaa !24
  %t461 = icmp sgt i64 %t457, %t458
  br i1 %t461, label %bb65, label %bb66
bb65:
  %t463 = load i64, ptr %l29, !tbaa !24
  %t465 = icmp sgt i64 %t463, 0
  br i1 %t465, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l248, !tbaa !24
  br label %bb70
bb67:
  %t467 = load i64, ptr %l28, !tbaa !24
  %t468 = load i64, ptr %l27, !tbaa !24
  %t471 = sub i64 %t467, %t468
  %t472 = load i64, ptr %l29, !tbaa !24
  %t475 = add i64 %t471, %t472
  %t477 = sub i64 %t475, 1
  %t478 = load i64, ptr %l29, !tbaa !24
  %t481 = sdiv i64 %t477, %t478
  store i64 %t481, ptr %l251, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l251, !tbaa !24
  br label %bb69
bb69:
  %t483 = load i64, ptr %l251, !tbaa !24
  store i64 %t483, ptr %l248, !tbaa !24
  br label %bb70
bb70:
  %t484 = load i64, ptr %l248, !tbaa !24
  store i64 %t484, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb71
bb71:
  %t485 = load i64, ptr %l31, !tbaa !24
  %t486 = load i64, ptr %l30, !tbaa !24
  %t489 = icmp slt i64 %t485, %t486
  %t491 = xor i1 %t489, true
  br i1 %t491, label %bb72, label %bb73
bb72:
  br label %bb82
bb73:
  br label %bb74
bb74:
  %t493 = load i64, ptr %l27, !tbaa !24
  %t494 = load i64, ptr %l31, !tbaa !24
  %t495 = load i64, ptr %l29, !tbaa !24
  %t498 = mul i64 %t494, %t495
  %t501 = add i64 %t493, %t498
  store i64 %t501, ptr %l32, !tbaa !24
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/mir:verifier", ptr %t503, i32 0, i32 16
  %t506 = load { i64, ptr }, ptr %t505, !tbaa !27
  store { i64, ptr } %t506, ptr %l270, !tbaa !27
  %t507 = load i64, ptr %l32, !tbaa !24
  %t509 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t510 = load ptr, ptr %t509, !tbaa !27
  %t511 = getelementptr i1, ptr %t510, i64 %t507
  %t512 = load i1, ptr %t511, !tbaa !31
  br i1 %t512, label %bb75, label %bb76
bb75:
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t516 = getelementptr %"compiler/mir:verifier", ptr %t514, i32 0, i32 9
  %t517 = load { i64, ptr }, ptr %t516, !tbaa !27
  store { i64, ptr } %t517, ptr %l275, !tbaa !27
  %t518 = load i64, ptr %l5, !tbaa !24
  %t519 = load i64, ptr %l4, !tbaa !24
  %t522 = mul i64 %t518, %t519
  %t523 = load i64, ptr %l32, !tbaa !24
  %t526 = add i64 %t522, %t523
  %t528 = getelementptr { i64, ptr }, ptr %l275, i32 0, i32 1
  %t529 = load ptr, ptr %t528, !tbaa !27
  %t530 = getelementptr i1, ptr %t529, i64 %t526
  %t531 = load i1, ptr %t530, !tbaa !31
  %t533 = xor i1 %t531, true
  store i1 %t533, ptr %l273, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb77
bb77:
  %t535 = load i1, ptr %l273, !tbaa !21
  br i1 %t535, label %bb78, label %bb79
bb78:
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t538 = getelementptr %"compiler/mir:verifier", ptr %t536, i32 0, i32 9
  %t539 = load { i64, ptr }, ptr %t538, !tbaa !27
  store { i64, ptr } %t539, ptr %l284, !tbaa !27
  %t540 = load i64, ptr %l5, !tbaa !24
  %t541 = load i64, ptr %l4, !tbaa !24
  %t544 = mul i64 %t540, %t541
  %t545 = load i64, ptr %l32, !tbaa !24
  %t548 = add i64 %t544, %t545
  %t550 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t551 = load ptr, ptr %t550, !tbaa !27
  %t552 = getelementptr i1, ptr %t551, i64 %t548
  store i1 true, ptr %t552, !tbaa !31
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/mir:verifier", ptr %t553, i32 0, i32 18
  store i1 true, ptr %t555, !tbaa !21
  br label %bb80
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t556 = load i64, ptr %l31, !tbaa !24
  %t558 = add i64 %t556, 1
  store i64 %t558, ptr %l31, !tbaa !24
  br label %bb71
bb82:
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t562 = getelementptr %"compiler/mir:verifier", ptr %t560, i32 0, i32 11
  %t563 = load { i64, ptr }, ptr %t562, !tbaa !27
  store { i64, ptr } %t563, ptr %l294, !tbaa !27
  %t564 = load i64, ptr %l5, !tbaa !24
  %t566 = getelementptr { i64, ptr }, ptr %l294, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = getelementptr i64, ptr %t567, i64 %t564
  %t569 = load i64, ptr %t568, !tbaa !34
  store i64 %t569, ptr %l296, !tbaa !24
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t572 = getelementptr %"compiler/mir:verifier", ptr %t570, i32 0, i32 17
  %t574 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t572)
  store i64 %t574, ptr %l299
  br label %bb83
bb83:
  %t575 = load i64, ptr %l296, !tbaa !24
  %t576 = load i64, ptr %l299, !tbaa !24
  %t577 = icmp eq i64 %t575, %t576
  store i1 %t577, ptr %l33, !tbaa !21
  %t579 = load i1, ptr %l33, !tbaa !21
  br i1 %t579, label %bb84, label %bb85
bb84:
  store i64 0, ptr %l34, !tbaa !24
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = getelementptr %"compiler/mir:verifier", ptr %t581, i32 0, i32 17
  %t585 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t583)
  store i64 %t585, ptr %l304
  br label %bb86
bb85:
  br label %bb104
bb86:
  %t586 = load i64, ptr %l304, !tbaa !24
  store i64 %t586, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t587 = load i64, ptr %l35, !tbaa !24
  %t588 = load i64, ptr %l34, !tbaa !24
  %t591 = icmp sgt i64 %t587, %t588
  br i1 %t591, label %bb87, label %bb88
bb87:
  %t593 = load i64, ptr %l36, !tbaa !24
  %t595 = icmp sgt i64 %t593, 0
  br i1 %t595, label %bb89, label %bb90
bb88:
  store i64 0, ptr %l308, !tbaa !24
  br label %bb92
bb89:
  %t597 = load i64, ptr %l35, !tbaa !24
  %t598 = load i64, ptr %l34, !tbaa !24
  %t601 = sub i64 %t597, %t598
  %t602 = load i64, ptr %l36, !tbaa !24
  %t605 = add i64 %t601, %t602
  %t607 = sub i64 %t605, 1
  %t608 = load i64, ptr %l36, !tbaa !24
  %t611 = sdiv i64 %t607, %t608
  store i64 %t611, ptr %l311, !tbaa !24
  br label %bb91
bb90:
  store i64 0, ptr %l311, !tbaa !24
  br label %bb91
bb91:
  %t613 = load i64, ptr %l311, !tbaa !24
  store i64 %t613, ptr %l308, !tbaa !24
  br label %bb92
bb92:
  %t614 = load i64, ptr %l308, !tbaa !24
  store i64 %t614, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb93
bb93:
  %t615 = load i64, ptr %l38, !tbaa !24
  %t616 = load i64, ptr %l37, !tbaa !24
  %t619 = icmp slt i64 %t615, %t616
  %t621 = xor i1 %t619, true
  br i1 %t621, label %bb94, label %bb95
bb94:
  br label %bb103
bb95:
  br label %bb96
bb96:
  %t623 = load i64, ptr %l34, !tbaa !24
  %t624 = load i64, ptr %l38, !tbaa !24
  %t625 = load i64, ptr %l36, !tbaa !24
  %t628 = mul i64 %t624, %t625
  %t631 = add i64 %t623, %t628
  store i64 %t631, ptr %l39, !tbaa !24
  %t633 = load i1, ptr %l33, !tbaa !21
  br i1 %t633, label %bb97, label %bb98
bb97:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/mir:verifier", ptr %t635, i32 0, i32 12
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t640 = getelementptr %"compiler/mir:verifier", ptr %t638, i32 0, i32 10
  %t641 = load { i64, ptr }, ptr %t640, !tbaa !27
  store { i64, ptr } %t641, ptr %l334, !tbaa !27
  %t642 = load i64, ptr %l5, !tbaa !24
  %t644 = getelementptr { i64, ptr }, ptr %l334, i32 0, i32 1
  %t645 = load ptr, ptr %t644, !tbaa !27
  %t646 = getelementptr i64, ptr %t645, i64 %t642
  %t647 = load i64, ptr %t646, !tbaa !34
  %t648 = load i64, ptr %l39, !tbaa !24
  %t651 = add i64 %t647, %t648
  %t654 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t637, i64 %t651)
  store i32 %t654, ptr %l339
  br label %bb99
bb98:
  store i1 false, ptr %l330, !tbaa !21
  br label %bb101
bb99:
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t657 = getelementptr %"compiler/mir:verifier", ptr %t655, i32 0, i32 17
  %t658 = load i64, ptr %l39, !tbaa !24
  %t661 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t657, i64 %t658)
  store i32 %t661, ptr %l343
  br label %bb100
bb100:
  %t662 = load i32, ptr %l339, !tbaa !23
  %t663 = load i32, ptr %l343, !tbaa !23
  %t664 = icmp eq i32 %t662, %t663
  store i1 %t664, ptr %l330, !tbaa !21
  br label %bb101
bb101:
  %t666 = load i1, ptr %l330, !tbaa !21
  store i1 %t666, ptr %l33, !tbaa !21
  br label %bb102
bb102:
  %t667 = load i64, ptr %l38, !tbaa !24
  %t669 = add i64 %t667, 1
  store i64 %t669, ptr %l38, !tbaa !24
  br label %bb93
bb103:
  br label %bb104
bb104:
  %t671 = load i1, ptr %l33, !tbaa !21
  %t673 = xor i1 %t671, true
  br i1 %t673, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s24
  %t675 = load ptr, ptr %l0, !tbaa !29
  store ptr %t675, ptr %l349, !tbaa !29
  %t676 = load i32, ptr %l1, !tbaa !23
  store i32 %t676, ptr %l350, !tbaa !23
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t679 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %s24, ptr %t677)
  store { i64, ptr } %t679, ptr %l352
  br label %bb107
bb106:
  br label %bb110
bb107:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load i32, ptr %l1, !tbaa !23
  %t684 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackOf(ptr %v0, ptr %s24, ptr %t680, i32 %t681)
  store { i64, ptr } %t684, ptr %l355
  br label %bb108
bb108:
  %t685 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t686 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t687 = load i32, ptr %l350, !tbaa !23
  %t688 = sext i32 %t687 to i64
  %t689 = call i64 @__olang_fmt_i64(ptr null, i64 %t688)
  %t690 = add i64 %t686, %t689
  %t691 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t692 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t693 = add i64 %t690, %t692
  %t694 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t695 = extractvalue { i64, ptr } %t694, 1
  %t696 = extractvalue { i64, ptr } %t694, 0
  %t697 = add i64 %t693, %t696
  %t698 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t699 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t700 = add i64 %t697, %t699
  %t701 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t702 = extractvalue { i64, ptr } %t701, 1
  %t703 = extractvalue { i64, ptr } %t701, 0
  %t704 = add i64 %t700, %t703
  %t705 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t704)
  call void @olang_textcopy(ptr %t705, ptr %t685, i64 %t686)
  %t706 = getelementptr i8, ptr %t705, i64 %t686
  %t707 = call i64 @__olang_fmt_i64(ptr %t706, i64 %t688)
  %t708 = getelementptr i8, ptr %t706, i64 %t689
  call void @olang_textcopy(ptr %t708, ptr %t691, i64 %t692)
  %t709 = getelementptr i8, ptr %t708, i64 %t692
  call void @olang_textcopy(ptr %t709, ptr %t695, i64 %t696)
  %t710 = getelementptr i8, ptr %t709, i64 %t696
  call void @olang_textcopy(ptr %t710, ptr %t698, i64 %t699)
  %t711 = getelementptr i8, ptr %t710, i64 %t699
  call void @olang_textcopy(ptr %t711, ptr %t702, i64 %t703)
  %t712 = insertvalue { i64, ptr } undef, i64 %t704, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t705, 1
  %t715 = extractvalue { i64, ptr } %t713, 0
  %t716 = extractvalue { i64, ptr } %t713, 1
  %t717 = mul i64 %t715, 1
  %t718 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t717)
  call void @llvm.memcpy.p0.p0.i64(ptr %t718, ptr %t716, i64 %t717, i1 false)
  %t719 = insertvalue { i64, ptr } undef, i64 %t715, 0
  %t720 = insertvalue { i64, ptr } %t719, ptr %t718, 1
  %t721 = load ptr, ptr %l349, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s24, ptr %t721, { i64, ptr } %t720)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s24)
  br label %bb110
bb110:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l19 = alloca i1
  %l27 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i32
  %l43 = alloca i32
  %l46 = alloca i1
  %l49 = alloca i32
  %l52 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i1
  %l62 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i64
  %l74 = alloca i64
  %l78 = alloca ptr
  %l81 = alloca i32
  %l84 = alloca i32
  %l85 = alloca i1
  %l86 = alloca i1
  %l94 = alloca i32
  %l97 = alloca i1
  %l100 = alloca i32
  %l103 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l111 = alloca i32
  %l112 = alloca { i64, ptr }
  %l124 = alloca i64
  %l127 = alloca i64
  %l146 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l152 = alloca i1
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  %t12 = load i32, ptr %l2, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  store i1 %t16, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l19, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t22 = load i32, ptr %l2, !tbaa !23
  %t26 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t20, i32 %t21, i32 %t22)
  store i1 %t26, ptr %l27
  br label %bb7
bb7:
  %t27 = load i1, ptr %l27, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = load i32, ptr %l1, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  %t37 = load ptr, ptr @__olang_prog_scope
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t37, ptr %t35, i32 %t36)
  store i1 %t40, ptr %l34
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t41 = load i1, ptr %l34, !tbaa !21
  br i1 %t41, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb17
bb15:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t44 = load ptr, ptr @__olang_prog_scope
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t44, ptr %t42, i32 %t43)
  store i32 %t47, ptr %l38
  br label %bb16
bb16:
  %t48 = load i32, ptr %l38, !range !{i32 0, i32 33}
  %t50 = trunc i64 21 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l35, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
bb18:
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t55 = load i32, ptr %l1, !tbaa !23
  %t56 = load ptr, ptr @__olang_prog_scope
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t56, ptr %t54, i32 %t55)
  store i32 %t59, ptr %l43
  br label %bb19
bb19:
  %t60 = load i32, ptr %l43, !range !{i32 0, i32 33}
  %t62 = trunc i64 21 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb20, label %bb21
bb20:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t66 = load i32, ptr %l2, !tbaa !23
  %t67 = load ptr, ptr @__olang_prog_scope
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t67, ptr %t65, i32 %t66)
  store i32 %t70, ptr %l49
  br label %bb22
bb21:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb23
bb22:
  %t71 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t73 = trunc i64 21 to i32
  %t74 = icmp eq i32 %t71, %t73
  store i1 %t74, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t76 = load i1, ptr %l46, !tbaa !21
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t77 = load ptr, ptr %l3, !tbaa !29
  store ptr %t77, ptr %l52, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t79 = load i32, ptr %l1, !tbaa !23
  %t80 = load ptr, ptr @__olang_prog_scope
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %t80, ptr %t78, i32 %t79)
  store i32 %t83, ptr %l55
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t85 = load i32, ptr %l2, !tbaa !23
  %t86 = load ptr, ptr @__olang_prog_scope
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %t86, ptr %t84, i32 %t85)
  store i32 %t89, ptr %l58
  br label %bb27
bb27:
  %t90 = load ptr, ptr @__olang_prog_scope
  %t91 = load ptr, ptr %l52, !tbaa !29
  %t92 = load i32, ptr %l55, !tbaa !23
  %t93 = load i32, ptr %l58, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t90, ptr %t91, i32 %t92, i32 %t93)
  store i1 %t94, ptr %l59
  br label %bb28
bb28:
  %t95 = load i1, ptr %l59, !tbaa !21
  store i1 %t95, ptr %rv
  br label %ret
bb29:
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t98 = load ptr, ptr @__olang_prog_scope
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t98, ptr %t96, i32 %t97)
  store i1 %t101, ptr %l62
  br label %bb30
bb30:
  %t102 = load i1, ptr %l62, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t104 = load i32, ptr %l2, !tbaa !23
  %t105 = load ptr, ptr @__olang_prog_scope
  %t108 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t105, ptr %t103, i32 %t104)
  store i1 %t108, ptr %l66
  br label %bb33
bb32:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb34
bb33:
  %t109 = load i1, ptr %l66, !tbaa !21
  store i1 %t109, ptr %l63, !tbaa !21
  br label %bb34
bb34:
  %t110 = load i1, ptr %l63, !tbaa !21
  br i1 %t110, label %bb35, label %bb36
bb35:
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t112 = load i32, ptr %l1, !tbaa !23
  %t113 = load ptr, ptr @__olang_prog_scope
  %t116 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t113, ptr %t111, i32 %t112)
  store i64 %t116, ptr %l69
  br label %bb37
bb36:
  br label %bb45
bb37:
  %t117 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t118 = load i64, ptr %l69, !tbaa !24
  %t120 = or i64 %t118, %t117
  store i64 %t120, ptr %l4, !tbaa !24
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t123 = load i32, ptr %l2, !tbaa !23
  %t124 = load ptr, ptr @__olang_prog_scope
  %t127 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t124, ptr %t122, i32 %t123)
  store i64 %t127, ptr %l74
  br label %bb38
bb38:
  %t128 = load i64, ptr @G_2ecompiler_2ftypes_2eSpread, !tbaa !24
  %t130 = xor i64 %t128, -1
  %t131 = load i64, ptr %l74, !tbaa !24
  %t133 = and i64 %t131, %t130
  store i64 %t133, ptr %l5, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l78, !tbaa !29
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t137 = load i32, ptr %l1, !tbaa !23
  %t138 = load ptr, ptr @__olang_prog_scope
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t138, ptr %t136, i32 %t137)
  store i32 %t141, ptr %l81
  br label %bb39
bb39:
  %t142 = load ptr, ptr %l3, !tbaa !29
  %t143 = load i32, ptr %l2, !tbaa !23
  %t144 = load ptr, ptr @__olang_prog_scope
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t144, ptr %t142, i32 %t143)
  store i32 %t147, ptr %l84
  br label %bb40
bb40:
  %t148 = load ptr, ptr %l78, !tbaa !29
  %t149 = load i32, ptr %l81, !tbaa !23
  %t150 = load i32, ptr %l84, !tbaa !23
  %t151 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t148, i32 %t149, i32 %t150)
  store i1 %t151, ptr %l85
  br label %bb41
bb41:
  %t152 = load i1, ptr %l85, !tbaa !21
  br i1 %t152, label %bb42, label %bb43
bb42:
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l5, !tbaa !24
  %t157 = or i64 %t153, %t154
  %t158 = load i64, ptr %l4, !tbaa !24
  %t161 = icmp eq i64 %t157, %t158
  store i1 %t161, ptr %l86, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb44
bb44:
  %t163 = load i1, ptr %l86, !tbaa !21
  store i1 %t163, ptr %rv
  br label %ret
bb45:
  %t164 = load ptr, ptr %l3, !tbaa !29
  %t165 = load i32, ptr %l1, !tbaa !23
  %t166 = load ptr, ptr @__olang_prog_scope
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t166, ptr %t164, i32 %t165)
  store i32 %t169, ptr %l94
  br label %bb46
bb46:
  %t170 = load i32, ptr %l94, !range !{i32 0, i32 33}
  %t172 = trunc i64 22 to i32
  %t173 = icmp eq i32 %t170, %t172
  br i1 %t173, label %bb47, label %bb48
bb47:
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t176 = load i32, ptr %l2, !tbaa !23
  %t177 = load ptr, ptr @__olang_prog_scope
  %t180 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t177, ptr %t175, i32 %t176)
  store i32 %t180, ptr %l100
  br label %bb49
bb48:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb50
bb49:
  %t181 = load i32, ptr %l100, !range !{i32 0, i32 33}
  %t183 = trunc i64 22 to i32
  %t184 = icmp eq i32 %t181, %t183
  store i1 %t184, ptr %l97, !tbaa !21
  br label %bb50
bb50:
  %t186 = load i1, ptr %l97, !tbaa !21
  br i1 %t186, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s6
  %t187 = load ptr, ptr %l3, !tbaa !29
  store ptr %t187, ptr %l103, !tbaa !29
  %t188 = load ptr, ptr %l3, !tbaa !29
  %t189 = load i32, ptr %l1, !tbaa !23
  %t190 = load ptr, ptr @__olang_prog_scope
  %t193 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t190, ptr %t188, i32 %t189)
  store i32 %t193, ptr %l106
  br label %bb53
bb52:
  br label %bb76
bb53:
  %t194 = load ptr, ptr @__olang_prog_scope
  %t195 = load ptr, ptr %l103, !tbaa !29
  %t196 = load i32, ptr %l106, !tbaa !23
  %t197 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t194, ptr %s6, ptr %t195, i32 %t196)
  store { i64, ptr } %t197, ptr %l107
  br label %bb54
bb54:
  %t198 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t198, ptr %l6, !tbaa !27
  %t199 = load ptr, ptr %l3, !tbaa !29
  store ptr %t199, ptr %l108, !tbaa !29
  %t200 = load ptr, ptr %l3, !tbaa !29
  %t201 = load i32, ptr %l2, !tbaa !23
  %t202 = load ptr, ptr @__olang_prog_scope
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t202, ptr %t200, i32 %t201)
  store i32 %t205, ptr %l111
  br label %bb55
bb55:
  %t206 = load ptr, ptr @__olang_prog_scope
  %t207 = load ptr, ptr %l108, !tbaa !29
  %t208 = load i32, ptr %l111, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t206, ptr %s6, ptr %t207, i32 %t208)
  store { i64, ptr } %t209, ptr %l112
  br label %bb56
bb56:
  %t210 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t210, ptr %l7, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t219 = icmp ne i64 %t213, %t216
  br i1 %t219, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s6)
  store i1 false, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  store i64 0, ptr %l8, !tbaa !24
  %t222 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t222, 0
  store i64 %t224, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t226 = load i64, ptr %l9, !tbaa !24
  %t227 = load i64, ptr %l8, !tbaa !24
  %t230 = icmp sgt i64 %t226, %t227
  br i1 %t230, label %bb60, label %bb61
bb60:
  %t232 = load i64, ptr %l10, !tbaa !24
  %t234 = icmp sgt i64 %t232, 0
  br i1 %t234, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb65
bb62:
  %t236 = load i64, ptr %l9, !tbaa !24
  %t237 = load i64, ptr %l8, !tbaa !24
  %t240 = sub i64 %t236, %t237
  %t241 = load i64, ptr %l10, !tbaa !24
  %t244 = add i64 %t240, %t241
  %t246 = sub i64 %t244, 1
  %t247 = load i64, ptr %l10, !tbaa !24
  %t250 = sdiv i64 %t246, %t247
  store i64 %t250, ptr %l127, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb64
bb64:
  %t252 = load i64, ptr %l127, !tbaa !24
  store i64 %t252, ptr %l124, !tbaa !24
  br label %bb65
bb65:
  %t253 = load i64, ptr %l124, !tbaa !24
  store i64 %t253, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb66
bb66:
  %t254 = load i64, ptr %l12, !tbaa !24
  %t255 = load i64, ptr %l11, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb67, label %bb68
bb67:
  br label %bb75
bb68:
  br label %bb69
bb69:
  %t262 = load i64, ptr %l8, !tbaa !24
  %t263 = load i64, ptr %l12, !tbaa !24
  %t264 = load i64, ptr %l10, !tbaa !24
  %t267 = mul i64 %t263, %t264
  %t270 = add i64 %t262, %t267
  store i64 %t270, ptr %l13, !tbaa !24
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t273, ptr %l146, !tbaa !27
  %t274 = load i64, ptr %l13, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr i32, ptr %t277, i64 %t274
  %t279 = load i32, ptr %t278, !tbaa !33
  %t280 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t280, ptr %l149, !tbaa !27
  %t281 = load i64, ptr %l13, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i32, ptr %t284, i64 %t281
  %t286 = load i32, ptr %t285, !tbaa !33
  %t290 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t272, i32 %t279, i32 %t286)
  store i1 %t290, ptr %l152
  br label %bb70
bb70:
  %t291 = load i1, ptr %l152, !tbaa !21
  %t292 = xor i1 %t291, true
  br i1 %t292, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s6)
  store i1 false, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t295 = load i64, ptr %l12, !tbaa !24
  %t297 = add i64 %t295, 1
  store i64 %t297, ptr %l12, !tbaa !24
  br label %bb66
bb75:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb76:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eflow(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l46 = alloca ptr
  %l49 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i64
  %l88 = alloca i64
  %l90 = alloca i64
  %l95 = alloca i32
  %l97 = alloca { i64, ptr }
  %l104 = alloca i64
  %l106 = alloca i64
  %l111 = alloca i32
  %l113 = alloca { i64, ptr }
  %l122 = alloca i64
  %l125 = alloca i64
  %l144 = alloca { i64, ptr }
  %l145 = alloca i64
  %l149 = alloca %"compiler/mir:Local"
  %l161 = alloca i64
  %l164 = alloca i64
  %l183 = alloca { i64, ptr }
  %l200 = alloca i64
  %l203 = alloca i64
  %l222 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 9
  %t9 = load ptr, ptr @__olang_prog_scope
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t9, ptr %t8)
  store i64 %t11, ptr %l35
  br label %bb1
bb1:
  %t12 = load i64, ptr %l35, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 7
  %t16 = load ptr, ptr @__olang_prog_scope
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %t16, ptr %t15)
  store i64 %t18, ptr %l38
  br label %bb2
bb2:
  %t19 = load i64, ptr %l38, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/mir:Fn", ptr %t20, i32 0, i32 8
  %t23 = load ptr, ptr @__olang_prog_scope
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t23, ptr %t22)
  store i64 %t25, ptr %l41
  br label %bb3
bb3:
  %t26 = load i64, ptr %l41, !tbaa !24
  store i64 %t26, ptr %l4, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l42, !tbaa !29
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %l43, !tbaa !24
  %t29 = load i64, ptr %l43, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb4, label %bb5
bb4:
  %t32 = load i64, ptr %l43, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = load ptr, ptr %l42, !tbaa !29
  %t39 = getelementptr %"compiler/mir:verifier", ptr %t38, i32 0, i32 6
  store { i64, ptr } %t36, ptr %t39, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l46, !tbaa !29
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = mul i64 %t41, %t42
  store i64 %t45, ptr %l49, !tbaa !24
  %t46 = load i64, ptr %l49, !tbaa !24
  %t47 = icmp sge i64 %t46, 0
  br i1 %t47, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3fc64ab4d22c7cd1_9c9bbb4060ef765d)
  unreachable
bb6:
  %t49 = load i64, ptr %l49, !tbaa !24
  %t50 = mul i64 %t49, 1
  %t51 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  %t55 = load ptr, ptr %l46, !tbaa !29
  %t56 = getelementptr %"compiler/mir:verifier", ptr %t55, i32 0, i32 7
  store { i64, ptr } %t53, ptr %t56, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l52, !tbaa !29
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = mul i64 %t58, %t59
  store i64 %t62, ptr %l55, !tbaa !24
  %t63 = load i64, ptr %l55, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  br i1 %t64, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_82a5970c46c34ec4_64144421b638a2b0)
  unreachable
bb8:
  %t66 = load i64, ptr %l55, !tbaa !24
  %t67 = mul i64 %t66, 1
  %t68 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t72 = load ptr, ptr %l52, !tbaa !29
  %t73 = getelementptr %"compiler/mir:verifier", ptr %t72, i32 0, i32 8
  store { i64, ptr } %t70, ptr %t73, !tbaa !27
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l58, !tbaa !29
  %t75 = load i64, ptr %l2, !tbaa !24
  %t76 = load i64, ptr %l4, !tbaa !24
  %t79 = mul i64 %t75, %t76
  store i64 %t79, ptr %l61, !tbaa !24
  %t80 = load i64, ptr %l61, !tbaa !24
  %t81 = icmp sge i64 %t80, 0
  br i1 %t81, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2ac31f2db6082ba7_5ac69b59325af853)
  unreachable
bb10:
  %t83 = load i64, ptr %l61, !tbaa !24
  %t84 = mul i64 %t83, 1
  %t85 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t89 = load ptr, ptr %l58, !tbaa !29
  %t90 = getelementptr %"compiler/mir:verifier", ptr %t89, i32 0, i32 9
  store { i64, ptr } %t87, ptr %t90, !tbaa !27
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l64, !tbaa !29
  %t92 = load i64, ptr %l2, !tbaa !24
  store i64 %t92, ptr %l65, !tbaa !24
  %t93 = load i64, ptr %l65, !tbaa !24
  %t94 = icmp sge i64 %t93, 0
  br i1 %t94, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_397ae699ba890fb2_f6680c8259f4281e)
  unreachable
bb12:
  %t96 = load i64, ptr %l65, !tbaa !24
  %t97 = icmp sle i64 %t96, 1152921504606846975
  br i1 %t97, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2836fb8ea59de3a5_79eeb5d0a68fc1c9)
  unreachable
bb14:
  %t99 = load i64, ptr %l65, !tbaa !24
  %t100 = mul i64 %t99, 8
  %t101 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t105 = load ptr, ptr %l64, !tbaa !29
  %t106 = getelementptr %"compiler/mir:verifier", ptr %t105, i32 0, i32 10
  store { i64, ptr } %t103, ptr %t106, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l69, !tbaa !29
  %t108 = load i64, ptr %l2, !tbaa !24
  store i64 %t108, ptr %l70, !tbaa !24
  %t109 = load i64, ptr %l70, !tbaa !24
  %t110 = icmp sge i64 %t109, 0
  br i1 %t110, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2836fb8ea59de3a5_79eeb5d0a68fc1c9)
  unreachable
bb16:
  %t112 = load i64, ptr %l70, !tbaa !24
  %t113 = icmp sle i64 %t112, 1152921504606846975
  br i1 %t113, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_13b0920ad4a1e938_72d556b41507b57c)
  unreachable
bb18:
  %t115 = load i64, ptr %l70, !tbaa !24
  %t116 = mul i64 %t115, 8
  %t117 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t121 = load ptr, ptr %l69, !tbaa !29
  %t122 = getelementptr %"compiler/mir:verifier", ptr %t121, i32 0, i32 11
  store { i64, ptr } %t119, ptr %t122, !tbaa !27
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l74, !tbaa !29
  %t124 = load i64, ptr %l3, !tbaa !24
  store i64 %t124, ptr %l75, !tbaa !24
  %t125 = load i64, ptr %l75, !tbaa !24
  %t126 = icmp sge i64 %t125, 0
  br i1 %t126, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_13b0920ad4a1e938_72d556b41507b57c)
  unreachable
bb20:
  %t128 = load i64, ptr %l75, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  %t134 = load ptr, ptr %l74, !tbaa !29
  %t135 = getelementptr %"compiler/mir:verifier", ptr %t134, i32 0, i32 14
  store { i64, ptr } %t132, ptr %t135, !tbaa !27
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l78, !tbaa !29
  %t137 = load i64, ptr %l3, !tbaa !24
  store i64 %t137, ptr %l79, !tbaa !24
  %t138 = load i64, ptr %l79, !tbaa !24
  %t139 = icmp sge i64 %t138, 0
  br i1 %t139, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f0f79482ff998b1b_575016ccefde52df)
  unreachable
bb22:
  %t141 = load i64, ptr %l79, !tbaa !24
  %t142 = mul i64 %t141, 1
  %t143 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t147 = load ptr, ptr %l78, !tbaa !29
  %t148 = getelementptr %"compiler/mir:verifier", ptr %t147, i32 0, i32 15
  store { i64, ptr } %t145, ptr %t148, !tbaa !27
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l82, !tbaa !29
  %t150 = load i64, ptr %l4, !tbaa !24
  store i64 %t150, ptr %l83, !tbaa !24
  %t151 = load i64, ptr %l83, !tbaa !24
  %t152 = icmp sge i64 %t151, 0
  br i1 %t152, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a4c79ab2e91ac186_f4797f1baf8f450a)
  unreachable
bb24:
  %t154 = load i64, ptr %l83, !tbaa !24
  %t155 = mul i64 %t154, 1
  %t156 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t155)
  %t157 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t160 = load ptr, ptr %l82, !tbaa !29
  %t161 = getelementptr %"compiler/mir:verifier", ptr %t160, i32 0, i32 16
  store { i64, ptr } %t158, ptr %t161, !tbaa !27
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr %"compiler/mir:Fn", ptr %t162, i32 0, i32 4
  store ptr %t164, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2c486f9205676389_1881cd4b4e7e41e5)
  unreachable
bb26:
  %t166 = load i64, ptr %l6, !tbaa !24
  store i64 %t166, ptr %l88, !tbaa !24
  %t167 = load ptr, ptr %l5, !tbaa !29
  %t168 = load ptr, ptr @__olang_prog_scope
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t168, ptr %t167)
  store i64 %t170, ptr %l90
  br label %bb27
bb27:
  %t171 = load i64, ptr %l88, !tbaa !24
  %t172 = load i64, ptr %l90, !tbaa !24
  %t173 = icmp slt i64 %t171, %t172
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb28, label %bb29
bb28:
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t177 = load ptr, ptr %l5, !tbaa !29
  %t178 = load i64, ptr %l6, !tbaa !24
  %t179 = load ptr, ptr @__olang_prog_scope
  %t182 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %t179, ptr %t177, i64 %t178)
  store i32 %t182, ptr %l95
  br label %bb31
bb31:
  %t183 = load i32, ptr %l95, !tbaa !23
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/mir:verifier", ptr %t184, i32 0, i32 14
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  store { i64, ptr } %t187, ptr %l97, !tbaa !27
  %t190 = sext i32 %t183 to i64
  %t192 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i1, ptr %t193, i64 %t190
  store i1 true, ptr %t194, !tbaa !31
  br label %bb32
bb32:
  %t195 = load i64, ptr %l6, !tbaa !24
  %t197 = add i64 %t195, 1
  store i64 %t197, ptr %l6, !tbaa !24
  br label %bb26
bb33:
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr %"compiler/mir:Fn", ptr %t199, i32 0, i32 5
  store ptr %t201, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb34
bb34:
  %t203 = load i64, ptr %l9, !tbaa !24
  store i64 %t203, ptr %l104, !tbaa !24
  %t204 = load ptr, ptr %l8, !tbaa !29
  %t205 = load ptr, ptr @__olang_prog_scope
  %t207 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t205, ptr %t204)
  store i64 %t207, ptr %l106
  br label %bb35
bb35:
  %t208 = load i64, ptr %l104, !tbaa !24
  %t209 = load i64, ptr %l106, !tbaa !24
  %t210 = icmp slt i64 %t208, %t209
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t214 = load ptr, ptr %l8, !tbaa !29
  %t215 = load i64, ptr %l9, !tbaa !24
  %t216 = load ptr, ptr @__olang_prog_scope
  %t219 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %t216, ptr %t214, i64 %t215)
  store i32 %t219, ptr %l111
  br label %bb39
bb39:
  %t220 = load i32, ptr %l111, !tbaa !23
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/mir:verifier", ptr %t221, i32 0, i32 14
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  store { i64, ptr } %t224, ptr %l113, !tbaa !27
  %t227 = sext i32 %t220 to i64
  %t229 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr i1, ptr %t230, i64 %t227
  store i1 true, ptr %t231, !tbaa !31
  br label %bb40
bb40:
  %t232 = load i64, ptr %l9, !tbaa !24
  %t234 = add i64 %t232, 1
  store i64 %t234, ptr %l9, !tbaa !24
  br label %bb34
bb41:
  store i64 0, ptr %l11, !tbaa !24
  %t236 = load i64, ptr %l3, !tbaa !24
  store i64 %t236, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t238 = load i64, ptr %l12, !tbaa !24
  %t239 = load i64, ptr %l11, !tbaa !24
  %t242 = icmp sgt i64 %t238, %t239
  br i1 %t242, label %bb42, label %bb43
bb42:
  %t244 = load i64, ptr %l13, !tbaa !24
  %t246 = icmp sgt i64 %t244, 0
  br i1 %t246, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb47
bb44:
  %t248 = load i64, ptr %l12, !tbaa !24
  %t249 = load i64, ptr %l11, !tbaa !24
  %t252 = sub i64 %t248, %t249
  %t253 = load i64, ptr %l13, !tbaa !24
  %t256 = add i64 %t252, %t253
  %t258 = sub i64 %t256, 1
  %t259 = load i64, ptr %l13, !tbaa !24
  %t262 = sdiv i64 %t258, %t259
  store i64 %t262, ptr %l125, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb46
bb46:
  %t264 = load i64, ptr %l125, !tbaa !24
  store i64 %t264, ptr %l122, !tbaa !24
  br label %bb47
bb47:
  %t265 = load i64, ptr %l122, !tbaa !24
  store i64 %t265, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb48
bb48:
  %t266 = load i64, ptr %l15, !tbaa !24
  %t267 = load i64, ptr %l14, !tbaa !24
  %t270 = icmp slt i64 %t266, %t267
  %t272 = xor i1 %t270, true
  br i1 %t272, label %bb49, label %bb50
bb49:
  br label %bb54
bb50:
  br label %bb51
bb51:
  %t274 = load i64, ptr %l11, !tbaa !24
  %t275 = load i64, ptr %l15, !tbaa !24
  %t276 = load i64, ptr %l13, !tbaa !24
  %t279 = mul i64 %t275, %t276
  %t282 = add i64 %t274, %t279
  store i64 %t282, ptr %l16, !tbaa !24
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/mir:verifier", ptr %t284, i32 0, i32 15
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  store { i64, ptr } %t287, ptr %l144, !tbaa !27
  %t288 = load i64, ptr %l16, !tbaa !24
  store i64 %t288, ptr %l145, !tbaa !24
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr %"compiler/mir:Fn", ptr %t289, i32 0, i32 7
  %t292 = load i64, ptr %l16, !tbaa !24
  %t293 = load ptr, ptr @__olang_prog_scope
  %t296 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t293, ptr %t291, i64 %t292)
  store %"compiler/mir:Local" %t296, ptr %l149
  br label %bb52
bb52:
  %t297 = getelementptr %"compiler/mir:Local", ptr %l149, i32 0, i32 4
  %t298 = load { i64, [1 x i64] }, ptr %t297
  %t300 = extractvalue { i64, [1 x i64] } %t298, 0
  %t301 = icmp eq i64 %t300, 3
  %t303 = load i64, ptr %l145, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i1, ptr %t305, i64 %t303
  store i1 %t301, ptr %t306, !tbaa !31
  br label %bb53
bb53:
  %t307 = load i64, ptr %l15, !tbaa !24
  %t309 = add i64 %t307, 1
  store i64 %t309, ptr %l15, !tbaa !24
  br label %bb48
bb54:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/mir:verifier", ptr %t311, i32 0, i32 5
  store i1 false, ptr %t313, !tbaa !21
  %t314 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t314, i32 0)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/mir:verifier", ptr %t316, i32 0, i32 18
  store i1 false, ptr %t318, !tbaa !21
  store i64 0, ptr %l17, !tbaa !24
  %t319 = load i64, ptr %l2, !tbaa !24
  store i64 %t319, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t321 = load i64, ptr %l18, !tbaa !24
  %t322 = load i64, ptr %l17, !tbaa !24
  %t325 = icmp sgt i64 %t321, %t322
  br i1 %t325, label %bb57, label %bb58
bb57:
  %t327 = load i64, ptr %l19, !tbaa !24
  %t329 = icmp sgt i64 %t327, 0
  br i1 %t329, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb62
bb59:
  %t331 = load i64, ptr %l18, !tbaa !24
  %t332 = load i64, ptr %l17, !tbaa !24
  %t335 = sub i64 %t331, %t332
  %t336 = load i64, ptr %l19, !tbaa !24
  %t339 = add i64 %t335, %t336
  %t341 = sub i64 %t339, 1
  %t342 = load i64, ptr %l19, !tbaa !24
  %t345 = sdiv i64 %t341, %t342
  store i64 %t345, ptr %l164, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb61
bb61:
  %t347 = load i64, ptr %l164, !tbaa !24
  store i64 %t347, ptr %l161, !tbaa !24
  br label %bb62
bb62:
  %t348 = load i64, ptr %l161, !tbaa !24
  store i64 %t348, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb63
bb63:
  %t349 = load i64, ptr %l21, !tbaa !24
  %t350 = load i64, ptr %l20, !tbaa !24
  %t353 = icmp slt i64 %t349, %t350
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb64, label %bb65
bb64:
  br label %bb72
bb65:
  br label %bb66
bb66:
  %t357 = load i64, ptr %l17, !tbaa !24
  %t358 = load i64, ptr %l21, !tbaa !24
  %t359 = load i64, ptr %l19, !tbaa !24
  %t362 = mul i64 %t358, %t359
  %t365 = add i64 %t357, %t362
  store i64 %t365, ptr %l22, !tbaa !24
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/mir:verifier", ptr %t367, i32 0, i32 6
  %t370 = load { i64, ptr }, ptr %t369, !tbaa !27
  store { i64, ptr } %t370, ptr %l183, !tbaa !27
  %t371 = load i64, ptr %l22, !tbaa !24
  %t373 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = getelementptr i1, ptr %t374, i64 %t371
  %t376 = load i1, ptr %t375, !tbaa !31
  br i1 %t376, label %bb67, label %bb68
bb67:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i64, ptr %l22, !tbaa !24
  %t381 = trunc i64 %t379 to i32
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %t378, i32 %t381)
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t385 = load i64, ptr %l21, !tbaa !24
  %t387 = add i64 %t385, 1
  store i64 %t387, ptr %l21, !tbaa !24
  br label %bb63
bb72:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/mir:verifier", ptr %t389, i32 0, i32 18
  %t392 = load i1, ptr %t391, !tbaa !21
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb73, label %bb74
bb73:
  br label %bb77
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb56
bb77:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/mir:verifier", ptr %t396, i32 0, i32 5
  store i1 true, ptr %t398, !tbaa !21
  store i64 0, ptr %l23, !tbaa !24
  %t399 = load i64, ptr %l2, !tbaa !24
  store i64 %t399, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t401 = load i64, ptr %l24, !tbaa !24
  %t402 = load i64, ptr %l23, !tbaa !24
  %t405 = icmp sgt i64 %t401, %t402
  br i1 %t405, label %bb78, label %bb79
bb78:
  %t407 = load i64, ptr %l25, !tbaa !24
  %t409 = icmp sgt i64 %t407, 0
  br i1 %t409, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l200, !tbaa !24
  br label %bb83
bb80:
  %t411 = load i64, ptr %l24, !tbaa !24
  %t412 = load i64, ptr %l23, !tbaa !24
  %t415 = sub i64 %t411, %t412
  %t416 = load i64, ptr %l25, !tbaa !24
  %t419 = add i64 %t415, %t416
  %t421 = sub i64 %t419, 1
  %t422 = load i64, ptr %l25, !tbaa !24
  %t425 = sdiv i64 %t421, %t422
  store i64 %t425, ptr %l203, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l203, !tbaa !24
  br label %bb82
bb82:
  %t427 = load i64, ptr %l203, !tbaa !24
  store i64 %t427, ptr %l200, !tbaa !24
  br label %bb83
bb83:
  %t428 = load i64, ptr %l200, !tbaa !24
  store i64 %t428, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb84
bb84:
  %t429 = load i64, ptr %l27, !tbaa !24
  %t430 = load i64, ptr %l26, !tbaa !24
  %t433 = icmp slt i64 %t429, %t430
  %t435 = xor i1 %t433, true
  br i1 %t435, label %bb85, label %bb86
bb85:
  br label %bb93
bb86:
  br label %bb87
bb87:
  %t437 = load i64, ptr %l23, !tbaa !24
  %t438 = load i64, ptr %l27, !tbaa !24
  %t439 = load i64, ptr %l25, !tbaa !24
  %t442 = mul i64 %t438, %t439
  %t445 = add i64 %t437, %t442
  store i64 %t445, ptr %l28, !tbaa !24
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/mir:verifier", ptr %t447, i32 0, i32 6
  %t450 = load { i64, ptr }, ptr %t449, !tbaa !27
  store { i64, ptr } %t450, ptr %l222, !tbaa !27
  %t451 = load i64, ptr %l28, !tbaa !24
  %t453 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !27
  %t455 = getelementptr i1, ptr %t454, i64 %t451
  %t456 = load i1, ptr %t455, !tbaa !31
  br i1 %t456, label %bb88, label %bb89
bb88:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t459 = load i64, ptr %l28, !tbaa !24
  %t461 = trunc i64 %t459 to i32
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %t458, i32 %t461)
  br label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t465 = load i64, ptr %l27, !tbaa !24
  %t467 = add i64 %t465, 1
  store i64 %t467, ptr %l27, !tbaa !24
  br label %bb84
bb93:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr %"compiler/mir:verifier", ptr %t469, i32 0, i32 3
  store i64 -1, ptr %t473, !tbaa !24
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t478 = getelementptr %"compiler/mir:verifier", ptr %t474, i32 0, i32 4
  store i64 -1, ptr %t478, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load ptr, ptr @__olang_prog_scope
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t6, ptr %t4, i32 %t5)
  store i32 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr %l7, !tbaa !23
  %t13 = icmp ne i32 %t11, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l10, !tbaa !29
  store { i64, ptr } %a3, ptr %l11, !tbaa !27
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t17, i32 %t18)
  store { i64, ptr } %t21, ptr %l14
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l17
  br label %bb5
bb5:
  %t27 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = add i64 %t39, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t28, i64 %t29)
  %t45 = getelementptr i8, ptr %t44, i64 %t29
  call void @olang_textcopy(ptr %t45, ptr %t30, i64 %t31)
  %t46 = getelementptr i8, ptr %t45, i64 %t31
  call void @olang_textcopy(ptr %t46, ptr %t34, i64 %t35)
  %t47 = getelementptr i8, ptr %t46, i64 %t35
  call void @olang_textcopy(ptr %t47, ptr %t37, i64 %t38)
  %t48 = getelementptr i8, ptr %t47, i64 %t38
  call void @olang_textcopy(ptr %t48, ptr %t41, i64 %t42)
  %t49 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t44, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t58 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t58, { i64, ptr } %t57)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t60 = load i32, ptr %l2, !tbaa !23
  store i32 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 17
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t15, i64 %t16)
  store i32 %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load i32, ptr %l14, !tbaa !23
  %t25 = icmp eq i32 %t20, %a1
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Range"
  %l7 = alloca i64
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store %"compiler/mir:Range" %a1, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/mir:verifier", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 11
  %t9 = load ptr, ptr @__olang_prog_scope
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %t9, ptr %t8)
  store i64 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load %"compiler/mir:Range", ptr %l3
  %t14 = load i64, ptr %l7, !tbaa !24
  %t15 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s0, ptr %t12, %"compiler/mir:Range" %t13, i64 %t14, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d163, i32 0, i32 1) })
  store i1 %t15, ptr %l8
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l60 = alloca { i64, [4 x i64] }
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load ptr, ptr @__olang_prog_scope
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t6, ptr %s0, ptr %t4, i32 %a2)
  store { i64, ptr } %t9, ptr %l14
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t20 = icmp ne i64 %t13, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l20, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t23, i32 %a1)
  store { i64, ptr } %t27, ptr %l23
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t35 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t43 = call i64 @__olang_fmt_i64(ptr null, i64 %t30)
  %t44 = add i64 %t41, %t43
  %t45 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t49 = sext i32 %t32 to i64
  %t50 = call i64 @__olang_fmt_i64(ptr null, i64 %t49)
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t33, i64 %t34)
  %t53 = getelementptr i8, ptr %t52, i64 %t34
  call void @olang_textcopy(ptr %t53, ptr %t36, i64 %t37)
  %t54 = getelementptr i8, ptr %t53, i64 %t37
  call void @olang_textcopy(ptr %t54, ptr %t39, i64 %t40)
  %t55 = getelementptr i8, ptr %t54, i64 %t40
  %t56 = call i64 @__olang_fmt_i64(ptr %t55, i64 %t30)
  %t57 = getelementptr i8, ptr %t55, i64 %t43
  call void @olang_textcopy(ptr %t57, ptr %t45, i64 %t46)
  %t58 = getelementptr i8, ptr %t57, i64 %t46
  %t59 = call i64 @__olang_fmt_i64(ptr %t58, i64 %t49)
  %t60 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t52, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t69 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t69, { i64, ptr } %t68)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  store i64 0, ptr %l5, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  store i64 %t73, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l5, !tbaa !24
  %t79 = icmp sgt i64 %t75, %t76
  br i1 %t79, label %bb7, label %bb8
bb7:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = icmp sgt i64 %t81, 0
  br i1 %t83, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t85 = load i64, ptr %l6, !tbaa !24
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = sub i64 %t85, %t86
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = add i64 %t89, %t90
  %t95 = sub i64 %t93, 1
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = sdiv i64 %t95, %t96
  store i64 %t99, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t101 = load i64, ptr %l37, !tbaa !24
  store i64 %t101, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t102 = load i64, ptr %l34, !tbaa !24
  store i64 %t102, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load i64, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l8, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t111 = load i64, ptr %l5, !tbaa !24
  %t112 = load i64, ptr %l9, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = mul i64 %t112, %t113
  %t119 = add i64 %t111, %t116
  store i64 %t119, ptr %l10, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l55, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l56, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/mir:Range", ptr %l3
  %t125 = load i64, ptr %l10, !tbaa !24
  %t129 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t123, %"compiler/mir:Range" %t124, i64 %t125)
  store { i64, [4 x i64] } %t129, ptr %l60
  br label %bb17
bb17:
  %t130 = load ptr, ptr %l56, !tbaa !29
  %t131 = load { i64, [4 x i64] }, ptr %l60
  %t132 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t130, { i64, [4 x i64] } %t131)
  store i32 %t132, ptr %l61
  br label %bb18
bb18:
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t133, ptr %l62, !tbaa !27
  %t134 = load i64, ptr %l10, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i32, ptr %t137, i64 %t134
  %t139 = load i32, ptr %t138, !tbaa !33
  %t140 = load i64, ptr %l10, !tbaa !24
  %t141 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t144 = call i64 @__olang_fmt_i64(ptr null, i64 %t140)
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t141, i64 %t142)
  %t147 = getelementptr i8, ptr %t146, i64 %t142
  %t148 = call i64 @__olang_fmt_i64(ptr %t147, i64 %t140)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t146, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = extractvalue { i64, ptr } %t150, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t158 = load ptr, ptr %l55, !tbaa !29
  %t159 = load i32, ptr %l61, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s4, ptr %t158, i32 %t159, i32 %t139, { i64, ptr } %t157)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t162 = load i64, ptr %l9, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l9, !tbaa !24
  br label %bb13
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2epointerLike(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/mir:verifier", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = load ptr, ptr @__olang_prog_scope
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t10, ptr %t8, i32 %a1)
  store i32 %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t14, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l9
  br label %bb2
bb2:
  %t18 = load i32, ptr %l9, !range !{i32 0, i32 33}
  store i32 %t18, ptr %l2
  %t19 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t21 = trunc i64 20 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t24 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t26 = trunc i64 19 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  %t30 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t32 = trunc i64 15 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprimType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l28 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i32
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i32
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l88 = alloca { i64, [4 x i64] }
  %l89 = alloca i32
  %l96 = alloca i32
  %l111 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i32
  %l116 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l138 = alloca i1
  %l140 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca i32
  %l147 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l165 = alloca i1
  %l167 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca ptr
  %l173 = alloca { i64, [4 x i64] }
  %l174 = alloca i32
  %l175 = alloca i32
  %l176 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i32
  %l181 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l192 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i32
  %l197 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l216 = alloca { i64, ptr }
  %l235 = alloca ptr
  %l238 = alloca { i64, [4 x i64] }
  %l239 = alloca i32
  %l240 = alloca ptr
  %l241 = alloca i32
  %l244 = alloca i32
  %l245 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i32
  %l250 = alloca { i64, ptr }
  %l252 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l263 = alloca i1
  %l265 = alloca i1
  %l269 = alloca i1
  %l273 = alloca i1
  %l277 = alloca ptr
  %l278 = alloca i32
  %l280 = alloca { i64, ptr }
  %l282 = alloca { i64, ptr }
  %l285 = alloca { i64, ptr }
  %l291 = alloca ptr
  %l292 = alloca i32
  %l294 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l299 = alloca { i64, ptr }
  %l304 = alloca ptr
  %l307 = alloca { i64, [4 x i64] }
  %l308 = alloca i32
  %l311 = alloca i32
  %l314 = alloca i32
  %l318 = alloca i1
  %l321 = alloca i1
  %l324 = alloca i1
  %l325 = alloca ptr
  %l328 = alloca i32
  %l331 = alloca i32
  %l332 = alloca i1
  %l336 = alloca i1
  %l340 = alloca i1
  %l343 = alloca ptr
  %l346 = alloca { i64, ptr }
  %l349 = alloca { i64, ptr }
  %l355 = alloca ptr
  %l358 = alloca { i64, ptr }
  %l369 = alloca i1
  %l370 = alloca i32
  %l373 = alloca i32
  %l377 = alloca i32
  %l380 = alloca ptr
  %l383 = alloca { i64, ptr }
  %l389 = alloca ptr
  %l392 = alloca { i64, ptr }
  %l403 = alloca i1
  %l405 = alloca ptr
  %l406 = alloca i32
  %l408 = alloca { i64, ptr }
  %l410 = alloca { i64, ptr }
  %l413 = alloca { i64, ptr }
  %l419 = alloca ptr
  %l420 = alloca i32
  %l422 = alloca { i64, ptr }
  %l424 = alloca { i64, ptr }
  %l427 = alloca { i64, ptr }
  %l434 = alloca i1
  %l436 = alloca ptr
  %l439 = alloca { i64, ptr }
  %l452 = alloca i1
  %l454 = alloca i1
  %l455 = alloca ptr
  %l456 = alloca ptr
  %l459 = alloca { i64, [4 x i64] }
  %l460 = alloca i32
  %l461 = alloca i32
  %l464 = alloca ptr
  %l465 = alloca i32
  %l467 = alloca { i64, ptr }
  %l469 = alloca { i64, ptr }
  %l472 = alloca { i64, ptr }
  %l478 = alloca i1
  %l480 = alloca ptr
  %l481 = alloca i32
  %l483 = alloca { i64, ptr }
  %l485 = alloca { i64, ptr }
  %l488 = alloca { i64, ptr }
  %l491 = alloca { i64, ptr }
  %l498 = alloca i1
  %l499 = alloca i32
  %l502 = alloca i32
  %l506 = alloca i32
  %l509 = alloca ptr
  %l512 = alloca { i64, ptr }
  %l518 = alloca ptr
  %l521 = alloca { i64, ptr }
  %l529 = alloca i1
  %l532 = alloca ptr
  %l535 = alloca { i64, ptr }
  %l541 = alloca ptr
  %l544 = alloca { i64, ptr }
  %l551 = alloca i1
  %l553 = alloca i1
  %l556 = alloca i1
  %l557 = alloca ptr
  %l560 = alloca { i64, ptr }
  %l563 = alloca ptr
  %l566 = alloca i32
  %l567 = alloca i1
  %l569 = alloca ptr
  %l572 = alloca { i64, ptr }
  %l575 = alloca ptr
  %l576 = alloca ptr
  %l579 = alloca { i64, [4 x i64] }
  %l580 = alloca i32
  %l581 = alloca i32
  %l589 = alloca i1
  %l591 = alloca ptr
  %l594 = alloca { i64, ptr }
  %l597 = alloca ptr
  %l600 = alloca i32
  %l601 = alloca i1
  %l603 = alloca ptr
  %l606 = alloca { i64, ptr }
  %l613 = alloca i1
  %l615 = alloca ptr
  %l618 = alloca { i64, ptr }
  %l624 = alloca ptr
  %l627 = alloca { i64, ptr }
  %l636 = alloca i1
  %l638 = alloca ptr
  %l639 = alloca i32
  %l641 = alloca { i64, ptr }
  %l643 = alloca { i64, ptr }
  %l646 = alloca { i64, ptr }
  %l649 = alloca ptr
  %l650 = alloca ptr
  %l653 = alloca { i64, [4 x i64] }
  %l654 = alloca i32
  %l655 = alloca i32
  %l658 = alloca ptr
  %l659 = alloca i32
  %l661 = alloca { i64, ptr }
  %l663 = alloca { i64, ptr }
  %l668 = alloca i1
  %l669 = alloca ptr
  %l672 = alloca i32
  %l674 = alloca i1
  %l676 = alloca ptr
  %l679 = alloca { i64, ptr }
  %l684 = alloca i1
  %l686 = alloca i1
  %l687 = alloca ptr
  %l688 = alloca ptr
  %l691 = alloca i32
  %l692 = alloca i32
  %l693 = alloca i1
  %l695 = alloca i1
  %l698 = alloca i64
  %l702 = alloca ptr
  %l703 = alloca i32
  %l705 = alloca { i64, ptr }
  %l707 = alloca { i64, ptr }
  %l710 = alloca { i64, ptr }
  %l715 = alloca i32
  %l720 = alloca i64
  %l723 = alloca i64
  %l741 = alloca ptr
  %l742 = alloca ptr
  %l746 = alloca { i64, [4 x i64] }
  %l747 = alloca i32
  %l748 = alloca i32
  %l749 = alloca i32
  %l751 = alloca { i64, ptr }
  %l753 = alloca { i64, ptr }
  %l764 = alloca ptr
  %l767 = alloca { i64, ptr }
  %l773 = alloca i1
  %l775 = alloca ptr
  %l776 = alloca i32
  %l778 = alloca { i64, ptr }
  %l780 = alloca { i64, ptr }
  %l783 = alloca { i64, ptr }
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.builder
  %s16room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.builder
  %s20room = alloca [64 x i8], align 8
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.builder
  %s27room = alloca [64 x i8], align 8
  %s30 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.builder
  %s34room = alloca [64 x i8], align 8
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.builder
  %s37room = alloca [64 x i8], align 8
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.builder
  %s40room = alloca [64 x i8], align 8
  %s44 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %s56 = alloca %olang.builder
  %s56room = alloca [64 x i8], align 8
  %s58 = alloca %olang.scope
  %s59 = alloca %olang.builder
  %s59room = alloca [64 x i8], align 8
  %s62 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %s66 = alloca %olang.builder
  %s66room = alloca [64 x i8], align 8
  %s68 = alloca %olang.scope
  %s69 = alloca %olang.builder
  %s69room = alloca [64 x i8], align 8
  %s72 = alloca %olang.scope
  %s74 = alloca %olang.scope
  %s77 = alloca %olang.scope
  %s79 = alloca %olang.scope
  %s82 = alloca %olang.scope
  %s84 = alloca %olang.scope
  %s86 = alloca %olang.scope
  %s88 = alloca %olang.scope
  %s90 = alloca %olang.scope
  %s93 = alloca %olang.scope
  %s95 = alloca %olang.scope
  %s98 = alloca %olang.scope
  %s99 = alloca %olang.builder
  %s99room = alloca [64 x i8], align 8
  %s101 = alloca %olang.scope
  %s102 = alloca %olang.builder
  %s102room = alloca [64 x i8], align 8
  %s104 = alloca %olang.scope
  %s107 = alloca %olang.scope
  %s108 = alloca %olang.builder
  %s108room = alloca [64 x i8], align 8
  %s112 = alloca %olang.scope
  %s113 = alloca %olang.builder
  %s113room = alloca [64 x i8], align 8
  %s117 = alloca %olang.scope
  %s120 = alloca %olang.scope
  %s121 = alloca %olang.builder
  %s121room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  store i64 %t9, ptr %l5, !tbaa !24
  %t11 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb1, label %bb2
bb1:
  br label %bb11
bb2:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t18 = trunc i64 1 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t23 = trunc i64 2 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  %t26 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t28 = trunc i64 20 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t31 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t33 = trunc i64 21 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 1, ptr %l28, !tbaa !24
  br label %bb47
bb12:
  %t36 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t38 = trunc i64 22 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  %t41 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t43 = trunc i64 24 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb15, label %bb16
bb15:
  br label %bb21
bb16:
  %t46 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t48 = trunc i64 29 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb17, label %bb18
bb17:
  br label %bb21
bb18:
  %t51 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t53 = trunc i64 44 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i64 1, ptr %l28, !tbaa !24
  br label %bb47
bb22:
  %t56 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t58 = trunc i64 32 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  %t61 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t63 = trunc i64 33 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  %t66 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t68 = trunc i64 34 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  %t71 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t73 = trunc i64 37 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i64 1, ptr %l28, !tbaa !24
  br label %bb47
bb32:
  %t76 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t78 = trunc i64 38 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i64 -1, ptr %l28, !tbaa !24
  br label %bb47
bb36:
  %t81 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t83 = trunc i64 28 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  %t86 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t88 = trunc i64 42 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i64 3, ptr %l28, !tbaa !24
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i64 2, ptr %l28, !tbaa !24
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_d0c28dbd82f4c36a_9dd446291f7ee706)
  unreachable
bb47:
  %t91 = load i64, ptr %l28, !tbaa !24
  store i64 %t91, ptr %l6, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = icmp slt i64 %t92, 0
  br i1 %t94, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l63, !tbaa !29
  %t97 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t97, ptr %l64
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s8, ptr %l64, i64 0)
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t99 = load ptr, ptr %s8
  %t100 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t101 = load i64, ptr %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t99, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l66, !tbaa !27
  %t105 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t106 = load ptr, ptr %t105
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %sbgrew.108, label %sbdone.109
sbgrew.108:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.109
sbdone.109:
  %t110 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t118 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s7, ptr %s7, { i64, ptr } %t116)
  store { i64, ptr } %t118, ptr %l68
  br label %bb51
bb51:
  %t119 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t120, i64 %t121)
  %t126 = getelementptr i8, ptr %t125, i64 %t121
  call void @olang_textcopy(ptr %t126, ptr %t122, i64 %t123)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t136 = load ptr, ptr %l63, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s7, ptr %t136, { i64, ptr } %t135)
  br label %bb52
bb52:
  %t138 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  store i32 %t138, ptr %rv
  br label %ret
bb53:
  %t140 = load i64, ptr %l5, !tbaa !24
  %t141 = load i64, ptr %l6, !tbaa !24
  %t144 = icmp ne i64 %t140, %t141
  br i1 %t144, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s10
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l75, !tbaa !29
  %t147 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t147, ptr %l76
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s11, ptr %l76, i64 0)
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t149 = load ptr, ptr %s11
  %t150 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t151 = load i64, ptr %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t149, i64 %t151)
  %t153 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  store { i64, ptr } %t154, ptr %l78, !tbaa !27
  %t155 = getelementptr %olang.builder, ptr %s11, i32 0, i32 3
  %t156 = load ptr, ptr %t155
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %sbgrew.158, label %sbdone.159
sbgrew.158:
  call void @__olang_sb_done(ptr %s11)
  br label %sbdone.159
sbdone.159:
  %t160 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t168 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s10, ptr %s10, { i64, ptr } %t166)
  store { i64, ptr } %t168, ptr %l80
  br label %bb57
bb57:
  %t169 = load i64, ptr %l5, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t177 = call i64 @__olang_fmt_i64(ptr null, i64 %t169)
  %t178 = add i64 %t175, %t177
  %t179 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t171, i64 %t172)
  %t183 = getelementptr i8, ptr %t182, i64 %t172
  call void @olang_textcopy(ptr %t183, ptr %t173, i64 %t174)
  %t184 = getelementptr i8, ptr %t183, i64 %t174
  %t185 = call i64 @__olang_fmt_i64(ptr %t184, i64 %t169)
  %t186 = getelementptr i8, ptr %t184, i64 %t177
  call void @olang_textcopy(ptr %t186, ptr %t179, i64 %t180)
  %t187 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t182, 1
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = extractvalue { i64, ptr } %t188, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  %t196 = load ptr, ptr %l75, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t196, { i64, ptr } %t195)
  br label %bb58
bb58:
  %t198 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  store i32 %t198, ptr %rv
  br label %ret
bb59:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l85, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/mir:Range", ptr %l3
  %t205 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t201, %"compiler/mir:Range" %t202, i64 0)
  store { i64, [4 x i64] } %t205, ptr %l88
  br label %bb60
bb60:
  %t206 = load ptr, ptr %l85, !tbaa !29
  %t207 = load { i64, [4 x i64] }, ptr %l88
  %t208 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t206, { i64, [4 x i64] } %t207)
  store i32 %t208, ptr %l89
  br label %bb61
bb61:
  %t209 = load i32, ptr %l89, !tbaa !23
  store i32 %t209, ptr %l7, !tbaa !23
  %t210 = load i32, ptr %l7, !tbaa !23
  %t211 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t214 = icmp eq i32 %t210, %t211
  br i1 %t214, label %bb62, label %bb63
bb62:
  %t216 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t216, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  %t218 = load ptr, ptr %l4, !tbaa !29
  %t219 = load i32, ptr %l7, !tbaa !23
  %t220 = load ptr, ptr @__olang_prog_scope
  %t223 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t220, ptr %t218, i32 %t219)
  store i32 %t223, ptr %l96
  br label %bb65
bb65:
  %t224 = load i32, ptr %l96, !tbaa !23
  store i32 %t224, ptr %l8, !tbaa !23
  %t225 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t227 = trunc i64 0 to i32
  %t228 = icmp eq i32 %t225, %t227
  br i1 %t228, label %bb66, label %bb67
bb66:
  br label %bb78
bb67:
  %t230 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t232 = trunc i64 3 to i32
  %t233 = icmp eq i32 %t230, %t232
  br i1 %t233, label %bb68, label %bb69
bb68:
  br label %bb78
bb69:
  %t235 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t237 = trunc i64 4 to i32
  %t238 = icmp eq i32 %t235, %t237
  br i1 %t238, label %bb70, label %bb71
bb70:
  br label %bb78
bb71:
  %t240 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t242 = trunc i64 5 to i32
  %t243 = icmp eq i32 %t240, %t242
  br i1 %t243, label %bb72, label %bb73
bb72:
  br label %bb78
bb73:
  %t245 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t247 = trunc i64 6 to i32
  %t248 = icmp eq i32 %t245, %t247
  br i1 %t248, label %bb74, label %bb75
bb74:
  br label %bb78
bb75:
  %t250 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t252 = trunc i64 7 to i32
  %t253 = icmp eq i32 %t250, %t252
  br i1 %t253, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb88
bb78:
  %t255 = load ptr, ptr %l4, !tbaa !29
  %t256 = load i32, ptr %l8, !tbaa !23
  %t257 = load ptr, ptr @__olang_prog_scope
  %t260 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %t257, ptr %t255, i32 %t256)
  store i1 %t260, ptr %l111
  br label %bb79
bb79:
  %t261 = load i1, ptr %l111, !tbaa !21
  %t262 = xor i1 %t261, true
  br i1 %t262, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s15
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  %t265 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t265, ptr %l114
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s16
  store ptr %s16room, ptr %s16
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s16, ptr %l114, i64 0)
  br label %bb82
bb81:
  br label %bb86
bb82:
  %t267 = load ptr, ptr %s16
  %t268 = getelementptr %olang.builder, ptr %s16, i32 0, i32 1
  %t269 = load i64, ptr %t268
  %t270 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t269)
  call void @olang_textcopy(ptr %t270, ptr %t267, i64 %t269)
  %t271 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t270, 1
  store { i64, ptr } %t272, ptr %l116, !tbaa !27
  %t273 = getelementptr %olang.builder, ptr %s16, i32 0, i32 3
  %t274 = load ptr, ptr %t273
  %t275 = icmp ne ptr %t274, null
  br i1 %t275, label %sbgrew.276, label %sbdone.277
sbgrew.276:
  call void @__olang_sb_done(ptr %s16)
  br label %sbdone.277
sbdone.277:
  %t278 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 0
  %t280 = extractvalue { i64, ptr } %t278, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  %t286 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s15, ptr %s15, { i64, ptr } %t284)
  store { i64, ptr } %t286, ptr %l118
  br label %bb83
bb83:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load i32, ptr %l7, !tbaa !23
  %t291 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s15, ptr %t287, i32 %t288)
  store { i64, ptr } %t291, ptr %l121
  br label %bb84
bb84:
  %t292 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t297 = add i64 %t294, %t296
  %t298 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t298, 1
  %t300 = extractvalue { i64, ptr } %t298, 0
  %t301 = add i64 %t297, %t300
  %t302 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t301)
  call void @olang_textcopy(ptr %t302, ptr %t293, i64 %t294)
  %t303 = getelementptr i8, ptr %t302, i64 %t294
  call void @olang_textcopy(ptr %t303, ptr %t295, i64 %t296)
  %t304 = getelementptr i8, ptr %t303, i64 %t296
  call void @olang_textcopy(ptr %t304, ptr %t299, i64 %t300)
  %t305 = insertvalue { i64, ptr } undef, i64 %t301, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t302, 1
  %t308 = extractvalue { i64, ptr } %t306, 0
  %t309 = extractvalue { i64, ptr } %t306, 1
  %t310 = mul i64 %t308, 1
  %t311 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t310)
  call void @llvm.memcpy.p0.p0.i64(ptr %t311, ptr %t309, i64 %t310, i1 false)
  %t312 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t311, 1
  %t314 = load ptr, ptr %l113, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s15, ptr %t314, { i64, ptr } %t313)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s15)
  br label %bb86
bb86:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t318 = load %"compiler/mir:Range", ptr %l3
  %t319 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %t316, i32 %t317, %"compiler/mir:Range" %t318, i32 %t319)
  br label %bb87
bb87:
  br label %bb510
bb88:
  %t324 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t326 = trunc i64 1 to i32
  %t327 = icmp eq i32 %t324, %t326
  br i1 %t327, label %bb89, label %bb90
bb89:
  br label %bb97
bb90:
  %t329 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t331 = trunc i64 10 to i32
  %t332 = icmp eq i32 %t329, %t331
  br i1 %t332, label %bb91, label %bb92
bb91:
  br label %bb97
bb92:
  %t334 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t336 = trunc i64 11 to i32
  %t337 = icmp eq i32 %t334, %t336
  br i1 %t337, label %bb93, label %bb94
bb93:
  br label %bb97
bb94:
  %t339 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t341 = trunc i64 12 to i32
  %t342 = icmp eq i32 %t339, %t341
  br i1 %t342, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb110
bb97:
  %t344 = load ptr, ptr %l4, !tbaa !29
  %t345 = load i32, ptr %l8, !tbaa !23
  %t346 = load ptr, ptr @__olang_prog_scope
  %t349 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t346, ptr %t344, i32 %t345)
  store i1 %t349, ptr %l138
  br label %bb98
bb98:
  %t350 = load i1, ptr %l138, !tbaa !21
  %t351 = xor i1 %t350, true
  br i1 %t351, label %bb99, label %bb100
bb99:
  %t353 = load i32, ptr %l8, !tbaa !23
  %t354 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t357 = icmp ne i32 %t353, %t354
  store i1 %t357, ptr %l140, !tbaa !21
  br label %bb101
bb100:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb101
bb101:
  %t359 = load i1, ptr %l140, !tbaa !21
  br i1 %t359, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s19
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l144, !tbaa !29
  %t361 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t361, ptr %l145
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s20
  store ptr %s20room, ptr %s20
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s20, ptr %l145, i64 0)
  br label %bb104
bb103:
  br label %bb108
bb104:
  %t363 = load ptr, ptr %s20
  %t364 = getelementptr %olang.builder, ptr %s20, i32 0, i32 1
  %t365 = load i64, ptr %t364
  %t366 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t365)
  call void @olang_textcopy(ptr %t366, ptr %t363, i64 %t365)
  %t367 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t368 = insertvalue { i64, ptr } %t367, ptr %t366, 1
  store { i64, ptr } %t368, ptr %l147, !tbaa !27
  %t369 = getelementptr %olang.builder, ptr %s20, i32 0, i32 3
  %t370 = load ptr, ptr %t369
  %t371 = icmp ne ptr %t370, null
  br i1 %t371, label %sbgrew.372, label %sbdone.373
sbgrew.372:
  call void @__olang_sb_done(ptr %s20)
  br label %sbdone.373
sbdone.373:
  %t374 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 0
  %t376 = extractvalue { i64, ptr } %t374, 1
  %t377 = mul i64 %t375, 1
  %t378 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t377)
  call void @llvm.memcpy.p0.p0.i64(ptr %t378, ptr %t376, i64 %t377, i1 false)
  %t379 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t380 = insertvalue { i64, ptr } %t379, ptr %t378, 1
  %t382 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s19, ptr %s19, { i64, ptr } %t380)
  store { i64, ptr } %t382, ptr %l149
  br label %bb105
bb105:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load i32, ptr %l7, !tbaa !23
  %t387 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s19, ptr %t383, i32 %t384)
  store { i64, ptr } %t387, ptr %l152
  br label %bb106
bb106:
  %t388 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t388, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t393 = add i64 %t390, %t392
  %t394 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = add i64 %t393, %t396
  %t398 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t397)
  call void @olang_textcopy(ptr %t398, ptr %t389, i64 %t390)
  %t399 = getelementptr i8, ptr %t398, i64 %t390
  call void @olang_textcopy(ptr %t399, ptr %t391, i64 %t392)
  %t400 = getelementptr i8, ptr %t399, i64 %t392
  call void @olang_textcopy(ptr %t400, ptr %t395, i64 %t396)
  %t401 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t402 = insertvalue { i64, ptr } %t401, ptr %t398, 1
  %t404 = extractvalue { i64, ptr } %t402, 0
  %t405 = extractvalue { i64, ptr } %t402, 1
  %t406 = mul i64 %t404, 1
  %t407 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t406)
  call void @llvm.memcpy.p0.p0.i64(ptr %t407, ptr %t405, i64 %t406, i1 false)
  %t408 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t409 = insertvalue { i64, ptr } %t408, ptr %t407, 1
  %t410 = load ptr, ptr %l144, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s19, ptr %t410, { i64, ptr } %t409)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s19)
  br label %bb108
bb108:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t414 = load %"compiler/mir:Range", ptr %l3
  %t415 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %t412, i32 %t413, %"compiler/mir:Range" %t414, i32 %t415)
  br label %bb109
bb109:
  br label %bb510
bb110:
  %t420 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t422 = trunc i64 8 to i32
  %t423 = icmp eq i32 %t420, %t422
  br i1 %t423, label %bb111, label %bb112
bb111:
  br label %bb115
bb112:
  %t425 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t427 = trunc i64 9 to i32
  %t428 = icmp eq i32 %t425, %t427
  br i1 %t428, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb140
bb115:
  %t430 = load ptr, ptr %l4, !tbaa !29
  %t431 = load i32, ptr %l8, !tbaa !23
  %t432 = load ptr, ptr @__olang_prog_scope
  %t435 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t432, ptr %t430, i32 %t431)
  store i1 %t435, ptr %l165
  br label %bb116
bb116:
  %t436 = load i1, ptr %l165, !tbaa !21
  %t437 = xor i1 %t436, true
  br i1 %t437, label %bb117, label %bb118
bb117:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb123
bb118:
  %t439 = load ptr, ptr %l4, !tbaa !29
  store ptr %t439, ptr %l168, !tbaa !29
  %t440 = load ptr, ptr %l4, !tbaa !29
  store ptr %t440, ptr %l169, !tbaa !29
  %t441 = load ptr, ptr %l0, !tbaa !29
  store ptr %t441, ptr %l170, !tbaa !29
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load %"compiler/mir:Range", ptr %l3
  %t446 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t442, %"compiler/mir:Range" %t443, i64 1)
  store { i64, [4 x i64] } %t446, ptr %l173
  br label %bb119
bb119:
  %t447 = load ptr, ptr %l170, !tbaa !29
  %t448 = load { i64, [4 x i64] }, ptr %l173
  %t449 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t447, { i64, [4 x i64] } %t448)
  store i32 %t449, ptr %l174
  br label %bb120
bb120:
  %t450 = load ptr, ptr @__olang_prog_scope
  %t451 = load ptr, ptr %l169, !tbaa !29
  %t452 = load i32, ptr %l174, !tbaa !23
  %t453 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t450, ptr %t451, i32 %t452)
  store i32 %t453, ptr %l175
  br label %bb121
bb121:
  %t454 = load ptr, ptr @__olang_prog_scope
  %t455 = load ptr, ptr %l168, !tbaa !29
  %t456 = load i32, ptr %l175, !tbaa !23
  %t457 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t454, ptr %t455, i32 %t456)
  store i1 %t457, ptr %l176
  br label %bb122
bb122:
  %t458 = load i1, ptr %l176, !tbaa !21
  %t459 = xor i1 %t458, true
  store i1 %t459, ptr %l167, !tbaa !21
  br label %bb123
bb123:
  %t461 = load i1, ptr %l167, !tbaa !21
  br i1 %t461, label %bb124, label %bb125
bb124:
  store %olang.scope zeroinitializer, ptr %s23
  %t462 = load ptr, ptr %l0, !tbaa !29
  store ptr %t462, ptr %l178, !tbaa !29
  %t463 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t463, ptr %l179
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s24, ptr %l179, i64 0)
  br label %bb126
bb125:
  br label %bb130
bb126:
  %t465 = load ptr, ptr %s24
  %t466 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t467 = load i64, ptr %t466
  %t468 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t467)
  call void @olang_textcopy(ptr %t468, ptr %t465, i64 %t467)
  %t469 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  store { i64, ptr } %t470, ptr %l181, !tbaa !27
  %t471 = getelementptr %olang.builder, ptr %s24, i32 0, i32 3
  %t472 = load ptr, ptr %t471
  %t473 = icmp ne ptr %t472, null
  br i1 %t473, label %sbgrew.474, label %sbdone.475
sbgrew.474:
  call void @__olang_sb_done(ptr %s24)
  br label %sbdone.475
sbdone.475:
  %t476 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t477 = extractvalue { i64, ptr } %t476, 0
  %t478 = extractvalue { i64, ptr } %t476, 1
  %t479 = mul i64 %t477, 1
  %t480 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t479)
  call void @llvm.memcpy.p0.p0.i64(ptr %t480, ptr %t478, i64 %t479, i1 false)
  %t481 = insertvalue { i64, ptr } undef, i64 %t477, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t480, 1
  %t484 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s23, ptr %s23, { i64, ptr } %t482)
  store { i64, ptr } %t484, ptr %l183
  br label %bb127
bb127:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load i32, ptr %l7, !tbaa !23
  %t489 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s23, ptr %t485, i32 %t486)
  store { i64, ptr } %t489, ptr %l186
  br label %bb128
bb128:
  %t490 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t491 = extractvalue { i64, ptr } %t490, 1
  %t492 = extractvalue { i64, ptr } %t490, 0
  %t493 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t494 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t495 = add i64 %t492, %t494
  %t496 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t496, 1
  %t498 = extractvalue { i64, ptr } %t496, 0
  %t499 = add i64 %t495, %t498
  %t500 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t499)
  call void @olang_textcopy(ptr %t500, ptr %t491, i64 %t492)
  %t501 = getelementptr i8, ptr %t500, i64 %t492
  call void @olang_textcopy(ptr %t501, ptr %t493, i64 %t494)
  %t502 = getelementptr i8, ptr %t501, i64 %t494
  call void @olang_textcopy(ptr %t502, ptr %t497, i64 %t498)
  %t503 = insertvalue { i64, ptr } undef, i64 %t499, 0
  %t504 = insertvalue { i64, ptr } %t503, ptr %t500, 1
  %t506 = extractvalue { i64, ptr } %t504, 0
  %t507 = extractvalue { i64, ptr } %t504, 1
  %t508 = mul i64 %t506, 1
  %t509 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t508)
  call void @llvm.memcpy.p0.p0.i64(ptr %t509, ptr %t507, i64 %t508, i1 false)
  %t510 = insertvalue { i64, ptr } undef, i64 %t506, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t509, 1
  %t512 = load ptr, ptr %l178, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s23, ptr %t512, { i64, ptr } %t511)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s23)
  br label %bb130
bb130:
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i32, ptr %l7, !tbaa !23
  %t516 = load i32, ptr %l2, !tbaa !23
  %t520 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t514, i32 %t515, i32 %t516)
  store i1 %t520, ptr %l192
  br label %bb131
bb131:
  %t521 = load i1, ptr %l192, !tbaa !21
  %t522 = xor i1 %t521, true
  br i1 %t522, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s26
  %t524 = load ptr, ptr %l0, !tbaa !29
  store ptr %t524, ptr %l194, !tbaa !29
  %t525 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t525, ptr %l195
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s27
  store ptr %s27room, ptr %s27
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s27, ptr %l195, i64 0)
  br label %bb134
bb133:
  br label %bb139
bb134:
  %t527 = load ptr, ptr %s27
  %t528 = getelementptr %olang.builder, ptr %s27, i32 0, i32 1
  %t529 = load i64, ptr %t528
  %t530 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t529)
  call void @olang_textcopy(ptr %t530, ptr %t527, i64 %t529)
  %t531 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t532 = insertvalue { i64, ptr } %t531, ptr %t530, 1
  store { i64, ptr } %t532, ptr %l197, !tbaa !27
  %t533 = getelementptr %olang.builder, ptr %s27, i32 0, i32 3
  %t534 = load ptr, ptr %t533
  %t535 = icmp ne ptr %t534, null
  br i1 %t535, label %sbgrew.536, label %sbdone.537
sbgrew.536:
  call void @__olang_sb_done(ptr %s27)
  br label %sbdone.537
sbdone.537:
  %t538 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t539 = extractvalue { i64, ptr } %t538, 0
  %t540 = extractvalue { i64, ptr } %t538, 1
  %t541 = mul i64 %t539, 1
  %t542 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t541)
  call void @llvm.memcpy.p0.p0.i64(ptr %t542, ptr %t540, i64 %t541, i1 false)
  %t543 = insertvalue { i64, ptr } undef, i64 %t539, 0
  %t544 = insertvalue { i64, ptr } %t543, ptr %t542, 1
  %t546 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s26, ptr %s26, { i64, ptr } %t544)
  store { i64, ptr } %t546, ptr %l199
  br label %bb135
bb135:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load i32, ptr %l7, !tbaa !23
  %t551 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s26, ptr %t547, i32 %t548)
  store { i64, ptr } %t551, ptr %l202
  br label %bb136
bb136:
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load i32, ptr %l2, !tbaa !23
  %t556 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s26, ptr %t552, i32 %t553)
  store { i64, ptr } %t556, ptr %l205
  br label %bb137
bb137:
  %t557 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t558 = extractvalue { i64, ptr } %t557, 1
  %t559 = extractvalue { i64, ptr } %t557, 0
  %t560 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t561 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t562 = add i64 %t559, %t561
  %t563 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t564 = extractvalue { i64, ptr } %t563, 1
  %t565 = extractvalue { i64, ptr } %t563, 0
  %t566 = add i64 %t562, %t565
  %t567 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t568 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t569 = add i64 %t566, %t568
  %t570 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t571 = extractvalue { i64, ptr } %t570, 1
  %t572 = extractvalue { i64, ptr } %t570, 0
  %t573 = add i64 %t569, %t572
  %t574 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t573)
  call void @olang_textcopy(ptr %t574, ptr %t558, i64 %t559)
  %t575 = getelementptr i8, ptr %t574, i64 %t559
  call void @olang_textcopy(ptr %t575, ptr %t560, i64 %t561)
  %t576 = getelementptr i8, ptr %t575, i64 %t561
  call void @olang_textcopy(ptr %t576, ptr %t564, i64 %t565)
  %t577 = getelementptr i8, ptr %t576, i64 %t565
  call void @olang_textcopy(ptr %t577, ptr %t567, i64 %t568)
  %t578 = getelementptr i8, ptr %t577, i64 %t568
  call void @olang_textcopy(ptr %t578, ptr %t571, i64 %t572)
  %t579 = insertvalue { i64, ptr } undef, i64 %t573, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t574, 1
  %t582 = extractvalue { i64, ptr } %t580, 0
  %t583 = extractvalue { i64, ptr } %t580, 1
  %t584 = mul i64 %t582, 1
  %t585 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t584)
  call void @llvm.memcpy.p0.p0.i64(ptr %t585, ptr %t583, i64 %t584, i1 false)
  %t586 = insertvalue { i64, ptr } undef, i64 %t582, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t585, 1
  %t588 = load ptr, ptr %l194, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s26, ptr %t588, { i64, ptr } %t587)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s26)
  br label %bb139
bb139:
  br label %bb510
bb140:
  %t590 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t592 = trunc i64 2 to i32
  %t593 = icmp eq i32 %t590, %t592
  br i1 %t593, label %bb141, label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb150
bb143:
  %t595 = load i32, ptr %l8, !tbaa !23
  %t596 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t599 = icmp ne i32 %t595, %t596
  br i1 %t599, label %bb144, label %bb145
bb144:
  store %olang.scope zeroinitializer, ptr %s30
  %t601 = load ptr, ptr %l0, !tbaa !29
  store ptr %t601, ptr %l213, !tbaa !29
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t603 = load i32, ptr %l7, !tbaa !23
  %t606 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s30, ptr %t602, i32 %t603)
  store { i64, ptr } %t606, ptr %l216
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t607 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t608 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t609 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t610 = extractvalue { i64, ptr } %t609, 1
  %t611 = extractvalue { i64, ptr } %t609, 0
  %t612 = add i64 %t608, %t611
  %t613 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t612)
  call void @olang_textcopy(ptr %t613, ptr %t607, i64 %t608)
  %t614 = getelementptr i8, ptr %t613, i64 %t608
  call void @olang_textcopy(ptr %t614, ptr %t610, i64 %t611)
  %t615 = insertvalue { i64, ptr } undef, i64 %t612, 0
  %t616 = insertvalue { i64, ptr } %t615, ptr %t613, 1
  %t618 = extractvalue { i64, ptr } %t616, 0
  %t619 = extractvalue { i64, ptr } %t616, 1
  %t620 = mul i64 %t618, 1
  %t621 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t620)
  call void @llvm.memcpy.p0.p0.i64(ptr %t621, ptr %t619, i64 %t620, i1 false)
  %t622 = insertvalue { i64, ptr } undef, i64 %t618, 0
  %t623 = insertvalue { i64, ptr } %t622, ptr %t621, 1
  %t624 = load ptr, ptr %l213, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s30, ptr %t624, { i64, ptr } %t623)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s30)
  br label %bb148
bb148:
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t627 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t628 = load %"compiler/mir:Range", ptr %l3
  %t629 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %t626, i32 %t627, %"compiler/mir:Range" %t628, i32 %t629)
  br label %bb149
bb149:
  br label %bb510
bb150:
  %t634 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t636 = trunc i64 13 to i32
  %t637 = icmp eq i32 %t634, %t636
  br i1 %t637, label %bb151, label %bb152
bb151:
  br label %bb163
bb152:
  %t639 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t641 = trunc i64 14 to i32
  %t642 = icmp eq i32 %t639, %t641
  br i1 %t642, label %bb153, label %bb154
bb153:
  br label %bb163
bb154:
  %t644 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t646 = trunc i64 15 to i32
  %t647 = icmp eq i32 %t644, %t646
  br i1 %t647, label %bb155, label %bb156
bb155:
  br label %bb163
bb156:
  %t649 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t651 = trunc i64 16 to i32
  %t652 = icmp eq i32 %t649, %t651
  br i1 %t652, label %bb157, label %bb158
bb157:
  br label %bb163
bb158:
  %t654 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t656 = trunc i64 17 to i32
  %t657 = icmp eq i32 %t654, %t656
  br i1 %t657, label %bb159, label %bb160
bb159:
  br label %bb163
bb160:
  %t659 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t661 = trunc i64 18 to i32
  %t662 = icmp eq i32 %t659, %t661
  br i1 %t662, label %bb161, label %bb162
bb161:
  br label %bb163
bb162:
  br label %bb200
bb163:
  %t664 = load ptr, ptr %l0, !tbaa !29
  store ptr %t664, ptr %l235, !tbaa !29
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t666 = load %"compiler/mir:Range", ptr %l3
  %t669 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t665, %"compiler/mir:Range" %t666, i64 1)
  store { i64, [4 x i64] } %t669, ptr %l238
  br label %bb164
bb164:
  %t670 = load ptr, ptr %l235, !tbaa !29
  %t671 = load { i64, [4 x i64] }, ptr %l238
  %t672 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t670, { i64, [4 x i64] } %t671)
  store i32 %t672, ptr %l239
  br label %bb165
bb165:
  %t673 = load i32, ptr %l239, !tbaa !23
  store i32 %t673, ptr %l9, !tbaa !23
  %t674 = load ptr, ptr %l4, !tbaa !29
  store ptr %t674, ptr %l240, !tbaa !29
  %t675 = load i32, ptr %l8, !tbaa !23
  store i32 %t675, ptr %l241, !tbaa !23
  %t676 = load ptr, ptr %l4, !tbaa !29
  %t677 = load i32, ptr %l9, !tbaa !23
  %t678 = load ptr, ptr @__olang_prog_scope
  %t681 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t678, ptr %t676, i32 %t677)
  store i32 %t681, ptr %l244
  br label %bb166
bb166:
  %t682 = load ptr, ptr @__olang_prog_scope
  %t683 = load ptr, ptr %l240, !tbaa !29
  %t684 = load i32, ptr %l241, !tbaa !23
  %t685 = load i32, ptr %l244, !tbaa !23
  %t686 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t682, ptr %t683, i32 %t684, i32 %t685)
  store i1 %t686, ptr %l245
  br label %bb167
bb167:
  %t687 = load i1, ptr %l245, !tbaa !21
  %t688 = xor i1 %t687, true
  br i1 %t688, label %bb168, label %bb169
bb168:
  store %olang.scope zeroinitializer, ptr %s33
  %t690 = load ptr, ptr %l0, !tbaa !29
  store ptr %t690, ptr %l247, !tbaa !29
  %t691 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t691, ptr %l248
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s34
  store ptr %s34room, ptr %s34
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s34, ptr %l248, i64 0)
  br label %bb170
bb169:
  br label %bb175
bb170:
  %t693 = load ptr, ptr %s34
  %t694 = getelementptr %olang.builder, ptr %s34, i32 0, i32 1
  %t695 = load i64, ptr %t694
  %t696 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t695)
  call void @olang_textcopy(ptr %t696, ptr %t693, i64 %t695)
  %t697 = insertvalue { i64, ptr } undef, i64 %t695, 0
  %t698 = insertvalue { i64, ptr } %t697, ptr %t696, 1
  store { i64, ptr } %t698, ptr %l250, !tbaa !27
  %t699 = getelementptr %olang.builder, ptr %s34, i32 0, i32 3
  %t700 = load ptr, ptr %t699
  %t701 = icmp ne ptr %t700, null
  br i1 %t701, label %sbgrew.702, label %sbdone.703
sbgrew.702:
  call void @__olang_sb_done(ptr %s34)
  br label %sbdone.703
sbdone.703:
  %t704 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t705 = extractvalue { i64, ptr } %t704, 0
  %t706 = extractvalue { i64, ptr } %t704, 1
  %t707 = mul i64 %t705, 1
  %t708 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t707)
  call void @llvm.memcpy.p0.p0.i64(ptr %t708, ptr %t706, i64 %t707, i1 false)
  %t709 = insertvalue { i64, ptr } undef, i64 %t705, 0
  %t710 = insertvalue { i64, ptr } %t709, ptr %t708, 1
  %t712 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s33, ptr %s33, { i64, ptr } %t710)
  store { i64, ptr } %t712, ptr %l252
  br label %bb171
bb171:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load i32, ptr %l7, !tbaa !23
  %t717 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s33, ptr %t713, i32 %t714)
  store { i64, ptr } %t717, ptr %l255
  br label %bb172
bb172:
  %t718 = load ptr, ptr %l0, !tbaa !29
  %t719 = load i32, ptr %l9, !tbaa !23
  %t722 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s33, ptr %t718, i32 %t719)
  store { i64, ptr } %t722, ptr %l258
  br label %bb173
bb173:
  %t723 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t724 = extractvalue { i64, ptr } %t723, 1
  %t725 = extractvalue { i64, ptr } %t723, 0
  %t726 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t727 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t728 = add i64 %t725, %t727
  %t729 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t730 = extractvalue { i64, ptr } %t729, 1
  %t731 = extractvalue { i64, ptr } %t729, 0
  %t732 = add i64 %t728, %t731
  %t733 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t734 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t735 = add i64 %t732, %t734
  %t736 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t737 = extractvalue { i64, ptr } %t736, 1
  %t738 = extractvalue { i64, ptr } %t736, 0
  %t739 = add i64 %t735, %t738
  %t740 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t739)
  call void @olang_textcopy(ptr %t740, ptr %t724, i64 %t725)
  %t741 = getelementptr i8, ptr %t740, i64 %t725
  call void @olang_textcopy(ptr %t741, ptr %t726, i64 %t727)
  %t742 = getelementptr i8, ptr %t741, i64 %t727
  call void @olang_textcopy(ptr %t742, ptr %t730, i64 %t731)
  %t743 = getelementptr i8, ptr %t742, i64 %t731
  call void @olang_textcopy(ptr %t743, ptr %t733, i64 %t734)
  %t744 = getelementptr i8, ptr %t743, i64 %t734
  call void @olang_textcopy(ptr %t744, ptr %t737, i64 %t738)
  %t745 = insertvalue { i64, ptr } undef, i64 %t739, 0
  %t746 = insertvalue { i64, ptr } %t745, ptr %t740, 1
  %t748 = extractvalue { i64, ptr } %t746, 0
  %t749 = extractvalue { i64, ptr } %t746, 1
  %t750 = mul i64 %t748, 1
  %t751 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t750)
  call void @llvm.memcpy.p0.p0.i64(ptr %t751, ptr %t749, i64 %t750, i1 false)
  %t752 = insertvalue { i64, ptr } undef, i64 %t748, 0
  %t753 = insertvalue { i64, ptr } %t752, ptr %t751, 1
  %t754 = load ptr, ptr %l247, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s33, ptr %t754, { i64, ptr } %t753)
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s33)
  br label %bb175
bb175:
  %t756 = load ptr, ptr %l4, !tbaa !29
  %t757 = load i32, ptr %l8, !tbaa !23
  %t758 = load ptr, ptr @__olang_prog_scope
  %t761 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %t758, ptr %t756, i32 %t757)
  store i1 %t761, ptr %l263
  br label %bb176
bb176:
  %t762 = load i1, ptr %l263, !tbaa !21
  %t763 = xor i1 %t762, true
  br i1 %t763, label %bb177, label %bb178
bb177:
  %t765 = load i32, ptr %l8, !tbaa !23
  %t766 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t769 = icmp ne i32 %t765, %t766
  store i1 %t769, ptr %l265, !tbaa !21
  br label %bb179
bb178:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb179
bb179:
  %t771 = load i1, ptr %l265, !tbaa !21
  br i1 %t771, label %bb180, label %bb181
bb180:
  %t772 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t774 = trunc i64 13 to i32
  %t775 = icmp eq i32 %t772, %t774
  %t777 = xor i1 %t775, true
  store i1 %t777, ptr %l269, !tbaa !21
  br label %bb182
bb181:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb182
bb182:
  %t779 = load i1, ptr %l269, !tbaa !21
  br i1 %t779, label %bb183, label %bb184
bb183:
  %t780 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t782 = trunc i64 14 to i32
  %t783 = icmp eq i32 %t780, %t782
  %t785 = xor i1 %t783, true
  store i1 %t785, ptr %l273, !tbaa !21
  br label %bb185
bb184:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb185
bb185:
  %t787 = load i1, ptr %l273, !tbaa !21
  br i1 %t787, label %bb186, label %bb187
bb186:
  store %olang.scope zeroinitializer, ptr %s36
  %t788 = load ptr, ptr %l0, !tbaa !29
  store ptr %t788, ptr %l277, !tbaa !29
  %t789 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t789, ptr %l278
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s37
  store ptr %s37room, ptr %s37
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s37, ptr %l278, i64 0)
  br label %bb188
bb187:
  br label %bb192
bb188:
  %t791 = load ptr, ptr %s37
  %t792 = getelementptr %olang.builder, ptr %s37, i32 0, i32 1
  %t793 = load i64, ptr %t792
  %t794 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t793)
  call void @olang_textcopy(ptr %t794, ptr %t791, i64 %t793)
  %t795 = insertvalue { i64, ptr } undef, i64 %t793, 0
  %t796 = insertvalue { i64, ptr } %t795, ptr %t794, 1
  store { i64, ptr } %t796, ptr %l280, !tbaa !27
  %t797 = getelementptr %olang.builder, ptr %s37, i32 0, i32 3
  %t798 = load ptr, ptr %t797
  %t799 = icmp ne ptr %t798, null
  br i1 %t799, label %sbgrew.800, label %sbdone.801
sbgrew.800:
  call void @__olang_sb_done(ptr %s37)
  br label %sbdone.801
sbdone.801:
  %t802 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t803 = extractvalue { i64, ptr } %t802, 0
  %t804 = extractvalue { i64, ptr } %t802, 1
  %t805 = mul i64 %t803, 1
  %t806 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t805)
  call void @llvm.memcpy.p0.p0.i64(ptr %t806, ptr %t804, i64 %t805, i1 false)
  %t807 = insertvalue { i64, ptr } undef, i64 %t803, 0
  %t808 = insertvalue { i64, ptr } %t807, ptr %t806, 1
  %t810 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s36, ptr %s36, { i64, ptr } %t808)
  store { i64, ptr } %t810, ptr %l282
  br label %bb189
bb189:
  %t811 = load ptr, ptr %l0, !tbaa !29
  %t812 = load i32, ptr %l7, !tbaa !23
  %t815 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s36, ptr %t811, i32 %t812)
  store { i64, ptr } %t815, ptr %l285
  br label %bb190
bb190:
  %t816 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t817 = extractvalue { i64, ptr } %t816, 1
  %t818 = extractvalue { i64, ptr } %t816, 0
  %t819 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t820 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t821 = add i64 %t818, %t820
  %t822 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t823 = extractvalue { i64, ptr } %t822, 1
  %t824 = extractvalue { i64, ptr } %t822, 0
  %t825 = add i64 %t821, %t824
  %t826 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t825)
  call void @olang_textcopy(ptr %t826, ptr %t817, i64 %t818)
  %t827 = getelementptr i8, ptr %t826, i64 %t818
  call void @olang_textcopy(ptr %t827, ptr %t819, i64 %t820)
  %t828 = getelementptr i8, ptr %t827, i64 %t820
  call void @olang_textcopy(ptr %t828, ptr %t823, i64 %t824)
  %t829 = insertvalue { i64, ptr } undef, i64 %t825, 0
  %t830 = insertvalue { i64, ptr } %t829, ptr %t826, 1
  %t832 = extractvalue { i64, ptr } %t830, 0
  %t833 = extractvalue { i64, ptr } %t830, 1
  %t834 = mul i64 %t832, 1
  %t835 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t834)
  call void @llvm.memcpy.p0.p0.i64(ptr %t835, ptr %t833, i64 %t834, i1 false)
  %t836 = insertvalue { i64, ptr } undef, i64 %t832, 0
  %t837 = insertvalue { i64, ptr } %t836, ptr %t835, 1
  %t838 = load ptr, ptr %l277, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s36, ptr %t838, { i64, ptr } %t837)
  br label %bb191
bb191:
  call void @__olang_scope_close(ptr %s36)
  br label %bb192
bb192:
  %t840 = load i32, ptr %l2, !tbaa !23
  %t841 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t844 = icmp ne i32 %t840, %t841
  br i1 %t844, label %bb193, label %bb194
bb193:
  store %olang.scope zeroinitializer, ptr %s39
  %t846 = load ptr, ptr %l0, !tbaa !29
  store ptr %t846, ptr %l291, !tbaa !29
  %t847 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t847, ptr %l292
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s40
  store ptr %s40room, ptr %s40
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s40, ptr %l292, i64 0)
  br label %bb195
bb194:
  br label %bb199
bb195:
  %t849 = load ptr, ptr %s40
  %t850 = getelementptr %olang.builder, ptr %s40, i32 0, i32 1
  %t851 = load i64, ptr %t850
  %t852 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t851)
  call void @olang_textcopy(ptr %t852, ptr %t849, i64 %t851)
  %t853 = insertvalue { i64, ptr } undef, i64 %t851, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t852, 1
  store { i64, ptr } %t854, ptr %l294, !tbaa !27
  %t855 = getelementptr %olang.builder, ptr %s40, i32 0, i32 3
  %t856 = load ptr, ptr %t855
  %t857 = icmp ne ptr %t856, null
  br i1 %t857, label %sbgrew.858, label %sbdone.859
sbgrew.858:
  call void @__olang_sb_done(ptr %s40)
  br label %sbdone.859
sbdone.859:
  %t860 = load { i64, ptr }, ptr %l294, !tbaa !27
  %t861 = extractvalue { i64, ptr } %t860, 0
  %t862 = extractvalue { i64, ptr } %t860, 1
  %t863 = mul i64 %t861, 1
  %t864 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t863)
  call void @llvm.memcpy.p0.p0.i64(ptr %t864, ptr %t862, i64 %t863, i1 false)
  %t865 = insertvalue { i64, ptr } undef, i64 %t861, 0
  %t866 = insertvalue { i64, ptr } %t865, ptr %t864, 1
  %t868 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s39, ptr %s39, { i64, ptr } %t866)
  store { i64, ptr } %t868, ptr %l296
  br label %bb196
bb196:
  %t869 = load ptr, ptr %l0, !tbaa !29
  %t870 = load i32, ptr %l2, !tbaa !23
  %t873 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s39, ptr %t869, i32 %t870)
  store { i64, ptr } %t873, ptr %l299
  br label %bb197
bb197:
  %t874 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t875 = extractvalue { i64, ptr } %t874, 1
  %t876 = extractvalue { i64, ptr } %t874, 0
  %t877 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t878 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t879 = add i64 %t876, %t878
  %t880 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t881 = extractvalue { i64, ptr } %t880, 1
  %t882 = extractvalue { i64, ptr } %t880, 0
  %t883 = add i64 %t879, %t882
  %t884 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t883)
  call void @olang_textcopy(ptr %t884, ptr %t875, i64 %t876)
  %t885 = getelementptr i8, ptr %t884, i64 %t876
  call void @olang_textcopy(ptr %t885, ptr %t877, i64 %t878)
  %t886 = getelementptr i8, ptr %t885, i64 %t878
  call void @olang_textcopy(ptr %t886, ptr %t881, i64 %t882)
  %t887 = insertvalue { i64, ptr } undef, i64 %t883, 0
  %t888 = insertvalue { i64, ptr } %t887, ptr %t884, 1
  %t890 = extractvalue { i64, ptr } %t888, 0
  %t891 = extractvalue { i64, ptr } %t888, 1
  %t892 = mul i64 %t890, 1
  %t893 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t892)
  call void @llvm.memcpy.p0.p0.i64(ptr %t893, ptr %t891, i64 %t892, i1 false)
  %t894 = insertvalue { i64, ptr } undef, i64 %t890, 0
  %t895 = insertvalue { i64, ptr } %t894, ptr %t893, 1
  %t896 = load ptr, ptr %l291, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s39, ptr %t896, { i64, ptr } %t895)
  br label %bb198
bb198:
  call void @__olang_scope_close(ptr %s39)
  br label %bb199
bb199:
  br label %bb510
bb200:
  %t898 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t900 = trunc i64 19 to i32
  %t901 = icmp eq i32 %t898, %t900
  br i1 %t901, label %bb201, label %bb202
bb201:
  br label %bb203
bb202:
  br label %bb236
bb203:
  %t903 = load ptr, ptr %l0, !tbaa !29
  store ptr %t903, ptr %l304, !tbaa !29
  %t904 = load ptr, ptr %l0, !tbaa !29
  %t905 = load %"compiler/mir:Range", ptr %l3
  %t908 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t904, %"compiler/mir:Range" %t905, i64 1)
  store { i64, [4 x i64] } %t908, ptr %l307
  br label %bb204
bb204:
  %t909 = load ptr, ptr %l304, !tbaa !29
  %t910 = load { i64, [4 x i64] }, ptr %l307
  %t911 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t909, { i64, [4 x i64] } %t910)
  store i32 %t911, ptr %l308
  br label %bb205
bb205:
  %t912 = load i32, ptr %l308, !tbaa !23
  store i32 %t912, ptr %l10, !tbaa !23
  %t913 = load ptr, ptr %l4, !tbaa !29
  %t914 = load i32, ptr %l8, !tbaa !23
  %t915 = load ptr, ptr @__olang_prog_scope
  %t918 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t915, ptr %t913, i32 %t914)
  store i32 %t918, ptr %l311
  br label %bb206
bb206:
  %t919 = load i32, ptr %l311, !range !{i32 0, i32 33}
  store i32 %t919, ptr %l11
  %t920 = load ptr, ptr %l4, !tbaa !29
  %t921 = load i32, ptr %l10, !tbaa !23
  %t922 = load ptr, ptr @__olang_prog_scope
  %t925 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t922, ptr %t920, i32 %t921)
  store i32 %t925, ptr %l314
  br label %bb207
bb207:
  %t926 = load i32, ptr %l314, !tbaa !23
  store i32 %t926, ptr %l12, !tbaa !23
  %t927 = load ptr, ptr %l4, !tbaa !29
  %t928 = load i32, ptr %l12, !tbaa !23
  %t929 = load i32, ptr %l8, !tbaa !23
  %t930 = load ptr, ptr @__olang_prog_scope
  %t934 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t930, ptr %t927, i32 %t928, i32 %t929)
  store i1 %t934, ptr %l318
  br label %bb208
bb208:
  %t935 = load i1, ptr %l318, !tbaa !21
  store i1 %t935, ptr %l13, !tbaa !21
  %t936 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t938 = trunc i64 20 to i32
  %t939 = icmp eq i32 %t936, %t938
  br i1 %t939, label %bb209, label %bb210
bb209:
  %t941 = load ptr, ptr %l4, !tbaa !29
  %t942 = load i32, ptr %l12, !tbaa !23
  %t943 = load ptr, ptr @__olang_prog_scope
  %t946 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t943, ptr %t941, i32 %t942)
  store i1 %t946, ptr %l324
  br label %bb211
bb210:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb212
bb211:
  %t947 = load i1, ptr %l324, !tbaa !21
  store i1 %t947, ptr %l321, !tbaa !21
  br label %bb212
bb212:
  %t948 = load i1, ptr %l321, !tbaa !21
  br i1 %t948, label %bb213, label %bb214
bb213:
  %t949 = load ptr, ptr %l0, !tbaa !29
  store ptr %t949, ptr %l325, !tbaa !29
  %t950 = load ptr, ptr %l4, !tbaa !29
  %t951 = load i32, ptr %l8, !tbaa !23
  %t952 = load ptr, ptr @__olang_prog_scope
  %t955 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t952, ptr %t950, i32 %t951)
  store i32 %t955, ptr %l328
  br label %bb215
bb214:
  br label %bb218
bb215:
  %t956 = load ptr, ptr %l4, !tbaa !29
  %t957 = load i32, ptr %l12, !tbaa !23
  %t958 = load ptr, ptr @__olang_prog_scope
  %t961 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t958, ptr %t956, i32 %t957)
  store i32 %t961, ptr %l331
  br label %bb216
bb216:
  %t962 = load ptr, ptr %l325, !tbaa !29
  %t963 = load i32, ptr %l328, !tbaa !23
  %t964 = load i32, ptr %l331, !tbaa !23
  %t965 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t962, i32 %t963, i32 %t964)
  store i1 %t965, ptr %l332
  br label %bb217
bb217:
  %t966 = load i1, ptr %l332, !tbaa !21
  store i1 %t966, ptr %l13, !tbaa !21
  br label %bb218
bb218:
  %t967 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t969 = trunc i64 20 to i32
  %t970 = icmp eq i32 %t967, %t969
  %t972 = xor i1 %t970, true
  br i1 %t972, label %bb219, label %bb220
bb219:
  %t974 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t976 = trunc i64 21 to i32
  %t977 = icmp eq i32 %t974, %t976
  %t979 = xor i1 %t977, true
  store i1 %t979, ptr %l336, !tbaa !21
  br label %bb221
bb220:
  store i1 false, ptr %l336, !tbaa !21
  br label %bb221
bb221:
  %t981 = load i1, ptr %l336, !tbaa !21
  br i1 %t981, label %bb222, label %bb223
bb222:
  store i1 true, ptr %l340, !tbaa !21
  br label %bb224
bb223:
  %t982 = load i1, ptr %l13, !tbaa !21
  %t984 = xor i1 %t982, true
  store i1 %t984, ptr %l340, !tbaa !21
  br label %bb224
bb224:
  %t986 = load i1, ptr %l340, !tbaa !21
  br i1 %t986, label %bb225, label %bb226
bb225:
  store %olang.scope zeroinitializer, ptr %s44
  %t987 = load ptr, ptr %l0, !tbaa !29
  store ptr %t987, ptr %l343, !tbaa !29
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t989 = load i32, ptr %l7, !tbaa !23
  %t992 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s44, ptr %t988, i32 %t989)
  store { i64, ptr } %t992, ptr %l346
  br label %bb227
bb226:
  br label %bb230
bb227:
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t994 = load i32, ptr %l10, !tbaa !23
  %t997 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s44, ptr %t993, i32 %t994)
  store { i64, ptr } %t997, ptr %l349
  br label %bb228
bb228:
  %t998 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t999 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t1000 = load { i64, ptr }, ptr %l346, !tbaa !27
  %t1001 = extractvalue { i64, ptr } %t1000, 1
  %t1002 = extractvalue { i64, ptr } %t1000, 0
  %t1003 = add i64 %t999, %t1002
  %t1004 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t1005 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t1006 = add i64 %t1003, %t1005
  %t1007 = load { i64, ptr }, ptr %l349, !tbaa !27
  %t1008 = extractvalue { i64, ptr } %t1007, 1
  %t1009 = extractvalue { i64, ptr } %t1007, 0
  %t1010 = add i64 %t1006, %t1009
  %t1011 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1010)
  call void @olang_textcopy(ptr %t1011, ptr %t998, i64 %t999)
  %t1012 = getelementptr i8, ptr %t1011, i64 %t999
  call void @olang_textcopy(ptr %t1012, ptr %t1001, i64 %t1002)
  %t1013 = getelementptr i8, ptr %t1012, i64 %t1002
  call void @olang_textcopy(ptr %t1013, ptr %t1004, i64 %t1005)
  %t1014 = getelementptr i8, ptr %t1013, i64 %t1005
  call void @olang_textcopy(ptr %t1014, ptr %t1008, i64 %t1009)
  %t1015 = insertvalue { i64, ptr } undef, i64 %t1010, 0
  %t1016 = insertvalue { i64, ptr } %t1015, ptr %t1011, 1
  %t1018 = extractvalue { i64, ptr } %t1016, 0
  %t1019 = extractvalue { i64, ptr } %t1016, 1
  %t1020 = mul i64 %t1018, 1
  %t1021 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1020)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1021, ptr %t1019, i64 %t1020, i1 false)
  %t1022 = insertvalue { i64, ptr } undef, i64 %t1018, 0
  %t1023 = insertvalue { i64, ptr } %t1022, ptr %t1021, 1
  %t1024 = load ptr, ptr %l343, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s44, ptr %t1024, { i64, ptr } %t1023)
  br label %bb229
bb229:
  call void @__olang_scope_close(ptr %s44)
  br label %bb230
bb230:
  %t1026 = load i32, ptr %l2, !tbaa !23
  %t1027 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1030 = icmp ne i32 %t1026, %t1027
  br i1 %t1030, label %bb231, label %bb232
bb231:
  store %olang.scope zeroinitializer, ptr %s46
  %t1032 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1032, ptr %l355, !tbaa !29
  %t1033 = load ptr, ptr %l0, !tbaa !29
  %t1034 = load i32, ptr %l2, !tbaa !23
  %t1037 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s46, ptr %t1033, i32 %t1034)
  store { i64, ptr } %t1037, ptr %l358
  br label %bb233
bb232:
  br label %bb235
bb233:
  %t1038 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t1039 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t1040 = load { i64, ptr }, ptr %l358, !tbaa !27
  %t1041 = extractvalue { i64, ptr } %t1040, 1
  %t1042 = extractvalue { i64, ptr } %t1040, 0
  %t1043 = add i64 %t1039, %t1042
  %t1044 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1043)
  call void @olang_textcopy(ptr %t1044, ptr %t1038, i64 %t1039)
  %t1045 = getelementptr i8, ptr %t1044, i64 %t1039
  call void @olang_textcopy(ptr %t1045, ptr %t1041, i64 %t1042)
  %t1046 = insertvalue { i64, ptr } undef, i64 %t1043, 0
  %t1047 = insertvalue { i64, ptr } %t1046, ptr %t1044, 1
  %t1049 = extractvalue { i64, ptr } %t1047, 0
  %t1050 = extractvalue { i64, ptr } %t1047, 1
  %t1051 = mul i64 %t1049, 1
  %t1052 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1051)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1052, ptr %t1050, i64 %t1051, i1 false)
  %t1053 = insertvalue { i64, ptr } undef, i64 %t1049, 0
  %t1054 = insertvalue { i64, ptr } %t1053, ptr %t1052, 1
  %t1055 = load ptr, ptr %l355, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s46, ptr %t1055, { i64, ptr } %t1054)
  br label %bb234
bb234:
  call void @__olang_scope_close(ptr %s46)
  br label %bb235
bb235:
  br label %bb510
bb236:
  %t1057 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1059 = trunc i64 20 to i32
  %t1060 = icmp eq i32 %t1057, %t1059
  br i1 %t1060, label %bb237, label %bb238
bb237:
  br label %bb241
bb238:
  %t1062 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1064 = trunc i64 21 to i32
  %t1065 = icmp eq i32 %t1062, %t1064
  br i1 %t1065, label %bb239, label %bb240
bb239:
  br label %bb241
bb240:
  br label %bb242
bb241:
  br label %bb510
bb242:
  %t1067 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1069 = trunc i64 22 to i32
  %t1070 = icmp eq i32 %t1067, %t1069
  br i1 %t1070, label %bb243, label %bb244
bb243:
  br label %bb245
bb244:
  br label %bb262
bb245:
  %t1072 = load ptr, ptr %l4, !tbaa !29
  %t1073 = load i32, ptr %l8, !tbaa !23
  %t1074 = load ptr, ptr @__olang_prog_scope
  %t1077 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t1074, ptr %t1072, i32 %t1073)
  store i1 %t1077, ptr %l369
  br label %bb246
bb246:
  %t1078 = load i1, ptr %l369, !tbaa !21
  br i1 %t1078, label %bb247, label %bb248
bb247:
  %t1079 = load ptr, ptr %l4, !tbaa !29
  %t1080 = load i32, ptr %l8, !tbaa !23
  %t1081 = load ptr, ptr @__olang_prog_scope
  %t1084 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t1081, ptr %t1079, i32 %t1080)
  store i32 %t1084, ptr %l373
  br label %bb249
bb248:
  %t1085 = load i32, ptr %l7, !tbaa !23
  store i32 %t1085, ptr %l370, !tbaa !23
  br label %bb250
bb249:
  %t1087 = load i32, ptr %l373, !tbaa !23
  store i32 %t1087, ptr %l370, !tbaa !23
  br label %bb250
bb250:
  %t1088 = load i32, ptr %l370, !tbaa !23
  %t1089 = load ptr, ptr %l0, !tbaa !29
  %t1093 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t1089, i32 %t1088)
  store i32 %t1093, ptr %l377
  br label %bb251
bb251:
  %t1094 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1095 = load i32, ptr %l377, !tbaa !23
  %t1097 = icmp eq i32 %t1095, %t1094
  br i1 %t1097, label %bb252, label %bb253
bb252:
  store %olang.scope zeroinitializer, ptr %s50
  %t1099 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1099, ptr %l380, !tbaa !29
  %t1100 = load ptr, ptr %l0, !tbaa !29
  %t1101 = load i32, ptr %l7, !tbaa !23
  %t1104 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s50, ptr %t1100, i32 %t1101)
  store { i64, ptr } %t1104, ptr %l383
  br label %bb254
bb253:
  br label %bb256
bb254:
  %t1105 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t1106 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t1107 = load { i64, ptr }, ptr %l383, !tbaa !27
  %t1108 = extractvalue { i64, ptr } %t1107, 1
  %t1109 = extractvalue { i64, ptr } %t1107, 0
  %t1110 = add i64 %t1106, %t1109
  %t1111 = call ptr @__olang_scope_alloc(ptr %s50, i64 %t1110)
  call void @olang_textcopy(ptr %t1111, ptr %t1105, i64 %t1106)
  %t1112 = getelementptr i8, ptr %t1111, i64 %t1106
  call void @olang_textcopy(ptr %t1112, ptr %t1108, i64 %t1109)
  %t1113 = insertvalue { i64, ptr } undef, i64 %t1110, 0
  %t1114 = insertvalue { i64, ptr } %t1113, ptr %t1111, 1
  %t1116 = extractvalue { i64, ptr } %t1114, 0
  %t1117 = extractvalue { i64, ptr } %t1114, 1
  %t1118 = mul i64 %t1116, 1
  %t1119 = call ptr @__olang_scope_alloc(ptr %s50, i64 %t1118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1119, ptr %t1117, i64 %t1118, i1 false)
  %t1120 = insertvalue { i64, ptr } undef, i64 %t1116, 0
  %t1121 = insertvalue { i64, ptr } %t1120, ptr %t1119, 1
  %t1122 = load ptr, ptr %l380, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s50, ptr %t1122, { i64, ptr } %t1121)
  br label %bb255
bb255:
  call void @__olang_scope_close(ptr %s50)
  br label %bb256
bb256:
  %t1124 = load i32, ptr %l2, !tbaa !23
  %t1125 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1128 = icmp ne i32 %t1124, %t1125
  br i1 %t1128, label %bb257, label %bb258
bb257:
  store %olang.scope zeroinitializer, ptr %s52
  %t1130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1130, ptr %l389, !tbaa !29
  %t1131 = load ptr, ptr %l0, !tbaa !29
  %t1132 = load i32, ptr %l2, !tbaa !23
  %t1135 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s52, ptr %t1131, i32 %t1132)
  store { i64, ptr } %t1135, ptr %l392
  br label %bb259
bb258:
  br label %bb261
bb259:
  %t1136 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t1137 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t1138 = load { i64, ptr }, ptr %l392, !tbaa !27
  %t1139 = extractvalue { i64, ptr } %t1138, 1
  %t1140 = extractvalue { i64, ptr } %t1138, 0
  %t1141 = add i64 %t1137, %t1140
  %t1142 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1141)
  call void @olang_textcopy(ptr %t1142, ptr %t1136, i64 %t1137)
  %t1143 = getelementptr i8, ptr %t1142, i64 %t1137
  call void @olang_textcopy(ptr %t1143, ptr %t1139, i64 %t1140)
  %t1144 = insertvalue { i64, ptr } undef, i64 %t1141, 0
  %t1145 = insertvalue { i64, ptr } %t1144, ptr %t1142, 1
  %t1147 = extractvalue { i64, ptr } %t1145, 0
  %t1148 = extractvalue { i64, ptr } %t1145, 1
  %t1149 = mul i64 %t1147, 1
  %t1150 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1150, ptr %t1148, i64 %t1149, i1 false)
  %t1151 = insertvalue { i64, ptr } undef, i64 %t1147, 0
  %t1152 = insertvalue { i64, ptr } %t1151, ptr %t1150, 1
  %t1153 = load ptr, ptr %l389, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s52, ptr %t1153, { i64, ptr } %t1152)
  br label %bb260
bb260:
  call void @__olang_scope_close(ptr %s52)
  br label %bb261
bb261:
  br label %bb510
bb262:
  %t1155 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1157 = trunc i64 32 to i32
  %t1158 = icmp eq i32 %t1155, %t1157
  br i1 %t1158, label %bb263, label %bb264
bb263:
  br label %bb269
bb264:
  %t1160 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1162 = trunc i64 33 to i32
  %t1163 = icmp eq i32 %t1160, %t1162
  br i1 %t1163, label %bb265, label %bb266
bb265:
  br label %bb269
bb266:
  %t1165 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1167 = trunc i64 34 to i32
  %t1168 = icmp eq i32 %t1165, %t1167
  br i1 %t1168, label %bb267, label %bb268
bb267:
  br label %bb269
bb268:
  br label %bb285
bb269:
  %t1170 = load ptr, ptr %l4, !tbaa !29
  %t1171 = load i32, ptr %l8, !tbaa !23
  %t1172 = load ptr, ptr @__olang_prog_scope
  %t1175 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t1172, ptr %t1170, i32 %t1171)
  store i1 %t1175, ptr %l403
  br label %bb270
bb270:
  %t1176 = load i1, ptr %l403, !tbaa !21
  %t1177 = xor i1 %t1176, true
  br i1 %t1177, label %bb271, label %bb272
bb271:
  store %olang.scope zeroinitializer, ptr %s55
  %t1179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1179, ptr %l405, !tbaa !29
  %t1180 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t1180, ptr %l406
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s56
  store ptr %s56room, ptr %s56
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s56, ptr %l406, i64 0)
  br label %bb273
bb272:
  br label %bb277
bb273:
  %t1182 = load ptr, ptr %s56
  %t1183 = getelementptr %olang.builder, ptr %s56, i32 0, i32 1
  %t1184 = load i64, ptr %t1183
  %t1185 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1184)
  call void @olang_textcopy(ptr %t1185, ptr %t1182, i64 %t1184)
  %t1186 = insertvalue { i64, ptr } undef, i64 %t1184, 0
  %t1187 = insertvalue { i64, ptr } %t1186, ptr %t1185, 1
  store { i64, ptr } %t1187, ptr %l408, !tbaa !27
  %t1188 = getelementptr %olang.builder, ptr %s56, i32 0, i32 3
  %t1189 = load ptr, ptr %t1188
  %t1190 = icmp ne ptr %t1189, null
  br i1 %t1190, label %sbgrew.1191, label %sbdone.1192
sbgrew.1191:
  call void @__olang_sb_done(ptr %s56)
  br label %sbdone.1192
sbdone.1192:
  %t1193 = load { i64, ptr }, ptr %l408, !tbaa !27
  %t1194 = extractvalue { i64, ptr } %t1193, 0
  %t1195 = extractvalue { i64, ptr } %t1193, 1
  %t1196 = mul i64 %t1194, 1
  %t1197 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1197, ptr %t1195, i64 %t1196, i1 false)
  %t1198 = insertvalue { i64, ptr } undef, i64 %t1194, 0
  %t1199 = insertvalue { i64, ptr } %t1198, ptr %t1197, 1
  %t1201 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s55, ptr %s55, { i64, ptr } %t1199)
  store { i64, ptr } %t1201, ptr %l410
  br label %bb274
bb274:
  %t1202 = load ptr, ptr %l0, !tbaa !29
  %t1203 = load i32, ptr %l7, !tbaa !23
  %t1206 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s55, ptr %t1202, i32 %t1203)
  store { i64, ptr } %t1206, ptr %l413
  br label %bb275
bb275:
  %t1207 = load { i64, ptr }, ptr %l410, !tbaa !27
  %t1208 = extractvalue { i64, ptr } %t1207, 1
  %t1209 = extractvalue { i64, ptr } %t1207, 0
  %t1210 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t1211 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t1212 = add i64 %t1209, %t1211
  %t1213 = load { i64, ptr }, ptr %l413, !tbaa !27
  %t1214 = extractvalue { i64, ptr } %t1213, 1
  %t1215 = extractvalue { i64, ptr } %t1213, 0
  %t1216 = add i64 %t1212, %t1215
  %t1217 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1216)
  call void @olang_textcopy(ptr %t1217, ptr %t1208, i64 %t1209)
  %t1218 = getelementptr i8, ptr %t1217, i64 %t1209
  call void @olang_textcopy(ptr %t1218, ptr %t1210, i64 %t1211)
  %t1219 = getelementptr i8, ptr %t1218, i64 %t1211
  call void @olang_textcopy(ptr %t1219, ptr %t1214, i64 %t1215)
  %t1220 = insertvalue { i64, ptr } undef, i64 %t1216, 0
  %t1221 = insertvalue { i64, ptr } %t1220, ptr %t1217, 1
  %t1223 = extractvalue { i64, ptr } %t1221, 0
  %t1224 = extractvalue { i64, ptr } %t1221, 1
  %t1225 = mul i64 %t1223, 1
  %t1226 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1226, ptr %t1224, i64 %t1225, i1 false)
  %t1227 = insertvalue { i64, ptr } undef, i64 %t1223, 0
  %t1228 = insertvalue { i64, ptr } %t1227, ptr %t1226, 1
  %t1229 = load ptr, ptr %l405, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s55, ptr %t1229, { i64, ptr } %t1228)
  br label %bb276
bb276:
  call void @__olang_scope_close(ptr %s55)
  br label %bb277
bb277:
  %t1231 = load i32, ptr %l2, !tbaa !23
  %t1232 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1235 = icmp ne i32 %t1231, %t1232
  br i1 %t1235, label %bb278, label %bb279
bb278:
  store %olang.scope zeroinitializer, ptr %s58
  %t1237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1237, ptr %l419, !tbaa !29
  %t1238 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t1238, ptr %l420
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s59
  store ptr %s59room, ptr %s59
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s59, ptr %l420, i64 0)
  br label %bb280
bb279:
  br label %bb284
bb280:
  %t1240 = load ptr, ptr %s59
  %t1241 = getelementptr %olang.builder, ptr %s59, i32 0, i32 1
  %t1242 = load i64, ptr %t1241
  %t1243 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t1242)
  call void @olang_textcopy(ptr %t1243, ptr %t1240, i64 %t1242)
  %t1244 = insertvalue { i64, ptr } undef, i64 %t1242, 0
  %t1245 = insertvalue { i64, ptr } %t1244, ptr %t1243, 1
  store { i64, ptr } %t1245, ptr %l422, !tbaa !27
  %t1246 = getelementptr %olang.builder, ptr %s59, i32 0, i32 3
  %t1247 = load ptr, ptr %t1246
  %t1248 = icmp ne ptr %t1247, null
  br i1 %t1248, label %sbgrew.1249, label %sbdone.1250
sbgrew.1249:
  call void @__olang_sb_done(ptr %s59)
  br label %sbdone.1250
sbdone.1250:
  %t1251 = load { i64, ptr }, ptr %l422, !tbaa !27
  %t1252 = extractvalue { i64, ptr } %t1251, 0
  %t1253 = extractvalue { i64, ptr } %t1251, 1
  %t1254 = mul i64 %t1252, 1
  %t1255 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t1254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1255, ptr %t1253, i64 %t1254, i1 false)
  %t1256 = insertvalue { i64, ptr } undef, i64 %t1252, 0
  %t1257 = insertvalue { i64, ptr } %t1256, ptr %t1255, 1
  %t1259 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s58, ptr %s58, { i64, ptr } %t1257)
  store { i64, ptr } %t1259, ptr %l424
  br label %bb281
bb281:
  %t1260 = load ptr, ptr %l0, !tbaa !29
  %t1261 = load i32, ptr %l2, !tbaa !23
  %t1264 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s58, ptr %t1260, i32 %t1261)
  store { i64, ptr } %t1264, ptr %l427
  br label %bb282
bb282:
  %t1265 = load { i64, ptr }, ptr %l424, !tbaa !27
  %t1266 = extractvalue { i64, ptr } %t1265, 1
  %t1267 = extractvalue { i64, ptr } %t1265, 0
  %t1268 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t1269 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t1270 = add i64 %t1267, %t1269
  %t1271 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t1272 = extractvalue { i64, ptr } %t1271, 1
  %t1273 = extractvalue { i64, ptr } %t1271, 0
  %t1274 = add i64 %t1270, %t1273
  %t1275 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t1274)
  call void @olang_textcopy(ptr %t1275, ptr %t1266, i64 %t1267)
  %t1276 = getelementptr i8, ptr %t1275, i64 %t1267
  call void @olang_textcopy(ptr %t1276, ptr %t1268, i64 %t1269)
  %t1277 = getelementptr i8, ptr %t1276, i64 %t1269
  call void @olang_textcopy(ptr %t1277, ptr %t1272, i64 %t1273)
  %t1278 = insertvalue { i64, ptr } undef, i64 %t1274, 0
  %t1279 = insertvalue { i64, ptr } %t1278, ptr %t1275, 1
  %t1281 = extractvalue { i64, ptr } %t1279, 0
  %t1282 = extractvalue { i64, ptr } %t1279, 1
  %t1283 = mul i64 %t1281, 1
  %t1284 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t1283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1284, ptr %t1282, i64 %t1283, i1 false)
  %t1285 = insertvalue { i64, ptr } undef, i64 %t1281, 0
  %t1286 = insertvalue { i64, ptr } %t1285, ptr %t1284, 1
  %t1287 = load ptr, ptr %l419, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s58, ptr %t1287, { i64, ptr } %t1286)
  br label %bb283
bb283:
  call void @__olang_scope_close(ptr %s58)
  br label %bb284
bb284:
  br label %bb510
bb285:
  %t1289 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1291 = trunc i64 37 to i32
  %t1292 = icmp eq i32 %t1289, %t1291
  br i1 %t1292, label %bb286, label %bb287
bb286:
  br label %bb288
bb287:
  br label %bb296
bb288:
  %t1294 = load ptr, ptr %l4, !tbaa !29
  %t1295 = load i32, ptr %l8, !tbaa !23
  %t1296 = load ptr, ptr @__olang_prog_scope
  %t1299 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t1296, ptr %t1294, i32 %t1295)
  store i1 %t1299, ptr %l434
  br label %bb289
bb289:
  %t1300 = load i1, ptr %l434, !tbaa !21
  %t1301 = xor i1 %t1300, true
  br i1 %t1301, label %bb290, label %bb291
bb290:
  store %olang.scope zeroinitializer, ptr %s62
  %t1303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1303, ptr %l436, !tbaa !29
  %t1304 = load ptr, ptr %l0, !tbaa !29
  %t1305 = load i32, ptr %l7, !tbaa !23
  %t1308 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s62, ptr %t1304, i32 %t1305)
  store { i64, ptr } %t1308, ptr %l439
  br label %bb292
bb291:
  br label %bb294
bb292:
  %t1309 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t1310 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t1311 = load { i64, ptr }, ptr %l439, !tbaa !27
  %t1312 = extractvalue { i64, ptr } %t1311, 1
  %t1313 = extractvalue { i64, ptr } %t1311, 0
  %t1314 = add i64 %t1310, %t1313
  %t1315 = call ptr @__olang_scope_alloc(ptr %s62, i64 %t1314)
  call void @olang_textcopy(ptr %t1315, ptr %t1309, i64 %t1310)
  %t1316 = getelementptr i8, ptr %t1315, i64 %t1310
  call void @olang_textcopy(ptr %t1316, ptr %t1312, i64 %t1313)
  %t1317 = insertvalue { i64, ptr } undef, i64 %t1314, 0
  %t1318 = insertvalue { i64, ptr } %t1317, ptr %t1315, 1
  %t1320 = extractvalue { i64, ptr } %t1318, 0
  %t1321 = extractvalue { i64, ptr } %t1318, 1
  %t1322 = mul i64 %t1320, 1
  %t1323 = call ptr @__olang_scope_alloc(ptr %s62, i64 %t1322)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1323, ptr %t1321, i64 %t1322, i1 false)
  %t1324 = insertvalue { i64, ptr } undef, i64 %t1320, 0
  %t1325 = insertvalue { i64, ptr } %t1324, ptr %t1323, 1
  %t1326 = load ptr, ptr %l436, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s62, ptr %t1326, { i64, ptr } %t1325)
  br label %bb293
bb293:
  call void @__olang_scope_close(ptr %s62)
  br label %bb294
bb294:
  %t1328 = load ptr, ptr %l0, !tbaa !29
  %t1329 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1330 = load %"compiler/mir:Range", ptr %l3
  %t1331 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %t1328, i32 %t1329, %"compiler/mir:Range" %t1330, i32 %t1331)
  br label %bb295
bb295:
  br label %bb510
bb296:
  %t1336 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1338 = trunc i64 35 to i32
  %t1339 = icmp eq i32 %t1336, %t1338
  br i1 %t1339, label %bb297, label %bb298
bb297:
  br label %bb301
bb298:
  %t1341 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1343 = trunc i64 36 to i32
  %t1344 = icmp eq i32 %t1341, %t1343
  br i1 %t1344, label %bb299, label %bb300
bb299:
  br label %bb301
bb300:
  br label %bb325
bb301:
  %t1346 = load ptr, ptr %l4, !tbaa !29
  %t1347 = load i32, ptr %l8, !tbaa !23
  %t1348 = load ptr, ptr @__olang_prog_scope
  %t1351 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t1348, ptr %t1346, i32 %t1347)
  store i1 %t1351, ptr %l452
  br label %bb302
bb302:
  %t1352 = load i1, ptr %l452, !tbaa !21
  %t1353 = xor i1 %t1352, true
  br i1 %t1353, label %bb303, label %bb304
bb303:
  store i1 true, ptr %l454, !tbaa !21
  br label %bb308
bb304:
  %t1355 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1355, ptr %l455, !tbaa !29
  %t1356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1356, ptr %l456, !tbaa !29
  %t1357 = load ptr, ptr %l0, !tbaa !29
  %t1358 = load %"compiler/mir:Range", ptr %l3
  %t1361 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t1357, %"compiler/mir:Range" %t1358, i64 1)
  store { i64, [4 x i64] } %t1361, ptr %l459
  br label %bb305
bb305:
  %t1362 = load ptr, ptr %l456, !tbaa !29
  %t1363 = load { i64, [4 x i64] }, ptr %l459
  %t1364 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t1362, { i64, [4 x i64] } %t1363)
  store i32 %t1364, ptr %l460
  br label %bb306
bb306:
  %t1365 = load ptr, ptr @__olang_prog_scope
  %t1366 = load ptr, ptr %l455, !tbaa !29
  %t1367 = load i32, ptr %l460, !tbaa !23
  %t1368 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t1365, ptr %t1366, i32 %t1367)
  store i32 %t1368, ptr %l461
  br label %bb307
bb307:
  %t1369 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1370 = load i32, ptr %l461, !tbaa !23
  %t1372 = icmp ne i32 %t1370, %t1369
  store i1 %t1372, ptr %l454, !tbaa !21
  br label %bb308
bb308:
  %t1374 = load i1, ptr %l454, !tbaa !21
  br i1 %t1374, label %bb309, label %bb310
bb309:
  store %olang.scope zeroinitializer, ptr %s65
  %t1375 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1375, ptr %l464, !tbaa !29
  %t1376 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t1376, ptr %l465
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s66
  store ptr %s66room, ptr %s66
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s66, ptr %l465, i64 0)
  br label %bb311
bb310:
  br label %bb315
bb311:
  %t1378 = load ptr, ptr %s66
  %t1379 = getelementptr %olang.builder, ptr %s66, i32 0, i32 1
  %t1380 = load i64, ptr %t1379
  %t1381 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1380)
  call void @olang_textcopy(ptr %t1381, ptr %t1378, i64 %t1380)
  %t1382 = insertvalue { i64, ptr } undef, i64 %t1380, 0
  %t1383 = insertvalue { i64, ptr } %t1382, ptr %t1381, 1
  store { i64, ptr } %t1383, ptr %l467, !tbaa !27
  %t1384 = getelementptr %olang.builder, ptr %s66, i32 0, i32 3
  %t1385 = load ptr, ptr %t1384
  %t1386 = icmp ne ptr %t1385, null
  br i1 %t1386, label %sbgrew.1387, label %sbdone.1388
sbgrew.1387:
  call void @__olang_sb_done(ptr %s66)
  br label %sbdone.1388
sbdone.1388:
  %t1389 = load { i64, ptr }, ptr %l467, !tbaa !27
  %t1390 = extractvalue { i64, ptr } %t1389, 0
  %t1391 = extractvalue { i64, ptr } %t1389, 1
  %t1392 = mul i64 %t1390, 1
  %t1393 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1393, ptr %t1391, i64 %t1392, i1 false)
  %t1394 = insertvalue { i64, ptr } undef, i64 %t1390, 0
  %t1395 = insertvalue { i64, ptr } %t1394, ptr %t1393, 1
  %t1397 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s65, ptr %s65, { i64, ptr } %t1395)
  store { i64, ptr } %t1397, ptr %l469
  br label %bb312
bb312:
  %t1398 = load ptr, ptr %l0, !tbaa !29
  %t1399 = load i32, ptr %l7, !tbaa !23
  %t1402 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s65, ptr %t1398, i32 %t1399)
  store { i64, ptr } %t1402, ptr %l472
  br label %bb313
bb313:
  %t1403 = load { i64, ptr }, ptr %l469, !tbaa !27
  %t1404 = extractvalue { i64, ptr } %t1403, 1
  %t1405 = extractvalue { i64, ptr } %t1403, 0
  %t1406 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t1407 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t1408 = add i64 %t1405, %t1407
  %t1409 = load { i64, ptr }, ptr %l472, !tbaa !27
  %t1410 = extractvalue { i64, ptr } %t1409, 1
  %t1411 = extractvalue { i64, ptr } %t1409, 0
  %t1412 = add i64 %t1408, %t1411
  %t1413 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1412)
  call void @olang_textcopy(ptr %t1413, ptr %t1404, i64 %t1405)
  %t1414 = getelementptr i8, ptr %t1413, i64 %t1405
  call void @olang_textcopy(ptr %t1414, ptr %t1406, i64 %t1407)
  %t1415 = getelementptr i8, ptr %t1414, i64 %t1407
  call void @olang_textcopy(ptr %t1415, ptr %t1410, i64 %t1411)
  %t1416 = insertvalue { i64, ptr } undef, i64 %t1412, 0
  %t1417 = insertvalue { i64, ptr } %t1416, ptr %t1413, 1
  %t1419 = extractvalue { i64, ptr } %t1417, 0
  %t1420 = extractvalue { i64, ptr } %t1417, 1
  %t1421 = mul i64 %t1419, 1
  %t1422 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1421)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1422, ptr %t1420, i64 %t1421, i1 false)
  %t1423 = insertvalue { i64, ptr } undef, i64 %t1419, 0
  %t1424 = insertvalue { i64, ptr } %t1423, ptr %t1422, 1
  %t1425 = load ptr, ptr %l464, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s65, ptr %t1425, { i64, ptr } %t1424)
  br label %bb314
bb314:
  call void @__olang_scope_close(ptr %s65)
  br label %bb315
bb315:
  %t1427 = load ptr, ptr %l0, !tbaa !29
  %t1428 = load i32, ptr %l7, !tbaa !23
  %t1429 = load i32, ptr %l2, !tbaa !23
  %t1433 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t1427, i32 %t1428, i32 %t1429)
  store i1 %t1433, ptr %l478
  br label %bb316
bb316:
  %t1434 = load i1, ptr %l478, !tbaa !21
  %t1435 = xor i1 %t1434, true
  br i1 %t1435, label %bb317, label %bb318
bb317:
  store %olang.scope zeroinitializer, ptr %s68
  %t1437 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1437, ptr %l480, !tbaa !29
  %t1438 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t1438, ptr %l481
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s69
  store ptr %s69room, ptr %s69
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s69, ptr %l481, i64 0)
  br label %bb319
bb318:
  br label %bb324
bb319:
  %t1440 = load ptr, ptr %s69
  %t1441 = getelementptr %olang.builder, ptr %s69, i32 0, i32 1
  %t1442 = load i64, ptr %t1441
  %t1443 = call ptr @__olang_scope_alloc(ptr %s68, i64 %t1442)
  call void @olang_textcopy(ptr %t1443, ptr %t1440, i64 %t1442)
  %t1444 = insertvalue { i64, ptr } undef, i64 %t1442, 0
  %t1445 = insertvalue { i64, ptr } %t1444, ptr %t1443, 1
  store { i64, ptr } %t1445, ptr %l483, !tbaa !27
  %t1446 = getelementptr %olang.builder, ptr %s69, i32 0, i32 3
  %t1447 = load ptr, ptr %t1446
  %t1448 = icmp ne ptr %t1447, null
  br i1 %t1448, label %sbgrew.1449, label %sbdone.1450
sbgrew.1449:
  call void @__olang_sb_done(ptr %s69)
  br label %sbdone.1450
sbdone.1450:
  %t1451 = load { i64, ptr }, ptr %l483, !tbaa !27
  %t1452 = extractvalue { i64, ptr } %t1451, 0
  %t1453 = extractvalue { i64, ptr } %t1451, 1
  %t1454 = mul i64 %t1452, 1
  %t1455 = call ptr @__olang_scope_alloc(ptr %s68, i64 %t1454)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1455, ptr %t1453, i64 %t1454, i1 false)
  %t1456 = insertvalue { i64, ptr } undef, i64 %t1452, 0
  %t1457 = insertvalue { i64, ptr } %t1456, ptr %t1455, 1
  %t1459 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s68, ptr %s68, { i64, ptr } %t1457)
  store { i64, ptr } %t1459, ptr %l485
  br label %bb320
bb320:
  %t1460 = load ptr, ptr %l0, !tbaa !29
  %t1461 = load i32, ptr %l7, !tbaa !23
  %t1464 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s68, ptr %t1460, i32 %t1461)
  store { i64, ptr } %t1464, ptr %l488
  br label %bb321
bb321:
  %t1465 = load ptr, ptr %l0, !tbaa !29
  %t1466 = load i32, ptr %l2, !tbaa !23
  %t1469 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s68, ptr %t1465, i32 %t1466)
  store { i64, ptr } %t1469, ptr %l491
  br label %bb322
bb322:
  %t1470 = load { i64, ptr }, ptr %l485, !tbaa !27
  %t1471 = extractvalue { i64, ptr } %t1470, 1
  %t1472 = extractvalue { i64, ptr } %t1470, 0
  %t1473 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t1474 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t1475 = add i64 %t1472, %t1474
  %t1476 = load { i64, ptr }, ptr %l488, !tbaa !27
  %t1477 = extractvalue { i64, ptr } %t1476, 1
  %t1478 = extractvalue { i64, ptr } %t1476, 0
  %t1479 = add i64 %t1475, %t1478
  %t1480 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t1481 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t1482 = add i64 %t1479, %t1481
  %t1483 = load { i64, ptr }, ptr %l491, !tbaa !27
  %t1484 = extractvalue { i64, ptr } %t1483, 1
  %t1485 = extractvalue { i64, ptr } %t1483, 0
  %t1486 = add i64 %t1482, %t1485
  %t1487 = call ptr @__olang_scope_alloc(ptr %s68, i64 %t1486)
  call void @olang_textcopy(ptr %t1487, ptr %t1471, i64 %t1472)
  %t1488 = getelementptr i8, ptr %t1487, i64 %t1472
  call void @olang_textcopy(ptr %t1488, ptr %t1473, i64 %t1474)
  %t1489 = getelementptr i8, ptr %t1488, i64 %t1474
  call void @olang_textcopy(ptr %t1489, ptr %t1477, i64 %t1478)
  %t1490 = getelementptr i8, ptr %t1489, i64 %t1478
  call void @olang_textcopy(ptr %t1490, ptr %t1480, i64 %t1481)
  %t1491 = getelementptr i8, ptr %t1490, i64 %t1481
  call void @olang_textcopy(ptr %t1491, ptr %t1484, i64 %t1485)
  %t1492 = insertvalue { i64, ptr } undef, i64 %t1486, 0
  %t1493 = insertvalue { i64, ptr } %t1492, ptr %t1487, 1
  %t1495 = extractvalue { i64, ptr } %t1493, 0
  %t1496 = extractvalue { i64, ptr } %t1493, 1
  %t1497 = mul i64 %t1495, 1
  %t1498 = call ptr @__olang_scope_alloc(ptr %s68, i64 %t1497)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1498, ptr %t1496, i64 %t1497, i1 false)
  %t1499 = insertvalue { i64, ptr } undef, i64 %t1495, 0
  %t1500 = insertvalue { i64, ptr } %t1499, ptr %t1498, 1
  %t1501 = load ptr, ptr %l480, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s68, ptr %t1501, { i64, ptr } %t1500)
  br label %bb323
bb323:
  call void @__olang_scope_close(ptr %s68)
  br label %bb324
bb324:
  br label %bb510
bb325:
  %t1503 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1505 = trunc i64 29 to i32
  %t1506 = icmp eq i32 %t1503, %t1505
  br i1 %t1506, label %bb326, label %bb327
bb326:
  br label %bb328
bb327:
  br label %bb345
bb328:
  %t1508 = load ptr, ptr %l4, !tbaa !29
  %t1509 = load i32, ptr %l8, !tbaa !23
  %t1510 = load ptr, ptr @__olang_prog_scope
  %t1513 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t1510, ptr %t1508, i32 %t1509)
  store i1 %t1513, ptr %l498
  br label %bb329
bb329:
  %t1514 = load i1, ptr %l498, !tbaa !21
  br i1 %t1514, label %bb330, label %bb331
bb330:
  %t1515 = load ptr, ptr %l4, !tbaa !29
  %t1516 = load i32, ptr %l8, !tbaa !23
  %t1517 = load ptr, ptr @__olang_prog_scope
  %t1520 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t1517, ptr %t1515, i32 %t1516)
  store i32 %t1520, ptr %l502
  br label %bb332
bb331:
  %t1521 = load i32, ptr %l7, !tbaa !23
  store i32 %t1521, ptr %l499, !tbaa !23
  br label %bb333
bb332:
  %t1523 = load i32, ptr %l502, !tbaa !23
  store i32 %t1523, ptr %l499, !tbaa !23
  br label %bb333
bb333:
  %t1524 = load i32, ptr %l499, !tbaa !23
  %t1525 = load ptr, ptr %l0, !tbaa !29
  %t1529 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t1525, i32 %t1524)
  store i32 %t1529, ptr %l506
  br label %bb334
bb334:
  %t1530 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1531 = load i32, ptr %l506, !tbaa !23
  %t1533 = icmp eq i32 %t1531, %t1530
  br i1 %t1533, label %bb335, label %bb336
bb335:
  store %olang.scope zeroinitializer, ptr %s72
  %t1535 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1535, ptr %l509, !tbaa !29
  %t1536 = load ptr, ptr %l0, !tbaa !29
  %t1537 = load i32, ptr %l7, !tbaa !23
  %t1540 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s72, ptr %t1536, i32 %t1537)
  store { i64, ptr } %t1540, ptr %l512
  br label %bb337
bb336:
  br label %bb339
bb337:
  %t1541 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t1542 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t1543 = load { i64, ptr }, ptr %l512, !tbaa !27
  %t1544 = extractvalue { i64, ptr } %t1543, 1
  %t1545 = extractvalue { i64, ptr } %t1543, 0
  %t1546 = add i64 %t1542, %t1545
  %t1547 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1546)
  call void @olang_textcopy(ptr %t1547, ptr %t1541, i64 %t1542)
  %t1548 = getelementptr i8, ptr %t1547, i64 %t1542
  call void @olang_textcopy(ptr %t1548, ptr %t1544, i64 %t1545)
  %t1549 = insertvalue { i64, ptr } undef, i64 %t1546, 0
  %t1550 = insertvalue { i64, ptr } %t1549, ptr %t1547, 1
  %t1552 = extractvalue { i64, ptr } %t1550, 0
  %t1553 = extractvalue { i64, ptr } %t1550, 1
  %t1554 = mul i64 %t1552, 1
  %t1555 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1554)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1555, ptr %t1553, i64 %t1554, i1 false)
  %t1556 = insertvalue { i64, ptr } undef, i64 %t1552, 0
  %t1557 = insertvalue { i64, ptr } %t1556, ptr %t1555, 1
  %t1558 = load ptr, ptr %l509, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s72, ptr %t1558, { i64, ptr } %t1557)
  br label %bb338
bb338:
  call void @__olang_scope_close(ptr %s72)
  br label %bb339
bb339:
  %t1560 = load i32, ptr %l2, !tbaa !23
  %t1561 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1564 = icmp ne i32 %t1560, %t1561
  br i1 %t1564, label %bb340, label %bb341
bb340:
  store %olang.scope zeroinitializer, ptr %s74
  %t1566 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1566, ptr %l518, !tbaa !29
  %t1567 = load ptr, ptr %l0, !tbaa !29
  %t1568 = load i32, ptr %l2, !tbaa !23
  %t1571 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s74, ptr %t1567, i32 %t1568)
  store { i64, ptr } %t1571, ptr %l521
  br label %bb342
bb341:
  br label %bb344
bb342:
  %t1572 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t1573 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t1574 = load { i64, ptr }, ptr %l521, !tbaa !27
  %t1575 = extractvalue { i64, ptr } %t1574, 1
  %t1576 = extractvalue { i64, ptr } %t1574, 0
  %t1577 = add i64 %t1573, %t1576
  %t1578 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1577)
  call void @olang_textcopy(ptr %t1578, ptr %t1572, i64 %t1573)
  %t1579 = getelementptr i8, ptr %t1578, i64 %t1573
  call void @olang_textcopy(ptr %t1579, ptr %t1575, i64 %t1576)
  %t1580 = insertvalue { i64, ptr } undef, i64 %t1577, 0
  %t1581 = insertvalue { i64, ptr } %t1580, ptr %t1578, 1
  %t1583 = extractvalue { i64, ptr } %t1581, 0
  %t1584 = extractvalue { i64, ptr } %t1581, 1
  %t1585 = mul i64 %t1583, 1
  %t1586 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1585)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1586, ptr %t1584, i64 %t1585, i1 false)
  %t1587 = insertvalue { i64, ptr } undef, i64 %t1583, 0
  %t1588 = insertvalue { i64, ptr } %t1587, ptr %t1586, 1
  %t1589 = load ptr, ptr %l518, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s74, ptr %t1589, { i64, ptr } %t1588)
  br label %bb343
bb343:
  call void @__olang_scope_close(ptr %s74)
  br label %bb344
bb344:
  br label %bb510
bb345:
  %t1591 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1593 = trunc i64 23 to i32
  %t1594 = icmp eq i32 %t1591, %t1593
  br i1 %t1594, label %bb346, label %bb347
bb346:
  br label %bb348
bb347:
  br label %bb360
bb348:
  %t1596 = load ptr, ptr %l0, !tbaa !29
  %t1598 = getelementptr %"compiler/mir:verifier", ptr %t1596, i32 0, i32 1
  %t1599 = load ptr, ptr %t1598, !tbaa !29
  %t1600 = load i32, ptr %l7, !tbaa !23
  %t1601 = load ptr, ptr @__olang_prog_scope
  %t1604 = call i1 @compiler_2fmir_2eHasCases(ptr %t1601, ptr %t1599, i32 %t1600)
  store i1 %t1604, ptr %l529
  br label %bb349
bb349:
  %t1605 = load i1, ptr %l529, !tbaa !21
  %t1608 = xor i1 %t1605, true
  br i1 %t1608, label %bb350, label %bb351
bb350:
  store %olang.scope zeroinitializer, ptr %s77
  %t1610 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1610, ptr %l532, !tbaa !29
  %t1611 = load ptr, ptr %l0, !tbaa !29
  %t1612 = load i32, ptr %l7, !tbaa !23
  %t1615 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s77, ptr %t1611, i32 %t1612)
  store { i64, ptr } %t1615, ptr %l535
  br label %bb352
bb351:
  br label %bb354
bb352:
  %t1616 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t1617 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t1618 = load { i64, ptr }, ptr %l535, !tbaa !27
  %t1619 = extractvalue { i64, ptr } %t1618, 1
  %t1620 = extractvalue { i64, ptr } %t1618, 0
  %t1621 = add i64 %t1617, %t1620
  %t1622 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1621)
  call void @olang_textcopy(ptr %t1622, ptr %t1616, i64 %t1617)
  %t1623 = getelementptr i8, ptr %t1622, i64 %t1617
  call void @olang_textcopy(ptr %t1623, ptr %t1619, i64 %t1620)
  %t1624 = insertvalue { i64, ptr } undef, i64 %t1621, 0
  %t1625 = insertvalue { i64, ptr } %t1624, ptr %t1622, 1
  %t1627 = extractvalue { i64, ptr } %t1625, 0
  %t1628 = extractvalue { i64, ptr } %t1625, 1
  %t1629 = mul i64 %t1627, 1
  %t1630 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1629)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1630, ptr %t1628, i64 %t1629, i1 false)
  %t1631 = insertvalue { i64, ptr } undef, i64 %t1627, 0
  %t1632 = insertvalue { i64, ptr } %t1631, ptr %t1630, 1
  %t1633 = load ptr, ptr %l532, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s77, ptr %t1633, { i64, ptr } %t1632)
  br label %bb353
bb353:
  call void @__olang_scope_close(ptr %s77)
  br label %bb354
bb354:
  %t1635 = load i32, ptr %l2, !tbaa !23
  %t1636 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1639 = icmp ne i32 %t1635, %t1636
  br i1 %t1639, label %bb355, label %bb356
bb355:
  store %olang.scope zeroinitializer, ptr %s79
  %t1641 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1641, ptr %l541, !tbaa !29
  %t1642 = load ptr, ptr %l0, !tbaa !29
  %t1643 = load i32, ptr %l2, !tbaa !23
  %t1646 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s79, ptr %t1642, i32 %t1643)
  store { i64, ptr } %t1646, ptr %l544
  br label %bb357
bb356:
  br label %bb359
bb357:
  %t1647 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t1648 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t1649 = load { i64, ptr }, ptr %l544, !tbaa !27
  %t1650 = extractvalue { i64, ptr } %t1649, 1
  %t1651 = extractvalue { i64, ptr } %t1649, 0
  %t1652 = add i64 %t1648, %t1651
  %t1653 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t1652)
  call void @olang_textcopy(ptr %t1653, ptr %t1647, i64 %t1648)
  %t1654 = getelementptr i8, ptr %t1653, i64 %t1648
  call void @olang_textcopy(ptr %t1654, ptr %t1650, i64 %t1651)
  %t1655 = insertvalue { i64, ptr } undef, i64 %t1652, 0
  %t1656 = insertvalue { i64, ptr } %t1655, ptr %t1653, 1
  %t1658 = extractvalue { i64, ptr } %t1656, 0
  %t1659 = extractvalue { i64, ptr } %t1656, 1
  %t1660 = mul i64 %t1658, 1
  %t1661 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t1660)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1661, ptr %t1659, i64 %t1660, i1 false)
  %t1662 = insertvalue { i64, ptr } undef, i64 %t1658, 0
  %t1663 = insertvalue { i64, ptr } %t1662, ptr %t1661, 1
  %t1664 = load ptr, ptr %l541, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s79, ptr %t1664, { i64, ptr } %t1663)
  br label %bb358
bb358:
  call void @__olang_scope_close(ptr %s79)
  br label %bb359
bb359:
  br label %bb510
bb360:
  %t1666 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1668 = trunc i64 43 to i32
  %t1669 = icmp eq i32 %t1666, %t1668
  br i1 %t1669, label %bb361, label %bb362
bb361:
  br label %bb363
bb362:
  br label %bb388
bb363:
  %t1671 = load ptr, ptr %l4, !tbaa !29
  %t1672 = load i32, ptr %l8, !tbaa !23
  %t1673 = load ptr, ptr @__olang_prog_scope
  %t1676 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t1673, ptr %t1671, i32 %t1672)
  store i1 %t1676, ptr %l551
  br label %bb364
bb364:
  %t1677 = load i1, ptr %l551, !tbaa !21
  %t1678 = xor i1 %t1677, true
  br i1 %t1678, label %bb365, label %bb366
bb365:
  store i1 true, ptr %l553, !tbaa !21
  br label %bb368
bb366:
  %t1680 = load ptr, ptr %l4, !tbaa !29
  %t1681 = load i32, ptr %l8, !tbaa !23
  %t1682 = load ptr, ptr @__olang_prog_scope
  %t1685 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %t1682, ptr %t1680, i32 %t1681)
  store i1 %t1685, ptr %l556
  br label %bb367
bb367:
  %t1686 = load i1, ptr %l556, !tbaa !21
  store i1 %t1686, ptr %l553, !tbaa !21
  br label %bb368
bb368:
  %t1687 = load i1, ptr %l553, !tbaa !21
  br i1 %t1687, label %bb369, label %bb370
bb369:
  store %olang.scope zeroinitializer, ptr %s82
  %t1688 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1688, ptr %l557, !tbaa !29
  %t1689 = load ptr, ptr %l0, !tbaa !29
  %t1690 = load i32, ptr %l7, !tbaa !23
  %t1693 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s82, ptr %t1689, i32 %t1690)
  store { i64, ptr } %t1693, ptr %l560
  br label %bb371
bb370:
  br label %bb373
bb371:
  %t1694 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t1695 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t1696 = load { i64, ptr }, ptr %l560, !tbaa !27
  %t1697 = extractvalue { i64, ptr } %t1696, 1
  %t1698 = extractvalue { i64, ptr } %t1696, 0
  %t1699 = add i64 %t1695, %t1698
  %t1700 = call ptr @__olang_scope_alloc(ptr %s82, i64 %t1699)
  call void @olang_textcopy(ptr %t1700, ptr %t1694, i64 %t1695)
  %t1701 = getelementptr i8, ptr %t1700, i64 %t1695
  call void @olang_textcopy(ptr %t1701, ptr %t1697, i64 %t1698)
  %t1702 = insertvalue { i64, ptr } undef, i64 %t1699, 0
  %t1703 = insertvalue { i64, ptr } %t1702, ptr %t1700, 1
  %t1705 = extractvalue { i64, ptr } %t1703, 0
  %t1706 = extractvalue { i64, ptr } %t1703, 1
  %t1707 = mul i64 %t1705, 1
  %t1708 = call ptr @__olang_scope_alloc(ptr %s82, i64 %t1707)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1708, ptr %t1706, i64 %t1707, i1 false)
  %t1709 = insertvalue { i64, ptr } undef, i64 %t1705, 0
  %t1710 = insertvalue { i64, ptr } %t1709, ptr %t1708, 1
  %t1711 = load ptr, ptr %l557, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s82, ptr %t1711, { i64, ptr } %t1710)
  br label %bb372
bb372:
  call void @__olang_scope_close(ptr %s82)
  br label %bb373
bb373:
  %t1713 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1713, ptr %l563, !tbaa !29
  %t1714 = load ptr, ptr %l4, !tbaa !29
  %t1715 = load i32, ptr %l2, !tbaa !23
  %t1716 = load ptr, ptr @__olang_prog_scope
  %t1719 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t1716, ptr %t1714, i32 %t1715)
  store i32 %t1719, ptr %l566
  br label %bb374
bb374:
  %t1720 = load ptr, ptr @__olang_prog_scope
  %t1721 = load ptr, ptr %l563, !tbaa !29
  %t1722 = load i32, ptr %l566, !tbaa !23
  %t1723 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %t1720, ptr %t1721, i32 %t1722)
  store i1 %t1723, ptr %l567
  br label %bb375
bb375:
  %t1724 = load i1, ptr %l567, !tbaa !21
  %t1725 = xor i1 %t1724, true
  br i1 %t1725, label %bb376, label %bb377
bb376:
  store %olang.scope zeroinitializer, ptr %s84
  %t1727 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1727, ptr %l569, !tbaa !29
  %t1728 = load ptr, ptr %l0, !tbaa !29
  %t1729 = load i32, ptr %l2, !tbaa !23
  %t1732 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s84, ptr %t1728, i32 %t1729)
  store { i64, ptr } %t1732, ptr %l572
  br label %bb378
bb377:
  br label %bb380
bb378:
  %t1733 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t1734 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t1735 = load { i64, ptr }, ptr %l572, !tbaa !27
  %t1736 = extractvalue { i64, ptr } %t1735, 1
  %t1737 = extractvalue { i64, ptr } %t1735, 0
  %t1738 = add i64 %t1734, %t1737
  %t1739 = call ptr @__olang_scope_alloc(ptr %s84, i64 %t1738)
  call void @olang_textcopy(ptr %t1739, ptr %t1733, i64 %t1734)
  %t1740 = getelementptr i8, ptr %t1739, i64 %t1734
  call void @olang_textcopy(ptr %t1740, ptr %t1736, i64 %t1737)
  %t1741 = insertvalue { i64, ptr } undef, i64 %t1738, 0
  %t1742 = insertvalue { i64, ptr } %t1741, ptr %t1739, 1
  %t1744 = extractvalue { i64, ptr } %t1742, 0
  %t1745 = extractvalue { i64, ptr } %t1742, 1
  %t1746 = mul i64 %t1744, 1
  %t1747 = call ptr @__olang_scope_alloc(ptr %s84, i64 %t1746)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1747, ptr %t1745, i64 %t1746, i1 false)
  %t1748 = insertvalue { i64, ptr } undef, i64 %t1744, 0
  %t1749 = insertvalue { i64, ptr } %t1748, ptr %t1747, 1
  %t1750 = load ptr, ptr %l569, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s84, ptr %t1750, { i64, ptr } %t1749)
  br label %bb379
bb379:
  call void @__olang_scope_close(ptr %s84)
  br label %bb380
bb380:
  %t1752 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1752, ptr %l575, !tbaa !29
  %t1753 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1753, ptr %l576, !tbaa !29
  %t1754 = load ptr, ptr %l0, !tbaa !29
  %t1755 = load %"compiler/mir:Range", ptr %l3
  %t1758 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t1754, %"compiler/mir:Range" %t1755, i64 1)
  store { i64, [4 x i64] } %t1758, ptr %l579
  br label %bb381
bb381:
  %t1759 = load ptr, ptr %l576, !tbaa !29
  %t1760 = load { i64, [4 x i64] }, ptr %l579
  %t1761 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t1759, { i64, [4 x i64] } %t1760)
  store i32 %t1761, ptr %l580
  br label %bb382
bb382:
  %t1762 = load ptr, ptr @__olang_prog_scope
  %t1763 = load ptr, ptr %l575, !tbaa !29
  %t1764 = load i32, ptr %l580, !tbaa !23
  %t1765 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t1762, ptr %t1763, i32 %t1764)
  store i32 %t1765, ptr %l581
  br label %bb383
bb383:
  %t1766 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1767 = load i32, ptr %l581, !tbaa !23
  %t1769 = icmp ne i32 %t1767, %t1766
  br i1 %t1769, label %bb384, label %bb385
bb384:
  store %olang.scope zeroinitializer, ptr %s86
  %t1771 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s86, ptr %t1771, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d198, i32 0, i32 1) })
  br label %bb386
bb385:
  br label %bb387
bb386:
  call void @__olang_scope_close(ptr %s86)
  br label %bb387
bb387:
  br label %bb510
bb388:
  %t1773 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1775 = trunc i64 44 to i32
  %t1776 = icmp eq i32 %t1773, %t1775
  br i1 %t1776, label %bb389, label %bb390
bb389:
  br label %bb391
bb390:
  br label %bb405
bb391:
  %t1778 = load ptr, ptr %l4, !tbaa !29
  %t1779 = load i32, ptr %l8, !tbaa !23
  %t1780 = load ptr, ptr @__olang_prog_scope
  %t1783 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %t1780, ptr %t1778, i32 %t1779)
  store i1 %t1783, ptr %l589
  br label %bb392
bb392:
  %t1784 = load i1, ptr %l589, !tbaa !21
  %t1785 = xor i1 %t1784, true
  br i1 %t1785, label %bb393, label %bb394
bb393:
  store %olang.scope zeroinitializer, ptr %s88
  %t1787 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1787, ptr %l591, !tbaa !29
  %t1788 = load ptr, ptr %l0, !tbaa !29
  %t1789 = load i32, ptr %l7, !tbaa !23
  %t1792 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s88, ptr %t1788, i32 %t1789)
  store { i64, ptr } %t1792, ptr %l594
  br label %bb395
bb394:
  br label %bb397
bb395:
  %t1793 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t1794 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t1795 = load { i64, ptr }, ptr %l594, !tbaa !27
  %t1796 = extractvalue { i64, ptr } %t1795, 1
  %t1797 = extractvalue { i64, ptr } %t1795, 0
  %t1798 = add i64 %t1794, %t1797
  %t1799 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t1798)
  call void @olang_textcopy(ptr %t1799, ptr %t1793, i64 %t1794)
  %t1800 = getelementptr i8, ptr %t1799, i64 %t1794
  call void @olang_textcopy(ptr %t1800, ptr %t1796, i64 %t1797)
  %t1801 = insertvalue { i64, ptr } undef, i64 %t1798, 0
  %t1802 = insertvalue { i64, ptr } %t1801, ptr %t1799, 1
  %t1804 = extractvalue { i64, ptr } %t1802, 0
  %t1805 = extractvalue { i64, ptr } %t1802, 1
  %t1806 = mul i64 %t1804, 1
  %t1807 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t1806)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1807, ptr %t1805, i64 %t1806, i1 false)
  %t1808 = insertvalue { i64, ptr } undef, i64 %t1804, 0
  %t1809 = insertvalue { i64, ptr } %t1808, ptr %t1807, 1
  %t1810 = load ptr, ptr %l591, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s88, ptr %t1810, { i64, ptr } %t1809)
  br label %bb396
bb396:
  call void @__olang_scope_close(ptr %s88)
  br label %bb397
bb397:
  %t1812 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1812, ptr %l597, !tbaa !29
  %t1813 = load ptr, ptr %l4, !tbaa !29
  %t1814 = load i32, ptr %l2, !tbaa !23
  %t1815 = load ptr, ptr @__olang_prog_scope
  %t1818 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t1815, ptr %t1813, i32 %t1814)
  store i32 %t1818, ptr %l600
  br label %bb398
bb398:
  %t1819 = load ptr, ptr @__olang_prog_scope
  %t1820 = load ptr, ptr %l597, !tbaa !29
  %t1821 = load i32, ptr %l600, !tbaa !23
  %t1822 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t1819, ptr %t1820, i32 %t1821)
  store i1 %t1822, ptr %l601
  br label %bb399
bb399:
  %t1823 = load i1, ptr %l601, !tbaa !21
  %t1824 = xor i1 %t1823, true
  br i1 %t1824, label %bb400, label %bb401
bb400:
  store %olang.scope zeroinitializer, ptr %s90
  %t1826 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1826, ptr %l603, !tbaa !29
  %t1827 = load ptr, ptr %l0, !tbaa !29
  %t1828 = load i32, ptr %l2, !tbaa !23
  %t1831 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s90, ptr %t1827, i32 %t1828)
  store { i64, ptr } %t1831, ptr %l606
  br label %bb402
bb401:
  br label %bb404
bb402:
  %t1832 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t1833 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t1834 = load { i64, ptr }, ptr %l606, !tbaa !27
  %t1835 = extractvalue { i64, ptr } %t1834, 1
  %t1836 = extractvalue { i64, ptr } %t1834, 0
  %t1837 = add i64 %t1833, %t1836
  %t1838 = call ptr @__olang_scope_alloc(ptr %s90, i64 %t1837)
  call void @olang_textcopy(ptr %t1838, ptr %t1832, i64 %t1833)
  %t1839 = getelementptr i8, ptr %t1838, i64 %t1833
  call void @olang_textcopy(ptr %t1839, ptr %t1835, i64 %t1836)
  %t1840 = insertvalue { i64, ptr } undef, i64 %t1837, 0
  %t1841 = insertvalue { i64, ptr } %t1840, ptr %t1838, 1
  %t1843 = extractvalue { i64, ptr } %t1841, 0
  %t1844 = extractvalue { i64, ptr } %t1841, 1
  %t1845 = mul i64 %t1843, 1
  %t1846 = call ptr @__olang_scope_alloc(ptr %s90, i64 %t1845)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1846, ptr %t1844, i64 %t1845, i1 false)
  %t1847 = insertvalue { i64, ptr } undef, i64 %t1843, 0
  %t1848 = insertvalue { i64, ptr } %t1847, ptr %t1846, 1
  %t1849 = load ptr, ptr %l603, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s90, ptr %t1849, { i64, ptr } %t1848)
  br label %bb403
bb403:
  call void @__olang_scope_close(ptr %s90)
  br label %bb404
bb404:
  br label %bb510
bb405:
  %t1851 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1853 = trunc i64 45 to i32
  %t1854 = icmp eq i32 %t1851, %t1853
  br i1 %t1854, label %bb406, label %bb407
bb406:
  br label %bb408
bb407:
  br label %bb420
bb408:
  %t1856 = load ptr, ptr %l4, !tbaa !29
  %t1857 = load i32, ptr %l8, !tbaa !23
  %t1858 = load ptr, ptr @__olang_prog_scope
  %t1861 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %t1858, ptr %t1856, i32 %t1857)
  store i1 %t1861, ptr %l613
  br label %bb409
bb409:
  %t1862 = load i1, ptr %l613, !tbaa !21
  %t1863 = xor i1 %t1862, true
  br i1 %t1863, label %bb410, label %bb411
bb410:
  store %olang.scope zeroinitializer, ptr %s93
  %t1865 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1865, ptr %l615, !tbaa !29
  %t1866 = load ptr, ptr %l0, !tbaa !29
  %t1867 = load i32, ptr %l7, !tbaa !23
  %t1870 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s93, ptr %t1866, i32 %t1867)
  store { i64, ptr } %t1870, ptr %l618
  br label %bb412
bb411:
  br label %bb414
bb412:
  %t1871 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t1872 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t1873 = load { i64, ptr }, ptr %l618, !tbaa !27
  %t1874 = extractvalue { i64, ptr } %t1873, 1
  %t1875 = extractvalue { i64, ptr } %t1873, 0
  %t1876 = add i64 %t1872, %t1875
  %t1877 = call ptr @__olang_scope_alloc(ptr %s93, i64 %t1876)
  call void @olang_textcopy(ptr %t1877, ptr %t1871, i64 %t1872)
  %t1878 = getelementptr i8, ptr %t1877, i64 %t1872
  call void @olang_textcopy(ptr %t1878, ptr %t1874, i64 %t1875)
  %t1879 = insertvalue { i64, ptr } undef, i64 %t1876, 0
  %t1880 = insertvalue { i64, ptr } %t1879, ptr %t1877, 1
  %t1882 = extractvalue { i64, ptr } %t1880, 0
  %t1883 = extractvalue { i64, ptr } %t1880, 1
  %t1884 = mul i64 %t1882, 1
  %t1885 = call ptr @__olang_scope_alloc(ptr %s93, i64 %t1884)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1885, ptr %t1883, i64 %t1884, i1 false)
  %t1886 = insertvalue { i64, ptr } undef, i64 %t1882, 0
  %t1887 = insertvalue { i64, ptr } %t1886, ptr %t1885, 1
  %t1888 = load ptr, ptr %l615, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s93, ptr %t1888, { i64, ptr } %t1887)
  br label %bb413
bb413:
  call void @__olang_scope_close(ptr %s93)
  br label %bb414
bb414:
  %t1890 = load i32, ptr %l2, !tbaa !23
  %t1891 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1894 = icmp ne i32 %t1890, %t1891
  br i1 %t1894, label %bb415, label %bb416
bb415:
  store %olang.scope zeroinitializer, ptr %s95
  %t1896 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1896, ptr %l624, !tbaa !29
  %t1897 = load ptr, ptr %l0, !tbaa !29
  %t1898 = load i32, ptr %l2, !tbaa !23
  %t1901 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s95, ptr %t1897, i32 %t1898)
  store { i64, ptr } %t1901, ptr %l627
  br label %bb417
bb416:
  br label %bb419
bb417:
  %t1902 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t1903 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t1904 = load { i64, ptr }, ptr %l627, !tbaa !27
  %t1905 = extractvalue { i64, ptr } %t1904, 1
  %t1906 = extractvalue { i64, ptr } %t1904, 0
  %t1907 = add i64 %t1903, %t1906
  %t1908 = call ptr @__olang_scope_alloc(ptr %s95, i64 %t1907)
  call void @olang_textcopy(ptr %t1908, ptr %t1902, i64 %t1903)
  %t1909 = getelementptr i8, ptr %t1908, i64 %t1903
  call void @olang_textcopy(ptr %t1909, ptr %t1905, i64 %t1906)
  %t1910 = insertvalue { i64, ptr } undef, i64 %t1907, 0
  %t1911 = insertvalue { i64, ptr } %t1910, ptr %t1908, 1
  %t1913 = extractvalue { i64, ptr } %t1911, 0
  %t1914 = extractvalue { i64, ptr } %t1911, 1
  %t1915 = mul i64 %t1913, 1
  %t1916 = call ptr @__olang_scope_alloc(ptr %s95, i64 %t1915)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1916, ptr %t1914, i64 %t1915, i1 false)
  %t1917 = insertvalue { i64, ptr } undef, i64 %t1913, 0
  %t1918 = insertvalue { i64, ptr } %t1917, ptr %t1916, 1
  %t1919 = load ptr, ptr %l624, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s95, ptr %t1919, { i64, ptr } %t1918)
  br label %bb418
bb418:
  call void @__olang_scope_close(ptr %s95)
  br label %bb419
bb419:
  br label %bb510
bb420:
  %t1921 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1923 = trunc i64 41 to i32
  %t1924 = icmp eq i32 %t1921, %t1923
  br i1 %t1924, label %bb421, label %bb422
bb421:
  br label %bb425
bb422:
  %t1926 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t1928 = trunc i64 42 to i32
  %t1929 = icmp eq i32 %t1926, %t1928
  br i1 %t1929, label %bb423, label %bb424
bb423:
  br label %bb425
bb424:
  br label %bb453
bb425:
  %t1931 = load ptr, ptr %l4, !tbaa !29
  %t1932 = load i32, ptr %l8, !tbaa !23
  %t1933 = load ptr, ptr @__olang_prog_scope
  %t1936 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %t1933, ptr %t1931, i32 %t1932)
  store i1 %t1936, ptr %l636
  br label %bb426
bb426:
  %t1937 = load i1, ptr %l636, !tbaa !21
  %t1938 = xor i1 %t1937, true
  br i1 %t1938, label %bb427, label %bb428
bb427:
  store %olang.scope zeroinitializer, ptr %s98
  %t1940 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1940, ptr %l638, !tbaa !29
  %t1941 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t1941, ptr %l639
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s99
  store ptr %s99room, ptr %s99
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s99, ptr %l639, i64 0)
  br label %bb429
bb428:
  br label %bb433
bb429:
  %t1943 = load ptr, ptr %s99
  %t1944 = getelementptr %olang.builder, ptr %s99, i32 0, i32 1
  %t1945 = load i64, ptr %t1944
  %t1946 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t1945)
  call void @olang_textcopy(ptr %t1946, ptr %t1943, i64 %t1945)
  %t1947 = insertvalue { i64, ptr } undef, i64 %t1945, 0
  %t1948 = insertvalue { i64, ptr } %t1947, ptr %t1946, 1
  store { i64, ptr } %t1948, ptr %l641, !tbaa !27
  %t1949 = getelementptr %olang.builder, ptr %s99, i32 0, i32 3
  %t1950 = load ptr, ptr %t1949
  %t1951 = icmp ne ptr %t1950, null
  br i1 %t1951, label %sbgrew.1952, label %sbdone.1953
sbgrew.1952:
  call void @__olang_sb_done(ptr %s99)
  br label %sbdone.1953
sbdone.1953:
  %t1954 = load { i64, ptr }, ptr %l641, !tbaa !27
  %t1955 = extractvalue { i64, ptr } %t1954, 0
  %t1956 = extractvalue { i64, ptr } %t1954, 1
  %t1957 = mul i64 %t1955, 1
  %t1958 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t1957)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1958, ptr %t1956, i64 %t1957, i1 false)
  %t1959 = insertvalue { i64, ptr } undef, i64 %t1955, 0
  %t1960 = insertvalue { i64, ptr } %t1959, ptr %t1958, 1
  %t1962 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s98, ptr %s98, { i64, ptr } %t1960)
  store { i64, ptr } %t1962, ptr %l643
  br label %bb430
bb430:
  %t1963 = load ptr, ptr %l0, !tbaa !29
  %t1964 = load i32, ptr %l7, !tbaa !23
  %t1967 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s98, ptr %t1963, i32 %t1964)
  store { i64, ptr } %t1967, ptr %l646
  br label %bb431
bb431:
  %t1968 = load { i64, ptr }, ptr %l643, !tbaa !27
  %t1969 = extractvalue { i64, ptr } %t1968, 1
  %t1970 = extractvalue { i64, ptr } %t1968, 0
  %t1971 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t1972 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t1973 = add i64 %t1970, %t1972
  %t1974 = load { i64, ptr }, ptr %l646, !tbaa !27
  %t1975 = extractvalue { i64, ptr } %t1974, 1
  %t1976 = extractvalue { i64, ptr } %t1974, 0
  %t1977 = add i64 %t1973, %t1976
  %t1978 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t1977)
  call void @olang_textcopy(ptr %t1978, ptr %t1969, i64 %t1970)
  %t1979 = getelementptr i8, ptr %t1978, i64 %t1970
  call void @olang_textcopy(ptr %t1979, ptr %t1971, i64 %t1972)
  %t1980 = getelementptr i8, ptr %t1979, i64 %t1972
  call void @olang_textcopy(ptr %t1980, ptr %t1975, i64 %t1976)
  %t1981 = insertvalue { i64, ptr } undef, i64 %t1977, 0
  %t1982 = insertvalue { i64, ptr } %t1981, ptr %t1978, 1
  %t1984 = extractvalue { i64, ptr } %t1982, 0
  %t1985 = extractvalue { i64, ptr } %t1982, 1
  %t1986 = mul i64 %t1984, 1
  %t1987 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t1986)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1987, ptr %t1985, i64 %t1986, i1 false)
  %t1988 = insertvalue { i64, ptr } undef, i64 %t1984, 0
  %t1989 = insertvalue { i64, ptr } %t1988, ptr %t1987, 1
  %t1990 = load ptr, ptr %l638, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s98, ptr %t1990, { i64, ptr } %t1989)
  br label %bb432
bb432:
  call void @__olang_scope_close(ptr %s98)
  br label %bb433
bb433:
  %t1992 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1992, ptr %l649, !tbaa !29
  %t1993 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1993, ptr %l650, !tbaa !29
  %t1994 = load ptr, ptr %l0, !tbaa !29
  %t1995 = load %"compiler/mir:Range", ptr %l3
  %t1998 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t1994, %"compiler/mir:Range" %t1995, i64 1)
  store { i64, [4 x i64] } %t1998, ptr %l653
  br label %bb434
bb434:
  %t1999 = load ptr, ptr %l650, !tbaa !29
  %t2000 = load { i64, [4 x i64] }, ptr %l653
  %t2001 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t1999, { i64, [4 x i64] } %t2000)
  store i32 %t2001, ptr %l654
  br label %bb435
bb435:
  %t2002 = load ptr, ptr @__olang_prog_scope
  %t2003 = load ptr, ptr %l649, !tbaa !29
  %t2004 = load i32, ptr %l654, !tbaa !23
  %t2005 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t2002, ptr %t2003, i32 %t2004)
  store i32 %t2005, ptr %l655
  br label %bb436
bb436:
  %t2006 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t2007 = load i32, ptr %l655, !tbaa !23
  %t2009 = icmp ne i32 %t2007, %t2006
  br i1 %t2009, label %bb437, label %bb438
bb437:
  store %olang.scope zeroinitializer, ptr %s101
  %t2011 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2011, ptr %l658, !tbaa !29
  %t2012 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t2012, ptr %l659
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s102
  store ptr %s102room, ptr %s102
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s102, ptr %l659, i64 0)
  br label %bb439
bb438:
  br label %bb442
bb439:
  %t2014 = load ptr, ptr %s102
  %t2015 = getelementptr %olang.builder, ptr %s102, i32 0, i32 1
  %t2016 = load i64, ptr %t2015
  %t2017 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2016)
  call void @olang_textcopy(ptr %t2017, ptr %t2014, i64 %t2016)
  %t2018 = insertvalue { i64, ptr } undef, i64 %t2016, 0
  %t2019 = insertvalue { i64, ptr } %t2018, ptr %t2017, 1
  store { i64, ptr } %t2019, ptr %l661, !tbaa !27
  %t2020 = getelementptr %olang.builder, ptr %s102, i32 0, i32 3
  %t2021 = load ptr, ptr %t2020
  %t2022 = icmp ne ptr %t2021, null
  br i1 %t2022, label %sbgrew.2023, label %sbdone.2024
sbgrew.2023:
  call void @__olang_sb_done(ptr %s102)
  br label %sbdone.2024
sbdone.2024:
  %t2025 = load { i64, ptr }, ptr %l661, !tbaa !27
  %t2026 = extractvalue { i64, ptr } %t2025, 0
  %t2027 = extractvalue { i64, ptr } %t2025, 1
  %t2028 = mul i64 %t2026, 1
  %t2029 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2028)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2029, ptr %t2027, i64 %t2028, i1 false)
  %t2030 = insertvalue { i64, ptr } undef, i64 %t2026, 0
  %t2031 = insertvalue { i64, ptr } %t2030, ptr %t2029, 1
  %t2033 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s101, ptr %s101, { i64, ptr } %t2031)
  store { i64, ptr } %t2033, ptr %l663
  br label %bb440
bb440:
  %t2034 = load { i64, ptr }, ptr %l663, !tbaa !27
  %t2035 = extractvalue { i64, ptr } %t2034, 1
  %t2036 = extractvalue { i64, ptr } %t2034, 0
  %t2037 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t2038 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t2039 = add i64 %t2036, %t2038
  %t2040 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2039)
  call void @olang_textcopy(ptr %t2040, ptr %t2035, i64 %t2036)
  %t2041 = getelementptr i8, ptr %t2040, i64 %t2036
  call void @olang_textcopy(ptr %t2041, ptr %t2037, i64 %t2038)
  %t2042 = insertvalue { i64, ptr } undef, i64 %t2039, 0
  %t2043 = insertvalue { i64, ptr } %t2042, ptr %t2040, 1
  %t2045 = extractvalue { i64, ptr } %t2043, 0
  %t2046 = extractvalue { i64, ptr } %t2043, 1
  %t2047 = mul i64 %t2045, 1
  %t2048 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2047)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2048, ptr %t2046, i64 %t2047, i1 false)
  %t2049 = insertvalue { i64, ptr } undef, i64 %t2045, 0
  %t2050 = insertvalue { i64, ptr } %t2049, ptr %t2048, 1
  %t2051 = load ptr, ptr %l658, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s101, ptr %t2051, { i64, ptr } %t2050)
  br label %bb441
bb441:
  call void @__olang_scope_close(ptr %s101)
  br label %bb442
bb442:
  %t2053 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t2055 = trunc i64 42 to i32
  %t2056 = icmp eq i32 %t2053, %t2055
  br i1 %t2056, label %bb443, label %bb444
bb443:
  %t2058 = load ptr, ptr %l4, !tbaa !29
  store ptr %t2058, ptr %l669, !tbaa !29
  %t2059 = load ptr, ptr %l4, !tbaa !29
  %t2060 = load i32, ptr %l2, !tbaa !23
  %t2061 = load ptr, ptr @__olang_prog_scope
  %t2064 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t2061, ptr %t2059, i32 %t2060)
  store i32 %t2064, ptr %l672
  br label %bb445
bb444:
  store i1 false, ptr %l668, !tbaa !21
  br label %bb447
bb445:
  %t2065 = load i32, ptr %l8, !tbaa !23
  %t2066 = load ptr, ptr @__olang_prog_scope
  %t2067 = load ptr, ptr %l669, !tbaa !29
  %t2068 = load i32, ptr %l672, !tbaa !23
  %t2070 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t2066, ptr %t2067, i32 %t2068, i32 %t2065)
  store i1 %t2070, ptr %l674
  br label %bb446
bb446:
  %t2071 = load i1, ptr %l674, !tbaa !21
  %t2072 = xor i1 %t2071, true
  store i1 %t2072, ptr %l668, !tbaa !21
  br label %bb447
bb447:
  %t2074 = load i1, ptr %l668, !tbaa !21
  br i1 %t2074, label %bb448, label %bb449
bb448:
  store %olang.scope zeroinitializer, ptr %s104
  %t2075 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2075, ptr %l676, !tbaa !29
  %t2076 = load ptr, ptr %l0, !tbaa !29
  %t2077 = load i32, ptr %l2, !tbaa !23
  %t2080 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s104, ptr %t2076, i32 %t2077)
  store { i64, ptr } %t2080, ptr %l679
  br label %bb450
bb449:
  br label %bb452
bb450:
  %t2081 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t2082 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t2083 = load { i64, ptr }, ptr %l679, !tbaa !27
  %t2084 = extractvalue { i64, ptr } %t2083, 1
  %t2085 = extractvalue { i64, ptr } %t2083, 0
  %t2086 = add i64 %t2082, %t2085
  %t2087 = call ptr @__olang_scope_alloc(ptr %s104, i64 %t2086)
  call void @olang_textcopy(ptr %t2087, ptr %t2081, i64 %t2082)
  %t2088 = getelementptr i8, ptr %t2087, i64 %t2082
  call void @olang_textcopy(ptr %t2088, ptr %t2084, i64 %t2085)
  %t2089 = insertvalue { i64, ptr } undef, i64 %t2086, 0
  %t2090 = insertvalue { i64, ptr } %t2089, ptr %t2087, 1
  %t2092 = extractvalue { i64, ptr } %t2090, 0
  %t2093 = extractvalue { i64, ptr } %t2090, 1
  %t2094 = mul i64 %t2092, 1
  %t2095 = call ptr @__olang_scope_alloc(ptr %s104, i64 %t2094)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2095, ptr %t2093, i64 %t2094, i1 false)
  %t2096 = insertvalue { i64, ptr } undef, i64 %t2092, 0
  %t2097 = insertvalue { i64, ptr } %t2096, ptr %t2095, 1
  %t2098 = load ptr, ptr %l676, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s104, ptr %t2098, { i64, ptr } %t2097)
  br label %bb451
bb451:
  call void @__olang_scope_close(ptr %s104)
  br label %bb452
bb452:
  br label %bb510
bb453:
  br i1 true, label %bb454, label %bb455
bb454:
  br label %bb456
bb455:
  br label %bb509
bb456:
  %t2100 = load ptr, ptr %l4, !tbaa !29
  %t2101 = load i32, ptr %l8, !tbaa !23
  %t2102 = load ptr, ptr @__olang_prog_scope
  %t2105 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t2102, ptr %t2100, i32 %t2101)
  store i1 %t2105, ptr %l684
  br label %bb457
bb457:
  %t2106 = load i1, ptr %l684, !tbaa !21
  %t2107 = xor i1 %t2106, true
  br i1 %t2107, label %bb458, label %bb459
bb458:
  store i1 true, ptr %l686, !tbaa !21
  br label %bb463
bb459:
  %t2109 = load ptr, ptr %l4, !tbaa !29
  store ptr %t2109, ptr %l687, !tbaa !29
  %t2110 = load ptr, ptr %l4, !tbaa !29
  store ptr %t2110, ptr %l688, !tbaa !29
  %t2111 = load ptr, ptr %l4, !tbaa !29
  %t2112 = load i32, ptr %l8, !tbaa !23
  %t2113 = load ptr, ptr @__olang_prog_scope
  %t2116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t2113, ptr %t2111, i32 %t2112)
  store i32 %t2116, ptr %l691
  br label %bb460
bb460:
  %t2117 = load ptr, ptr @__olang_prog_scope
  %t2118 = load ptr, ptr %l688, !tbaa !29
  %t2119 = load i32, ptr %l691, !tbaa !23
  %t2120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t2117, ptr %t2118, i32 %t2119)
  store i32 %t2120, ptr %l692
  br label %bb461
bb461:
  %t2121 = load ptr, ptr @__olang_prog_scope
  %t2122 = load ptr, ptr %l687, !tbaa !29
  %t2123 = load i32, ptr %l692, !tbaa !23
  %t2124 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t2121, ptr %t2122, i32 %t2123)
  store i1 %t2124, ptr %l693
  br label %bb462
bb462:
  %t2125 = load i1, ptr %l693, !tbaa !21
  %t2126 = xor i1 %t2125, true
  store i1 %t2126, ptr %l686, !tbaa !21
  br label %bb463
bb463:
  %t2128 = load i1, ptr %l686, !tbaa !21
  br i1 %t2128, label %bb464, label %bb465
bb464:
  store i1 true, ptr %l695, !tbaa !21
  br label %bb467
bb465:
  %t2129 = load ptr, ptr %l4, !tbaa !29
  %t2130 = load i32, ptr %l8, !tbaa !23
  %t2131 = load ptr, ptr @__olang_prog_scope
  %t2134 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t2131, ptr %t2129, i32 %t2130)
  store i64 %t2134, ptr %l698
  br label %bb466
bb466:
  %t2135 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t2136 = load i64, ptr %l698, !tbaa !24
  %t2138 = and i64 %t2136, %t2135
  %t2140 = icmp eq i64 %t2138, 0
  store i1 %t2140, ptr %l695, !tbaa !21
  br label %bb467
bb467:
  %t2142 = load i1, ptr %l695, !tbaa !21
  br i1 %t2142, label %bb468, label %bb469
bb468:
  store %olang.scope zeroinitializer, ptr %s107
  %t2143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2143, ptr %l702, !tbaa !29
  %t2144 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t2144, ptr %l703
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s108
  store ptr %s108room, ptr %s108
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s108, ptr %l703, i64 0)
  br label %bb470
bb469:
  %t2146 = load ptr, ptr %l4, !tbaa !29
  %t2147 = load i32, ptr %l8, !tbaa !23
  %t2148 = load ptr, ptr @__olang_prog_scope
  %t2151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t2148, ptr %t2146, i32 %t2147)
  store i32 %t2151, ptr %l715
  br label %bb474
bb470:
  %t2152 = load ptr, ptr %s108
  %t2153 = getelementptr %olang.builder, ptr %s108, i32 0, i32 1
  %t2154 = load i64, ptr %t2153
  %t2155 = call ptr @__olang_scope_alloc(ptr %s107, i64 %t2154)
  call void @olang_textcopy(ptr %t2155, ptr %t2152, i64 %t2154)
  %t2156 = insertvalue { i64, ptr } undef, i64 %t2154, 0
  %t2157 = insertvalue { i64, ptr } %t2156, ptr %t2155, 1
  store { i64, ptr } %t2157, ptr %l705, !tbaa !27
  %t2158 = getelementptr %olang.builder, ptr %s108, i32 0, i32 3
  %t2159 = load ptr, ptr %t2158
  %t2160 = icmp ne ptr %t2159, null
  br i1 %t2160, label %sbgrew.2161, label %sbdone.2162
sbgrew.2161:
  call void @__olang_sb_done(ptr %s108)
  br label %sbdone.2162
sbdone.2162:
  %t2163 = load { i64, ptr }, ptr %l705, !tbaa !27
  %t2164 = extractvalue { i64, ptr } %t2163, 0
  %t2165 = extractvalue { i64, ptr } %t2163, 1
  %t2166 = mul i64 %t2164, 1
  %t2167 = call ptr @__olang_scope_alloc(ptr %s107, i64 %t2166)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2167, ptr %t2165, i64 %t2166, i1 false)
  %t2168 = insertvalue { i64, ptr } undef, i64 %t2164, 0
  %t2169 = insertvalue { i64, ptr } %t2168, ptr %t2167, 1
  %t2171 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s107, ptr %s107, { i64, ptr } %t2169)
  store { i64, ptr } %t2171, ptr %l707
  br label %bb471
bb471:
  %t2172 = load ptr, ptr %l0, !tbaa !29
  %t2173 = load i32, ptr %l7, !tbaa !23
  %t2176 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s107, ptr %t2172, i32 %t2173)
  store { i64, ptr } %t2176, ptr %l710
  br label %bb472
bb472:
  %t2177 = load { i64, ptr }, ptr %l707, !tbaa !27
  %t2178 = extractvalue { i64, ptr } %t2177, 1
  %t2179 = extractvalue { i64, ptr } %t2177, 0
  %t2180 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t2181 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t2182 = add i64 %t2179, %t2181
  %t2183 = load { i64, ptr }, ptr %l710, !tbaa !27
  %t2184 = extractvalue { i64, ptr } %t2183, 1
  %t2185 = extractvalue { i64, ptr } %t2183, 0
  %t2186 = add i64 %t2182, %t2185
  %t2187 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t2188 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t2189 = add i64 %t2186, %t2188
  %t2190 = call ptr @__olang_scope_alloc(ptr %s107, i64 %t2189)
  call void @olang_textcopy(ptr %t2190, ptr %t2178, i64 %t2179)
  %t2191 = getelementptr i8, ptr %t2190, i64 %t2179
  call void @olang_textcopy(ptr %t2191, ptr %t2180, i64 %t2181)
  %t2192 = getelementptr i8, ptr %t2191, i64 %t2181
  call void @olang_textcopy(ptr %t2192, ptr %t2184, i64 %t2185)
  %t2193 = getelementptr i8, ptr %t2192, i64 %t2185
  call void @olang_textcopy(ptr %t2193, ptr %t2187, i64 %t2188)
  %t2194 = insertvalue { i64, ptr } undef, i64 %t2189, 0
  %t2195 = insertvalue { i64, ptr } %t2194, ptr %t2190, 1
  %t2197 = extractvalue { i64, ptr } %t2195, 0
  %t2198 = extractvalue { i64, ptr } %t2195, 1
  %t2199 = mul i64 %t2197, 1
  %t2200 = call ptr @__olang_scope_alloc(ptr %s107, i64 %t2199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2200, ptr %t2198, i64 %t2199, i1 false)
  %t2201 = insertvalue { i64, ptr } undef, i64 %t2197, 0
  %t2202 = insertvalue { i64, ptr } %t2201, ptr %t2200, 1
  %t2203 = load ptr, ptr %l702, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s107, ptr %t2203, { i64, ptr } %t2202)
  br label %bb473
bb473:
  call void @__olang_scope_close(ptr %s107)
  br label %bb508
bb474:
  %t2205 = load i32, ptr %l715, !tbaa !23
  store i32 %t2205, ptr %l17, !tbaa !23
  store i64 1, ptr %l18, !tbaa !24
  %t2206 = load i64, ptr %l5, !tbaa !24
  store i64 %t2206, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t2208 = load i64, ptr %l19, !tbaa !24
  %t2209 = load i64, ptr %l18, !tbaa !24
  %t2212 = icmp sgt i64 %t2208, %t2209
  br i1 %t2212, label %bb475, label %bb476
bb475:
  %t2214 = load i64, ptr %l20, !tbaa !24
  %t2216 = icmp sgt i64 %t2214, 0
  br i1 %t2216, label %bb477, label %bb478
bb476:
  store i64 0, ptr %l720, !tbaa !24
  br label %bb480
bb477:
  %t2218 = load i64, ptr %l19, !tbaa !24
  %t2219 = load i64, ptr %l18, !tbaa !24
  %t2222 = sub i64 %t2218, %t2219
  %t2223 = load i64, ptr %l20, !tbaa !24
  %t2226 = add i64 %t2222, %t2223
  %t2228 = sub i64 %t2226, 1
  %t2229 = load i64, ptr %l20, !tbaa !24
  %t2232 = sdiv i64 %t2228, %t2229
  store i64 %t2232, ptr %l723, !tbaa !24
  br label %bb479
bb478:
  store i64 0, ptr %l723, !tbaa !24
  br label %bb479
bb479:
  %t2234 = load i64, ptr %l723, !tbaa !24
  store i64 %t2234, ptr %l720, !tbaa !24
  br label %bb480
bb480:
  %t2235 = load i64, ptr %l720, !tbaa !24
  store i64 %t2235, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb481
bb481:
  store %olang.scope zeroinitializer, ptr %s112
  %t2236 = load i64, ptr %l22, !tbaa !24
  %t2237 = load i64, ptr %l21, !tbaa !24
  %t2240 = icmp slt i64 %t2236, %t2237
  %t2242 = xor i1 %t2240, true
  br i1 %t2242, label %bb482, label %bb483
bb482:
  call void @__olang_scope_close(ptr %s112)
  br label %bb491
bb483:
  br label %bb484
bb484:
  %t2244 = load i64, ptr %l18, !tbaa !24
  %t2245 = load i64, ptr %l22, !tbaa !24
  %t2246 = load i64, ptr %l20, !tbaa !24
  %t2249 = mul i64 %t2245, %t2246
  %t2252 = add i64 %t2244, %t2249
  store i64 %t2252, ptr %l23, !tbaa !24
  %t2254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2254, ptr %l741, !tbaa !29
  %t2255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2255, ptr %l742, !tbaa !29
  %t2256 = load ptr, ptr %l0, !tbaa !29
  %t2257 = load %"compiler/mir:Range", ptr %l3
  %t2258 = load i64, ptr %l23, !tbaa !24
  %t2262 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t2256, %"compiler/mir:Range" %t2257, i64 %t2258)
  store { i64, [4 x i64] } %t2262, ptr %l746
  br label %bb485
bb485:
  %t2263 = load ptr, ptr %l742, !tbaa !29
  %t2264 = load { i64, [4 x i64] }, ptr %l746
  %t2265 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t2263, { i64, [4 x i64] } %t2264)
  store i32 %t2265, ptr %l747
  br label %bb486
bb486:
  %t2266 = load i32, ptr %l17, !tbaa !23
  store i32 %t2266, ptr %l748, !tbaa !23
  %t2267 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t2267, ptr %l749
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s113
  store ptr %s113room, ptr %s113
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s113, ptr %l749, i64 0)
  br label %bb487
bb487:
  %t2269 = load ptr, ptr %s113
  %t2270 = getelementptr %olang.builder, ptr %s113, i32 0, i32 1
  %t2271 = load i64, ptr %t2270
  %t2272 = call ptr @__olang_scope_alloc(ptr %s112, i64 %t2271)
  call void @olang_textcopy(ptr %t2272, ptr %t2269, i64 %t2271)
  %t2273 = insertvalue { i64, ptr } undef, i64 %t2271, 0
  %t2274 = insertvalue { i64, ptr } %t2273, ptr %t2272, 1
  store { i64, ptr } %t2274, ptr %l751, !tbaa !27
  %t2275 = getelementptr %olang.builder, ptr %s113, i32 0, i32 3
  %t2276 = load ptr, ptr %t2275
  %t2277 = icmp ne ptr %t2276, null
  br i1 %t2277, label %sbgrew.2278, label %sbdone.2279
sbgrew.2278:
  call void @__olang_sb_done(ptr %s113)
  br label %sbdone.2279
sbdone.2279:
  %t2280 = load { i64, ptr }, ptr %l751, !tbaa !27
  %t2281 = extractvalue { i64, ptr } %t2280, 0
  %t2282 = extractvalue { i64, ptr } %t2280, 1
  %t2283 = mul i64 %t2281, 1
  %t2284 = call ptr @__olang_scope_alloc(ptr %s112, i64 %t2283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2284, ptr %t2282, i64 %t2283, i1 false)
  %t2285 = insertvalue { i64, ptr } undef, i64 %t2281, 0
  %t2286 = insertvalue { i64, ptr } %t2285, ptr %t2284, 1
  %t2288 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s112, ptr %s112, { i64, ptr } %t2286)
  store { i64, ptr } %t2288, ptr %l753
  br label %bb488
bb488:
  %t2289 = load i64, ptr %l23, !tbaa !24
  %t2290 = load { i64, ptr }, ptr %l753, !tbaa !27
  %t2291 = extractvalue { i64, ptr } %t2290, 1
  %t2292 = extractvalue { i64, ptr } %t2290, 0
  %t2293 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t2294 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t2295 = add i64 %t2292, %t2294
  %t2297 = call i64 @__olang_fmt_i64(ptr null, i64 %t2289)
  %t2298 = add i64 %t2295, %t2297
  %t2299 = call ptr @__olang_scope_alloc(ptr %s112, i64 %t2298)
  call void @olang_textcopy(ptr %t2299, ptr %t2291, i64 %t2292)
  %t2300 = getelementptr i8, ptr %t2299, i64 %t2292
  call void @olang_textcopy(ptr %t2300, ptr %t2293, i64 %t2294)
  %t2301 = getelementptr i8, ptr %t2300, i64 %t2294
  %t2302 = call i64 @__olang_fmt_i64(ptr %t2301, i64 %t2289)
  %t2303 = insertvalue { i64, ptr } undef, i64 %t2298, 0
  %t2304 = insertvalue { i64, ptr } %t2303, ptr %t2299, 1
  %t2306 = extractvalue { i64, ptr } %t2304, 0
  %t2307 = extractvalue { i64, ptr } %t2304, 1
  %t2308 = mul i64 %t2306, 1
  %t2309 = call ptr @__olang_scope_alloc(ptr %s112, i64 %t2308)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2309, ptr %t2307, i64 %t2308, i1 false)
  %t2310 = insertvalue { i64, ptr } undef, i64 %t2306, 0
  %t2311 = insertvalue { i64, ptr } %t2310, ptr %t2309, 1
  %t2312 = load ptr, ptr %l741, !tbaa !29
  %t2313 = load i32, ptr %l747, !tbaa !23
  %t2314 = load i32, ptr %l748, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s112, ptr %t2312, i32 %t2313, i32 %t2314, { i64, ptr } %t2311)
  br label %bb489
bb489:
  call void @__olang_scope_close(ptr %s112)
  br label %bb490
bb490:
  %t2316 = load i64, ptr %l22, !tbaa !24
  %t2318 = add i64 %t2316, 1
  store i64 %t2318, ptr %l22, !tbaa !24
  br label %bb481
bb491:
  %t2320 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t2322 = trunc i64 25 to i32
  %t2323 = icmp eq i32 %t2320, %t2322
  br i1 %t2323, label %bb492, label %bb493
bb492:
  %t2325 = load i32, ptr %l2, !tbaa !23
  %t2326 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t2329 = icmp ne i32 %t2325, %t2326
  br i1 %t2329, label %bb494, label %bb495
bb493:
  %t2331 = load ptr, ptr %l0, !tbaa !29
  %t2332 = load i32, ptr %l17, !tbaa !23
  %t2333 = load i32, ptr %l2, !tbaa !23
  %t2337 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t2331, i32 %t2332, i32 %t2333)
  store i1 %t2337, ptr %l773
  br label %bb499
bb494:
  store %olang.scope zeroinitializer, ptr %s117
  %t2338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2338, ptr %l764, !tbaa !29
  %t2339 = load ptr, ptr %l0, !tbaa !29
  %t2340 = load i32, ptr %l2, !tbaa !23
  %t2343 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s117, ptr %t2339, i32 %t2340)
  store { i64, ptr } %t2343, ptr %l767
  br label %bb496
bb495:
  br label %bb498
bb496:
  %t2344 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t2345 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t2346 = load { i64, ptr }, ptr %l767, !tbaa !27
  %t2347 = extractvalue { i64, ptr } %t2346, 1
  %t2348 = extractvalue { i64, ptr } %t2346, 0
  %t2349 = add i64 %t2345, %t2348
  %t2350 = call ptr @__olang_scope_alloc(ptr %s117, i64 %t2349)
  call void @olang_textcopy(ptr %t2350, ptr %t2344, i64 %t2345)
  %t2351 = getelementptr i8, ptr %t2350, i64 %t2345
  call void @olang_textcopy(ptr %t2351, ptr %t2347, i64 %t2348)
  %t2352 = insertvalue { i64, ptr } undef, i64 %t2349, 0
  %t2353 = insertvalue { i64, ptr } %t2352, ptr %t2350, 1
  %t2355 = extractvalue { i64, ptr } %t2353, 0
  %t2356 = extractvalue { i64, ptr } %t2353, 1
  %t2357 = mul i64 %t2355, 1
  %t2358 = call ptr @__olang_scope_alloc(ptr %s117, i64 %t2357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2358, ptr %t2356, i64 %t2357, i1 false)
  %t2359 = insertvalue { i64, ptr } undef, i64 %t2355, 0
  %t2360 = insertvalue { i64, ptr } %t2359, ptr %t2358, 1
  %t2361 = load ptr, ptr %l764, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s117, ptr %t2361, { i64, ptr } %t2360)
  br label %bb497
bb497:
  call void @__olang_scope_close(ptr %s117)
  br label %bb498
bb498:
  br label %bb507
bb499:
  %t2363 = load i1, ptr %l773, !tbaa !21
  %t2364 = xor i1 %t2363, true
  br i1 %t2364, label %bb500, label %bb501
bb500:
  store %olang.scope zeroinitializer, ptr %s120
  %t2366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2366, ptr %l775, !tbaa !29
  %t2367 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t2367, ptr %l776
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s121
  store ptr %s121room, ptr %s121
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s121, ptr %l776, i64 0)
  br label %bb502
bb501:
  br label %bb506
bb502:
  %t2369 = load ptr, ptr %s121
  %t2370 = getelementptr %olang.builder, ptr %s121, i32 0, i32 1
  %t2371 = load i64, ptr %t2370
  %t2372 = call ptr @__olang_scope_alloc(ptr %s120, i64 %t2371)
  call void @olang_textcopy(ptr %t2372, ptr %t2369, i64 %t2371)
  %t2373 = insertvalue { i64, ptr } undef, i64 %t2371, 0
  %t2374 = insertvalue { i64, ptr } %t2373, ptr %t2372, 1
  store { i64, ptr } %t2374, ptr %l778, !tbaa !27
  %t2375 = getelementptr %olang.builder, ptr %s121, i32 0, i32 3
  %t2376 = load ptr, ptr %t2375
  %t2377 = icmp ne ptr %t2376, null
  br i1 %t2377, label %sbgrew.2378, label %sbdone.2379
sbgrew.2378:
  call void @__olang_sb_done(ptr %s121)
  br label %sbdone.2379
sbdone.2379:
  %t2380 = load { i64, ptr }, ptr %l778, !tbaa !27
  %t2381 = extractvalue { i64, ptr } %t2380, 0
  %t2382 = extractvalue { i64, ptr } %t2380, 1
  %t2383 = mul i64 %t2381, 1
  %t2384 = call ptr @__olang_scope_alloc(ptr %s120, i64 %t2383)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2384, ptr %t2382, i64 %t2383, i1 false)
  %t2385 = insertvalue { i64, ptr } undef, i64 %t2381, 0
  %t2386 = insertvalue { i64, ptr } %t2385, ptr %t2384, 1
  %t2388 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s120, ptr %s120, { i64, ptr } %t2386)
  store { i64, ptr } %t2388, ptr %l780
  br label %bb503
bb503:
  %t2389 = load ptr, ptr %l0, !tbaa !29
  %t2390 = load i32, ptr %l2, !tbaa !23
  %t2393 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s120, ptr %t2389, i32 %t2390)
  store { i64, ptr } %t2393, ptr %l783
  br label %bb504
bb504:
  %t2394 = load { i64, ptr }, ptr %l780, !tbaa !27
  %t2395 = extractvalue { i64, ptr } %t2394, 1
  %t2396 = extractvalue { i64, ptr } %t2394, 0
  %t2397 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t2398 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t2399 = add i64 %t2396, %t2398
  %t2400 = load { i64, ptr }, ptr %l783, !tbaa !27
  %t2401 = extractvalue { i64, ptr } %t2400, 1
  %t2402 = extractvalue { i64, ptr } %t2400, 0
  %t2403 = add i64 %t2399, %t2402
  %t2404 = call ptr @__olang_scope_alloc(ptr %s120, i64 %t2403)
  call void @olang_textcopy(ptr %t2404, ptr %t2395, i64 %t2396)
  %t2405 = getelementptr i8, ptr %t2404, i64 %t2396
  call void @olang_textcopy(ptr %t2405, ptr %t2397, i64 %t2398)
  %t2406 = getelementptr i8, ptr %t2405, i64 %t2398
  call void @olang_textcopy(ptr %t2406, ptr %t2401, i64 %t2402)
  %t2407 = insertvalue { i64, ptr } undef, i64 %t2403, 0
  %t2408 = insertvalue { i64, ptr } %t2407, ptr %t2404, 1
  %t2410 = extractvalue { i64, ptr } %t2408, 0
  %t2411 = extractvalue { i64, ptr } %t2408, 1
  %t2412 = mul i64 %t2410, 1
  %t2413 = call ptr @__olang_scope_alloc(ptr %s120, i64 %t2412)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2413, ptr %t2411, i64 %t2412, i1 false)
  %t2414 = insertvalue { i64, ptr } undef, i64 %t2410, 0
  %t2415 = insertvalue { i64, ptr } %t2414, ptr %t2413, 1
  %t2416 = load ptr, ptr %l775, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s120, ptr %t2416, { i64, ptr } %t2415)
  br label %bb505
bb505:
  call void @__olang_scope_close(ptr %s120)
  br label %bb506
bb506:
  br label %bb507
bb507:
  br label %bb508
bb508:
  br label %bb510
bb509:
  call void @__olang_check_failed(ptr @olang_loc_7968c2a45e42402b_522993cc8bbef1e7)
  unreachable
bb510:
  %t2418 = load i32, ptr %l2, !tbaa !23
  store i32 %t2418, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprojected(ptr %v0, ptr %a0, i32 %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l25 = alloca i32
  %l29 = alloca i1
  %l32 = alloca { i64, ptr }
  %l35 = alloca i1
  %l38 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i64
  %l47 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l63 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l76 = alloca i32
  %l80 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l89 = alloca i32
  %l95 = alloca i32
  %l99 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l108 = alloca i32
  %l111 = alloca i1
  %l114 = alloca i1
  %l117 = alloca i32
  %l120 = alloca i1
  %l121 = alloca i64
  %l124 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca i64
  %l130 = alloca { i64, ptr }
  %l135 = alloca i32
  %l140 = alloca i1
  %l142 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l151 = alloca i32
  %l158 = alloca i32
  %l162 = alloca i1
  %l165 = alloca { i64, ptr }
  %l168 = alloca i1
  %l171 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i64
  %l180 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l189 = alloca i64
  %l192 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, [1 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load { i64, [1 x i64] }, ptr %l2
  %t8 = extractvalue { i64, [1 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb18
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/mir:verifier", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t20 = load ptr, ptr @__olang_prog_scope
  %t23 = call i32 @compiler_2fmir_2eFieldsOf(ptr %t20, ptr %t18, i32 %t19)
  store i32 %t23, ptr %l25
  br label %bb4
bb4:
  %t24 = load i32, ptr %l25, !tbaa !23
  store i32 %t24, ptr %l5, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/mir:verifier", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t30 = load ptr, ptr @__olang_prog_scope
  %t33 = call i1 @compiler_2fmir_2eHasFields(ptr %t30, ptr %t28, i32 %t29)
  store i1 %t33, ptr %l29
  br label %bb5
bb5:
  %t34 = load i1, ptr %l29, !tbaa !21
  store i1 %t34, ptr %l6, !tbaa !21
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t36 = load i32, ptr %l5, !tbaa !23
  %t37 = load ptr, ptr @__olang_prog_scope
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t37, ptr %s1, ptr %t35, i32 %t36)
  store { i64, ptr } %t40, ptr %l32
  br label %bb6
bb6:
  %t41 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t41, ptr %l7, !tbaa !27
  %t42 = load i1, ptr %l6, !tbaa !21
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb9
bb8:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp slt i64 %t46, 0
  store i1 %t48, ptr %l35, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l35, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb12
bb11:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t57 = icmp sge i64 %t51, %t54
  store i1 %t57, ptr %l38, !tbaa !21
  br label %bb12
bb12:
  %t59 = load i1, ptr %l38, !tbaa !21
  br i1 %t59, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l43, !tbaa !29
  %t61 = load i64, ptr %l4, !tbaa !24
  store i64 %t61, ptr %l44, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l1, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s2, ptr %t62, i32 %t63)
  store { i64, ptr } %t66, ptr %l47
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t67 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t69 = load i64, ptr %l44, !tbaa !24
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t71 = add i64 %t68, %t70
  %t72 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t67, i64 %t68)
  %t80 = getelementptr i8, ptr %t79, i64 %t68
  %t81 = call i64 @__olang_fmt_i64(ptr %t80, i64 %t69)
  %t82 = getelementptr i8, ptr %t80, i64 %t70
  call void @olang_textcopy(ptr %t82, ptr %t72, i64 %t73)
  %t83 = getelementptr i8, ptr %t82, i64 %t73
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t79, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t93, { i64, ptr } %t92)
  br label %bb16
bb16:
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store i32 %t95, ptr %rv
  br label %ret
bb17:
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t97, ptr %l51, !tbaa !27
  %t98 = load i64, ptr %l4, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i32, ptr %t101, i64 %t98
  %t103 = load i32, ptr %t102, !tbaa !33
  call void @__olang_scope_close(ptr %s1)
  store i32 %t103, ptr %rv
  br label %ret
bb18:
  %t105 = load { i64, [1 x i64] }, ptr %l2
  %t107 = extractvalue { i64, [1 x i64] } %t105, 0
  %t108 = icmp eq i64 %t107, 1
  br i1 %t108, label %bb19, label %bb20
bb19:
  %t110 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t111 = getelementptr { i32 }, ptr %t110, i32 0, i32 0
  %t112 = load i32, ptr %t111
  store i32 %t112, ptr %l8, !tbaa !23
  br label %bb21
bb20:
  br label %bb38
bb21:
  %t114 = load ptr, ptr %l3, !tbaa !29
  store ptr %t114, ptr %l57, !tbaa !29
  %t115 = load ptr, ptr %l3, !tbaa !29
  store ptr %t115, ptr %l58, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l8, !tbaa !23
  %t120 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l61
  br label %bb22
bb22:
  %t121 = load ptr, ptr @__olang_prog_scope
  %t122 = load ptr, ptr %l58, !tbaa !29
  %t123 = load i32, ptr %l61, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t121, ptr %t122, i32 %t123)
  store i32 %t124, ptr %l62
  br label %bb23
bb23:
  %t125 = load ptr, ptr @__olang_prog_scope
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = load i32, ptr %l62, !tbaa !23
  %t128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t125, ptr %t126, i32 %t127)
  store i1 %t128, ptr %l63
  br label %bb24
bb24:
  %t129 = load i1, ptr %l63, !tbaa !21
  %t130 = xor i1 %t129, true
  br i1 %t130, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l65, !tbaa !29
  %t133 = load i32, ptr %l8, !tbaa !23
  store i32 %t133, ptr %l66, !tbaa !23
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l67, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l8, !tbaa !23
  %t139 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t139, ptr %l70
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t140 = load ptr, ptr %l67, !tbaa !29
  %t141 = load i32, ptr %l70, !tbaa !23
  %t142 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t140, i32 %t141)
  store { i64, ptr } %t142, ptr %l71
  br label %bb28
bb28:
  %t143 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t145 = load i32, ptr %l66, !tbaa !23
  %t146 = sext i32 %t145 to i64
  %t147 = call i64 @__olang_fmt_i64(ptr null, i64 %t146)
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t152 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = add i64 %t151, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t143, i64 %t144)
  %t157 = getelementptr i8, ptr %t156, i64 %t144
  %t158 = call i64 @__olang_fmt_i64(ptr %t157, i64 %t146)
  %t159 = getelementptr i8, ptr %t157, i64 %t147
  call void @olang_textcopy(ptr %t159, ptr %t149, i64 %t150)
  %t160 = getelementptr i8, ptr %t159, i64 %t150
  call void @olang_textcopy(ptr %t160, ptr %t153, i64 %t154)
  %t161 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t156, 1
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t165 = extractvalue { i64, ptr } %t162, 1
  %t166 = mul i64 %t164, 1
  %t167 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t166)
  call void @llvm.memcpy.p0.p0.i64(ptr %t167, ptr %t165, i64 %t166, i1 false)
  %t168 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  %t170 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t170, { i64, ptr } %t169)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l1, !tbaa !23
  %t176 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l76
  br label %bb31
bb31:
  %t177 = load i32, ptr %l76, !tbaa !23
  store i32 %t177, ptr %l9, !tbaa !23
  %t178 = load i32, ptr %l9, !tbaa !23
  %t179 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t182 = icmp eq i32 %t178, %t179
  br i1 %t182, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l80, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s7, ptr %t185, i32 %t186)
  store { i64, ptr } %t189, ptr %l83
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t190 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t192 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = add i64 %t191, %t194
  %t196 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t197 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t198 = add i64 %t195, %t197
  %t199 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t198)
  call void @olang_textcopy(ptr %t199, ptr %t190, i64 %t191)
  %t200 = getelementptr i8, ptr %t199, i64 %t191
  call void @olang_textcopy(ptr %t200, ptr %t193, i64 %t194)
  %t201 = getelementptr i8, ptr %t200, i64 %t194
  call void @olang_textcopy(ptr %t201, ptr %t196, i64 %t197)
  %t202 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t199, 1
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = extractvalue { i64, ptr } %t203, 1
  %t207 = mul i64 %t205, 1
  %t208 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t207)
  call void @llvm.memcpy.p0.p0.i64(ptr %t208, ptr %t206, i64 %t207, i1 false)
  %t209 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t211 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s7, ptr %t211, { i64, ptr } %t210)
  br label %bb35
bb35:
  %t213 = load i32, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  store i32 %t213, ptr %rv
  br label %ret
bb36:
  %t215 = load ptr, ptr %l3, !tbaa !29
  %t216 = load i32, ptr %l9, !tbaa !23
  %t217 = load ptr, ptr @__olang_prog_scope
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t217, ptr %t215, i32 %t216)
  store i32 %t220, ptr %l89
  br label %bb37
bb37:
  %t221 = load i32, ptr %l89, !tbaa !23
  store i32 %t221, ptr %rv
  br label %ret
bb38:
  %t222 = load { i64, [1 x i64] }, ptr %l2
  %t224 = extractvalue { i64, [1 x i64] } %t222, 0
  %t225 = icmp eq i64 %t224, 2
  br i1 %t225, label %bb39, label %bb40
bb39:
  %t227 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t228 = getelementptr { i64 }, ptr %t227, i32 0, i32 0
  %t229 = load i64, ptr %t228
  store i64 %t229, ptr %l10, !tbaa !24
  br label %bb41
bb40:
  br label %bb66
bb41:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load i32, ptr %l1, !tbaa !23
  %t235 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t231, i32 %t232)
  store i32 %t235, ptr %l95
  br label %bb42
bb42:
  %t236 = load i32, ptr %l95, !tbaa !23
  store i32 %t236, ptr %l11, !tbaa !23
  %t237 = load i32, ptr %l11, !tbaa !23
  %t238 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t241 = icmp eq i32 %t237, %t238
  br i1 %t241, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l99, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i32, ptr %l1, !tbaa !23
  %t248 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s10, ptr %t244, i32 %t245)
  store { i64, ptr } %t248, ptr %l102
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t249 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t251 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = add i64 %t250, %t253
  %t255 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t257 = add i64 %t254, %t256
  %t258 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t257)
  call void @olang_textcopy(ptr %t258, ptr %t249, i64 %t250)
  %t259 = getelementptr i8, ptr %t258, i64 %t250
  call void @olang_textcopy(ptr %t259, ptr %t252, i64 %t253)
  %t260 = getelementptr i8, ptr %t259, i64 %t253
  call void @olang_textcopy(ptr %t260, ptr %t255, i64 %t256)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t258, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } %t262, 1
  %t266 = mul i64 %t264, 1
  %t267 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t267, ptr %t265, i64 %t266, i1 false)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t270 = load ptr, ptr %l99, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t270, { i64, ptr } %t269)
  br label %bb46
bb46:
  %t272 = load i32, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  store i32 %t272, ptr %rv
  br label %ret
bb47:
  %t274 = load ptr, ptr %l3, !tbaa !29
  %t275 = load i32, ptr %l11, !tbaa !23
  %t276 = load ptr, ptr @__olang_prog_scope
  %t279 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t276, ptr %t274, i32 %t275)
  store i32 %t279, ptr %l108
  br label %bb48
bb48:
  %t280 = load i32, ptr %l108, !tbaa !23
  store i32 %t280, ptr %l12, !tbaa !23
  %t281 = load i64, ptr %l10, !tbaa !24
  %t283 = icmp slt i64 %t281, 0
  br i1 %t283, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb59
bb50:
  %t285 = load i32, ptr %l12, !tbaa !23
  %t287 = icmp ne i32 %t285, 0
  br i1 %t287, label %bb51, label %bb52
bb51:
  %t289 = load ptr, ptr %l3, !tbaa !29
  %t290 = load i32, ptr %l12, !tbaa !23
  %t291 = load ptr, ptr @__olang_prog_scope
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t291, ptr %t289, i32 %t290)
  store i32 %t294, ptr %l117
  br label %bb53
bb52:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb54
bb53:
  %t295 = load i32, ptr %l117, !range !{i32 0, i32 33}
  %t297 = trunc i64 26 to i32
  %t298 = icmp eq i32 %t295, %t297
  store i1 %t298, ptr %l114, !tbaa !21
  br label %bb54
bb54:
  %t300 = load i1, ptr %l114, !tbaa !21
  br i1 %t300, label %bb55, label %bb56
bb55:
  %t301 = load i64, ptr %l10, !tbaa !24
  store i64 %t301, ptr %l121, !tbaa !24
  %t302 = load ptr, ptr %l3, !tbaa !29
  %t303 = load i32, ptr %l12, !tbaa !23
  %t304 = load ptr, ptr @__olang_prog_scope
  %t307 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %t304, ptr %t302, i32 %t303)
  store i64 %t307, ptr %l124
  br label %bb57
bb56:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb58
bb57:
  %t308 = load i64, ptr %l121, !tbaa !24
  %t309 = load i64, ptr %l124, !tbaa !24
  %t310 = icmp sge i64 %t308, %t309
  store i1 %t310, ptr %l120, !tbaa !21
  br label %bb58
bb58:
  %t312 = load i1, ptr %l120, !tbaa !21
  store i1 %t312, ptr %l111, !tbaa !21
  br label %bb59
bb59:
  %t313 = load i1, ptr %l111, !tbaa !21
  br i1 %t313, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s12
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l126, !tbaa !29
  %t315 = load i64, ptr %l10, !tbaa !24
  store i64 %t315, ptr %l127, !tbaa !24
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load i32, ptr %l1, !tbaa !23
  %t320 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s12, ptr %t316, i32 %t317)
  store { i64, ptr } %t320, ptr %l130
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t321 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t322 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t323 = load i64, ptr %l127, !tbaa !24
  %t324 = call i64 @__olang_fmt_i64(ptr null, i64 %t323)
  %t325 = add i64 %t322, %t324
  %t326 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t327 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t328 = add i64 %t325, %t327
  %t329 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = add i64 %t328, %t331
  %t333 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t321, i64 %t322)
  %t334 = getelementptr i8, ptr %t333, i64 %t322
  %t335 = call i64 @__olang_fmt_i64(ptr %t334, i64 %t323)
  %t336 = getelementptr i8, ptr %t334, i64 %t324
  call void @olang_textcopy(ptr %t336, ptr %t326, i64 %t327)
  %t337 = getelementptr i8, ptr %t336, i64 %t327
  call void @olang_textcopy(ptr %t337, ptr %t330, i64 %t331)
  %t338 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t333, 1
  %t341 = extractvalue { i64, ptr } %t339, 0
  %t342 = extractvalue { i64, ptr } %t339, 1
  %t343 = mul i64 %t341, 1
  %t344 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t343)
  call void @llvm.memcpy.p0.p0.i64(ptr %t344, ptr %t342, i64 %t343, i1 false)
  %t345 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t344, 1
  %t347 = load ptr, ptr %l126, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s12, ptr %t347, { i64, ptr } %t346)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  %t349 = load ptr, ptr %l3, !tbaa !29
  %t350 = load i32, ptr %l11, !tbaa !23
  %t351 = load ptr, ptr @__olang_prog_scope
  %t354 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t351, ptr %t349, i32 %t350)
  store i32 %t354, ptr %l135
  br label %bb65
bb65:
  %t355 = load i32, ptr %l135, !tbaa !23
  store i32 %t355, ptr %rv
  br label %ret
bb66:
  %t356 = load { i64, [1 x i64] }, ptr %l2
  %t358 = extractvalue { i64, [1 x i64] } %t356, 0
  %t359 = icmp eq i64 %t358, 3
  br i1 %t359, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb77
bb69:
  %t361 = load ptr, ptr %l3, !tbaa !29
  %t362 = load i32, ptr %l1, !tbaa !23
  %t363 = load ptr, ptr @__olang_prog_scope
  %t366 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t363, ptr %t361, i32 %t362)
  store i1 %t366, ptr %l140
  br label %bb70
bb70:
  %t367 = load i1, ptr %l140, !tbaa !21
  %t368 = xor i1 %t367, true
  br i1 %t368, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s15
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l142, !tbaa !29
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i32, ptr %l1, !tbaa !23
  %t375 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s15, ptr %t371, i32 %t372)
  store { i64, ptr } %t375, ptr %l145
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t376 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t377 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t378 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t379 = extractvalue { i64, ptr } %t378, 1
  %t380 = extractvalue { i64, ptr } %t378, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t384 = add i64 %t381, %t383
  %t385 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t376, i64 %t377)
  %t386 = getelementptr i8, ptr %t385, i64 %t377
  call void @olang_textcopy(ptr %t386, ptr %t379, i64 %t380)
  %t387 = getelementptr i8, ptr %t386, i64 %t380
  call void @olang_textcopy(ptr %t387, ptr %t382, i64 %t383)
  %t388 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t385, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = extractvalue { i64, ptr } %t389, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  %t397 = load ptr, ptr %l142, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s15, ptr %t397, { i64, ptr } %t396)
  br label %bb74
bb74:
  %t399 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  store i32 %t399, ptr %rv
  br label %ret
bb75:
  %t401 = load ptr, ptr %l3, !tbaa !29
  %t402 = load i32, ptr %l1, !tbaa !23
  %t403 = load ptr, ptr @__olang_prog_scope
  %t406 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t403, ptr %t401, i32 %t402)
  store i32 %t406, ptr %l151
  br label %bb76
bb76:
  %t407 = load i32, ptr %l151, !tbaa !23
  store i32 %t407, ptr %rv
  br label %ret
bb77:
  %t408 = load { i64, [1 x i64] }, ptr %l2
  %t410 = extractvalue { i64, [1 x i64] } %t408, 0
  %t411 = icmp eq i64 %t410, 4
  br i1 %t411, label %bb78, label %bb79
bb78:
  %t413 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t414 = getelementptr { i64 }, ptr %t413, i32 0, i32 0
  %t415 = load i64, ptr %t414
  store i64 %t415, ptr %l13, !tbaa !24
  br label %bb80
bb79:
  br label %bb100
bb80:
  store %olang.scope zeroinitializer, ptr %s17
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/mir:verifier", ptr %t417, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t421 = load i32, ptr %l1, !tbaa !23
  %t422 = load ptr, ptr @__olang_prog_scope
  %t425 = call i32 @compiler_2fmir_2eCasesOf(ptr %t422, ptr %t420, i32 %t421)
  store i32 %t425, ptr %l158
  br label %bb81
bb81:
  %t426 = load i32, ptr %l158, !tbaa !23
  store i32 %t426, ptr %l14, !tbaa !23
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/mir:verifier", ptr %t427, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t431 = load i32, ptr %l1, !tbaa !23
  %t432 = load ptr, ptr @__olang_prog_scope
  %t435 = call i1 @compiler_2fmir_2eHasCases(ptr %t432, ptr %t430, i32 %t431)
  store i1 %t435, ptr %l162
  br label %bb82
bb82:
  %t436 = load i1, ptr %l162, !tbaa !21
  store i1 %t436, ptr %l15, !tbaa !21
  %t437 = load ptr, ptr %l3, !tbaa !29
  %t438 = load i32, ptr %l14, !tbaa !23
  %t439 = load ptr, ptr @__olang_prog_scope
  %t442 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t439, ptr %s17, ptr %t437, i32 %t438)
  store { i64, ptr } %t442, ptr %l165
  br label %bb83
bb83:
  %t443 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t443, ptr %l16, !tbaa !27
  %t444 = load i1, ptr %l15, !tbaa !21
  %t446 = xor i1 %t444, true
  br i1 %t446, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l168, !tbaa !21
  br label %bb86
bb85:
  %t448 = load i64, ptr %l13, !tbaa !24
  %t450 = icmp slt i64 %t448, 0
  store i1 %t450, ptr %l168, !tbaa !21
  br label %bb86
bb86:
  %t452 = load i1, ptr %l168, !tbaa !21
  br i1 %t452, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l171, !tbaa !21
  br label %bb89
bb88:
  %t453 = load i64, ptr %l13, !tbaa !24
  %t454 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t456 = extractvalue { i64, ptr } %t454, 0
  %t459 = icmp sge i64 %t453, %t456
  store i1 %t459, ptr %l171, !tbaa !21
  br label %bb89
bb89:
  %t461 = load i1, ptr %l171, !tbaa !21
  br i1 %t461, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s18
  %t462 = load ptr, ptr %l0, !tbaa !29
  store ptr %t462, ptr %l176, !tbaa !29
  %t463 = load i64, ptr %l13, !tbaa !24
  store i64 %t463, ptr %l177, !tbaa !24
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t465 = load i32, ptr %l1, !tbaa !23
  %t468 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s18, ptr %t464, i32 %t465)
  store { i64, ptr } %t468, ptr %l180
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t469 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t470 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t471 = load i64, ptr %l177, !tbaa !24
  %t472 = call i64 @__olang_fmt_i64(ptr null, i64 %t471)
  %t473 = add i64 %t470, %t472
  %t474 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t475 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t476 = add i64 %t473, %t475
  %t477 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t477, 1
  %t479 = extractvalue { i64, ptr } %t477, 0
  %t480 = add i64 %t476, %t479
  %t481 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t480)
  call void @olang_textcopy(ptr %t481, ptr %t469, i64 %t470)
  %t482 = getelementptr i8, ptr %t481, i64 %t470
  %t483 = call i64 @__olang_fmt_i64(ptr %t482, i64 %t471)
  %t484 = getelementptr i8, ptr %t482, i64 %t472
  call void @olang_textcopy(ptr %t484, ptr %t474, i64 %t475)
  %t485 = getelementptr i8, ptr %t484, i64 %t475
  call void @olang_textcopy(ptr %t485, ptr %t478, i64 %t479)
  %t486 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t481, 1
  %t489 = extractvalue { i64, ptr } %t487, 0
  %t490 = extractvalue { i64, ptr } %t487, 1
  %t491 = mul i64 %t489, 1
  %t492 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t491)
  call void @llvm.memcpy.p0.p0.i64(ptr %t492, ptr %t490, i64 %t491, i1 false)
  %t493 = insertvalue { i64, ptr } undef, i64 %t489, 0
  %t494 = insertvalue { i64, ptr } %t493, ptr %t492, 1
  %t495 = load ptr, ptr %l176, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s18, ptr %t495, { i64, ptr } %t494)
  br label %bb93
bb93:
  %t497 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s17)
  store i32 %t497, ptr %rv
  br label %ret
bb94:
  %t499 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t499, ptr %l184, !tbaa !27
  %t500 = load i64, ptr %l13, !tbaa !24
  %t502 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t503 = load ptr, ptr %t502, !tbaa !27
  %t504 = getelementptr i32, ptr %t503, i64 %t500
  %t505 = load i32, ptr %t504, !tbaa !33
  %t507 = icmp eq i32 %t505, 0
  br i1 %t507, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s20
  %t509 = load ptr, ptr %l0, !tbaa !29
  store ptr %t509, ptr %l188, !tbaa !29
  %t510 = load i64, ptr %l13, !tbaa !24
  store i64 %t510, ptr %l189, !tbaa !24
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load i32, ptr %l1, !tbaa !23
  %t515 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s20, ptr %t511, i32 %t512)
  store { i64, ptr } %t515, ptr %l192
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t516 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t517 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t518 = load i64, ptr %l189, !tbaa !24
  %t519 = call i64 @__olang_fmt_i64(ptr null, i64 %t518)
  %t520 = add i64 %t517, %t519
  %t521 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t522 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t523 = add i64 %t520, %t522
  %t524 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t525 = extractvalue { i64, ptr } %t524, 1
  %t526 = extractvalue { i64, ptr } %t524, 0
  %t527 = add i64 %t523, %t526
  %t528 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t529 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t530 = add i64 %t527, %t529
  %t531 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t530)
  call void @olang_textcopy(ptr %t531, ptr %t516, i64 %t517)
  %t532 = getelementptr i8, ptr %t531, i64 %t517
  %t533 = call i64 @__olang_fmt_i64(ptr %t532, i64 %t518)
  %t534 = getelementptr i8, ptr %t532, i64 %t519
  call void @olang_textcopy(ptr %t534, ptr %t521, i64 %t522)
  %t535 = getelementptr i8, ptr %t534, i64 %t522
  call void @olang_textcopy(ptr %t535, ptr %t525, i64 %t526)
  %t536 = getelementptr i8, ptr %t535, i64 %t526
  call void @olang_textcopy(ptr %t536, ptr %t528, i64 %t529)
  %t537 = insertvalue { i64, ptr } undef, i64 %t530, 0
  %t538 = insertvalue { i64, ptr } %t537, ptr %t531, 1
  %t540 = extractvalue { i64, ptr } %t538, 0
  %t541 = extractvalue { i64, ptr } %t538, 1
  %t542 = mul i64 %t540, 1
  %t543 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t542)
  call void @llvm.memcpy.p0.p0.i64(ptr %t543, ptr %t541, i64 %t542, i1 false)
  %t544 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  %t546 = load ptr, ptr %l188, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s20, ptr %t546, { i64, ptr } %t545)
  br label %bb98
bb98:
  %t548 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s17)
  store i32 %t548, ptr %rv
  br label %ret
bb99:
  %t550 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t550, ptr %l196, !tbaa !27
  %t551 = load i64, ptr %l13, !tbaa !24
  %t553 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t554 = load ptr, ptr %t553, !tbaa !27
  %t555 = getelementptr i32, ptr %t554, i64 %t551
  %t556 = load i32, ptr %t555, !tbaa !33
  call void @__olang_scope_close(ptr %s17)
  store i32 %t556, ptr %rv
  br label %ret
bb100:
  call void @__olang_check_failed(ptr @olang_loc_5e1988e97d308376_f66bcffef950dfda)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Range"
  %l7 = alloca i64
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store %"compiler/mir:Range" %a1, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/mir:verifier", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 12
  %t9 = load ptr, ptr @__olang_prog_scope
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %t9, ptr %t8)
  store i64 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load %"compiler/mir:Range", ptr %l3
  %t14 = load i64, ptr %l7, !tbaa !24
  %t15 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s0, ptr %t12, %"compiler/mir:Range" %t13, i64 %t14, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d228, i32 0, i32 1) })
  store i1 %t15, ptr %l8
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueShape(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [1 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Lvalue"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca %"compiler/mir:Range"
  %l15 = alloca %"compiler/mir:Range"
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca { i64, [1 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t10, { i64, [4 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb79
bb5:
  %t14 = load { i64, [15 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [15 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t19, i32 0, i32 0
  %t21 = load %"compiler/mir:Lvalue", ptr %t20
  store %"compiler/mir:Lvalue" %t21, ptr %l3
  br label %bb12
bb7:
  %t23 = load { i64, [15 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [15 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t28, i32 0, i32 0
  %t30 = load %"compiler/mir:Lvalue", ptr %t29
  store %"compiler/mir:Lvalue" %t30, ptr %l3
  br label %bb12
bb9:
  %t32 = load { i64, [15 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [15 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 5
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/mir:Lvalue", ptr %t38
  store %"compiler/mir:Lvalue" %t39, ptr %l3
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/mir:Lvalue", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t41, %"compiler/mir:Lvalue" %t42)
  br label %bb13
bb13:
  br label %bb79
bb14:
  %t45 = load { i64, [15 x i64] }, ptr %l1
  %t47 = extractvalue { i64, [15 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 3
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t51 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t50, i32 0, i32 2
  %t52 = load %"compiler/mir:Range", ptr %t51
  store %"compiler/mir:Range" %t52, ptr %l4
  br label %bb21
bb16:
  %t54 = load { i64, [15 x i64] }, ptr %l1
  %t56 = extractvalue { i64, [15 x i64] } %t54, 0
  %t57 = icmp eq i64 %t56, 4
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t60 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t59, i32 0, i32 2
  %t61 = load %"compiler/mir:Range", ptr %t60
  store %"compiler/mir:Range" %t61, ptr %l4
  br label %bb21
bb18:
  %t63 = load { i64, [15 x i64] }, ptr %l1
  %t65 = extractvalue { i64, [15 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 6
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t69 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t68, i32 0, i32 2
  %t70 = load %"compiler/mir:Range", ptr %t69
  store %"compiler/mir:Range" %t70, ptr %l4
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load %"compiler/mir:Range", ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t72, %"compiler/mir:Range" %t73)
  br label %bb22
bb22:
  br label %bb79
bb23:
  %t76 = load { i64, [15 x i64] }, ptr %l1
  %t78 = extractvalue { i64, [15 x i64] } %t76, 0
  %t79 = icmp eq i64 %t78, 7
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t81 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t82 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t81, i32 0, i32 0
  %t83 = load { i64, [1 x i64] }, ptr %t82
  store { i64, [1 x i64] } %t83, ptr %l5
  %t85 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t86 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t85, i32 0, i32 1
  %t87 = load { i64, [4 x i64] }, ptr %t86
  store { i64, [4 x i64] } %t87, ptr %l6
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load { i64, [1 x i64] }, ptr %l5
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t89, { i64, [1 x i64] } %t90)
  br label %bb27
bb27:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t93, { i64, [4 x i64] } %t94)
  br label %bb28
bb28:
  br label %bb79
bb29:
  %t97 = load { i64, [15 x i64] }, ptr %l1
  %t99 = extractvalue { i64, [15 x i64] } %t97, 0
  %t100 = icmp eq i64 %t99, 8
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t102 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t103 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t102, i32 0, i32 0
  %t104 = load { i64, [1 x i64] }, ptr %t103
  store { i64, [1 x i64] } %t104, ptr %l7
  %t106 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t107 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t106, i32 0, i32 2
  %t108 = load { i64, [4 x i64] }, ptr %t107
  store { i64, [4 x i64] } %t108, ptr %l8
  %t110 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t111 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t110, i32 0, i32 3
  %t112 = load { i64, [4 x i64] }, ptr %t111
  store { i64, [4 x i64] } %t112, ptr %l9
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load { i64, [1 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t114, { i64, [1 x i64] } %t115)
  br label %bb33
bb33:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, [4 x i64] }, ptr %l8
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t118, { i64, [4 x i64] } %t119)
  br label %bb34
bb34:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, [4 x i64] }, ptr %l9
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t122, { i64, [4 x i64] } %t123)
  br label %bb35
bb35:
  br label %bb79
bb36:
  %t126 = load { i64, [15 x i64] }, ptr %l1
  %t128 = extractvalue { i64, [15 x i64] } %t126, 0
  %t129 = icmp eq i64 %t128, 9
  br i1 %t129, label %bb37, label %bb38
bb37:
  %t131 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t132 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t131, i32 0, i32 0
  %t133 = load %"compiler/mir:Lvalue", ptr %t132
  store %"compiler/mir:Lvalue" %t133, ptr %l10
  %t135 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t136 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t135, i32 0, i32 1
  %t137 = load { i64, [4 x i64] }, ptr %t136
  store { i64, [4 x i64] } %t137, ptr %l11
  %t139 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t140 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t139, i32 0, i32 2
  %t141 = load { i64, [4 x i64] }, ptr %t140
  store { i64, [4 x i64] } %t141, ptr %l12
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load %"compiler/mir:Lvalue", ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t143, %"compiler/mir:Lvalue" %t144)
  br label %bb40
bb40:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load { i64, [4 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t147, { i64, [4 x i64] } %t148)
  br label %bb41
bb41:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load { i64, [4 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t151, { i64, [4 x i64] } %t152)
  br label %bb42
bb42:
  br label %bb79
bb43:
  %t155 = load { i64, [15 x i64] }, ptr %l1
  %t157 = extractvalue { i64, [15 x i64] } %t155, 0
  %t158 = icmp eq i64 %t157, 10
  br i1 %t158, label %bb44, label %bb45
bb44:
  %t160 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t161 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t160, i32 0, i32 2
  %t162 = load { i64, [1 x i64] }, ptr %t161
  store { i64, [1 x i64] } %t162, ptr %l13
  %t164 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t165 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t164, i32 0, i32 3
  %t166 = load %"compiler/mir:Range", ptr %t165
  store %"compiler/mir:Range" %t166, ptr %l14
  %t168 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t169 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t168, i32 0, i32 4
  %t170 = load %"compiler/mir:Range", ptr %t169
  store %"compiler/mir:Range" %t170, ptr %l15
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load { i64, [1 x i64] }, ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t172, { i64, [1 x i64] } %t173)
  br label %bb47
bb47:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load %"compiler/mir:Range", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t176, %"compiler/mir:Range" %t177)
  br label %bb48
bb48:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load %"compiler/mir:Range", ptr %l15
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %t180, %"compiler/mir:Range" %t181)
  br label %bb49
bb49:
  br label %bb79
bb50:
  %t184 = load { i64, [15 x i64] }, ptr %l1
  %t186 = extractvalue { i64, [15 x i64] } %t184, 0
  %t187 = icmp eq i64 %t186, 11
  br i1 %t187, label %bb51, label %bb52
bb51:
  %t189 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t190 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t189, i32 0, i32 0
  %t191 = load { i64, [4 x i64] }, ptr %t190
  store { i64, [4 x i64] } %t191, ptr %l16
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, [4 x i64] }, ptr %l16
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t193, { i64, [4 x i64] } %t194)
  br label %bb54
bb54:
  br label %bb79
bb55:
  %t197 = load { i64, [15 x i64] }, ptr %l1
  %t199 = extractvalue { i64, [15 x i64] } %t197, 0
  %t200 = icmp eq i64 %t199, 12
  br i1 %t200, label %bb56, label %bb57
bb56:
  %t202 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t203 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t202, i32 0, i32 0
  %t204 = load { i64, [1 x i64] }, ptr %t203
  store { i64, [1 x i64] } %t204, ptr %l17
  %t206 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t207 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t206, i32 0, i32 1
  %t208 = load { i64, [1 x i64] }, ptr %t207
  store { i64, [1 x i64] } %t208, ptr %l18
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load { i64, [1 x i64] }, ptr %l17
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t210, { i64, [1 x i64] } %t211)
  br label %bb59
bb59:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load { i64, [1 x i64] }, ptr %l18
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t214, { i64, [1 x i64] } %t215)
  br label %bb60
bb60:
  br label %bb79
bb61:
  %t218 = load { i64, [15 x i64] }, ptr %l1
  %t220 = extractvalue { i64, [15 x i64] } %t218, 0
  %t221 = icmp eq i64 %t220, 13
  br i1 %t221, label %bb62, label %bb63
bb62:
  %t223 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t224 = getelementptr { { i64, [1 x i64] } }, ptr %t223, i32 0, i32 0
  %t225 = load { i64, [1 x i64] }, ptr %t224
  store { i64, [1 x i64] } %t225, ptr %l19
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, [1 x i64] }, ptr %l19
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t227, { i64, [1 x i64] } %t228)
  br label %bb65
bb65:
  br label %bb79
bb66:
  %t231 = load { i64, [15 x i64] }, ptr %l1
  %t233 = extractvalue { i64, [15 x i64] } %t231, 0
  %t234 = icmp eq i64 %t233, 14
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t237 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t236, i32 0, i32 0
  %t238 = load { i64, [4 x i64] }, ptr %t237
  store { i64, [4 x i64] } %t238, ptr %l20
  %t240 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t241 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t240, i32 0, i32 1
  %t242 = load { i64, [1 x i64] }, ptr %t241
  store { i64, [1 x i64] } %t242, ptr %l21
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load { i64, [4 x i64] }, ptr %l20
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t244, { i64, [4 x i64] } %t245)
  br label %bb70
bb70:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load { i64, [1 x i64] }, ptr %l21
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t248, { i64, [1 x i64] } %t249)
  br label %bb71
bb71:
  br label %bb79
bb72:
  %t252 = load { i64, [15 x i64] }, ptr %l1
  %t254 = extractvalue { i64, [15 x i64] } %t252, 0
  %t255 = icmp eq i64 %t254, 15
  br i1 %t255, label %bb73, label %bb74
bb73:
  br label %bb77
bb74:
  %t257 = load { i64, [15 x i64] }, ptr %l1
  %t259 = extractvalue { i64, [15 x i64] } %t257, 0
  %t260 = icmp eq i64 %t259, 16
  br i1 %t260, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_d06e38c3720099d6_401a7f863dec038a)
  unreachable
bb79:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i64
  %l10 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 8
  %t14 = load ptr, ptr @__olang_prog_scope
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t14, ptr %t13)
  store i64 %t16, ptr %l10
  br label %bb3
bb3:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = icmp sge i64 %t17, %t18
  store i1 %t19, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l4, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t27 = sext i32 %t23 to i64
  %t28 = call i64 @__olang_fmt_i64(ptr null, i64 %t27)
  %t29 = add i64 %t25, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t24, i64 %t25)
  %t31 = getelementptr i8, ptr %t30, i64 %t25
  %t32 = call i64 @__olang_fmt_i64(ptr %t31, i64 %t27)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t30, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t22, { i64, ptr } %t41)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb8:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esliceType(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i32
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca i32
  %l80 = alloca i1
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load i32, ptr %l16, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l5, !tbaa !29
  store ptr %t12, ptr %l17, !tbaa !29
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t14 = load i32, ptr %l4, !tbaa !23
  %t15 = load ptr, ptr @__olang_prog_scope
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t15, ptr %t13, i32 %t14)
  store i32 %t18, ptr %l20
  br label %bb2
bb2:
  %t19 = load ptr, ptr @__olang_prog_scope
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t21 = load i32, ptr %l20, !tbaa !23
  %t22 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t19, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l21
  br label %bb3
bb3:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l23, !tbaa !29
  %t25 = load ptr, ptr %l5, !tbaa !29
  store ptr %t25, ptr %l24, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t27 = load i32, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr @__olang_prog_scope
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t28, ptr %t26, i32 %t27)
  store i32 %t31, ptr %l27
  br label %bb6
bb5:
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t32, ptr %l22, !tbaa !23
  br label %bb9
bb6:
  %t34 = load ptr, ptr @__olang_prog_scope
  %t35 = load ptr, ptr %l24, !tbaa !29
  %t36 = load i32, ptr %l27, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t34, ptr %t35, i32 %t36)
  store i32 %t37, ptr %l28
  br label %bb7
bb7:
  %t38 = load ptr, ptr %l23, !tbaa !29
  %t39 = load i32, ptr %l28, !tbaa !23
  %t40 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t40, ptr %l29
  br label %bb8
bb8:
  %t41 = load i32, ptr %l29, !tbaa !23
  store i32 %t41, ptr %l22, !tbaa !23
  br label %bb9
bb9:
  %t42 = load i32, ptr %l22, !tbaa !23
  store i32 %t42, ptr %l7, !tbaa !23
  %t43 = load i32, ptr %l6, !tbaa !23
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t47 = icmp eq i32 %t43, %t44
  br i1 %t47, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb12
bb11:
  %t49 = load i32, ptr %l7, !tbaa !23
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t53 = icmp eq i32 %t49, %t50
  store i1 %t53, ptr %l34, !tbaa !21
  br label %bb12
bb12:
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb20
bb14:
  %t56 = load ptr, ptr %l5, !tbaa !29
  store ptr %t56, ptr %l39, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  %t58 = load ptr, ptr %l5, !tbaa !29
  %t59 = load i32, ptr %l6, !tbaa !23
  %t60 = load ptr, ptr @__olang_prog_scope
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t60, ptr %t58, i32 %t59)
  store i32 %t63, ptr %l43
  br label %bb15
bb15:
  %t64 = load ptr, ptr @__olang_prog_scope
  %t65 = load ptr, ptr %l40, !tbaa !29
  %t66 = load i32, ptr %l43, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t64, ptr %t65, i32 %t66)
  store i32 %t67, ptr %l44
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l5, !tbaa !29
  store ptr %t68, ptr %l45, !tbaa !29
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t70 = load i32, ptr %l7, !tbaa !23
  %t71 = load ptr, ptr @__olang_prog_scope
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t71, ptr %t69, i32 %t70)
  store i32 %t74, ptr %l48
  br label %bb17
bb17:
  %t75 = load ptr, ptr @__olang_prog_scope
  %t76 = load ptr, ptr %l45, !tbaa !29
  %t77 = load i32, ptr %l48, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t75, ptr %t76, i32 %t77)
  store i32 %t78, ptr %l49
  br label %bb18
bb18:
  %t79 = load ptr, ptr @__olang_prog_scope
  %t80 = load ptr, ptr %l39, !tbaa !29
  %t81 = load i32, ptr %l44, !tbaa !23
  %t82 = load i32, ptr %l49, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t79, ptr %t80, i32 %t81, i32 %t82)
  store i1 %t83, ptr %l50
  br label %bb19
bb19:
  %t84 = load i1, ptr %l50, !tbaa !21
  %t85 = xor i1 %t84, true
  store i1 %t85, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t87 = load i1, ptr %l38, !tbaa !21
  br i1 %t87, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s1
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l52, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l4, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t89, i32 %t90)
  store { i64, ptr } %t93, ptr %l55
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l1, !tbaa !23
  %t98 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t94, i32 %t95)
  store { i64, ptr } %t98, ptr %l58
  br label %bb24
bb24:
  %t99 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t101 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = add i64 %t100, %t103
  %t105 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t107 = add i64 %t104, %t106
  %t108 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = add i64 %t107, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t99, i64 %t100)
  %t113 = getelementptr i8, ptr %t112, i64 %t100
  call void @olang_textcopy(ptr %t113, ptr %t102, i64 %t103)
  %t114 = getelementptr i8, ptr %t113, i64 %t103
  call void @olang_textcopy(ptr %t114, ptr %t105, i64 %t106)
  %t115 = getelementptr i8, ptr %t114, i64 %t106
  call void @olang_textcopy(ptr %t115, ptr %t109, i64 %t110)
  %t116 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t112, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = extractvalue { i64, ptr } %t117, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t125 = load ptr, ptr %l52, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t125, { i64, ptr } %t124)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t130 = insertvalue [2 x { i64, [4 x i64] }] undef, { i64, [4 x i64] } %a2, 0
  %t132 = insertvalue [2 x { i64, [4 x i64] }] %t130, { i64, [4 x i64] } %a3, 1
  %t134 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 80, i64 8)
  store [2 x { i64, [4 x i64] }] %t132, ptr %t134
  store ptr %t134, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t136 = load ptr, ptr %l8
  store i64 2, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t139 = load i64, ptr %l9, !tbaa !24
  %t140 = load i64, ptr %l10, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb28, label %bb29
bb28:
  br label %bb39
bb29:
  br label %bb30
bb30:
  %t147 = load ptr, ptr %l8
  %t148 = load i64, ptr %l9, !tbaa !24
  %t151 = getelementptr [2 x { i64, [4 x i64] }], ptr %t147, i64 0, i64 %t148
  %t152 = load { i64, [4 x i64] }, ptr %t151
  %t154 = load ptr, ptr %l5, !tbaa !29
  store ptr %t154, ptr %l74, !tbaa !29
  %t155 = load ptr, ptr %l5, !tbaa !29
  store ptr %t155, ptr %l75, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t160 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t156, { i64, [4 x i64] } %t152)
  store i32 %t160, ptr %l78
  br label %bb31
bb31:
  %t161 = load ptr, ptr @__olang_prog_scope
  %t162 = load ptr, ptr %l75, !tbaa !29
  %t163 = load i32, ptr %l78, !tbaa !23
  %t164 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t161, ptr %t162, i32 %t163)
  store i32 %t164, ptr %l79
  br label %bb32
bb32:
  %t165 = load ptr, ptr @__olang_prog_scope
  %t166 = load ptr, ptr %l74, !tbaa !29
  %t167 = load i32, ptr %l79, !tbaa !23
  %t168 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t165, ptr %t166, i32 %t167)
  store i1 %t168, ptr %l80
  br label %bb33
bb33:
  %t169 = load i1, ptr %l80, !tbaa !21
  %t170 = xor i1 %t169, true
  br i1 %t170, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t172 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t172, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d232, i32 0, i32 1) })
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t174 = load i64, ptr %l9, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l9, !tbaa !24
  br label %bb27
bb39:
  call void @__olang_scope_close(ptr %s3)
  %t178 = load i32, ptr %l4, !tbaa !23
  store i32 %t178, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtFlow(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca %"compiler/mir:Lvalue"
  %l15 = alloca i32
  %l16 = alloca %"compiler/mir:Lvalue"
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca %"compiler/mir:Lvalue"
  %l20 = alloca %"compiler/mir:Lvalue"
  %l21 = alloca { i64, [4 x i64] }
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca %"compiler/mir:Task"
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %l43 = alloca { i64, [1 x i64] }
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca i32
  %l50 = alloca { i64, [4 x i64] }
  %l51 = alloca i32
  %l52 = alloca i32
  %l55 = alloca ptr
  %l56 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l77 = alloca %"compiler/mir:Local"
  %l85 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca i1
  %l99 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l110 = alloca %"compiler/mir:Local"
  %l113 = alloca ptr
  %l114 = alloca i1
  %l121 = alloca i1
  %l128 = alloca i64
  %l130 = alloca i32
  %l132 = alloca ptr
  %l135 = alloca i64
  %l137 = alloca i32
  %l143 = alloca %"compiler/mir:ScopeInfo"
  %l148 = alloca ptr
  %l149 = alloca i32
  %l152 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l166 = alloca i1
  %l174 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l183 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i1
  %l214 = alloca ptr
  %l215 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i1
  %l252 = alloca i1
  %l262 = alloca %"compiler/mir:Task"
  %l267 = alloca i32
  %l270 = alloca i32
  %l288 = alloca ptr
  %l296 = alloca %"compiler/mir:Lvalue"
  %l307 = alloca i32
  %l310 = alloca i32
  %l328 = alloca ptr
  %l336 = alloca { i64, [1 x i64] }
  %l343 = alloca i32
  %l346 = alloca i32
  %l371 = alloca { i64, [1 x i64] }
  %l383 = alloca i32
  %l386 = alloca i32
  %l404 = alloca ptr
  %l412 = alloca %"compiler/mir:TaskClause"
  %l417 = alloca { i64, ptr }
  %l420 = alloca ptr
  %l421 = alloca i1
  %l424 = alloca ptr
  %l425 = alloca i1
  %l428 = alloca ptr
  %l429 = alloca i1
  %l436 = alloca ptr
  %l437 = alloca i1
  %l446 = alloca i1
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s37 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t7 = load ptr, ptr %l55, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l55, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 15}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l56, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l56, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t17, i32 0, i32 1
  %t19 = load %"compiler/mir:Lvalue", ptr %t18
  store %"compiler/mir:Lvalue" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t23, i32 0, i32 2
  %t25 = load { i64, [15 x i64] }, ptr %t24
  store { i64, [15 x i64] } %t25, ptr %l4
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, [15 x i64] }, ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueFlow(ptr %v0, ptr %t27, { i64, [15 x i64] } %t28)
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/mir:Lvalue", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estores(ptr %v0, ptr %t31, %"compiler/mir:Lvalue" %t32)
  br label %bb7
bb7:
  br label %bb208
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t36 = load ptr, ptr %l67, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l67, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 15}
  %t42 = icmp eq i64 %t40, 1
  store i1 %t42, ptr %l68, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l68, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [21 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32 }, ptr %t46, i32 0, i32 1
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/mir:Fn", ptr %t50, i32 0, i32 7
  %t53 = load i32, ptr %l5, !tbaa !23
  %t55 = sext i32 %t53 to i64
  %t56 = load ptr, ptr @__olang_prog_scope
  %t59 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t56, ptr %t52, i64 %t55)
  store %"compiler/mir:Local" %t59, ptr %l77
  br label %bb14
bb14:
  %t60 = getelementptr %"compiler/mir:Local", ptr %l77, i32 0, i32 4
  %t61 = load { i64, [1 x i64] }, ptr %t60
  store { i64, [1 x i64] } %t61, ptr %l6
  %t63 = load { i64, [1 x i64] }, ptr %l6
  %t65 = extractvalue { i64, [1 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 3
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, [1 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t70, { i64, [1 x i64] } %t71)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/mir:verifier", ptr %t74, i32 0, i32 15
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l85, !tbaa !27
  %t78 = load i32, ptr %l5, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t82 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i1, ptr %t83, i64 %t80
  store i1 true, ptr %t84, !tbaa !31
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/mir:verifier", ptr %t85, i32 0, i32 14
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l89, !tbaa !27
  %t89 = load i32, ptr %l5, !tbaa !23
  %t91 = sext i32 %t89 to i64
  %t93 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i1, ptr %t94, i64 %t91
  store i1 false, ptr %t95, !tbaa !31
  br label %bb208
bb19:
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t97 = load ptr, ptr %l92, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb20, label %bb21
bb20:
  %t100 = load ptr, ptr %l92, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 15}
  %t103 = icmp eq i64 %t101, 2
  store i1 %t103, ptr %l93, !tbaa !21
  br label %bb21
bb21:
  %t104 = load i1, ptr %l93, !tbaa !21
  br i1 %t104, label %bb22, label %bb23
bb22:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [21 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32 }, ptr %t107, i32 0, i32 1
  %t109 = load i32, ptr %t108
  store i32 %t109, ptr %l7, !tbaa !23
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/mir:verifier", ptr %t111, i32 0, i32 14
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l99, !tbaa !27
  %t115 = load i32, ptr %l7, !tbaa !23
  %t117 = sext i32 %t115 to i64
  %t119 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i1, ptr %t120, i64 %t117
  store i1 false, ptr %t121, !tbaa !31
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/mir:verifier", ptr %t122, i32 0, i32 15
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l103, !tbaa !27
  %t126 = load i32, ptr %l7, !tbaa !23
  %t128 = sext i32 %t126 to i64
  store i64 %t128, ptr %l105, !tbaa !24
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t131 = getelementptr %"compiler/mir:Fn", ptr %t129, i32 0, i32 7
  %t132 = load i32, ptr %l7, !tbaa !23
  %t134 = sext i32 %t132 to i64
  %t135 = load ptr, ptr @__olang_prog_scope
  %t138 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t135, ptr %t131, i64 %t134)
  store %"compiler/mir:Local" %t138, ptr %l110
  br label %bb25
bb25:
  %t139 = getelementptr %"compiler/mir:Local", ptr %l110, i32 0, i32 4
  %t140 = load { i64, [1 x i64] }, ptr %t139
  %t142 = extractvalue { i64, [1 x i64] } %t140, 0
  %t143 = icmp eq i64 %t142, 3
  %t145 = load i64, ptr %l105, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i1, ptr %t147, i64 %t145
  store i1 %t143, ptr %t148, !tbaa !31
  br label %bb208
bb26:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t150 = load ptr, ptr %l113, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb27, label %bb28
bb27:
  %t153 = load ptr, ptr %l113, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 15}
  %t156 = icmp eq i64 %t154, 3
  store i1 %t156, ptr %l114, !tbaa !21
  br label %bb28
bb28:
  %t157 = load i1, ptr %l114, !tbaa !21
  br i1 %t157, label %bb29, label %bb30
bb29:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [21 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32 }, ptr %t160, i32 0, i32 1
  %t162 = load i32, ptr %t161
  store i32 %t162, ptr %l8, !tbaa !23
  br label %bb31
bb30:
  br label %bb51
bb31:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l8, !tbaa !23
  %t168 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t164, i32 %t165)
  store i1 %t168, ptr %l121
  br label %bb32
bb32:
  %t169 = load i1, ptr %l121, !tbaa !21
  br i1 %t169, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l8, !tbaa !23
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t175 = sext i32 %t171 to i64
  %t176 = call i64 @__olang_fmt_i64(ptr null, i64 %t175)
  %t177 = add i64 %t173, %t176
  %t178 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t180 = add i64 %t177, %t179
  %t181 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t172, i64 %t173)
  %t182 = getelementptr i8, ptr %t181, i64 %t173
  %t183 = call i64 @__olang_fmt_i64(ptr %t182, i64 %t175)
  %t184 = getelementptr i8, ptr %t182, i64 %t176
  call void @olang_textcopy(ptr %t184, ptr %t178, i64 %t179)
  %t185 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t181, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = extractvalue { i64, ptr } %t186, 1
  %t190 = mul i64 %t188, 1
  %t191 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t190)
  call void @llvm.memcpy.p0.p0.i64(ptr %t191, ptr %t189, i64 %t190, i1 false)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s6, ptr %t170, { i64, ptr } %t193)
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb36:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/mir:verifier", ptr %t196, i32 0, i32 17
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t198)
  store i64 %t200, ptr %l128
  br label %bb37
bb37:
  %t201 = load i64, ptr %l128, !tbaa !24
  %t202 = icmp sgt i64 %t201, 0
  br i1 %t202, label %bb38, label %bb39
bb38:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/mir:verifier", ptr %t204, i32 0, i32 17
  store ptr %t206, ptr %l132, !tbaa !29
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/mir:verifier", ptr %t207, i32 0, i32 17
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t209)
  store i64 %t211, ptr %l135
  br label %bb40
bb39:
  %t212 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  store i32 %t212, ptr %l130, !tbaa !23
  br label %bb42
bb40:
  %t214 = load i64, ptr %l135, !tbaa !24
  %t215 = sub i64 %t214, 1
  %t216 = load ptr, ptr %l132, !tbaa !29
  %t218 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t216, i64 %t215)
  store i32 %t218, ptr %l137
  br label %bb41
bb41:
  %t219 = load i32, ptr %l137, !tbaa !23
  store i32 %t219, ptr %l130, !tbaa !23
  br label %bb42
bb42:
  %t220 = load i32, ptr %l130, !tbaa !23
  store i32 %t220, ptr %l9, !tbaa !23
  %t221 = load ptr, ptr %l2, !tbaa !29
  %t223 = getelementptr %"compiler/mir:Fn", ptr %t221, i32 0, i32 8
  %t224 = load i32, ptr %l8, !tbaa !23
  %t226 = sext i32 %t224 to i64
  %t227 = load ptr, ptr @__olang_prog_scope
  %t230 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t227, ptr %t223, i64 %t226)
  store %"compiler/mir:ScopeInfo" %t230, ptr %l143
  br label %bb43
bb43:
  %t231 = getelementptr %"compiler/mir:ScopeInfo", ptr %l143, i32 0, i32 1
  %t232 = load i32, ptr %t231, !tbaa !23
  store i32 %t232, ptr %l10, !tbaa !23
  %t234 = load i32, ptr %l10, !tbaa !23
  %t235 = load i32, ptr %l9, !tbaa !23
  %t238 = icmp ne i32 %t234, %t235
  br i1 %t238, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l148, !tbaa !29
  %t241 = load i32, ptr %l8, !tbaa !23
  store i32 %t241, ptr %l149, !tbaa !23
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i32, ptr %l9, !tbaa !23
  %t246 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %s8, ptr %t242, i32 %t243)
  store { i64, ptr } %t246, ptr %l152
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i32, ptr %l10, !tbaa !23
  %t251 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %s8, ptr %t247, i32 %t248)
  store { i64, ptr } %t251, ptr %l155
  br label %bb47
bb47:
  %t252 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t253 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t254 = load i32, ptr %l149, !tbaa !23
  %t255 = sext i32 %t254 to i64
  %t256 = call i64 @__olang_fmt_i64(ptr null, i64 %t255)
  %t257 = add i64 %t253, %t256
  %t258 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t259 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t260 = add i64 %t257, %t259
  %t261 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = add i64 %t260, %t263
  %t265 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t267 = add i64 %t264, %t266
  %t268 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = add i64 %t267, %t270
  %t272 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t271)
  call void @olang_textcopy(ptr %t272, ptr %t252, i64 %t253)
  %t273 = getelementptr i8, ptr %t272, i64 %t253
  %t274 = call i64 @__olang_fmt_i64(ptr %t273, i64 %t255)
  %t275 = getelementptr i8, ptr %t273, i64 %t256
  call void @olang_textcopy(ptr %t275, ptr %t258, i64 %t259)
  %t276 = getelementptr i8, ptr %t275, i64 %t259
  call void @olang_textcopy(ptr %t276, ptr %t262, i64 %t263)
  %t277 = getelementptr i8, ptr %t276, i64 %t263
  call void @olang_textcopy(ptr %t277, ptr %t265, i64 %t266)
  %t278 = getelementptr i8, ptr %t277, i64 %t266
  call void @olang_textcopy(ptr %t278, ptr %t269, i64 %t270)
  %t279 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t272, 1
  %t282 = extractvalue { i64, ptr } %t280, 0
  %t283 = extractvalue { i64, ptr } %t280, 1
  %t284 = mul i64 %t282, 1
  %t285 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t284)
  call void @llvm.memcpy.p0.p0.i64(ptr %t285, ptr %t283, i64 %t284, i1 false)
  %t286 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  %t288 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t288, { i64, ptr } %t287)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb49:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/mir:verifier", ptr %t290, i32 0, i32 17
  %t293 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t292, i32 %t293)
  br label %bb50
bb50:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/mir:verifier", ptr %t296, i32 0, i32 16
  %t299 = load { i64, ptr }, ptr %t298, !tbaa !27
  store { i64, ptr } %t299, ptr %l162, !tbaa !27
  %t300 = load i32, ptr %l8, !tbaa !23
  %t302 = sext i32 %t300 to i64
  %t304 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i1, ptr %t305, i64 %t302
  store i1 false, ptr %t306, !tbaa !31
  br label %bb208
bb51:
  %t307 = load ptr, ptr %l1, !tbaa !29
  store ptr %t307, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t308 = load ptr, ptr %l165, !tbaa !29
  %t309 = icmp ne ptr %t308, null
  br i1 %t309, label %bb52, label %bb53
bb52:
  %t311 = load ptr, ptr %l165, !tbaa !29
  %t312 = load i64, ptr %t311, !range !{i64 0, i64 15}
  %t314 = icmp eq i64 %t312, 4
  store i1 %t314, ptr %l166, !tbaa !21
  br label %bb53
bb53:
  %t315 = load i1, ptr %l166, !tbaa !21
  br i1 %t315, label %bb54, label %bb55
bb54:
  %t316 = load ptr, ptr %l1, !tbaa !29
  %t318 = getelementptr { i64, [21 x i64] }, ptr %t316, i32 0, i32 1
  %t319 = getelementptr { %"compiler/source:Span", i32 }, ptr %t318, i32 0, i32 1
  %t320 = load i32, ptr %t319
  store i32 %t320, ptr %l11, !tbaa !23
  br label %bb56
bb55:
  br label %bb62
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %s10, ptr %t322, i32 %t323, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d238, i32 0, i32 1) })
  br label %bb57
bb57:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/mir:verifier", ptr %t326, i32 0, i32 16
  %t329 = load { i64, ptr }, ptr %t328, !tbaa !27
  store { i64, ptr } %t329, ptr %l174, !tbaa !27
  %t330 = load i32, ptr %l11, !tbaa !23
  %t332 = sext i32 %t330 to i64
  %t334 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i1, ptr %t335, i64 %t332
  %t337 = load i1, ptr %t336, !tbaa !31
  br i1 %t337, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i32, ptr %l11, !tbaa !23
  %t341 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t344 = sext i32 %t340 to i64
  %t345 = call i64 @__olang_fmt_i64(ptr null, i64 %t344)
  %t346 = add i64 %t342, %t345
  %t347 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t349 = add i64 %t346, %t348
  %t350 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t349)
  call void @olang_textcopy(ptr %t350, ptr %t341, i64 %t342)
  %t351 = getelementptr i8, ptr %t350, i64 %t342
  %t352 = call i64 @__olang_fmt_i64(ptr %t351, i64 %t344)
  %t353 = getelementptr i8, ptr %t351, i64 %t345
  call void @olang_textcopy(ptr %t353, ptr %t347, i64 %t348)
  %t354 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t350, 1
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t358 = extractvalue { i64, ptr } %t355, 1
  %t359 = mul i64 %t357, 1
  %t360 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t359)
  call void @llvm.memcpy.p0.p0.i64(ptr %t360, ptr %t358, i64 %t359, i1 false)
  %t361 = insertvalue { i64, ptr } undef, i64 %t357, 0
  %t362 = insertvalue { i64, ptr } %t361, ptr %t360, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t339, { i64, ptr } %t362)
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s11)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  br label %bb208
bb62:
  %t365 = load ptr, ptr %l1, !tbaa !29
  store ptr %t365, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t366 = load ptr, ptr %l182, !tbaa !29
  %t367 = icmp ne ptr %t366, null
  br i1 %t367, label %bb63, label %bb64
bb63:
  %t369 = load ptr, ptr %l182, !tbaa !29
  %t370 = load i64, ptr %t369, !range !{i64 0, i64 15}
  %t372 = icmp eq i64 %t370, 5
  store i1 %t372, ptr %l183, !tbaa !21
  br label %bb64
bb64:
  %t373 = load i1, ptr %l183, !tbaa !21
  br i1 %t373, label %bb65, label %bb66
bb65:
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t376 = getelementptr { i64, [21 x i64] }, ptr %t374, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t376, i32 0, i32 1
  %t378 = load { i64, [1 x i64] }, ptr %t377
  store { i64, [1 x i64] } %t378, ptr %l12
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [21 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t382, i32 0, i32 3
  %t384 = load { i64, [4 x i64] }, ptr %t383
  store { i64, [4 x i64] } %t384, ptr %l13
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load { i64, [1 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t386, { i64, [1 x i64] } %t387)
  br label %bb68
bb68:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load { i64, [4 x i64] }, ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t390, { i64, [4 x i64] } %t391)
  br label %bb69
bb69:
  br label %bb208
bb70:
  %t394 = load ptr, ptr %l1, !tbaa !29
  store ptr %t394, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t395 = load ptr, ptr %l194, !tbaa !29
  %t396 = icmp ne ptr %t395, null
  br i1 %t396, label %bb71, label %bb72
bb71:
  %t398 = load ptr, ptr %l194, !tbaa !29
  %t399 = load i64, ptr %t398, !range !{i64 0, i64 15}
  %t401 = icmp eq i64 %t399, 6
  store i1 %t401, ptr %l195, !tbaa !21
  br label %bb72
bb72:
  %t402 = load i1, ptr %l195, !tbaa !21
  br i1 %t402, label %bb73, label %bb74
bb73:
  %t403 = load ptr, ptr %l1, !tbaa !29
  %t405 = getelementptr { i64, [21 x i64] }, ptr %t403, i32 0, i32 1
  %t406 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t405, i32 0, i32 1
  %t407 = load %"compiler/mir:Lvalue", ptr %t406
  store %"compiler/mir:Lvalue" %t407, ptr %l14
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load %"compiler/mir:Lvalue", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t409, %"compiler/mir:Lvalue" %t410)
  br label %bb76
bb76:
  br label %bb208
bb77:
  %t413 = load ptr, ptr %l1, !tbaa !29
  store ptr %t413, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t414 = load ptr, ptr %l202, !tbaa !29
  %t415 = icmp ne ptr %t414, null
  br i1 %t415, label %bb78, label %bb79
bb78:
  %t417 = load ptr, ptr %l202, !tbaa !29
  %t418 = load i64, ptr %t417, !range !{i64 0, i64 15}
  %t420 = icmp eq i64 %t418, 7
  store i1 %t420, ptr %l203, !tbaa !21
  br label %bb79
bb79:
  %t421 = load i1, ptr %l203, !tbaa !21
  br i1 %t421, label %bb80, label %bb81
bb80:
  %t422 = load ptr, ptr %l1, !tbaa !29
  %t424 = getelementptr { i64, [21 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t424, i32 0, i32 1
  %t426 = load i32, ptr %t425
  store i32 %t426, ptr %l15, !tbaa !23
  %t428 = load ptr, ptr %l1, !tbaa !29
  %t430 = getelementptr { i64, [21 x i64] }, ptr %t428, i32 0, i32 1
  %t431 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t430, i32 0, i32 2
  %t432 = load %"compiler/mir:Lvalue", ptr %t431
  store %"compiler/mir:Lvalue" %t432, ptr %l16
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t434, i32 %t435)
  br label %bb83
bb83:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load %"compiler/mir:Lvalue", ptr %l16
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t438, %"compiler/mir:Lvalue" %t439)
  br label %bb84
bb84:
  br label %bb208
bb85:
  %t442 = load ptr, ptr %l1, !tbaa !29
  store ptr %t442, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t443 = load ptr, ptr %l214, !tbaa !29
  %t444 = icmp ne ptr %t443, null
  br i1 %t444, label %bb86, label %bb87
bb86:
  %t446 = load ptr, ptr %l214, !tbaa !29
  %t447 = load i64, ptr %t446, !range !{i64 0, i64 15}
  %t449 = icmp eq i64 %t447, 8
  store i1 %t449, ptr %l215, !tbaa !21
  br label %bb87
bb87:
  %t450 = load i1, ptr %l215, !tbaa !21
  br i1 %t450, label %bb88, label %bb89
bb88:
  %t451 = load ptr, ptr %l1, !tbaa !29
  %t453 = getelementptr { i64, [21 x i64] }, ptr %t451, i32 0, i32 1
  %t454 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t453, i32 0, i32 1
  %t455 = load { i64, [1 x i64] }, ptr %t454
  store { i64, [1 x i64] } %t455, ptr %l17
  %t457 = load ptr, ptr %l1, !tbaa !29
  %t459 = getelementptr { i64, [21 x i64] }, ptr %t457, i32 0, i32 1
  %t460 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t459, i32 0, i32 3
  %t461 = load { i64, [4 x i64] }, ptr %t460
  store { i64, [4 x i64] } %t461, ptr %l18
  br label %bb90
bb89:
  br label %bb93
bb90:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load { i64, [1 x i64] }, ptr %l17
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t463, { i64, [1 x i64] } %t464)
  br label %bb91
bb91:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load { i64, [4 x i64] }, ptr %l18
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t467, { i64, [4 x i64] } %t468)
  br label %bb92
bb92:
  br label %bb208
bb93:
  %t471 = load ptr, ptr %l1, !tbaa !29
  store ptr %t471, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t472 = load ptr, ptr %l226, !tbaa !29
  %t473 = icmp ne ptr %t472, null
  br i1 %t473, label %bb94, label %bb95
bb94:
  %t475 = load ptr, ptr %l226, !tbaa !29
  %t476 = load i64, ptr %t475, !range !{i64 0, i64 15}
  %t478 = icmp eq i64 %t476, 9
  store i1 %t478, ptr %l227, !tbaa !21
  br label %bb95
bb95:
  %t479 = load i1, ptr %l227, !tbaa !21
  br i1 %t479, label %bb96, label %bb97
bb96:
  %t480 = load ptr, ptr %l1, !tbaa !29
  %t482 = getelementptr { i64, [21 x i64] }, ptr %t480, i32 0, i32 1
  %t483 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t482, i32 0, i32 1
  %t484 = load %"compiler/mir:Lvalue", ptr %t483
  store %"compiler/mir:Lvalue" %t484, ptr %l19
  %t486 = load ptr, ptr %l1, !tbaa !29
  %t488 = getelementptr { i64, [21 x i64] }, ptr %t486, i32 0, i32 1
  %t489 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t488, i32 0, i32 2
  %t490 = load %"compiler/mir:Lvalue", ptr %t489
  store %"compiler/mir:Lvalue" %t490, ptr %l20
  %t492 = load ptr, ptr %l1, !tbaa !29
  %t494 = getelementptr { i64, [21 x i64] }, ptr %t492, i32 0, i32 1
  %t495 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t494, i32 0, i32 3
  %t496 = load { i64, [4 x i64] }, ptr %t495
  store { i64, [4 x i64] } %t496, ptr %l21
  br label %bb98
bb97:
  br label %bb102
bb98:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t499 = load %"compiler/mir:Lvalue", ptr %l20
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t498, %"compiler/mir:Lvalue" %t499)
  br label %bb99
bb99:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load { i64, [4 x i64] }, ptr %l21
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t502, { i64, [4 x i64] } %t503)
  br label %bb100
bb100:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load %"compiler/mir:Lvalue", ptr %l19
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t506, %"compiler/mir:Lvalue" %t507)
  br label %bb101
bb101:
  br label %bb208
bb102:
  %t510 = load ptr, ptr %l1, !tbaa !29
  store ptr %t510, ptr %l242, !tbaa !29
  store i1 false, ptr %l243, !tbaa !21
  %t511 = load ptr, ptr %l242, !tbaa !29
  %t512 = icmp ne ptr %t511, null
  br i1 %t512, label %bb103, label %bb104
bb103:
  %t514 = load ptr, ptr %l242, !tbaa !29
  %t515 = load i64, ptr %t514, !range !{i64 0, i64 15}
  %t517 = icmp eq i64 %t515, 10
  store i1 %t517, ptr %l243, !tbaa !21
  br label %bb104
bb104:
  %t518 = load i1, ptr %l243, !tbaa !21
  br i1 %t518, label %bb105, label %bb106
bb105:
  %t519 = load ptr, ptr %l1, !tbaa !29
  %t521 = getelementptr { i64, [21 x i64] }, ptr %t519, i32 0, i32 1
  %t522 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t521, i32 0, i32 1
  %t523 = load i32, ptr %t522
  store i32 %t523, ptr %l22, !tbaa !23
  %t525 = load ptr, ptr %l1, !tbaa !29
  %t527 = getelementptr { i64, [21 x i64] }, ptr %t525, i32 0, i32 1
  %t528 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t527, i32 0, i32 2
  %t529 = load i32, ptr %t528
  store i32 %t529, ptr %l23, !tbaa !23
  br label %bb107
bb106:
  br label %bb175
bb107:
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t532 = load i32, ptr %l22, !tbaa !23
  %t535 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t531, i32 %t532)
  store i1 %t535, ptr %l252
  br label %bb108
bb108:
  %t536 = load i1, ptr %l252, !tbaa !21
  %t537 = xor i1 %t536, true
  br i1 %t537, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s19
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load i32, ptr %l22, !tbaa !23
  %t541 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t542 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t544 = sext i32 %t540 to i64
  %t545 = call i64 @__olang_fmt_i64(ptr null, i64 %t544)
  %t546 = add i64 %t542, %t545
  %t547 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t548 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t549 = add i64 %t546, %t548
  %t550 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t549)
  call void @olang_textcopy(ptr %t550, ptr %t541, i64 %t542)
  %t551 = getelementptr i8, ptr %t550, i64 %t542
  %t552 = call i64 @__olang_fmt_i64(ptr %t551, i64 %t544)
  %t553 = getelementptr i8, ptr %t551, i64 %t545
  call void @olang_textcopy(ptr %t553, ptr %t547, i64 %t548)
  %t554 = insertvalue { i64, ptr } undef, i64 %t549, 0
  %t555 = insertvalue { i64, ptr } %t554, ptr %t550, 1
  %t557 = extractvalue { i64, ptr } %t555, 0
  %t558 = extractvalue { i64, ptr } %t555, 1
  %t559 = mul i64 %t557, 1
  %t560 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t559)
  call void @llvm.memcpy.p0.p0.i64(ptr %t560, ptr %t558, i64 %t559, i1 false)
  %t561 = insertvalue { i64, ptr } undef, i64 %t557, 0
  %t562 = insertvalue { i64, ptr } %t561, ptr %t560, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s19, ptr %t539, { i64, ptr } %t562)
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_scope_close(ptr %s19)
  br label %bb112
bb112:
  %t565 = load ptr, ptr %l2, !tbaa !29
  %t567 = getelementptr %"compiler/mir:Fn", ptr %t565, i32 0, i32 16
  %t568 = load i32, ptr %l23, !tbaa !23
  %t570 = sext i32 %t568 to i64
  %t571 = load ptr, ptr @__olang_prog_scope
  %t574 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t571, ptr %t567, i64 %t570)
  store %"compiler/mir:Task" %t574, ptr %l262
  br label %bb113
bb113:
  %t575 = load %"compiler/mir:Task", ptr %l262
  store %"compiler/mir:Task" %t575, ptr %l24
  store i32 0, ptr %l25, !tbaa !23
  %t576 = getelementptr %"compiler/mir:Task", ptr %l24, i32 0, i32 3
  %t577 = getelementptr %"compiler/mir:Range", ptr %t576, i32 0, i32 1
  %t578 = load i32, ptr %t577, !tbaa !23
  store i32 %t578, ptr %l26, !tbaa !23
  store i32 1, ptr %l27, !tbaa !23
  %t580 = load i32, ptr %l26, !tbaa !23
  %t581 = load i32, ptr %l25, !tbaa !23
  %t584 = icmp sgt i32 %t580, %t581
  br i1 %t584, label %bb114, label %bb115
bb114:
  %t586 = load i32, ptr %l27, !tbaa !23
  %t588 = icmp sgt i32 %t586, 0
  br i1 %t588, label %bb116, label %bb117
bb115:
  store i32 0, ptr %l267, !tbaa !23
  br label %bb119
bb116:
  %t590 = load i32, ptr %l26, !tbaa !23
  %t591 = load i32, ptr %l25, !tbaa !23
  %t594 = sub i32 %t590, %t591
  %t595 = load i32, ptr %l27, !tbaa !23
  %t598 = add i32 %t594, %t595
  %t600 = sub i32 %t598, 1
  %t601 = load i32, ptr %l27, !tbaa !23
  %t604 = sdiv i32 %t600, %t601
  store i32 %t604, ptr %l270, !tbaa !23
  br label %bb118
bb117:
  store i32 0, ptr %l270, !tbaa !23
  br label %bb118
bb118:
  %t606 = load i32, ptr %l270, !tbaa !23
  store i32 %t606, ptr %l267, !tbaa !23
  br label %bb119
bb119:
  %t607 = load i32, ptr %l267, !tbaa !23
  store i32 %t607, ptr %l28, !tbaa !23
  store i32 0, ptr %l29, !tbaa !23
  br label %bb120
bb120:
  %t608 = load i32, ptr %l29, !tbaa !23
  %t609 = load i32, ptr %l28, !tbaa !23
  %t612 = icmp slt i32 %t608, %t609
  %t614 = xor i1 %t612, true
  br i1 %t614, label %bb121, label %bb122
bb121:
  br label %bb127
bb122:
  br label %bb123
bb123:
  %t616 = load i32, ptr %l25, !tbaa !23
  %t617 = load i32, ptr %l29, !tbaa !23
  %t618 = load i32, ptr %l27, !tbaa !23
  %t621 = mul i32 %t617, %t618
  %t624 = add i32 %t616, %t621
  %t626 = load ptr, ptr %l0, !tbaa !29
  store ptr %t626, ptr %l288, !tbaa !29
  %t627 = load ptr, ptr %l2, !tbaa !29
  %t629 = getelementptr %"compiler/mir:Fn", ptr %t627, i32 0, i32 13
  %t630 = getelementptr %"compiler/mir:Task", ptr %l24, i32 0, i32 3
  %t631 = getelementptr %"compiler/mir:Range", ptr %t630, i32 0, i32 0
  %t632 = load i32, ptr %t631, !tbaa !23
  %t634 = sext i32 %t632 to i64
  %t637 = sext i32 %t624 to i64
  %t640 = add i64 %t634, %t637
  %t641 = load ptr, ptr @__olang_prog_scope
  %t644 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %t641, ptr %t629, i64 %t640)
  store %"compiler/mir:Lvalue" %t644, ptr %l296
  br label %bb124
bb124:
  %t645 = load ptr, ptr %l288, !tbaa !29
  %t646 = load %"compiler/mir:Lvalue", ptr %l296
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t645, %"compiler/mir:Lvalue" %t646)
  br label %bb125
bb125:
  br label %bb126
bb126:
  %t647 = load i32, ptr %l29, !tbaa !23
  %t649 = add i32 %t647, 1
  store i32 %t649, ptr %l29, !tbaa !23
  br label %bb120
bb127:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t652 = getelementptr %"compiler/mir:Task", ptr %l24, i32 0, i32 0
  %t653 = load { i64, [7 x i64] }, ptr %t652
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %t651, { i64, [7 x i64] } %t653)
  br label %bb128
bb128:
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = getelementptr %"compiler/mir:Task", ptr %l24, i32 0, i32 1
  %t658 = load %"compiler/mir:Range", ptr %t657
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t656, %"compiler/mir:Range" %t658)
  br label %bb129
bb129:
  store i32 0, ptr %l31, !tbaa !23
  %t661 = getelementptr %"compiler/mir:Task", ptr %l24, i32 0, i32 2
  %t662 = getelementptr %"compiler/mir:Range", ptr %t661, i32 0, i32 1
  %t663 = load i32, ptr %t662, !tbaa !23
  store i32 %t663, ptr %l32, !tbaa !23
  store i32 1, ptr %l33, !tbaa !23
  %t665 = load i32, ptr %l32, !tbaa !23
  %t666 = load i32, ptr %l31, !tbaa !23
  %t669 = icmp sgt i32 %t665, %t666
  br i1 %t669, label %bb130, label %bb131
bb130:
  %t671 = load i32, ptr %l33, !tbaa !23
  %t673 = icmp sgt i32 %t671, 0
  br i1 %t673, label %bb132, label %bb133
bb131:
  store i32 0, ptr %l307, !tbaa !23
  br label %bb135
bb132:
  %t675 = load i32, ptr %l32, !tbaa !23
  %t676 = load i32, ptr %l31, !tbaa !23
  %t679 = sub i32 %t675, %t676
  %t680 = load i32, ptr %l33, !tbaa !23
  %t683 = add i32 %t679, %t680
  %t685 = sub i32 %t683, 1
  %t686 = load i32, ptr %l33, !tbaa !23
  %t689 = sdiv i32 %t685, %t686
  store i32 %t689, ptr %l310, !tbaa !23
  br label %bb134
bb133:
  store i32 0, ptr %l310, !tbaa !23
  br label %bb134
bb134:
  %t691 = load i32, ptr %l310, !tbaa !23
  store i32 %t691, ptr %l307, !tbaa !23
  br label %bb135
bb135:
  %t692 = load i32, ptr %l307, !tbaa !23
  store i32 %t692, ptr %l34, !tbaa !23
  store i32 0, ptr %l35, !tbaa !23
  br label %bb136
bb136:
  %t693 = load i32, ptr %l35, !tbaa !23
  %t694 = load i32, ptr %l34, !tbaa !23
  %t697 = icmp slt i32 %t693, %t694
  %t699 = xor i1 %t697, true
  br i1 %t699, label %bb137, label %bb138
bb137:
  br label %bb143
bb138:
  br label %bb139
bb139:
  %t701 = load i32, ptr %l31, !tbaa !23
  %t702 = load i32, ptr %l35, !tbaa !23
  %t703 = load i32, ptr %l33, !tbaa !23
  %t706 = mul i32 %t702, %t703
  %t709 = add i32 %t701, %t706
  %t711 = load ptr, ptr %l0, !tbaa !29
  store ptr %t711, ptr %l328, !tbaa !29
  %t712 = load ptr, ptr %l2, !tbaa !29
  %t714 = getelementptr %"compiler/mir:Fn", ptr %t712, i32 0, i32 12
  %t715 = getelementptr %"compiler/mir:Task", ptr %l24, i32 0, i32 2
  %t716 = getelementptr %"compiler/mir:Range", ptr %t715, i32 0, i32 0
  %t717 = load i32, ptr %t716, !tbaa !23
  %t719 = sext i32 %t717 to i64
  %t722 = sext i32 %t709 to i64
  %t725 = add i64 %t719, %t722
  %t726 = load ptr, ptr @__olang_prog_scope
  %t729 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t726, ptr %t714, i64 %t725)
  store { i64, [1 x i64] } %t729, ptr %l336
  br label %bb140
bb140:
  %t730 = load ptr, ptr %l328, !tbaa !29
  %t731 = load { i64, [1 x i64] }, ptr %l336
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t730, { i64, [1 x i64] } %t731)
  br label %bb141
bb141:
  br label %bb142
bb142:
  %t732 = load i32, ptr %l35, !tbaa !23
  %t734 = add i32 %t732, 1
  store i32 %t734, ptr %l35, !tbaa !23
  br label %bb136
bb143:
  store i32 0, ptr %l37, !tbaa !23
  %t736 = getelementptr %"compiler/mir:Task", ptr %l24, i32 0, i32 7
  %t737 = getelementptr %"compiler/mir:Range", ptr %t736, i32 0, i32 1
  %t738 = load i32, ptr %t737, !tbaa !23
  store i32 %t738, ptr %l38, !tbaa !23
  store i32 1, ptr %l39, !tbaa !23
  %t740 = load i32, ptr %l38, !tbaa !23
  %t741 = load i32, ptr %l37, !tbaa !23
  %t744 = icmp sgt i32 %t740, %t741
  br i1 %t744, label %bb144, label %bb145
bb144:
  %t746 = load i32, ptr %l39, !tbaa !23
  %t748 = icmp sgt i32 %t746, 0
  br i1 %t748, label %bb146, label %bb147
bb145:
  store i32 0, ptr %l343, !tbaa !23
  br label %bb149
bb146:
  %t750 = load i32, ptr %l38, !tbaa !23
  %t751 = load i32, ptr %l37, !tbaa !23
  %t754 = sub i32 %t750, %t751
  %t755 = load i32, ptr %l39, !tbaa !23
  %t758 = add i32 %t754, %t755
  %t760 = sub i32 %t758, 1
  %t761 = load i32, ptr %l39, !tbaa !23
  %t764 = sdiv i32 %t760, %t761
  store i32 %t764, ptr %l346, !tbaa !23
  br label %bb148
bb147:
  store i32 0, ptr %l346, !tbaa !23
  br label %bb148
bb148:
  %t766 = load i32, ptr %l346, !tbaa !23
  store i32 %t766, ptr %l343, !tbaa !23
  br label %bb149
bb149:
  %t767 = load i32, ptr %l343, !tbaa !23
  store i32 %t767, ptr %l40, !tbaa !23
  store i32 0, ptr %l41, !tbaa !23
  br label %bb150
bb150:
  %t768 = load i32, ptr %l41, !tbaa !23
  %t769 = load i32, ptr %l40, !tbaa !23
  %t772 = icmp slt i32 %t768, %t769
  %t774 = xor i1 %t772, true
  br i1 %t774, label %bb151, label %bb152
bb151:
  br label %bb160
bb152:
  br label %bb153
bb153:
  %t776 = load i32, ptr %l37, !tbaa !23
  %t777 = load i32, ptr %l41, !tbaa !23
  %t778 = load i32, ptr %l39, !tbaa !23
  %t781 = mul i32 %t777, %t778
  %t784 = add i32 %t776, %t781
  %t786 = load ptr, ptr %l2, !tbaa !29
  %t788 = getelementptr %"compiler/mir:Fn", ptr %t786, i32 0, i32 12
  %t789 = getelementptr %"compiler/mir:Task", ptr %l24, i32 0, i32 7
  %t790 = getelementptr %"compiler/mir:Range", ptr %t789, i32 0, i32 0
  %t791 = load i32, ptr %t790, !tbaa !23
  %t793 = sext i32 %t791 to i64
  %t796 = sext i32 %t784 to i64
  %t799 = add i64 %t793, %t796
  %t800 = load ptr, ptr @__olang_prog_scope
  %t803 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t800, ptr %t788, i64 %t799)
  store { i64, [1 x i64] } %t803, ptr %l371
  br label %bb154
bb154:
  %t804 = load { i64, [1 x i64] }, ptr %l371
  store { i64, [1 x i64] } %t804, ptr %l43
  %t805 = load { i64, [1 x i64] }, ptr %l43
  %t807 = extractvalue { i64, [1 x i64] } %t805, 0
  %t808 = icmp eq i64 %t807, 3
  %t810 = xor i1 %t808, true
  br i1 %t810, label %bb155, label %bb156
bb155:
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t813 = load { i64, [1 x i64] }, ptr %l43
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t812, { i64, [1 x i64] } %t813)
  br label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb158
bb158:
  br label %bb159
bb159:
  %t816 = load i32, ptr %l41, !tbaa !23
  %t818 = add i32 %t816, 1
  store i32 %t818, ptr %l41, !tbaa !23
  br label %bb150
bb160:
  store i32 0, ptr %l44, !tbaa !23
  %t820 = getelementptr %"compiler/mir:Task", ptr %l24, i32 0, i32 4
  %t821 = getelementptr %"compiler/mir:Range", ptr %t820, i32 0, i32 1
  %t822 = load i32, ptr %t821, !tbaa !23
  store i32 %t822, ptr %l45, !tbaa !23
  store i32 1, ptr %l46, !tbaa !23
  %t824 = load i32, ptr %l45, !tbaa !23
  %t825 = load i32, ptr %l44, !tbaa !23
  %t828 = icmp sgt i32 %t824, %t825
  br i1 %t828, label %bb161, label %bb162
bb161:
  %t830 = load i32, ptr %l46, !tbaa !23
  %t832 = icmp sgt i32 %t830, 0
  br i1 %t832, label %bb163, label %bb164
bb162:
  store i32 0, ptr %l383, !tbaa !23
  br label %bb166
bb163:
  %t834 = load i32, ptr %l45, !tbaa !23
  %t835 = load i32, ptr %l44, !tbaa !23
  %t838 = sub i32 %t834, %t835
  %t839 = load i32, ptr %l46, !tbaa !23
  %t842 = add i32 %t838, %t839
  %t844 = sub i32 %t842, 1
  %t845 = load i32, ptr %l46, !tbaa !23
  %t848 = sdiv i32 %t844, %t845
  store i32 %t848, ptr %l386, !tbaa !23
  br label %bb165
bb164:
  store i32 0, ptr %l386, !tbaa !23
  br label %bb165
bb165:
  %t850 = load i32, ptr %l386, !tbaa !23
  store i32 %t850, ptr %l383, !tbaa !23
  br label %bb166
bb166:
  %t851 = load i32, ptr %l383, !tbaa !23
  store i32 %t851, ptr %l47, !tbaa !23
  store i32 0, ptr %l48, !tbaa !23
  br label %bb167
bb167:
  %t852 = load i32, ptr %l48, !tbaa !23
  %t853 = load i32, ptr %l47, !tbaa !23
  %t856 = icmp slt i32 %t852, %t853
  %t858 = xor i1 %t856, true
  br i1 %t858, label %bb168, label %bb169
bb168:
  br label %bb174
bb169:
  br label %bb170
bb170:
  %t860 = load i32, ptr %l44, !tbaa !23
  %t861 = load i32, ptr %l48, !tbaa !23
  %t862 = load i32, ptr %l46, !tbaa !23
  %t865 = mul i32 %t861, %t862
  %t868 = add i32 %t860, %t865
  %t870 = load ptr, ptr %l0, !tbaa !29
  store ptr %t870, ptr %l404, !tbaa !29
  %t871 = load ptr, ptr %l2, !tbaa !29
  %t873 = getelementptr %"compiler/mir:Fn", ptr %t871, i32 0, i32 17
  %t874 = getelementptr %"compiler/mir:Task", ptr %l24, i32 0, i32 4
  %t875 = getelementptr %"compiler/mir:Range", ptr %t874, i32 0, i32 0
  %t876 = load i32, ptr %t875, !tbaa !23
  %t878 = sext i32 %t876 to i64
  %t881 = sext i32 %t868 to i64
  %t884 = add i64 %t878, %t881
  %t885 = load ptr, ptr @__olang_prog_scope
  %t888 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %t885, ptr %t873, i64 %t884)
  store %"compiler/mir:TaskClause" %t888, ptr %l412
  br label %bb171
bb171:
  %t889 = getelementptr %"compiler/mir:TaskClause", ptr %l412, i32 0, i32 2
  %t890 = load { i64, [4 x i64] }, ptr %t889
  %t891 = load ptr, ptr %l404, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t891, { i64, [4 x i64] } %t890)
  br label %bb172
bb172:
  br label %bb173
bb173:
  %t893 = load i32, ptr %l48, !tbaa !23
  %t895 = add i32 %t893, 1
  store i32 %t895, ptr %l48, !tbaa !23
  br label %bb167
bb174:
  %t897 = load ptr, ptr %l0, !tbaa !29
  %t899 = getelementptr %"compiler/mir:verifier", ptr %t897, i32 0, i32 16
  %t900 = load { i64, ptr }, ptr %t899, !tbaa !27
  store { i64, ptr } %t900, ptr %l417, !tbaa !27
  %t901 = load i32, ptr %l22, !tbaa !23
  %t903 = sext i32 %t901 to i64
  %t905 = getelementptr { i64, ptr }, ptr %l417, i32 0, i32 1
  %t906 = load ptr, ptr %t905, !tbaa !27
  %t907 = getelementptr i1, ptr %t906, i64 %t903
  store i1 true, ptr %t907, !tbaa !31
  br label %bb208
bb175:
  %t908 = load ptr, ptr %l1, !tbaa !29
  store ptr %t908, ptr %l420, !tbaa !29
  store i1 false, ptr %l421, !tbaa !21
  %t909 = load ptr, ptr %l420, !tbaa !29
  %t910 = icmp ne ptr %t909, null
  br i1 %t910, label %bb176, label %bb177
bb176:
  %t912 = load ptr, ptr %l420, !tbaa !29
  %t913 = load i64, ptr %t912, !range !{i64 0, i64 15}
  %t915 = icmp eq i64 %t913, 11
  store i1 %t915, ptr %l421, !tbaa !21
  br label %bb177
bb177:
  %t916 = load i1, ptr %l421, !tbaa !21
  br i1 %t916, label %bb178, label %bb179
bb178:
  br label %bb184
bb179:
  %t917 = load ptr, ptr %l1, !tbaa !29
  store ptr %t917, ptr %l424, !tbaa !29
  store i1 false, ptr %l425, !tbaa !21
  %t918 = load ptr, ptr %l424, !tbaa !29
  %t919 = icmp ne ptr %t918, null
  br i1 %t919, label %bb180, label %bb181
bb180:
  %t921 = load ptr, ptr %l424, !tbaa !29
  %t922 = load i64, ptr %t921, !range !{i64 0, i64 15}
  %t924 = icmp eq i64 %t922, 13
  store i1 %t924, ptr %l425, !tbaa !21
  br label %bb181
bb181:
  %t925 = load i1, ptr %l425, !tbaa !21
  br i1 %t925, label %bb182, label %bb183
bb182:
  br label %bb184
bb183:
  br label %bb185
bb184:
  br label %bb208
bb185:
  %t926 = load ptr, ptr %l1, !tbaa !29
  store ptr %t926, ptr %l428, !tbaa !29
  store i1 false, ptr %l429, !tbaa !21
  %t927 = load ptr, ptr %l428, !tbaa !29
  %t928 = icmp ne ptr %t927, null
  br i1 %t928, label %bb186, label %bb187
bb186:
  %t930 = load ptr, ptr %l428, !tbaa !29
  %t931 = load i64, ptr %t930, !range !{i64 0, i64 15}
  %t933 = icmp eq i64 %t931, 12
  store i1 %t933, ptr %l429, !tbaa !21
  br label %bb187
bb187:
  %t934 = load i1, ptr %l429, !tbaa !21
  br i1 %t934, label %bb188, label %bb189
bb188:
  %t935 = load ptr, ptr %l1, !tbaa !29
  %t937 = getelementptr { i64, [21 x i64] }, ptr %t935, i32 0, i32 1
  %t938 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t937, i32 0, i32 1
  %t939 = load { i64, [4 x i64] }, ptr %t938
  store { i64, [4 x i64] } %t939, ptr %l50
  br label %bb190
bb189:
  br label %bb192
bb190:
  %t941 = load ptr, ptr %l0, !tbaa !29
  %t942 = load { i64, [4 x i64] }, ptr %l50
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t941, { i64, [4 x i64] } %t942)
  br label %bb191
bb191:
  br label %bb208
bb192:
  %t945 = load ptr, ptr %l1, !tbaa !29
  store ptr %t945, ptr %l436, !tbaa !29
  store i1 false, ptr %l437, !tbaa !21
  %t946 = load ptr, ptr %l436, !tbaa !29
  %t947 = icmp ne ptr %t946, null
  br i1 %t947, label %bb193, label %bb194
bb193:
  %t949 = load ptr, ptr %l436, !tbaa !29
  %t950 = load i64, ptr %t949, !range !{i64 0, i64 15}
  %t952 = icmp eq i64 %t950, 14
  store i1 %t952, ptr %l437, !tbaa !21
  br label %bb194
bb194:
  %t953 = load i1, ptr %l437, !tbaa !21
  br i1 %t953, label %bb195, label %bb196
bb195:
  %t954 = load ptr, ptr %l1, !tbaa !29
  %t956 = getelementptr { i64, [21 x i64] }, ptr %t954, i32 0, i32 1
  %t957 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t956, i32 0, i32 1
  %t958 = load i32, ptr %t957
  store i32 %t958, ptr %l51, !tbaa !23
  %t960 = load ptr, ptr %l1, !tbaa !29
  %t962 = getelementptr { i64, [21 x i64] }, ptr %t960, i32 0, i32 1
  %t963 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t962, i32 0, i32 2
  %t964 = load i32, ptr %t963
  store i32 %t964, ptr %l52, !tbaa !23
  br label %bb197
bb196:
  br label %bb207
bb197:
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t967 = load i32, ptr %l51, !tbaa !23
  %t970 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t966, i32 %t967)
  store i1 %t970, ptr %l446
  br label %bb198
bb198:
  %t971 = load i1, ptr %l446, !tbaa !21
  %t972 = xor i1 %t971, true
  br i1 %t972, label %bb199, label %bb200
bb199:
  store %olang.scope zeroinitializer, ptr %s37
  %t974 = load ptr, ptr %l0, !tbaa !29
  %t975 = load i32, ptr %l51, !tbaa !23
  %t976 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t977 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t979 = sext i32 %t975 to i64
  %t980 = call i64 @__olang_fmt_i64(ptr null, i64 %t979)
  %t981 = add i64 %t977, %t980
  %t982 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t983 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t984 = add i64 %t981, %t983
  %t985 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t984)
  call void @olang_textcopy(ptr %t985, ptr %t976, i64 %t977)
  %t986 = getelementptr i8, ptr %t985, i64 %t977
  %t987 = call i64 @__olang_fmt_i64(ptr %t986, i64 %t979)
  %t988 = getelementptr i8, ptr %t986, i64 %t980
  call void @olang_textcopy(ptr %t988, ptr %t982, i64 %t983)
  %t989 = insertvalue { i64, ptr } undef, i64 %t984, 0
  %t990 = insertvalue { i64, ptr } %t989, ptr %t985, 1
  %t992 = extractvalue { i64, ptr } %t990, 0
  %t993 = extractvalue { i64, ptr } %t990, 1
  %t994 = mul i64 %t992, 1
  %t995 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t994)
  call void @llvm.memcpy.p0.p0.i64(ptr %t995, ptr %t993, i64 %t994, i1 false)
  %t996 = insertvalue { i64, ptr } undef, i64 %t992, 0
  %t997 = insertvalue { i64, ptr } %t996, ptr %t995, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s37, ptr %t974, { i64, ptr } %t997)
  br label %bb201
bb200:
  br label %bb202
bb201:
  call void @__olang_scope_close(ptr %s37)
  br label %bb202
bb202:
  %t1000 = load i32, ptr %l52, !tbaa !23
  %t1001 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t1004 = icmp ne i32 %t1000, %t1001
  br i1 %t1004, label %bb203, label %bb204
bb203:
  %t1006 = load ptr, ptr %l0, !tbaa !29
  %t1007 = load i32, ptr %l52, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t1006, i32 %t1007)
  br label %bb205
bb204:
  br label %bb206
bb205:
  br label %bb206
bb206:
  br label %bb208
bb207:
  call void @__olang_check_failed(ptr @olang_loc_30c75e8686103aec_2a803509807dc2e8)
  unreachable
bb208:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estores(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l9 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/mir:verifier", ptr %t13, i32 0, i32 15
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = load i32, ptr %l3, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t21 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i1, ptr %t22, i64 %t19
  %t24 = load i1, ptr %t23, !tbaa !31
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t33 = sext i32 %t29 to i64
  %t34 = call i64 @__olang_fmt_i64(ptr null, i64 %t33)
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  %t41 = call i64 @__olang_fmt_i64(ptr %t40, i64 %t33)
  %t42 = getelementptr i8, ptr %t40, i64 %t34
  call void @olang_textcopy(ptr %t42, ptr %t36, i64 %t37)
  %t43 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t39, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t28, { i64, ptr } %t51)
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t54 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t55 = getelementptr %"compiler/mir:Range", ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55, !tbaa !23
  %t58 = icmp eq i32 %t56, 0
  br i1 %t58, label %bb8, label %bb9
bb8:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/mir:verifier", ptr %t60, i32 0, i32 14
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l21, !tbaa !27
  %t64 = load i32, ptr %l3, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t68 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i1, ptr %t69, i64 %t66
  store i1 true, ptr %t70, !tbaa !31
  br label %bb11
bb9:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/mir:Lvalue", ptr %l1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t71, %"compiler/mir:Lvalue" %t72)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb18
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load %"compiler/mir:Lvalue", ptr %l1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t75, %"compiler/mir:Lvalue" %t76)
  br label %bb16
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8c773ec7d9409528_6b556770aed18854)
  unreachable
bb18:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etagType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l6 = alloca i1
  %l10 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load ptr, ptr @__olang_prog_scope
  %t9 = call i1 @compiler_2fmir_2eHasCases(ptr %t6, ptr %t4, i32 %t5)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %l2, !tbaa !21
  %t11 = load i32, ptr %l1, !tbaa !23
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t15 = icmp ne i32 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i1, ptr %l2, !tbaa !21
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l16
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t28 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t30 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = add i64 %t29, %t32
  %t34 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t28, i64 %t29)
  %t38 = getelementptr i8, ptr %t37, i64 %t29
  call void @olang_textcopy(ptr %t38, ptr %t31, i64 %t32)
  %t39 = getelementptr i8, ptr %t38, i64 %t32
  call void @olang_textcopy(ptr %t39, ptr %t34, i64 %t35)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t49 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t49, { i64, ptr } %t48)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t51 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermFlow(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l16 = alloca i32
  %l17 = alloca %"compiler/mir:Call"
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i32
  %l26 = alloca %"compiler/mir:Call"
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l33 = alloca { i64, [4 x i64] }
  %l34 = alloca { i64, [4 x i64] }
  %l35 = alloca i32
  %l36 = alloca { i64, [4 x i64] }
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l71 = alloca i32
  %l74 = alloca i32
  %l92 = alloca ptr
  %l100 = alloca %"compiler/mir:Case"
  %l113 = alloca %"compiler/mir:Call"
  %l122 = alloca i32
  %l125 = alloca i32
  %l143 = alloca ptr
  %l151 = alloca { i64, [1 x i64] }
  %l158 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l194 = alloca %"compiler/mir:Call"
  %l203 = alloca i32
  %l206 = alloca i32
  %l224 = alloca ptr
  %l232 = alloca { i64, [1 x i64] }
  %l237 = alloca i64
  %l239 = alloca ptr
  %l241 = alloca { i64, ptr }
  %l254 = alloca i64
  %l256 = alloca ptr
  %l258 = alloca { i64, ptr }
  %l282 = alloca i1
  %l289 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l301 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %s13 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s28 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [8 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [8 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t15, i32 %t16)
  br label %bb4
bb4:
  br label %bb136
bb5:
  %t19 = load { i64, [8 x i64] }, ptr %l1
  %t21 = extractvalue { i64, [8 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 2
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t25 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t24, i32 0, i32 0
  %t26 = load { i64, [4 x i64] }, ptr %t25
  store { i64, [4 x i64] } %t26, ptr %l4
  %t28 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l5, !tbaa !23
  %t32 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t33 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t32, i32 0, i32 2
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l6, !tbaa !23
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, [4 x i64] }, ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t36, { i64, [4 x i64] } %t37)
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t40, i32 %t41)
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t44, i32 %t45)
  br label %bb11
bb11:
  br label %bb136
bb12:
  %t48 = load { i64, [8 x i64] }, ptr %l1
  %t50 = extractvalue { i64, [8 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 3
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t54 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t53, i32 0, i32 0
  %t55 = load { i64, [4 x i64] }, ptr %t54
  store { i64, [4 x i64] } %t55, ptr %l7
  %t57 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t58 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t57, i32 0, i32 1
  %t59 = load %"compiler/mir:Range", ptr %t58
  store %"compiler/mir:Range" %t59, ptr %l8
  %t61 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t61, i32 0, i32 2
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l9, !tbaa !23
  br label %bb15
bb14:
  br label %bb32
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, [4 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t65, { i64, [4 x i64] } %t66)
  br label %bb16
bb16:
  store i32 0, ptr %l10, !tbaa !23
  %t69 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 1
  %t70 = load i32, ptr %t69, !tbaa !23
  store i32 %t70, ptr %l11, !tbaa !23
  store i32 1, ptr %l12, !tbaa !23
  %t72 = load i32, ptr %l11, !tbaa !23
  %t73 = load i32, ptr %l10, !tbaa !23
  %t76 = icmp sgt i32 %t72, %t73
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load i32, ptr %l12, !tbaa !23
  %t80 = icmp sgt i32 %t78, 0
  br i1 %t80, label %bb19, label %bb20
bb18:
  store i32 0, ptr %l71, !tbaa !23
  br label %bb22
bb19:
  %t82 = load i32, ptr %l11, !tbaa !23
  %t83 = load i32, ptr %l10, !tbaa !23
  %t86 = sub i32 %t82, %t83
  %t87 = load i32, ptr %l12, !tbaa !23
  %t90 = add i32 %t86, %t87
  %t92 = sub i32 %t90, 1
  %t93 = load i32, ptr %l12, !tbaa !23
  %t96 = sdiv i32 %t92, %t93
  store i32 %t96, ptr %l74, !tbaa !23
  br label %bb21
bb20:
  store i32 0, ptr %l74, !tbaa !23
  br label %bb21
bb21:
  %t98 = load i32, ptr %l74, !tbaa !23
  store i32 %t98, ptr %l71, !tbaa !23
  br label %bb22
bb22:
  %t99 = load i32, ptr %l71, !tbaa !23
  store i32 %t99, ptr %l13, !tbaa !23
  store i32 0, ptr %l14, !tbaa !23
  br label %bb23
bb23:
  %t100 = load i32, ptr %l14, !tbaa !23
  %t101 = load i32, ptr %l13, !tbaa !23
  %t104 = icmp slt i32 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t108 = load i32, ptr %l10, !tbaa !23
  %t109 = load i32, ptr %l14, !tbaa !23
  %t110 = load i32, ptr %l12, !tbaa !23
  %t113 = mul i32 %t109, %t110
  %t116 = add i32 %t108, %t113
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l92, !tbaa !29
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = getelementptr %"compiler/mir:Fn", ptr %t119, i32 0, i32 15
  %t122 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t123 = load i32, ptr %t122, !tbaa !23
  %t125 = sext i32 %t123 to i64
  %t128 = sext i32 %t116 to i64
  %t131 = add i64 %t125, %t128
  %t132 = load ptr, ptr @__olang_prog_scope
  %t135 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %t132, ptr %t121, i64 %t131)
  store %"compiler/mir:Case" %t135, ptr %l100
  br label %bb27
bb27:
  %t136 = getelementptr %"compiler/mir:Case", ptr %l100, i32 0, i32 1
  %t137 = load i32, ptr %t136, !tbaa !23
  %t138 = load ptr, ptr %l92, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t138, i32 %t137)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t140 = load i32, ptr %l14, !tbaa !23
  %t142 = add i32 %t140, 1
  store i32 %t142, ptr %l14, !tbaa !23
  br label %bb23
bb30:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t144, i32 %t145)
  br label %bb31
bb31:
  br label %bb136
bb32:
  %t148 = load { i64, [8 x i64] }, ptr %l1
  %t150 = extractvalue { i64, [8 x i64] } %t148, 0
  %t151 = icmp eq i64 %t150, 4
  br i1 %t151, label %bb33, label %bb34
bb33:
  %t153 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32 }, ptr %t153, i32 0, i32 1
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l16, !tbaa !23
  br label %bb35
bb34:
  br label %bb66
bb35:
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t159 = getelementptr %"compiler/mir:Fn", ptr %t157, i32 0, i32 14
  %t160 = load i32, ptr %l16, !tbaa !23
  %t162 = sext i32 %t160 to i64
  %t163 = load ptr, ptr @__olang_prog_scope
  %t166 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t163, ptr %t159, i64 %t162)
  store %"compiler/mir:Call" %t166, ptr %l113
  br label %bb36
bb36:
  %t167 = load %"compiler/mir:Call", ptr %l113
  store %"compiler/mir:Call" %t167, ptr %l17
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 0
  %t170 = load { i64, [7 x i64] }, ptr %t169
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %t168, { i64, [7 x i64] } %t170)
  br label %bb37
bb37:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 1
  %t175 = load %"compiler/mir:Range", ptr %t174
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t173, %"compiler/mir:Range" %t175)
  br label %bb38
bb38:
  store i32 0, ptr %l18, !tbaa !23
  %t178 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 2
  %t179 = getelementptr %"compiler/mir:Range", ptr %t178, i32 0, i32 1
  %t180 = load i32, ptr %t179, !tbaa !23
  store i32 %t180, ptr %l19, !tbaa !23
  store i32 1, ptr %l20, !tbaa !23
  %t182 = load i32, ptr %l19, !tbaa !23
  %t183 = load i32, ptr %l18, !tbaa !23
  %t186 = icmp sgt i32 %t182, %t183
  br i1 %t186, label %bb39, label %bb40
bb39:
  %t188 = load i32, ptr %l20, !tbaa !23
  %t190 = icmp sgt i32 %t188, 0
  br i1 %t190, label %bb41, label %bb42
bb40:
  store i32 0, ptr %l122, !tbaa !23
  br label %bb44
bb41:
  %t192 = load i32, ptr %l19, !tbaa !23
  %t193 = load i32, ptr %l18, !tbaa !23
  %t196 = sub i32 %t192, %t193
  %t197 = load i32, ptr %l20, !tbaa !23
  %t200 = add i32 %t196, %t197
  %t202 = sub i32 %t200, 1
  %t203 = load i32, ptr %l20, !tbaa !23
  %t206 = sdiv i32 %t202, %t203
  store i32 %t206, ptr %l125, !tbaa !23
  br label %bb43
bb42:
  store i32 0, ptr %l125, !tbaa !23
  br label %bb43
bb43:
  %t208 = load i32, ptr %l125, !tbaa !23
  store i32 %t208, ptr %l122, !tbaa !23
  br label %bb44
bb44:
  %t209 = load i32, ptr %l122, !tbaa !23
  store i32 %t209, ptr %l21, !tbaa !23
  store i32 0, ptr %l22, !tbaa !23
  br label %bb45
bb45:
  %t210 = load i32, ptr %l22, !tbaa !23
  %t211 = load i32, ptr %l21, !tbaa !23
  %t214 = icmp slt i32 %t210, %t211
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  br label %bb48
bb48:
  %t218 = load i32, ptr %l18, !tbaa !23
  %t219 = load i32, ptr %l22, !tbaa !23
  %t220 = load i32, ptr %l20, !tbaa !23
  %t223 = mul i32 %t219, %t220
  %t226 = add i32 %t218, %t223
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l143, !tbaa !29
  %t229 = load ptr, ptr %l2, !tbaa !29
  %t231 = getelementptr %"compiler/mir:Fn", ptr %t229, i32 0, i32 12
  %t232 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 2
  %t233 = getelementptr %"compiler/mir:Range", ptr %t232, i32 0, i32 0
  %t234 = load i32, ptr %t233, !tbaa !23
  %t236 = sext i32 %t234 to i64
  %t239 = sext i32 %t226 to i64
  %t242 = add i64 %t236, %t239
  %t243 = load ptr, ptr @__olang_prog_scope
  %t246 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t243, ptr %t231, i64 %t242)
  store { i64, [1 x i64] } %t246, ptr %l151
  br label %bb49
bb49:
  %t247 = load ptr, ptr %l143, !tbaa !29
  %t248 = load { i64, [1 x i64] }, ptr %l151
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t247, { i64, [1 x i64] } %t248)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t249 = load i32, ptr %l22, !tbaa !23
  %t251 = add i32 %t249, 1
  store i32 %t251, ptr %l22, !tbaa !23
  br label %bb45
bb52:
  %t253 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 7
  %t254 = load i32, ptr %t253, !tbaa !23
  %t255 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t258 = icmp ne i32 %t254, %t255
  br i1 %t258, label %bb53, label %bb54
bb53:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/mir:verifier", ptr %t260, i32 0, i32 15
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l158, !tbaa !27
  %t264 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t265 = load i32, ptr %t264, !tbaa !23
  %t267 = sext i32 %t265 to i64
  %t269 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i1, ptr %t270, i64 %t267
  %t272 = load i1, ptr %t271, !tbaa !31
  br i1 %t272, label %bb55, label %bb56
bb54:
  br label %bb60
bb55:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/mir:verifier", ptr %t274, i32 0, i32 14
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  store { i64, ptr } %t277, ptr %l163, !tbaa !27
  %t278 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t279 = load i32, ptr %t278, !tbaa !23
  %t281 = sext i32 %t279 to i64
  %t283 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i1, ptr %t284, i64 %t281
  %t286 = load i1, ptr %t285, !tbaa !31
  store i1 %t286, ptr %l24, !tbaa !21
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/mir:verifier", ptr %t288, i32 0, i32 14
  %t291 = load { i64, ptr }, ptr %t290, !tbaa !27
  store { i64, ptr } %t291, ptr %l168, !tbaa !27
  %t292 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t293 = load i32, ptr %t292, !tbaa !23
  %t295 = sext i32 %t293 to i64
  %t297 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = getelementptr i1, ptr %t298, i64 %t295
  store i1 true, ptr %t299, !tbaa !31
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 7
  %t302 = load i32, ptr %t301, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t300, i32 %t302)
  br label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s13
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t307 = load i32, ptr %t306, !tbaa !23
  %t308 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t311 = sext i32 %t307 to i64
  %t312 = call i64 @__olang_fmt_i64(ptr null, i64 %t311)
  %t313 = add i64 %t309, %t312
  %t314 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t315 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t316 = add i64 %t313, %t315
  %t317 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t316)
  call void @olang_textcopy(ptr %t317, ptr %t308, i64 %t309)
  %t318 = getelementptr i8, ptr %t317, i64 %t309
  %t319 = call i64 @__olang_fmt_i64(ptr %t318, i64 %t311)
  %t320 = getelementptr i8, ptr %t318, i64 %t312
  call void @olang_textcopy(ptr %t320, ptr %t314, i64 %t315)
  %t321 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t317, 1
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t325 = extractvalue { i64, ptr } %t322, 1
  %t326 = mul i64 %t324, 1
  %t327 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t326)
  call void @llvm.memcpy.p0.p0.i64(ptr %t327, ptr %t325, i64 %t326, i1 false)
  %t328 = insertvalue { i64, ptr } undef, i64 %t324, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t327, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s13, ptr %t305, { i64, ptr } %t329)
  br label %bb58
bb57:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/mir:verifier", ptr %t332, i32 0, i32 14
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l174, !tbaa !27
  %t336 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 6
  %t337 = load i32, ptr %t336, !tbaa !23
  %t339 = sext i32 %t337 to i64
  %t340 = load i1, ptr %l24, !tbaa !21
  %t343 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr i1, ptr %t344, i64 %t339
  store i1 %t340, ptr %t345, !tbaa !31
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s13)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t346 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 4
  %t347 = load i1, ptr %t346, !tbaa !21
  br i1 %t347, label %bb61, label %bb62
bb61:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 3
  %t351 = load %"compiler/mir:Lvalue", ptr %t350
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estores(ptr %v0, ptr %t349, %"compiler/mir:Lvalue" %t351)
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/mir:Call", ptr %l17, i32 0, i32 5
  %t356 = load i32, ptr %t355, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t354, i32 %t356)
  br label %bb65
bb65:
  br label %bb136
bb66:
  %t359 = load { i64, [8 x i64] }, ptr %l1
  %t361 = extractvalue { i64, [8 x i64] } %t359, 0
  %t362 = icmp eq i64 %t361, 6
  br i1 %t362, label %bb67, label %bb68
bb67:
  %t364 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t365 = getelementptr { %"compiler/source:Span", i32 }, ptr %t364, i32 0, i32 1
  %t366 = load i32, ptr %t365
  store i32 %t366, ptr %l25, !tbaa !23
  br label %bb69
bb68:
  br label %bb93
bb69:
  %t368 = load ptr, ptr %l2, !tbaa !29
  %t370 = getelementptr %"compiler/mir:Fn", ptr %t368, i32 0, i32 14
  %t371 = load i32, ptr %l25, !tbaa !23
  %t373 = sext i32 %t371 to i64
  %t374 = load ptr, ptr @__olang_prog_scope
  %t377 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t374, ptr %t370, i64 %t373)
  store %"compiler/mir:Call" %t377, ptr %l194
  br label %bb70
bb70:
  %t378 = load %"compiler/mir:Call", ptr %l194
  store %"compiler/mir:Call" %t378, ptr %l26
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/mir:Call", ptr %l26, i32 0, i32 0
  %t381 = load { i64, [7 x i64] }, ptr %t380
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %t379, { i64, [7 x i64] } %t381)
  br label %bb71
bb71:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/mir:Call", ptr %l26, i32 0, i32 1
  %t386 = load %"compiler/mir:Range", ptr %t385
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t384, %"compiler/mir:Range" %t386)
  br label %bb72
bb72:
  store i32 0, ptr %l27, !tbaa !23
  %t389 = getelementptr %"compiler/mir:Call", ptr %l26, i32 0, i32 2
  %t390 = getelementptr %"compiler/mir:Range", ptr %t389, i32 0, i32 1
  %t391 = load i32, ptr %t390, !tbaa !23
  store i32 %t391, ptr %l28, !tbaa !23
  store i32 1, ptr %l29, !tbaa !23
  %t393 = load i32, ptr %l28, !tbaa !23
  %t394 = load i32, ptr %l27, !tbaa !23
  %t397 = icmp sgt i32 %t393, %t394
  br i1 %t397, label %bb73, label %bb74
bb73:
  %t399 = load i32, ptr %l29, !tbaa !23
  %t401 = icmp sgt i32 %t399, 0
  br i1 %t401, label %bb75, label %bb76
bb74:
  store i32 0, ptr %l203, !tbaa !23
  br label %bb78
bb75:
  %t403 = load i32, ptr %l28, !tbaa !23
  %t404 = load i32, ptr %l27, !tbaa !23
  %t407 = sub i32 %t403, %t404
  %t408 = load i32, ptr %l29, !tbaa !23
  %t411 = add i32 %t407, %t408
  %t413 = sub i32 %t411, 1
  %t414 = load i32, ptr %l29, !tbaa !23
  %t417 = sdiv i32 %t413, %t414
  store i32 %t417, ptr %l206, !tbaa !23
  br label %bb77
bb76:
  store i32 0, ptr %l206, !tbaa !23
  br label %bb77
bb77:
  %t419 = load i32, ptr %l206, !tbaa !23
  store i32 %t419, ptr %l203, !tbaa !23
  br label %bb78
bb78:
  %t420 = load i32, ptr %l203, !tbaa !23
  store i32 %t420, ptr %l30, !tbaa !23
  store i32 0, ptr %l31, !tbaa !23
  br label %bb79
bb79:
  %t421 = load i32, ptr %l31, !tbaa !23
  %t422 = load i32, ptr %l30, !tbaa !23
  %t425 = icmp slt i32 %t421, %t422
  %t427 = xor i1 %t425, true
  br i1 %t427, label %bb80, label %bb81
bb80:
  br label %bb86
bb81:
  br label %bb82
bb82:
  %t429 = load i32, ptr %l27, !tbaa !23
  %t430 = load i32, ptr %l31, !tbaa !23
  %t431 = load i32, ptr %l29, !tbaa !23
  %t434 = mul i32 %t430, %t431
  %t437 = add i32 %t429, %t434
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l224, !tbaa !29
  %t440 = load ptr, ptr %l2, !tbaa !29
  %t442 = getelementptr %"compiler/mir:Fn", ptr %t440, i32 0, i32 12
  %t443 = getelementptr %"compiler/mir:Call", ptr %l26, i32 0, i32 2
  %t444 = getelementptr %"compiler/mir:Range", ptr %t443, i32 0, i32 0
  %t445 = load i32, ptr %t444, !tbaa !23
  %t447 = sext i32 %t445 to i64
  %t450 = sext i32 %t437 to i64
  %t453 = add i64 %t447, %t450
  %t454 = load ptr, ptr @__olang_prog_scope
  %t457 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t454, ptr %t442, i64 %t453)
  store { i64, [1 x i64] } %t457, ptr %l232
  br label %bb83
bb83:
  %t458 = load ptr, ptr %l224, !tbaa !29
  %t459 = load { i64, [1 x i64] }, ptr %l232
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t458, { i64, [1 x i64] } %t459)
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t460 = load i32, ptr %l31, !tbaa !23
  %t462 = add i32 %t460, 1
  store i32 %t462, ptr %l31, !tbaa !23
  br label %bb79
bb86:
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = getelementptr %"compiler/mir:verifier", ptr %t464, i32 0, i32 17
  %t468 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t466)
  store i64 %t468, ptr %l237
  br label %bb87
bb87:
  %t469 = load i64, ptr %l237, !tbaa !24
  %t470 = icmp sgt i64 %t469, 0
  br i1 %t470, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s20
  %t472 = load ptr, ptr %l0, !tbaa !29
  store ptr %t472, ptr %l239, !tbaa !29
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t475 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %s20, ptr %t473)
  store { i64, ptr } %t475, ptr %l241
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t476 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t477 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t478 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t478, 1
  %t480 = extractvalue { i64, ptr } %t478, 0
  %t481 = add i64 %t477, %t480
  %t482 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t483 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t484 = add i64 %t481, %t483
  %t485 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t484)
  call void @olang_textcopy(ptr %t485, ptr %t476, i64 %t477)
  %t486 = getelementptr i8, ptr %t485, i64 %t477
  call void @olang_textcopy(ptr %t486, ptr %t479, i64 %t480)
  %t487 = getelementptr i8, ptr %t486, i64 %t480
  call void @olang_textcopy(ptr %t487, ptr %t482, i64 %t483)
  %t488 = insertvalue { i64, ptr } undef, i64 %t484, 0
  %t489 = insertvalue { i64, ptr } %t488, ptr %t485, 1
  %t491 = extractvalue { i64, ptr } %t489, 0
  %t492 = extractvalue { i64, ptr } %t489, 1
  %t493 = mul i64 %t491, 1
  %t494 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t493)
  call void @llvm.memcpy.p0.p0.i64(ptr %t494, ptr %t492, i64 %t493, i1 false)
  %t495 = insertvalue { i64, ptr } undef, i64 %t491, 0
  %t496 = insertvalue { i64, ptr } %t495, ptr %t494, 1
  %t497 = load ptr, ptr %l239, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s20, ptr %t497, { i64, ptr } %t496)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s20)
  br label %bb92
bb92:
  br label %bb136
bb93:
  %t499 = load { i64, [8 x i64] }, ptr %l1
  %t501 = extractvalue { i64, [8 x i64] } %t499, 0
  %t502 = icmp eq i64 %t501, 5
  br i1 %t502, label %bb94, label %bb95
bb94:
  %t504 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t505 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t504, i32 0, i32 1
  %t506 = load { i64, [4 x i64] }, ptr %t505
  store { i64, [4 x i64] } %t506, ptr %l33
  br label %bb98
bb95:
  %t508 = load { i64, [8 x i64] }, ptr %l1
  %t510 = extractvalue { i64, [8 x i64] } %t508, 0
  %t511 = icmp eq i64 %t510, 7
  br i1 %t511, label %bb96, label %bb97
bb96:
  %t513 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t514 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t513, i32 0, i32 1
  %t515 = load { i64, [4 x i64] }, ptr %t514
  store { i64, [4 x i64] } %t515, ptr %l33
  br label %bb98
bb97:
  br label %bb106
bb98:
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t518 = load { i64, [4 x i64] }, ptr %l33
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t517, { i64, [4 x i64] } %t518)
  br label %bb99
bb99:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/mir:verifier", ptr %t521, i32 0, i32 17
  %t525 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t523)
  store i64 %t525, ptr %l254
  br label %bb100
bb100:
  %t526 = load i64, ptr %l254, !tbaa !24
  %t527 = icmp sgt i64 %t526, 0
  br i1 %t527, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s23
  %t529 = load ptr, ptr %l0, !tbaa !29
  store ptr %t529, ptr %l256, !tbaa !29
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t532 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %s23, ptr %t530)
  store { i64, ptr } %t532, ptr %l258
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t533 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t534 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t535 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t536 = extractvalue { i64, ptr } %t535, 1
  %t537 = extractvalue { i64, ptr } %t535, 0
  %t538 = add i64 %t534, %t537
  %t539 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t540 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t541 = add i64 %t538, %t540
  %t542 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t541)
  call void @olang_textcopy(ptr %t542, ptr %t533, i64 %t534)
  %t543 = getelementptr i8, ptr %t542, i64 %t534
  call void @olang_textcopy(ptr %t543, ptr %t536, i64 %t537)
  %t544 = getelementptr i8, ptr %t543, i64 %t537
  call void @olang_textcopy(ptr %t544, ptr %t539, i64 %t540)
  %t545 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t546 = insertvalue { i64, ptr } %t545, ptr %t542, 1
  %t548 = extractvalue { i64, ptr } %t546, 0
  %t549 = extractvalue { i64, ptr } %t546, 1
  %t550 = mul i64 %t548, 1
  %t551 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t550)
  call void @llvm.memcpy.p0.p0.i64(ptr %t551, ptr %t549, i64 %t550, i1 false)
  %t552 = insertvalue { i64, ptr } undef, i64 %t548, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t551, 1
  %t554 = load ptr, ptr %l256, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s23, ptr %t554, { i64, ptr } %t553)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s23)
  br label %bb105
bb105:
  br label %bb136
bb106:
  %t556 = load { i64, [8 x i64] }, ptr %l1
  %t558 = extractvalue { i64, [8 x i64] } %t556, 0
  %t559 = icmp eq i64 %t558, 11
  br i1 %t559, label %bb107, label %bb108
bb107:
  %t561 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t562 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t561, i32 0, i32 1
  %t563 = load { i64, [4 x i64] }, ptr %t562
  store { i64, [4 x i64] } %t563, ptr %l34
  %t565 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t566 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t565, i32 0, i32 2
  %t567 = load i32, ptr %t566
  store i32 %t567, ptr %l35, !tbaa !23
  br label %bb109
bb108:
  br label %bb112
bb109:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load { i64, [4 x i64] }, ptr %l34
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t569, { i64, [4 x i64] } %t570)
  br label %bb110
bb110:
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t574 = load i32, ptr %l35, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t573, i32 %t574)
  br label %bb111
bb111:
  br label %bb136
bb112:
  %t577 = load { i64, [8 x i64] }, ptr %l1
  %t579 = extractvalue { i64, [8 x i64] } %t577, 0
  %t580 = icmp eq i64 %t579, 9
  br i1 %t580, label %bb113, label %bb114
bb113:
  %t582 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t583 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t582, i32 0, i32 2
  %t584 = load { i64, [4 x i64] }, ptr %t583
  store { i64, [4 x i64] } %t584, ptr %l36
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load { i64, [4 x i64] }, ptr %l36
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t586, { i64, [4 x i64] } %t587)
  br label %bb116
bb116:
  br label %bb136
bb117:
  %t590 = load { i64, [8 x i64] }, ptr %l1
  %t592 = extractvalue { i64, [8 x i64] } %t590, 0
  %t593 = icmp eq i64 %t592, 8
  br i1 %t593, label %bb118, label %bb119
bb118:
  %t595 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t596 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t595, i32 0, i32 1
  %t597 = load i32, ptr %t596
  store i32 %t597, ptr %l37, !tbaa !23
  %t599 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t600 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t599, i32 0, i32 2
  %t601 = load i32, ptr %t600
  store i32 %t601, ptr %l38, !tbaa !23
  %t603 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t604 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t603, i32 0, i32 3
  %t605 = load i32, ptr %t604
  store i32 %t605, ptr %l39, !tbaa !23
  %t607 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t608 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t607, i32 0, i32 4
  %t609 = load i32, ptr %t608
  store i32 %t609, ptr %l40, !tbaa !23
  br label %bb120
bb119:
  br label %bb131
bb120:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load i32, ptr %l37, !tbaa !23
  %t615 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t611, i32 %t612)
  store i1 %t615, ptr %l282
  br label %bb121
bb121:
  %t616 = load i1, ptr %l282, !tbaa !21
  %t617 = xor i1 %t616, true
  br i1 %t617, label %bb122, label %bb123
bb122:
  store %olang.scope zeroinitializer, ptr %s28
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t620 = load i32, ptr %l37, !tbaa !23
  %t621 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t622 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t624 = sext i32 %t620 to i64
  %t625 = call i64 @__olang_fmt_i64(ptr null, i64 %t624)
  %t626 = add i64 %t622, %t625
  %t627 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t628 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t629 = add i64 %t626, %t628
  %t630 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t629)
  call void @olang_textcopy(ptr %t630, ptr %t621, i64 %t622)
  %t631 = getelementptr i8, ptr %t630, i64 %t622
  %t632 = call i64 @__olang_fmt_i64(ptr %t631, i64 %t624)
  %t633 = getelementptr i8, ptr %t631, i64 %t625
  call void @olang_textcopy(ptr %t633, ptr %t627, i64 %t628)
  %t634 = insertvalue { i64, ptr } undef, i64 %t629, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t630, 1
  %t637 = extractvalue { i64, ptr } %t635, 0
  %t638 = extractvalue { i64, ptr } %t635, 1
  %t639 = mul i64 %t637, 1
  %t640 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t639)
  call void @llvm.memcpy.p0.p0.i64(ptr %t640, ptr %t638, i64 %t639, i1 false)
  %t641 = insertvalue { i64, ptr } undef, i64 %t637, 0
  %t642 = insertvalue { i64, ptr } %t641, ptr %t640, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s28, ptr %t619, { i64, ptr } %t642)
  br label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_scope_close(ptr %s28)
  br label %bb125
bb125:
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t647 = getelementptr %"compiler/mir:verifier", ptr %t645, i32 0, i32 16
  %t648 = load { i64, ptr }, ptr %t647, !tbaa !27
  store { i64, ptr } %t648, ptr %l289, !tbaa !27
  %t649 = load i32, ptr %l37, !tbaa !23
  %t651 = sext i32 %t649 to i64
  %t653 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t654 = load ptr, ptr %t653, !tbaa !27
  %t655 = getelementptr i1, ptr %t654, i64 %t651
  store i1 false, ptr %t655, !tbaa !31
  %t656 = load i32, ptr %l40, !tbaa !23
  %t657 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t660 = icmp ne i32 %t656, %t657
  br i1 %t660, label %bb126, label %bb127
bb126:
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t664 = getelementptr %"compiler/mir:verifier", ptr %t662, i32 0, i32 14
  %t665 = load { i64, ptr }, ptr %t664, !tbaa !27
  store { i64, ptr } %t665, ptr %l296, !tbaa !27
  %t666 = load i32, ptr %l39, !tbaa !23
  %t668 = sext i32 %t666 to i64
  %t670 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t671 = load ptr, ptr %t670, !tbaa !27
  %t672 = getelementptr i1, ptr %t671, i64 %t668
  %t673 = load i1, ptr %t672, !tbaa !31
  store i1 %t673, ptr %l41, !tbaa !21
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t677 = getelementptr %"compiler/mir:verifier", ptr %t675, i32 0, i32 14
  %t678 = load { i64, ptr }, ptr %t677, !tbaa !27
  store { i64, ptr } %t678, ptr %l301, !tbaa !27
  %t679 = load i32, ptr %l39, !tbaa !23
  %t681 = sext i32 %t679 to i64
  %t683 = getelementptr { i64, ptr }, ptr %l301, i32 0, i32 1
  %t684 = load ptr, ptr %t683, !tbaa !27
  %t685 = getelementptr i1, ptr %t684, i64 %t681
  store i1 true, ptr %t685, !tbaa !31
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load i32, ptr %l40, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t686, i32 %t687)
  br label %bb128
bb127:
  br label %bb129
bb128:
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t692 = getelementptr %"compiler/mir:verifier", ptr %t690, i32 0, i32 14
  %t693 = load { i64, ptr }, ptr %t692, !tbaa !27
  store { i64, ptr } %t693, ptr %l307, !tbaa !27
  %t694 = load i32, ptr %l39, !tbaa !23
  %t696 = sext i32 %t694 to i64
  %t697 = load i1, ptr %l41, !tbaa !21
  %t700 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t701 = load ptr, ptr %t700, !tbaa !27
  %t702 = getelementptr i1, ptr %t701, i64 %t696
  store i1 %t697, ptr %t702, !tbaa !31
  br label %bb129
bb129:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load i32, ptr %l38, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eenter(ptr %v0, ptr %t703, i32 %t704)
  br label %bb130
bb130:
  br label %bb136
bb131:
  br i1 true, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb136
bb135:
  call void @__olang_check_failed(ptr @olang_loc_d66c95c574566df8_862c2f5cde7f4614)
  unreachable
bb136:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l9 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l9
  br label %bb4
bb4:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t23 = sext i32 %t19 to i64
  %t24 = call i64 @__olang_fmt_i64(ptr null, i64 %t23)
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t23)
  %t32 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t32, ptr %t26, i64 %t27)
  %t33 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t29, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t18, { i64, ptr } %t41)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  br label %bb19
bb9:
  %t44 = load { i64, [1 x i64] }, ptr %l1
  %t46 = extractvalue { i64, [1 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 4
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t50 = getelementptr { i32 }, ptr %t49, i32 0, i32 0
  %t51 = load i32, ptr %t50
  store i32 %t51, ptr %l3, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t53, i32 %t54)
  br label %bb13
bb13:
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_587900af1cc61a9a_48225b2d2b7d46c6)
  unreachable
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t1, i32 %t2, i32 %t3)
  store i1 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l9, !tbaa !29
  store { i64, ptr } %a3, ptr %l10, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t13, i32 %t14)
  store { i64, ptr } %t17, ptr %l13
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l16
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t24, i64 %t25)
  %t44 = getelementptr i8, ptr %t43, i64 %t25
  call void @olang_textcopy(ptr %t44, ptr %t26, i64 %t27)
  %t45 = getelementptr i8, ptr %t44, i64 %t27
  call void @olang_textcopy(ptr %t45, ptr %t30, i64 %t31)
  %t46 = getelementptr i8, ptr %t45, i64 %t31
  call void @olang_textcopy(ptr %t46, ptr %t33, i64 %t34)
  %t47 = getelementptr i8, ptr %t46, i64 %t34
  call void @olang_textcopy(ptr %t47, ptr %t37, i64 %t38)
  %t48 = getelementptr i8, ptr %t47, i64 %t38
  call void @olang_textcopy(ptr %t48, ptr %t40, i64 %t41)
  %t49 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t43, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t58 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t58, { i64, ptr } %t57)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eexpect(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v1, ptr %v0, ptr %s0, ptr %a1, ptr %a0)
  store { i64, ptr } %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %v2, { i64, ptr } %t7, { i64, ptr } %t8)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l12
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l11
  br label %bb2
bb2:
  %t16 = load i64, ptr %l11, !tbaa !24
  store i64 %t16, ptr %l8, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t20 = icmp sge i64 %t17, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t24 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t27 = extractvalue { i64, ptr } %t22, 1
  %t28 = extractvalue { i64, ptr } %t22, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t34 = extractvalue { i64, ptr } %t23, 1
  %t35 = extractvalue { i64, ptr } %t23, 0
  %t36 = add i64 %t32, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t24, i64 %t25)
  %t38 = getelementptr i8, ptr %t37, i64 %t25
  call void @olang_textcopy(ptr %t38, ptr %t27, i64 %t28)
  %t39 = getelementptr i8, ptr %t38, i64 %t28
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t40, ptr %t34, i64 %t35)
  %t41 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t37, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = extractvalue { i64, ptr } %t49, 0
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  call void @__olang_check_failed_text(ptr @olang_loc_2787a88b0b468961_ce97027662ecd8ed, { i64, ptr } %t54)
  unreachable
ret:
  ret void
}

define dso_local %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7) #0 {
entry:
  %rv = alloca %"compiler/mir:Call"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/mir:Call" undef, { i64, [7 x i64] } %a0, 0
  %t20 = insertvalue %"compiler/mir:Call" %t18, %"compiler/mir:Range" %a1, 1
  %t22 = insertvalue %"compiler/mir:Call" %t20, %"compiler/mir:Range" %a2, 2
  %t24 = insertvalue %"compiler/mir:Call" %t22, %"compiler/mir:Lvalue" %a3, 3
  %t26 = insertvalue %"compiler/mir:Call" %t24, i1 %a4, 4
  %t28 = insertvalue %"compiler/mir:Call" %t26, i32 %a5, 5
  %t30 = insertvalue %"compiler/mir:Call" %t28, i32 %a6, 6
  %t32 = insertvalue %"compiler/mir:Call" %t30, i32 %a7, 7
  store %"compiler/mir:Call" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Call", ptr %rv
  ret %"compiler/mir:Call" %rr
}

define dso_local %"compiler/mir:Case" @compiler_2fmir_3aCase_2ector(ptr %v0, i64 %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/mir:Case"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/mir:Case" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/mir:Case" %t6, i32 %a1, 1
  store %"compiler/mir:Case" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Case", ptr %rv
  ret %"compiler/mir:Case" %rr
}

define dso_local void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca %"compiler/mir:Fn"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } %a0, ptr %l4
  store i32 %a1, ptr %l5, !tbaa !23
  store i64 %a2, ptr %l6, !tbaa !24
  store %"compiler/source:Span" %a3, ptr %l7
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l37
  br label %bb1
bb1:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l8
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l38
  br label %bb2
bb2:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l9
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l39
  br label %bb3
bb3:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l10
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l40
  br label %bb4
bb4:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l11
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l41
  br label %bb5
bb5:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l12
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l42
  br label %bb6
bb6:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l13
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l43
  br label %bb7
bb7:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l14
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l44
  br label %bb8
bb8:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l15
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l45
  br label %bb9
bb9:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l16
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l46
  br label %bb10
bb10:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l17
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l47
  br label %bb11
bb11:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l18
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l48
  br label %bb12
bb12:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l19
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l49
  br label %bb13
bb13:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l20
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l50
  br label %bb14
bb14:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l21
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l51
  br label %bb15
bb15:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l22
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l52
  br label %bb16
bb16:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l23
  %t41 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l53
  br label %bb17
bb17:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l24
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l54
  br label %bb18
bb18:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l25
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l55
  br label %bb19
bb19:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l26
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l56
  br label %bb20
bb20:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l27
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l57
  br label %bb21
bb21:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l28
  store i1 false, ptr %l29, !tbaa !21
  store i64 0, ptr %l30, !tbaa !24
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l58
  br label %bb22
bb22:
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l31
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l59
  br label %bb23
bb23:
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  %t55 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 0
  %t56 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t56, ptr %t55
  %t57 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 1
  %t58 = load i32, ptr %l5, !tbaa !23
  store i32 %t58, ptr %t57, !tbaa !23
  %t59 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 2
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %t59, !tbaa !24
  %t61 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 3
  %t62 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t62, ptr %t61
  %t63 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 4
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %t63
  %t65 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 5
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %t65
  %t67 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 6
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %t67
  %t69 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 7
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t69
  %t71 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 8
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %t71
  %t73 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 9
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %t73
  %t75 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 10
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %t75
  %t77 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 11
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %t77
  %t79 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 12
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %t79
  %t81 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 13
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %t81
  %t83 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 14
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %t83
  %t85 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 15
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %t85
  %t87 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 16
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %t87
  %t89 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 17
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %t89
  %t91 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 18
  %t92 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %t91
  %t93 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 19
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %t93
  %t95 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 20
  %t96 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %t95
  %t97 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 21
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %t97
  %t99 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 22
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %t99
  %t101 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 23
  %t102 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %t101
  %t103 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 24
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %t103
  %t105 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 25
  %t106 = load i1, ptr %l29, !tbaa !21
  store i1 %t106, ptr %t105, !tbaa !21
  %t107 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 26
  %t108 = load i64, ptr %l30, !tbaa !24
  store i64 %t108, ptr %t107, !tbaa !24
  %t109 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 27
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %t109
  %t111 = getelementptr %"compiler/mir:Fn", ptr %l60, i32 0, i32 28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %t111
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l60, i64 800, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:ScopeInfo" @compiler_2fmir_3aScopeInfo_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4) #0 {
entry:
  %rv = alloca %"compiler/mir:ScopeInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/mir:ScopeInfo" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/mir:ScopeInfo" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/mir:ScopeInfo" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/mir:ScopeInfo" %t16, %"compiler/source:Span" %a3, 3
  %t20 = insertvalue %"compiler/mir:ScopeInfo" %t18, i32 %a4, 4
  store %"compiler/mir:ScopeInfo" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:ScopeInfo", ptr %rv
  ret %"compiler/mir:ScopeInfo" %rr
}

define dso_local %"compiler/mir:TaskClause" @compiler_2fmir_3aTaskClause_2ector(ptr %v0, %"compiler/mir:Range" %a0, i1 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %rv = alloca %"compiler/mir:TaskClause"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/mir:TaskClause" undef, %"compiler/mir:Range" %a0, 0
  %t10 = insertvalue %"compiler/mir:TaskClause" %t8, i1 %a1, 1
  %t12 = insertvalue %"compiler/mir:TaskClause" %t10, { i64, [4 x i64] } %a2, 2
  store %"compiler/mir:TaskClause" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:TaskClause", ptr %rv
  ret %"compiler/mir:TaskClause" %rr
}

define dso_local void @compiler_2fmir_3averifier_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"compiler/mir:verifier"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  %t5 = call %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t5, ptr %l23
  br label %bb1
bb1:
  %t6 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t6, ptr %l4
  store i64 -1, ptr %l5, !tbaa !24
  store i64 -1, ptr %l6, !tbaa !24
  store i1 true, ptr %l7, !tbaa !21
  %t7 = icmp sge i64 0, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = mul i64 0, 1
  %t10 = insertvalue { i64, ptr } undef, i64 0, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t11, ptr %l8, !tbaa !27
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_5380db3ec2a99a3_371ccfada9fdfeef)
  unreachable
bb4:
  %t15 = mul i64 0, 1
  %t16 = insertvalue { i64, ptr } undef, i64 0, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t17, ptr %l9, !tbaa !27
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5983d076d5883d2e_1665ff00cbce2e1a)
  unreachable
bb6:
  %t21 = mul i64 0, 1
  %t22 = insertvalue { i64, ptr } undef, i64 0, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t23, ptr %l10, !tbaa !27
  %t25 = icmp sge i64 0, 0
  br i1 %t25, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_910dd2c5a789172d_f03cfbb9736a8799)
  unreachable
bb8:
  %t27 = mul i64 0, 1
  %t28 = insertvalue { i64, ptr } undef, i64 0, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t29, ptr %l11, !tbaa !27
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2a1e3324a3ced000_b715b4216485c88c)
  unreachable
bb10:
  %t33 = icmp sle i64 0, 1152921504606846975
  br i1 %t33, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_424aba850193e62f_5d41a9f8bd7e1e63)
  unreachable
bb12:
  %t35 = mul i64 0, 8
  %t36 = insertvalue { i64, ptr } undef, i64 0, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t37, ptr %l12, !tbaa !27
  %t39 = icmp sge i64 0, 0
  br i1 %t39, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_424aba850193e62f_5d41a9f8bd7e1e63)
  unreachable
bb14:
  %t41 = icmp sle i64 0, 1152921504606846975
  br i1 %t41, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_26e15834dfadce5a_40849b88d9a51eee)
  unreachable
bb16:
  %t43 = mul i64 0, 8
  %t44 = insertvalue { i64, ptr } undef, i64 0, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t45, ptr %l13, !tbaa !27
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l38
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_26e15834dfadce5a_40849b88d9a51eee)
  unreachable
bb18:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l14
  %t49 = icmp sge i64 0, 0
  br i1 %t49, label %bb19, label %bb20
bb19:
  %t51 = mul i64 0, 1
  %t52 = insertvalue { i64, ptr } undef, i64 0, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t53, ptr %l15, !tbaa !27
  %t55 = icmp sge i64 0, 0
  br i1 %t55, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_390ccbe637d1d3d9_30a6ef9f1a3ec7ed)
  unreachable
bb21:
  %t57 = mul i64 0, 1
  %t58 = insertvalue { i64, ptr } undef, i64 0, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t59, ptr %l16, !tbaa !27
  %t61 = icmp sge i64 0, 0
  br i1 %t61, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_1f26baa5abf820cc_81869963bb6d62c0)
  unreachable
bb23:
  %t63 = mul i64 0, 1
  %t64 = insertvalue { i64, ptr } undef, i64 0, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t65, ptr %l17, !tbaa !27
  %t67 = icmp sge i64 0, 0
  br i1 %t67, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_200617782b41aa6b_62fe98f9543f67b7)
  unreachable
bb25:
  %t69 = mul i64 0, 1
  %t70 = insertvalue { i64, ptr } undef, i64 0, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t71, ptr %l18, !tbaa !27
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l47
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_d8b0f1b6ba5e5556_5a69466de52f9302)
  unreachable
bb27:
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  %t75 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 0
  %t76 = load ptr, ptr %l2, !tbaa !29
  store ptr %t76, ptr %t75, !tbaa !29
  %t77 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 1
  %t78 = load ptr, ptr %l3, !tbaa !29
  store ptr %t78, ptr %t77, !tbaa !29
  %t79 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 2
  %t80 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t80, ptr %t79
  %t81 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 3
  %t82 = load i64, ptr %l5, !tbaa !24
  store i64 %t82, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 4
  %t84 = load i64, ptr %l6, !tbaa !24
  store i64 %t84, ptr %t83, !tbaa !24
  %t85 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 5
  %t86 = load i1, ptr %l7, !tbaa !21
  store i1 %t86, ptr %t85, !tbaa !21
  %t87 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 6
  %t88 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t88, ptr %t87, !tbaa !27
  %t89 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 7
  %t90 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t90, ptr %t89, !tbaa !27
  %t91 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 8
  %t92 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t92, ptr %t91, !tbaa !27
  %t93 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 9
  %t94 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t94, ptr %t93, !tbaa !27
  %t95 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 10
  %t96 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t96, ptr %t95, !tbaa !27
  %t97 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 11
  %t98 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t98, ptr %t97, !tbaa !27
  %t99 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 12
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %t99
  %t101 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 13
  %t102 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t102, ptr %t101, !tbaa !27
  %t103 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 14
  %t104 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t104, ptr %t103, !tbaa !27
  %t105 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 15
  %t106 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t106, ptr %t105, !tbaa !27
  %t107 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 16
  %t108 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t108, ptr %t107, !tbaa !27
  %t109 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %t109
  %t111 = getelementptr %"compiler/mir:verifier", ptr %l48, i32 0, i32 18
  store i1 false, ptr %t111, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l48, i64 304, i1 false)
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aborted" }>, align 8
@.d2 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"unreachable reached" }>, align 8
@.d3 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"null reached" }>, align 8
@.d4 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"raised a null error" }>, align 8
@.d5 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"assertion failed" }>, align 8
@.d6 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"slice bounds out of range" }>, align 8
@.d7 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"array length out of range" }>, align 8
@.d8 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"'as' named what the value is not" }>, align 8
@.d9 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"array length does not match its fixed storage" }>, align 8
@.d10 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"lane lengths differ" }>, align 8
@.d11 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c"a generator asked for its next value inside its own walk" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"b" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d16 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"assert B" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d19 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"global " }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d21 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"literal B" }>, align 8
@.d22 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d23 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"zero T" }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d25 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"V" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d30 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"vars " }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aLocalKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 4}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d37 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" in S" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" block " }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" fails " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aScopeKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 7}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
ret:
  ret void
}

@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d46 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"bb" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d48 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" bb" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"B" }>, align 8
@.d54 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"adapter B" }>, align 8
@.d55 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"copied B" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 8}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
ret:
  ret void
}

@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d57 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"init " }>, align 8
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" top" }>, align 8
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d60 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"any render table " }>, align 8
@.d61 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@.d62 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"copy " }>, align 8
@.d63 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"const " }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d65 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"data " }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d67 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"G" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d74 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[L" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d76 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d78 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".*" }>, align 8
@.d79 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" as " }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d81 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"V" }>, align 8
@.d82 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"program" }>, align 8
@.d83 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"frame" }>, align 8
@.d84 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"held(L" }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d86 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ref " }>, align 8
@.d87 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d88 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"take " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 49}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 i64 39, label %bb41 i64 40, label %bb42 i64 41, label %bb43 i64 42, label %bb44 i64 43, label %bb45 i64 44, label %bb46 i64 45, label %bb47 i64 46, label %bb48 i64 47, label %bb49 i64 48, label %bb50 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d317, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d317, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d318, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d318, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d320, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d320, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d321, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d321, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
bb41:
  %t83 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t83, i64 %t84)
  br label %bb1
bb42:
  %t85 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t85, i64 %t86)
  br label %bb1
bb43:
  %t87 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t87, i64 %t88)
  br label %bb1
bb44:
  %t89 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t89, i64 %t90)
  br label %bb1
bb45:
  %t91 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d326, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d326, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t91, i64 %t92)
  br label %bb1
bb46:
  %t93 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t93, i64 %t94)
  br label %bb1
bb47:
  %t95 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t95, i64 %t96)
  br label %bb1
bb48:
  %t97 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t97, i64 %t98)
  br label %bb1
bb49:
  %t99 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t99, i64 %t100)
  br label %bb1
bb50:
  %t101 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t101, i64 %t102)
  br label %bb1
ret:
  ret void
}

@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d92 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"overflows " }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d94 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d95 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d96 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"tag " }>, align 8
@.d97 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" #" }>, align 8
@.d98 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d99 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"make " }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d101 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d102 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"new in " }>, align 8
@.d103 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d104 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d105 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"newarray in " }>, align 8
@.d106 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d108 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d109 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d110 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"slice " }>, align 8
@.d111 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d112 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" : " }>, align 8
@.d113 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"]: " }>, align 8
@.d114 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d115 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" captures " }>, align 8
@.d116 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"closure " }>, align 8
@.d117 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d120 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d121 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"recode " }>, align 8
@.d122 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" from " }>, align 8
@.d123 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d124 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"text " }>, align 8
@.d125 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d126 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d127 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"region in " }>, align 8
@.d128 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"region of " }>, align 8
@.d129 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" or " }>, align 8
@.d130 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"payload push" }>, align 8
@.d131 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"payload top: " }>, align 8
@.d132 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d133 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d134 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d136 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d137 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d138 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d139 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" copies [" }>, align 8
@.d140 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d141 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" catch" }>, align 8
@.d142 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" all" }>, align 8
@.d143 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d145 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d146 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" -> " }>, align 8
@.d147 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"param " }>, align 8
@.d148 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"capture " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aVarKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 6}
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d332, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d332, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 1
  %t10 = getelementptr { i64 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  %t13 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t14 = call i64 @__olang_fmt_i64(ptr %t13, i64 %t11)
  call void @__olang_sb_add(ptr %v0, i64 %t14)
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb3:
  %t17 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb4:
  %t19 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d336, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d336, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb5:
  %t21 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d337, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d337, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb6:
  %t23 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr { i64, [1 x i64] }, ptr %t27, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  %t32 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t33 = call i64 @__olang_fmt_i64(ptr %t32, i64 %t30)
  call void @__olang_sb_add(ptr %v0, i64 %t33)
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t34, i64 %t35)
  br label %bb1
bb7:
  %t36 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t36, i64 %t37)
  br label %bb1
ret:
  ret void
}

@.d149 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"built in S" }>, align 8
@.d150 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c", which is not open" }>, align 8
@.d151 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"built in S" }>, align 8
@.d152 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", which is inert" }>, align 8
@.d153 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"a dispatch through a " }>, align 8
@.d154 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a call of a " }>, align 8
@.d155 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", not a function" }>, align 8
@.d156 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a switch with the value " }>, align 8
@.d157 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" twice" }>, align 8
@.d158 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"enters bb" }>, align 8
@.d159 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" with scopes " }>, align 8
@.d160 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", where another path has " }>, align 8
@.d161 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" is a " }>, align 8
@.d162 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", not a " }>, align 8
@.d163 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"operands" }>, align 8
@.d164 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d165 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d166 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" parts made of " }>, align 8
@.d167 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"part " }>, align 8
@.d168 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" is a check: a test and a branch in MIR" }>, align 8
@.d169 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d170 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" operands" }>, align 8
@.d171 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d172 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d173 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d174 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d175 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d176 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Not of a " }>, align 8
@.d177 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d178 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" and a " }>, align 8
@.d179 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d180 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d181 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Same of a " }>, align 8
@.d182 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" and a " }>, align 8
@.d183 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Same typed " }>, align 8
@.d184 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Len of a " }>, align 8
@.d185 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Len typed " }>, align 8
@.d186 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d187 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d188 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ByteSwap of a " }>, align 8
@.d189 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d190 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d191 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d192 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"Retire of a " }>, align 8
@.d193 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"Retire typed " }>, align 8
@.d194 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"IsCase of a " }>, align 8
@.d195 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"IsCase typed " }>, align 8
@.d196 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"AnyMake of a " }>, align 8
@.d197 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"AnyMake typed " }>, align 8
@.d198 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"AnyMake's table not an I64" }>, align 8
@.d199 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"AnyInstance of a " }>, align 8
@.d200 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"AnyInstance typed " }>, align 8
@.d201 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"AnyIs of a " }>, align 8
@.d202 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"AnyIs typed " }>, align 8
@.d203 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d204 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"'s field not an I64" }>, align 8
@.d205 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"Repack typed " }>, align 8
@.d206 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d207 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c", not a writable reference to an integer" }>, align 8
@.d208 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"'s operand " }>, align 8
@.d209 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"AtomicStore typed " }>, align 8
@.d210 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d211 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"no field " }>, align 8
@.d212 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" in a " }>, align 8
@.d213 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"an index L" }>, align 8
@.d214 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" is a " }>, align 8
@.d215 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"an index into a " }>, align 8
@.d216 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", not an array" }>, align 8
@.d217 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"an index into a " }>, align 8
@.d218 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", not an array" }>, align 8
@.d219 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"constant index " }>, align 8
@.d220 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" outside a " }>, align 8
@.d221 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a deref of a " }>, align 8
@.d222 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c", not a reference" }>, align 8
@.d223 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no case " }>, align 8
@.d224 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" in a " }>, align 8
@.d225 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"case " }>, align 8
@.d226 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d227 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" has no payload" }>, align 8
@.d228 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"scopes" }>, align 8
@.d229 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"no scope S" }>, align 8
@.d230 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"a slice " }>, align 8
@.d231 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d232 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"a slice's bound that is no integer" }>, align 8
@.d233 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d234 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" opened while it is open" }>, align 8
@.d235 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d236 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" opened in " }>, align 8
@.d237 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", not in its parent " }>, align 8
@.d238 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"closed" }>, align 8
@.d239 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"join S" }>, align 8
@.d240 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" closed with tasks not waited for" }>, align 8
@.d241 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a spawn into S" }>, align 8
@.d242 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c", which is not open" }>, align 8
@.d243 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"deferred code registered at S" }>, align 8
@.d244 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c", which is not open" }>, align 8
@.d245 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d246 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c" stored into with no storage: its Live not reached" }>, align 8
@.d247 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"the case of a " }>, align 8
@.d248 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", not an enum" }>, align 8
@.d249 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d250 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c" given an error code with no storage" }>, align 8
@.d251 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"jumps out of the function with " }>, align 8
@.d252 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" open" }>, align 8
@.d253 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"leaves the function with " }>, align 8
@.d254 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" open" }>, align 8
@.d255 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a wait for S" }>, align 8
@.d256 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c", which is not open" }>, align 8
@.d257 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d258 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" used where it is not open" }>, align 8
@.d259 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" is a " }>, align 8
@.d260 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", where a " }>, align 8
@.d261 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" is wanted" }>, align 8
@.d262 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"wanted '" }>, align 8
@.d263 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"' among:\0A" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr }) cold noreturn
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

@__olang_empty_array = external constant [16 x i64]
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d264 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.LocalKind.Param" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d265 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"mir.LocalKind.Capture" }>, align 8
@.d266 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"mir.LocalKind.Var" }>, align 8
@.d267 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.LocalKind.Temp" }>, align 8
@.d268 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.ScopeKind.Frame" }>, align 8
@.d269 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.ScopeKind.Block" }>, align 8
@.d270 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.ScopeKind.Loop" }>, align 8
@.d271 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.ScopeKind.Join" }>, align 8
@.d272 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.ScopeKind.Region" }>, align 8
@.d273 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.ScopeKind.Inert" }>, align 8
@.d274 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"mir.ScopeKind.Builder" }>, align 8
@.d275 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"mir.HelperKind.Render" }>, align 8
@.d276 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Equal" }>, align 8
@.d277 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Hash" }>, align 8
@.d278 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Zero" }>, align 8
@.d279 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Copy" }>, align 8
@.d280 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Parts" }>, align 8
@.d281 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Drop" }>, align 8
@.d282 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Guard" }>, align 8
@.d283 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Neg" }>, align 8
@.d284 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitNot" }>, align 8
@.d285 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Not" }>, align 8
@.d286 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Add" }>, align 8
@.d287 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Sub" }>, align 8
@.d288 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Mul" }>, align 8
@.d289 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Div" }>, align 8
@.d290 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Rem" }>, align 8
@.d291 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Shl" }>, align 8
@.d292 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Shr" }>, align 8
@.d293 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitAnd" }>, align 8
@.d294 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.PrimOp.BitOr" }>, align 8
@.d295 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitXor" }>, align 8
@.d296 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Eq" }>, align 8
@.d297 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Ne" }>, align 8
@.d298 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Lt" }>, align 8
@.d299 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Le" }>, align 8
@.d300 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Gt" }>, align 8
@.d301 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Ge" }>, align 8
@.d302 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.PrimOp.Same" }>, align 8
@.d303 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.Convert" }>, align 8
@.d304 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.Bitcast" }>, align 8
@.d305 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Len" }>, align 8
@.d306 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.IsCase" }>, align 8
@.d307 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.AtomicLoad" }>, align 8
@.d308 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.AtomicStore" }>, align 8
@.d309 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"typed.PrimOp.AtomicAdd" }>, align 8
@.d310 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.AtomicSwap" }>, align 8
@.d311 = private unnamed_addr constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"typed.PrimOp.AtomicCompareSwap" }>, align 8
@.d312 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Retire" }>, align 8
@.d313 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.Destroy" }>, align 8
@.d314 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.PrimOp.Drop" }>, align 8
@.d315 = private unnamed_addr constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"typed.PrimOp.LeadingZeros" }>, align 8
@.d316 = private unnamed_addr constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"typed.PrimOp.TrailingZeros" }>, align 8
@.d317 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.PopCount" }>, align 8
@.d318 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.RotateLeft" }>, align 8
@.d319 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.RotateRight" }>, align 8
@.d320 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.ByteSwap" }>, align 8
@.d321 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.PrimOp.Holds" }>, align 8
@.d322 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.LaneLen" }>, align 8
@.d323 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.NonEmpty" }>, align 8
@.d324 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Unpack" }>, align 8
@.d325 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Repack" }>, align 8
@.d326 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.AnyMake" }>, align 8
@.d327 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.AnyInstance" }>, align 8
@.d328 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.PrimOp.AnyIs" }>, align 8
@.d329 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.ErrPush" }>, align 8
@.d330 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"typed.PrimOp.ErrCaught" }>, align 8
@.d331 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.ErrTaken" }>, align 8
@.d332 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"mir.VarKind.Param" }>, align 8
@.d333 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d334 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d335 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.VarKind.Result" }>, align 8
@.d336 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.VarKind.Instance" }>, align 8
@.d337 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.VarKind.Closing" }>, align 8
@.d338 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.VarKind.Capture" }>, align 8
@.d339 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.VarKind.Builder" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@olang_loc_84efd3c782aef4d6_8c92393edf5749f2 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
declare void @compiler_2fmir_2eFn_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eSetAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Local" %a2)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %v0, { i64, [2 x i64] } %a0, %"compiler/mir:Range" %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_419ac27aa82c7b2c_45256e944a6f3408 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2ePush_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, %"compiler/mir:Case" %a1)
declare %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %v0, i32 %a0, i32 %a1)
@olang_loc_f17cf97eff0353b6_fea489b4a6f80ab2 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2ePush_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2ePush_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eLen_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2ePush_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eLen_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2ePush_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, %"compiler/mir:TaskClause" %a1)
declare %"compiler/mir:Task" @compiler_2fmir_3aTask_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4, %"compiler/mir:Range" %a5, %"compiler/source:Span" %a6, %"compiler/mir:Range" %a7)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2ePush_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, %"compiler/mir:Task" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:dumper" @compiler_2fmir_3adumper_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ePush_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fmir_2ewritesInto(ptr %v0, ptr %a0, { i64, [21 x i64] } %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_5b04576c3a0c01b1_2f8c01babecc81b5 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_14ebfa33b1d03356_270fe526a4636ad2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmir_2eshort(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eterm(ptr %v0, ptr %v1, ptr %a0, { i64, [8 x i64] } %a1)
declare %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_792180efaebdc40a_e488d776d0fba16e = external constant [0 x i8]
@olang_loc_4b3ff56260a2bca0_3dcb0434d488ed4c = external constant [0 x i8]
@olang_loc_2f605f8b851f9dfa_b0e742a1ba211956 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ddfec86899b5c27b_91be796056af7d77 = external constant [0 x i8]
@olang_loc_3c759898227385e0_43502750c3b6307c = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
@olang_loc_55b2be13c853614c_e5b496909f3a0f10 = external constant [0 x i8]
declare %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %v1, ptr %a0, { i64, [7 x i64] } %a1)
declare %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6326b544498e75fa_e53a2c99f88826ee = external constant [0 x i8]
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a15aa4830130cc38_9fcdb454ad4b970c = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
@olang_loc_43daeee16a7347fc_3936ff71893c42a0 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
@olang_loc_690174ade0b6e824_1aa5c898f3f73ab8 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b20acbf668615715_202a9ab5dba06089 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eSpread = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3fc64ab4d22c7cd1_9c9bbb4060ef765d = external constant [0 x i8]
@olang_loc_82a5970c46c34ec4_64144421b638a2b0 = external constant [0 x i8]
@olang_loc_2ac31f2db6082ba7_5ac69b59325af853 = external constant [0 x i8]
@olang_loc_397ae699ba890fb2_f6680c8259f4281e = external constant [0 x i8]
@olang_loc_2836fb8ea59de3a5_79eeb5d0a68fc1c9 = external constant [0 x i8]
@olang_loc_13b0920ad4a1e938_72d556b41507b57c = external constant [0 x i8]
@olang_loc_f0f79482ff998b1b_575016ccefde52df = external constant [0 x i8]
@olang_loc_a4c79ab2e91ac186_f4797f1baf8f450a = external constant [0 x i8]
@olang_loc_2c486f9205676389_1881cd4b4e7e41e5 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_d0c28dbd82f4c36a_9dd446291f7ee706 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %a0, i32 %a1, %"compiler/mir:Range" %a2, i32 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7968c2a45e42402b_522993cc8bbef1e7 = external constant [0 x i8]
declare i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5e1988e97d308376_f66bcffef950dfda = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_d06e38c3720099d6_401a7f863dec038a = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueFlow(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_30c75e8686103aec_2a803509807dc2e8 = external constant [0 x i8]
@olang_loc_8c773ec7d9409528_6b556770aed18854 = external constant [0 x i8]
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d66c95c574566df8_862c2f5cde7f4614 = external constant [0 x i8]
@olang_loc_587900af1cc61a9a_48225b2d2b7d46c6 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2787a88b0b468961_ce97027662ecd8ed = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_5380db3ec2a99a3_371ccfada9fdfeef = external constant [0 x i8]
@olang_loc_5983d076d5883d2e_1665ff00cbce2e1a = external constant [0 x i8]
@olang_loc_910dd2c5a789172d_f03cfbb9736a8799 = external constant [0 x i8]
@olang_loc_2a1e3324a3ced000_b715b4216485c88c = external constant [0 x i8]
@olang_loc_424aba850193e62f_5d41a9f8bd7e1e63 = external constant [0 x i8]
@olang_loc_26e15834dfadce5a_40849b88d9a51eee = external constant [0 x i8]
@olang_loc_390ccbe637d1d3d9_30a6ef9f1a3ec7ed = external constant [0 x i8]
@olang_loc_1f26baa5abf820cc_81869963bb6d62c0 = external constant [0 x i8]
@olang_loc_200617782b41aa6b_62fe98f9543f67b7 = external constant [0 x i8]
@olang_loc_d8b0f1b6ba5e5556_5a69466de52f9302 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
