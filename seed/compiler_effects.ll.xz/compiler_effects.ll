; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64 }
%"compiler/effects:Effects" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/effects:Facts", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/effects:root" = type { i64, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/effects:link" = type { i64, i64, i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/effects:pair" = type { i64, i64 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
@G_2ecompiler_2feffects_2eCapC = constant <{ [8 x i8] }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eCapCount = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eCapEnvironment = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eCapFiles = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eCapNetwork = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eCapProcesses = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eCapThreads = constant <{ [8 x i8] }> <{ [8 x i8] c"\20\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eenvNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eenvNames.k1, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eenvNames.k2, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eenvNames.k3, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eenvNames.k4, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eenvNames.k5 }>, align 64
@G_2ecompiler_2feffects_2eenvNames.k1 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\67\65\74\65\6E\76" }>, align 8
@G_2ecompiler_2feffects_2eenvNames.k2 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\65\74\65\6E\76" }>, align 8
@G_2ecompiler_2feffects_2eenvNames.k3 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\75\6E\73\65\74\65\6E\76" }>, align 8
@G_2ecompiler_2feffects_2eenvNames.k4 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\70\75\74\65\6E\76" }>, align 8
@G_2ecompiler_2feffects_2eenvNames.k5 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\5F\5F\6F\6C\61\6E\67\5F\65\6E\76" }>, align 8
@G_2ecompiler_2feffects_2efileNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k1, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k2, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k3, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k4, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k5, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k6, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k7, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k8, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k9, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k10, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k11, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k12, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k13, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k14, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k15, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k16, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k17, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k18, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k19, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k20, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k21, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k22, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k23, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k24, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2efileNames.k25 }>, align 64
@G_2ecompiler_2feffects_2efileNames.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6F\70\65\6E" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k2 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6F\70\65\6E\61\74" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k3 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\63\72\65\61\74" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k4 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\6F\70\65\6E" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k5 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6D\6B\64\69\72" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k6 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\72\6D\64\69\72" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k7 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\72\65\6D\6F\76\65" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k8 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\75\6E\6C\69\6E\6B" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k9 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k10 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6C\69\6E\6B" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k11 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\79\6D\6C\69\6E\6B" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k12 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\72\65\61\64\6C\69\6E\6B" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k13 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\72\65\61\6C\70\61\74\68" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k14 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\6F\70\65\6E\64\69\72" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k15 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\63\68\64\69\72" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k16 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\67\65\74\63\77\64" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k17 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\74\72\75\6E\63\61\74\65" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k18 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\63\68\6D\6F\64" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k19 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\61\63\63\65\73\73" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k20 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\6D\6B\73\74\65\6D\70" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k21 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\6D\6B\64\74\65\6D\70" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k22 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\5F\5F\6F\6C\61\6E\67\5F\73\74\61\74" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k23 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\5F\5F\6F\6C\61\6E\67\5F\64\69\72" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k24 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\5F\5F\6F\6C\61\6E\67\5F\72\65\61\6C\70\61\74\68" }>, align 8
@G_2ecompiler_2feffects_2efileNames.k25 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\5F\5F\6F\6C\61\6E\67\5F\6D\6B\64\74\65\6D\70" }>, align 8
@G_2ecompiler_2feffects_2enetNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2enetNames.k1, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2enetNames.k2, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2enetNames.k3, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2enetNames.k4, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2enetNames.k5, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2enetNames.k6, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2enetNames.k7 }>, align 64
@G_2ecompiler_2feffects_2enetNames.k1 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\6F\63\6B\65\74" }>, align 8
@G_2ecompiler_2feffects_2enetNames.k2 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\63\6F\6E\6E\65\63\74" }>, align 8
@G_2ecompiler_2feffects_2enetNames.k3 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\62\69\6E\64" }>, align 8
@G_2ecompiler_2feffects_2enetNames.k4 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6C\69\73\74\65\6E" }>, align 8
@G_2ecompiler_2feffects_2enetNames.k5 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\61\63\63\65\70\74" }>, align 8
@G_2ecompiler_2feffects_2enetNames.k6 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\61\63\63\65\70\74\34" }>, align 8
@G_2ecompiler_2feffects_2enetNames.k7 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\67\65\74\61\64\64\72\69\6E\66\6F" }>, align 8
@G_2ecompiler_2feffects_2eprocNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k1, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k2, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k3, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k4, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k5, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k6, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k7, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k8, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k9, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k10, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k11, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2eprocNames.k12 }>, align 64
@G_2ecompiler_2feffects_2eprocNames.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\66\6F\72\6B" }>, align 8
@G_2ecompiler_2feffects_2eprocNames.k2 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\76\66\6F\72\6B" }>, align 8
@G_2ecompiler_2feffects_2eprocNames.k3 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\65\78\65\63\76" }>, align 8
@G_2ecompiler_2feffects_2eprocNames.k4 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\65\78\65\63\76\65" }>, align 8
@G_2ecompiler_2feffects_2eprocNames.k5 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\65\78\65\63\76\70" }>, align 8
@G_2ecompiler_2feffects_2eprocNames.k6 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\70\6F\73\69\78\5F\73\70\61\77\6E" }>, align 8
@G_2ecompiler_2feffects_2eprocNames.k7 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\70\6F\73\69\78\5F\73\70\61\77\6E\70" }>, align 8
@G_2ecompiler_2feffects_2eprocNames.k8 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\79\73\74\65\6D" }>, align 8
@G_2ecompiler_2feffects_2eprocNames.k9 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6B\69\6C\6C" }>, align 8
@G_2ecompiler_2feffects_2eprocNames.k10 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\77\61\69\74\70\69\64" }>, align 8
@G_2ecompiler_2feffects_2eprocNames.k11 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\5F\5F\6F\6C\61\6E\67\5F\73\70\61\77\6E" }>, align 8
@G_2ecompiler_2feffects_2eprocNames.k12 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\5F\5F\6F\6C\61\6E\67\5F\65\78\65\63" }>, align 8
@G_2ecompiler_2feffects_2equickNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k1, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k2, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k3, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k4, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k5, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k6, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k7, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k8, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k9, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k10, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k11, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k12, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k13, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k14, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k15, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k16, [8 x i8] c"\14\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k17, [8 x i8] c"\15\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k18, [8 x i8] c"\13\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k19, [8 x i8] c"\16\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k20, [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k21, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k22, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k23, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k24, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k25, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feffects_2equickNames.k26 }>, align 64
@G_2ecompiler_2feffects_2equickNames.k1 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\5F\5F\6F\6C\61\6E\67\5F\65\72\72" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k2 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\5F\5F\6F\6C\61\6E\67\5F\61\72\67\5F\63\6F\75\6E\74" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k3 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\5F\5F\6F\6C\61\6E\67\5F\61\72\67" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k4 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\5F\5F\6F\6C\61\6E\67\5F\65\6E\76" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k5 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6D\65\6D\63\70\79" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k6 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\6D\65\6D\6D\6F\76\65" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k7 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6D\65\6D\73\65\74" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k8 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6D\65\6D\63\6D\70" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k9 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\6C\65\6E" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k10 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\63\6D\70" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k11 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\74\72\6E\63\6D\70" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k12 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\63\6C\6F\63\6B\5F\67\65\74\74\69\6D\65" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k13 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\69\6D\65" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k14 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\67\65\74\65\6E\76" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k15 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\69\73\61\74\74\79" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k16 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\67\65\74\70\69\64" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k17 = internal constant <{ [20 x i8] }> <{ [20 x i8] c"\70\74\68\72\65\61\64\5F\6D\75\74\65\78\5F\75\6E\6C\6F\63\6B" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k18 = internal constant <{ [21 x i8] }> <{ [21 x i8] c"\70\74\68\72\65\61\64\5F\72\77\6C\6F\63\6B\5F\75\6E\6C\6F\63\6B" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k19 = internal constant <{ [19 x i8] }> <{ [19 x i8] c"\70\74\68\72\65\61\64\5F\63\6F\6E\64\5F\73\69\67\6E\61\6C" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k20 = internal constant <{ [22 x i8] }> <{ [22 x i8] c"\70\74\68\72\65\61\64\5F\63\6F\6E\64\5F\62\72\6F\61\64\63\61\73\74" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k21 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\70\74\68\72\65\61\64\5F\6D\75\74\65\78\5F\69\6E\69\74" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k22 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\70\74\68\72\65\61\64\5F\63\6F\6E\64\5F\69\6E\69\74" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k23 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\66\72\65\65\61\64\64\72\69\6E\66\6F" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k24 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\67\65\74\73\6F\63\6B\6E\61\6D\65" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k25 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\67\65\74\70\65\65\72\6E\61\6D\65" }>, align 8
@G_2ecompiler_2feffects_2equickNames.k26 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\73\65\74\73\6F\63\6B\6F\70\74" }>, align 8
define dso_local { i64, ptr } @compiler_2feffects_2eCapName(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t5, ptr %l1, !tbaa !27
  br label %bb25
bb4:
  %t7 = load i64, ptr %l0, !tbaa !24
  %t9 = icmp eq i64 %t7, 1
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l1, !tbaa !27
  br label %bb25
bb8:
  %t13 = load i64, ptr %l0, !tbaa !24
  %t15 = icmp eq i64 %t13, 2
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  br label %bb25
bb12:
  %t19 = load i64, ptr %l0, !tbaa !24
  %t21 = icmp eq i64 %t19, 3
  br i1 %t21, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l1, !tbaa !27
  br label %bb25
bb16:
  %t25 = load i64, ptr %l0, !tbaa !24
  %t27 = icmp eq i64 %t25, 4
  br i1 %t27, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t31, ptr %l1, !tbaa !27
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_290980515b4efda2_9d4c073daad962b6)
  unreachable
bb25:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l25, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t46, ptr %l1, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2feffects_2eCapText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l18 = alloca i64
  %l38 = alloca i64
  %l47 = alloca i1
  %l52 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2feffects_2eCapCount, !tbaa !24
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l15, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb26
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/effects:Facts", ptr %t51, i32 0, i32 13
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  store i64 %t55, ptr %l38, !tbaa !24
  %t56 = load i64, ptr %l38, !tbaa !24
  %t57 = load i64, ptr %l38, !tbaa !24
  %t58 = shl i64 1, %t57
  %t61 = and i64 %t54, %t58
  %t63 = icmp eq i64 %t61, 0
  br i1 %t63, label %bb12, label %bb13
bb12:
  br label %bb25
bb13:
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l8, !tbaa !24
  %t68 = getelementptr %"compiler/effects:Facts", ptr %t65, i32 0, i32 14
  %t70 = getelementptr [6 x i64], ptr %t68, i64 0, i64 %t66
  %t71 = load i64, ptr %t70, !tbaa !34
  store i64 %t71, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t83 = icmp slt i64 %t77, %t80
  store i1 %t83, ptr %l47, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb17
bb17:
  %t85 = load i1, ptr %l47, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l52, !tbaa !29
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = call { i64, ptr } @compiler_2feffects_2eCapName(ptr %s4, i64 %t86)
  store { i64, ptr } %t88, ptr %l54
  br label %bb20
bb19:
  store ptr %l2, ptr %l60, !tbaa !29
  %t89 = load i64, ptr %l8, !tbaa !24
  %t91 = call { i64, ptr } @compiler_2feffects_2eCapName(ptr %s0, i64 %t89)
  store { i64, ptr } %t91, ptr %l62
  br label %bb22
bb20:
  %t92 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t92, ptr %l55, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %t96, i64 %t93
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !37
  %t99 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t106 = extractvalue { i64, ptr } %t98, 1
  %t107 = extractvalue { i64, ptr } %t98, 0
  %t108 = add i64 %t104, %t107
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t100, i64 %t101)
  %t113 = getelementptr i8, ptr %t112, i64 %t101
  call void @olang_textcopy(ptr %t113, ptr %t102, i64 %t103)
  %t114 = getelementptr i8, ptr %t113, i64 %t103
  call void @olang_textcopy(ptr %t114, ptr %t106, i64 %t107)
  %t115 = getelementptr i8, ptr %t114, i64 %t107
  call void @olang_textcopy(ptr %t115, ptr %t109, i64 %t110)
  %t116 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t112, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = extractvalue { i64, ptr } %t117, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t125 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t125, { i64, ptr } %t124)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb22:
  %t127 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t134 = load ptr, ptr %l60, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t134, { i64, ptr } %t133)
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t136 = load i64, ptr %l7, !tbaa !24
  %t138 = add i64 %t136, 1
  store i64 %t138, ptr %l7, !tbaa !24
  br label %bb8
bb26:
  %t141 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %v2, ptr %v2, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store { i64, ptr } %t141, ptr %l67
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t142 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t142, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2feffects_2eConservative(i32 %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 6 to i32
  %t4 = icmp eq i32 %a0, %t3
  %t6 = xor i1 %t4, true
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2feffects_2eDescribe(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca i64
  %l42 = alloca i64
  %l63 = alloca i1
  %l65 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l101 = alloca i1
  %l111 = alloca ptr
  %l114 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l124 = alloca i1
  %l127 = alloca i1
  %l130 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l14, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l15, !tbaa !24
  %t9 = load i64, ptr %l15, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l16, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t20, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Facts", ptr %t22, i32 0, i32 9
  %t25 = load i1, ptr %t24, !tbaa !21
  br i1 %t25, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i64, ptr } @compiler_2feffects_2eendsNote(ptr %v0, ptr %s2, ptr %t27)
  store { i64, ptr } %t29, ptr %l20
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t30 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t32 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = add i64 %t31, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t30, i64 %t31)
  %t37 = getelementptr i8, ptr %t36, i64 %t31
  call void @olang_textcopy(ptr %t37, ptr %t33, i64 %t34)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eIdle(ptr %v0, ptr %t41)
  store i1 %t43, ptr %l23
  br label %bb8
bb8:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eEvaluable(ptr %v0, ptr %t45)
  store i1 %t47, ptr %l25
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2feffects_2eendsNote(ptr %v0, ptr %s5, ptr %t49)
  store { i64, ptr } %t51, ptr %l27
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t52 = extractvalue { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t54 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = add i64 %t53, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t52, i64 %t53)
  %t59 = getelementptr i8, ptr %t58, i64 %t53
  call void @olang_textcopy(ptr %t59, ptr %t55, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t58, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call { i64, ptr } @compiler_2feffects_2eendsNote(ptr %v0, ptr %s4, ptr %t63)
  store { i64, ptr } %t65, ptr %l30
  br label %bb16
bb16:
  %t66 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t68 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = add i64 %t67, %t70
  %t72 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t66, i64 %t67)
  %t73 = getelementptr i8, ptr %t72, i64 %t67
  call void @olang_textcopy(ptr %t73, ptr %t69, i64 %t70)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t72, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t75, ptr %rv
  br label %ret
bb17:
  %t77 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l32
  br label %bb18
bb18:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l2
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l33
  br label %bb19
bb19:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load i64, ptr %l4, !tbaa !24
  %t89 = icmp sgt i64 %t85, %t86
  br i1 %t89, label %bb20, label %bb21
bb20:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  br i1 %t93, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb25
bb22:
  %t95 = load i64, ptr %l5, !tbaa !24
  %t96 = load i64, ptr %l4, !tbaa !24
  %t99 = sub i64 %t95, %t96
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t99, %t100
  %t105 = sub i64 %t103, 1
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = sdiv i64 %t105, %t106
  store i64 %t109, ptr %l42, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb24
bb24:
  %t111 = load i64, ptr %l42, !tbaa !24
  store i64 %t111, ptr %l39, !tbaa !24
  br label %bb25
bb25:
  %t112 = load i64, ptr %l39, !tbaa !24
  store i64 %t112, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb26
bb26:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l7, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb27, label %bb28
bb27:
  br label %bb36
bb28:
  br label %bb29
bb29:
  %t121 = load i64, ptr %l4, !tbaa !24
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l6, !tbaa !24
  %t126 = mul i64 %t122, %t123
  %t129 = add i64 %t121, %t126
  store i64 %t129, ptr %l9, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/effects:Facts", ptr %t131, i32 0, i32 15
  %t134 = load i64, ptr %t133, !tbaa !24
  %t135 = load i64, ptr %l9, !tbaa !24
  %t138 = call i1 @compiler_2feffects_2ehasBit(i64 %t134, i64 %t135)
  store i1 %t138, ptr %l63
  br label %bb30
bb30:
  %t139 = load i1, ptr %l63, !tbaa !21
  br i1 %t139, label %bb31, label %bb32
bb31:
  %t140 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t140, ptr %l65, !tbaa !27
  %t141 = load i64, ptr %l9, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %t144, i64 %t141
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !37
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t150 = extractvalue { i64, ptr } %t146, 1
  %t151 = extractvalue { i64, ptr } %t146, 0
  %t152 = add i64 %t148, %t151
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t155 = add i64 %t152, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t147, i64 %t148)
  %t157 = getelementptr i8, ptr %t156, i64 %t148
  call void @olang_textcopy(ptr %t157, ptr %t150, i64 %t151)
  %t158 = getelementptr i8, ptr %t157, i64 %t151
  call void @olang_textcopy(ptr %t158, ptr %t153, i64 %t154)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t156, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = extractvalue { i64, ptr } %t160, 1
  %t164 = mul i64 %t162, 1
  %t165 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t165, ptr %t163, i64 %t164, i1 false)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t167)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t170 = load i64, ptr %l8, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l8, !tbaa !24
  br label %bb26
bb36:
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t175, ptr %l73
  br label %bb37
bb37:
  %t176 = load i64, ptr %l73, !tbaa !24
  %t177 = icmp sgt i64 %t176, 0
  br i1 %t177, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s13
  store ptr %l2, ptr %l75, !tbaa !29
  %t180 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s13, ptr %s13, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store { i64, ptr } %t180, ptr %l77
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t181 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t183 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = add i64 %t182, %t185
  %t187 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t186)
  call void @olang_textcopy(ptr %t187, ptr %t181, i64 %t182)
  %t188 = getelementptr i8, ptr %t187, i64 %t182
  call void @olang_textcopy(ptr %t188, ptr %t184, i64 %t185)
  %t189 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t187, 1
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t193 = extractvalue { i64, ptr } %t190, 1
  %t194 = mul i64 %t192, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t194)
  call void @llvm.memcpy.p0.p0.i64(ptr %t195, ptr %t193, i64 %t194, i1 false)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t198 = load ptr, ptr %l75, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t198, { i64, ptr } %t197)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s13)
  br label %bb42
bb42:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/effects:Facts", ptr %t200, i32 0, i32 2
  %t203 = load i1, ptr %t202, !tbaa !21
  br i1 %t203, label %bb43, label %bb44
bb43:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  store ptr %l2, ptr %l83, !tbaa !29
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/effects:Facts", ptr %t206, i32 0, i32 0
  %t209 = load i1, ptr %t208, !tbaa !21
  br i1 %t209, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l87, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t211, ptr %l86, !tbaa !27
  br label %bb49
bb48:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l89, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t213, ptr %l86, !tbaa !27
  br label %bb49
bb49:
  %t215 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t222 = load ptr, ptr %l83, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t222, { i64, ptr } %t221)
  br label %bb50
bb50:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/effects:Facts", ptr %t224, i32 0, i32 10
  %t227 = load i1, ptr %t226, !tbaa !21
  br i1 %t227, label %bb51, label %bb52
bb51:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb54
bb54:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/effects:Facts", ptr %t230, i32 0, i32 6
  %t233 = load i1, ptr %t232, !tbaa !21
  br i1 %t233, label %bb55, label %bb56
bb55:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = call { i64, ptr } @compiler_2feffects_2ecapText(ptr %v0, ptr %s0, ptr %t236)
  store { i64, ptr } %t238, ptr %l99
  br label %bb59
bb59:
  %t239 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t239, ptr %l10, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t242 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t240, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t242, ptr %l101
  br label %bb60
bb60:
  %t243 = load i1, ptr %l101, !tbaa !21
  %t244 = xor i1 %t243, true
  br i1 %t244, label %bb61, label %bb62
bb61:
  %t246 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t246)
  br label %bb63
bb62:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/effects:Facts", ptr %t249, i32 0, i32 4
  %t252 = load i1, ptr %t251, !tbaa !21
  br i1 %t252, label %bb64, label %bb65
bb63:
  br label %bb68
bb64:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d23, i32 0, i32 1) })
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/effects:Facts", ptr %t255, i32 0, i32 11
  %t258 = load i1, ptr %t257, !tbaa !21
  br i1 %t258, label %bb69, label %bb70
bb69:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d24, i32 0, i32 1) })
  br label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb72
bb72:
  store ptr %l2, ptr %l111, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/effects:Facts", ptr %t261, i32 0, i32 1
  %t264 = load i1, ptr %t263, !tbaa !21
  br i1 %t264, label %bb73, label %bb74
bb73:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l115, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t266, ptr %l114, !tbaa !27
  br label %bb75
bb74:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l117, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t268, ptr %l114, !tbaa !27
  br label %bb75
bb75:
  %t270 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t270, 0
  %t272 = extractvalue { i64, ptr } %t270, 1
  %t273 = mul i64 %t271, 1
  %t274 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t273)
  call void @llvm.memcpy.p0.p0.i64(ptr %t274, ptr %t272, i64 %t273, i1 false)
  %t275 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  %t277 = load ptr, ptr %l111, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t277, { i64, ptr } %t276)
  br label %bb76
bb76:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/effects:Facts", ptr %t279, i32 0, i32 7
  %t282 = load i1, ptr %t281, !tbaa !21
  br i1 %t282, label %bb77, label %bb78
bb77:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb80
bb80:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eTerminates(ptr %v0, ptr %t285)
  store i1 %t287, ptr %l124
  br label %bb81
bb81:
  %t288 = load i1, ptr %l124, !tbaa !21
  br i1 %t288, label %bb82, label %bb83
bb82:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb85
bb85:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eEvaluable(ptr %v0, ptr %t290)
  store i1 %t292, ptr %l127
  br label %bb86
bb86:
  %t293 = load i1, ptr %l127, !tbaa !21
  br i1 %t293, label %bb87, label %bb88
bb87:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb90
bb90:
  %t296 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %v2, ptr %v2, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store { i64, ptr } %t296, ptr %l130
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s0)
  %t297 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t297, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2feffects_2eFactNamed(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 0, ptr %l1
  br label %bb40
bb5:
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t8, ptr %l6
  br label %bb6
bb6:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 1, ptr %l1
  br label %bb40
bb10:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t13, ptr %l9
  br label %bb11
bb11:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i32 2, ptr %l1
  br label %bb40
bb15:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t18, ptr %l12
  br label %bb16
bb16:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 3, ptr %l1
  br label %bb40
bb20:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t23, ptr %l15
  br label %bb21
bb21:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i32 4, ptr %l1
  br label %bb40
bb25:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t28, ptr %l18
  br label %bb26
bb26:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i32 5, ptr %l1
  br label %bb40
bb30:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t33, ptr %l21
  br label %bb31
bb31:
  %t34 = load i1, ptr %l21, !tbaa !21
  br i1 %t34, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i32 6, ptr %l1
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i32 7, ptr %l1
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_ca5cd6c537ac5d6_e2b62d3f2efcd5d2)
  unreachable
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i32, ptr %l1, !range !{i32 0, i32 8}
  store i32 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2feffects_2eMerge(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i1
  %l44 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca ptr
  %l59 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca i1
  %l68 = alloca ptr
  %l71 = alloca i1
  %l74 = alloca ptr
  %l77 = alloca i1
  %l80 = alloca ptr
  %l83 = alloca i1
  %l96 = alloca i64
  %l99 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/effects:Facts", ptr %t2, i32 0, i32 0
  %t5 = load i1, ptr %t4, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/effects:Facts", ptr %t7, i32 0, i32 0
  %t10 = load i1, ptr %t9, !tbaa !21
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l11, !tbaa !21
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t13, i32 0, i32 0
  store i1 %t12, ptr %t14, !tbaa !21
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l14, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/effects:Facts", ptr %t16, i32 0, i32 1
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/effects:Facts", ptr %t21, i32 0, i32 1
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t26 = load i1, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = getelementptr %"compiler/effects:Facts", ptr %t27, i32 0, i32 1
  store i1 %t26, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Facts", ptr %t30, i32 0, i32 2
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/effects:Facts", ptr %t35, i32 0, i32 2
  %t38 = load i1, ptr %t37, !tbaa !21
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l23, !tbaa !21
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = getelementptr %"compiler/effects:Facts", ptr %t41, i32 0, i32 2
  store i1 %t40, ptr %t42, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/effects:Facts", ptr %t44, i32 0, i32 3
  %t47 = load i1, ptr %t46, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/effects:Facts", ptr %t49, i32 0, i32 3
  %t52 = load i1, ptr %t51, !tbaa !21
  store i1 %t52, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l29, !tbaa !21
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = getelementptr %"compiler/effects:Facts", ptr %t55, i32 0, i32 3
  store i1 %t54, ptr %t56, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/effects:Facts", ptr %t58, i32 0, i32 4
  %t61 = load i1, ptr %t60, !tbaa !21
  br i1 %t61, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb15
bb14:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/effects:Facts", ptr %t63, i32 0, i32 4
  %t66 = load i1, ptr %t65, !tbaa !21
  store i1 %t66, ptr %l35, !tbaa !21
  br label %bb15
bb15:
  %t68 = load i1, ptr %l35, !tbaa !21
  %t69 = load ptr, ptr %l32, !tbaa !29
  %t70 = getelementptr %"compiler/effects:Facts", ptr %t69, i32 0, i32 4
  store i1 %t68, ptr %t70, !tbaa !21
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l38, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/effects:Facts", ptr %t72, i32 0, i32 5
  %t75 = load i1, ptr %t74, !tbaa !21
  br i1 %t75, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb18
bb17:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/effects:Facts", ptr %t77, i32 0, i32 5
  %t80 = load i1, ptr %t79, !tbaa !21
  store i1 %t80, ptr %l41, !tbaa !21
  br label %bb18
bb18:
  %t82 = load i1, ptr %l41, !tbaa !21
  %t83 = load ptr, ptr %l38, !tbaa !29
  %t84 = getelementptr %"compiler/effects:Facts", ptr %t83, i32 0, i32 5
  store i1 %t82, ptr %t84, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l44, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/effects:Facts", ptr %t86, i32 0, i32 6
  %t89 = load i1, ptr %t88, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb21
bb20:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/effects:Facts", ptr %t91, i32 0, i32 6
  %t94 = load i1, ptr %t93, !tbaa !21
  store i1 %t94, ptr %l47, !tbaa !21
  br label %bb21
bb21:
  %t96 = load i1, ptr %l47, !tbaa !21
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = getelementptr %"compiler/effects:Facts", ptr %t97, i32 0, i32 6
  store i1 %t96, ptr %t98, !tbaa !21
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l50, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/effects:Facts", ptr %t100, i32 0, i32 7
  %t103 = load i1, ptr %t102, !tbaa !21
  br i1 %t103, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb24
bb23:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/effects:Facts", ptr %t105, i32 0, i32 7
  %t108 = load i1, ptr %t107, !tbaa !21
  store i1 %t108, ptr %l53, !tbaa !21
  br label %bb24
bb24:
  %t110 = load i1, ptr %l53, !tbaa !21
  %t111 = load ptr, ptr %l50, !tbaa !29
  %t112 = getelementptr %"compiler/effects:Facts", ptr %t111, i32 0, i32 7
  store i1 %t110, ptr %t112, !tbaa !21
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l56, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/effects:Facts", ptr %t114, i32 0, i32 8
  %t117 = load i1, ptr %t116, !tbaa !21
  br i1 %t117, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb27
bb26:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr %"compiler/effects:Facts", ptr %t119, i32 0, i32 8
  %t122 = load i1, ptr %t121, !tbaa !21
  store i1 %t122, ptr %l59, !tbaa !21
  br label %bb27
bb27:
  %t124 = load i1, ptr %l59, !tbaa !21
  %t125 = load ptr, ptr %l56, !tbaa !29
  %t126 = getelementptr %"compiler/effects:Facts", ptr %t125, i32 0, i32 8
  store i1 %t124, ptr %t126, !tbaa !21
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l62, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/effects:Facts", ptr %t128, i32 0, i32 9
  %t131 = load i1, ptr %t130, !tbaa !21
  br i1 %t131, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb30
bb29:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr %"compiler/effects:Facts", ptr %t133, i32 0, i32 9
  %t136 = load i1, ptr %t135, !tbaa !21
  store i1 %t136, ptr %l65, !tbaa !21
  br label %bb30
bb30:
  %t138 = load i1, ptr %l65, !tbaa !21
  %t139 = load ptr, ptr %l62, !tbaa !29
  %t140 = getelementptr %"compiler/effects:Facts", ptr %t139, i32 0, i32 9
  store i1 %t138, ptr %t140, !tbaa !21
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l68, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/effects:Facts", ptr %t142, i32 0, i32 10
  %t145 = load i1, ptr %t144, !tbaa !21
  br i1 %t145, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb33
bb32:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/effects:Facts", ptr %t147, i32 0, i32 10
  %t150 = load i1, ptr %t149, !tbaa !21
  store i1 %t150, ptr %l71, !tbaa !21
  br label %bb33
bb33:
  %t152 = load i1, ptr %l71, !tbaa !21
  %t153 = load ptr, ptr %l68, !tbaa !29
  %t154 = getelementptr %"compiler/effects:Facts", ptr %t153, i32 0, i32 10
  store i1 %t152, ptr %t154, !tbaa !21
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l74, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/effects:Facts", ptr %t156, i32 0, i32 11
  %t159 = load i1, ptr %t158, !tbaa !21
  br i1 %t159, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb36
bb35:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/effects:Facts", ptr %t161, i32 0, i32 11
  %t164 = load i1, ptr %t163, !tbaa !21
  store i1 %t164, ptr %l77, !tbaa !21
  br label %bb36
bb36:
  %t166 = load i1, ptr %l77, !tbaa !21
  %t167 = load ptr, ptr %l74, !tbaa !29
  %t168 = getelementptr %"compiler/effects:Facts", ptr %t167, i32 0, i32 11
  store i1 %t166, ptr %t168, !tbaa !21
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l80, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/effects:Facts", ptr %t170, i32 0, i32 12
  %t173 = load i1, ptr %t172, !tbaa !21
  br i1 %t173, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb39
bb38:
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/effects:Facts", ptr %t175, i32 0, i32 12
  %t178 = load i1, ptr %t177, !tbaa !21
  store i1 %t178, ptr %l83, !tbaa !21
  br label %bb39
bb39:
  %t180 = load i1, ptr %l83, !tbaa !21
  %t181 = load ptr, ptr %l80, !tbaa !29
  %t182 = getelementptr %"compiler/effects:Facts", ptr %t181, i32 0, i32 12
  store i1 %t180, ptr %t182, !tbaa !21
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/effects:Facts", ptr %t184, i32 0, i32 13
  %t187 = load i64, ptr %t186, !tbaa !24
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr %"compiler/effects:Facts", ptr %t188, i32 0, i32 13
  %t191 = load i64, ptr %t190, !tbaa !24
  %t194 = or i64 %t187, %t191
  %t197 = getelementptr %"compiler/effects:Facts", ptr %t183, i32 0, i32 13
  store i64 %t194, ptr %t197, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t198 = load i64, ptr @G_2ecompiler_2feffects_2eCapCount, !tbaa !24
  store i64 %t198, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t200 = load i64, ptr %l3, !tbaa !24
  %t201 = load i64, ptr %l2, !tbaa !24
  %t204 = icmp sgt i64 %t200, %t201
  br i1 %t204, label %bb40, label %bb41
bb40:
  %t206 = load i64, ptr %l4, !tbaa !24
  %t208 = icmp sgt i64 %t206, 0
  br i1 %t208, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb45
bb42:
  %t210 = load i64, ptr %l3, !tbaa !24
  %t211 = load i64, ptr %l2, !tbaa !24
  %t214 = sub i64 %t210, %t211
  %t215 = load i64, ptr %l4, !tbaa !24
  %t218 = add i64 %t214, %t215
  %t220 = sub i64 %t218, 1
  %t221 = load i64, ptr %l4, !tbaa !24
  %t224 = sdiv i64 %t220, %t221
  store i64 %t224, ptr %l99, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb44
bb44:
  %t226 = load i64, ptr %l99, !tbaa !24
  store i64 %t226, ptr %l96, !tbaa !24
  br label %bb45
bb45:
  %t227 = load i64, ptr %l96, !tbaa !24
  store i64 %t227, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb46
bb46:
  %t228 = load i64, ptr %l6, !tbaa !24
  %t229 = load i64, ptr %l5, !tbaa !24
  %t232 = icmp slt i64 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb47, label %bb48
bb47:
  br label %bb54
bb48:
  br label %bb49
bb49:
  %t236 = load i64, ptr %l2, !tbaa !24
  %t237 = load i64, ptr %l6, !tbaa !24
  %t238 = load i64, ptr %l4, !tbaa !24
  %t241 = mul i64 %t237, %t238
  %t244 = add i64 %t236, %t241
  store i64 %t244, ptr %l7, !tbaa !24
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load i64, ptr %l7, !tbaa !24
  %t249 = getelementptr %"compiler/effects:Facts", ptr %t246, i32 0, i32 14
  %t251 = getelementptr [6 x i64], ptr %t249, i64 0, i64 %t247
  %t252 = load i64, ptr %t251, !tbaa !34
  %t254 = icmp slt i64 %t252, 0
  br i1 %t254, label %bb50, label %bb51
bb50:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i64, ptr %l7, !tbaa !24
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t259 = load i64, ptr %l7, !tbaa !24
  %t261 = getelementptr %"compiler/effects:Facts", ptr %t258, i32 0, i32 14
  %t263 = getelementptr [6 x i64], ptr %t261, i64 0, i64 %t259
  %t264 = load i64, ptr %t263, !tbaa !34
  %t267 = getelementptr %"compiler/effects:Facts", ptr %t256, i32 0, i32 14
  %t269 = getelementptr [6 x i64], ptr %t267, i64 0, i64 %t257
  store i64 %t264, ptr %t269, !tbaa !34
  br label %bb52
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t270 = load i64, ptr %l6, !tbaa !24
  %t272 = add i64 %t270, 1
  store i64 %t272, ptr %l6, !tbaa !24
  br label %bb46
bb54:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feffects_2ecapIndex(i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l32 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load i64, ptr @G_2ecompiler_2feffects_2eCapCount, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l14, !tbaa !24
  store i64 %t29, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l11, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l1, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  store i64 %t49, ptr %l32, !tbaa !24
  %t50 = load i64, ptr %l32, !tbaa !24
  %t51 = load i64, ptr %l32, !tbaa !24
  %t52 = shl i64 1, %t51
  %t56 = icmp eq i64 %t52, %a0
  br i1 %t56, label %bb11, label %bb12
bb11:
  %t58 = load i64, ptr %l6, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l5, !tbaa !24
  br label %bb7
bb15:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feffects_2ecapOf(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l29 = alloca i1
  %l45 = alloca i1
  %l61 = alloca i1
  %l77 = alloca i1
  %l82 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr @G_2ecompiler_2feffects_2efileNames, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t2 = load ptr, ptr %l1
  store i64 25, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l1
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = getelementptr [25 x { i64, ptr }], ptr %t13, i64 0, i64 %t14
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !37
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = load ptr, ptr @__olang_prog_scope
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t22, { i64, ptr } %t20, { i64, ptr } %t18)
  store i1 %t25, ptr %l29
  br label %bb5
bb5:
  %t26 = load i1, ptr %l29, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t27 = load i64, ptr @G_2ecompiler_2feffects_2eCapFiles, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = add i64 %t29, 1
  store i64 %t31, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  store ptr @G_2ecompiler_2feffects_2enetNames, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t34 = load ptr, ptr %l5
  store i64 7, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l5
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = getelementptr [7 x { i64, ptr }], ptr %t45, i64 0, i64 %t46
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !37
  %t52 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t54 = load ptr, ptr @__olang_prog_scope
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t54, { i64, ptr } %t52, { i64, ptr } %t50)
  store i1 %t57, ptr %l45
  br label %bb15
bb15:
  %t58 = load i1, ptr %l45, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t59 = load i64, ptr @G_2ecompiler_2feffects_2eCapNetwork, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t59, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb11
bb20:
  store ptr @G_2ecompiler_2feffects_2eprocNames, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t66 = load ptr, ptr %l9
  store i64 12, ptr %l11, !tbaa !24
  br label %bb21
bb21:
  %t69 = load i64, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  br label %bb24
bb24:
  %t77 = load ptr, ptr %l9
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = getelementptr [12 x { i64, ptr }], ptr %t77, i64 0, i64 %t78
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !37
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t86 = load ptr, ptr @__olang_prog_scope
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t86, { i64, ptr } %t84, { i64, ptr } %t82)
  store i1 %t89, ptr %l61
  br label %bb25
bb25:
  %t90 = load i1, ptr %l61, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr @G_2ecompiler_2feffects_2eCapProcesses, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t91, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l10, !tbaa !24
  br label %bb21
bb30:
  store ptr @G_2ecompiler_2feffects_2eenvNames, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  %t98 = load ptr, ptr %l13
  store i64 5, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  %t101 = load i64, ptr %l14, !tbaa !24
  %t102 = load i64, ptr %l15, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb32, label %bb33
bb32:
  br label %bb40
bb33:
  br label %bb34
bb34:
  %t109 = load ptr, ptr %l13
  %t110 = load i64, ptr %l14, !tbaa !24
  %t113 = getelementptr [5 x { i64, ptr }], ptr %t109, i64 0, i64 %t110
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !37
  %t116 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t118 = load ptr, ptr @__olang_prog_scope
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t118, { i64, ptr } %t116, { i64, ptr } %t114)
  store i1 %t121, ptr %l77
  br label %bb35
bb35:
  %t122 = load i1, ptr %l77, !tbaa !21
  br i1 %t122, label %bb36, label %bb37
bb36:
  %t123 = load i64, ptr @G_2ecompiler_2feffects_2eCapEnvironment, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t123, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t125 = load i64, ptr %l14, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l14, !tbaa !24
  br label %bb31
bb40:
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t129, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t131, ptr %l82
  br label %bb41
bb41:
  %t132 = load i1, ptr %l82, !tbaa !21
  br i1 %t132, label %bb42, label %bb43
bb42:
  %t133 = load i64, ptr @G_2ecompiler_2feffects_2eCapThreads, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t133, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2feffects_2ecapText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l16 = alloca i64
  %l36 = alloca i64
  %l40 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2feffects_2eCapCount, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t53 = getelementptr %"compiler/effects:Facts", ptr %a0, i32 0, i32 13
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  store i64 %t55, ptr %l36, !tbaa !24
  %t56 = load i64, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = shl i64 1, %t57
  %t61 = and i64 %t54, %t58
  %t63 = icmp ne i64 %t61, 0
  br i1 %t63, label %bb12, label %bb13
bb12:
  store ptr %l1, ptr %l40, !tbaa !29
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = call { i64, ptr } @compiler_2feffects_2eCapName(ptr %s0, i64 %t65)
  store { i64, ptr } %t67, ptr %l42
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t68 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t75, { i64, ptr } %t74)
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb8
bb18:
  %t82 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store { i64, ptr } %t82, ptr %l47
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eModuleOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2egrow(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/effects:Effects", ptr %t3, i32 0, i32 7
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 1
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t8, i64 %a1)
  store ptr %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t19 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t17, i64 %t16)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l13
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb4, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l12
  br label %bb3
bb3:
  %t24 = load i64, ptr %l12, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l3, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/effects:Facts"
  %l5 = alloca i1
  %l6 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"compiler/effects:Facts"
  %l17 = alloca i64
  %l24 = alloca %"compiler/effects:Facts"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Facts"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l9
  br label %bb3
bb3:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l5, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s1)
  store %"compiler/effects:Facts" %t16, ptr %l11
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t17 = load %"compiler/effects:Facts", ptr %l11
  store %"compiler/effects:Facts" %t17, ptr %l2
  %t18 = getelementptr %"compiler/effects:Facts", ptr %l2, i32 0, i32 12
  store i1 true, ptr %t18, !tbaa !21
  %t19 = load %"compiler/effects:Facts", ptr %l2
  call void @__olang_scope_close(ptr %s1)
  store %"compiler/effects:Facts" %t19, ptr %rv
  br label %ret
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2egrow(ptr %v0, ptr %t21)
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/effects:Effects", ptr %t23, i32 0, i32 6
  %t26 = load i64, ptr %l1, !tbaa !24
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l17
  br label %bb10
bb10:
  %t30 = load i64, ptr %l17, !tbaa !24
  %t31 = icmp slt i64 %t30, 2
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2evisit(ptr %v0, ptr %t33, i64 %t34)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/effects:Effects", ptr %t37, i32 0, i32 5
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t39, i64 %t40)
  store %"compiler/effects:Facts" %t43, ptr %l24
  br label %bb15
bb15:
  %t44 = load %"compiler/effects:Facts", ptr %l24
  store %"compiler/effects:Facts" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Facts", ptr %rv
  ret %"compiler/effects:Facts" %rr
}

define dso_local %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOfExtern(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/effects:Facts"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/effects:Facts"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Facts"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2egrow(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/effects:Effects", ptr %t3, i32 0, i32 14
  %t6 = load %"compiler/effects:Facts", ptr %t5
  store %"compiler/effects:Facts" %t6, ptr %l2
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load %"compiler/effects:Facts", ptr %l8
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = getelementptr %"compiler/effects:Effects", ptr %t11, i32 0, i32 14
  store %"compiler/effects:Facts" %t10, ptr %t12
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/effects:Effects", ptr %t13, i32 0, i32 20
  store i64 -1, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eextern(ptr %v0, ptr %t16, i64 %a1)
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/effects:Effects", ptr %t20, i32 0, i32 14
  %t23 = load %"compiler/effects:Facts", ptr %t22
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load %"compiler/effects:Facts", ptr %l2
  %t29 = getelementptr %"compiler/effects:Effects", ptr %t25, i32 0, i32 14
  store %"compiler/effects:Facts" %t26, ptr %t29
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Facts" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Facts", ptr %rv
  ret %"compiler/effects:Facts" %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/effects:root"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca %"compiler/effects:root"
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca %"compiler/effects:root"
  %l43 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load i1, ptr %l19, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t36, i32 0, i32 17
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  store %"compiler/effects:root" %t43, ptr %l27
  br label %bb10
bb10:
  %t44 = getelementptr %"compiler/effects:root", ptr %l27, i32 0, i32 0
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t48 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t46, i64 %t45)
  %t49 = extractvalue { i32, i64 } %t48, 1
  %t50 = extractvalue { i32, i64 } %t48, 0
  store i32 %t50, ptr %l30
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb12, label %ok.52, !prof !99
ok.52:
  store i64 %t49, ptr %l29
  br label %bb11
bb11:
  %t53 = load i64, ptr %l29, !tbaa !24
  store i64 %t53, ptr %l22, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb14
bb14:
  %t54 = load i64, ptr %l22, !tbaa !24
  store i64 %t54, ptr %rv
  br label %ret
bb15:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 3
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t63 = load i1, ptr %l32, !tbaa !21
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb29
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t74 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t70, ptr %t71)
  store %"compiler/effects:root" %t74, ptr %l39
  br label %bb21
bb21:
  %t75 = load %"compiler/effects:root", ptr %l39
  store %"compiler/effects:root" %t75, ptr %l5
  %t76 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 1
  %t77 = load i1, ptr %t76, !tbaa !21
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i64 -1, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/effects:Effects", ptr %t82, i32 0, i32 17
  %t85 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 0
  %t86 = load i64, ptr %t85, !tbaa !24
  %t89 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t84, i64 %t86)
  %t90 = extractvalue { i32, i64 } %t89, 1
  %t91 = extractvalue { i32, i64 } %t89, 0
  store i32 %t91, ptr %l48
  %t92 = icmp ne i32 %t91, 0
  br i1 %t92, label %bb26, label %ok.93, !prof !99
ok.93:
  store i64 %t90, ptr %l47
  br label %bb25
bb25:
  %t94 = load i64, ptr %l47, !tbaa !24
  store i64 %t94, ptr %l43, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l43, !tbaa !24
  br label %bb28
bb28:
  %t95 = load i64, ptr %l43, !tbaa !24
  store i64 %t95, ptr %rv
  br label %ret
bb29:
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb30, label %bb31
bb30:
  %t100 = load ptr, ptr %l49, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 18}
  %t103 = icmp eq i64 %t101, 17
  store i1 %t103, ptr %l50, !tbaa !21
  br label %bb31
bb31:
  %t104 = load i1, ptr %l50, !tbaa !21
  br i1 %t104, label %bb32, label %bb33
bb32:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t115 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargParam(ptr %v0, ptr %v1, ptr %t111, ptr %t112)
  store i64 %t115, ptr %l57
  br label %bb35
bb35:
  %t116 = load i64, ptr %l57, !tbaa !24
  store i64 %t116, ptr %rv
  br label %ret
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i64 -1, ptr %rv
  br label %ret
bb40:
  call void @__olang_check_failed(ptr @olang_loc_4055e0fe87b920f9_59f1ceb8b6607d)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb15
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Alt", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  store ptr %t57, ptr %l9, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l9, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Bind", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t59, ptr %t63)
  br label %bb10
bb10:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Bind", ptr %t68, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = sext i32 %t71 to i64
  %t74 = load ptr, ptr %l9, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Bind", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ederive(ptr %v0, ptr %v1, ptr %t67, i64 %t73, ptr %t77)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l7, !tbaa !24
  br label %bb6
bb13:
  br label %bb14
bb14:
  %t85 = load i64, ptr %l3, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l3, !tbaa !24
  br label %bb1
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Arm", ptr %t90, i32 0, i32 2
  %t93 = load ptr, ptr %t92, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t89, ptr %t93)
  br label %bb16
bb16:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Arm", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t96, ptr %t100)
  br label %bb17
bb17:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Arm", ptr %t104, i32 0, i32 4
  %t107 = load ptr, ptr %t106, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t103, ptr %t107)
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l35 = alloca i64
  %l38 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca i64
  %l65 = alloca ptr
  %l70 = alloca %"compiler/effects:link"
  %l73 = alloca ptr
  %l74 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca i1
  %l108 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t7 = load ptr, ptr %l19, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l20, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb25
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/effects:Effects", ptr %t21, i32 0, i32 15
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t23, i64 %t26)
  br label %bb6
bb6:
  store i64 0, ptr %l4, !tbaa !24
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Call", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb12
bb9:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l38, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb11
bb11:
  %t62 = load i64, ptr %l38, !tbaa !24
  store i64 %t62, ptr %l35, !tbaa !24
  br label %bb12
bb12:
  %t63 = load i64, ptr %l35, !tbaa !24
  store i64 %t63, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l9, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Call", ptr %t83, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l58, !tbaa !27
  %t87 = load i64, ptr %l9, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr ptr, ptr %t90, i64 %t87
  %t92 = load ptr, ptr %t91, !tbaa !39
  %t95 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargParam(ptr %v0, ptr %v1, ptr %t82, ptr %t92)
  store i64 %t95, ptr %l61
  br label %bb17
bb17:
  %t96 = load i64, ptr %l61, !tbaa !24
  store i64 %t96, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t99 = icmp sge i64 %t97, 0
  br i1 %t99, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/effects:Effects", ptr %t101, i32 0, i32 16
  store ptr %t103, ptr %l65, !tbaa !29
  %t104 = load i32, ptr %l3, !tbaa !23
  %t106 = sext i32 %t104 to i64
  %t107 = load i64, ptr %l9, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t112 = call %"compiler/effects:link" @compiler_2feffects_3alink_2ector(ptr %s4, i64 %t106, i64 %t107, i64 %t108)
  store %"compiler/effects:link" %t112, ptr %l70
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t113 = load ptr, ptr %l65, !tbaa !29
  %t114 = load %"compiler/effects:link", ptr %l70
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ePush_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %t113, %"compiler/effects:link" %t114)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l8, !tbaa !24
  br label %bb13
bb24:
  br label %bb52
bb25:
  %t119 = load ptr, ptr %l2, !tbaa !29
  store ptr %t119, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t120 = load ptr, ptr %l73, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb26, label %bb27
bb26:
  %t123 = load ptr, ptr %l73, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 5}
  %t126 = icmp eq i64 %t124, 1
  store i1 %t126, ptr %l74, !tbaa !21
  br label %bb27
bb27:
  %t127 = load i1, ptr %l74, !tbaa !21
  br i1 %t127, label %bb28, label %bb29
bb28:
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { i64 }, ptr %t130, i32 0, i32 0
  %t132 = load i64, ptr %t131
  store i64 %t132, ptr %l11, !tbaa !24
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eextern(ptr %v0, ptr %t134, i64 %t135)
  br label %bb31
bb31:
  br label %bb52
bb32:
  %t138 = load ptr, ptr %l2, !tbaa !29
  store ptr %t138, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t139 = load ptr, ptr %l81, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb33, label %bb34
bb33:
  %t142 = load ptr, ptr %l81, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 5}
  %t145 = icmp eq i64 %t143, 2
  store i1 %t145, ptr %l82, !tbaa !21
  br label %bb34
bb34:
  %t146 = load i1, ptr %l82, !tbaa !21
  br i1 %t146, label %bb35, label %bb36
bb35:
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { ptr }, ptr %t149, i32 0, i32 0
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l12, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/effects:Effects", ptr %t153, i32 0, i32 14
  %t156 = getelementptr %"compiler/effects:Facts", ptr %t155, i32 0, i32 9
  store i1 true, ptr %t156, !tbaa !21
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t157, ptr %t158)
  br label %bb38
bb38:
  br label %bb52
bb39:
  %t162 = load ptr, ptr %l2, !tbaa !29
  store ptr %t162, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t163 = load ptr, ptr %l91, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb40, label %bb41
bb40:
  %t166 = load ptr, ptr %l91, !tbaa !29
  %t167 = load i64, ptr %t166, !range !{i64 0, i64 5}
  %t169 = icmp eq i64 %t167, 3
  store i1 %t169, ptr %l92, !tbaa !21
  br label %bb41
bb41:
  %t170 = load i1, ptr %l92, !tbaa !21
  br i1 %t170, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/effects:Effects", ptr %t171, i32 0, i32 14
  %t174 = getelementptr %"compiler/effects:Facts", ptr %t173, i32 0, i32 9
  store i1 true, ptr %t174, !tbaa !21
  br label %bb52
bb45:
  %t175 = load ptr, ptr %l2, !tbaa !29
  store ptr %t175, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t176 = load ptr, ptr %l96, !tbaa !29
  %t177 = icmp ne ptr %t176, null
  br i1 %t177, label %bb46, label %bb47
bb46:
  %t179 = load ptr, ptr %l96, !tbaa !29
  %t180 = load i64, ptr %t179, !range !{i64 0, i64 5}
  %t182 = icmp eq i64 %t180, 4
  store i1 %t182, ptr %l97, !tbaa !21
  br label %bb47
bb47:
  %t183 = load i1, ptr %l97, !tbaa !21
  br i1 %t183, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_1bc29689bbb58e32_9924d9acc7f0abd6)
  unreachable
bb52:
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t186 = getelementptr %"compiler/typed:Call", ptr %t184, i32 0, i32 1
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  store { i64, ptr } %t187, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t189 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  store i64 %t191, ptr %l15, !tbaa !24
  br label %bb53
bb53:
  %t193 = load i64, ptr %l14, !tbaa !24
  %t194 = load i64, ptr %l15, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb54, label %bb55
bb54:
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t201 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t201, ptr %l108, !tbaa !27
  %t202 = load i64, ptr %l14, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr ptr, ptr %t205, i64 %t202
  %t207 = load ptr, ptr %t206, !tbaa !39
  %t209 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t209, ptr %t207)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t214 = load i64, ptr %l14, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l14, !tbaa !24
  br label %bb53
bb59:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecap(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/effects:Effects", ptr %t2, i32 0, i32 14
  %t5 = getelementptr %"compiler/effects:Facts", ptr %t4, i32 0, i32 13
  %t6 = load i64, ptr %t5, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = or i64 %t6, %t7
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 14
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t13, i32 0, i32 13
  store i64 %t10, ptr %t14, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2feffects_2ecapIndex(i64 %t15)
  store i64 %t17, ptr %l9
  br label %bb1
bb1:
  %t18 = load i64, ptr %l9, !tbaa !24
  store i64 %t18, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp sge i64 %t19, 0
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr %"compiler/effects:Effects", ptr %t23, i32 0, i32 14
  %t27 = getelementptr %"compiler/effects:Facts", ptr %t26, i32 0, i32 14
  %t29 = getelementptr [6 x i64], ptr %t27, i64 0, i64 %t24
  %t30 = load i64, ptr %t29, !tbaa !34
  %t32 = icmp slt i64 %t30, 0
  store i1 %t32, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t34 = load i1, ptr %l12, !tbaa !21
  br i1 %t34, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l2, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/effects:Effects", ptr %t37, i32 0, i32 20
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = getelementptr %"compiler/effects:Effects", ptr %t35, i32 0, i32 14
  %t44 = getelementptr %"compiler/effects:Facts", ptr %t43, i32 0, i32 14
  %t46 = getelementptr [6 x i64], ptr %t44, i64 0, i64 %t36
  store i64 %t40, ptr %t46, !tbaa !34
  br label %bb7
bb6:
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclause(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Clause", ptr %t2, i32 0, i32 3
  %t5 = load ptr, ptr %t4, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Clause", ptr %t8, i32 0, i32 4
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t33, ptr %t31)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ederive(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l11 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i1
  %l21 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t7)
  store i32 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i1, ptr %l9, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/effects:Effects", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t22)
  store i32 %t24, ptr %l16
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb5:
  %t25 = load ptr, ptr %l14, !tbaa !29
  %t26 = load i32, ptr %l16, !tbaa !23
  %t27 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t27, ptr %l17
  br label %bb6
bb6:
  %t28 = load i1, ptr %l17, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l11, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  br label %ret
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t36 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %t32, ptr %t33, i64 0)
  store i64 %t36, ptr %l21
  br label %bb11
bb11:
  %t37 = load i64, ptr %l21, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = icmp ne i64 %t38, 0
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Effects", ptr %t42, i32 0, i32 18
  %t46 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t44, i64 %a1, i64 %t46)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l98 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l102 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %l156 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l165 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i1
  %l223 = alloca { i64, ptr }
  %l233 = alloca ptr
  %l234 = alloca i1
  %l247 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l273 = alloca ptr
  %l279 = alloca ptr
  %l280 = alloca i1
  %l296 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l304 = alloca i1
  %l311 = alloca ptr
  %l312 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t6 = load ptr, ptr %l44, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l44, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l45, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l45, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t15 = load ptr, ptr %l48, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l48, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l49, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l49, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb186
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t24 = load ptr, ptr %l52, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l52, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l53, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l53, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb26
bb17:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t39 = load ptr, ptr %l58, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l58, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l59, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l59, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb26
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t54 = load ptr, ptr %l64, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l64, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l65, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l65, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t68, ptr %t69, i1 false)
  br label %bb27
bb27:
  br label %bb186
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t73 = load ptr, ptr %l72, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb29, label %bb30
bb29:
  %t76 = load ptr, ptr %l72, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 5
  store i1 %t79, ptr %l73, !tbaa !21
  br label %bb30
bb30:
  %t80 = load i1, ptr %l73, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/effects:Effects", ptr %t87, i32 0, i32 14
  %t90 = getelementptr %"compiler/effects:Facts", ptr %t89, i32 0, i32 0
  store i1 true, ptr %t90, !tbaa !21
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Promote", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  br label %bb34
bb34:
  br label %bb186
bb35:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t100 = load ptr, ptr %l83, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb36, label %bb37
bb36:
  %t103 = load ptr, ptr %l83, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 18}
  %t106 = icmp eq i64 %t104, 16
  store i1 %t106, ptr %l84, !tbaa !21
  br label %bb37
bb37:
  %t107 = load i1, ptr %l84, !tbaa !21
  br i1 %t107, label %bb38, label %bb39
bb38:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb59
bb40:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/effects:Effects", ptr %t114, i32 0, i32 14
  %t117 = getelementptr %"compiler/effects:Facts", ptr %t116, i32 0, i32 0
  store i1 true, ptr %t117, !tbaa !21
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Text", ptr %t118, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  store i64 %t125, ptr %l7, !tbaa !24
  br label %bb41
bb41:
  %t127 = load i64, ptr %l6, !tbaa !24
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb42, label %bb43
bb42:
  br label %bb58
bb43:
  br label %bb44
bb44:
  %t135 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t135, ptr %l98, !tbaa !27
  %t136 = load i64, ptr %l6, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr ptr, ptr %t139, i64 %t136
  %t141 = load ptr, ptr %t140, !tbaa !39
  store ptr %t141, ptr %l8, !tbaa !29
  %t143 = load ptr, ptr %l8, !tbaa !29
  store ptr %t143, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t144 = load ptr, ptr %l101, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb45, label %bb46
bb45:
  %t147 = load ptr, ptr %l101, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 2}
  %t150 = icmp eq i64 %t148, 1
  store i1 %t150, ptr %l102, !tbaa !21
  br label %bb46
bb46:
  %t151 = load i1, ptr %l102, !tbaa !21
  br i1 %t151, label %bb47, label %bb48
bb47:
  %t152 = load ptr, ptr %l8, !tbaa !29
  %t154 = getelementptr { i64, [2 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { ptr }, ptr %t154, i32 0, i32 0
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l9, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  br label %bb50
bb50:
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_696967e496dd013f_3ccf8d6ad66b978b)
  unreachable
bb56:
  br label %bb57
bb57:
  %t163 = load i64, ptr %l6, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l6, !tbaa !24
  br label %bb41
bb58:
  br label %bb186
bb59:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t168 = load ptr, ptr %l112, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb60, label %bb61
bb60:
  %t171 = load ptr, ptr %l112, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 18}
  %t174 = icmp eq i64 %t172, 8
  store i1 %t174, ptr %l113, !tbaa !21
  br label %bb61
bb61:
  %t175 = load i1, ptr %l113, !tbaa !21
  br i1 %t175, label %bb62, label %bb63
bb62:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l10, !tbaa !29
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/effects:Effects", ptr %t182, i32 0, i32 14
  %t185 = getelementptr %"compiler/effects:Facts", ptr %t184, i32 0, i32 0
  store i1 true, ptr %t185, !tbaa !21
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load ptr, ptr %l10, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Collect", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t186, ptr %t190)
  br label %bb65
bb65:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l10, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Collect", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t193, ptr %t197)
  br label %bb66
bb66:
  br label %bb186
bb67:
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t202 = load ptr, ptr %l126, !tbaa !29
  %t203 = icmp ne ptr %t202, null
  br i1 %t203, label %bb68, label %bb69
bb68:
  %t205 = load ptr, ptr %l126, !tbaa !29
  %t206 = load i64, ptr %t205, !range !{i64 0, i64 18}
  %t208 = icmp eq i64 %t206, 6
  store i1 %t208, ptr %l127, !tbaa !21
  br label %bb69
bb69:
  %t209 = load i1, ptr %l127, !tbaa !21
  br i1 %t209, label %bb70, label %bb71
bb70:
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t212, i32 0, i32 2
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l11, !tbaa !29
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecall(ptr %v0, ptr %v1, ptr %t216, ptr %t217)
  br label %bb73
bb73:
  br label %bb186
bb74:
  %t220 = load ptr, ptr %l1, !tbaa !29
  store ptr %t220, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t221 = load ptr, ptr %l134, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb75, label %bb76
bb75:
  %t224 = load ptr, ptr %l134, !tbaa !29
  %t225 = load i64, ptr %t224, !range !{i64 0, i64 18}
  %t227 = icmp eq i64 %t225, 7
  store i1 %t227, ptr %l135, !tbaa !21
  br label %bb76
bb76:
  %t228 = load i1, ptr %l135, !tbaa !21
  br i1 %t228, label %bb77, label %bb78
bb77:
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t231, i32 0, i32 2
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l12, !tbaa !29
  br label %bb79
bb78:
  br label %bb91
bb79:
  %t235 = load ptr, ptr %l12, !tbaa !29
  %t237 = getelementptr %"compiler/typed:Make", ptr %t235, i32 0, i32 4
  %t238 = load i32, ptr %t237, !tbaa !23
  %t240 = sext i32 %t238 to i64
  %t242 = icmp sge i64 %t240, 0
  br i1 %t242, label %bb80, label %bb81
bb80:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/effects:Effects", ptr %t244, i32 0, i32 14
  %t247 = getelementptr %"compiler/effects:Facts", ptr %t246, i32 0, i32 0
  store i1 true, ptr %t247, !tbaa !21
  br label %bb82
bb81:
  br label %bb82
bb82:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l12, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Make", ptr %t249, i32 0, i32 3
  %t252 = load ptr, ptr %t251, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t248, ptr %t252)
  br label %bb83
bb83:
  %t255 = load ptr, ptr %l12, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Make", ptr %t255, i32 0, i32 2
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  store { i64, ptr } %t258, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t260 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t260, 0
  store i64 %t262, ptr %l15, !tbaa !24
  br label %bb84
bb84:
  %t264 = load i64, ptr %l14, !tbaa !24
  %t265 = load i64, ptr %l15, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb85, label %bb86
bb85:
  br label %bb90
bb86:
  br label %bb87
bb87:
  %t272 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t272, ptr %l156, !tbaa !27
  %t273 = load i64, ptr %l14, !tbaa !24
  %t275 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr ptr, ptr %t276, i64 %t273
  %t278 = load ptr, ptr %t277, !tbaa !39
  %t280 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t280, ptr %t278)
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t285 = load i64, ptr %l14, !tbaa !24
  %t287 = add i64 %t285, 1
  store i64 %t287, ptr %l14, !tbaa !24
  br label %bb84
bb90:
  br label %bb186
bb91:
  %t289 = load ptr, ptr %l1, !tbaa !29
  store ptr %t289, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t290 = load ptr, ptr %l164, !tbaa !29
  %t291 = icmp ne ptr %t290, null
  br i1 %t291, label %bb92, label %bb93
bb92:
  %t293 = load ptr, ptr %l164, !tbaa !29
  %t294 = load i64, ptr %t293, !range !{i64 0, i64 18}
  %t296 = icmp eq i64 %t294, 9
  store i1 %t296, ptr %l165, !tbaa !21
  br label %bb93
bb93:
  %t297 = load i1, ptr %l165, !tbaa !21
  br i1 %t297, label %bb94, label %bb95
bb94:
  %t298 = load ptr, ptr %l1, !tbaa !29
  %t300 = getelementptr { i64, [5 x i64] }, ptr %t298, i32 0, i32 1
  %t301 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t300, i32 0, i32 2
  %t302 = load i32, ptr %t301, !range !{i32 0, i32 43}
  store i32 %t302, ptr %l17
  %t304 = load ptr, ptr %l1, !tbaa !29
  %t306 = getelementptr { i64, [5 x i64] }, ptr %t304, i32 0, i32 1
  %t307 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t306, i32 0, i32 4
  %t308 = load { i64, ptr }, ptr %t307
  store { i64, ptr } %t308, ptr %l18, !tbaa !27
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load i32, ptr %l17, !range !{i32 0, i32 43}
  %t312 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eprim(ptr %v0, ptr %v1, ptr %t310, i32 %t311, { i64, ptr } %t312)
  br label %bb97
bb97:
  br label %bb186
bb98:
  %t316 = load ptr, ptr %l1, !tbaa !29
  store ptr %t316, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t317 = load ptr, ptr %l175, !tbaa !29
  %t318 = icmp ne ptr %t317, null
  br i1 %t318, label %bb99, label %bb100
bb99:
  %t320 = load ptr, ptr %l175, !tbaa !29
  %t321 = load i64, ptr %t320, !range !{i64 0, i64 18}
  %t323 = icmp eq i64 %t321, 10
  store i1 %t323, ptr %l176, !tbaa !21
  br label %bb100
bb100:
  %t324 = load i1, ptr %l176, !tbaa !21
  br i1 %t324, label %bb101, label %bb102
bb101:
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr { i64, [5 x i64] }, ptr %t325, i32 0, i32 1
  %t328 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t327, i32 0, i32 2
  %t329 = load ptr, ptr %t328
  store ptr %t329, ptr %l19, !tbaa !29
  br label %bb103
bb102:
  br label %bb107
bb103:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l19, !tbaa !29
  %t334 = getelementptr %"compiler/typed:Slice", ptr %t332, i32 0, i32 0
  %t335 = load ptr, ptr %t334, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t331, ptr %t335, i1 false)
  br label %bb104
bb104:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load ptr, ptr %l19, !tbaa !29
  %t341 = getelementptr %"compiler/typed:Slice", ptr %t339, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t338, ptr %t342)
  br label %bb105
bb105:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l19, !tbaa !29
  %t349 = getelementptr %"compiler/typed:Slice", ptr %t347, i32 0, i32 2
  %t350 = load ptr, ptr %t349, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t346, ptr %t350)
  br label %bb106
bb106:
  br label %bb186
bb107:
  %t354 = load ptr, ptr %l1, !tbaa !29
  store ptr %t354, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t355 = load ptr, ptr %l192, !tbaa !29
  %t356 = icmp ne ptr %t355, null
  br i1 %t356, label %bb108, label %bb109
bb108:
  %t358 = load ptr, ptr %l192, !tbaa !29
  %t359 = load i64, ptr %t358, !range !{i64 0, i64 18}
  %t361 = icmp eq i64 %t359, 11
  store i1 %t361, ptr %l193, !tbaa !21
  br label %bb109
bb109:
  %t362 = load i1, ptr %l193, !tbaa !21
  br i1 %t362, label %bb110, label %bb111
bb110:
  %t363 = load ptr, ptr %l1, !tbaa !29
  %t365 = getelementptr { i64, [5 x i64] }, ptr %t363, i32 0, i32 1
  %t366 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t365, i32 0, i32 2
  %t367 = load ptr, ptr %t366
  store ptr %t367, ptr %l20, !tbaa !29
  br label %bb112
bb111:
  br label %bb116
bb112:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load ptr, ptr %l20, !tbaa !29
  %t372 = getelementptr %"compiler/typed:Cond", ptr %t370, i32 0, i32 0
  %t373 = load ptr, ptr %t372, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t369, ptr %t373)
  br label %bb113
bb113:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load ptr, ptr %l20, !tbaa !29
  %t380 = getelementptr %"compiler/typed:Cond", ptr %t378, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t377, ptr %t381)
  br label %bb114
bb114:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load ptr, ptr %l20, !tbaa !29
  %t387 = getelementptr %"compiler/typed:Cond", ptr %t385, i32 0, i32 2
  %t388 = load ptr, ptr %t387, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t384, ptr %t388)
  br label %bb115
bb115:
  br label %bb186
bb116:
  %t392 = load ptr, ptr %l1, !tbaa !29
  store ptr %t392, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t393 = load ptr, ptr %l209, !tbaa !29
  %t394 = icmp ne ptr %t393, null
  br i1 %t394, label %bb117, label %bb118
bb117:
  %t396 = load ptr, ptr %l209, !tbaa !29
  %t397 = load i64, ptr %t396, !range !{i64 0, i64 18}
  %t399 = icmp eq i64 %t397, 12
  store i1 %t399, ptr %l210, !tbaa !21
  br label %bb118
bb118:
  %t400 = load i1, ptr %l210, !tbaa !21
  br i1 %t400, label %bb119, label %bb120
bb119:
  %t401 = load ptr, ptr %l1, !tbaa !29
  %t403 = getelementptr { i64, [5 x i64] }, ptr %t401, i32 0, i32 1
  %t404 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t403, i32 0, i32 2
  %t405 = load ptr, ptr %t404
  store ptr %t405, ptr %l21, !tbaa !29
  br label %bb121
bb120:
  br label %bb130
bb121:
  %t407 = load ptr, ptr %l21, !tbaa !29
  %t409 = getelementptr %"compiler/typed:Seq", ptr %t407, i32 0, i32 0
  %t410 = load { i64, ptr }, ptr %t409, !tbaa !27
  store { i64, ptr } %t410, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t412 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t414 = extractvalue { i64, ptr } %t412, 0
  store i64 %t414, ptr %l24, !tbaa !24
  br label %bb122
bb122:
  %t416 = load i64, ptr %l23, !tbaa !24
  %t417 = load i64, ptr %l24, !tbaa !24
  %t420 = icmp slt i64 %t416, %t417
  %t422 = xor i1 %t420, true
  br i1 %t422, label %bb123, label %bb124
bb123:
  br label %bb128
bb124:
  br label %bb125
bb125:
  %t424 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t424, ptr %l223, !tbaa !27
  %t425 = load i64, ptr %l23, !tbaa !24
  %t427 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = getelementptr ptr, ptr %t428, i64 %t425
  %t430 = load ptr, ptr %t429, !tbaa !39
  %t432 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %t432, ptr %t430)
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t436 = load i64, ptr %l23, !tbaa !24
  %t438 = add i64 %t436, 1
  store i64 %t438, ptr %l23, !tbaa !24
  br label %bb122
bb128:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load ptr, ptr %l21, !tbaa !29
  %t443 = getelementptr %"compiler/typed:Seq", ptr %t441, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t440, ptr %t444)
  br label %bb129
bb129:
  br label %bb186
bb130:
  %t447 = load ptr, ptr %l1, !tbaa !29
  store ptr %t447, ptr %l233, !tbaa !29
  store i1 false, ptr %l234, !tbaa !21
  %t448 = load ptr, ptr %l233, !tbaa !29
  %t449 = icmp ne ptr %t448, null
  br i1 %t449, label %bb131, label %bb132
bb131:
  %t451 = load ptr, ptr %l233, !tbaa !29
  %t452 = load i64, ptr %t451, !range !{i64 0, i64 18}
  %t454 = icmp eq i64 %t452, 13
  store i1 %t454, ptr %l234, !tbaa !21
  br label %bb132
bb132:
  %t455 = load i1, ptr %l234, !tbaa !21
  br i1 %t455, label %bb133, label %bb134
bb133:
  %t456 = load ptr, ptr %l1, !tbaa !29
  %t458 = getelementptr { i64, [5 x i64] }, ptr %t456, i32 0, i32 1
  %t459 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t458, i32 0, i32 2
  %t460 = load ptr, ptr %t459
  store ptr %t460, ptr %l26, !tbaa !29
  br label %bb135
bb134:
  br label %bb157
bb135:
  %t462 = load ptr, ptr %l26, !tbaa !29
  %t464 = getelementptr %"compiler/typed:Match", ptr %t462, i32 0, i32 0
  %t465 = load { i64, ptr }, ptr %t464, !tbaa !27
  store { i64, ptr } %t465, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t467 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t467, 0
  store i64 %t469, ptr %l29, !tbaa !24
  br label %bb136
bb136:
  %t471 = load i64, ptr %l28, !tbaa !24
  %t472 = load i64, ptr %l29, !tbaa !24
  %t475 = icmp slt i64 %t471, %t472
  %t477 = xor i1 %t475, true
  br i1 %t477, label %bb137, label %bb138
bb137:
  br label %bb142
bb138:
  br label %bb139
bb139:
  %t479 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t479, ptr %l247, !tbaa !27
  %t480 = load i64, ptr %l28, !tbaa !24
  %t482 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr ptr, ptr %t483, i64 %t480
  %t485 = load ptr, ptr %t484, !tbaa !39
  %t487 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %t487, ptr %t485)
  br label %bb140
bb140:
  br label %bb141
bb141:
  %t491 = load i64, ptr %l28, !tbaa !24
  %t493 = add i64 %t491, 1
  store i64 %t493, ptr %l28, !tbaa !24
  br label %bb136
bb142:
  %t495 = load ptr, ptr %l26, !tbaa !29
  %t497 = getelementptr %"compiler/typed:Match", ptr %t495, i32 0, i32 1
  %t498 = load { i64, ptr }, ptr %t497, !tbaa !27
  store { i64, ptr } %t498, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t500 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t500, 0
  store i64 %t502, ptr %l33, !tbaa !24
  br label %bb143
bb143:
  %t504 = load i64, ptr %l32, !tbaa !24
  %t505 = load i64, ptr %l33, !tbaa !24
  %t508 = icmp slt i64 %t504, %t505
  %t510 = xor i1 %t508, true
  br i1 %t510, label %bb144, label %bb145
bb144:
  br label %bb149
bb145:
  br label %bb146
bb146:
  %t512 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t512, ptr %l262, !tbaa !27
  %t513 = load i64, ptr %l32, !tbaa !24
  %t515 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !27
  %t517 = getelementptr ptr, ptr %t516, i64 %t513
  %t518 = load ptr, ptr %t517, !tbaa !39
  %t520 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2earm(ptr %v0, ptr %v1, ptr %t520, ptr %t518)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t524 = load i64, ptr %l32, !tbaa !24
  %t526 = add i64 %t524, 1
  store i64 %t526, ptr %l32, !tbaa !24
  br label %bb143
bb149:
  %t528 = load ptr, ptr %l26, !tbaa !29
  %t530 = getelementptr %"compiler/typed:Match", ptr %t528, i32 0, i32 2
  %t531 = load ptr, ptr %t530, !tbaa !29
  %t533 = icmp eq ptr %t531, null
  %t535 = xor i1 %t533, true
  br i1 %t535, label %bb150, label %bb151
bb150:
  %t537 = load ptr, ptr %l0, !tbaa !29
  store ptr %t537, ptr %l273, !tbaa !29
  %t538 = load ptr, ptr %l26, !tbaa !29
  %t540 = getelementptr %"compiler/typed:Match", ptr %t538, i32 0, i32 2
  %t541 = load ptr, ptr %t540, !tbaa !29
  %t543 = icmp eq ptr %t541, null
  br i1 %t543, label %bb152, label %bb153
bb151:
  br label %bb156
bb152:
  call void @__olang_check_failed(ptr @olang_loc_97fbcd283fc57d27_f3da2d8a892755b3)
  unreachable
bb153:
  br label %bb154
bb154:
  %t545 = load ptr, ptr %l26, !tbaa !29
  %t547 = getelementptr %"compiler/typed:Match", ptr %t545, i32 0, i32 2
  %t548 = load ptr, ptr %t547, !tbaa !29
  %t549 = load ptr, ptr %l273, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2earm(ptr %v0, ptr %v1, ptr %t549, ptr %t548)
  br label %bb155
bb155:
  br label %bb156
bb156:
  br label %bb186
bb157:
  %t551 = load ptr, ptr %l1, !tbaa !29
  store ptr %t551, ptr %l279, !tbaa !29
  store i1 false, ptr %l280, !tbaa !21
  %t552 = load ptr, ptr %l279, !tbaa !29
  %t553 = icmp ne ptr %t552, null
  br i1 %t553, label %bb158, label %bb159
bb158:
  %t555 = load ptr, ptr %l279, !tbaa !29
  %t556 = load i64, ptr %t555, !range !{i64 0, i64 18}
  %t558 = icmp eq i64 %t556, 14
  store i1 %t558, ptr %l280, !tbaa !21
  br label %bb159
bb159:
  %t559 = load i1, ptr %l280, !tbaa !21
  br i1 %t559, label %bb160, label %bb161
bb160:
  %t560 = load ptr, ptr %l1, !tbaa !29
  %t562 = getelementptr { i64, [5 x i64] }, ptr %t560, i32 0, i32 1
  %t563 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t562, i32 0, i32 2
  %t564 = load ptr, ptr %t563
  store ptr %t564, ptr %l35, !tbaa !29
  br label %bb162
bb161:
  br label %bb171
bb162:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load ptr, ptr %l35, !tbaa !29
  %t569 = getelementptr %"compiler/typed:Try", ptr %t567, i32 0, i32 0
  %t570 = load ptr, ptr %t569, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t566, ptr %t570)
  br label %bb163
bb163:
  %t573 = load ptr, ptr %l35, !tbaa !29
  %t575 = getelementptr %"compiler/typed:Try", ptr %t573, i32 0, i32 1
  %t576 = load { i64, ptr }, ptr %t575, !tbaa !27
  store { i64, ptr } %t576, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t578 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t578, 0
  store i64 %t580, ptr %l38, !tbaa !24
  br label %bb164
bb164:
  %t582 = load i64, ptr %l37, !tbaa !24
  %t583 = load i64, ptr %l38, !tbaa !24
  %t586 = icmp slt i64 %t582, %t583
  %t588 = xor i1 %t586, true
  br i1 %t588, label %bb165, label %bb166
bb165:
  br label %bb170
bb166:
  br label %bb167
bb167:
  %t590 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t590, ptr %l296, !tbaa !27
  %t591 = load i64, ptr %l37, !tbaa !24
  %t593 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !27
  %t595 = getelementptr ptr, ptr %t594, i64 %t591
  %t596 = load ptr, ptr %t595, !tbaa !39
  %t598 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclause(ptr %v0, ptr %v1, ptr %t598, ptr %t596)
  br label %bb168
bb168:
  br label %bb169
bb169:
  %t602 = load i64, ptr %l37, !tbaa !24
  %t604 = add i64 %t602, 1
  store i64 %t604, ptr %l37, !tbaa !24
  br label %bb164
bb170:
  br label %bb186
bb171:
  %t606 = load ptr, ptr %l1, !tbaa !29
  store ptr %t606, ptr %l303, !tbaa !29
  store i1 false, ptr %l304, !tbaa !21
  %t607 = load ptr, ptr %l303, !tbaa !29
  %t608 = icmp ne ptr %t607, null
  br i1 %t608, label %bb172, label %bb173
bb172:
  %t610 = load ptr, ptr %l303, !tbaa !29
  %t611 = load i64, ptr %t610, !range !{i64 0, i64 18}
  %t613 = icmp eq i64 %t611, 15
  store i1 %t613, ptr %l304, !tbaa !21
  br label %bb173
bb173:
  %t614 = load i1, ptr %l304, !tbaa !21
  br i1 %t614, label %bb174, label %bb175
bb174:
  %t615 = load ptr, ptr %l1, !tbaa !29
  %t617 = getelementptr { i64, [5 x i64] }, ptr %t615, i32 0, i32 1
  %t618 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t617, i32 0, i32 2
  %t619 = load ptr, ptr %t618
  store ptr %t619, ptr %l40, !tbaa !29
  br label %bb176
bb175:
  br label %bb178
bb176:
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efnVal(ptr %v0, ptr %v1, ptr %t621, ptr %t622)
  br label %bb177
bb177:
  br label %bb186
bb178:
  %t625 = load ptr, ptr %l1, !tbaa !29
  store ptr %t625, ptr %l311, !tbaa !29
  store i1 false, ptr %l312, !tbaa !21
  %t626 = load ptr, ptr %l311, !tbaa !29
  %t627 = icmp ne ptr %t626, null
  br i1 %t627, label %bb179, label %bb180
bb179:
  %t629 = load ptr, ptr %l311, !tbaa !29
  %t630 = load i64, ptr %t629, !range !{i64 0, i64 18}
  %t632 = icmp eq i64 %t630, 17
  store i1 %t632, ptr %l312, !tbaa !21
  br label %bb180
bb180:
  %t633 = load i1, ptr %l312, !tbaa !21
  br i1 %t633, label %bb181, label %bb182
bb181:
  %t634 = load ptr, ptr %l1, !tbaa !29
  %t636 = getelementptr { i64, [5 x i64] }, ptr %t634, i32 0, i32 1
  %t637 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t636, i32 0, i32 2
  %t638 = load ptr, ptr %t637
  store ptr %t638, ptr %l41, !tbaa !29
  br label %bb183
bb182:
  br label %bb185
bb183:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t641 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t640, ptr %t641)
  br label %bb184
bb184:
  br label %bb186
bb185:
  call void @__olang_check_failed(ptr @olang_loc_261689b2925f7f5_26a5fe8340cfcde1)
  unreachable
bb186:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca %"compiler/effects:root"
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca i64
  %l41 = alloca ptr
  %l47 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store %"compiler/effects:root" %t35, ptr %l19
  br label %bb10
bb10:
  %t36 = getelementptr %"compiler/effects:root", ptr %l19, i32 0, i32 0
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 17
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l22, !tbaa !21
  br i1 %t47, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t58 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexprRoot(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  store i64 %t58, ptr %l29
  br label %bb17
bb17:
  %t59 = load i64, ptr %l29, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
bb18:
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t61 = load ptr, ptr %l30, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l30, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 18}
  %t67 = icmp eq i64 %t65, 12
  store i1 %t67, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l31, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [5 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb31
bb23:
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Seq", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l41, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Seq", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = icmp eq ptr %t88, null
  br i1 %t90, label %bb26, label %bb27
bb25:
  store i64 -1, ptr %l40, !tbaa !24
  br label %bb30
bb26:
  call void @__olang_check_failed(ptr @olang_loc_b6aab166389be830_fe1a1964ddaa5424)
  unreachable
bb27:
  br label %bb28
bb28:
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Seq", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load ptr, ptr %l41, !tbaa !29
  %t98 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexprRoot(ptr %v0, ptr %v1, ptr %t96, ptr %t95)
  store i64 %t98, ptr %l47
  br label %bb29
bb29:
  %t99 = load i64, ptr %l47, !tbaa !24
  store i64 %t99, ptr %l40, !tbaa !24
  br label %bb30
bb30:
  %t100 = load i64, ptr %l40, !tbaa !24
  store i64 %t100, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i64 -1, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_28b83159130c3f56_5f8d6e7786c968a)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eextern(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l9 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l22 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i64
  %l50 = alloca i1
  %l57 = alloca ptr
  %l60 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %a1)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/effects:Effects", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t19, i32 %t23)
  store { i64, ptr } %t26, ptr %l16
  br label %bb2
bb2:
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 3
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Sig", ptr %t32, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = call i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %t28, i64 %t37)
  store i1 %t40, ptr %l22
  br label %bb3
bb3:
  %t41 = load i1, ptr %l22, !tbaa !21
  br i1 %t41, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t42, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t44, ptr %l24
  br label %bb7
bb7:
  %t45 = load i1, ptr %l24, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/effects:Effects", ptr %t48, i32 0, i32 14
  %t51 = getelementptr %"compiler/effects:Facts", ptr %t50, i32 0, i32 4
  store i1 true, ptr %t51, !tbaa !21
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t54 = call i1 @compiler_2feffects_2equickC(ptr %v0, { i64, ptr } %t52)
  store i1 %t54, ptr %l28
  br label %bb11
bb11:
  %t55 = load i1, ptr %l28, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/effects:Effects", ptr %t58, i32 0, i32 14
  %t61 = getelementptr %"compiler/effects:Facts", ptr %t60, i32 0, i32 1
  store i1 true, ptr %t61, !tbaa !21
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/effects:Effects", ptr %t62, i32 0, i32 14
  %t65 = getelementptr %"compiler/effects:Facts", ptr %t64, i32 0, i32 5
  store i1 true, ptr %t65, !tbaa !21
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t66, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t68, ptr %l33
  br label %bb15
bb15:
  %t69 = load i1, ptr %l33, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb19
bb17:
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t70, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t72, ptr %l36
  br label %bb18
bb18:
  %t73 = load i1, ptr %l36, !tbaa !21
  store i1 %t73, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t74 = load i1, ptr %l34, !tbaa !21
  br i1 %t74, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb23
bb21:
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t75, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t77, ptr %l39
  br label %bb22
bb22:
  %t78 = load i1, ptr %l39, !tbaa !21
  store i1 %t78, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l37, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/effects:Effects", ptr %t80, i32 0, i32 14
  %t83 = getelementptr %"compiler/effects:Facts", ptr %t82, i32 0, i32 11
  store i1 true, ptr %t83, !tbaa !21
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t86 = call i64 @compiler_2feffects_2ecapOf(ptr %v0, { i64, ptr } %t84)
  store i64 %t86, ptr %l42
  br label %bb27
bb27:
  %t87 = load i64, ptr %l42, !tbaa !24
  store i64 %t87, ptr %l4, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t90 = icmp ne i64 %t88, 0
  br i1 %t90, label %bb28, label %bb29
bb28:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecap(ptr %v0, ptr %t92, i64 %t93)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/effects:Effects", ptr %t96, i32 0, i32 20
  %t99 = load i64, ptr %t98, !tbaa !24
  %t101 = icmp sge i64 %t99, 0
  br i1 %t101, label %bb32, label %bb33
bb32:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/effects:Effects", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 10
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/effects:Effects", ptr %t112, i32 0, i32 20
  %t115 = load i64, ptr %t114, !tbaa !24
  %t118 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t111, i64 %t115)
  store ptr %t118, ptr %l57
  br label %bb34
bb33:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb36
bb34:
  %t119 = load ptr, ptr %l57, !tbaa !29
  %t121 = getelementptr %"compiler/load:Module", ptr %t119, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t122, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t124, ptr %l60
  br label %bb35
bb35:
  %t125 = load i1, ptr %l60, !tbaa !21
  %t126 = xor i1 %t125, true
  store i1 %t126, ptr %l50, !tbaa !21
  br label %bb36
bb36:
  %t128 = load i1, ptr %l50, !tbaa !21
  br i1 %t128, label %bb37, label %bb38
bb37:
  %t131 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t133 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t131, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t133, ptr %l65
  br label %bb39
bb38:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb40
bb39:
  %t134 = load i1, ptr %l65, !tbaa !21
  %t135 = xor i1 %t134, true
  store i1 %t135, ptr %l63, !tbaa !21
  br label %bb40
bb40:
  %t137 = load i1, ptr %l63, !tbaa !21
  br i1 %t137, label %bb41, label %bb42
bb41:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr @G_2ecompiler_2feffects_2eCapC, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecap(ptr %v0, ptr %t138, i64 %t139)
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l33 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l47 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb32
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t11 = load ptr, ptr %l14, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l14, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 3}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t21, i32 0, i32 0
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l2, !tbaa !23
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  br label %bb11
bb10:
  br label %bb23
bb11:
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/effects:Effects", ptr %t37, i32 0, i32 14
  %t40 = getelementptr %"compiler/effects:Facts", ptr %t39, i32 0, i32 0
  store i1 true, ptr %t40, !tbaa !21
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t55, ptr %l33, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Capture", ptr %t61, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t63, ptr %t67)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l5, !tbaa !24
  br label %bb15
bb21:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/effects:Effects", ptr %t75, i32 0, i32 15
  %t78 = load i32, ptr %l2, !tbaa !23
  %t80 = sext i32 %t78 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t77, i64 %t80)
  br label %bb22
bb22:
  br label %bb32
bb23:
  %t83 = load ptr, ptr %l1, !tbaa !29
  store ptr %t83, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t84 = load ptr, ptr %l46, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb24, label %bb25
bb24:
  %t87 = load ptr, ptr %l46, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 3}
  %t90 = icmp eq i64 %t88, 2
  store i1 %t90, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  %t91 = load i1, ptr %l47, !tbaa !21
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { i32, ptr, i32 }, ptr %t94, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l8, !tbaa !23
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { i32, ptr, i32 }, ptr %t100, i32 0, i32 1
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l9, !tbaa !29
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/effects:Effects", ptr %t104, i32 0, i32 14
  %t107 = getelementptr %"compiler/effects:Facts", ptr %t106, i32 0, i32 0
  store i1 true, ptr %t107, !tbaa !21
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t108, ptr %t109)
  br label %bb29
bb29:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/effects:Effects", ptr %t113, i32 0, i32 15
  %t116 = load i32, ptr %l8, !tbaa !23
  %t118 = sext i32 %t116 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t115, i64 %t118)
  br label %bb30
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_d8634726df7208f7_383307572af5b0b3)
  unreachable
bb32:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 8}
  %t18 = icmp eq i64 %t16, 3
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalRoot(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i1 %t30, ptr %l18
  br label %bb12
bb12:
  %t31 = load i1, ptr %l18, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
bb13:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb14, label %bb15
bb14:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 8}
  %t39 = icmp eq i64 %t37, 4
  store i1 %t39, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t40 = load i1, ptr %l20, !tbaa !21
  br i1 %t40, label %bb16, label %bb17
bb16:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb25
bb18:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/effects:Effects", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  store ptr %t52, ptr %l27, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Elem", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t56)
  store i32 %t58, ptr %l30
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l27, !tbaa !29
  %t60 = load i32, ptr %l30, !tbaa !23
  %t61 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t61, ptr %l31
  br label %bb20
bb20:
  %t62 = load i1, ptr %l31, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Elem", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalRoot(ptr %v0, ptr %v1, ptr %t65, ptr %t69)
  store i1 %t72, ptr %l37
  br label %bb23
bb22:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb24
bb23:
  %t73 = load i1, ptr %l37, !tbaa !21
  store i1 %t73, ptr %l33, !tbaa !21
  br label %bb24
bb24:
  %t74 = load i1, ptr %l33, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
bb25:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t76 = load ptr, ptr %l38, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb26, label %bb27
bb26:
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 8}
  %t82 = icmp eq i64 %t80, 5
  store i1 %t82, ptr %l39, !tbaa !21
  br label %bb27
bb27:
  %t83 = load i1, ptr %l39, !tbaa !21
  br i1 %t83, label %bb28, label %bb29
bb28:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Payload", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t97 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalRoot(ptr %v0, ptr %v1, ptr %t90, ptr %t94)
  store i1 %t97, ptr %l47
  br label %bb31
bb31:
  %t98 = load i1, ptr %l47, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @olang_loc_5ee506974b9441c7_64c0c11887ed9ad3)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2egrow(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca %"compiler/effects:Facts"
  %l19 = alloca ptr
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/effects:Facts"
  %l37 = alloca i64
  %l43 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l73 = alloca ptr
  %l78 = alloca ptr
  %l84 = alloca ptr
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 6
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t17, i32 0, i32 2
  store ptr %t19, ptr %l16, !tbaa !29
  %t20 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s1)
  store %"compiler/effects:Facts" %t20, ptr %l17
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = load %"compiler/effects:Facts", ptr %l17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ePush_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t21, %"compiler/effects:Facts" %t22)
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/effects:Effects", ptr %t23, i32 0, i32 3
  store ptr %t25, ptr %l19, !tbaa !29
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l20
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %s1, ptr %t27, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28)
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/effects:Effects", ptr %t29, i32 0, i32 4
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l23
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l22, !tbaa !29
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H691765597a1d0d55e0f84306543aa643(ptr %v0, ptr %s1, ptr %t33, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34)
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/effects:Effects", ptr %t35, i32 0, i32 5
  store ptr %t37, ptr %l25, !tbaa !29
  %t38 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s1)
  store %"compiler/effects:Facts" %t38, ptr %l26
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t40 = load %"compiler/effects:Facts", ptr %l26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ePush_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t39, %"compiler/effects:Facts" %t40)
  br label %bb14
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/effects:Effects", ptr %t41, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t43, i64 0)
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/effects:Effects", ptr %t45, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t47, i64 -1)
  br label %bb16
bb16:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/effects:Effects", ptr %t49, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t51, i64 0)
  br label %bb17
bb17:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/effects:Effects", ptr %t53, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t55, i1 false)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb19:
  br label %bb1
bb20:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/effects:Effects", ptr %t57, i32 0, i32 7
  %t61 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t59)
  store i64 %t61, ptr %l37
  br label %bb21
bb21:
  %t62 = load i64, ptr %l37, !tbaa !24
  %t63 = icmp eq i64 %t62, 0
  br i1 %t63, label %bb22, label %bb23
bb22:
  store i64 0, ptr %l1, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/effects:Effects", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 10
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t73)
  store i64 %t75, ptr %l43
  br label %bb24
bb23:
  br label %bb43
bb24:
  %t76 = load i64, ptr %l43, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t77 = load i64, ptr %l2, !tbaa !24
  %t78 = load i64, ptr %l1, !tbaa !24
  %t81 = icmp sgt i64 %t77, %t78
  br i1 %t81, label %bb25, label %bb26
bb25:
  %t83 = load i64, ptr %l3, !tbaa !24
  %t85 = icmp sgt i64 %t83, 0
  br i1 %t85, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb30
bb27:
  %t87 = load i64, ptr %l2, !tbaa !24
  %t88 = load i64, ptr %l1, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load i64, ptr %l3, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l3, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  store i64 %t101, ptr %l50, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb29
bb29:
  %t103 = load i64, ptr %l50, !tbaa !24
  store i64 %t103, ptr %l47, !tbaa !24
  br label %bb30
bb30:
  %t104 = load i64, ptr %l47, !tbaa !24
  store i64 %t104, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb31
bb31:
  %t105 = load i64, ptr %l5, !tbaa !24
  %t106 = load i64, ptr %l4, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb32, label %bb33
bb32:
  br label %bb42
bb33:
  br label %bb34
bb34:
  %t113 = load i64, ptr %l1, !tbaa !24
  %t114 = load i64, ptr %l5, !tbaa !24
  %t115 = load i64, ptr %l3, !tbaa !24
  %t118 = mul i64 %t114, %t115
  %t121 = add i64 %t113, %t118
  store i64 %t121, ptr %l6, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/effects:Effects", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 10
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t131, i64 %t132)
  store ptr %t135, ptr %l73
  br label %bb35
bb35:
  %t136 = load ptr, ptr %l73, !tbaa !29
  %t138 = getelementptr %"compiler/load:Module", ptr %t136, i32 0, i32 4
  %t139 = load i64, ptr %t138, !tbaa !24
  %t141 = icmp sge i64 %t139, 0
  br i1 %t141, label %bb36, label %bb37
bb36:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/effects:Effects", ptr %t143, i32 0, i32 7
  store ptr %t145, ptr %l78, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/effects:Effects", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/load:Loader", ptr %t152, i32 0, i32 10
  %t155 = load i64, ptr %l6, !tbaa !24
  %t158 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t154, i64 %t155)
  store ptr %t158, ptr %l84
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t159 = load ptr, ptr %l84, !tbaa !29
  %t161 = getelementptr %"compiler/load:Module", ptr %t159, i32 0, i32 4
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load i64, ptr %l6, !tbaa !24
  %t164 = load ptr, ptr %l78, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t164, i64 %t162, i64 %t163)
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t167 = load i64, ptr %l5, !tbaa !24
  %t169 = add i64 %t167, 1
  store i64 %t169, ptr %l5, !tbaa !24
  br label %bb31
bb42:
  br label %bb43
bb43:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2emutGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/effects:pair"
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/names:Entry"
  %l11 = alloca %"compiler/effects:pair"
  %l15 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i64
  %l30 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca %"compiler/names:Entry"
  %l51 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i32, ptr %l2, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"compiler/effects:pair" @compiler_2feffects_3apair_2ector(ptr %s0, i64 %t1, i64 %t4)
  store %"compiler/effects:pair" %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load %"compiler/effects:pair", ptr %l11
  store %"compiler/effects:pair" %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 8
  %t12 = load %"compiler/effects:pair", ptr %l3
  %t15 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_H7835af935af759534f3892df019d3666(ptr %v0, ptr %t11, %"compiler/effects:pair" %t12)
  store i1 %t15, ptr %l15
  br label %bb2
bb2:
  %t16 = load i1, ptr %l15, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t17, i32 0, i32 8
  %t20 = load %"compiler/effects:pair", ptr %l3
  %t23 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_H5e2f333902255d77192898689554d128(ptr %v0, ptr %t19, %"compiler/effects:pair" %t20)
  %t24 = extractvalue { i32, i1 } %t23, 1
  %t25 = extractvalue { i32, i1 } %t23, 0
  store i32 %t25, ptr %l21
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb6, label %ok.27, !prof !99
ok.27:
  store i1 %t24, ptr %l20
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t28 = load i1, ptr %l20, !tbaa !21
  store i1 %t28, ptr %l16, !tbaa !21
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i1, ptr %l16, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
bb9:
  store i1 false, ptr %l4, !tbaa !21
  %t30 = load i64, ptr %l1, !tbaa !24
  %t32 = icmp sge i64 %t30, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load i64, ptr %l1, !tbaa !24
  store i64 %t34, ptr %l25, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/effects:Effects", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/names:Resolver", ptr %t41, i32 0, i32 1
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H1e7e683fc0332c06b6c705cd46691777(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l30
  br label %bb12
bb11:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb13
bb12:
  %t46 = load i64, ptr %l25, !tbaa !24
  %t47 = load i64, ptr %l30, !tbaa !24
  %t48 = icmp slt i64 %t46, %t47
  store i1 %t48, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t50 = load i1, ptr %l24, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/effects:Effects", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/names:Resolver", ptr %t57, i32 0, i32 1
  %t60 = load i64, ptr %l1, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l37
  br label %bb16
bb15:
  br label %bb31
bb16:
  %t64 = load ptr, ptr %l37, !tbaa !29
  %t66 = getelementptr %"compiler/names:Table", ptr %t64, i32 0, i32 0
  store ptr %t66, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t68 = load i64, ptr %l6, !tbaa !24
  store i64 %t68, ptr %l40, !tbaa !24
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l42
  br label %bb18
bb18:
  %t72 = load i64, ptr %l40, !tbaa !24
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = icmp slt i64 %t72, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb19, label %bb20
bb19:
  br label %bb30
bb20:
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store %"compiler/names:Entry" %t82, ptr %l47
  br label %bb22
bb22:
  %t83 = load %"compiler/names:Entry", ptr %l47
  store %"compiler/names:Entry" %t83, ptr %l7
  %t84 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load i32, ptr %l2, !tbaa !23
  %t89 = icmp eq i32 %t85, %t86
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t91 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 3
  %t92 = load i1, ptr %t91, !tbaa !21
  store i1 %t92, ptr %l51, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb25
bb25:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l6, !tbaa !24
  br label %bb17
bb30:
  br label %bb31
bb31:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/effects:Effects", ptr %t99, i32 0, i32 8
  %t102 = load %"compiler/effects:pair", ptr %l3
  %t103 = load i1, ptr %l4, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_Ha1bc2f35f7d195c0ca99c509224bae7a(ptr %v0, ptr %t101, %"compiler/effects:pair" %t102, i1 %t103)
  br label %bb32
bb32:
  %t107 = load i1, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t107, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a2, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estore(ptr %v0, ptr %v1, ptr %t3, ptr %t4)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceParts(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceParts(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l28 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l13, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb57
bb10:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 1
  store i1 %t26, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l18, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t30, i32 0, i32 2
  %t32 = load i64, ptr %t31
  store i64 %t32, ptr %l2, !tbaa !24
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t36, i32 0, i32 3
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l3, !tbaa !23
  br label %bb15
bb14:
  br label %bb20
bb15:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i32, ptr %l3, !tbaa !23
  %t46 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2emutGlobal(ptr %v0, ptr %t40, i64 %t41, i32 %t42)
  store i1 %t46, ptr %l28
  br label %bb16
bb16:
  %t47 = load i1, ptr %l28, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/effects:Effects", ptr %t48, i32 0, i32 14
  %t51 = getelementptr %"compiler/effects:Facts", ptr %t50, i32 0, i32 3
  store i1 true, ptr %t51, !tbaa !21
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb57
bb20:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb21, label %bb22
bb21:
  %t56 = load ptr, ptr %l30, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 8}
  %t59 = icmp eq i64 %t57, 2
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb22
bb22:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb23, label %bb24
bb23:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t63, i32 0, i32 2
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  br label %bb26
bb26:
  br label %bb57
bb27:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t73 = load ptr, ptr %l39, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb28, label %bb29
bb28:
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 8}
  %t79 = icmp eq i64 %t77, 3
  store i1 %t79, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb30, label %bb31
bb30:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l5, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceParts(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  br label %bb33
bb33:
  br label %bb57
bb34:
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t92 = load ptr, ptr %l47, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb35, label %bb36
bb35:
  %t95 = load ptr, ptr %l47, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 8}
  %t98 = icmp eq i64 %t96, 4
  store i1 %t98, ptr %l48, !tbaa !21
  br label %bb36
bb36:
  %t99 = load i1, ptr %l48, !tbaa !21
  br i1 %t99, label %bb37, label %bb38
bb37:
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t102, i32 0, i32 2
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l6, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Elem", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceParts(ptr %v0, ptr %v1, ptr %t106, ptr %t110)
  br label %bb40
bb40:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Elem", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t113, ptr %t117)
  br label %bb41
bb41:
  br label %bb57
bb42:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t122 = load ptr, ptr %l60, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb43, label %bb44
bb43:
  %t125 = load ptr, ptr %l60, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 8}
  %t128 = icmp eq i64 %t126, 5
  store i1 %t128, ptr %l61, !tbaa !21
  br label %bb44
bb44:
  %t129 = load i1, ptr %l61, !tbaa !21
  br i1 %t129, label %bb45, label %bb46
bb45:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l7, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l7, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Payload", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceParts(ptr %v0, ptr %v1, ptr %t136, ptr %t140)
  br label %bb48
bb48:
  br label %bb57
bb49:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t144 = load ptr, ptr %l69, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb50, label %bb51
bb50:
  %t147 = load ptr, ptr %l69, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 8}
  %t150 = icmp eq i64 %t148, 6
  store i1 %t150, ptr %l70, !tbaa !21
  br label %bb51
bb51:
  %t151 = load i1, ptr %l70, !tbaa !21
  br i1 %t151, label %bb52, label %bb53
bb52:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t154, i32 0, i32 2
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l8, !tbaa !29
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  br label %bb55
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_8e774b84f9d07387_321b570aadbfd9f3)
  unreachable
bb57:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/effects:root"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca %"compiler/effects:root"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l26 = alloca %"compiler/effects:root"
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca %"compiler/effects:root"
  %l37 = alloca i64
  %l39 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca %"compiler/effects:root"
  %l48 = alloca ptr
  %l49 = alloca i1
  %l57 = alloca %"compiler/effects:root"
  %l58 = alloca ptr
  %l59 = alloca i1
  %l66 = alloca i64
  %l68 = alloca %"compiler/effects:root"
  %l69 = alloca %"compiler/effects:root"
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/effects:root"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t20 = call %"compiler/effects:root" @compiler_2feffects_3aroot_2ector(ptr %s1, i64 %t18, i1 false)
  store %"compiler/effects:root" %t20, ptr %l17
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  %t21 = load %"compiler/effects:root", ptr %l17
  store %"compiler/effects:root" %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store %"compiler/effects:root" %t41, ptr %l26
  br label %bb13
bb13:
  %t42 = load %"compiler/effects:root", ptr %l26
  store %"compiler/effects:root" %t42, ptr %rv
  br label %ret
bb14:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l28, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb27
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Elem", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t58, ptr %t62)
  store %"compiler/effects:root" %t65, ptr %l36
  br label %bb20
bb20:
  %t66 = load %"compiler/effects:root", ptr %l36
  store %"compiler/effects:root" %t66, ptr %l5
  %t67 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l37, !tbaa !24
  %t69 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 1
  %t70 = load i1, ptr %t69, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb25
bb22:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/effects:Effects", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  store ptr %t77, ptr %l42, !tbaa !29
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Elem", ptr %t78, i32 0, i32 0
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t81)
  store i32 %t83, ptr %l45
  br label %bb23
bb23:
  %t84 = load ptr, ptr %l42, !tbaa !29
  %t85 = load i32, ptr %l45, !tbaa !23
  %t86 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t86, ptr %l46
  br label %bb24
bb24:
  %t87 = load i1, ptr %l46, !tbaa !21
  store i1 %t87, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i64, ptr %l37, !tbaa !24
  %t89 = load i1, ptr %l39, !tbaa !21
  %t90 = call %"compiler/effects:root" @compiler_2feffects_3aroot_2ector(ptr %s3, i64 %t88, i1 %t89)
  store %"compiler/effects:root" %t90, ptr %l47
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  %t91 = load %"compiler/effects:root", ptr %l47
  store %"compiler/effects:root" %t91, ptr %rv
  br label %ret
bb27:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t93 = load ptr, ptr %l48, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 8}
  %t99 = icmp eq i64 %t97, 5
  store i1 %t99, ptr %l49, !tbaa !21
  br label %bb29
bb29:
  %t100 = load i1, ptr %l49, !tbaa !21
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Payload", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t114 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t107, ptr %t111)
  store %"compiler/effects:root" %t114, ptr %l57
  br label %bb33
bb33:
  %t115 = load %"compiler/effects:root", ptr %l57
  store %"compiler/effects:root" %t115, ptr %rv
  br label %ret
bb34:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t117 = load ptr, ptr %l58, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb35, label %bb36
bb35:
  %t120 = load ptr, ptr %l58, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 8}
  %t123 = icmp eq i64 %t121, 2
  store i1 %t123, ptr %l59, !tbaa !21
  br label %bb36
bb36:
  %t124 = load i1, ptr %l59, !tbaa !21
  br i1 %t124, label %bb37, label %bb38
bb37:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t127, i32 0, i32 2
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l7, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  store %olang.scope zeroinitializer, ptr %s5
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l7, !tbaa !29
  %t135 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexprRoot(ptr %v0, ptr %v1, ptr %t131, ptr %t132)
  store i64 %t135, ptr %l66
  br label %bb40
bb40:
  %t136 = load i64, ptr %l66, !tbaa !24
  %t139 = call %"compiler/effects:root" @compiler_2feffects_3aroot_2ector(ptr %s5, i64 %t136, i1 true)
  store %"compiler/effects:root" %t139, ptr %l68
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s5)
  %t140 = load %"compiler/effects:root", ptr %l68
  store %"compiler/effects:root" %t140, ptr %rv
  br label %ret
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb47
bb45:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = call %"compiler/effects:root" @compiler_2feffects_3aroot_2ector(ptr %s6, i64 -1, i1 false)
  store %"compiler/effects:root" %t141, ptr %l69
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  %t142 = load %"compiler/effects:root", ptr %l69
  store %"compiler/effects:root" %t142, ptr %rv
  br label %ret
bb47:
  call void @__olang_check_failed(ptr @olang_loc_def19e55677a13ff_78d59d2dfbb79d83)
  unreachable
ret:
  %rr = load %"compiler/effects:root", ptr %rv
  ret %"compiler/effects:root" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l22 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t3 = trunc i64 29 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 14
  %t9 = getelementptr %"compiler/effects:Facts", ptr %t8, i32 0, i32 10
  store i1 true, ptr %t9, !tbaa !21
  br label %bb23
bb4:
  %t10 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t12 = trunc i64 25 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  %t15 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t17 = trunc i64 26 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t20 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t22 = trunc i64 27 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  %t25 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t27 = trunc i64 28 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb14, label %bb15
bb14:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t37, ptr %l22, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 0
  %t41 = load ptr, ptr %t40, !tbaa !39
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritten(ptr %v0, ptr %v1, ptr %t36, ptr %t41)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_31e57a958c31a5ba_705aefa950dbf3e6)
  unreachable
bb23:
  %t44 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t44, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l5, !tbaa !24
  br label %bb24
bb24:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb25, label %bb26
bb25:
  br label %bb30
bb26:
  br label %bb27
bb27:
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t58, ptr %l31, !tbaa !27
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr ptr, ptr %t62, i64 %t59
  %t64 = load ptr, ptr %t63, !tbaa !39
  %t66 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t66, ptr %t64)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb24
bb30:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i64
  %l41 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i1
  %l57 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca ptr
  %l73 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i32
  %l87 = alloca i64
  %l88 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t7 = load ptr, ptr %l15, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l15, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 11
  store i1 %t13, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l16, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Cond", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = icmp eq ptr %t24, null
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l26, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Cond", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb15
bb11:
  call void @__olang_check_failed(ptr @olang_loc_e883a08fe0a2dfcb_10d50552a173805f)
  unreachable
bb12:
  br label %bb13
bb13:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Cond", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t48 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %t45, ptr %t41, i64 %t44)
  store i64 %t48, ptr %l34
  br label %bb14
bb14:
  %t49 = load i64, ptr %l34, !tbaa !24
  store i64 %t49, ptr %l25, !tbaa !24
  br label %bb15
bb15:
  %t50 = load i64, ptr %l25, !tbaa !24
  store i64 %t50, ptr %l35, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Cond", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  %t59 = add i64 %t57, 1
  %t63 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %t52, ptr %t56, i64 %t59)
  store i64 %t63, ptr %l41
  br label %bb16
bb16:
  %t64 = load i64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l41, !tbaa !24
  %t66 = or i64 %t64, %t65
  store i64 %t66, ptr %rv
  br label %ret
bb17:
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t69 = load ptr, ptr %l43, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t72 = load ptr, ptr %l43, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 18}
  %t75 = icmp eq i64 %t73, 13
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb19
bb19:
  %t76 = load i1, ptr %l44, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 2
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb36
bb22:
  store i64 0, ptr %l6, !tbaa !24
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Match", ptr %t83, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  store i64 %t90, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb24, label %bb25
bb24:
  br label %bb35
bb25:
  br label %bb26
bb26:
  %t100 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t100, ptr %l57, !tbaa !27
  %t101 = load i64, ptr %l8, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr ptr, ptr %t104, i64 %t101
  %t106 = load ptr, ptr %t105, !tbaa !39
  store ptr %t106, ptr %l10, !tbaa !29
  %t108 = load ptr, ptr %l10, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Arm", ptr %t108, i32 0, i32 4
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb27, label %bb28
bb27:
  %t117 = load i64, ptr %l6, !tbaa !24
  store i64 %t117, ptr %l64, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l65, !tbaa !29
  %t119 = load ptr, ptr %l10, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Arm", ptr %t119, i32 0, i32 4
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb29, label %bb30
bb28:
  br label %bb33
bb29:
  call void @__olang_check_failed(ptr @olang_loc_be89c63eecba24dc_20b8a06f464464c0)
  unreachable
bb30:
  br label %bb31
bb31:
  %t126 = load ptr, ptr %l10, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Arm", ptr %t126, i32 0, i32 4
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load i64, ptr %l2, !tbaa !24
  %t132 = add i64 %t130, 1
  %t133 = load ptr, ptr %l65, !tbaa !29
  %t136 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %t133, ptr %t129, i64 %t132)
  store i64 %t136, ptr %l73
  br label %bb32
bb32:
  %t137 = load i64, ptr %l64, !tbaa !24
  %t138 = load i64, ptr %l73, !tbaa !24
  %t139 = or i64 %t137, %t138
  store i64 %t139, ptr %l6, !tbaa !24
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t141 = load i64, ptr %l8, !tbaa !24
  %t143 = add i64 %t141, 1
  store i64 %t143, ptr %l8, !tbaa !24
  br label %bb23
bb35:
  %t145 = load i64, ptr %l6, !tbaa !24
  store i64 %t145, ptr %rv
  br label %ret
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_da29f57e967b0d58_398b0b5997e9910c)
  unreachable
bb41:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t151 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexprRoot(ptr %v0, ptr %v1, ptr %t147, ptr %t148)
  store i64 %t151, ptr %l80
  br label %bb42
bb42:
  %t152 = load i64, ptr %l80, !tbaa !24
  store i64 %t152, ptr %l11, !tbaa !24
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/effects:Effects", ptr %t153, i32 0, i32 17
  %t156 = load i64, ptr %l11, !tbaa !24
  %t159 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t155, i64 %t156)
  %t160 = extractvalue { i32, i64 } %t159, 1
  %t161 = extractvalue { i32, i64 } %t159, 0
  store i32 %t161, ptr %l86
  %t162 = icmp ne i32 %t161, 0
  br i1 %t162, label %bb44, label %ok.163, !prof !99
ok.163:
  store i64 %t160, ptr %l85
  br label %bb43
bb43:
  %t164 = load i64, ptr %l85, !tbaa !24
  store i64 %t164, ptr %l81, !tbaa !24
  br label %bb46
bb44:
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l81, !tbaa !24
  br label %bb46
bb46:
  %t165 = load i64, ptr %l81, !tbaa !24
  %t166 = call i64 @compiler_2feffects_2eparamBit(i64 %t165)
  store i64 %t166, ptr %l87
  br label %bb47
bb47:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/effects:Effects", ptr %t167, i32 0, i32 18
  %t170 = load i64, ptr %l11, !tbaa !24
  %t173 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t169, i64 %t170)
  %t174 = extractvalue { i32, i64 } %t173, 1
  %t175 = extractvalue { i32, i64 } %t173, 0
  store i32 %t175, ptr %l93
  %t176 = icmp ne i32 %t175, 0
  br i1 %t176, label %bb49, label %ok.177, !prof !99
ok.177:
  store i64 %t174, ptr %l92
  br label %bb48
bb48:
  %t178 = load i64, ptr %l92, !tbaa !24
  store i64 %t178, ptr %l88, !tbaa !24
  br label %bb51
bb49:
  br label %bb50
bb50:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l88, !tbaa !24
  br label %bb51
bb51:
  %t179 = load i64, ptr %l87, !tbaa !24
  %t180 = load i64, ptr %l88, !tbaa !24
  %t181 = or i64 %t179, %t180
  store i64 %t181, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2esettle(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/effects:Facts"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/effects:Facts"
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/effects:link"
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca %"compiler/effects:Facts"
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i64
  %l57 = alloca i64
  %l58 = alloca ptr
  %l62 = alloca %"compiler/effects:Facts"
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca i64
  %l73 = alloca i64
  %l78 = alloca i64
  %l84 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i64
  %l91 = alloca i64
  %l93 = alloca ptr
  %l97 = alloca %"compiler/effects:Facts"
  %l105 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i64
  %l117 = alloca %"compiler/effects:Facts"
  %l128 = alloca i64
  %l130 = alloca i64
  %l135 = alloca i64
  %l139 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca i64
  %l145 = alloca i64
  %l150 = alloca %"compiler/effects:link"
  %l153 = alloca i1
  %l154 = alloca i64
  %l157 = alloca i64
  %l159 = alloca i1
  %l163 = alloca i64
  %l167 = alloca i1
  %l168 = alloca i1
  %l172 = alloca i64
  %l177 = alloca %"compiler/effects:Facts"
  %l180 = alloca i1
  %l182 = alloca i1
  %l186 = alloca %"compiler/effects:Facts"
  %l189 = alloca i1
  %l194 = alloca %"compiler/effects:Facts"
  %l195 = alloca i64
  %l197 = alloca i64
  %l202 = alloca ptr
  %l210 = alloca i64
  %l212 = alloca i64
  %l217 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s20 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t1, ptr %l31
  br label %bb1
bb1:
  %t2 = load %"compiler/effects:Facts", ptr %l31
  store %"compiler/effects:Facts" %t2, ptr %l2
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l32
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l34, !tbaa !24
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l36
  br label %bb4
bb4:
  %t11 = load i64, ptr %l34, !tbaa !24
  %t12 = load i64, ptr %l36, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l41
  br label %bb8
bb8:
  %t22 = load i64, ptr %l41, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l3, i64 %t22, i1 true)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l5, !tbaa !24
  br label %bb3
bb11:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t30)
  store i64 %t32, ptr %l47
  br label %bb12
bb12:
  %t33 = load i64, ptr %l47, !tbaa !24
  %t34 = icmp sgt i64 %t33, 1
  store i1 %t34, ptr %l7, !tbaa !21
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t38 = load i64, ptr %l9, !tbaa !24
  store i64 %t38, ptr %l50, !tbaa !24
  %t39 = load ptr, ptr %l8, !tbaa !29
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t39)
  store i64 %t41, ptr %l52
  br label %bb14
bb14:
  %t42 = load i64, ptr %l50, !tbaa !24
  %t43 = load i64, ptr %l52, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb16:
  br label %bb17
bb17:
  %t48 = load ptr, ptr %l8, !tbaa !29
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t48, i64 %t49)
  store i64 %t52, ptr %l57
  br label %bb18
bb18:
  %t53 = load i64, ptr %l57, !tbaa !24
  store i64 %t53, ptr %l10, !tbaa !24
  store ptr %l2, ptr %l58, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/effects:Effects", ptr %t54, i32 0, i32 2
  %t57 = load i64, ptr %l10, !tbaa !24
  %t60 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t56, i64 %t57)
  store %"compiler/effects:Facts" %t60, ptr %l62
  br label %bb19
bb19:
  %t61 = load %"compiler/effects:Facts", ptr %l62
  %t62 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 80, i64 8)
  store %"compiler/effects:Facts" %t61, ptr %t62
  %t63 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s5, ptr %t63, ptr %t62)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/effects:Effects", ptr %t65, i32 0, i32 3
  %t68 = load i64, ptr %l10, !tbaa !24
  %t71 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %s6, ptr %t67, i64 %t68)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %l67
  br label %bb21
bb21:
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s6, ptr %l67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l69
  br label %bb22
bb22:
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  %t75 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %t75
  store ptr %t75, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  %t77 = load i64, ptr %l12, !tbaa !24
  store i64 %t77, ptr %l71, !tbaa !24
  %t78 = load ptr, ptr %l11, !tbaa !29
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s6, ptr %t78)
  store i64 %t80, ptr %l73
  br label %bb24
bb24:
  %t81 = load i64, ptr %l71, !tbaa !24
  %t82 = load i64, ptr %l73, !tbaa !24
  %t83 = icmp slt i64 %t81, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb26:
  br label %bb27
bb27:
  %t87 = load ptr, ptr %l11, !tbaa !29
  %t88 = load i64, ptr %l12, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s6, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l78
  br label %bb28
bb28:
  %t92 = load i64, ptr %l78, !tbaa !24
  store i64 %t92, ptr %l13, !tbaa !24
  %t93 = load i64, ptr %l13, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t97 = icmp eq i64 %t93, %t94
  br i1 %t97, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l3, i64 %t99)
  store i1 %t102, ptr %l84
  br label %bb32
bb32:
  %t103 = load i1, ptr %l84, !tbaa !21
  br i1 %t103, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb34:
  br label %bb35
bb35:
  %t104 = load i64, ptr %l13, !tbaa !24
  %t106 = icmp slt i64 %t104, 0
  br i1 %t106, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb39
bb37:
  %t108 = load i64, ptr %l13, !tbaa !24
  store i64 %t108, ptr %l88, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/effects:Effects", ptr %t109, i32 0, i32 1
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t111)
  store i64 %t113, ptr %l91
  br label %bb38
bb38:
  %t114 = load i64, ptr %l88, !tbaa !24
  %t115 = load i64, ptr %l91, !tbaa !24
  %t116 = icmp sge i64 %t114, %t115
  store i1 %t116, ptr %l87, !tbaa !21
  br label %bb39
bb39:
  %t118 = load i1, ptr %l87, !tbaa !21
  br i1 %t118, label %bb40, label %bb41
bb40:
  %t119 = getelementptr %"compiler/effects:Facts", ptr %l2, i32 0, i32 12
  store i1 true, ptr %t119, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb41:
  br label %bb42
bb42:
  store ptr %l2, ptr %l93, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/effects:Effects", ptr %t120, i32 0, i32 5
  %t123 = load i64, ptr %l13, !tbaa !24
  %t126 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t122, i64 %t123)
  store %"compiler/effects:Facts" %t126, ptr %l97
  br label %bb43
bb43:
  %t127 = load %"compiler/effects:Facts", ptr %l97
  %t128 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 80, i64 8)
  store %"compiler/effects:Facts" %t127, ptr %t128
  %t129 = load ptr, ptr %l93, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s7, ptr %t129, ptr %t128)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb45:
  %t131 = load i64, ptr %l12, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l12, !tbaa !24
  br label %bb23
bb46:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  br label %bb47
bb47:
  %t135 = load i64, ptr %l9, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l9, !tbaa !24
  br label %bb13
bb48:
  %t139 = load i1, ptr %l7, !tbaa !21
  br i1 %t139, label %bb49, label %bb50
bb49:
  %t141 = getelementptr %"compiler/effects:Facts", ptr %l2, i32 0, i32 7
  store i1 true, ptr %t141, !tbaa !21
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb52
bb52:
  %t144 = load i64, ptr %l15, !tbaa !24
  store i64 %t144, ptr %l105, !tbaa !24
  %t145 = load ptr, ptr %l14, !tbaa !29
  %t147 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t145)
  store i64 %t147, ptr %l107
  br label %bb53
bb53:
  %t148 = load i64, ptr %l105, !tbaa !24
  %t149 = load i64, ptr %l107, !tbaa !24
  %t150 = icmp slt i64 %t148, %t149
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb54, label %bb55
bb54:
  br label %bb61
bb55:
  br label %bb56
bb56:
  %t154 = load ptr, ptr %l14, !tbaa !29
  %t155 = load i64, ptr %l15, !tbaa !24
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t154, i64 %t155)
  store i64 %t158, ptr %l112
  br label %bb57
bb57:
  %t159 = load i64, ptr %l112, !tbaa !24
  store i64 %t159, ptr %l16, !tbaa !24
  %t160 = load %"compiler/effects:Facts", ptr %l2
  store %"compiler/effects:Facts" %t160, ptr %l17
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/effects:Effects", ptr %t162, i32 0, i32 2
  %t165 = load i64, ptr %l16, !tbaa !24
  %t168 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t164, i64 %t165)
  store %"compiler/effects:Facts" %t168, ptr %l117
  br label %bb58
bb58:
  %t169 = getelementptr %"compiler/effects:Facts", ptr %l117, i32 0, i32 15
  %t170 = load i64, ptr %t169, !tbaa !24
  %t172 = getelementptr %"compiler/effects:Facts", ptr %l17, i32 0, i32 15
  store i64 %t170, ptr %t172, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/effects:Effects", ptr %t173, i32 0, i32 5
  %t176 = load i64, ptr %l16, !tbaa !24
  %t177 = load %"compiler/effects:Facts", ptr %l17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eSetAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t175, i64 %t176, %"compiler/effects:Facts" %t177)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t181 = load i64, ptr %l15, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l15, !tbaa !24
  br label %bb52
bb61:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb62
bb62:
  %t185 = load i1, ptr %l18, !tbaa !21
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb63, label %bb64
bb63:
  br label %bb117
bb64:
  br label %bb65
bb65:
  store i1 false, ptr %l18, !tbaa !21
  %t189 = load ptr, ptr %l1, !tbaa !29
  store ptr %t189, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb66
bb66:
  %t191 = load i64, ptr %l20, !tbaa !24
  store i64 %t191, ptr %l128, !tbaa !24
  %t192 = load ptr, ptr %l19, !tbaa !29
  %t194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t192)
  store i64 %t194, ptr %l130
  br label %bb67
bb67:
  %t195 = load i64, ptr %l128, !tbaa !24
  %t196 = load i64, ptr %l130, !tbaa !24
  %t197 = icmp slt i64 %t195, %t196
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb68, label %bb69
bb68:
  br label %bb115
bb69:
  br label %bb70
bb70:
  %t201 = load ptr, ptr %l19, !tbaa !29
  %t202 = load i64, ptr %l20, !tbaa !24
  %t205 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t201, i64 %t202)
  store i64 %t205, ptr %l135
  br label %bb71
bb71:
  %t206 = load i64, ptr %l135, !tbaa !24
  store i64 %t206, ptr %l21, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s20
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/effects:Effects", ptr %t207, i32 0, i32 4
  %t210 = load i64, ptr %l21, !tbaa !24
  %t213 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hec46674a538af874724ad5c9698b0829(ptr %v0, ptr %s20, ptr %t209, i64 %t210)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t213, ptr %l139
  br label %bb72
bb72:
  %t215 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %s20, ptr %l139)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t215, ptr %l141
  br label %bb73
bb73:
  %t216 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l141
  %t217 = call ptr @__olang_scope_alloc_a(ptr %s20, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t216, ptr %t217
  store ptr %t217, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb74
bb74:
  %t219 = load i64, ptr %l23, !tbaa !24
  store i64 %t219, ptr %l143, !tbaa !24
  %t220 = load ptr, ptr %l22, !tbaa !29
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eLen_3ccompiler_2feffects_3alink_3e(ptr %s20, ptr %t220)
  store i64 %t222, ptr %l145
  br label %bb75
bb75:
  %t223 = load i64, ptr %l143, !tbaa !24
  %t224 = load i64, ptr %l145, !tbaa !24
  %t225 = icmp slt i64 %t223, %t224
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb76, label %bb77
bb76:
  br label %bb113
bb77:
  br label %bb78
bb78:
  %t229 = load ptr, ptr %l22, !tbaa !29
  %t230 = load i64, ptr %l23, !tbaa !24
  %t233 = call %"compiler/effects:link" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eAt_3ccompiler_2feffects_3alink_3e(ptr %s20, ptr %t229, i64 %t230)
  store %"compiler/effects:link" %t233, ptr %l150
  br label %bb79
bb79:
  %t234 = load %"compiler/effects:link", ptr %l150
  store %"compiler/effects:link" %t234, ptr %l24
  %t235 = getelementptr %"compiler/effects:link", ptr %l24, i32 0, i32 0
  %t236 = load i64, ptr %t235, !tbaa !24
  %t238 = icmp slt i64 %t236, 0
  br i1 %t238, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb83
bb81:
  %t240 = getelementptr %"compiler/effects:link", ptr %l24, i32 0, i32 0
  %t241 = load i64, ptr %t240, !tbaa !24
  store i64 %t241, ptr %l154, !tbaa !24
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/effects:Effects", ptr %t242, i32 0, i32 1
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t244)
  store i64 %t246, ptr %l157
  br label %bb82
bb82:
  %t247 = load i64, ptr %l154, !tbaa !24
  %t248 = load i64, ptr %l157, !tbaa !24
  %t249 = icmp sge i64 %t247, %t248
  store i1 %t249, ptr %l153, !tbaa !21
  br label %bb83
bb83:
  %t251 = load i1, ptr %l153, !tbaa !21
  br i1 %t251, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l159, !tbaa !21
  br label %bb87
bb85:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/effects:Effects", ptr %t252, i32 0, i32 6
  %t255 = getelementptr %"compiler/effects:link", ptr %l24, i32 0, i32 0
  %t256 = load i64, ptr %t255, !tbaa !24
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t254, i64 %t256)
  store i64 %t259, ptr %l163
  br label %bb86
bb86:
  %t260 = load i64, ptr %l163, !tbaa !24
  %t261 = icmp slt i64 %t260, 1
  store i1 %t261, ptr %l159, !tbaa !21
  br label %bb87
bb87:
  %t263 = load i1, ptr %l159, !tbaa !21
  br i1 %t263, label %bb88, label %bb89
bb88:
  br label %bb112
bb89:
  br label %bb90
bb90:
  %t264 = getelementptr %"compiler/effects:link", ptr %l24, i32 0, i32 0
  %t265 = load i64, ptr %t264, !tbaa !24
  %t268 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l3, i64 %t265)
  store i1 %t268, ptr %l167
  br label %bb91
bb91:
  %t269 = load i1, ptr %l167, !tbaa !21
  br i1 %t269, label %bb92, label %bb93
bb92:
  store i1 true, ptr %l168, !tbaa !21
  br label %bb95
bb93:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/effects:Effects", ptr %t270, i32 0, i32 6
  %t273 = getelementptr %"compiler/effects:link", ptr %l24, i32 0, i32 0
  %t274 = load i64, ptr %t273, !tbaa !24
  %t277 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t272, i64 %t274)
  store i64 %t277, ptr %l172
  br label %bb94
bb94:
  %t278 = load i64, ptr %l172, !tbaa !24
  %t279 = icmp eq i64 %t278, 2
  store i1 %t279, ptr %l168, !tbaa !21
  br label %bb95
bb95:
  %t281 = load i1, ptr %l168, !tbaa !21
  br i1 %t281, label %bb96, label %bb97
bb96:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/effects:Effects", ptr %t282, i32 0, i32 5
  %t285 = getelementptr %"compiler/effects:link", ptr %l24, i32 0, i32 0
  %t286 = load i64, ptr %t285, !tbaa !24
  %t289 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t284, i64 %t286)
  store %"compiler/effects:Facts" %t289, ptr %l177
  br label %bb98
bb97:
  br label %bb111
bb98:
  %t290 = getelementptr %"compiler/effects:Facts", ptr %l177, i32 0, i32 15
  %t291 = load i64, ptr %t290, !tbaa !24
  %t292 = getelementptr %"compiler/effects:link", ptr %l24, i32 0, i32 1
  %t293 = load i64, ptr %t292, !tbaa !24
  %t296 = call i1 @compiler_2feffects_2ehasBit(i64 %t291, i64 %t293)
  store i1 %t296, ptr %l180
  br label %bb99
bb99:
  %t297 = load i1, ptr %l180, !tbaa !21
  %t298 = xor i1 %t297, true
  br i1 %t298, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb104
bb101:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/effects:Effects", ptr %t300, i32 0, i32 5
  %t303 = load i64, ptr %l21, !tbaa !24
  %t306 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t302, i64 %t303)
  store %"compiler/effects:Facts" %t306, ptr %l186
  br label %bb102
bb102:
  %t307 = getelementptr %"compiler/effects:Facts", ptr %l186, i32 0, i32 15
  %t308 = load i64, ptr %t307, !tbaa !24
  %t309 = getelementptr %"compiler/effects:link", ptr %l24, i32 0, i32 2
  %t310 = load i64, ptr %t309, !tbaa !24
  %t313 = call i1 @compiler_2feffects_2ehasBit(i64 %t308, i64 %t310)
  store i1 %t313, ptr %l189
  br label %bb103
bb103:
  %t314 = load i1, ptr %l189, !tbaa !21
  store i1 %t314, ptr %l182, !tbaa !21
  br label %bb104
bb104:
  %t315 = load i1, ptr %l182, !tbaa !21
  br i1 %t315, label %bb105, label %bb106
bb105:
  br label %bb112
bb106:
  br label %bb107
bb107:
  %t316 = load i64, ptr %l21, !tbaa !24
  store i64 %t316, ptr %l25, !tbaa !24
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/effects:Effects", ptr %t318, i32 0, i32 5
  %t321 = load i64, ptr %l21, !tbaa !24
  %t324 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t320, i64 %t321)
  store %"compiler/effects:Facts" %t324, ptr %l194
  br label %bb108
bb108:
  %t325 = getelementptr %"compiler/effects:Facts", ptr %l194, i32 0, i32 15
  %t326 = load i64, ptr %t325, !tbaa !24
  store i64 %t326, ptr %l195, !tbaa !24
  %t327 = getelementptr %"compiler/effects:link", ptr %l24, i32 0, i32 2
  %t328 = load i64, ptr %t327, !tbaa !24
  %t330 = call i64 @compiler_2feffects_2eparamBit(i64 %t328)
  store i64 %t330, ptr %l197
  br label %bb109
bb109:
  %t331 = load i64, ptr %l195, !tbaa !24
  %t332 = load i64, ptr %l197, !tbaa !24
  %t333 = or i64 %t331, %t332
  store i64 %t333, ptr %l26, !tbaa !24
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/effects:Effects", ptr %t335, i32 0, i32 5
  %t338 = load i64, ptr %l25, !tbaa !24
  %t341 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t337, i64 %t338)
  store ptr %t341, ptr %l202
  br label %bb110
bb110:
  %t342 = load ptr, ptr %l202, !tbaa !29
  %t344 = load i64, ptr %l26, !tbaa !24
  %t347 = getelementptr %"compiler/effects:Facts", ptr %t342, i32 0, i32 15
  store i64 %t344, ptr %t347, !tbaa !24
  store i1 true, ptr %l18, !tbaa !21
  br label %bb111
bb111:
  br label %bb112
bb112:
  %t348 = load i64, ptr %l23, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l23, !tbaa !24
  br label %bb74
bb113:
  call void @__olang_scope_close(ptr %s20)
  br label %bb114
bb114:
  %t352 = load i64, ptr %l20, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l20, !tbaa !24
  br label %bb66
bb115:
  br label %bb116
bb116:
  br label %bb62
bb117:
  %t356 = load ptr, ptr %l1, !tbaa !29
  store ptr %t356, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb118
bb118:
  %t358 = load i64, ptr %l29, !tbaa !24
  store i64 %t358, ptr %l210, !tbaa !24
  %t359 = load ptr, ptr %l28, !tbaa !29
  %t361 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t359)
  store i64 %t361, ptr %l212
  br label %bb119
bb119:
  %t362 = load i64, ptr %l210, !tbaa !24
  %t363 = load i64, ptr %l212, !tbaa !24
  %t364 = icmp slt i64 %t362, %t363
  %t366 = xor i1 %t364, true
  br i1 %t366, label %bb120, label %bb121
bb120:
  br label %bb126
bb121:
  br label %bb122
bb122:
  %t368 = load ptr, ptr %l28, !tbaa !29
  %t369 = load i64, ptr %l29, !tbaa !24
  %t372 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t368, i64 %t369)
  store i64 %t372, ptr %l217
  br label %bb123
bb123:
  %t373 = load i64, ptr %l217, !tbaa !24
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/effects:Effects", ptr %t374, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t376, i64 %t373, i64 2)
  br label %bb124
bb124:
  br label %bb125
bb125:
  %t380 = load i64, ptr %l29, !tbaa !24
  %t382 = add i64 %t380, 1
  store i64 %t382, ptr %l29, !tbaa !24
  br label %bb118
bb126:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l103 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i1
  %l197 = alloca { i64, ptr }
  %l204 = alloca ptr
  %l205 = alloca i1
  %l221 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t2 = load ptr, ptr %l30, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l30, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l31, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l31, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t31 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ederive(ptr %v0, ptr %v1, ptr %t27, i64 %t30, ptr %t31)
  br label %bb7
bb7:
  br label %bb142
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t36 = load ptr, ptr %l45, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l45, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 17}
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l46, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l46, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  br label %bb17
bb12:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t51 = load ptr, ptr %l51, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t54 = load ptr, ptr %l51, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 17}
  %t57 = icmp eq i64 %t55, 15
  store i1 %t57, ptr %l52, !tbaa !21
  br label %bb14
bb14:
  %t58 = load i1, ptr %l52, !tbaa !21
  br i1 %t58, label %bb15, label %bb16
bb15:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [3 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", ptr }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  br label %bb18
bb18:
  br label %bb142
bb19:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t71 = load ptr, ptr %l60, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t74 = load ptr, ptr %l60, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 17}
  %t77 = icmp eq i64 %t75, 1
  store i1 %t77, ptr %l61, !tbaa !21
  br label %bb21
bb21:
  %t78 = load i1, ptr %l61, !tbaa !21
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l6, !tbaa !29
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t91, ptr %t92, i1 true)
  br label %bb25
bb25:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t95, ptr %t96)
  br label %bb26
bb26:
  br label %bb142
bb27:
  %t100 = load ptr, ptr %l1, !tbaa !29
  store ptr %t100, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t101 = load ptr, ptr %l73, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb28, label %bb29
bb28:
  %t104 = load ptr, ptr %l73, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 17}
  %t107 = icmp eq i64 %t105, 3
  store i1 %t107, ptr %l74, !tbaa !21
  br label %bb29
bb29:
  %t108 = load i1, ptr %l74, !tbaa !21
  br i1 %t108, label %bb30, label %bb31
bb30:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [3 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", ptr }, ptr %t111, i32 0, i32 1
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l7, !tbaa !29
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l7, !tbaa !29
  %t118 = getelementptr %"compiler/typed:If", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t115, ptr %t119)
  br label %bb33
bb33:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l7, !tbaa !29
  %t126 = getelementptr %"compiler/typed:If", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t123, ptr %t127)
  br label %bb34
bb34:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l7, !tbaa !29
  %t134 = getelementptr %"compiler/typed:If", ptr %t132, i32 0, i32 2
  %t135 = load ptr, ptr %t134, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t131, ptr %t135)
  br label %bb35
bb35:
  br label %bb142
bb36:
  %t138 = load ptr, ptr %l1, !tbaa !29
  store ptr %t138, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t139 = load ptr, ptr %l90, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb37, label %bb38
bb37:
  %t142 = load ptr, ptr %l90, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 17}
  %t145 = icmp eq i64 %t143, 4
  store i1 %t145, ptr %l91, !tbaa !21
  br label %bb38
bb38:
  %t146 = load i1, ptr %l91, !tbaa !21
  br i1 %t146, label %bb39, label %bb40
bb39:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t149, i32 0, i32 1
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l8, !tbaa !29
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t155, i32 0, i32 2
  %t157 = load ptr, ptr %t156
  store ptr %t157, ptr %l9, !tbaa !29
  br label %bb41
bb40:
  br label %bb48
bb41:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/effects:Effects", ptr %t159, i32 0, i32 19
  %t162 = load ptr, ptr %l8, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Block", ptr %t162, i32 0, i32 0
  %t165 = load i32, ptr %t164, !tbaa !23
  %t167 = sext i32 %t165 to i64
  %t170 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t161, i64 %t167)
  store i1 %t170, ptr %l103
  br label %bb42
bb42:
  %t171 = load i1, ptr %l103, !tbaa !21
  %t172 = xor i1 %t171, true
  br i1 %t172, label %bb43, label %bb44
bb43:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/effects:Effects", ptr %t174, i32 0, i32 14
  %t177 = getelementptr %"compiler/effects:Facts", ptr %t176, i32 0, i32 8
  store i1 true, ptr %t177, !tbaa !21
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t178, ptr %t179)
  br label %bb46
bb46:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t183, ptr %t184)
  br label %bb47
bb47:
  br label %bb142
bb48:
  %t187 = load ptr, ptr %l1, !tbaa !29
  store ptr %t187, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t188 = load ptr, ptr %l111, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb49, label %bb50
bb49:
  %t191 = load ptr, ptr %l111, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 17}
  %t194 = icmp eq i64 %t192, 6
  store i1 %t194, ptr %l112, !tbaa !21
  br label %bb50
bb50:
  %t195 = load i1, ptr %l112, !tbaa !21
  br i1 %t195, label %bb51, label %bb52
bb51:
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t198 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", ptr }, ptr %t198, i32 0, i32 1
  %t200 = load ptr, ptr %t199
  store ptr %t200, ptr %l10, !tbaa !29
  br label %bb57
bb52:
  %t202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t202, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t203 = load ptr, ptr %l117, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb53, label %bb54
bb53:
  %t206 = load ptr, ptr %l117, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 16
  store i1 %t209, ptr %l118, !tbaa !21
  br label %bb54
bb54:
  %t210 = load i1, ptr %l118, !tbaa !21
  br i1 %t210, label %bb55, label %bb56
bb55:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l10, !tbaa !29
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t217, ptr %t218)
  br label %bb58
bb58:
  br label %bb142
bb59:
  %t221 = load ptr, ptr %l1, !tbaa !29
  store ptr %t221, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t222 = load ptr, ptr %l125, !tbaa !29
  %t223 = icmp ne ptr %t222, null
  br i1 %t223, label %bb60, label %bb61
bb60:
  %t225 = load ptr, ptr %l125, !tbaa !29
  %t226 = load i64, ptr %t225, !range !{i64 0, i64 17}
  %t228 = icmp eq i64 %t226, 8
  store i1 %t228, ptr %l126, !tbaa !21
  br label %bb61
bb61:
  %t229 = load i1, ptr %l126, !tbaa !21
  br i1 %t229, label %bb62, label %bb63
bb62:
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr { i64, [3 x i64] }, ptr %t230, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t232, i32 0, i32 1
  %t234 = load ptr, ptr %t233
  store ptr %t234, ptr %l11, !tbaa !29
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t236, ptr %t237)
  br label %bb65
bb65:
  br label %bb142
bb66:
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t242 = load ptr, ptr %l134, !tbaa !29
  %t243 = icmp ne ptr %t242, null
  br i1 %t243, label %bb67, label %bb68
bb67:
  %t245 = load ptr, ptr %l134, !tbaa !29
  %t246 = load i64, ptr %t245, !range !{i64 0, i64 17}
  %t248 = icmp eq i64 %t246, 5
  store i1 %t248, ptr %l135, !tbaa !21
  br label %bb68
bb68:
  %t249 = load i1, ptr %l135, !tbaa !21
  br i1 %t249, label %bb69, label %bb70
bb69:
  br label %bb75
bb70:
  %t250 = load ptr, ptr %l1, !tbaa !29
  store ptr %t250, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t251 = load ptr, ptr %l138, !tbaa !29
  %t252 = icmp ne ptr %t251, null
  br i1 %t252, label %bb71, label %bb72
bb71:
  %t254 = load ptr, ptr %l138, !tbaa !29
  %t255 = load i64, ptr %t254, !range !{i64 0, i64 17}
  %t257 = icmp eq i64 %t255, 7
  store i1 %t257, ptr %l139, !tbaa !21
  br label %bb72
bb72:
  %t258 = load i1, ptr %l139, !tbaa !21
  br i1 %t258, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb142
bb76:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l142, !tbaa !29
  store i1 false, ptr %l143, !tbaa !21
  %t260 = load ptr, ptr %l142, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb77, label %bb78
bb77:
  %t263 = load ptr, ptr %l142, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 17}
  %t266 = icmp eq i64 %t264, 11
  store i1 %t266, ptr %l143, !tbaa !21
  br label %bb78
bb78:
  %t267 = load i1, ptr %l143, !tbaa !21
  br i1 %t267, label %bb79, label %bb80
bb79:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [3 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", ptr }, ptr %t270, i32 0, i32 1
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l12, !tbaa !29
  br label %bb85
bb80:
  %t274 = load ptr, ptr %l1, !tbaa !29
  store ptr %t274, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t275 = load ptr, ptr %l148, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb81, label %bb82
bb81:
  %t278 = load ptr, ptr %l148, !tbaa !29
  %t279 = load i64, ptr %t278, !range !{i64 0, i64 17}
  %t281 = icmp eq i64 %t279, 12
  store i1 %t281, ptr %l149, !tbaa !21
  br label %bb82
bb82:
  %t282 = load i1, ptr %l149, !tbaa !21
  br i1 %t282, label %bb83, label %bb84
bb83:
  %t283 = load ptr, ptr %l1, !tbaa !29
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { %"compiler/source:Span", ptr }, ptr %t285, i32 0, i32 1
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l12, !tbaa !29
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t289, ptr %t290)
  br label %bb86
bb86:
  br label %bb142
bb87:
  %t294 = load ptr, ptr %l1, !tbaa !29
  store ptr %t294, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t295 = load ptr, ptr %l157, !tbaa !29
  %t296 = icmp ne ptr %t295, null
  br i1 %t296, label %bb88, label %bb89
bb88:
  %t298 = load ptr, ptr %l157, !tbaa !29
  %t299 = load i64, ptr %t298, !range !{i64 0, i64 17}
  %t301 = icmp eq i64 %t299, 9
  store i1 %t301, ptr %l158, !tbaa !21
  br label %bb89
bb89:
  %t302 = load i1, ptr %l158, !tbaa !21
  br i1 %t302, label %bb90, label %bb91
bb90:
  %t303 = load ptr, ptr %l1, !tbaa !29
  %t305 = getelementptr { i64, [3 x i64] }, ptr %t303, i32 0, i32 1
  %t306 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t305, i32 0, i32 2
  %t307 = load ptr, ptr %t306
  store ptr %t307, ptr %l13, !tbaa !29
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t309, ptr %t310)
  br label %bb93
bb93:
  br label %bb142
bb94:
  %t313 = load ptr, ptr %l1, !tbaa !29
  store ptr %t313, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t314 = load ptr, ptr %l165, !tbaa !29
  %t315 = icmp ne ptr %t314, null
  br i1 %t315, label %bb95, label %bb96
bb95:
  %t317 = load ptr, ptr %l165, !tbaa !29
  %t318 = load i64, ptr %t317, !range !{i64 0, i64 17}
  %t320 = icmp eq i64 %t318, 10
  store i1 %t320, ptr %l166, !tbaa !21
  br label %bb96
bb96:
  %t321 = load i1, ptr %l166, !tbaa !21
  br i1 %t321, label %bb97, label %bb98
bb97:
  %t322 = load ptr, ptr %l1, !tbaa !29
  %t324 = getelementptr { i64, [3 x i64] }, ptr %t322, i32 0, i32 1
  %t325 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t324, i32 0, i32 1
  %t326 = load ptr, ptr %t325
  store ptr %t326, ptr %l14, !tbaa !29
  %t328 = load ptr, ptr %l1, !tbaa !29
  %t330 = getelementptr { i64, [3 x i64] }, ptr %t328, i32 0, i32 1
  %t331 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t330, i32 0, i32 2
  %t332 = load ptr, ptr %t331
  store ptr %t332, ptr %l15, !tbaa !29
  br label %bb99
bb98:
  br label %bb102
bb99:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t334, ptr %t335)
  br label %bb100
bb100:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t339, ptr %t340)
  br label %bb101
bb101:
  br label %bb142
bb102:
  %t343 = load ptr, ptr %l1, !tbaa !29
  store ptr %t343, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t344 = load ptr, ptr %l178, !tbaa !29
  %t345 = icmp ne ptr %t344, null
  br i1 %t345, label %bb103, label %bb104
bb103:
  %t347 = load ptr, ptr %l178, !tbaa !29
  %t348 = load i64, ptr %t347, !range !{i64 0, i64 17}
  %t350 = icmp eq i64 %t348, 13
  store i1 %t350, ptr %l179, !tbaa !21
  br label %bb104
bb104:
  %t351 = load i1, ptr %l179, !tbaa !21
  br i1 %t351, label %bb105, label %bb106
bb105:
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t354 = getelementptr { i64, [3 x i64] }, ptr %t352, i32 0, i32 1
  %t355 = getelementptr { %"compiler/source:Span", ptr }, ptr %t354, i32 0, i32 1
  %t356 = load ptr, ptr %t355
  store ptr %t356, ptr %l16, !tbaa !29
  br label %bb107
bb106:
  br label %bb116
bb107:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/effects:Effects", ptr %t358, i32 0, i32 14
  %t361 = getelementptr %"compiler/effects:Facts", ptr %t360, i32 0, i32 1
  store i1 true, ptr %t361, !tbaa !21
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load ptr, ptr %l16, !tbaa !29
  %t365 = getelementptr %"compiler/typed:Join", ptr %t363, i32 0, i32 0
  %t366 = load ptr, ptr %t365, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t362, ptr %t366)
  br label %bb108
bb108:
  %t370 = load ptr, ptr %l16, !tbaa !29
  %t372 = getelementptr %"compiler/typed:Join", ptr %t370, i32 0, i32 2
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  store { i64, ptr } %t373, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t375 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t375, 0
  store i64 %t377, ptr %l19, !tbaa !24
  br label %bb109
bb109:
  %t379 = load i64, ptr %l18, !tbaa !24
  %t380 = load i64, ptr %l19, !tbaa !24
  %t383 = icmp slt i64 %t379, %t380
  %t385 = xor i1 %t383, true
  br i1 %t385, label %bb110, label %bb111
bb110:
  br label %bb115
bb111:
  br label %bb112
bb112:
  %t387 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t387, ptr %l197, !tbaa !27
  %t388 = load i64, ptr %l18, !tbaa !24
  %t390 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr ptr, ptr %t391, i64 %t388
  %t393 = load ptr, ptr %t392, !tbaa !39
  %t395 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclause(ptr %v0, ptr %v1, ptr %t395, ptr %t393)
  br label %bb113
bb113:
  br label %bb114
bb114:
  %t399 = load i64, ptr %l18, !tbaa !24
  %t401 = add i64 %t399, 1
  store i64 %t401, ptr %l18, !tbaa !24
  br label %bb109
bb115:
  br label %bb142
bb116:
  %t403 = load ptr, ptr %l1, !tbaa !29
  store ptr %t403, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t404 = load ptr, ptr %l204, !tbaa !29
  %t405 = icmp ne ptr %t404, null
  br i1 %t405, label %bb117, label %bb118
bb117:
  %t407 = load ptr, ptr %l204, !tbaa !29
  %t408 = load i64, ptr %t407, !range !{i64 0, i64 17}
  %t410 = icmp eq i64 %t408, 14
  store i1 %t410, ptr %l205, !tbaa !21
  br label %bb118
bb118:
  %t411 = load i1, ptr %l205, !tbaa !21
  br i1 %t411, label %bb119, label %bb120
bb119:
  %t412 = load ptr, ptr %l1, !tbaa !29
  %t414 = getelementptr { i64, [3 x i64] }, ptr %t412, i32 0, i32 1
  %t415 = getelementptr { %"compiler/source:Span", ptr }, ptr %t414, i32 0, i32 1
  %t416 = load ptr, ptr %t415
  store ptr %t416, ptr %l21, !tbaa !29
  br label %bb121
bb120:
  br label %bb141
bb121:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/effects:Effects", ptr %t418, i32 0, i32 14
  %t421 = getelementptr %"compiler/effects:Facts", ptr %t420, i32 0, i32 6
  store i1 true, ptr %t421, !tbaa !21
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load i64, ptr @G_2ecompiler_2feffects_2eCapThreads, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecap(ptr %v0, ptr %t422, i64 %t423)
  br label %bb122
bb122:
  %t426 = load ptr, ptr %l21, !tbaa !29
  %t428 = getelementptr %"compiler/typed:Spawn", ptr %t426, i32 0, i32 0
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  store { i64, ptr } %t429, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t431 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t431, 0
  store i64 %t433, ptr %l24, !tbaa !24
  br label %bb123
bb123:
  %t435 = load i64, ptr %l23, !tbaa !24
  %t436 = load i64, ptr %l24, !tbaa !24
  %t439 = icmp slt i64 %t435, %t436
  %t441 = xor i1 %t439, true
  br i1 %t441, label %bb124, label %bb125
bb124:
  br label %bb132
bb125:
  br label %bb126
bb126:
  %t443 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t443, ptr %l221, !tbaa !27
  %t444 = load i64, ptr %l23, !tbaa !24
  %t446 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr ptr, ptr %t447, i64 %t444
  %t449 = load ptr, ptr %t448, !tbaa !39
  store ptr %t449, ptr %l25, !tbaa !29
  %t451 = load ptr, ptr %l25, !tbaa !29
  %t453 = icmp eq ptr %t451, null
  %t455 = xor i1 %t453, true
  br i1 %t455, label %bb127, label %bb128
bb127:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t457, ptr %t458, i1 true)
  br label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t461 = load i64, ptr %l23, !tbaa !24
  %t463 = add i64 %t461, 1
  store i64 %t463, ptr %l23, !tbaa !24
  br label %bb123
bb132:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load ptr, ptr %l21, !tbaa !29
  %t468 = getelementptr %"compiler/typed:Spawn", ptr %t466, i32 0, i32 1
  %t469 = load ptr, ptr %t468, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t465, ptr %t469)
  br label %bb133
bb133:
  %t473 = load ptr, ptr %l21, !tbaa !29
  %t475 = getelementptr %"compiler/typed:Spawn", ptr %t473, i32 0, i32 2
  %t476 = load { i64, ptr }, ptr %t475, !tbaa !27
  store { i64, ptr } %t476, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t478 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t478, 0
  store i64 %t480, ptr %l28, !tbaa !24
  br label %bb134
bb134:
  %t482 = load i64, ptr %l27, !tbaa !24
  %t483 = load i64, ptr %l28, !tbaa !24
  %t486 = icmp slt i64 %t482, %t483
  %t488 = xor i1 %t486, true
  br i1 %t488, label %bb135, label %bb136
bb135:
  br label %bb140
bb136:
  br label %bb137
bb137:
  %t490 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t490, ptr %l243, !tbaa !27
  %t491 = load i64, ptr %l27, !tbaa !24
  %t493 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = getelementptr ptr, ptr %t494, i64 %t491
  %t496 = load ptr, ptr %t495, !tbaa !39
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t501 = getelementptr %"compiler/typed:TaskClause", ptr %t496, i32 0, i32 3
  %t502 = load ptr, ptr %t501, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t498, ptr %t502)
  br label %bb138
bb138:
  br label %bb139
bb139:
  %t505 = load i64, ptr %l27, !tbaa !24
  %t507 = add i64 %t505, 1
  store i64 %t507, ptr %l27, !tbaa !24
  br label %bb134
bb140:
  br label %bb142
bb141:
  call void @__olang_check_failed(ptr @olang_loc_cdd9fd819eb1314_592489ef7c054390)
  unreachable
bb142:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estore(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/effects:root"
  %l5 = alloca i1
  %l9 = alloca %"compiler/effects:root"
  %l12 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalRoot(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/effects:Effects", ptr %t7, i32 0, i32 14
  %t10 = getelementptr %"compiler/effects:Facts", ptr %t9, i32 0, i32 2
  store i1 true, ptr %t10, !tbaa !21
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  store %"compiler/effects:root" %t15, ptr %l9
  br label %bb5
bb5:
  %t16 = load %"compiler/effects:root", ptr %l9
  store %"compiler/effects:root" %t16, ptr %l2
  %t17 = getelementptr %"compiler/effects:root", ptr %l2, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = icmp sge i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = getelementptr %"compiler/effects:root", ptr %l2, i32 0, i32 1
  %t23 = load i1, ptr %t22, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t25 = load i1, ptr %l12, !tbaa !21
  br i1 %t25, label %bb9, label %bb10
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/effects:root", ptr %l2, i32 0, i32 0
  %t28 = load i64, ptr %t27, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ethrough(ptr %v0, ptr %t26, i64 %t28)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ethrough(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 17
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l9, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/effects:Effects", ptr %t15, i32 0, i32 14
  %t18 = getelementptr %"compiler/effects:Facts", ptr %t17, i32 0, i32 15
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l11, !tbaa !24
  %t22 = call i64 @compiler_2feffects_2eparamBit(i64 %t13)
  store i64 %t22, ptr %l13
  br label %bb5
bb5:
  %t23 = load i64, ptr %l11, !tbaa !24
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = or i64 %t23, %t24
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/effects:Effects", ptr %t26, i32 0, i32 18
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t28, i64 %t29)
  %t33 = extractvalue { i32, i64 } %t32, 1
  %t34 = extractvalue { i32, i64 } %t32, 0
  store i32 %t34, ptr %l20
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb7, label %ok.36, !prof !99
ok.36:
  store i64 %t33, ptr %l19
  br label %bb6
bb6:
  %t37 = load i64, ptr %l19, !tbaa !24
  store i64 %t37, ptr %l15, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l15, !tbaa !24
  br label %bb9
bb9:
  %t38 = load i64, ptr %l14, !tbaa !24
  %t39 = load i64, ptr %l15, !tbaa !24
  %t40 = or i64 %t38, %t39
  %t42 = load ptr, ptr %l9, !tbaa !29
  %t43 = getelementptr %"compiler/effects:Effects", ptr %t42, i32 0, i32 14
  %t44 = getelementptr %"compiler/effects:Facts", ptr %t43, i32 0, i32 15
  store i64 %t40, ptr %t44, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2evisit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l19 = alloca ptr
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i1
  %l46 = alloca i64
  %l49 = alloca i64
  %l51 = alloca i1
  %l55 = alloca i64
  %l60 = alloca i64
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca i64
  %l79 = alloca i64
  %l83 = alloca i1
  %l84 = alloca i1
  %l88 = alloca i64
  %l92 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca i64
  %l100 = alloca i64
  %l106 = alloca i64
  %l110 = alloca i64
  %l112 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalk(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/effects:Effects", ptr %t5, i32 0, i32 9
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 13
  %t12 = load i64, ptr %t11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t7, i64 %t8, i64 %t12)
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/effects:Effects", ptr %t16, i32 0, i32 10
  %t19 = load i64, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/effects:Effects", ptr %t20, i32 0, i32 13
  %t23 = load i64, ptr %t22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19, i64 %t23)
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = getelementptr %"compiler/effects:Effects", ptr %t28, i32 0, i32 13
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = add i64 %t30, 1
  %t34 = load ptr, ptr %l19, !tbaa !29
  %t35 = getelementptr %"compiler/effects:Effects", ptr %t34, i32 0, i32 13
  store i64 %t32, ptr %t35, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t36, i32 0, i32 12
  %t39 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t38, i64 %t39)
  br label %bb4
bb4:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Effects", ptr %t42, i32 0, i32 11
  %t45 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t44, i64 %t45, i1 true)
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/effects:Effects", ptr %t48, i32 0, i32 3
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %s1, ptr %t50, i64 %t51)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l31
  br label %bb6
bb6:
  %t56 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s1, ptr %l31)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l33
  br label %bb7
bb7:
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t58 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %t58
  store ptr %t58, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  %t60 = load i64, ptr %l3, !tbaa !24
  store i64 %t60, ptr %l35, !tbaa !24
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t61)
  store i64 %t63, ptr %l37
  br label %bb9
bb9:
  %t64 = load i64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l37, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb10, label %bb11
bb10:
  br label %bb49
bb11:
  br label %bb12
bb12:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i64, ptr %l3, !tbaa !24
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t70, i64 %t71)
  store i64 %t74, ptr %l42
  br label %bb13
bb13:
  %t75 = load i64, ptr %l42, !tbaa !24
  store i64 %t75, ptr %l4, !tbaa !24
  %t76 = load i64, ptr %l4, !tbaa !24
  %t78 = icmp slt i64 %t76, 0
  br i1 %t78, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb17
bb15:
  %t80 = load i64, ptr %l4, !tbaa !24
  store i64 %t80, ptr %l46, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/effects:Effects", ptr %t81, i32 0, i32 1
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t83)
  store i64 %t85, ptr %l49
  br label %bb16
bb16:
  %t86 = load i64, ptr %l46, !tbaa !24
  %t87 = load i64, ptr %l49, !tbaa !24
  %t88 = icmp sge i64 %t86, %t87
  store i1 %t88, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t90 = load i1, ptr %l45, !tbaa !21
  br i1 %t90, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb21
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/effects:Effects", ptr %t91, i32 0, i32 6
  %t94 = load i64, ptr %l4, !tbaa !24
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t93, i64 %t94)
  store i64 %t97, ptr %l55
  br label %bb20
bb20:
  %t98 = load i64, ptr %l55, !tbaa !24
  %t99 = icmp eq i64 %t98, 2
  store i1 %t99, ptr %l51, !tbaa !21
  br label %bb21
bb21:
  %t101 = load i1, ptr %l51, !tbaa !21
  br i1 %t101, label %bb22, label %bb23
bb22:
  br label %bb48
bb23:
  br label %bb24
bb24:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/effects:Effects", ptr %t102, i32 0, i32 9
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t104, i64 %t105)
  store i64 %t108, ptr %l60
  br label %bb25
bb25:
  %t109 = load i64, ptr %l60, !tbaa !24
  %t110 = icmp slt i64 %t109, 0
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2evisit(ptr %v0, ptr %t112, i64 %t113)
  br label %bb28
bb27:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/effects:Effects", ptr %t116, i32 0, i32 11
  %t119 = load i64, ptr %l4, !tbaa !24
  %t122 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t118, i64 %t119)
  store i1 %t122, ptr %l83
  br label %bb36
bb28:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/effects:Effects", ptr %t123, i32 0, i32 10
  %t126 = load i64, ptr %l4, !tbaa !24
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t126)
  store i64 %t129, ptr %l67
  br label %bb29
bb29:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/effects:Effects", ptr %t130, i32 0, i32 10
  %t133 = load i64, ptr %l1, !tbaa !24
  %t136 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t132, i64 %t133)
  store i64 %t136, ptr %l71
  br label %bb30
bb30:
  %t137 = load i64, ptr %l67, !tbaa !24
  %t138 = load i64, ptr %l71, !tbaa !24
  %t139 = icmp slt i64 %t137, %t138
  br i1 %t139, label %bb31, label %bb32
bb31:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/effects:Effects", ptr %t141, i32 0, i32 10
  store ptr %t143, ptr %l74, !tbaa !29
  %t144 = load i64, ptr %l1, !tbaa !24
  store i64 %t144, ptr %l75, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/effects:Effects", ptr %t145, i32 0, i32 10
  %t148 = load i64, ptr %l4, !tbaa !24
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t147, i64 %t148)
  store i64 %t151, ptr %l79
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t152 = load ptr, ptr %l74, !tbaa !29
  %t153 = load i64, ptr %l75, !tbaa !24
  %t154 = load i64, ptr %l79, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t152, i64 %t153, i64 %t154)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb47
bb36:
  %t155 = load i1, ptr %l83, !tbaa !21
  br i1 %t155, label %bb37, label %bb38
bb37:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/effects:Effects", ptr %t156, i32 0, i32 9
  %t159 = load i64, ptr %l4, !tbaa !24
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t158, i64 %t159)
  store i64 %t162, ptr %l88
  br label %bb39
bb38:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb41
bb39:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/effects:Effects", ptr %t163, i32 0, i32 10
  %t166 = load i64, ptr %l1, !tbaa !24
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t165, i64 %t166)
  store i64 %t169, ptr %l92
  br label %bb40
bb40:
  %t170 = load i64, ptr %l88, !tbaa !24
  %t171 = load i64, ptr %l92, !tbaa !24
  %t172 = icmp slt i64 %t170, %t171
  store i1 %t172, ptr %l84, !tbaa !21
  br label %bb41
bb41:
  %t174 = load i1, ptr %l84, !tbaa !21
  br i1 %t174, label %bb42, label %bb43
bb42:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/effects:Effects", ptr %t175, i32 0, i32 10
  store ptr %t177, ptr %l95, !tbaa !29
  %t178 = load i64, ptr %l1, !tbaa !24
  store i64 %t178, ptr %l96, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/effects:Effects", ptr %t179, i32 0, i32 9
  %t182 = load i64, ptr %l4, !tbaa !24
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t181, i64 %t182)
  store i64 %t185, ptr %l100
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t186 = load ptr, ptr %l95, !tbaa !29
  %t187 = load i64, ptr %l96, !tbaa !24
  %t188 = load i64, ptr %l100, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t186, i64 %t187, i64 %t188)
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l3, !tbaa !24
  br label %bb8
bb49:
  call void @__olang_scope_close(ptr %s1)
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/effects:Effects", ptr %t193, i32 0, i32 10
  %t196 = load i64, ptr %l1, !tbaa !24
  %t199 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t195, i64 %t196)
  store i64 %t199, ptr %l106
  br label %bb50
bb50:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/effects:Effects", ptr %t200, i32 0, i32 9
  %t203 = load i64, ptr %l1, !tbaa !24
  %t206 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t202, i64 %t203)
  store i64 %t206, ptr %l110
  br label %bb51
bb51:
  %t207 = load i64, ptr %l106, !tbaa !24
  %t208 = load i64, ptr %l110, !tbaa !24
  %t209 = icmp ne i64 %t207, %t208
  br i1 %t209, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb53:
  br label %bb54
bb54:
  %t211 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t211, ptr %l112
  br label %bb55
bb55:
  %t212 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t212, ptr %l5
  br label %bb56
bb56:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/effects:Effects", ptr %t213, i32 0, i32 12
  %t217 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t215)
  %t218 = extractvalue { i32, i64 } %t217, 1
  %t219 = extractvalue { i32, i64 } %t217, 0
  store i32 %t219, ptr %l117
  %t220 = icmp ne i32 %t219, 0
  br i1 %t220, label %bb58, label %ok.221, !prof !99
ok.221:
  store i64 %t218, ptr %l116
  br label %bb57
bb57:
  %t222 = load i64, ptr %l116, !tbaa !24
  store i64 %t222, ptr %l113, !tbaa !24
  br label %bb60
bb58:
  br label %bb59
bb59:
  call void @__olang_ert_req_clear()
  br label %bb67
bb60:
  %t223 = load i64, ptr %l113, !tbaa !24
  store i64 %t223, ptr %l6, !tbaa !24
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/effects:Effects", ptr %t224, i32 0, i32 11
  %t227 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t226, i64 %t227, i1 false)
  br label %bb61
bb61:
  %t230 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t230)
  br label %bb62
bb62:
  %t233 = load i64, ptr %l6, !tbaa !24
  %t234 = load i64, ptr %l1, !tbaa !24
  %t237 = icmp eq i64 %t233, %t234
  br i1 %t237, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb56
bb67:
  %t239 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2esettle(ptr %v0, ptr %s0, ptr %t239, ptr %l5)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalk(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, [2 x i64] }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca %"compiler/effects:Facts"
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca ptr
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca ptr
  %l27 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l28 = alloca ptr
  %l29 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l32 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l58 = alloca ptr
  %l62 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l71 = alloca i64
  %l73 = alloca i64
  %l78 = alloca i32
  %l85 = alloca ptr
  %l86 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i32
  %l112 = alloca ptr
  %l113 = alloca i64
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l119 = alloca ptr
  %l120 = alloca i64
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l124 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4, i64 1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/effects:Effects", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l19
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l19, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l20, !tbaa !29
  %t16 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t16, ptr %l21
  br label %bb3
bb3:
  %t17 = load %"compiler/effects:Facts", ptr %l21
  %t18 = load ptr, ptr %l20, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t18, i32 0, i32 14
  store %"compiler/effects:Facts" %t17, ptr %t19
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l22, !tbaa !29
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l23
  br label %bb4
bb4:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t23, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %t24
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l24, !tbaa !29
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l25
  br label %bb5
bb5:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  %t28 = load ptr, ptr %l24, !tbaa !29
  %t29 = getelementptr %"compiler/effects:Effects", ptr %t28, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %t29
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l26, !tbaa !29
  %t31 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t31, ptr %l27
  br label %bb6
bb6:
  %t32 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l27
  %t33 = load ptr, ptr %l26, !tbaa !29
  %t34 = getelementptr %"compiler/effects:Effects", ptr %t33, i32 0, i32 17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t32, ptr %t34
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l28, !tbaa !29
  %t36 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t36, ptr %l29
  br label %bb7
bb7:
  %t37 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l29
  %t38 = load ptr, ptr %l28, !tbaa !29
  %t39 = getelementptr %"compiler/effects:Effects", ptr %t38, i32 0, i32 18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t37, ptr %t39
  store i64 0, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Body", ptr %t40, i32 0, i32 5
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l32
  br label %bb8
bb8:
  %t45 = load i64, ptr %l32, !tbaa !24
  store i64 %t45, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb14
bb11:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l3, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l39, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb13
bb13:
  %t72 = load i64, ptr %l39, !tbaa !24
  store i64 %t72, ptr %l36, !tbaa !24
  br label %bb14
bb14:
  %t73 = load i64, ptr %l36, !tbaa !24
  store i64 %t73, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t74 = load i64, ptr %l7, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb16, label %bb17
bb16:
  br label %bb22
bb17:
  br label %bb18
bb18:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l8, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/effects:Effects", ptr %t92, i32 0, i32 17
  store ptr %t94, ptr %l58, !tbaa !29
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Body", ptr %t95, i32 0, i32 5
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t97, i64 %t98)
  store i32 %t101, ptr %l62
  br label %bb19
bb19:
  %t102 = load i32, ptr %l62, !tbaa !23
  %t103 = sext i32 %t102 to i64
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = load ptr, ptr %l58, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t105, i64 %t103, i64 %t104)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t108 = load i64, ptr %l7, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb15
bb22:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l67, !tbaa !29
  %t113 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t113, ptr %l68
  br label %bb23
bb23:
  %t114 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l68
  %t115 = load ptr, ptr %l67, !tbaa !29
  %t116 = getelementptr %"compiler/effects:Effects", ptr %t115, i32 0, i32 19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t114, ptr %t116
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 21
  store ptr %t119, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb24
bb24:
  %t121 = load i64, ptr %l10, !tbaa !24
  store i64 %t121, ptr %l71, !tbaa !24
  %t122 = load ptr, ptr %l9, !tbaa !29
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t122)
  store i64 %t124, ptr %l73
  br label %bb25
bb25:
  %t125 = load i64, ptr %l71, !tbaa !24
  %t126 = load i64, ptr %l73, !tbaa !24
  %t127 = icmp slt i64 %t125, %t126
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb26, label %bb27
bb26:
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t131 = load ptr, ptr %l9, !tbaa !29
  %t132 = load i64, ptr %l10, !tbaa !24
  %t135 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t131, i64 %t132)
  store i32 %t135, ptr %l78
  br label %bb29
bb29:
  %t136 = load i32, ptr %l78, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/effects:Effects", ptr %t137, i32 0, i32 19
  %t142 = sext i32 %t136 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t139, i64 %t142, i1 true)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t145 = load i64, ptr %l10, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l10, !tbaa !24
  br label %bb24
bb32:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l85, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/effects:Effects", ptr %t150, i32 0, i32 7
  %t153 = load ptr, ptr %l2, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Body", ptr %t153, i32 0, i32 3
  %t156 = load i64, ptr %t155, !tbaa !24
  %t159 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t152, i64 %t156)
  %t160 = extractvalue { i32, i64 } %t159, 1
  %t161 = extractvalue { i32, i64 } %t159, 0
  store i32 %t161, ptr %l92
  %t162 = icmp ne i32 %t161, 0
  br i1 %t162, label %bb34, label %ok.163, !prof !99
ok.163:
  store i64 %t160, ptr %l91
  br label %bb33
bb33:
  %t164 = load i64, ptr %l91, !tbaa !24
  store i64 %t164, ptr %l86, !tbaa !24
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l86, !tbaa !24
  br label %bb36
bb36:
  %t165 = load i64, ptr %l86, !tbaa !24
  %t166 = load ptr, ptr %l85, !tbaa !29
  %t167 = getelementptr %"compiler/effects:Effects", ptr %t166, i32 0, i32 20
  store i64 %t165, ptr %t167, !tbaa !24
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Body", ptr %t168, i32 0, i32 11
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = icmp eq ptr %t171, null
  br i1 %t173, label %bb37, label %bb38
bb37:
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Body", ptr %t175, i32 0, i32 1
  %t178 = load { i64, [2 x i64] }, ptr %t177
  store { i64, [2 x i64] } %t178, ptr %l12
  %t180 = load { i64, [2 x i64] }, ptr %l12
  %t182 = extractvalue { i64, [2 x i64] } %t180, 0
  %t183 = icmp eq i64 %t182, 2
  br i1 %t183, label %bb39, label %bb40
bb38:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l2, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Body", ptr %t186, i32 0, i32 11
  %t189 = load ptr, ptr %t188, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v0, ptr %t185, ptr %t189)
  br label %bb50
bb39:
  br label %bb43
bb40:
  %t192 = load { i64, [2 x i64] }, ptr %l12
  %t194 = extractvalue { i64, [2 x i64] } %t192, 0
  %t195 = icmp eq i64 %t194, 10
  br i1 %t195, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/effects:Effects", ptr %t197, i32 0, i32 14
  %t200 = getelementptr %"compiler/effects:Facts", ptr %t199, i32 0, i32 12
  store i1 true, ptr %t200, !tbaa !21
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_51a035064631b681_e4502e206a44b155)
  unreachable
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/effects:Effects", ptr %t201, i32 0, i32 2
  %t204 = load i64, ptr %l1, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/effects:Effects", ptr %t205, i32 0, i32 14
  %t208 = load %"compiler/effects:Facts", ptr %t207
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eSetAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t203, i64 %t204, %"compiler/effects:Facts" %t208)
  br label %bb52
bb52:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/effects:Effects", ptr %t212, i32 0, i32 3
  store ptr %t214, ptr %l112, !tbaa !29
  %t215 = load i64, ptr %l1, !tbaa !24
  store i64 %t215, ptr %l113, !tbaa !24
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/effects:Effects", ptr %t216, i32 0, i32 15
  %t219 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t218
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t219, ptr %l115
  %t221 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l115)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t221, ptr %l117
  br label %bb53
bb53:
  %t222 = load ptr, ptr %l112, !tbaa !29
  %t223 = load i64, ptr %l113, !tbaa !24
  %t224 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hca3b6abf349bf7326560c41fbdf5fb42(ptr %v0, ptr %s0, ptr %t222, i64 %t223, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t224)
  br label %bb54
bb54:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/effects:Effects", ptr %t225, i32 0, i32 4
  store ptr %t227, ptr %l119, !tbaa !29
  %t228 = load i64, ptr %l1, !tbaa !24
  store i64 %t228, ptr %l120, !tbaa !24
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/effects:Effects", ptr %t229, i32 0, i32 16
  %t232 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t231
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232, ptr %l122
  %t234 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %s0, ptr %l122)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %l124
  br label %bb55
bb55:
  %t235 = load ptr, ptr %l119, !tbaa !29
  %t236 = load i64, ptr %l120, !tbaa !24
  %t237 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Had7562134349141a1e65e244951d3fe8(ptr %v0, ptr %s0, ptr %t235, i64 %t236, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t237)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/effects:root"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l22 = alloca %"compiler/effects:root"
  %l27 = alloca ptr
  %l28 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estore(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb30
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t39 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store %"compiler/effects:root" %t39, ptr %l22
  br label %bb13
bb13:
  %t40 = load %"compiler/effects:root", ptr %l22
  store %"compiler/effects:root" %t40, ptr %l4
  %t41 = getelementptr %"compiler/effects:root", ptr %l4, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/effects:root", ptr %l4, i32 0, i32 0
  %t48 = load i64, ptr %t47, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ethrough(ptr %v0, ptr %t46, i64 %t48)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb30
bb18:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t55 = load ptr, ptr %l27, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 18}
  %t58 = icmp eq i64 %t56, 17
  store i1 %t58, ptr %l28, !tbaa !21
  br label %bb20
bb20:
  %t59 = load i1, ptr %l28, !tbaa !21
  br i1 %t59, label %bb21, label %bb22
bb21:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritten(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  br label %bb24
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_b365fbc2fc2a8203_e371dcb77fb488d7)
  unreachable
bb30:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eEvaluable(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t12, i32 0, i32 3
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Facts", ptr %t18, i32 0, i32 9
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/effects:Facts", ptr %t24, i32 0, i32 12
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Facts", ptr %t30, i32 0, i32 11
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  %t36 = xor i1 %t35, true
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l47 = alloca i1
  %l50 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %l66 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb6
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Facts", ptr %t11, i32 0, i32 9
  %t14 = load i1, ptr %t13, !tbaa !21
  store i1 %t14, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb9
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Facts", ptr %t17, i32 0, i32 12
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l10, !tbaa !21
  store i1 %t22, ptr %l2, !tbaa !21
  br label %bb70
bb10:
  %t23 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t25 = trunc i64 1 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/effects:Facts", ptr %t28, i32 0, i32 1
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb16
bb15:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/effects:Facts", ptr %t33, i32 0, i32 9
  %t36 = load i1, ptr %t35, !tbaa !21
  store i1 %t36, ptr %l17, !tbaa !21
  br label %bb16
bb16:
  %t38 = load i1, ptr %l17, !tbaa !21
  br i1 %t38, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb19
bb18:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/effects:Facts", ptr %t39, i32 0, i32 12
  %t42 = load i1, ptr %t41, !tbaa !21
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l20, !tbaa !21
  store i1 %t44, ptr %l2, !tbaa !21
  br label %bb70
bb20:
  %t45 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t47 = trunc i64 2 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb30
bb23:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/effects:Facts", ptr %t50, i32 0, i32 2
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb26
bb25:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/effects:Facts", ptr %t55, i32 0, i32 9
  %t58 = load i1, ptr %t57, !tbaa !21
  store i1 %t58, ptr %l27, !tbaa !21
  br label %bb26
bb26:
  %t60 = load i1, ptr %l27, !tbaa !21
  br i1 %t60, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb29
bb28:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/effects:Facts", ptr %t61, i32 0, i32 12
  %t64 = load i1, ptr %t63, !tbaa !21
  store i1 %t64, ptr %l30, !tbaa !21
  br label %bb29
bb29:
  %t66 = load i1, ptr %l30, !tbaa !21
  store i1 %t66, ptr %l2, !tbaa !21
  br label %bb70
bb30:
  %t67 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t69 = trunc i64 3 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb40
bb33:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/effects:Facts", ptr %t72, i32 0, i32 4
  %t75 = load i1, ptr %t74, !tbaa !21
  br i1 %t75, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb36
bb35:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/effects:Facts", ptr %t77, i32 0, i32 9
  %t80 = load i1, ptr %t79, !tbaa !21
  store i1 %t80, ptr %l37, !tbaa !21
  br label %bb36
bb36:
  %t82 = load i1, ptr %l37, !tbaa !21
  br i1 %t82, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb39
bb38:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/effects:Facts", ptr %t83, i32 0, i32 12
  %t86 = load i1, ptr %t85, !tbaa !21
  store i1 %t86, ptr %l40, !tbaa !21
  br label %bb39
bb39:
  %t88 = load i1, ptr %l40, !tbaa !21
  store i1 %t88, ptr %l2, !tbaa !21
  br label %bb70
bb40:
  %t89 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t91 = trunc i64 4 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb50
bb43:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/effects:Facts", ptr %t94, i32 0, i32 6
  %t97 = load i1, ptr %t96, !tbaa !21
  br i1 %t97, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb46
bb45:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/effects:Facts", ptr %t99, i32 0, i32 9
  %t102 = load i1, ptr %t101, !tbaa !21
  store i1 %t102, ptr %l47, !tbaa !21
  br label %bb46
bb46:
  %t104 = load i1, ptr %l47, !tbaa !21
  br i1 %t104, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb49
bb48:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/effects:Facts", ptr %t105, i32 0, i32 12
  %t108 = load i1, ptr %t107, !tbaa !21
  store i1 %t108, ptr %l50, !tbaa !21
  br label %bb49
bb49:
  %t110 = load i1, ptr %l50, !tbaa !21
  store i1 %t110, ptr %l2, !tbaa !21
  br label %bb70
bb50:
  %t111 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t113 = trunc i64 5 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb60
bb53:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/effects:Facts", ptr %t116, i32 0, i32 7
  %t119 = load i1, ptr %t118, !tbaa !21
  br i1 %t119, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb56
bb55:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/effects:Facts", ptr %t121, i32 0, i32 9
  %t124 = load i1, ptr %t123, !tbaa !21
  store i1 %t124, ptr %l57, !tbaa !21
  br label %bb56
bb56:
  %t126 = load i1, ptr %l57, !tbaa !21
  br i1 %t126, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb59
bb58:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/effects:Facts", ptr %t127, i32 0, i32 12
  %t130 = load i1, ptr %t129, !tbaa !21
  store i1 %t130, ptr %l60, !tbaa !21
  br label %bb59
bb59:
  %t132 = load i1, ptr %l60, !tbaa !21
  store i1 %t132, ptr %l2, !tbaa !21
  br label %bb70
bb60:
  %t133 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t135 = trunc i64 6 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eTerminates(ptr %v0, ptr %t138)
  store i1 %t140, ptr %l66
  br label %bb64
bb64:
  %t141 = load i1, ptr %l66, !tbaa !21
  store i1 %t141, ptr %l2, !tbaa !21
  br label %bb70
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_5b8067b2e95ea30f_d9100a71d97bc52b)
  unreachable
bb70:
  %t142 = load i1, ptr %l2, !tbaa !21
  store i1 %t142, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eIdle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l28 = alloca i1
  %l32 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 1
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t12, i32 0, i32 2
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Facts", ptr %t18, i32 0, i32 4
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/effects:Facts", ptr %t24, i32 0, i32 6
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Facts", ptr %t30, i32 0, i32 9
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Facts", ptr %t36, i32 0, i32 10
  %t39 = load i1, ptr %t38, !tbaa !21
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Facts", ptr %t42, i32 0, i32 12
  %t45 = load i1, ptr %t44, !tbaa !21
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb22, label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/effects:Facts", ptr %t49, i32 0, i32 11
  %t52 = load i1, ptr %t51, !tbaa !21
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb25, label %bb26
bb25:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/effects:Facts", ptr %t56, i32 0, i32 13
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = icmp eq i64 %t59, 0
  store i1 %t61, ptr %l28, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb27
bb27:
  %t63 = load i1, ptr %l28, !tbaa !21
  br i1 %t63, label %bb28, label %bb29
bb28:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/effects:Facts", ptr %t64, i32 0, i32 15
  %t67 = load i64, ptr %t66, !tbaa !24
  %t69 = icmp eq i64 %t67, 0
  store i1 %t69, ptr %l32, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb30
bb30:
  %t71 = load i1, ptr %l32, !tbaa !21
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eTerminates(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 7
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t12, i32 0, i32 9
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Facts", ptr %t18, i32 0, i32 1
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/effects:Facts", ptr %t24, i32 0, i32 5
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Facts", ptr %t30, i32 0, i32 12
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  %t36 = xor i1 %t35, true
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2feffects_2eendsNote(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eTerminates(ptr %v0, ptr %t22)
  store i1 %t24, ptr %l8
  br label %bb4
bb4:
  %t25 = load i1, ptr %l8, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %l9, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t28, ptr %l9, !tbaa !27
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l14, !tbaa !24
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l15, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l14, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t43, ptr %l9, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2feffects_2ehasBit(i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l4 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l2, !tbaa !24
  %t4 = call i64 @compiler_2feffects_2eparamBit(i64 %a1)
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = and i64 %t5, %t6
  %t9 = icmp ne i64 %t7, 0
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feffects_2eparamBit(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = icmp slt i64 %t5, 63
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load i64, ptr %l0, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = shl i64 1, %t12
  store i64 %t13, ptr %l6, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t15 = load i64, ptr %l6, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feffects_2equickC(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l17 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr @G_2ecompiler_2feffects_2equickNames, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t2 = load ptr, ptr %l1
  store i64 26, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l1
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = getelementptr [26 x { i64, ptr }], ptr %t13, i64 0, i64 %t14
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !37
  %t22 = load ptr, ptr @__olang_prog_scope
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t22, { i64, ptr } %a0, { i64, ptr } %t18)
  store i1 %t25, ptr %l17
  br label %bb5
bb5:
  %t26 = load i1, ptr %l17, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_3aEffects_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l16 = alloca %"compiler/effects:Facts"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l31 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"compiler/effects:Facts"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l40 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l41 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l42 = alloca %"compiler/effects:Effects"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l3
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l25
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l4
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l26
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l27
  br label %bb3
bb3:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l6
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l28
  br label %bb4
bb4:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l7
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l29
  br label %bb5
bb5:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l8
  %t15 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t15, ptr %l30
  br label %bb6
bb6:
  %t16 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l30
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %l9
  %t17 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t17, ptr %l31
  br label %bb7
bb7:
  %t18 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l31
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t18, ptr %l10
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l32
  br label %bb8
bb8:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l11
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l33
  br label %bb9
bb9:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l12
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l34
  br label %bb10
bb10:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l13
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l35
  br label %bb11
bb11:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l14
  store i64 0, ptr %l15, !tbaa !24
  %t27 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %v2)
  store %"compiler/effects:Facts" %t27, ptr %l36
  br label %bb12
bb12:
  %t28 = load %"compiler/effects:Facts", ptr %l36
  store %"compiler/effects:Facts" %t28, ptr %l16
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l37
  br label %bb13
bb13:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l17
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l38
  br label %bb14
bb14:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l18
  %t33 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t33, ptr %l39
  br label %bb15
bb15:
  %t34 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l39
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t34, ptr %l19
  %t35 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %l40
  br label %bb16
bb16:
  %t36 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t36, ptr %l20
  %t37 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t37, ptr %l41
  br label %bb17
bb17:
  %t38 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41
  %t39 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 0
  %t40 = load ptr, ptr %l2, !tbaa !29
  store ptr %t40, ptr %t39, !tbaa !29
  %t41 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 1
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %t41
  %t43 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 2
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %t43
  %t45 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 3
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %t45
  %t47 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 4
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %t47
  %t49 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 5
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t49
  %t51 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 6
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %t51
  %t53 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 7
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %t53
  %t55 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 8
  %t56 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t56, ptr %t55
  %t57 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 9
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %t57
  %t59 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 10
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t59
  %t61 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 11
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %t61
  %t63 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 12
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %t63
  %t65 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 13
  %t66 = load i64, ptr %l15, !tbaa !24
  store i64 %t66, ptr %t65, !tbaa !24
  %t67 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 14
  %t68 = load %"compiler/effects:Facts", ptr %l16
  store %"compiler/effects:Facts" %t68, ptr %t67
  %t69 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 15
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t69
  %t71 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 16
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %t71
  %t73 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 17
  %t74 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t74, ptr %t73
  %t75 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 18
  %t76 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t76, ptr %t75
  %t77 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t38, ptr %t77
  %t79 = getelementptr %"compiler/effects:Effects", ptr %l42, i32 0, i32 20
  store i64 -1, ptr %t79, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l42, i64 848, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/effects:Facts"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [6 x i64] undef, i64 -1, 0
  %t2 = insertvalue [6 x i64] %t1, i64 -1, 1
  %t3 = insertvalue [6 x i64] %t2, i64 -1, 2
  %t4 = insertvalue [6 x i64] %t3, i64 -1, 3
  %t5 = insertvalue [6 x i64] %t4, i64 -1, 4
  %t6 = insertvalue [6 x i64] %t5, i64 -1, 5
  %t9 = insertvalue %"compiler/effects:Facts" undef, i1 false, 0
  %t11 = insertvalue %"compiler/effects:Facts" %t9, i1 false, 1
  %t13 = insertvalue %"compiler/effects:Facts" %t11, i1 false, 2
  %t15 = insertvalue %"compiler/effects:Facts" %t13, i1 false, 3
  %t17 = insertvalue %"compiler/effects:Facts" %t15, i1 false, 4
  %t19 = insertvalue %"compiler/effects:Facts" %t17, i1 false, 5
  %t21 = insertvalue %"compiler/effects:Facts" %t19, i1 false, 6
  %t23 = insertvalue %"compiler/effects:Facts" %t21, i1 false, 7
  %t25 = insertvalue %"compiler/effects:Facts" %t23, i1 false, 8
  %t27 = insertvalue %"compiler/effects:Facts" %t25, i1 false, 9
  %t29 = insertvalue %"compiler/effects:Facts" %t27, i1 false, 10
  %t31 = insertvalue %"compiler/effects:Facts" %t29, i1 false, 11
  %t33 = insertvalue %"compiler/effects:Facts" %t31, i1 false, 12
  %t35 = insertvalue %"compiler/effects:Facts" %t33, i64 0, 13
  %t37 = insertvalue %"compiler/effects:Facts" %t35, [6 x i64] %t6, 14
  %t39 = insertvalue %"compiler/effects:Facts" %t37, i64 0, 15
  store %"compiler/effects:Facts" %t39, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Facts", ptr %rv
  ret %"compiler/effects:Facts" %rr
}

define dso_local %"compiler/effects:link" @compiler_2feffects_3alink_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/effects:link"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/effects:link" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/effects:link" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/effects:link" %t10, i64 %a2, 2
  store %"compiler/effects:link" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:link", ptr %rv
  ret %"compiler/effects:link" %rr
}

define dso_local %"compiler/effects:pair" @compiler_2feffects_3apair_2ector(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/effects:pair"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/effects:pair" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/effects:pair" %t6, i64 %a1, 1
  store %"compiler/effects:pair" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:pair", ptr %rv
  ret %"compiler/effects:pair" %rr
}

define dso_local %"compiler/effects:root" @compiler_2feffects_3aroot_2ector(ptr %v0, i64 %a0, i1 %a1) #0 {
entry:
  %rv = alloca %"compiler/effects:root"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/effects:root" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/effects:root" %t6, i1 %a1, 1
  store %"compiler/effects:root" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:root", ptr %rv
  ret %"compiler/effects:root" %rr
}

@.d0 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"files" }>, align 8
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"network" }>, align 8
@.d2 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"processes" }>, align 8
@.d3 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"environment" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"C" }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"threads" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d9 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"not known - it reaches code that did not check" }>, align 8
@.d10 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c"anything - it calls through a function value or an 'any'" }>, align 8
@.d11 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"none - it may be computed while compiling where its arguments are known" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d15 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d16 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"writes through " }>, align 8
@.d17 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"writes a global" }>, align 8
@.d18 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"allocates" }>, align 8
@.d19 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"allocates nothing" }>, align 8
@.d20 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"may grow a Vec" }>, align 8
@.d21 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"starts tasks" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"calls C" }>, align 8
@.d24 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"may end the program" }>, align 8
@.d25 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"may block" }>, align 8
@.d26 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"never blocks" }>, align 8
@.d27 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"recursive" }>, align 8
@.d28 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"always ends" }>, align 8
@.d29 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"may be computed while compiling" }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"; " }>, align 8
@.d31 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Allocates" }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Blocks" }>, align 8
@.d33 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"WritesGlobals" }>, align 8
@.d34 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"CallsC" }>, align 8
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Spawns" }>, align 8
@.d36 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Recursive" }>, align 8
@.d37 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Terminates" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d38 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"pthread_create" }>, align 8
@.d39 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
declare void @__olang_ert_req_clear()
@.d40 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"exit" }>, align 8
@.d42 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_exit" }>, align 8
@.d43 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"abort" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d45 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d46 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"; recursive" }>, align 8
@.d47 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"; always ends" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_loc_290980515b4efda2_9d4c073daad962b6 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ca5cd6c537ac5d6_e2b62d3f2efcd5d2 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4055e0fe87b920f9_59f1ceb8b6607d = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ePush_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0, %"compiler/effects:link" %a1)
@olang_loc_1bc29689bbb58e32_9924d9acc7f0abd6 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_696967e496dd013f_3ccf8d6ad66b978b = external constant [0 x i8]
@olang_loc_97fbcd283fc57d27_f3da2d8a892755b3 = external constant [0 x i8]
@olang_loc_261689b2925f7f5_26a5fe8340cfcde1 = external constant [0 x i8]
@olang_loc_b6aab166389be830_fe1a1964ddaa5424 = external constant [0 x i8]
@olang_loc_28b83159130c3f56_5f8d6e7786c968a = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_d8634726df7208f7_383307572af5b0b3 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_5ee506974b9441c7_64c0c11887ed9ad3 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ePush_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, %"compiler/effects:Facts" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H691765597a1d0d55e0f84306543aa643(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_H7835af935af759534f3892df019d3666(ptr %v0, ptr %a0, %"compiler/effects:pair" %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_H5e2f333902255d77192898689554d128(ptr %v0, ptr %a0, %"compiler/effects:pair" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H1e7e683fc0332c06b6c705cd46691777(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_Ha1bc2f35f7d195c0ca99c509224bae7a(ptr %v0, ptr %a0, %"compiler/effects:pair" %a1, i1 %a2)
@olang_loc_8e774b84f9d07387_321b570aadbfd9f3 = external constant [0 x i8]
@olang_loc_def19e55677a13ff_78d59d2dfbb79d83 = external constant [0 x i8]
@olang_loc_31e57a958c31a5ba_705aefa950dbf3e6 = external constant [0 x i8]
@olang_loc_e883a08fe0a2dfcb_10d50552a173805f = external constant [0 x i8]
@olang_loc_be89c63eecba24dc_20b8a06f464464c0 = external constant [0 x i8]
@olang_loc_da29f57e967b0d58_398b0b5997e9910c = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eSetAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/effects:Facts" %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hec46674a538af874724ad5c9698b0829(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eLen_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:link" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eAt_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_cdd9fd819eb1314_592489ef7c054390 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_51a035064631b681_e4502e206a44b155 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hca3b6abf349bf7326560c41fbdf5fb42(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Had7562134349141a1e65e244951d3fe8(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
@olang_loc_b365fbc2fc2a8203_e371dcb77fb488d7 = external constant [0 x i8]
@olang_loc_5b8067b2e95ea30f_d9100a71d97bc52b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
