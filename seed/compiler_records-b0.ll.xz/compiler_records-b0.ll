; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, i1, i1, i64, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, { i64, ptr }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, i1, { i64, ptr }, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/views:Kept" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/views:Cand" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fsBody", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, ptr, { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i1, i1, i1, i1, i1, { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fnRecs", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, { i64, [2 x i64] }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"compiler/source:Span", i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i1, i1, i1, i1, i64, i1, i1, i1, i1, i64, i1, i1, i1, i1, i64, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, ptr, { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:instTree", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:instTree", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/scope:Gap", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:fsBody" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:fnRecs" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:instTree" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/build:Held" = type { { i64, ptr }, { i64, ptr }, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/eval:Blob" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/eval:Image" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8" = type { i64, %"compiler/eval:Image" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
define dso_local { i64, ptr } @compiler_2frecords_2eBuildInputs(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/os:FileInfo"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/target:Target"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l11 = alloca %"std/os:FileInfo"
  %l13 = alloca %"std/os:FileInfo"
  %l14 = alloca i32
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l29 = alloca %"compiler/target:Target"
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d0, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l8
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l7
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l8, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s0, { i64, ptr } %t13)
  %t16 = extractvalue { i32, %"std/os:FileInfo" } %t15, 1
  %t17 = extractvalue { i32, %"std/os:FileInfo" } %t15, 0
  store i32 %t17, ptr %l14
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb8, label %ok.19, !prof !99
ok.19:
  store %"std/os:FileInfo" %t16, ptr %l13
  br label %bb7
bb7:
  %t20 = load %"std/os:FileInfo", ptr %l13
  store %"std/os:FileInfo" %t20, ptr %l11
  br label %bb12
bb8:
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  store i1 %t24, ptr %l16, !tbaa !21
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t30, ptr %l20, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load i64, ptr %l21, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l22, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l21, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t44, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb12:
  %t46 = load %"std/os:FileInfo", ptr %l11
  store %"std/os:FileInfo" %t46, ptr %l3
  %t47 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t48 = extractvalue { i32, { i64, ptr } } %t47, 1
  %t49 = extractvalue { i32, { i64, ptr } } %t47, 0
  store i32 %t49, ptr %l25
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb14, label %ok.51, !prof !99
ok.51:
  store { i64, ptr } %t48, ptr %l24
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t52, ptr %l23, !tbaa !27
  br label %bb18
bb14:
  %t53 = load i32, ptr %l25, !tbaa !23
  %t54 = ashr i32 %t53, 16
  %t56 = icmp eq i32 %t54, 1
  br i1 %t56, label %bb15, label %bb16
bb15:
  call void @__olang_errpay_pop()
  br label %bb16
bb16:
  br label %bb17
bb17:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb18
bb18:
  %t58 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t58, ptr %l4, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/build:Config", ptr %t59, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t61, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l29, i64 152, i1 false)
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t62, ptr %l30, !tbaa !27
  %t63 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 1
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l31, !tbaa !24
  %t65 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 2
  %t66 = load i64, ptr %t65, !tbaa !24
  store i64 %t66, ptr %l32, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/build:Config", ptr %t67, i32 0, i32 4
  %t70 = load i1, ptr %t69, !tbaa !21
  store i1 %t70, ptr %l34, !tbaa !21
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/build:Config", ptr %t71, i32 0, i32 6
  %t74 = load i1, ptr %t73, !tbaa !21
  store i1 %t74, ptr %l36, !tbaa !21
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/build:Config", ptr %t75, i32 0, i32 7
  %t78 = load i1, ptr %t77, !tbaa !21
  store i1 %t78, ptr %l38, !tbaa !21
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/build:Config", ptr %t79, i32 0, i32 5
  %t82 = load i1, ptr %t81, !tbaa !21
  store i1 %t82, ptr %l40, !tbaa !21
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/build:Config", ptr %t83, i32 0, i32 11
  %t86 = load i1, ptr %t85, !tbaa !21
  store i1 %t86, ptr %l42, !tbaa !21
  store i1 %a1, ptr %l43, !tbaa !21
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/build:Config", ptr %t88, i32 0, i32 18
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l46, !tbaa !27
  br label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l46, !tbaa !27
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/build:Config", ptr %t93, i32 0, i32 22
  %t96 = load i1, ptr %t95, !tbaa !21
  br i1 %t96, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l49, !tbaa !27
  br label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l49, !tbaa !27
  br label %bb24
bb24:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/build:Config", ptr %t98, i32 0, i32 16
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t103 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t101, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t103, ptr %l52
  br label %bb25
bb25:
  %t104 = load i1, ptr %l52, !tbaa !21
  %t105 = xor i1 %t104, true
  br i1 %t105, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l54, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l54, !tbaa !27
  br label %bb28
bb28:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/build:Config", ptr %t107, i32 0, i32 19
  %t110 = load i1, ptr %t109, !tbaa !21
  br i1 %t110, label %bb29, label %bb30
bb29:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l57, !tbaa !27
  br label %bb31
bb30:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l57, !tbaa !27
  br label %bb31
bb31:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/build:Config", ptr %t112, i32 0, i32 26
  %t115 = load i1, ptr %t114, !tbaa !21
  br i1 %t115, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l60, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l60, !tbaa !27
  br label %bb34
bb34:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/build:Config", ptr %t117, i32 0, i32 10
  %t120 = load i1, ptr %t119, !tbaa !21
  br i1 %t120, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l63, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l63, !tbaa !27
  br label %bb37
bb37:
  %t122 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 1
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l64, !tbaa !27
  %t124 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l65, !tbaa !27
  %t126 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 4
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l66, !tbaa !27
  %t128 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 5
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l67, !tbaa !27
  %t130 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 10
  %t131 = load i1, ptr %t130, !tbaa !21
  br i1 %t131, label %bb38, label %bb39
bb38:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb40
bb40:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/build:Config", ptr %t133, i32 0, i32 3
  %t137 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFingerprint(ptr %v0, ptr %s0, ptr %t135)
  store { i64, ptr } %t137, ptr %l72
  br label %bb41
bb41:
  %t138 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t138, ptr %l73, !tbaa !27
  %t139 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t139, ptr %l74
  br label %bb42
bb42:
  %t140 = call { i64, ptr } @compiler_2frecords_2eruntimeStamp(ptr %s0)
  store { i64, ptr } %t140, ptr %l75
  br label %bb43
bb43:
  %t141 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t146 = add i64 %t143, %t145
  %t147 = load i64, ptr %l31, !tbaa !24
  %t148 = call i64 @__olang_fmt_i64(ptr null, i64 %t147)
  %t149 = add i64 %t146, %t148
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t151 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t152 = add i64 %t149, %t151
  %t153 = load i64, ptr %l32, !tbaa !24
  %t154 = call i64 @__olang_fmt_i64(ptr null, i64 %t153)
  %t155 = add i64 %t152, %t154
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t158 = add i64 %t155, %t157
  %t159 = load i1, ptr %l34, !tbaa !21
  %t160 = select i1 %t159, ptr @.c21, ptr @.c22
  %t161 = select i1 %t159, i64 4, i64 5
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t166 = load i1, ptr %l36, !tbaa !21
  %t167 = select i1 %t166, ptr @.c21, ptr @.c22
  %t168 = select i1 %t166, i64 4, i64 5
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = load i1, ptr %l38, !tbaa !21
  %t174 = select i1 %t173, ptr @.c21, ptr @.c22
  %t175 = select i1 %t173, i64 4, i64 5
  %t176 = add i64 %t172, %t175
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t180 = load i1, ptr %l40, !tbaa !21
  %t181 = select i1 %t180, ptr @.c21, ptr @.c22
  %t182 = select i1 %t180, i64 4, i64 5
  %t183 = add i64 %t179, %t182
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t186 = add i64 %t183, %t185
  %t187 = load i1, ptr %l42, !tbaa !21
  %t188 = select i1 %t187, ptr @.c21, ptr @.c22
  %t189 = select i1 %t187, i64 4, i64 5
  %t190 = add i64 %t186, %t189
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t192 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t193 = add i64 %t190, %t192
  %t194 = load i1, ptr %l43, !tbaa !21
  %t195 = select i1 %t194, ptr @.c21, ptr @.c22
  %t196 = select i1 %t194, i64 4, i64 5
  %t197 = add i64 %t193, %t196
  %t198 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 1
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t201 = add i64 %t197, %t200
  %t202 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = add i64 %t201, %t204
  %t206 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = add i64 %t205, %t208
  %t210 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = add i64 %t213, %t216
  %t218 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t231 = add i64 %t228, %t230
  %t232 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t239 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = add i64 %t238, %t241
  %t243 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t245 = add i64 %t242, %t244
  %t246 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t246, 1
  %t248 = extractvalue { i64, ptr } %t246, 0
  %t249 = add i64 %t245, %t248
  %t250 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = add i64 %t256, %t259
  %t261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t264 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = add i64 %t263, %t266
  %t268 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t270 = add i64 %t267, %t269
  %t271 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = add i64 %t270, %t273
  %t275 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t276 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t277 = add i64 %t274, %t276
  %t278 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = add i64 %t277, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t142, i64 %t143)
  %t283 = getelementptr i8, ptr %t282, i64 %t143
  call void @olang_textcopy(ptr %t283, ptr %t144, i64 %t145)
  %t284 = getelementptr i8, ptr %t283, i64 %t145
  %t285 = call i64 @__olang_fmt_i64(ptr %t284, i64 %t147)
  %t286 = getelementptr i8, ptr %t284, i64 %t148
  call void @olang_textcopy(ptr %t286, ptr %t150, i64 %t151)
  %t287 = getelementptr i8, ptr %t286, i64 %t151
  %t288 = call i64 @__olang_fmt_i64(ptr %t287, i64 %t153)
  %t289 = getelementptr i8, ptr %t287, i64 %t154
  call void @olang_textcopy(ptr %t289, ptr %t156, i64 %t157)
  %t290 = getelementptr i8, ptr %t289, i64 %t157
  call void @olang_textcopy(ptr %t290, ptr %t160, i64 %t161)
  %t291 = getelementptr i8, ptr %t290, i64 %t161
  call void @olang_textcopy(ptr %t291, ptr %t163, i64 %t164)
  %t292 = getelementptr i8, ptr %t291, i64 %t164
  call void @olang_textcopy(ptr %t292, ptr %t167, i64 %t168)
  %t293 = getelementptr i8, ptr %t292, i64 %t168
  call void @olang_textcopy(ptr %t293, ptr %t170, i64 %t171)
  %t294 = getelementptr i8, ptr %t293, i64 %t171
  call void @olang_textcopy(ptr %t294, ptr %t174, i64 %t175)
  %t295 = getelementptr i8, ptr %t294, i64 %t175
  call void @olang_textcopy(ptr %t295, ptr %t177, i64 %t178)
  %t296 = getelementptr i8, ptr %t295, i64 %t178
  call void @olang_textcopy(ptr %t296, ptr %t181, i64 %t182)
  %t297 = getelementptr i8, ptr %t296, i64 %t182
  call void @olang_textcopy(ptr %t297, ptr %t184, i64 %t185)
  %t298 = getelementptr i8, ptr %t297, i64 %t185
  call void @olang_textcopy(ptr %t298, ptr %t188, i64 %t189)
  %t299 = getelementptr i8, ptr %t298, i64 %t189
  call void @olang_textcopy(ptr %t299, ptr %t191, i64 %t192)
  %t300 = getelementptr i8, ptr %t299, i64 %t192
  call void @olang_textcopy(ptr %t300, ptr %t195, i64 %t196)
  %t301 = getelementptr i8, ptr %t300, i64 %t196
  call void @olang_textcopy(ptr %t301, ptr %t199, i64 %t200)
  %t302 = getelementptr i8, ptr %t301, i64 %t200
  call void @olang_textcopy(ptr %t302, ptr %t203, i64 %t204)
  %t303 = getelementptr i8, ptr %t302, i64 %t204
  call void @olang_textcopy(ptr %t303, ptr %t207, i64 %t208)
  %t304 = getelementptr i8, ptr %t303, i64 %t208
  call void @olang_textcopy(ptr %t304, ptr %t211, i64 %t212)
  %t305 = getelementptr i8, ptr %t304, i64 %t212
  call void @olang_textcopy(ptr %t305, ptr %t215, i64 %t216)
  %t306 = getelementptr i8, ptr %t305, i64 %t216
  call void @olang_textcopy(ptr %t306, ptr %t219, i64 %t220)
  %t307 = getelementptr i8, ptr %t306, i64 %t220
  call void @olang_textcopy(ptr %t307, ptr %t222, i64 %t223)
  %t308 = getelementptr i8, ptr %t307, i64 %t223
  call void @olang_textcopy(ptr %t308, ptr %t226, i64 %t227)
  %t309 = getelementptr i8, ptr %t308, i64 %t227
  call void @olang_textcopy(ptr %t309, ptr %t229, i64 %t230)
  %t310 = getelementptr i8, ptr %t309, i64 %t230
  call void @olang_textcopy(ptr %t310, ptr %t233, i64 %t234)
  %t311 = getelementptr i8, ptr %t310, i64 %t234
  call void @olang_textcopy(ptr %t311, ptr %t236, i64 %t237)
  %t312 = getelementptr i8, ptr %t311, i64 %t237
  call void @olang_textcopy(ptr %t312, ptr %t240, i64 %t241)
  %t313 = getelementptr i8, ptr %t312, i64 %t241
  call void @olang_textcopy(ptr %t313, ptr %t243, i64 %t244)
  %t314 = getelementptr i8, ptr %t313, i64 %t244
  call void @olang_textcopy(ptr %t314, ptr %t247, i64 %t248)
  %t315 = getelementptr i8, ptr %t314, i64 %t248
  call void @olang_textcopy(ptr %t315, ptr %t251, i64 %t252)
  %t316 = getelementptr i8, ptr %t315, i64 %t252
  call void @olang_textcopy(ptr %t316, ptr %t254, i64 %t255)
  %t317 = getelementptr i8, ptr %t316, i64 %t255
  call void @olang_textcopy(ptr %t317, ptr %t258, i64 %t259)
  %t318 = getelementptr i8, ptr %t317, i64 %t259
  call void @olang_textcopy(ptr %t318, ptr %t261, i64 %t262)
  %t319 = getelementptr i8, ptr %t318, i64 %t262
  call void @olang_textcopy(ptr %t319, ptr %t265, i64 %t266)
  %t320 = getelementptr i8, ptr %t319, i64 %t266
  call void @olang_textcopy(ptr %t320, ptr %t268, i64 %t269)
  %t321 = getelementptr i8, ptr %t320, i64 %t269
  call void @olang_textcopy(ptr %t321, ptr %t272, i64 %t273)
  %t322 = getelementptr i8, ptr %t321, i64 %t273
  call void @olang_textcopy(ptr %t322, ptr %t275, i64 %t276)
  %t323 = getelementptr i8, ptr %t322, i64 %t276
  call void @olang_textcopy(ptr %t323, ptr %t279, i64 %t280)
  %t324 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t282, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t325, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2frecords_2eCheckIncrFailed(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %l26 = alloca i64
  %l30 = alloca i32
  %l32 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Kept", ptr %t1, i32 0, i32 6
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store { i64, ptr } %t19, ptr %l13
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t22 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t25 = extractvalue { i64, ptr } %t20, 1
  %t26 = extractvalue { i64, ptr } %t20, 0
  %t27 = add i64 %t23, %t26
  %t28 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = getelementptr i8, ptr %t31, i64 %t23
  call void @olang_textcopy(ptr %t32, ptr %t25, i64 %t26)
  %t33 = getelementptr i8, ptr %t32, i64 %t26
  call void @olang_textcopy(ptr %t33, ptr %t28, i64 %t29)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t31, 1
  %t37 = call i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t35)
  store i32 %t37, ptr %l16
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb8, label %ok.39, !prof !99
ok.39:
  br label %bb7
bb7:
  br label %bb12
bb8:
  %t40 = load i32, ptr %l16, !tbaa !23
  %t41 = ashr i32 %t40, 16
  %t43 = icmp eq i32 %t41, 1
  store i1 %t43, ptr %l18, !tbaa !21
  %t44 = load i32, ptr %l16, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  br i1 %t47, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t52 = add i64 %t49, 1
  store i64 %t52, ptr %l2, !tbaa !24
  br label %bb1
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/views:Kept", ptr %t54, i32 0, i32 6
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l26
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/views:Kept", ptr %t59, i32 0, i32 4
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t65 = load i64, ptr %l26, !tbaa !24
  %t66 = call i64 @__olang_fmt_i64(ptr null, i64 %t65)
  %t67 = add i64 %t64, %t66
  %t68 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t72 = call i64 @__olang_fmt_i64(ptr null, i64 %t62)
  %t73 = add i64 %t70, %t72
  %t74 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t63, i64 %t64)
  %t78 = getelementptr i8, ptr %t77, i64 %t64
  %t79 = call i64 @__olang_fmt_i64(ptr %t78, i64 %t65)
  %t80 = getelementptr i8, ptr %t78, i64 %t66
  call void @olang_textcopy(ptr %t80, ptr %t68, i64 %t69)
  %t81 = getelementptr i8, ptr %t80, i64 %t69
  %t82 = call i64 @__olang_fmt_i64(ptr %t81, i64 %t62)
  %t83 = getelementptr i8, ptr %t81, i64 %t72
  call void @olang_textcopy(ptr %t83, ptr %t74, i64 %t75)
  %t84 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t77, 1
  %t87 = call i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t85)
  store i32 %t87, ptr %l30
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb17, label %ok.89, !prof !99
ok.89:
  br label %bb16
bb16:
  br label %bb21
bb17:
  %t90 = load i32, ptr %l30, !tbaa !23
  %t91 = ashr i32 %t90, 16
  %t93 = icmp eq i32 %t91, 1
  store i1 %t93, ptr %l32, !tbaa !21
  %t94 = load i32, ptr %l30, !tbaa !23
  %t95 = ashr i32 %t94, 16
  %t97 = icmp eq i32 %t95, 1
  br i1 %t97, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  call void @std_2fos_2eExit(i32 3)
  unreachable
bb22:
  call void @__olang_check_failed(ptr @olang_loc_fb666446bedbe7d2_84e447b691c6d3de)
  unreachable
ret:
  ret void
}

define dso_local void @compiler_2frecords_2eFrontRecords(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %lp17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l26 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca i1
  %l63 = alloca ptr
  %l67 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l81 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l96 = alloca { i64, ptr }
  %l101 = alloca i1
  %l103 = alloca i1
  %l104 = alloca { i64, ptr }
  %l106 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l116 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca %"compiler/views:Cand"
  %l123 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l130 = alloca %"compiler/views:Cand"
  %l131 = alloca i32
  %l133 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t6, i64 %t7)
  %t12 = getelementptr i8, ptr %t11, i64 %t7
  call void @olang_textcopy(ptr %t12, ptr %t8, i64 %t9)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t11, 1
  %t17 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s0, ptr %s0, { i64, ptr } %t14)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l24
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb2, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l23
  br label %bb1
bb1:
  %t22 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  br label %bb6
bb2:
  %t23 = load i32, ptr %l24, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  store i1 %t26, ptr %l26, !tbaa !21
  %t27 = load i32, ptr %l24, !tbaa !23
  %t28 = ashr i32 %t27, 16
  %t30 = icmp eq i32 %t28, 1
  br i1 %t30, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l37, !tbaa !24
  store i64 %t63, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l34, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb60
bb15:
  br label %bb16
bb16:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l10, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t83, ptr %l55, !tbaa !27
  %t84 = load i64, ptr %l10, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %t87, i64 %t84
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !37
  %t91 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s4, { i64, ptr } %t89, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t91, ptr %l58
  br label %bb17
bb17:
  %t92 = load i1, ptr %l58, !tbaa !21
  br i1 %t92, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb21
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/load:Loader", ptr %t93, i32 0, i32 10
  %t96 = load i64, ptr %l10, !tbaa !24
  %t99 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t95, i64 %t96)
  store ptr %t99, ptr %l63
  br label %bb20
bb20:
  %t100 = load ptr, ptr %l63, !tbaa !29
  %t102 = getelementptr %"compiler/load:Module", ptr %t100, i32 0, i32 4
  %t103 = load i64, ptr %t102, !tbaa !24
  %t105 = icmp slt i64 %t103, 0
  store i1 %t105, ptr %l59, !tbaa !21
  br label %bb21
bb21:
  %t107 = load i1, ptr %l59, !tbaa !21
  br i1 %t107, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb23:
  br label %bb24
bb24:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l67, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 10
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t111, i64 %t112)
  store ptr %t115, ptr %l71
  br label %bb25
bb25:
  %t116 = load ptr, ptr %l71, !tbaa !29
  %t118 = getelementptr %"compiler/load:Module", ptr %t116, i32 0, i32 2
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t120, ptr %l74, !tbaa !27
  %t121 = load i64, ptr %l10, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %t124, i64 %t121
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !37
  %t127 = load ptr, ptr %l67, !tbaa !29
  %t130 = call { i64, ptr } @compiler_2frecords_2efrontStem(ptr %v1, ptr %v0, ptr %v2, ptr %s4, ptr %t127, { i64, ptr } %t119, { i64, ptr } %t126)
  store { i64, ptr } %t130, ptr %l77
  br label %bb26
bb26:
  %t131 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t131, ptr %l11, !tbaa !27
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr %"compiler/build:Config", ptr %t132, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t139 = add i64 %t137, 5
  store i64 %t139, ptr %l81, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l83, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l84, !tbaa !24
  %t145 = load i64, ptr %l81, !tbaa !24
  %t146 = icmp sge i64 %t145, 0
  br i1 %t146, label %bb27, label %bb28
bb27:
  %t148 = load i64, ptr %l81, !tbaa !24
  %t149 = load i64, ptr %l83, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_323c52581f8b1abf_a440e4b95536001b)
  unreachable
bb29:
  %t152 = load i64, ptr %l83, !tbaa !24
  %t153 = load i64, ptr %l84, !tbaa !24
  %t154 = icmp sle i64 %t152, %t153
  br i1 %t154, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_323c52581f8b1abf_a440e4b95536001b)
  unreachable
bb31:
  %t156 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l81, !tbaa !24
  %t159 = load i64, ptr %l83, !tbaa !24
  %t160 = getelementptr i8, ptr %t157, i64 %t158
  %t161 = sub i64 %t159, %t158
  %t162 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t160, 1
  store { i64, ptr } %t163, ptr %l12, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t165, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l15, !tbaa !24
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_323c52581f8b1abf_a440e4b95536001b)
  unreachable
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t171 = load i64, ptr %l14, !tbaa !24
  %t172 = load i64, ptr %l15, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb58
bb35:
  br label %bb36
bb36:
  %t179 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t179, ptr %l96, !tbaa !27
  %t180 = load i64, ptr %l14, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %t183, i64 %t180
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !37
  store { i64, ptr } %t185, ptr %l16, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t191 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t187, { i64, ptr } %t188)
  store i1 %t191, ptr %l101
  br label %bb37
bb37:
  %t192 = load i1, ptr %l101, !tbaa !21
  %t193 = xor i1 %t192, true
  br i1 %t193, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb47
bb39:
  %t195 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t195, ptr %l104, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  store i64 %t198, ptr %l106, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t199, 0
  store i64 %t202, ptr %l109, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  store i64 %t204, ptr %l110, !tbaa !24
  %t205 = load i64, ptr %l106, !tbaa !24
  %t206 = icmp sge i64 %t205, 0
  br i1 %t206, label %bb40, label %bb41
bb40:
  %t208 = load i64, ptr %l106, !tbaa !24
  %t209 = load i64, ptr %l109, !tbaa !24
  %t210 = icmp sle i64 %t208, %t209
  br i1 %t210, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_9c5452f20d69d8c2_bc172545126ff01e)
  unreachable
bb42:
  %t212 = load i64, ptr %l109, !tbaa !24
  %t213 = load i64, ptr %l110, !tbaa !24
  %t214 = icmp sle i64 %t212, %t213
  br i1 %t214, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_9c5452f20d69d8c2_bc172545126ff01e)
  unreachable
bb44:
  %t216 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = load i64, ptr %l106, !tbaa !24
  %t219 = load i64, ptr %l109, !tbaa !24
  %t220 = getelementptr i8, ptr %t217, i64 %t218
  %t221 = sub i64 %t219, %t218
  %t222 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t220, 1
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l116, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t227 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s7, { i64, ptr } %t223, { i64, ptr } %t226)
  store i1 %t227, ptr %l117
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_9c5452f20d69d8c2_bc172545126ff01e)
  unreachable
bb46:
  %t228 = load i1, ptr %l117, !tbaa !21
  store i1 %t228, ptr %l103, !tbaa !21
  br label %bb47
bb47:
  %t229 = load i1, ptr %l103, !tbaa !21
  br i1 %t229, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s7)
  br label %bb57
bb49:
  br label %bb50
bb50:
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr %"compiler/build:Config", ptr %t230, i32 0, i32 0
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t233, 1
  %t237 = extractvalue { i64, ptr } %t233, 0
  %t238 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t239 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t240 = add i64 %t237, %t239
  %t242 = extractvalue { i64, ptr } %t234, 1
  %t243 = extractvalue { i64, ptr } %t234, 0
  %t244 = add i64 %t240, %t243
  %t245 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t244)
  call void @olang_textcopy(ptr %t245, ptr %t236, i64 %t237)
  %t246 = getelementptr i8, ptr %t245, i64 %t237
  call void @olang_textcopy(ptr %t246, ptr %t238, i64 %t239)
  %t247 = getelementptr i8, ptr %t246, i64 %t239
  call void @olang_textcopy(ptr %t247, ptr %t242, i64 %t243)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t245, 1
  store { i64, ptr } %t249, ptr %l123, !tbaa !27
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/load:Loader", ptr %t251, i32 0, i32 10
  %t254 = load i64, ptr %l10, !tbaa !24
  %t257 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t253, i64 %t254)
  store ptr %t257, ptr %l127
  br label %bb51
bb51:
  %t258 = load ptr, ptr %l127, !tbaa !29
  %t260 = getelementptr %"compiler/load:Module", ptr %t258, i32 0, i32 4
  %t261 = load i64, ptr %t260, !tbaa !24
  %t262 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t264 = call { i32, %"compiler/views:Cand" } @compiler_2frecords_2efrontRecord(ptr %s7, ptr %v3, { i64, ptr } %t262, i64 %t261)
  %t265 = extractvalue { i32, %"compiler/views:Cand" } %t264, 1
  %t266 = extractvalue { i32, %"compiler/views:Cand" } %t264, 0
  store i32 %t266, ptr %l131
  %t267 = icmp ne i32 %t266, 0
  br i1 %t267, label %bb53, label %ok.268, !prof !99
ok.268:
  store %"compiler/views:Cand" %t265, ptr %l130
  br label %bb52
bb52:
  %t269 = load %"compiler/views:Cand", ptr %l130
  store %"compiler/views:Cand" %t269, ptr %l118
  br label %bb55
bb53:
  %t270 = load i32, ptr %l131, !tbaa !23
  %t271 = ashr i32 %t270, 16
  %t273 = icmp eq i32 %t271, 1
  store i1 %t273, ptr %l133, !tbaa !21
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s7)
  br label %bb57
bb55:
  %t274 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 104, i64 8)
  store ptr %t274, ptr %lp17
  %t275 = load %"compiler/views:Cand", ptr %l118
  %t276 = load ptr, ptr %lp17
  store %"compiler/views:Cand" %t275, ptr %t276
  %t279 = getelementptr %"compiler/views:Kept", ptr %a3, i32 0, i32 0
  %t280 = load ptr, ptr %lp17
  %t281 = load %"compiler/views:Cand", ptr %t280
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aCand_3e_2ePush_3ccompiler_2fviews_3aCand_3e(ptr %v3, ptr %v3, ptr %t279, %"compiler/views:Cand" %t281)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s7)
  br label %bb57
bb57:
  %t284 = load i64, ptr %l14, !tbaa !24
  %t287 = add i64 %t284, 1
  store i64 %t287, ptr %l14, !tbaa !24
  br label %bb33
bb58:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb59:
  %t289 = load i64, ptr %l9, !tbaa !24
  %t292 = add i64 %t289, 1
  store i64 %t292, ptr %l9, !tbaa !24
  br label %bb13
bb60:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2frecords_2eKeepFront(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l31 = alloca i64
  %l33 = alloca i1
  %l39 = alloca { i64, ptr }
  %l44 = alloca i32
  %l46 = alloca i1
  %l49 = alloca i32
  %l55 = alloca i64
  %l58 = alloca i64
  %l76 = alloca { i64, ptr }
  %l79 = alloca i1
  %l80 = alloca i1
  %l84 = alloca ptr
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca ptr
  %l94 = alloca ptr
  %l97 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca i32
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca i64
  %l104 = alloca %"std/prelude/text:StringBuilder"
  %l106 = alloca { i64, ptr }
  %l109 = alloca i1
  %l112 = alloca { i64, ptr }
  %l118 = alloca i64
  %l120 = alloca i64
  %l125 = alloca { i64, ptr }
  %l137 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l139 = alloca i64
  %l141 = alloca i64
  %l146 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca ptr
  %l161 = alloca ptr
  %l164 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l172 = alloca i64
  %l178 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l185 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/views:Kept", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2frecords_2echeckOthers(ptr %v0, ptr %v1, ptr %v4, ptr %v5, ptr %t6, ptr %t7, ptr %t8, ptr %t9)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t16 = getelementptr %"compiler/views:Kept", ptr %t14, i32 0, i32 7
  %t18 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cs_H4aa8749bc5cf37a88c7557cdc2f2204a(ptr %v4, ptr %t16)
  store i64 %t18, ptr %l31
  br label %bb5
bb5:
  %t19 = load i64, ptr %l31, !tbaa !24
  %t20 = icmp eq i64 %t19, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb8
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp eq i64 %t24, 0
  store i1 %t26, ptr %l33, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l33, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = call { i64, ptr } @compiler_2frecords_2eReaderRecords(ptr %v0, ptr %v1, ptr %s0, ptr %t29, ptr %t30)
  store { i64, ptr } %t33, ptr %l39
  br label %bb12
bb12:
  %t34 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t34, ptr %l6, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 1
  %t41 = extractvalue { i64, ptr } %t38, 0
  %t42 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t40, i64 %t41)
  %t46 = getelementptr i8, ptr %t45, i64 %t41
  call void @olang_textcopy(ptr %t46, ptr %t42, i64 %t43)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  %t51 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t48)
  store i32 %t51, ptr %l44
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb14, label %ok.53, !prof !99
ok.53:
  br label %bb13
bb13:
  br label %bb18
bb14:
  %t54 = load i32, ptr %l44, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  store i1 %t57, ptr %l46, !tbaa !21
  %t58 = load i32, ptr %l44, !tbaa !23
  %t59 = ashr i32 %t58, 16
  %t61 = icmp eq i32 %t59, 1
  br i1 %t61, label %bb15, label %bb16
bb15:
  call void @__olang_errpay_pop()
  br label %bb16
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  %t63 = call i32 @compiler_2fbuild_2ePid()
  store i32 %t63, ptr %l49
  br label %bb19
bb19:
  %t64 = load i32, ptr %l49, !tbaa !23
  store i32 %t64, ptr %l7, !tbaa !23
  store i64 0, ptr %l8, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb20, label %bb21
bb20:
  %t75 = load i64, ptr %l10, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb25
bb22:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l10, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l58, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb24
bb24:
  %t95 = load i64, ptr %l58, !tbaa !24
  store i64 %t95, ptr %l55, !tbaa !24
  br label %bb25
bb25:
  %t96 = load i64, ptr %l55, !tbaa !24
  store i64 %t96, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load i64, ptr %l12, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb88
bb28:
  br label %bb29
bb29:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t106 = load i64, ptr %l12, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l13, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t115, ptr %l76, !tbaa !27
  %t116 = load i64, ptr %l13, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %t119, i64 %t116
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !37
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s6, { i64, ptr } %t121, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t123, ptr %l79
  br label %bb30
bb30:
  %t124 = load i1, ptr %l79, !tbaa !21
  br i1 %t124, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb34
bb32:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/load:Loader", ptr %t125, i32 0, i32 10
  %t128 = load i64, ptr %l13, !tbaa !24
  %t131 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t127, i64 %t128)
  store ptr %t131, ptr %l84
  br label %bb33
bb33:
  %t132 = load ptr, ptr %l84, !tbaa !29
  %t134 = getelementptr %"compiler/load:Module", ptr %t132, i32 0, i32 4
  %t135 = load i64, ptr %t134, !tbaa !24
  %t137 = icmp slt i64 %t135, 0
  store i1 %t137, ptr %l80, !tbaa !21
  br label %bb34
bb34:
  %t139 = load i1, ptr %l80, !tbaa !21
  br i1 %t139, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb87
bb36:
  br label %bb37
bb37:
  %t140 = load ptr, ptr %l4, !tbaa !29
  %t142 = getelementptr %"compiler/views:Kept", ptr %t140, i32 0, i32 7
  store ptr %t142, ptr %l90, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/load:Loader", ptr %t143, i32 0, i32 10
  %t146 = load i64, ptr %l13, !tbaa !24
  %t149 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t145, i64 %t146)
  store ptr %t149, ptr %l94
  br label %bb38
bb38:
  %t150 = load ptr, ptr %l94, !tbaa !29
  %t152 = getelementptr %"compiler/load:Module", ptr %t150, i32 0, i32 4
  %t153 = load i64, ptr %t152, !tbaa !24
  %t154 = load ptr, ptr %l90, !tbaa !29
  %t156 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cs_H5a6cbfc85b925203d0895958ef20509b(ptr %v4, ptr %v4, ptr %t154, i64 %t153)
  %t157 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t156, 1
  %t158 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t156, 0
  store i32 %t158, ptr %l98
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb40, label %ok.160, !prof !99
ok.160:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %l97
  br label %bb39
bb39:
  %t162 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v4, ptr %l97)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %l100
  br label %bb42
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb87
bb42:
  %t163 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %l88
  br label %bb43
bb43:
  %t164 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %l14
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v4, ptr %l14)
  store i64 %t166, ptr %l102
  br label %bb44
bb44:
  %t167 = load i64, ptr %l102, !tbaa !24
  %t168 = icmp eq i64 %t167, 0
  br i1 %t168, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s6)
  br label %bb87
bb46:
  br label %bb47
bb47:
  %t170 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s6)
  store %"std/prelude/text:StringBuilder" %t170, ptr %l104
  br label %bb48
bb48:
  %t171 = load %"std/prelude/text:StringBuilder", ptr %l104
  store %"std/prelude/text:StringBuilder" %t171, ptr %l15
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s6, ptr %l15, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb49
bb49:
  %t173 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t173, ptr %l106, !tbaa !27
  %t174 = load i64, ptr %l13, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %t177, i64 %t174
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !37
  %t181 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s6, { i64, ptr } %t179, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t181, ptr %l109
  br label %bb50
bb50:
  %t182 = load i1, ptr %l109, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t185 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t185, ptr %l112, !tbaa !27
  %t186 = load i64, ptr %l13, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr { i64, ptr }, ptr %t189, i64 %t186
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !37
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = extractvalue { i64, ptr } %t191, 0
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t197 = add i64 %t194, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t193, i64 %t194)
  %t199 = getelementptr i8, ptr %t198, i64 %t194
  call void @olang_textcopy(ptr %t199, ptr %t195, i64 %t196)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s10, ptr %l15, { i64, ptr } %t201)
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s10)
  br label %bb54
bb54:
  store ptr %l14, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s13
  %t206 = load i64, ptr %l17, !tbaa !24
  store i64 %t206, ptr %l118, !tbaa !24
  %t207 = load ptr, ptr %l16, !tbaa !29
  %t209 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v4, ptr %t207)
  store i64 %t209, ptr %l120
  br label %bb56
bb56:
  %t210 = load i64, ptr %l118, !tbaa !24
  %t211 = load i64, ptr %l120, !tbaa !24
  %t212 = icmp slt i64 %t210, %t211
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s13)
  br label %bb63
bb58:
  br label %bb59
bb59:
  %t216 = load ptr, ptr %l16, !tbaa !29
  %t217 = load i64, ptr %l17, !tbaa !24
  %t220 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v4, ptr %v4, ptr %t216, i64 %t217)
  store { i64, ptr } %t220, ptr %l125
  br label %bb60
bb60:
  %t221 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t223 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t226 = extractvalue { i64, ptr } %t221, 1
  %t227 = extractvalue { i64, ptr } %t221, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t231 = add i64 %t228, %t230
  %t232 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t231)
  call void @olang_textcopy(ptr %t232, ptr %t223, i64 %t224)
  %t233 = getelementptr i8, ptr %t232, i64 %t224
  call void @olang_textcopy(ptr %t233, ptr %t226, i64 %t227)
  %t234 = getelementptr i8, ptr %t233, i64 %t227
  call void @olang_textcopy(ptr %t234, ptr %t229, i64 %t230)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t232, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s13, ptr %l15, { i64, ptr } %t236)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb62
bb62:
  %t240 = load i64, ptr %l17, !tbaa !24
  %t243 = add i64 %t240, 1
  store i64 %t243, ptr %l17, !tbaa !24
  br label %bb55
bb63:
  store %olang.scope zeroinitializer, ptr %s16
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t247 = load i64, ptr %l13, !tbaa !24
  %t248 = load ptr, ptr %l5, !tbaa !29
  %t253 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2frecords_2eothers(ptr %v0, ptr %v1, ptr %v5, ptr %s16, ptr %t245, ptr %t246, i64 %t247, ptr %t248)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t253, ptr %l137
  br label %bb64
bb64:
  %t254 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l137
  %t255 = call ptr @__olang_scope_alloc_a(ptr %s16, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t254, ptr %t255
  store ptr %t255, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb65
bb65:
  store %olang.scope zeroinitializer, ptr %s17
  %t257 = load i64, ptr %l20, !tbaa !24
  store i64 %t257, ptr %l139, !tbaa !24
  %t258 = load ptr, ptr %l19, !tbaa !29
  %t260 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s16, ptr %t258)
  store i64 %t260, ptr %l141
  br label %bb66
bb66:
  %t261 = load i64, ptr %l139, !tbaa !24
  %t262 = load i64, ptr %l141, !tbaa !24
  %t263 = icmp slt i64 %t261, %t262
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s17)
  br label %bb73
bb68:
  br label %bb69
bb69:
  %t267 = load ptr, ptr %l19, !tbaa !29
  %t268 = load i64, ptr %l20, !tbaa !24
  %t271 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s16, ptr %s16, ptr %t267, i64 %t268)
  store { i64, ptr } %t271, ptr %l146
  br label %bb70
bb70:
  %t272 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t272, 1
  %t276 = extractvalue { i64, ptr } %t272, 0
  %t277 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t279 = add i64 %t276, %t278
  %t280 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t279)
  call void @olang_textcopy(ptr %t280, ptr %t275, i64 %t276)
  %t281 = getelementptr i8, ptr %t280, i64 %t276
  call void @olang_textcopy(ptr %t281, ptr %t277, i64 %t278)
  %t282 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t280, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s17, ptr %l15, { i64, ptr } %t283)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s17)
  br label %bb72
bb72:
  %t287 = load i64, ptr %l20, !tbaa !24
  %t290 = add i64 %t287, 1
  store i64 %t290, ptr %l20, !tbaa !24
  br label %bb65
bb73:
  call void @__olang_scope_close(ptr %s16)
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s6, ptr %l15, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb74
bb74:
  %t294 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s6, ptr %s6, ptr %l15)
  store { i64, ptr } %t294, ptr %l156
  br label %bb75
bb75:
  %t295 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t295, ptr %l22, !tbaa !27
  %t296 = load ptr, ptr %l2, !tbaa !29
  store ptr %t296, ptr %l157, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/load:Loader", ptr %t297, i32 0, i32 10
  %t300 = load i64, ptr %l13, !tbaa !24
  %t303 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t299, i64 %t300)
  store ptr %t303, ptr %l161
  br label %bb76
bb76:
  %t304 = load ptr, ptr %l161, !tbaa !29
  %t306 = getelementptr %"compiler/load:Module", ptr %t304, i32 0, i32 2
  %t307 = load { i64, ptr }, ptr %t306, !tbaa !27
  %t308 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t308, ptr %l164, !tbaa !27
  %t309 = load i64, ptr %l13, !tbaa !24
  %t311 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %t312, i64 %t309
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !37
  %t315 = load ptr, ptr %l157, !tbaa !29
  %t318 = call { i64, ptr } @compiler_2frecords_2efrontStem(ptr %v2, ptr %v0, ptr %v3, ptr %s6, ptr %t315, { i64, ptr } %t307, { i64, ptr } %t314)
  store { i64, ptr } %t318, ptr %l167
  br label %bb77
bb77:
  %t319 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t319, ptr %l168, !tbaa !27
  %t320 = load i64, ptr %l13, !tbaa !24
  %t322 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr { i64, ptr }, ptr %t323, i64 %t320
  %t325 = load { i64, ptr }, ptr %t324, !tbaa !37
  %t327 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %s0, ptr %s6, { i64, ptr } %t325)
  store { i64, ptr } %t327, ptr %l171
  br label %bb78
bb78:
  %t328 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  store i64 %t329, ptr %l172, !tbaa !24
  %t330 = icmp sge i64 0, 0
  br i1 %t330, label %bb79, label %bb80
bb79:
  %t332 = icmp sle i64 0, 16
  br i1 %t332, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @olang_loc_f22b8e51d216f7bc_367675fc034647b8)
  unreachable
bb81:
  %t334 = load i64, ptr %l172, !tbaa !24
  %t335 = icmp sle i64 16, %t334
  br i1 %t335, label %bb83, label %bb84
bb82:
  call void @__olang_check_failed(ptr @olang_loc_f22b8e51d216f7bc_367675fc034647b8)
  unreachable
bb83:
  %t337 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = getelementptr i8, ptr %t338, i64 0
  %t340 = sub i64 16, 0
  %t341 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t339, 1
  %t343 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t347 = extractvalue { i64, ptr } %t342, 1
  %t348 = extractvalue { i64, ptr } %t342, 0
  %t349 = add i64 %t345, %t348
  %t350 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t349)
  call void @olang_textcopy(ptr %t350, ptr %t344, i64 %t345)
  %t351 = getelementptr i8, ptr %t350, i64 %t345
  call void @olang_textcopy(ptr %t351, ptr %t347, i64 %t348)
  %t352 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t350, 1
  store { i64, ptr } %t353, ptr %l178, !tbaa !27
  %t355 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t355, ptr %l179, !tbaa !27
  %t356 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t358 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %s6, ptr %s6, { i64, ptr } %t356)
  store { i64, ptr } %t358, ptr %l181
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_f22b8e51d216f7bc_367675fc034647b8)
  unreachable
bb85:
  %t359 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 1
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t362 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t364 = add i64 %t361, %t363
  %t365 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 1
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t360, i64 %t361)
  %t373 = getelementptr i8, ptr %t372, i64 %t361
  call void @olang_textcopy(ptr %t373, ptr %t362, i64 %t363)
  %t374 = getelementptr i8, ptr %t373, i64 %t363
  call void @olang_textcopy(ptr %t374, ptr %t366, i64 %t367)
  %t375 = getelementptr i8, ptr %t374, i64 %t367
  call void @olang_textcopy(ptr %t375, ptr %t369, i64 %t370)
  %t376 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t377 = insertvalue { i64, ptr } %t376, ptr %t372, 1
  %t379 = load i32, ptr %l7, !tbaa !23
  %t380 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t383 = call i1 @compiler_2frecords_2ePutFile(ptr %s6, ptr %s6, { i64, ptr } %t380, { i64, ptr } %t377, i32 %t379)
  store i1 %t383, ptr %l185
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s6)
  br label %bb87
bb87:
  %t384 = load i64, ptr %l12, !tbaa !24
  %t387 = add i64 %t384, 1
  store i64 %t387, ptr %l12, !tbaa !24
  br label %bb26
bb88:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2frecords_2eKeepScope(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca i64
  %l29 = alloca { i64, ptr }
  %l34 = alloca i32
  %l36 = alloca i1
  %l39 = alloca i32
  %l45 = alloca i64
  %l48 = alloca i64
  %l66 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca i1
  %l74 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l83 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l91 = alloca i1
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l109 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l113 = alloca i32
  %l114 = alloca i1
  %l117 = alloca ptr
  %l121 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l132 = alloca i64
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l145 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRecords(ptr %v3, ptr %s0, ptr %a3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l20
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l5
  %t6 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H0211835ad1df5edc8086b9b7bc878d6e(ptr %s0, ptr %l5)
  store i64 %t6, ptr %l22
  br label %bb2
bb2:
  %t7 = load i64, ptr %l22, !tbaa !24
  %t8 = icmp eq i64 %t7, 0
  br i1 %t8, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l6, !tbaa !29
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t22 = call { i64, ptr } @compiler_2frecords_2eReaderRecords(ptr %v0, ptr %v0, ptr %s0, ptr %t18, ptr %t19)
  store { i64, ptr } %t22, ptr %l29
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/build:Config", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = extractvalue { i64, ptr } %t27, 0
  %t31 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t29, i64 %t30)
  %t35 = getelementptr i8, ptr %t34, i64 %t30
  call void @olang_textcopy(ptr %t35, ptr %t31, i64 %t32)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t34, 1
  %t40 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t37)
  store i32 %t40, ptr %l34
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb8, label %ok.42, !prof !99
ok.42:
  br label %bb7
bb7:
  br label %bb12
bb8:
  %t43 = load i32, ptr %l34, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  store i1 %t46, ptr %l36, !tbaa !21
  %t47 = load i32, ptr %l34, !tbaa !23
  %t48 = ashr i32 %t47, 16
  %t50 = icmp eq i32 %t48, 1
  br i1 %t50, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t52 = call i32 @compiler_2fbuild_2ePid()
  store i32 %t52, ptr %l39
  br label %bb13
bb13:
  %t53 = load i32, ptr %l39, !tbaa !23
  store i32 %t53, ptr %l8, !tbaa !23
  store i64 0, ptr %l9, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = load i64, ptr %l9, !tbaa !24
  %t62 = icmp sgt i64 %t58, %t59
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load i64, ptr %l11, !tbaa !24
  %t66 = icmp sgt i64 %t64, 0
  br i1 %t66, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb19
bb16:
  %t68 = load i64, ptr %l10, !tbaa !24
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = sub i64 %t68, %t69
  %t73 = load i64, ptr %l11, !tbaa !24
  %t76 = add i64 %t72, %t73
  %t78 = sub i64 %t76, 1
  %t79 = load i64, ptr %l11, !tbaa !24
  %t82 = sdiv i64 %t78, %t79
  store i64 %t82, ptr %l48, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb18
bb18:
  %t84 = load i64, ptr %l48, !tbaa !24
  store i64 %t84, ptr %l45, !tbaa !24
  br label %bb19
bb19:
  %t85 = load i64, ptr %l45, !tbaa !24
  store i64 %t85, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t86 = load i64, ptr %l13, !tbaa !24
  %t87 = load i64, ptr %l12, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb22:
  br label %bb23
bb23:
  %t94 = load i64, ptr %l9, !tbaa !24
  %t95 = load i64, ptr %l13, !tbaa !24
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = mul i64 %t95, %t96
  %t102 = add i64 %t94, %t99
  store i64 %t102, ptr %l14, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t104, ptr %l66, !tbaa !27
  %t105 = load i64, ptr %l14, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %t108, i64 %t105
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !37
  %t112 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s5, { i64, ptr } %t110, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t112, ptr %l69
  br label %bb24
bb24:
  %t113 = load i1, ptr %l69, !tbaa !21
  br i1 %t113, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb28
bb26:
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/load:Loader", ptr %t114, i32 0, i32 10
  %t117 = load i64, ptr %l14, !tbaa !24
  %t120 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t116, i64 %t117)
  store ptr %t120, ptr %l74
  br label %bb27
bb27:
  %t121 = load ptr, ptr %l74, !tbaa !29
  %t123 = getelementptr %"compiler/load:Module", ptr %t121, i32 0, i32 4
  %t124 = load i64, ptr %t123, !tbaa !24
  %t126 = icmp slt i64 %t124, 0
  store i1 %t126, ptr %l70, !tbaa !21
  br label %bb28
bb28:
  %t128 = load i1, ptr %l70, !tbaa !21
  br i1 %t128, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb30:
  br label %bb31
bb31:
  store ptr %l5, ptr %l79, !tbaa !29
  %t129 = load ptr, ptr %l6, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 10
  %t132 = load i64, ptr %l14, !tbaa !24
  %t135 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t131, i64 %t132)
  store ptr %t135, ptr %l83
  br label %bb32
bb32:
  %t136 = load ptr, ptr %l83, !tbaa !29
  %t138 = getelementptr %"compiler/load:Module", ptr %t136, i32 0, i32 4
  %t139 = load i64, ptr %t138, !tbaa !24
  %t140 = load ptr, ptr %l79, !tbaa !29
  %t142 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %s0, ptr %s0, ptr %t140, i64 %t139)
  %t143 = extractvalue { i32, { i64, ptr } } %t142, 1
  %t144 = extractvalue { i32, { i64, ptr } } %t142, 0
  store i32 %t144, ptr %l87
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb34, label %ok.146, !prof !99
ok.146:
  store { i64, ptr } %t143, ptr %l86
  br label %bb33
bb33:
  %t147 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t147, ptr %l78, !tbaa !27
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb36:
  %t148 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t148, ptr %l15, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t149, ptr %l88, !tbaa !27
  %t150 = load i64, ptr %l14, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %t153, i64 %t150
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !37
  %t157 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s5, { i64, ptr } %t155, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t157, ptr %l91
  br label %bb37
bb37:
  %t158 = load i1, ptr %l91, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb38, label %bb39
bb38:
  %t161 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t161, ptr %l94, !tbaa !27
  %t162 = load i64, ptr %l14, !tbaa !24
  %t164 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %t165, i64 %t162
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !37
  %t169 = extractvalue { i64, ptr } %t167, 1
  %t170 = extractvalue { i64, ptr } %t167, 0
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t169, i64 %t170)
  %t175 = getelementptr i8, ptr %t174, i64 %t170
  call void @olang_textcopy(ptr %t175, ptr %t171, i64 %t172)
  %t176 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t174, 1
  store { i64, ptr } %t177, ptr %l93, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l93, !tbaa !27
  br label %bb40
bb40:
  %t180 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t182 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = add i64 %t181, %t184
  %t186 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t180, i64 %t181)
  %t187 = getelementptr i8, ptr %t186, i64 %t181
  call void @olang_textcopy(ptr %t187, ptr %t183, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t186, 1
  %t192 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t189, 1
  %t195 = extractvalue { i64, ptr } %t189, 0
  %t197 = extractvalue { i64, ptr } %t192, 1
  %t198 = extractvalue { i64, ptr } %t192, 0
  %t199 = add i64 %t195, %t198
  %t200 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t199)
  call void @olang_textcopy(ptr %t200, ptr %t194, i64 %t195)
  %t201 = getelementptr i8, ptr %t200, i64 %t195
  call void @olang_textcopy(ptr %t201, ptr %t197, i64 %t198)
  %t202 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t200, 1
  store { i64, ptr } %t203, ptr %l17, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t205, ptr %l103, !tbaa !27
  store ptr %a4, ptr %l105, !tbaa !29
  %t207 = load ptr, ptr %l6, !tbaa !29
  %t209 = getelementptr %"compiler/load:Loader", ptr %t207, i32 0, i32 10
  %t210 = load i64, ptr %l14, !tbaa !24
  %t213 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t209, i64 %t210)
  store ptr %t213, ptr %l109
  br label %bb41
bb41:
  %t214 = load ptr, ptr %l109, !tbaa !29
  %t216 = getelementptr %"compiler/load:Module", ptr %t214, i32 0, i32 4
  %t217 = load i64, ptr %t216, !tbaa !24
  %t218 = load ptr, ptr %l105, !tbaa !29
  %t220 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v4, ptr %v4, ptr %t218, i64 %t217)
  %t221 = extractvalue { i32, { i64, ptr } } %t220, 1
  %t222 = extractvalue { i32, { i64, ptr } } %t220, 0
  store i32 %t222, ptr %l113
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb43, label %ok.224, !prof !99
ok.224:
  store { i64, ptr } %t221, ptr %l112
  br label %bb42
bb42:
  %t225 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t225, ptr %l104, !tbaa !27
  br label %bb45
bb43:
  br label %bb44
bb44:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l104, !tbaa !27
  br label %bb45
bb45:
  %t226 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t228 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %v4, { i64, ptr } %t226, { i64, ptr } %t227)
  store i1 %t228, ptr %l114
  br label %bb46
bb46:
  %t229 = load i1, ptr %l114, !tbaa !21
  br i1 %t229, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb48:
  br label %bb49
bb49:
  %t230 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = extractvalue { i64, ptr } %t230, 0
  %t234 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t235 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t236 = add i64 %t233, %t235
  %t237 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t236)
  call void @olang_textcopy(ptr %t237, ptr %t232, i64 %t233)
  %t238 = getelementptr i8, ptr %t237, i64 %t233
  call void @olang_textcopy(ptr %t238, ptr %t234, i64 %t235)
  %t239 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t237, 1
  store { i64, ptr } %t240, ptr %l18, !tbaa !27
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l117, !tbaa !29
  %t243 = load ptr, ptr %l6, !tbaa !29
  %t245 = getelementptr %"compiler/load:Loader", ptr %t243, i32 0, i32 10
  %t246 = load i64, ptr %l14, !tbaa !24
  %t249 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t245, i64 %t246)
  store ptr %t249, ptr %l121
  br label %bb50
bb50:
  %t250 = load ptr, ptr %l121, !tbaa !29
  %t252 = getelementptr %"compiler/load:Module", ptr %t250, i32 0, i32 2
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t254, ptr %l124, !tbaa !27
  %t255 = load i64, ptr %l14, !tbaa !24
  %t257 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !27
  %t259 = getelementptr { i64, ptr }, ptr %t258, i64 %t255
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !37
  %t261 = load ptr, ptr %l117, !tbaa !29
  %t264 = call { i64, ptr } @compiler_2frecords_2escopeStem(ptr %v1, ptr %v0, ptr %v2, ptr %s5, ptr %t261, { i64, ptr } %t253, { i64, ptr } %t260)
  store { i64, ptr } %t264, ptr %l127
  br label %bb51
bb51:
  %t265 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t265, ptr %l128, !tbaa !27
  %t266 = load i64, ptr %l14, !tbaa !24
  %t268 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr { i64, ptr }, ptr %t269, i64 %t266
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !37
  %t273 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %s0, ptr %s5, { i64, ptr } %t271)
  store { i64, ptr } %t273, ptr %l131
  br label %bb52
bb52:
  %t274 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  store i64 %t275, ptr %l132, !tbaa !24
  %t276 = icmp sge i64 0, 0
  br i1 %t276, label %bb53, label %bb54
bb53:
  %t278 = icmp sle i64 0, 16
  br i1 %t278, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_54f44bc773787685_bd98309550db61e1)
  unreachable
bb55:
  %t280 = load i64, ptr %l132, !tbaa !24
  %t281 = icmp sle i64 16, %t280
  br i1 %t281, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_54f44bc773787685_bd98309550db61e1)
  unreachable
bb57:
  %t283 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i8, ptr %t284, i64 0
  %t286 = sub i64 16, 0
  %t287 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t285, 1
  %t289 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t293 = extractvalue { i64, ptr } %t288, 1
  %t294 = extractvalue { i64, ptr } %t288, 0
  %t295 = add i64 %t291, %t294
  %t296 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t295)
  call void @olang_textcopy(ptr %t296, ptr %t290, i64 %t291)
  %t297 = getelementptr i8, ptr %t296, i64 %t291
  call void @olang_textcopy(ptr %t297, ptr %t293, i64 %t294)
  %t298 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t296, 1
  store { i64, ptr } %t299, ptr %l138, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t301, ptr %l139, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t304 = call { i64, ptr } @compiler_2frecords_2esumOf(ptr %s5, ptr %s5, { i64, ptr } %t302)
  store { i64, ptr } %t304, ptr %l141
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_54f44bc773787685_bd98309550db61e1)
  unreachable
bb59:
  %t305 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t305, 1
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t308 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t310 = add i64 %t307, %t309
  %t311 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 1
  %t313 = extractvalue { i64, ptr } %t311, 0
  %t314 = add i64 %t310, %t313
  %t315 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t317 = add i64 %t314, %t316
  %t318 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t317)
  call void @olang_textcopy(ptr %t318, ptr %t306, i64 %t307)
  %t319 = getelementptr i8, ptr %t318, i64 %t307
  call void @olang_textcopy(ptr %t319, ptr %t308, i64 %t309)
  %t320 = getelementptr i8, ptr %t319, i64 %t309
  call void @olang_textcopy(ptr %t320, ptr %t312, i64 %t313)
  %t321 = getelementptr i8, ptr %t320, i64 %t313
  call void @olang_textcopy(ptr %t321, ptr %t315, i64 %t316)
  %t322 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t318, 1
  %t325 = load i32, ptr %l8, !tbaa !23
  %t326 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t329 = call i1 @compiler_2frecords_2ePutFile(ptr %s5, ptr %s5, { i64, ptr } %t326, { i64, ptr } %t323, i32 %t325)
  store i1 %t329, ptr %l145
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb61:
  %t330 = load i64, ptr %l13, !tbaa !24
  %t333 = add i64 %t330, 1
  store i64 %t333, ptr %l13, !tbaa !24
  br label %bb20
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2frecords_2eModuleKeys(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l42 = alloca i1
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l65 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l96 = alloca ptr
  %l97 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l107 = alloca ptr
  %l108 = alloca i64
  %l114 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l129 = alloca i64
  %l131 = alloca i64
  %l136 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l138 = alloca i64
  %l140 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l145 = alloca i64
  %l146 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l155 = alloca i64
  %l156 = alloca i64
  %l159 = alloca { i64, ptr }
  %l168 = alloca i64
  %l171 = alloca i64
  %l193 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l201 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l203 = alloca i64
  %l205 = alloca i64
  %l210 = alloca i64
  %l211 = alloca ptr
  %l212 = alloca i64
  %l217 = alloca ptr
  %l227 = alloca { i64, ptr }
  %l228 = alloca i64
  %l229 = alloca i64
  %l232 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t19 = alloca i64
  %t117 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l33
  br label %bb1
bb1:
  %t8 = load i64, ptr %l33, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l34, !tbaa !24
  %t10 = load i64, ptr %l34, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l34, !tbaa !24
  %t14 = icmp sle i64 %t13, 576460752303423487
  br i1 %t14, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_8d034036672d852_5fe6d572cc7f08a6)
  unreachable
bb4:
  %t16 = load i64, ptr %l34, !tbaa !24
  %t17 = mul i64 %t16, 16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  store i64 0, ptr %t19
  br label %fill.20
fill.20:
  %t23 = load i64, ptr %t19
  %t24 = icmp slt i64 %t23, %t16
  br i1 %t24, label %fillb.21, label %filld.22
fillb.21:
  %t25 = getelementptr { i64, ptr }, ptr %t18, i64 %t23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %t25
  %t26 = add i64 %t23, 1
  store i64 %t26, ptr %t19
  br label %fill.20
filld.22:
  %t27 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t18, 1
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t34 = call { i64, ptr } @compiler_2frecords_2eBuildInputs(ptr %v1, ptr %s0, ptr %t30, i1 %a2)
  store { i64, ptr } %t34, ptr %l40
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8d034036672d852_5fe6d572cc7f08a6)
  unreachable
bb6:
  %t35 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t35, ptr %l6, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t36, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t38, ptr %l42
  br label %bb7
bb7:
  %t39 = load i1, ptr %l42, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t42, ptr %l44, !tbaa !27
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/build:Config", ptr %t43, i32 0, i32 4
  %t46 = load i1, ptr %t45, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 12
  %t53 = load i64, ptr %t52, !tbaa !24
  %t56 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t48, i64 %t53)
  store ptr %t56, ptr %l52
  br label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l47, !tbaa !27
  br label %bb15
bb13:
  %t57 = load ptr, ptr %l52, !tbaa !29
  %t59 = getelementptr %"compiler/load:Module", ptr %t57, i32 0, i32 2
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l54, !tbaa !27
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/load:Loader", ptr %t63, i32 0, i32 12
  %t66 = load i64, ptr %t65, !tbaa !24
  %t69 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t61, i64 %t66)
  store ptr %t69, ptr %l59
  br label %bb14
bb14:
  %t70 = load ptr, ptr %l59, !tbaa !29
  %t72 = getelementptr %"compiler/load:Module", ptr %t70, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t74 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t76 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t84 = extractvalue { i64, ptr } %t73, 1
  %t85 = extractvalue { i64, ptr } %t73, 0
  %t86 = add i64 %t82, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t74, i64 %t75)
  %t88 = getelementptr i8, ptr %t87, i64 %t75
  call void @olang_textcopy(ptr %t88, ptr %t77, i64 %t78)
  %t89 = getelementptr i8, ptr %t88, i64 %t78
  call void @olang_textcopy(ptr %t89, ptr %t80, i64 %t81)
  %t90 = getelementptr i8, ptr %t89, i64 %t81
  call void @olang_textcopy(ptr %t90, ptr %t84, i64 %t85)
  %t91 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t87, 1
  store { i64, ptr } %t92, ptr %l47, !tbaa !27
  br label %bb15
bb15:
  %t95 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t101 = add i64 %t97, %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t96, i64 %t97)
  %t103 = getelementptr i8, ptr %t102, i64 %t97
  call void @olang_textcopy(ptr %t103, ptr %t99, i64 %t100)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  store { i64, ptr } %t105, ptr %l7, !tbaa !27
  %t107 = load i64, ptr %l4, !tbaa !24
  store i64 %t107, ptr %l65, !tbaa !24
  %t108 = load i64, ptr %l65, !tbaa !24
  %t109 = icmp sge i64 %t108, 0
  br i1 %t109, label %bb16, label %bb17
bb16:
  %t111 = load i64, ptr %l65, !tbaa !24
  %t112 = icmp sle i64 %t111, 576460752303423487
  br i1 %t112, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_55114c4c1f153b47_5d38716d9a9c2c3b)
  unreachable
bb18:
  %t114 = load i64, ptr %l65, !tbaa !24
  %t115 = mul i64 %t114, 16
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  store i64 0, ptr %t117
  br label %fill.118
fill.118:
  %t121 = load i64, ptr %t117
  %t122 = icmp slt i64 %t121, %t114
  br i1 %t122, label %fillb.119, label %filld.120
fillb.119:
  %t123 = getelementptr { i64, ptr }, ptr %t116, i64 %t121
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %t123
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %t117
  br label %fill.118
filld.120:
  %t125 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t116, 1
  store { i64, ptr } %t126, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t128 = load i64, ptr %l4, !tbaa !24
  store i64 %t128, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t130 = load i64, ptr %l10, !tbaa !24
  %t131 = load i64, ptr %l9, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  br i1 %t134, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_55114c4c1f153b47_5d38716d9a9c2c3b)
  unreachable
bb20:
  %t136 = load i64, ptr %l11, !tbaa !24
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb25
bb22:
  %t140 = load i64, ptr %l10, !tbaa !24
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = sub i64 %t140, %t141
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = add i64 %t144, %t145
  %t150 = sub i64 %t148, 1
  %t151 = load i64, ptr %l11, !tbaa !24
  %t154 = sdiv i64 %t150, %t151
  store i64 %t154, ptr %l76, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb24
bb24:
  %t156 = load i64, ptr %l76, !tbaa !24
  store i64 %t156, ptr %l73, !tbaa !24
  br label %bb25
bb25:
  %t157 = load i64, ptr %l73, !tbaa !24
  store i64 %t157, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t158 = load i64, ptr %l13, !tbaa !24
  %t159 = load i64, ptr %l12, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb28:
  br label %bb29
bb29:
  %t166 = load i64, ptr %l9, !tbaa !24
  %t167 = load i64, ptr %l13, !tbaa !24
  %t168 = load i64, ptr %l11, !tbaa !24
  %t171 = mul i64 %t167, %t168
  %t174 = add i64 %t166, %t171
  store i64 %t174, ptr %l14, !tbaa !24
  %t176 = load ptr, ptr %l3, !tbaa !29
  %t177 = load i64, ptr %l14, !tbaa !24
  %t180 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t176, i64 %t177)
  store ptr %t180, ptr %l96
  br label %bb30
bb30:
  %t181 = load ptr, ptr %l96, !tbaa !29
  store ptr %t181, ptr %l15, !tbaa !29
  %t182 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t182, ptr %l97
  br label %bb31
bb31:
  %t183 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l97
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t183, ptr %l16
  %t184 = load ptr, ptr %l15, !tbaa !29
  %t186 = getelementptr %"compiler/load:Module", ptr %t184, i32 0, i32 2
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t187)
  br label %bb32
bb32:
  %t190 = load ptr, ptr %l15, !tbaa !29
  %t192 = getelementptr %"compiler/load:Module", ptr %t190, i32 0, i32 0
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t193)
  br label %bb33
bb33:
  %t196 = load ptr, ptr %l15, !tbaa !29
  %t198 = getelementptr %"compiler/load:Module", ptr %t196, i32 0, i32 1
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t199)
  br label %bb34
bb34:
  store ptr %l16, ptr %l107, !tbaa !29
  %t202 = call ptr @__olang_scope_hold(ptr %s5)
  %t203 = ptrtoint ptr %t202 to i64
  store i64 %t203, ptr %l108, !tbaa !24
  %t204 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t204, label %bb35, label %bb36
bb35:
  %t206 = call ptr @__olang_region_make(ptr %s5)
  %t207 = ptrtoint ptr %t206 to i64
  store i64 %t207, ptr %l108, !tbaa !24
  br label %bb36
bb36:
  %t208 = load ptr, ptr %l15, !tbaa !29
  %t210 = getelementptr %"compiler/load:Module", ptr %t208, i32 0, i32 6
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = icmp eq ptr %t211, null
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb37, label %bb38
bb37:
  %t217 = load ptr, ptr %l15, !tbaa !29
  %t219 = getelementptr %"compiler/load:Module", ptr %t217, i32 0, i32 6
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = icmp eq ptr %t220, null
  br i1 %t222, label %bb39, label %bb40
bb38:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l124, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t226 = load i64, ptr %l108
  %t227 = inttoptr i64 %t226 to ptr
  %t228 = extractvalue { i64, ptr } %t224, 0
  %t229 = extractvalue { i64, ptr } %t224, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_held_alloc(ptr %t227, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  store { i64, ptr } %t233, ptr %l114, !tbaa !27
  br label %bb42
bb39:
  call void @__olang_check_failed(ptr @olang_loc_9658ab26a60a31a4_8c8d053bf8a13660)
  unreachable
bb40:
  br label %bb41
bb41:
  %t235 = load ptr, ptr %l15, !tbaa !29
  %t237 = getelementptr %"compiler/load:Module", ptr %t235, i32 0, i32 6
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t241 = getelementptr %"compiler/source:Source", ptr %t238, i32 0, i32 1
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  %t245 = load i64, ptr %l108
  %t246 = inttoptr i64 %t245 to ptr
  %t247 = extractvalue { i64, ptr } %t242, 0
  %t248 = extractvalue { i64, ptr } %t242, 1
  %t249 = mul i64 %t247, 1
  %t250 = call ptr @__olang_held_alloc(ptr %t246, i64 %t249)
  call void @llvm.memcpy.p0.p0.i64(ptr %t250, ptr %t248, i64 %t249, i1 false)
  %t251 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  store { i64, ptr } %t252, ptr %l114, !tbaa !27
  br label %bb42
bb42:
  %t254 = load ptr, ptr %l107, !tbaa !29
  %t255 = load { i64, ptr }, ptr %l114, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s5, ptr %s5, ptr %t254, { i64, ptr } %t255)
  br label %bb43
bb43:
  %t256 = load ptr, ptr %l15, !tbaa !29
  %t258 = getelementptr %"compiler/load:Module", ptr %t256, i32 0, i32 32
  store ptr %t258, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t260 = load i64, ptr %l18, !tbaa !24
  store i64 %t260, ptr %l129, !tbaa !24
  %t261 = load ptr, ptr %l17, !tbaa !29
  %t263 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t261)
  store i64 %t263, ptr %l131
  br label %bb45
bb45:
  %t264 = load i64, ptr %l129, !tbaa !24
  %t265 = load i64, ptr %l131, !tbaa !24
  %t266 = icmp slt i64 %t264, %t265
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb56
bb47:
  br label %bb48
bb48:
  %t270 = load ptr, ptr %l17, !tbaa !29
  %t271 = load i64, ptr %l18, !tbaa !24
  %t274 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t270, i64 %t271)
  store { i64, ptr } %t274, ptr %l136
  br label %bb49
bb49:
  %t275 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t275, ptr %l19, !tbaa !27
  store ptr %l16, ptr %l137, !tbaa !29
  %t276 = call ptr @__olang_scope_hold(ptr %s5)
  %t277 = ptrtoint ptr %t276 to i64
  store i64 %t277, ptr %l138, !tbaa !24
  %t278 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t278, label %bb50, label %bb51
bb50:
  %t280 = call ptr @__olang_region_make(ptr %s5)
  %t281 = ptrtoint ptr %t280 to i64
  store i64 %t281, ptr %l138, !tbaa !24
  br label %bb51
bb51:
  %t282 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t282, ptr %l140, !tbaa !27
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t287 = call { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2eEmbedded(ptr %v0, ptr %v0, ptr %s7, ptr %t283, { i64, ptr } %t284)
  store { i64, ptr } %t287, ptr %l143
  br label %bb52
bb52:
  %t288 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t288, ptr %l144, !tbaa !27
  %t289 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 0
  store i64 %t290, ptr %l145, !tbaa !24
  %t291 = load i64, ptr %l145, !tbaa !24
  %t292 = mul i64 %t291, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t292)
  %t294 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  store { i64, ptr } %t295, ptr %l146, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = load i64, ptr %l145, !tbaa !24
  %t301 = mul i64 %t300, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t297, ptr %t299, i64 %t301, i1 false)
  %t302 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t305 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %s7, ptr %s7, { i64, ptr } %t302)
  store { i64, ptr } %t305, ptr %l149
  br label %bb53
bb53:
  %t306 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t308 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t314 = add i64 %t311, %t313
  %t315 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = add i64 %t314, %t317
  %t319 = load i64, ptr %l138
  %t320 = inttoptr i64 %t319 to ptr
  %t321 = call ptr @__olang_held_alloc(ptr %t320, i64 %t318)
  call void @olang_textcopy(ptr %t321, ptr %t306, i64 %t307)
  %t322 = getelementptr i8, ptr %t321, i64 %t307
  call void @olang_textcopy(ptr %t322, ptr %t309, i64 %t310)
  %t323 = getelementptr i8, ptr %t322, i64 %t310
  call void @olang_textcopy(ptr %t323, ptr %t312, i64 %t313)
  %t324 = getelementptr i8, ptr %t323, i64 %t313
  call void @olang_textcopy(ptr %t324, ptr %t316, i64 %t317)
  %t325 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t321, 1
  %t328 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s5, ptr %s5, ptr %t328, { i64, ptr } %t326)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb55:
  %t330 = load i64, ptr %l18, !tbaa !24
  %t333 = add i64 %t330, 1
  store i64 %t333, ptr %l18, !tbaa !24
  br label %bb44
bb56:
  %t335 = load i64, ptr %l14, !tbaa !24
  store i64 %t335, ptr %l155, !tbaa !24
  %t336 = call ptr @__olang_scope_hold(ptr %s0)
  %t337 = ptrtoint ptr %t336 to i64
  store i64 %t337, ptr %l156, !tbaa !24
  %t338 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t338, label %bb57, label %bb58
bb57:
  %t340 = call ptr @__olang_region_make(ptr %s0)
  %t341 = ptrtoint ptr %t340 to i64
  store i64 %t341, ptr %l156, !tbaa !24
  br label %bb58
bb58:
  %t342 = load i64, ptr %l156
  %t343 = inttoptr i64 %t342 to ptr
  %t345 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s5, ptr %t343, ptr %l16)
  store { i64, ptr } %t345, ptr %l159
  br label %bb59
bb59:
  %t346 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t348 = load i64, ptr %l155, !tbaa !24
  %t349 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr { i64, ptr }, ptr %t350, i64 %t348
  store { i64, ptr } %t346, ptr %t351, !tbaa !37
  call void @__olang_scope_close(ptr %s5)
  br label %bb60
bb60:
  %t352 = load i64, ptr %l13, !tbaa !24
  %t355 = add i64 %t352, 1
  store i64 %t355, ptr %l13, !tbaa !24
  br label %bb26
bb61:
  store i64 0, ptr %l20, !tbaa !24
  %t357 = load i64, ptr %l4, !tbaa !24
  store i64 %t357, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t359 = load i64, ptr %l21, !tbaa !24
  %t360 = load i64, ptr %l20, !tbaa !24
  %t363 = icmp sgt i64 %t359, %t360
  br i1 %t363, label %bb62, label %bb63
bb62:
  %t365 = load i64, ptr %l22, !tbaa !24
  %t367 = icmp sgt i64 %t365, 0
  br i1 %t367, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb67
bb64:
  %t369 = load i64, ptr %l21, !tbaa !24
  %t370 = load i64, ptr %l20, !tbaa !24
  %t373 = sub i64 %t369, %t370
  %t374 = load i64, ptr %l22, !tbaa !24
  %t377 = add i64 %t373, %t374
  %t379 = sub i64 %t377, 1
  %t380 = load i64, ptr %l22, !tbaa !24
  %t383 = sdiv i64 %t379, %t380
  store i64 %t383, ptr %l171, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l171, !tbaa !24
  br label %bb66
bb66:
  %t385 = load i64, ptr %l171, !tbaa !24
  store i64 %t385, ptr %l168, !tbaa !24
  br label %bb67
bb67:
  %t386 = load i64, ptr %l168, !tbaa !24
  store i64 %t386, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s12
  %t387 = load i64, ptr %l24, !tbaa !24
  %t388 = load i64, ptr %l23, !tbaa !24
  %t391 = icmp slt i64 %t387, %t388
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s12)
  br label %bb95
bb70:
  br label %bb71
bb71:
  %t395 = load i64, ptr %l20, !tbaa !24
  %t396 = load i64, ptr %l24, !tbaa !24
  %t397 = load i64, ptr %l22, !tbaa !24
  %t400 = mul i64 %t396, %t397
  %t403 = add i64 %t395, %t400
  store i64 %t403, ptr %l25, !tbaa !24
  %t405 = load i64, ptr %l25, !tbaa !24
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/load:Loader", ptr %t406, i32 0, i32 12
  %t409 = load i64, ptr %t408, !tbaa !24
  %t412 = icmp eq i64 %t405, %t409
  br i1 %t412, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s12)
  br label %bb94
bb73:
  br label %bb74
bb74:
  %t414 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s12, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t414, ptr %l193
  br label %bb75
bb75:
  %t415 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l193
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t415, ptr %l26
  %t416 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s12, ptr %s0, ptr %l26, { i64, ptr } %t416)
  br label %bb76
bb76:
  %t419 = load i64, ptr %l25, !tbaa !24
  %t421 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr { i64, ptr }, ptr %t422, i64 %t419
  %t424 = load { i64, ptr }, ptr %t423, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s12, ptr %s0, ptr %l26, { i64, ptr } %t424)
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s14
  %t427 = load ptr, ptr %l3, !tbaa !29
  %t428 = load i64, ptr %l25, !tbaa !24
  %t431 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2frecords_2eReached(ptr %v0, ptr %s14, ptr %t427, i64 %t428)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t431, ptr %l201
  br label %bb78
bb78:
  %t432 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l201
  %t433 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t432, ptr %t433
  store ptr %t433, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb79
bb79:
  %t435 = load i64, ptr %l28, !tbaa !24
  store i64 %t435, ptr %l203, !tbaa !24
  %t436 = load ptr, ptr %l27, !tbaa !29
  %t438 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s14, ptr %t436)
  store i64 %t438, ptr %l205
  br label %bb80
bb80:
  %t439 = load i64, ptr %l203, !tbaa !24
  %t440 = load i64, ptr %l205, !tbaa !24
  %t441 = icmp slt i64 %t439, %t440
  %t443 = xor i1 %t441, true
  br i1 %t443, label %bb81, label %bb82
bb81:
  br label %bb90
bb82:
  br label %bb83
bb83:
  %t445 = load ptr, ptr %l27, !tbaa !29
  %t446 = load i64, ptr %l28, !tbaa !24
  %t449 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s14, ptr %t445, i64 %t446)
  store i64 %t449, ptr %l210
  br label %bb84
bb84:
  %t450 = load i64, ptr %l210, !tbaa !24
  store i64 %t450, ptr %l29, !tbaa !24
  store ptr %l26, ptr %l211, !tbaa !29
  %t451 = call ptr @__olang_scope_hold(ptr %s12)
  %t452 = ptrtoint ptr %t451 to i64
  store i64 %t452, ptr %l212, !tbaa !24
  %t453 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t453, label %bb85, label %bb86
bb85:
  %t455 = call ptr @__olang_region_make(ptr %s12)
  %t456 = ptrtoint ptr %t455 to i64
  store i64 %t456, ptr %l212, !tbaa !24
  br label %bb86
bb86:
  %t457 = load ptr, ptr %l3, !tbaa !29
  %t459 = load i64, ptr %l29, !tbaa !24
  %t462 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t457, i64 %t459)
  store ptr %t462, ptr %l217
  br label %bb87
bb87:
  %t463 = load ptr, ptr %l217, !tbaa !29
  %t465 = getelementptr %"compiler/load:Module", ptr %t463, i32 0, i32 2
  %t466 = load { i64, ptr }, ptr %t465, !tbaa !27
  %t467 = load i64, ptr %l29, !tbaa !24
  %t469 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !27
  %t471 = getelementptr { i64, ptr }, ptr %t470, i64 %t467
  %t472 = load { i64, ptr }, ptr %t471, !tbaa !37
  %t474 = extractvalue { i64, ptr } %t466, 1
  %t475 = extractvalue { i64, ptr } %t466, 0
  %t476 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t477 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t478 = add i64 %t475, %t477
  %t480 = extractvalue { i64, ptr } %t472, 1
  %t481 = extractvalue { i64, ptr } %t472, 0
  %t482 = add i64 %t478, %t481
  %t483 = load i64, ptr %l212
  %t484 = inttoptr i64 %t483 to ptr
  %t485 = call ptr @__olang_held_alloc(ptr %t484, i64 %t482)
  call void @olang_textcopy(ptr %t485, ptr %t474, i64 %t475)
  %t486 = getelementptr i8, ptr %t485, i64 %t475
  call void @olang_textcopy(ptr %t486, ptr %t476, i64 %t477)
  %t487 = getelementptr i8, ptr %t486, i64 %t477
  call void @olang_textcopy(ptr %t487, ptr %t480, i64 %t481)
  %t488 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t489 = insertvalue { i64, ptr } %t488, ptr %t485, 1
  %t491 = load ptr, ptr %l211, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s12, ptr %s12, ptr %t491, { i64, ptr } %t489)
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t493 = load i64, ptr %l28, !tbaa !24
  %t496 = add i64 %t493, 1
  store i64 %t496, ptr %l28, !tbaa !24
  br label %bb79
bb90:
  call void @__olang_scope_close(ptr %s14)
  %t498 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t498, ptr %l227, !tbaa !27
  %t499 = load i64, ptr %l25, !tbaa !24
  store i64 %t499, ptr %l228, !tbaa !24
  %t500 = call ptr @__olang_scope_hold(ptr %v2)
  %t501 = ptrtoint ptr %t500 to i64
  store i64 %t501, ptr %l229, !tbaa !24
  %t502 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t502, label %bb91, label %bb92
bb91:
  %t504 = call ptr @__olang_region_make(ptr %v2)
  %t505 = ptrtoint ptr %t504 to i64
  store i64 %t505, ptr %l229, !tbaa !24
  br label %bb92
bb92:
  %t506 = load i64, ptr %l229
  %t507 = inttoptr i64 %t506 to ptr
  %t509 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s12, ptr %t507, ptr %l26)
  store { i64, ptr } %t509, ptr %l232
  br label %bb93
bb93:
  %t510 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t512 = load i64, ptr %l228, !tbaa !24
  %t513 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t514 = load ptr, ptr %t513, !tbaa !27
  %t515 = getelementptr { i64, ptr }, ptr %t514, i64 %t512
  store { i64, ptr } %t510, ptr %t515, !tbaa !37
  call void @__olang_scope_close(ptr %s12)
  br label %bb94
bb94:
  %t516 = load i64, ptr %l24, !tbaa !24
  %t519 = add i64 %t516, 1
  store i64 %t519, ptr %l24, !tbaa !24
  br label %bb68
bb95:
  %t521 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t521, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2frecords_2ePutFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l18 = alloca i32
  %l20 = alloca i1
  %l24 = alloca i32
  %l26 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t1, 1
  %t5 = extractvalue { i64, ptr } %t1, 0
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = sext i32 %a2 to i64
  %t11 = call i64 @__olang_fmt_i64(ptr null, i64 %t10)
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t10)
  %t20 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t20, ptr %t13, i64 %t14)
  %t21 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t16, 1
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v1, { i64, ptr } %t24, { i64, ptr } %a1)
  store i32 %t29, ptr %l10
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb2, label %ok.31, !prof !99
ok.31:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t32 = load i32, ptr %l10, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  store i1 %t35, ptr %l12, !tbaa !21
  %t36 = load i32, ptr %l10, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  br i1 %t39, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v0, { i64, ptr } %t42, { i64, ptr } %t43)
  store i32 %t46, ptr %l18
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb8, label %ok.48, !prof !99
ok.48:
  br label %bb7
bb7:
  br label %bb18
bb8:
  %t49 = load i32, ptr %l18, !tbaa !23
  %t50 = ashr i32 %t49, 16
  %t52 = icmp eq i32 %t50, 1
  store i1 %t52, ptr %l20, !tbaa !21
  %t53 = load i32, ptr %l18, !tbaa !23
  %t54 = ashr i32 %t53, 16
  %t56 = icmp eq i32 %t54, 1
  br i1 %t56, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t58)
  store i32 %t60, ptr %l24
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb13, label %ok.62, !prof !99
ok.62:
  br label %bb12
bb12:
  br label %bb17
bb13:
  %t63 = load i32, ptr %l24, !tbaa !23
  %t64 = ashr i32 %t63, 16
  %t66 = icmp eq i32 %t64, 1
  store i1 %t66, ptr %l26, !tbaa !21
  %t67 = load i32, ptr %l24, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  br i1 %t70, label %bb14, label %bb15
bb14:
  call void @__olang_errpay_pop()
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2frecords_2eReached(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/load:Import"
  %l17 = alloca i64
  %l18 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca i64
  %l82 = alloca i64
  %l87 = alloca %"compiler/load:Import"
  %l90 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load i64, ptr %l17, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l18, !tbaa !24
  %t6 = load i64, ptr %l18, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l18, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l3, !tbaa !27
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l21
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_7fdbfc0a8c76ca86_bcbf652a9859a812)
  unreachable
bb4:
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t16, ptr %lp4
  %t17 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t18 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %t18
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l22
  br label %bb5
bb5:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %a1)
  br label %bb6
bb6:
  store i64 0, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  store i64 %t24, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb12
bb9:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l32, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb11
bb11:
  %t52 = load i64, ptr %l32, !tbaa !24
  store i64 %t52, ptr %l29, !tbaa !24
  br label %bb12
bb12:
  %t53 = load i64, ptr %l29, !tbaa !24
  store i64 %t53, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t54 = load i64, ptr %l10, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb14, label %bb15
bb14:
  br label %bb23
bb15:
  br label %bb16
bb16:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l11, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t72, i64 %t74)
  store ptr %t77, ptr %l53
  br label %bb17
bb17:
  %t78 = load ptr, ptr %l53, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 3
  %t81 = load i1, ptr %t80, !tbaa !21
  br i1 %t81, label %bb18, label %bb19
bb18:
  %t83 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t83)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t86 = load i64, ptr %l10, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l10, !tbaa !24
  br label %bb13
bb23:
  br label %bb24
bb24:
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t92, ptr %l62
  br label %bb25
bb25:
  %t93 = load i64, ptr %l62, !tbaa !24
  %t94 = icmp sgt i64 %t93, 0
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb26, label %bb27
bb26:
  br label %bb54
bb27:
  br label %bb28
bb28:
  %t99 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %l5)
  %t100 = extractvalue { i32, i64 } %t99, 1
  %t101 = extractvalue { i32, i64 } %t99, 0
  store i32 %t101, ptr %l68
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb30, label %ok.103, !prof !99
ok.103:
  store i64 %t100, ptr %l67
  br label %bb29
bb29:
  %t104 = load i64, ptr %l67, !tbaa !24
  store i64 %t104, ptr %l65, !tbaa !24
  br label %bb32
bb30:
  br label %bb31
bb31:
  br label %bb54
bb32:
  %t105 = load i64, ptr %l65, !tbaa !24
  store i64 %t105, ptr %l12, !tbaa !24
  %t106 = load i64, ptr %l12, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i1, ptr %t109, i64 %t106
  %t111 = load i1, ptr %t110, !tbaa !31
  br i1 %t111, label %bb33, label %bb34
bb33:
  br label %bb53
bb34:
  br label %bb35
bb35:
  %t113 = load i64, ptr %l12, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i1, ptr %t116, i64 %t113
  store i1 true, ptr %t117, !tbaa !31
  %t118 = load ptr, ptr %lp4
  %t119 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t118, i64 %t119)
  br label %bb36
bb36:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i64, ptr %l12, !tbaa !24
  %t127 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t122, i64 %t124)
  store ptr %t127, ptr %l77
  br label %bb37
bb37:
  %t128 = load ptr, ptr %l77, !tbaa !29
  %t130 = getelementptr %"compiler/load:Module", ptr %t128, i32 0, i32 11
  store ptr %t130, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb38
bb38:
  %t132 = load i64, ptr %l14, !tbaa !24
  store i64 %t132, ptr %l80, !tbaa !24
  %t133 = load ptr, ptr %l13, !tbaa !29
  %t135 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t133)
  store i64 %t135, ptr %l82
  br label %bb39
bb39:
  %t136 = load i64, ptr %l80, !tbaa !24
  %t137 = load i64, ptr %l82, !tbaa !24
  %t138 = icmp slt i64 %t136, %t137
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb40, label %bb41
bb40:
  br label %bb52
bb41:
  br label %bb42
bb42:
  %t142 = load ptr, ptr %l13, !tbaa !29
  %t143 = load i64, ptr %l14, !tbaa !24
  %t146 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t142, i64 %t143)
  store %"compiler/load:Import" %t146, ptr %l87
  br label %bb43
bb43:
  %t147 = load %"compiler/load:Import", ptr %l87
  store %"compiler/load:Import" %t147, ptr %l15
  %t148 = getelementptr %"compiler/load:Import", ptr %l15, i32 0, i32 5
  %t149 = load i64, ptr %t148, !tbaa !24
  %t151 = icmp sge i64 %t149, 0
  br i1 %t151, label %bb44, label %bb45
bb44:
  %t153 = getelementptr %"compiler/load:Import", ptr %l15, i32 0, i32 5
  %t154 = load i64, ptr %t153, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i1, ptr %t157, i64 %t154
  %t159 = load i1, ptr %t158, !tbaa !31
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l90, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l90, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = getelementptr %"compiler/load:Import", ptr %l15, i32 0, i32 5
  %t165 = load i64, ptr %t164, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t165)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t168 = load i64, ptr %l14, !tbaa !24
  %t171 = add i64 %t168, 1
  store i64 %t171, ptr %l14, !tbaa !24
  br label %bb38
bb52:
  br label %bb53
bb53:
  br label %bb24
bb54:
  %t173 = load ptr, ptr %lp4
  %t174 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_65, 0
  %t175 = insertvalue { ptr, ptr } %t174, ptr null, 1
  %t178 = extractvalue { ptr, ptr } %t175, 0
  %t179 = extractvalue { ptr, ptr } %t175, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v1, ptr %s0, ptr %t173, ptr %t178, ptr %t179)
  br label %bb55
bb55:
  %t180 = load ptr, ptr %lp4
  %t181 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t180
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t181, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2frecords_2eReaderRecords(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l36 = alloca i64
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca ptr
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l79 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i64
  %l87 = alloca ptr
  %l91 = alloca ptr
  %l95 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l96 = alloca ptr
  %l97 = alloca i64
  %l100 = alloca ptr
  %l104 = alloca ptr
  %l108 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l145 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l147 = alloca i64
  %l149 = alloca i64
  %l154 = alloca i64
  %l160 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l162 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l164 = alloca i64
  %l166 = alloca i64
  %l171 = alloca { i64, ptr }
  %l172 = alloca i64
  %l173 = alloca { i64, ptr }
  %l181 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l183 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l185 = alloca i64
  %l187 = alloca i64
  %l192 = alloca { i64, ptr }
  %l193 = alloca i64
  %l194 = alloca { i64, ptr }
  %l205 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l207 = alloca i64
  %l209 = alloca i64
  %l214 = alloca { i64, ptr }
  %l216 = alloca i64
  %l218 = alloca i1
  %l219 = alloca ptr
  %l221 = alloca i64
  %l223 = alloca { i64, ptr }
  %l225 = alloca i1
  %l232 = alloca { i64, ptr }
  %l233 = alloca i64
  %l234 = alloca i64
  %l237 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t17 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l36
  br label %bb1
bb1:
  %t8 = load i64, ptr %l36, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l36, !tbaa !24
  %t12 = icmp sle i64 %t11, 576460752303423487
  br i1 %t12, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_e43862288177251d_fb6c75927359cd1)
  unreachable
bb4:
  %t14 = load i64, ptr %l36, !tbaa !24
  %t15 = mul i64 %t14, 16
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  store i64 0, ptr %t17
  br label %fill.18
fill.18:
  %t21 = load i64, ptr %t17
  %t22 = icmp slt i64 %t21, %t14
  br i1 %t22, label %fillb.19, label %filld.20
fillb.19:
  %t23 = getelementptr { i64, ptr }, ptr %t16, i64 %t21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %t23
  %t24 = add i64 %t21, 1
  store i64 %t24, ptr %t17
  br label %fill.18
filld.20:
  %t25 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t16, 1
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l40
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_e43862288177251d_fb6c75927359cd1)
  unreachable
bb6:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l4
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l41
  br label %bb7
bb7:
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l5
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 3
  %t39 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eTokens(ptr %v1, ptr %s0, ptr %t37)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t39, ptr %l45
  br label %bb8
bb8:
  %t40 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t40, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l47
  br label %bb9
bb9:
  %t44 = load i64, ptr %l47, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb10, label %bb11
bb10:
  %t51 = load i64, ptr %l9, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb15
bb12:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l9, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l54, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb14
bb14:
  %t71 = load i64, ptr %l54, !tbaa !24
  store i64 %t71, ptr %l51, !tbaa !24
  br label %bb15
bb15:
  %t72 = load i64, ptr %l51, !tbaa !24
  store i64 %t72, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load i64, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb18:
  br label %bb19
bb19:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l12, !tbaa !24
  store ptr %l4, ptr %l72, !tbaa !29
  %t91 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %l73
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l72, !tbaa !29
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Haef94f44435f0acde1bbcde30a350c1f(ptr %s0, ptr %s2, ptr %t92, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93)
  br label %bb21
bb21:
  store ptr %l5, ptr %l74, !tbaa !29
  %t94 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %l75
  br label %bb22
bb22:
  %t95 = load ptr, ptr %l74, !tbaa !29
  %t96 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Haef94f44435f0acde1bbcde30a350c1f(ptr %s0, ptr %s2, ptr %t95, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96)
  br label %bb23
bb23:
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t97, i64 %t99)
  store ptr %t102, ptr %l79
  br label %bb24
bb24:
  %t103 = load ptr, ptr %l79, !tbaa !29
  %t105 = getelementptr %"compiler/load:Module", ptr %t103, i32 0, i32 4
  %t106 = load i64, ptr %t105, !tbaa !24
  %t108 = icmp slt i64 %t106, 0
  br i1 %t108, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb26:
  br label %bb27
bb27:
  store ptr %l4, ptr %l83, !tbaa !29
  %t110 = load i64, ptr %l12, !tbaa !24
  store i64 %t110, ptr %l84, !tbaa !24
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 3
  store ptr %t116, ptr %l87, !tbaa !29
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t119 = load i64, ptr %l12, !tbaa !24
  %t122 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t117, i64 %t119)
  store ptr %t122, ptr %l91
  br label %bb28
bb28:
  %t123 = load ptr, ptr %l91, !tbaa !29
  %t125 = getelementptr %"compiler/load:Module", ptr %t123, i32 0, i32 4
  %t126 = load i64, ptr %t125, !tbaa !24
  %t127 = load ptr, ptr %l87, !tbaa !29
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eRecordLines(ptr %v1, ptr %s0, ptr %s2, ptr %t127, i64 %t126, i1 true, ptr %l6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l95
  br label %bb29
bb29:
  %t131 = load ptr, ptr %l83, !tbaa !29
  %t132 = load i64, ptr %l84, !tbaa !24
  %t133 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Ha9227021807533b22d8a6fac522f3c47(ptr %s0, ptr %s2, ptr %t131, i64 %t132, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133)
  br label %bb30
bb30:
  store ptr %l5, ptr %l96, !tbaa !29
  %t134 = load i64, ptr %l12, !tbaa !24
  store i64 %t134, ptr %l97, !tbaa !24
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 3
  store ptr %t140, ptr %l100, !tbaa !29
  %t141 = load ptr, ptr %l2, !tbaa !29
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t141, i64 %t143)
  store ptr %t146, ptr %l104
  br label %bb31
bb31:
  %t147 = load ptr, ptr %l104, !tbaa !29
  %t149 = getelementptr %"compiler/load:Module", ptr %t147, i32 0, i32 4
  %t150 = load i64, ptr %t149, !tbaa !24
  %t151 = load ptr, ptr %l100, !tbaa !29
  %t154 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eRecordLines(ptr %v1, ptr %s0, ptr %s2, ptr %t151, i64 %t150, i1 false, ptr %l6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %l108
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l96, !tbaa !29
  %t156 = load i64, ptr %l97, !tbaa !24
  %t157 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l108
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Ha9227021807533b22d8a6fac522f3c47(ptr %s0, ptr %s2, ptr %t155, i64 %t156, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = add i64 %t158, 1
  store i64 %t161, ptr %l11, !tbaa !24
  br label %bb16
bb35:
  store i64 0, ptr %l13, !tbaa !24
  %t163 = load ptr, ptr %l2, !tbaa !29
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t163)
  store i64 %t165, ptr %l113
  br label %bb36
bb36:
  %t166 = load i64, ptr %l113, !tbaa !24
  store i64 %t166, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t167 = load i64, ptr %l14, !tbaa !24
  %t168 = load i64, ptr %l13, !tbaa !24
  %t171 = icmp sgt i64 %t167, %t168
  br i1 %t171, label %bb37, label %bb38
bb37:
  %t173 = load i64, ptr %l15, !tbaa !24
  %t175 = icmp sgt i64 %t173, 0
  br i1 %t175, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb42
bb39:
  %t177 = load i64, ptr %l14, !tbaa !24
  %t178 = load i64, ptr %l13, !tbaa !24
  %t181 = sub i64 %t177, %t178
  %t182 = load i64, ptr %l15, !tbaa !24
  %t185 = add i64 %t181, %t182
  %t187 = sub i64 %t185, 1
  %t188 = load i64, ptr %l15, !tbaa !24
  %t191 = sdiv i64 %t187, %t188
  store i64 %t191, ptr %l120, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb41
bb41:
  %t193 = load i64, ptr %l120, !tbaa !24
  store i64 %t193, ptr %l117, !tbaa !24
  br label %bb42
bb42:
  %t194 = load i64, ptr %l117, !tbaa !24
  store i64 %t194, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t195 = load i64, ptr %l17, !tbaa !24
  %t196 = load i64, ptr %l16, !tbaa !24
  %t199 = icmp slt i64 %t195, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb110
bb45:
  br label %bb46
bb46:
  %t203 = load i64, ptr %l13, !tbaa !24
  %t204 = load i64, ptr %l17, !tbaa !24
  %t205 = load i64, ptr %l15, !tbaa !24
  %t208 = mul i64 %t204, %t205
  %t211 = add i64 %t203, %t208
  store i64 %t211, ptr %l18, !tbaa !24
  %t213 = load i64, ptr %l18, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/load:Loader", ptr %t214, i32 0, i32 12
  %t217 = load i64, ptr %t216, !tbaa !24
  %t220 = icmp eq i64 %t213, %t217
  br i1 %t220, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s6)
  br label %bb109
bb48:
  br label %bb49
bb49:
  %t222 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s6, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t222, ptr %l142
  br label %bb50
bb50:
  %t223 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t223, ptr %l19
  store %olang.scope zeroinitializer, ptr %s8
  %t224 = load ptr, ptr %l2, !tbaa !29
  %t225 = load i64, ptr %l18, !tbaa !24
  %t228 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2frecords_2eReached(ptr %v0, ptr %s8, ptr %t224, i64 %t225)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %l145
  br label %bb51
bb51:
  %t229 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l145
  %t230 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t229, ptr %t230
  store ptr %t230, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb52
bb52:
  %t232 = load i64, ptr %l21, !tbaa !24
  store i64 %t232, ptr %l147, !tbaa !24
  %t233 = load ptr, ptr %l20, !tbaa !29
  %t235 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s8, ptr %t233)
  store i64 %t235, ptr %l149
  br label %bb53
bb53:
  %t236 = load i64, ptr %l147, !tbaa !24
  %t237 = load i64, ptr %l149, !tbaa !24
  %t238 = icmp slt i64 %t236, %t237
  %t240 = xor i1 %t238, true
  br i1 %t240, label %bb54, label %bb55
bb54:
  br label %bb84
bb55:
  br label %bb56
bb56:
  %t242 = load ptr, ptr %l20, !tbaa !29
  %t243 = load i64, ptr %l21, !tbaa !24
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s8, ptr %t242, i64 %t243)
  store i64 %t246, ptr %l154
  br label %bb57
bb57:
  %t247 = load i64, ptr %l154, !tbaa !24
  store i64 %t247, ptr %l22, !tbaa !24
  %t248 = load i64, ptr %l22, !tbaa !24
  %t249 = load i64, ptr %l18, !tbaa !24
  %t252 = icmp eq i64 %t248, %t249
  br i1 %t252, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t254 = load i64, ptr %l22, !tbaa !24
  %t257 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H0fdbabf49251589cbd1b71c681b39072(ptr %s0, ptr %s11, ptr %l4, i64 %t254)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t257, ptr %l160
  br label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s15
  %t258 = load i64, ptr %l22, !tbaa !24
  %t261 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H0fdbabf49251589cbd1b71c681b39072(ptr %s0, ptr %s15, ptr %l5, i64 %t258)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t261, ptr %l181
  br label %bb71
bb60:
  %t263 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e(ptr %s11, ptr %l160)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t263, ptr %l162
  br label %bb61
bb61:
  %t264 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l162
  %t265 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t264, ptr %t265
  store ptr %t265, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb62
bb62:
  %t267 = load i64, ptr %l24, !tbaa !24
  store i64 %t267, ptr %l164, !tbaa !24
  %t268 = load ptr, ptr %l23, !tbaa !29
  %t270 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2eLen_H327daf8a5f05e7deba4c08807621a9fe(ptr %s11, ptr %t268)
  store i64 %t270, ptr %l166
  br label %bb63
bb63:
  %t271 = load i64, ptr %l164, !tbaa !24
  %t272 = load i64, ptr %l166, !tbaa !24
  %t273 = icmp slt i64 %t271, %t272
  %t275 = xor i1 %t273, true
  br i1 %t275, label %bb64, label %bb65
bb64:
  br label %bb70
bb65:
  br label %bb66
bb66:
  %t277 = load ptr, ptr %l23, !tbaa !29
  %t278 = load i64, ptr %l24, !tbaa !24
  %t281 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2eAt__Hb06c5aa34d45867a1decef3b510ab43e(ptr %s11, ptr %s6, ptr %t277, i64 %t278)
  store { i64, ptr } %t281, ptr %l171
  br label %bb67
bb67:
  %t282 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 0
  store i64 %t283, ptr %l172, !tbaa !24
  %t284 = load i64, ptr %l172, !tbaa !24
  %t285 = mul i64 %t284, 1
  %t286 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t285)
  %t287 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  store { i64, ptr } %t288, ptr %l173, !tbaa !27
  %t289 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = load i64, ptr %l172, !tbaa !24
  %t294 = mul i64 %t293, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t290, ptr %t292, i64 %t294, i1 false)
  %t295 = load { i64, ptr }, ptr %l173, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s6, ptr %s6, ptr %l19, { i64, ptr } %t295)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t299 = load i64, ptr %l24, !tbaa !24
  %t302 = add i64 %t299, 1
  store i64 %t302, ptr %l24, !tbaa !24
  br label %bb62
bb70:
  call void @__olang_scope_close(ptr %s11)
  br label %bb82
bb71:
  %t305 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e(ptr %s15, ptr %l181)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t305, ptr %l183
  br label %bb72
bb72:
  %t306 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l183
  %t307 = call ptr @__olang_scope_alloc_a(ptr %s15, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t306, ptr %t307
  store ptr %t307, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb73
bb73:
  %t309 = load i64, ptr %l27, !tbaa !24
  store i64 %t309, ptr %l185, !tbaa !24
  %t310 = load ptr, ptr %l26, !tbaa !29
  %t312 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2eLen_H327daf8a5f05e7deba4c08807621a9fe(ptr %s15, ptr %t310)
  store i64 %t312, ptr %l187
  br label %bb74
bb74:
  %t313 = load i64, ptr %l185, !tbaa !24
  %t314 = load i64, ptr %l187, !tbaa !24
  %t315 = icmp slt i64 %t313, %t314
  %t317 = xor i1 %t315, true
  br i1 %t317, label %bb75, label %bb76
bb75:
  br label %bb81
bb76:
  br label %bb77
bb77:
  %t319 = load ptr, ptr %l26, !tbaa !29
  %t320 = load i64, ptr %l27, !tbaa !24
  %t323 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2eAt__Hb06c5aa34d45867a1decef3b510ab43e(ptr %s15, ptr %s6, ptr %t319, i64 %t320)
  store { i64, ptr } %t323, ptr %l192
  br label %bb78
bb78:
  %t324 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t324, 0
  store i64 %t325, ptr %l193, !tbaa !24
  %t326 = load i64, ptr %l193, !tbaa !24
  %t327 = mul i64 %t326, 1
  %t328 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t327)
  %t329 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t328, 1
  store { i64, ptr } %t330, ptr %l194, !tbaa !27
  %t331 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = load i64, ptr %l193, !tbaa !24
  %t336 = mul i64 %t335, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t332, ptr %t334, i64 %t336, i1 false)
  %t337 = load { i64, ptr }, ptr %l194, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s6, ptr %s6, ptr %l19, { i64, ptr } %t337)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t341 = load i64, ptr %l27, !tbaa !24
  %t344 = add i64 %t341, 1
  store i64 %t344, ptr %l27, !tbaa !24
  br label %bb73
bb81:
  call void @__olang_scope_close(ptr %s15)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t346 = load i64, ptr %l21, !tbaa !24
  %t349 = add i64 %t346, 1
  store i64 %t349, ptr %l21, !tbaa !24
  br label %bb52
bb84:
  call void @__olang_scope_close(ptr %s8)
  %t351 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_67, 0
  %t352 = insertvalue { ptr, ptr } %t351, ptr null, 1
  %t355 = extractvalue { ptr, ptr } %t352, 0
  %t356 = extractvalue { ptr, ptr } %t352, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s6, ptr %s6, ptr %l19, ptr %t355, ptr %t356)
  br label %bb85
bb85:
  %t357 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s6, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t357, ptr %l205
  br label %bb86
bb86:
  %t358 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l205
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t358, ptr %l29
  store ptr %l19, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb87
bb87:
  %t360 = load i64, ptr %l31, !tbaa !24
  store i64 %t360, ptr %l207, !tbaa !24
  %t361 = load ptr, ptr %l30, !tbaa !29
  %t363 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s6, ptr %t361)
  store i64 %t363, ptr %l209
  br label %bb88
bb88:
  %t364 = load i64, ptr %l207, !tbaa !24
  %t365 = load i64, ptr %l209, !tbaa !24
  %t366 = icmp slt i64 %t364, %t365
  %t368 = xor i1 %t366, true
  br i1 %t368, label %bb89, label %bb90
bb89:
  br label %bb105
bb90:
  br label %bb91
bb91:
  %t370 = load ptr, ptr %l30, !tbaa !29
  %t371 = load i64, ptr %l31, !tbaa !24
  %t374 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s6, ptr %s6, ptr %t370, i64 %t371)
  store { i64, ptr } %t374, ptr %l214
  br label %bb92
bb92:
  %t375 = load { i64, ptr }, ptr %l214, !tbaa !27
  store { i64, ptr } %t375, ptr %l32, !tbaa !27
  %t377 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s6, ptr %l29)
  store i64 %t377, ptr %l216
  br label %bb93
bb93:
  %t378 = load i64, ptr %l216, !tbaa !24
  %t379 = icmp eq i64 %t378, 0
  br i1 %t379, label %bb94, label %bb95
bb94:
  store i1 true, ptr %l218, !tbaa !21
  br label %bb99
bb95:
  store ptr %l29, ptr %l219, !tbaa !29
  %t382 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s6, ptr %l29)
  store i64 %t382, ptr %l221
  br label %bb96
bb96:
  %t383 = load i64, ptr %l221, !tbaa !24
  %t384 = sub i64 %t383, 1
  %t385 = load ptr, ptr %l219, !tbaa !29
  %t387 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s6, ptr %s6, ptr %t385, i64 %t384)
  store { i64, ptr } %t387, ptr %l223
  br label %bb97
bb97:
  %t388 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t389 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t391 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t389, { i64, ptr } %t388)
  store i1 %t391, ptr %l225
  br label %bb98
bb98:
  %t392 = load i1, ptr %l225, !tbaa !21
  %t393 = xor i1 %t392, true
  store i1 %t393, ptr %l218, !tbaa !21
  br label %bb99
bb99:
  %t395 = load i1, ptr %l218, !tbaa !21
  br i1 %t395, label %bb100, label %bb101
bb100:
  %t396 = load { i64, ptr }, ptr %l32, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s6, ptr %s6, ptr %l29, { i64, ptr } %t396)
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t399 = load i64, ptr %l31, !tbaa !24
  %t402 = add i64 %t399, 1
  store i64 %t402, ptr %l31, !tbaa !24
  br label %bb87
bb105:
  %t404 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t404, ptr %l232, !tbaa !27
  %t405 = load i64, ptr %l18, !tbaa !24
  store i64 %t405, ptr %l233, !tbaa !24
  %t406 = call ptr @__olang_scope_hold(ptr %v2)
  %t407 = ptrtoint ptr %t406 to i64
  store i64 %t407, ptr %l234, !tbaa !24
  %t408 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t408, label %bb106, label %bb107
bb106:
  %t410 = call ptr @__olang_region_make(ptr %v2)
  %t411 = ptrtoint ptr %t410 to i64
  store i64 %t411, ptr %l234, !tbaa !24
  br label %bb107
bb107:
  %t412 = load i64, ptr %l234
  %t413 = inttoptr i64 %t412 to ptr
  %t415 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s6, ptr %s6, ptr %t413, ptr %l29, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store { i64, ptr } %t415, ptr %l237
  br label %bb108
bb108:
  %t416 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t418 = load i64, ptr %l233, !tbaa !24
  %t419 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !27
  %t421 = getelementptr { i64, ptr }, ptr %t420, i64 %t418
  store { i64, ptr } %t416, ptr %t421, !tbaa !37
  call void @__olang_scope_close(ptr %s6)
  br label %bb109
bb109:
  %t422 = load i64, ptr %l17, !tbaa !24
  %t425 = add i64 %t422, 1
  store i64 %t425, ptr %l17, !tbaa !24
  br label %bb43
bb110:
  %t427 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t427, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2frecords_2eScopeRecords(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %lp25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l38 = alloca i1
  %l45 = alloca i64
  %l48 = alloca i64
  %l66 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca i1
  %l74 = alloca ptr
  %l79 = alloca ptr
  %l83 = alloca ptr
  %l87 = alloca ptr
  %l91 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca i32
  %l108 = alloca i1
  %l118 = alloca i64
  %l121 = alloca i64
  %l139 = alloca { i64, ptr }
  %l142 = alloca i1
  %l143 = alloca i1
  %l147 = alloca ptr
  %l151 = alloca ptr
  %l155 = alloca ptr
  %l158 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l165 = alloca i64
  %l167 = alloca i64
  %l168 = alloca i64
  %l180 = alloca { i64, ptr }
  %l185 = alloca i1
  %l187 = alloca i1
  %l188 = alloca { i64, ptr }
  %l190 = alloca i64
  %l193 = alloca i64
  %l194 = alloca i64
  %l200 = alloca { i64, ptr }
  %l201 = alloca i1
  %l202 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l210 = alloca i32
  %l212 = alloca i1
  %l213 = alloca i64
  %l215 = alloca i64
  %l216 = alloca i32
  %l220 = alloca ptr
  %l224 = alloca ptr
  %l226 = alloca i64
  %l228 = alloca i64
  %l230 = alloca i64
  %l231 = alloca i64
  %l236 = alloca i32
  %l238 = alloca i1
  %l240 = alloca ptr
  %l244 = alloca ptr
  %l247 = alloca ptr
  %l251 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v4)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l27
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l4
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 291
  store i1 true, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l3, !tbaa !29
  store ptr %t14, ptr %l32, !tbaa !29
  %t15 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d69, i32 0, i32 1) })
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l35
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store { i64, ptr } %t16, ptr %l34
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t20, ptr %l33, !tbaa !27
  br label %bb7
bb3:
  %t21 = load i32, ptr %l35, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb7
bb7:
  %t26 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t27, ptr %l38
  br label %bb8
bb8:
  %t28 = load i1, ptr %l38, !tbaa !21
  %t29 = xor i1 %t28, true
  %t31 = load ptr, ptr %l32, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 292
  store i1 %t29, ptr %t32, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb14
bb11:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l48, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb13
bb13:
  %t63 = load i64, ptr %l48, !tbaa !24
  store i64 %t63, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t64 = load i64, ptr %l45, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb17:
  br label %bb18
bb18:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l11, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t83, ptr %l66, !tbaa !27
  %t84 = load i64, ptr %l11, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %t87, i64 %t84
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !37
  %t91 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s2, { i64, ptr } %t89, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t91, ptr %l69
  br label %bb19
bb19:
  %t92 = load i1, ptr %l69, !tbaa !21
  br i1 %t92, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb23
bb21:
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = getelementptr %"compiler/load:Loader", ptr %t93, i32 0, i32 10
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t95, i64 %t96)
  store ptr %t99, ptr %l74
  br label %bb22
bb22:
  %t100 = load ptr, ptr %l74, !tbaa !29
  %t102 = getelementptr %"compiler/load:Module", ptr %t100, i32 0, i32 4
  %t103 = load i64, ptr %t102, !tbaa !24
  %t105 = icmp slt i64 %t103, 0
  store i1 %t105, ptr %l70, !tbaa !21
  br label %bb23
bb23:
  %t107 = load i1, ptr %l70, !tbaa !21
  br i1 %t107, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t108 = load ptr, ptr %l3, !tbaa !29
  %t110 = getelementptr %"compiler/scope:Scoper", ptr %t108, i32 0, i32 307
  store ptr %t110, ptr %l79, !tbaa !29
  %t111 = load ptr, ptr %l5, !tbaa !29
  %t113 = getelementptr %"compiler/load:Loader", ptr %t111, i32 0, i32 10
  %t114 = load i64, ptr %l11, !tbaa !24
  %t117 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t113, i64 %t114)
  store ptr %t117, ptr %l83
  br label %bb27
bb27:
  %t118 = load ptr, ptr %l83, !tbaa !29
  %t120 = getelementptr %"compiler/load:Module", ptr %t118, i32 0, i32 4
  %t121 = load i64, ptr %t120, !tbaa !24
  %t122 = load ptr, ptr %l79, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v3, ptr %t122, i64 %t121, i1 true)
  br label %bb28
bb28:
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t126 = getelementptr %"compiler/scope:Scoper", ptr %t124, i32 0, i32 308
  store ptr %t126, ptr %l87, !tbaa !29
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t129 = getelementptr %"compiler/load:Loader", ptr %t127, i32 0, i32 10
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t129, i64 %t130)
  store ptr %t133, ptr %l91
  br label %bb29
bb29:
  %t134 = load ptr, ptr %l91, !tbaa !29
  %t136 = getelementptr %"compiler/load:Module", ptr %t134, i32 0, i32 4
  %t137 = load i64, ptr %t136, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t138, ptr %l94, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %t142, i64 %t139
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !37
  %t145 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v3, ptr %v2, ptr %t145, i64 %t137, { i64, ptr } %t144)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t151 = add i64 %t148, 1
  store i64 %t151, ptr %l10, !tbaa !24
  br label %bb15
bb32:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/build:Config", ptr %t153, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = extractvalue { i64, ptr } %t156, 0
  %t160 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t162 = add i64 %t159, %t161
  %t163 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t162)
  call void @olang_textcopy(ptr %t163, ptr %t158, i64 %t159)
  %t164 = getelementptr i8, ptr %t163, i64 %t159
  call void @olang_textcopy(ptr %t164, ptr %t160, i64 %t161)
  %t165 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t163, 1
  %t169 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s0, ptr %s0, { i64, ptr } %t166)
  %t170 = extractvalue { i32, { i64, ptr } } %t169, 1
  %t171 = extractvalue { i32, { i64, ptr } } %t169, 0
  store i32 %t171, ptr %l106
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb34, label %ok.173, !prof !99
ok.173:
  store { i64, ptr } %t170, ptr %l105
  br label %bb33
bb33:
  %t174 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t174, ptr %l100, !tbaa !27
  br label %bb38
bb34:
  %t175 = load i32, ptr %l106, !tbaa !23
  %t176 = ashr i32 %t175, 16
  %t178 = icmp eq i32 %t176, 1
  store i1 %t178, ptr %l108, !tbaa !21
  %t179 = load i32, ptr %l106, !tbaa !23
  %t180 = ashr i32 %t179, 16
  %t182 = icmp eq i32 %t180, 1
  br i1 %t182, label %bb35, label %bb36
bb35:
  call void @__olang_errpay_pop()
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t184 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t184, ptr %rv
  br label %ret
bb38:
  %t186 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t186, ptr %l12, !tbaa !27
  %t187 = load ptr, ptr %l3, !tbaa !29
  %t189 = getelementptr %"compiler/scope:Scoper", ptr %t187, i32 0, i32 290
  store i1 true, ptr %t189, !tbaa !21
  store i64 0, ptr %l13, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t194 = load i64, ptr %l14, !tbaa !24
  %t195 = load i64, ptr %l13, !tbaa !24
  %t198 = icmp sgt i64 %t194, %t195
  br i1 %t198, label %bb39, label %bb40
bb39:
  %t200 = load i64, ptr %l15, !tbaa !24
  %t202 = icmp sgt i64 %t200, 0
  br i1 %t202, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb44
bb41:
  %t204 = load i64, ptr %l14, !tbaa !24
  %t205 = load i64, ptr %l13, !tbaa !24
  %t208 = sub i64 %t204, %t205
  %t209 = load i64, ptr %l15, !tbaa !24
  %t212 = add i64 %t208, %t209
  %t214 = sub i64 %t212, 1
  %t215 = load i64, ptr %l15, !tbaa !24
  %t218 = sdiv i64 %t214, %t215
  store i64 %t218, ptr %l121, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb43
bb43:
  %t220 = load i64, ptr %l121, !tbaa !24
  store i64 %t220, ptr %l118, !tbaa !24
  br label %bb44
bb44:
  %t221 = load i64, ptr %l118, !tbaa !24
  store i64 %t221, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t222 = load i64, ptr %l17, !tbaa !24
  %t223 = load i64, ptr %l16, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s8)
  br label %bb109
bb47:
  br label %bb48
bb48:
  %t230 = load i64, ptr %l13, !tbaa !24
  %t231 = load i64, ptr %l17, !tbaa !24
  %t232 = load i64, ptr %l15, !tbaa !24
  %t235 = mul i64 %t231, %t232
  %t238 = add i64 %t230, %t235
  store i64 %t238, ptr %l18, !tbaa !24
  %t240 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t240, ptr %l139, !tbaa !27
  %t241 = load i64, ptr %l18, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr { i64, ptr }, ptr %t244, i64 %t241
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !37
  %t248 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s8, { i64, ptr } %t246, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t248, ptr %l142
  br label %bb49
bb49:
  %t249 = load i1, ptr %l142, !tbaa !21
  br i1 %t249, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb53
bb51:
  %t250 = load ptr, ptr %l5, !tbaa !29
  %t252 = getelementptr %"compiler/load:Loader", ptr %t250, i32 0, i32 10
  %t253 = load i64, ptr %l18, !tbaa !24
  %t256 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t252, i64 %t253)
  store ptr %t256, ptr %l147
  br label %bb52
bb52:
  %t257 = load ptr, ptr %l147, !tbaa !29
  %t259 = getelementptr %"compiler/load:Module", ptr %t257, i32 0, i32 4
  %t260 = load i64, ptr %t259, !tbaa !24
  %t262 = icmp slt i64 %t260, 0
  store i1 %t262, ptr %l143, !tbaa !21
  br label %bb53
bb53:
  %t264 = load i1, ptr %l143, !tbaa !21
  br i1 %t264, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb108
bb55:
  br label %bb56
bb56:
  %t265 = load ptr, ptr %l1, !tbaa !29
  store ptr %t265, ptr %l151, !tbaa !29
  %t266 = load ptr, ptr %l5, !tbaa !29
  %t268 = getelementptr %"compiler/load:Loader", ptr %t266, i32 0, i32 10
  %t269 = load i64, ptr %l18, !tbaa !24
  %t272 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t268, i64 %t269)
  store ptr %t272, ptr %l155
  br label %bb57
bb57:
  %t273 = load ptr, ptr %l155, !tbaa !29
  %t275 = getelementptr %"compiler/load:Module", ptr %t273, i32 0, i32 2
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  %t277 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t277, ptr %l158, !tbaa !27
  %t278 = load i64, ptr %l18, !tbaa !24
  %t280 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr { i64, ptr }, ptr %t281, i64 %t278
  %t283 = load { i64, ptr }, ptr %t282, !tbaa !37
  %t284 = load ptr, ptr %l151, !tbaa !29
  %t287 = call { i64, ptr } @compiler_2frecords_2escopeStem(ptr %v1, ptr %v0, ptr %v2, ptr %s8, ptr %t284, { i64, ptr } %t276, { i64, ptr } %t283)
  store { i64, ptr } %t287, ptr %l161
  br label %bb58
bb58:
  %t288 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t288, ptr %l19, !tbaa !27
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr %"compiler/build:Config", ptr %t289, i32 0, i32 0
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t296 = add i64 %t294, 5
  store i64 %t296, ptr %l165, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  store i64 %t299, ptr %l167, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t300, 0
  store i64 %t301, ptr %l168, !tbaa !24
  %t302 = load i64, ptr %l165, !tbaa !24
  %t303 = icmp sge i64 %t302, 0
  br i1 %t303, label %bb59, label %bb60
bb59:
  %t305 = load i64, ptr %l165, !tbaa !24
  %t306 = load i64, ptr %l167, !tbaa !24
  %t307 = icmp sle i64 %t305, %t306
  br i1 %t307, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_4e9604c680c7b950_9ac30b55dba7b9c)
  unreachable
bb61:
  %t309 = load i64, ptr %l167, !tbaa !24
  %t310 = load i64, ptr %l168, !tbaa !24
  %t311 = icmp sle i64 %t309, %t310
  br i1 %t311, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_4e9604c680c7b950_9ac30b55dba7b9c)
  unreachable
bb63:
  %t313 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = load i64, ptr %l165, !tbaa !24
  %t316 = load i64, ptr %l167, !tbaa !24
  %t317 = getelementptr i8, ptr %t314, i64 %t315
  %t318 = sub i64 %t316, %t315
  %t319 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t317, 1
  store { i64, ptr } %t320, ptr %l20, !tbaa !27
  %t322 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t322, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t324 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t324, 0
  store i64 %t326, ptr %l23, !tbaa !24
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_4e9604c680c7b950_9ac30b55dba7b9c)
  unreachable
bb65:
  store %olang.scope zeroinitializer, ptr %s11
  %t328 = load i64, ptr %l22, !tbaa !24
  %t329 = load i64, ptr %l23, !tbaa !24
  %t332 = icmp slt i64 %t328, %t329
  %t334 = xor i1 %t332, true
  br i1 %t334, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s11)
  br label %bb107
bb67:
  br label %bb68
bb68:
  %t336 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t336, ptr %l180, !tbaa !27
  %t337 = load i64, ptr %l22, !tbaa !24
  %t339 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = getelementptr { i64, ptr }, ptr %t340, i64 %t337
  %t342 = load { i64, ptr }, ptr %t341, !tbaa !37
  store { i64, ptr } %t342, ptr %l24, !tbaa !27
  %t344 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t348 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s8, { i64, ptr } %t344, { i64, ptr } %t345)
  store i1 %t348, ptr %l185
  br label %bb69
bb69:
  %t349 = load i1, ptr %l185, !tbaa !21
  %t350 = xor i1 %t349, true
  br i1 %t350, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l187, !tbaa !21
  br label %bb79
bb71:
  %t352 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t352, ptr %l188, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t353, 0
  store i64 %t355, ptr %l190, !tbaa !24
  %t356 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t356, 0
  store i64 %t359, ptr %l193, !tbaa !24
  %t360 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t360, 0
  store i64 %t361, ptr %l194, !tbaa !24
  %t362 = load i64, ptr %l190, !tbaa !24
  %t363 = icmp sge i64 %t362, 0
  br i1 %t363, label %bb72, label %bb73
bb72:
  %t365 = load i64, ptr %l190, !tbaa !24
  %t366 = load i64, ptr %l193, !tbaa !24
  %t367 = icmp sle i64 %t365, %t366
  br i1 %t367, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @olang_loc_5b539dac05fcd02d_94c517b58e4a7909)
  unreachable
bb74:
  %t369 = load i64, ptr %l193, !tbaa !24
  %t370 = load i64, ptr %l194, !tbaa !24
  %t371 = icmp sle i64 %t369, %t370
  br i1 %t371, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_5b539dac05fcd02d_94c517b58e4a7909)
  unreachable
bb76:
  %t373 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = load i64, ptr %l190, !tbaa !24
  %t376 = load i64, ptr %l193, !tbaa !24
  %t377 = getelementptr i8, ptr %t374, i64 %t375
  %t378 = sub i64 %t376, %t375
  %t379 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t380 = insertvalue { i64, ptr } %t379, ptr %t377, 1
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l200, !tbaa !27
  %t383 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t384 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s11, { i64, ptr } %t380, { i64, ptr } %t383)
  store i1 %t384, ptr %l201
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_5b539dac05fcd02d_94c517b58e4a7909)
  unreachable
bb78:
  %t385 = load i1, ptr %l201, !tbaa !21
  store i1 %t385, ptr %l187, !tbaa !21
  br label %bb79
bb79:
  %t386 = load i1, ptr %l187, !tbaa !21
  br i1 %t386, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s11)
  br label %bb106
bb81:
  br label %bb82
bb82:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l1, !tbaa !29
  %t390 = getelementptr %"compiler/build:Config", ptr %t388, i32 0, i32 0
  %t391 = load { i64, ptr }, ptr %t390, !tbaa !27
  %t392 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t391, 1
  %t395 = extractvalue { i64, ptr } %t391, 0
  %t396 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t397 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t398 = add i64 %t395, %t397
  %t400 = extractvalue { i64, ptr } %t392, 1
  %t401 = extractvalue { i64, ptr } %t392, 0
  %t402 = add i64 %t398, %t401
  %t403 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t394, i64 %t395)
  %t404 = getelementptr i8, ptr %t403, i64 %t395
  call void @olang_textcopy(ptr %t404, ptr %t396, i64 %t397)
  %t405 = getelementptr i8, ptr %t404, i64 %t397
  call void @olang_textcopy(ptr %t405, ptr %t400, i64 %t401)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t403, 1
  %t411 = call { i32, { i64, ptr } } @compiler_2frecords_2escopeRecord(ptr %v0, ptr %s11, ptr %v4, ptr %t387, { i64, ptr } %t407)
  %t412 = extractvalue { i32, { i64, ptr } } %t411, 1
  %t413 = extractvalue { i32, { i64, ptr } } %t411, 0
  store i32 %t413, ptr %l210
  %t414 = icmp ne i32 %t413, 0
  br i1 %t414, label %bb84, label %ok.415, !prof !99
ok.415:
  store { i64, ptr } %t412, ptr %l209
  br label %bb83
bb83:
  %t416 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t416, ptr %l202, !tbaa !27
  br label %bb86
bb84:
  %t417 = load i32, ptr %l210, !tbaa !23
  %t418 = ashr i32 %t417, 16
  %t420 = icmp eq i32 %t418, 1
  store i1 %t420, ptr %l212, !tbaa !21
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s11)
  br label %bb106
bb86:
  %t421 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t421, ptr %lp25
  %t422 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t423 = load ptr, ptr %lp25
  store { i64, ptr } %t422, ptr %t423, !tbaa !27
  %t424 = load ptr, ptr %lp25
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  %t427 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v4, ptr %s11, { i64, ptr } %t425, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d77, i32 0, i32 1) })
  %t428 = extractvalue { i32, i64 } %t427, 1
  %t429 = extractvalue { i32, i64 } %t427, 0
  store i32 %t429, ptr %l216
  %t430 = icmp ne i32 %t429, 0
  br i1 %t430, label %bb88, label %ok.431, !prof !99
ok.431:
  store i64 %t428, ptr %l215
  br label %bb87
bb87:
  %t432 = load i64, ptr %l215, !tbaa !24
  store i64 %t432, ptr %l213, !tbaa !24
  br label %bb90
bb88:
  br label %bb89
bb89:
  %t433 = load ptr, ptr %lp25
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t434, 0
  store i64 %t436, ptr %l213, !tbaa !24
  br label %bb90
bb90:
  %t438 = load i64, ptr %l213, !tbaa !24
  %t439 = sub i64 %t438, 1
  store i64 %t439, ptr %l26, !tbaa !24
  %t441 = load ptr, ptr %l3, !tbaa !29
  store ptr %t441, ptr %l220, !tbaa !29
  %t442 = load ptr, ptr %l5, !tbaa !29
  %t444 = getelementptr %"compiler/load:Loader", ptr %t442, i32 0, i32 10
  %t445 = load i64, ptr %l18, !tbaa !24
  %t448 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t444, i64 %t445)
  store ptr %t448, ptr %l224
  br label %bb91
bb91:
  %t449 = load ptr, ptr %l224, !tbaa !29
  %t451 = getelementptr %"compiler/load:Module", ptr %t449, i32 0, i32 4
  %t452 = load i64, ptr %t451, !tbaa !24
  store i64 %t452, ptr %l226, !tbaa !24
  %t453 = load i64, ptr %l26, !tbaa !24
  %t455 = add i64 %t453, 1
  store i64 %t455, ptr %l228, !tbaa !24
  %t456 = load ptr, ptr %lp25
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t457, 0
  store i64 %t459, ptr %l230, !tbaa !24
  %t460 = load ptr, ptr %lp25
  %t461 = load { i64, ptr }, ptr %t460, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t461, 0
  store i64 %t462, ptr %l231, !tbaa !24
  %t463 = load i64, ptr %l228, !tbaa !24
  %t464 = icmp sge i64 %t463, 0
  br i1 %t464, label %bb92, label %bb93
bb92:
  %t466 = load i64, ptr %l228, !tbaa !24
  %t467 = load i64, ptr %l230, !tbaa !24
  %t468 = icmp sle i64 %t466, %t467
  br i1 %t468, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @olang_loc_c66c474bbb96a3ce_87152442c6a85c6a)
  unreachable
bb94:
  %t470 = load i64, ptr %l230, !tbaa !24
  %t471 = load i64, ptr %l231, !tbaa !24
  %t472 = icmp sle i64 %t470, %t471
  br i1 %t472, label %bb96, label %bb97
bb95:
  call void @__olang_check_failed(ptr @olang_loc_c66c474bbb96a3ce_87152442c6a85c6a)
  unreachable
bb96:
  %t474 = load ptr, ptr %lp25
  %t475 = getelementptr { i64, ptr }, ptr %t474, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !27
  %t477 = load i64, ptr %l228, !tbaa !24
  %t478 = load i64, ptr %l230, !tbaa !24
  %t479 = getelementptr i8, ptr %t476, i64 %t477
  %t480 = sub i64 %t478, %t477
  %t481 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t479, 1
  %t483 = load ptr, ptr %l220, !tbaa !29
  %t484 = load i64, ptr %l226, !tbaa !24
  %t486 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eAddRecord(ptr %v3, ptr %v4, ptr %t483, i64 %t484, { i64, ptr } %t482)
  store i32 %t486, ptr %l236
  %t487 = icmp ne i32 %t486, 0
  br i1 %t487, label %bb99, label %ok.488, !prof !99
ok.488:
  br label %bb98
bb97:
  call void @__olang_check_failed(ptr @olang_loc_c66c474bbb96a3ce_87152442c6a85c6a)
  unreachable
bb98:
  br label %bb101
bb99:
  %t489 = load i32, ptr %l236, !tbaa !23
  %t490 = ashr i32 %t489, 16
  %t492 = icmp eq i32 %t490, 1
  store i1 %t492, ptr %l238, !tbaa !21
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s11)
  br label %bb106
bb101:
  %t493 = load ptr, ptr %l3, !tbaa !29
  %t495 = getelementptr %"compiler/scope:Scoper", ptr %t493, i32 0, i32 306
  store ptr %t495, ptr %l240, !tbaa !29
  %t496 = load ptr, ptr %l5, !tbaa !29
  %t498 = getelementptr %"compiler/load:Loader", ptr %t496, i32 0, i32 10
  %t499 = load i64, ptr %l18, !tbaa !24
  %t502 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t498, i64 %t499)
  store ptr %t502, ptr %l244
  br label %bb102
bb102:
  %t503 = load ptr, ptr %l244, !tbaa !29
  %t505 = getelementptr %"compiler/load:Module", ptr %t503, i32 0, i32 4
  %t506 = load i64, ptr %t505, !tbaa !24
  %t507 = load ptr, ptr %l240, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v3, ptr %t507, i64 %t506, i1 true)
  br label %bb103
bb103:
  store ptr %l4, ptr %l247, !tbaa !29
  %t509 = load ptr, ptr %l5, !tbaa !29
  %t511 = getelementptr %"compiler/load:Loader", ptr %t509, i32 0, i32 10
  %t512 = load i64, ptr %l18, !tbaa !24
  %t515 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t511, i64 %t512)
  store ptr %t515, ptr %l251
  br label %bb104
bb104:
  %t516 = load ptr, ptr %l251, !tbaa !29
  %t518 = getelementptr %"compiler/load:Module", ptr %t516, i32 0, i32 4
  %t519 = load i64, ptr %t518, !tbaa !24
  %t520 = load ptr, ptr %lp25
  %t521 = load { i64, ptr }, ptr %t520, !tbaa !27
  %t522 = load ptr, ptr %l247, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v4, ptr %v4, ptr %t522, i64 %t519, { i64, ptr } %t521)
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s11)
  br label %bb107
bb106:
  %t525 = load i64, ptr %l22, !tbaa !24
  %t528 = add i64 %t525, 1
  store i64 %t528, ptr %l22, !tbaa !24
  br label %bb65
bb107:
  call void @__olang_scope_close(ptr %s8)
  br label %bb108
bb108:
  %t530 = load i64, ptr %l17, !tbaa !24
  %t533 = add i64 %t530, 1
  store i64 %t533, ptr %l17, !tbaa !24
  br label %bb45
bb109:
  %t535 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t535, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local void @compiler_2frecords_2eTrimRecordDir(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/os:FileInfo"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca %"compiler/build:Held"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l24 = alloca i1
  %l37 = alloca { i64, ptr }
  %l41 = alloca i1
  %l43 = alloca %"std/os:FileInfo"
  %l48 = alloca %"std/os:FileInfo"
  %l49 = alloca i32
  %l51 = alloca i1
  %l61 = alloca i32
  %l63 = alloca i1
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca i64
  %l78 = alloca i64
  %l83 = alloca %"compiler/build:Held"
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i32
  %l98 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l110 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l22
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l21
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t8, ptr %l19, !tbaa !27
  br label %bb10
bb2:
  %t9 = load i32, ptr %l22, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l24, !tbaa !21
  %t13 = load i32, ptr %l22, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t18 = icmp sge i64 0, 0
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = icmp sle i64 0, 576460752303423487
  br i1 %t20, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9ddf5b6d72b888b0_7ac7d96e6bd8ca04)
  unreachable
bb8:
  %t22 = mul i64 0, 16
  %t23 = insertvalue { i64, ptr } undef, i64 0, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_9ddf5b6d72b888b0_7ac7d96e6bd8ca04)
  unreachable
bb10:
  %t26 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t26, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb13:
  br label %bb14
bb14:
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t41, ptr %l37, !tbaa !27
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l9, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t49, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t51, ptr %l41
  br label %bb15
bb15:
  %t52 = load i1, ptr %l41, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb17:
  br label %bb18
bb18:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = extractvalue { i64, ptr } %t55, 0
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t64 = extractvalue { i64, ptr } %t56, 1
  %t65 = extractvalue { i64, ptr } %t56, 0
  %t66 = add i64 %t62, %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t58, i64 %t59)
  %t68 = getelementptr i8, ptr %t67, i64 %t59
  call void @olang_textcopy(ptr %t68, ptr %t60, i64 %t61)
  %t69 = getelementptr i8, ptr %t68, i64 %t61
  call void @olang_textcopy(ptr %t69, ptr %t64, i64 %t65)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t67, 1
  %t74 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s2, { i64, ptr } %t71)
  %t75 = extractvalue { i32, %"std/os:FileInfo" } %t74, 1
  %t76 = extractvalue { i32, %"std/os:FileInfo" } %t74, 0
  store i32 %t76, ptr %l49
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb20, label %ok.78, !prof !99
ok.78:
  store %"std/os:FileInfo" %t75, ptr %l48
  br label %bb19
bb19:
  %t79 = load %"std/os:FileInfo", ptr %l48
  store %"std/os:FileInfo" %t79, ptr %l43
  br label %bb24
bb20:
  %t80 = load i32, ptr %l49, !tbaa !23
  %t81 = ashr i32 %t80, 16
  %t83 = icmp eq i32 %t81, 1
  store i1 %t83, ptr %l51, !tbaa !21
  %t84 = load i32, ptr %l49, !tbaa !23
  %t85 = ashr i32 %t84, 16
  %t87 = icmp eq i32 %t85, 1
  br i1 %t87, label %bb21, label %bb22
bb21:
  call void @__olang_errpay_pop()
  br label %bb22
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb24:
  %t89 = load %"std/os:FileInfo", ptr %l43
  store %"std/os:FileInfo" %t89, ptr %l10
  %t90 = getelementptr %"std/os:FileInfo", ptr %l10, i32 0, i32 2
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = load i64, ptr %l2, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  br i1 %t95, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = extractvalue { i64, ptr } %t97, 0
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t106 = extractvalue { i64, ptr } %t98, 1
  %t107 = extractvalue { i64, ptr } %t98, 0
  %t108 = add i64 %t104, %t107
  %t109 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t100, i64 %t101)
  %t110 = getelementptr i8, ptr %t109, i64 %t101
  call void @olang_textcopy(ptr %t110, ptr %t102, i64 %t103)
  %t111 = getelementptr i8, ptr %t110, i64 %t103
  call void @olang_textcopy(ptr %t111, ptr %t106, i64 %t107)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t109, 1
  %t116 = call i32 @std_2fos_2eRemove(ptr %s6, { i64, ptr } %t113)
  store i32 %t116, ptr %l61
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb28, label %ok.118, !prof !99
ok.118:
  br label %bb27
bb26:
  br label %bb33
bb27:
  br label %bb32
bb28:
  %t119 = load i32, ptr %l61, !tbaa !23
  %t120 = ashr i32 %t119, 16
  %t122 = icmp eq i32 %t120, 1
  store i1 %t122, ptr %l63, !tbaa !21
  %t123 = load i32, ptr %l61, !tbaa !23
  %t124 = ashr i32 %t123, 16
  %t126 = icmp eq i32 %t124, 1
  br i1 %t126, label %bb29, label %bb30
bb29:
  call void @__olang_errpay_pop()
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l7, !tbaa !24
  br label %bb11
bb35:
  %t133 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t135 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2eHoldings(ptr %v0, ptr %s0, { i64, ptr } %t133, i64 2, i1 false)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t135, ptr %l70
  br label %bb36
bb36:
  %t136 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %l11
  %t137 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_81, 0
  %t138 = insertvalue { ptr, ptr } %t137, ptr null, 1
  %t141 = extractvalue { ptr, ptr } %t138, 0
  %t142 = extractvalue { ptr, ptr } %t138, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2eSort_3cco_Hab5ed93197c78b68858212b8060a2c8d(ptr %s0, ptr %s0, ptr %l11, ptr %t141, ptr %t142)
  br label %bb37
bb37:
  %t143 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t143, ptr %l73
  br label %bb38
bb38:
  %t144 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l73
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t144, ptr %l12
  %t145 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t145, ptr %l74
  br label %bb39
bb39:
  %t146 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t146, ptr %l13
  store ptr %l11, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s11
  %t148 = load i64, ptr %l15, !tbaa !24
  store i64 %t148, ptr %l76, !tbaa !24
  %t149 = load ptr, ptr %l14, !tbaa !29
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2eLen_3ccompiler_2fbuild_3aHeld_3e(ptr %s0, ptr %t149)
  store i64 %t151, ptr %l78
  br label %bb41
bb41:
  %t152 = load i64, ptr %l76, !tbaa !24
  %t153 = load i64, ptr %l78, !tbaa !24
  %t154 = icmp slt i64 %t152, %t153
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb43:
  br label %bb44
bb44:
  %t158 = load ptr, ptr %l14, !tbaa !29
  %t159 = load i64, ptr %l15, !tbaa !24
  %t162 = call %"compiler/build:Held" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2eAt_3ccompiler_2fbuild_3aHeld_3e(ptr %s0, ptr %s0, ptr %t158, i64 %t159)
  store %"compiler/build:Held" %t162, ptr %l83
  br label %bb45
bb45:
  %t163 = load %"compiler/build:Held", ptr %l83
  store %"compiler/build:Held" %t163, ptr %l16
  %t164 = getelementptr %"compiler/build:Held", ptr %l16, i32 0, i32 0
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  %t167 = call { i64, ptr } @compiler_2fbuild_2eStemOf(ptr %s0, ptr %s0, { i64, ptr } %t165, i64 1)
  store { i64, ptr } %t167, ptr %l85
  br label %bb46
bb46:
  %t168 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t168, ptr %l17, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t172 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %s0, ptr %s0, ptr %l12, { i64, ptr } %t169)
  %t173 = extractvalue { i32, i64 } %t172, 1
  %t174 = extractvalue { i32, i64 } %t172, 0
  store i32 %t174, ptr %l90
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb48, label %ok.176, !prof !99
ok.176:
  store i64 %t173, ptr %l89
  br label %bb47
bb47:
  %t177 = load i64, ptr %l89, !tbaa !24
  store i64 %t177, ptr %l86, !tbaa !24
  br label %bb50
bb48:
  br label %bb49
bb49:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb50
bb50:
  %t178 = load i64, ptr %l86, !tbaa !24
  %t179 = add i64 %t178, 1
  store i64 %t179, ptr %l18, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t182 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %s0, ptr %s0, ptr %l12, { i64, ptr } %t181, i64 %t182)
  br label %bb51
bb51:
  %t186 = load i64, ptr %l18, !tbaa !24
  %t190 = icmp sle i64 %t186, %a3
  br i1 %t190, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb55
bb53:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr %"compiler/build:Held", ptr %l16, i32 0, i32 0
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  %t197 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v1, ptr %s0, ptr %t192, { i64, ptr } %t194)
  store i1 %t197, ptr %l101
  br label %bb54
bb54:
  %t198 = load i1, ptr %l101, !tbaa !21
  store i1 %t198, ptr %l98, !tbaa !21
  br label %bb55
bb55:
  %t199 = load i1, ptr %l98, !tbaa !21
  br i1 %t199, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb58
bb57:
  %t200 = getelementptr %"compiler/build:Held", ptr %l16, i32 0, i32 3
  %t201 = load i64, ptr %t200, !tbaa !24
  %t202 = load i64, ptr %l2, !tbaa !24
  %t205 = icmp sge i64 %t201, %t202
  store i1 %t205, ptr %l102, !tbaa !21
  br label %bb58
bb58:
  %t207 = load i1, ptr %l102, !tbaa !21
  br i1 %t207, label %bb59, label %bb60
bb59:
  %t208 = load %"compiler/build:Held", ptr %l16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2ePush_3ccompiler_2fbuild_3aHeld_3e(ptr %s0, ptr %s0, ptr %l13, %"compiler/build:Held" %t208)
  br label %bb61
bb60:
  %t211 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t214 = call i1 @compiler_2fbuild_2eDrop(ptr %v0, ptr %s11, { i64, ptr } %t211, ptr %l16)
  store i1 %t214, ptr %l110
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb64
bb64:
  %t215 = load i64, ptr %l15, !tbaa !24
  %t218 = add i64 %t215, 1
  store i64 %t218, ptr %l15, !tbaa !24
  br label %bb40
bb65:
  %t220 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t222 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fbuild_2eTrim(ptr %v0, ptr %s0, ptr %v1, { i64, ptr } %t220, ptr %l13, ptr %t221, i64 %t222, i64 %a4)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2frecords_2eTrimRecords(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca { i64, ptr }
  %l40 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i64
  %l48 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l9, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t53, ptr %l37, !tbaa !27
  %t54 = load i64, ptr %l9, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %t57, i64 %t54
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !37
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s2, { i64, ptr } %t59, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t61, ptr %l40
  br label %bb12
bb12:
  %t62 = load i1, ptr %l40, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l3, ptr %l42, !tbaa !29
  %t65 = call ptr @__olang_scope_hold(ptr %s0)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l43, !tbaa !24
  %t67 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0
  br i1 %t67, label %bb15, label %bb16
bb14:
  br label %bb26
bb15:
  %t69 = call ptr @__olang_region_make(ptr %s0)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l43, !tbaa !24
  br label %bb16
bb16:
  %t73 = getelementptr %"compiler/load:Loader", ptr %a1, i32 0, i32 10
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t73, i64 %t74)
  store ptr %t77, ptr %l48
  br label %bb17
bb17:
  %t78 = load ptr, ptr %l48, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 2
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t83 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %s3, { i64, ptr } %t81)
  store { i64, ptr } %t83, ptr %l51
  br label %bb18
bb18:
  %t84 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t84, ptr %l52, !tbaa !27
  %t85 = load i64, ptr %l9, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %t88, i64 %t85
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !37
  store { i64, ptr } %t90, ptr %l54, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l55, !tbaa !24
  %t93 = icmp sge i64 0, 0
  br i1 %t93, label %bb19, label %bb20
bb19:
  %t95 = icmp sle i64 0, 20
  br i1 %t95, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_58cc7f1bdd3662ce_92747872ad267992)
  unreachable
bb21:
  %t97 = load i64, ptr %l55, !tbaa !24
  %t98 = icmp sle i64 20, %t97
  br i1 %t98, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_58cc7f1bdd3662ce_92747872ad267992)
  unreachable
bb23:
  %t100 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 0
  %t103 = sub i64 20, 0
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  %t106 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t113 = extractvalue { i64, ptr } %t105, 1
  %t114 = extractvalue { i64, ptr } %t105, 0
  %t115 = add i64 %t111, %t114
  %t116 = load i64, ptr %l43
  %t117 = inttoptr i64 %t116 to ptr
  %t118 = call ptr @__olang_held_alloc(ptr %t117, i64 %t115)
  call void @olang_textcopy(ptr %t118, ptr %t107, i64 %t108)
  %t119 = getelementptr i8, ptr %t118, i64 %t108
  call void @olang_textcopy(ptr %t119, ptr %t109, i64 %t110)
  %t120 = getelementptr i8, ptr %t119, i64 %t110
  call void @olang_textcopy(ptr %t120, ptr %t113, i64 %t114)
  %t121 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t118, 1
  %t124 = load ptr, ptr %l42, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %s0, ptr %t124, { i64, ptr } %t122, i1 true)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_58cc7f1bdd3662ce_92747872ad267992)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = add i64 %t126, 1
  store i64 %t129, ptr %l8, !tbaa !24
  br label %bb8
bb28:
  %t133 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 1
  %t137 = extractvalue { i64, ptr } %t134, 0
  %t138 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t136, i64 %t137)
  %t142 = getelementptr i8, ptr %t141, i64 %t137
  call void @olang_textcopy(ptr %t142, ptr %t138, i64 %t139)
  %t143 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t141, 1
  store { i64, ptr } %t144, ptr %l68, !tbaa !27
  store ptr %l3, ptr %l69, !tbaa !29
  %t146 = call i64 @compiler_2fbuild_2eRecent()
  store i64 %t146, ptr %l70
  br label %bb29
bb29:
  %t147 = load i64, ptr @G_2ecompiler_2frecords_2eRecKeys, !tbaa !24
  %t148 = load i64, ptr @G_2ecompiler_2frecords_2eRecCap, !tbaa !24
  %t149 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t150 = load ptr, ptr %l69, !tbaa !29
  %t151 = load i64, ptr %l70, !tbaa !24
  call void @compiler_2frecords_2eTrimRecordDir(ptr %s0, ptr %s0, { i64, ptr } %t149, ptr %t150, i64 %t151, i64 %t147, i64 %t148)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2frecords_2echeckOthers(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca i64
  %l50 = alloca ptr
  %l54 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i32
  %l62 = alloca %"compiler/views:Cand"
  %l64 = alloca %"compiler/views:Cand"
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l67 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i1
  %l88 = alloca i64
  %l90 = alloca i64
  %l95 = alloca { i64, ptr }
  %l99 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i64
  %l108 = alloca ptr
  %l118 = alloca i64
  %l120 = alloca i64
  %l125 = alloca { i64, ptr }
  %l129 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i64
  %l138 = alloca ptr
  %l152 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 10
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l23
  br label %bb1
bb1:
  %t6 = load i64, ptr %l23, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l30, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l30, !tbaa !24
  store i64 %t33, ptr %l27, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l27, !tbaa !24
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb65
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l9, !tbaa !24
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/views:Kept", ptr %t53, i32 0, i32 5
  store ptr %t55, ptr %l50, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/load:Loader", ptr %t56, i32 0, i32 10
  %t59 = load i64, ptr %l9, !tbaa !24
  %t62 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t58, i64 %t59)
  store ptr %t62, ptr %l54
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l54, !tbaa !29
  %t65 = getelementptr %"compiler/load:Module", ptr %t63, i32 0, i32 4
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load ptr, ptr %l50, !tbaa !29
  %t69 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v2, ptr %t67, i64 %t66)
  %t70 = extractvalue { i32, i64 } %t69, 1
  %t71 = extractvalue { i32, i64 } %t69, 0
  store i32 %t71, ptr %l58
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb14, label %ok.73, !prof !99
ok.73:
  store i64 %t70, ptr %l57
  br label %bb13
bb13:
  %t74 = load i64, ptr %l57, !tbaa !24
  store i64 %t74, ptr %l48, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb16:
  %t75 = load i64, ptr %l48, !tbaa !24
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/views:Kept", ptr %t76, i32 0, i32 0
  %t82 = call %"compiler/views:Cand" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aCand_3e_2eAt_3ccompiler_2fviews_3aCand_3e(ptr %v2, ptr %v2, ptr %t78, i64 %t75)
  store %"compiler/views:Cand" %t82, ptr %l62
  br label %bb17
bb17:
  %t84 = call %"compiler/views:Cand" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fviews_3aCand(ptr %s2, ptr %l62)
  store %"compiler/views:Cand" %t84, ptr %l64
  br label %bb18
bb18:
  %t85 = getelementptr %"compiler/views:Cand", ptr %l64, i32 0, i32 3
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l66
  %t88 = call ptr @__olang_scope_hold(ptr %s2)
  %t89 = ptrtoint ptr %t88 to i64
  store i64 %t89, ptr %l67, !tbaa !24
  %t90 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = call ptr @__olang_region_make_part(ptr %s2)
  %t93 = ptrtoint ptr %t92 to i64
  store i64 %t93, ptr %l67, !tbaa !24
  br label %bb20
bb20:
  %t94 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66, i32 0, i32 0
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l69, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l70, !tbaa !24
  %t98 = load i64, ptr %l70, !tbaa !24
  %t99 = mul i64 %t98, 16
  %t100 = load i64, ptr %l67
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = call ptr @__olang_held_alloc(ptr %t101, i64 %t99)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l71, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l70, !tbaa !24
  %t110 = mul i64 %t109, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  %t111 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t112 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66, i32 0, i32 0
  store { i64, ptr } %t111, ptr %t112, !tbaa !27
  %t113 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t113, label %bb21, label %bb22
bb21:
  %t115 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  %t119 = icmp eq i64 %t117, 0
  br i1 %t119, label %bb23, label %bb24
bb22:
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l11
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i64, ptr %l9, !tbaa !24
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2frecords_2eothers(ptr %v0, ptr %v1, ptr %v3, ptr %s2, ptr %t122, ptr %a1, i64 %t124, ptr %a3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l79
  br label %bb25
bb23:
  %t131 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t131, !tbaa !27
  br label %bb24
bb24:
  %t132 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66, i32 0, i32 0
  %t133 = load i64, ptr %l67
  %t134 = inttoptr i64 %t133 to ptr
  %t135 = load { i64, ptr }, ptr %t132
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = call ptr @__olang_region_or(ptr %t136, ptr null)
  %t138 = icmp ne ptr %t137, null
  %t139 = select i1 %t138, ptr %t137, ptr null
  call void @__olang_region_settle_in(ptr %t134, ptr %t139)
  br label %bb22
bb25:
  %t140 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %l12
  %t142 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v2, ptr %s2, ptr %s2, ptr %l11, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) })
  store { i64, ptr } %t142, ptr %l81
  br label %bb26
bb26:
  %t143 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t143, ptr %l82, !tbaa !27
  %t145 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s2, ptr %s2, ptr %s2, ptr %l12, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store { i64, ptr } %t145, ptr %l84
  br label %bb27
bb27:
  %t146 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t149 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t147, { i64, ptr } %t146)
  store i1 %t149, ptr %l86
  br label %bb28
bb28:
  %t150 = load i1, ptr %l86, !tbaa !21
  br i1 %t150, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb30:
  br label %bb31
bb31:
  store ptr %l12, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb32
bb32:
  %t152 = load i64, ptr %l14, !tbaa !24
  store i64 %t152, ptr %l88, !tbaa !24
  %t153 = load ptr, ptr %l13, !tbaa !29
  %t155 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %t153)
  store i64 %t155, ptr %l90
  br label %bb33
bb33:
  %t156 = load i64, ptr %l88, !tbaa !24
  %t157 = load i64, ptr %l90, !tbaa !24
  %t158 = icmp slt i64 %t156, %t157
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb34, label %bb35
bb34:
  br label %bb47
bb35:
  br label %bb36
bb36:
  %t162 = load ptr, ptr %l13, !tbaa !29
  %t163 = load i64, ptr %l14, !tbaa !24
  %t166 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %t162, i64 %t163)
  store { i64, ptr } %t166, ptr %l95
  br label %bb37
bb37:
  %t167 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t167, ptr %l15, !tbaa !27
  %t168 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t173 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v2, ptr %s2, ptr %l11, { i64, ptr } %t168)
  store i1 %t173, ptr %l99
  br label %bb38
bb38:
  %t174 = load i1, ptr %l99, !tbaa !21
  %t175 = xor i1 %t174, true
  br i1 %t175, label %bb39, label %bb40
bb39:
  %t177 = load ptr, ptr %l2, !tbaa !29
  %t179 = getelementptr %"compiler/views:Kept", ptr %t177, i32 0, i32 6
  store ptr %t179, ptr %l102, !tbaa !29
  %t180 = call ptr @__olang_scope_hold(ptr %v2)
  %t181 = ptrtoint ptr %t180 to i64
  store i64 %t181, ptr %l103, !tbaa !24
  %t182 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t182, label %bb41, label %bb42
bb40:
  br label %bb45
bb41:
  %t184 = call ptr @__olang_region_make(ptr %v2)
  %t185 = ptrtoint ptr %t184 to i64
  store i64 %t185, ptr %l103, !tbaa !24
  br label %bb42
bb42:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/load:Loader", ptr %t186, i32 0, i32 10
  %t189 = load i64, ptr %l9, !tbaa !24
  %t192 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t188, i64 %t189)
  store ptr %t192, ptr %l108
  br label %bb43
bb43:
  %t193 = load ptr, ptr %l108, !tbaa !29
  %t195 = getelementptr %"compiler/load:Module", ptr %t193, i32 0, i32 2
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t196, 1
  %t200 = extractvalue { i64, ptr } %t196, 0
  %t201 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t203 = add i64 %t200, %t202
  %t205 = extractvalue { i64, ptr } %t197, 1
  %t206 = extractvalue { i64, ptr } %t197, 0
  %t207 = add i64 %t203, %t206
  %t208 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t210 = add i64 %t207, %t209
  %t211 = load i64, ptr %l103
  %t212 = inttoptr i64 %t211 to ptr
  %t213 = call ptr @__olang_held_alloc(ptr %t212, i64 %t210)
  call void @olang_textcopy(ptr %t213, ptr %t199, i64 %t200)
  %t214 = getelementptr i8, ptr %t213, i64 %t200
  call void @olang_textcopy(ptr %t214, ptr %t201, i64 %t202)
  %t215 = getelementptr i8, ptr %t214, i64 %t202
  call void @olang_textcopy(ptr %t215, ptr %t205, i64 %t206)
  %t216 = getelementptr i8, ptr %t215, i64 %t206
  call void @olang_textcopy(ptr %t216, ptr %t208, i64 %t209)
  %t217 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t213, 1
  %t220 = load ptr, ptr %l102, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t220, { i64, ptr } %t218)
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t222 = load i64, ptr %l14, !tbaa !24
  %t225 = add i64 %t222, 1
  store i64 %t225, ptr %l14, !tbaa !24
  br label %bb32
bb47:
  store ptr %l11, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb48
bb48:
  %t228 = load i64, ptr %l18, !tbaa !24
  store i64 %t228, ptr %l118, !tbaa !24
  %t229 = load ptr, ptr %l17, !tbaa !29
  %t231 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t229)
  store i64 %t231, ptr %l120
  br label %bb49
bb49:
  %t232 = load i64, ptr %l118, !tbaa !24
  %t233 = load i64, ptr %l120, !tbaa !24
  %t234 = icmp slt i64 %t232, %t233
  %t236 = xor i1 %t234, true
  br i1 %t236, label %bb50, label %bb51
bb50:
  br label %bb63
bb51:
  br label %bb52
bb52:
  %t238 = load ptr, ptr %l17, !tbaa !29
  %t239 = load i64, ptr %l18, !tbaa !24
  %t242 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t238, i64 %t239)
  store { i64, ptr } %t242, ptr %l125
  br label %bb53
bb53:
  %t243 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t243, ptr %l19, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t249 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %s2, ptr %v2, ptr %l12, { i64, ptr } %t244)
  store i1 %t249, ptr %l129
  br label %bb54
bb54:
  %t250 = load i1, ptr %l129, !tbaa !21
  %t251 = xor i1 %t250, true
  br i1 %t251, label %bb55, label %bb56
bb55:
  %t253 = load ptr, ptr %l2, !tbaa !29
  %t255 = getelementptr %"compiler/views:Kept", ptr %t253, i32 0, i32 6
  store ptr %t255, ptr %l132, !tbaa !29
  %t256 = call ptr @__olang_scope_hold(ptr %v2)
  %t257 = ptrtoint ptr %t256 to i64
  store i64 %t257, ptr %l133, !tbaa !24
  %t258 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t258, label %bb57, label %bb58
bb56:
  br label %bb61
bb57:
  %t260 = call ptr @__olang_region_make(ptr %v2)
  %t261 = ptrtoint ptr %t260 to i64
  store i64 %t261, ptr %l133, !tbaa !24
  br label %bb58
bb58:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/load:Loader", ptr %t262, i32 0, i32 10
  %t265 = load i64, ptr %l9, !tbaa !24
  %t268 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t264, i64 %t265)
  store ptr %t268, ptr %l138
  br label %bb59
bb59:
  %t269 = load ptr, ptr %l138, !tbaa !29
  %t271 = getelementptr %"compiler/load:Module", ptr %t269, i32 0, i32 2
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  %t273 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t272, 1
  %t276 = extractvalue { i64, ptr } %t272, 0
  %t277 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t279 = add i64 %t276, %t278
  %t281 = extractvalue { i64, ptr } %t273, 1
  %t282 = extractvalue { i64, ptr } %t273, 0
  %t283 = add i64 %t279, %t282
  %t284 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t285 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t286 = add i64 %t283, %t285
  %t287 = load i64, ptr %l133
  %t288 = inttoptr i64 %t287 to ptr
  %t289 = call ptr @__olang_held_alloc(ptr %t288, i64 %t286)
  call void @olang_textcopy(ptr %t289, ptr %t275, i64 %t276)
  %t290 = getelementptr i8, ptr %t289, i64 %t276
  call void @olang_textcopy(ptr %t290, ptr %t277, i64 %t278)
  %t291 = getelementptr i8, ptr %t290, i64 %t278
  call void @olang_textcopy(ptr %t291, ptr %t281, i64 %t282)
  %t292 = getelementptr i8, ptr %t291, i64 %t282
  call void @olang_textcopy(ptr %t292, ptr %t284, i64 %t285)
  %t293 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t289, 1
  %t296 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t296, { i64, ptr } %t294)
  br label %bb60
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t298 = load i64, ptr %l18, !tbaa !24
  %t301 = add i64 %t298, 1
  store i64 %t301, ptr %l18, !tbaa !24
  br label %bb48
bb63:
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb64:
  %t303 = load i64, ptr %l8, !tbaa !24
  %t306 = add i64 %t303, 1
  store i64 %t306, ptr %l8, !tbaa !24
  br label %bb8
bb65:
  %t308 = load ptr, ptr %l2, !tbaa !29
  %t310 = getelementptr %"compiler/views:Kept", ptr %t308, i32 0, i32 6
  %t312 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t310)
  store i64 %t312, ptr %l152
  br label %bb66
bb66:
  %t313 = load i64, ptr %l152, !tbaa !24
  %t314 = icmp sgt i64 %t313, 0
  br i1 %t314, label %bb67, label %bb68
bb67:
  %t316 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2frecords_2eCheckIncrFailed(ptr %v2, ptr %t316)
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb70
bb70:
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/views:Cand" } @compiler_2frecords_2efrontRecord(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l27 = alloca { i64, ptr }
  %l29 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l47 = alloca { i64, ptr }
  %l49 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l59 = alloca %"std/prelude/text:LineIter"
  %l61 = alloca ptr
  %l63 = alloca i64
  %l65 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l73 = alloca i64
  %l75 = alloca { i64, ptr }
  %l76 = alloca i1
  %l80 = alloca %"compiler/views:Cand"
  %l82 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l110 = alloca { i64, ptr }
  %l112 = alloca i1
  %l116 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i64
  %l120 = alloca { i64, ptr }
  %l123 = alloca i64
  %l124 = alloca i64
  %l132 = alloca i1
  %l133 = alloca i1
  %l135 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/views:Cand" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l16
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l15
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t8, ptr %l13, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l16, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l18, !tbaa !21
  %t13 = load i32, ptr %l16, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t19 = insertvalue { i32, %"compiler/views:Cand" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/views:Cand" } %t19, ptr %rv
  br label %ret
bb6:
  %t20 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d91, i32 0, i32 1) })
  %t24 = extractvalue { i32, i64 } %t23, 1
  %t25 = extractvalue { i32, i64 } %t23, 0
  store i32 %t25, ptr %l25
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb8, label %ok.27, !prof !99
ok.27:
  store i64 %t24, ptr %l24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l24, !tbaa !24
  store i64 %t28, ptr %l22, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t30 = insertvalue { i32, %"compiler/views:Cand" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/views:Cand" } %t30, ptr %rv
  br label %ret
bb10:
  %t31 = load i64, ptr %l22, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l27, !tbaa !27
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 5
  store i64 %t35, ptr %l29, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t36, 0
  store i64 %t39, ptr %l32, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l33, !tbaa !24
  %t42 = load i64, ptr %l29, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load i64, ptr %l29, !tbaa !24
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_74134b5dcc105c42_96a34be2631e3c86)
  unreachable
bb13:
  %t49 = load i64, ptr %l32, !tbaa !24
  %t50 = load i64, ptr %l33, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_74134b5dcc105c42_96a34be2631e3c86)
  unreachable
bb15:
  %t53 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l29, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = getelementptr i8, ptr %t54, i64 %t55
  %t58 = sub i64 %t56, %t55
  %t59 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t57, 1
  %t62 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, ptr %s0, { i64, ptr } %t60)
  store { i64, ptr } %t62, ptr %l38
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_74134b5dcc105c42_96a34be2631e3c86)
  unreachable
bb17:
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t63, ptr %l39, !tbaa !27
  %t64 = load i64, ptr %l3, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l41, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l42, !tbaa !24
  %t69 = icmp sge i64 0, 0
  br i1 %t69, label %bb18, label %bb19
bb18:
  %t71 = load i64, ptr %l41, !tbaa !24
  %t72 = icmp sle i64 0, %t71
  br i1 %t72, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_74134b5dcc105c42_96a34be2631e3c86)
  unreachable
bb20:
  %t74 = load i64, ptr %l41, !tbaa !24
  %t75 = load i64, ptr %l42, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_74134b5dcc105c42_96a34be2631e3c86)
  unreachable
bb22:
  %t78 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l41, !tbaa !24
  %t81 = getelementptr i8, ptr %t79, i64 0
  %t82 = sub i64 %t80, 0
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t86 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v1, ptr %s0, { i64, ptr } %t84)
  store { i64, ptr } %t86, ptr %l47
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_74134b5dcc105c42_96a34be2631e3c86)
  unreachable
bb24:
  %t87 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t88, { i64, ptr } %t87)
  store i1 %t90, ptr %l49
  br label %bb25
bb25:
  %t91 = load i1, ptr %l49, !tbaa !21
  %t92 = xor i1 %t91, true
  br i1 %t92, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t95 = insertvalue { i32, %"compiler/views:Cand" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/views:Cand" } %t95, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t96, ptr %l52, !tbaa !27
  %t97 = load i64, ptr %l3, !tbaa !24
  store i64 %t97, ptr %l53, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l54, !tbaa !24
  %t100 = icmp sge i64 0, 0
  br i1 %t100, label %bb29, label %bb30
bb29:
  %t102 = load i64, ptr %l53, !tbaa !24
  %t103 = icmp sle i64 0, %t102
  br i1 %t103, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_9fb4ac3de319e3f_96fac2b32e45e763)
  unreachable
bb31:
  %t105 = load i64, ptr %l53, !tbaa !24
  %t106 = load i64, ptr %l54, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  br i1 %t107, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_9fb4ac3de319e3f_96fac2b32e45e763)
  unreachable
bb33:
  %t109 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = getelementptr i8, ptr %t110, i64 0
  %t113 = sub i64 %t111, 0
  %t114 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t112, 1
  %t117 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t115)
  store %"std/prelude/text:LineIter" %t117, ptr %l59
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_9fb4ac3de319e3f_96fac2b32e45e763)
  unreachable
bb35:
  %t118 = load %"std/prelude/text:LineIter", ptr %l59
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"std/prelude/text:LineIter" %t118, ptr %t119
  %t121 = call ptr @std_2fprelude_2fiterator_2estd_2fprelude_2ftext_3aLineIter_2eToVec_3cstd_2fprelude_2ftex_H26ca3914517df8db224f03300752057f(ptr %v1, ptr %v1, ptr %t119)
  store ptr %t121, ptr %l61
  br label %bb36
bb36:
  %t122 = load ptr, ptr %l61, !tbaa !29
  store ptr %t122, ptr %l4, !tbaa !29
  %t123 = load ptr, ptr %l4, !tbaa !29
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t123)
  store i64 %t125, ptr %l63
  br label %bb37
bb37:
  %t126 = load i64, ptr %l63, !tbaa !24
  %t127 = icmp slt i64 %t126, 2
  br i1 %t127, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb42
bb39:
  %t129 = load ptr, ptr %l4, !tbaa !29
  %t131 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t129, i64 0)
  store { i64, ptr } %t131, ptr %l67
  br label %bb40
bb40:
  %t132 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t133 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t132, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t133, ptr %l68
  br label %bb41
bb41:
  %t134 = load i1, ptr %l68, !tbaa !21
  %t135 = xor i1 %t134, true
  store i1 %t135, ptr %l65, !tbaa !21
  br label %bb42
bb42:
  %t137 = load i1, ptr %l65, !tbaa !21
  br i1 %t137, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb48
bb44:
  %t138 = load ptr, ptr %l4, !tbaa !29
  store ptr %t138, ptr %l71, !tbaa !29
  %t139 = load ptr, ptr %l4, !tbaa !29
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t139)
  store i64 %t141, ptr %l73
  br label %bb45
bb45:
  %t142 = load i64, ptr %l73, !tbaa !24
  %t143 = sub i64 %t142, 1
  %t144 = load ptr, ptr %l71, !tbaa !29
  %t146 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t144, i64 %t143)
  store { i64, ptr } %t146, ptr %l75
  br label %bb46
bb46:
  %t147 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t147, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t148, ptr %l76
  br label %bb47
bb47:
  %t149 = load i1, ptr %l76, !tbaa !21
  %t150 = xor i1 %t149, true
  store i1 %t150, ptr %l70, !tbaa !21
  br label %bb48
bb48:
  %t152 = load i1, ptr %l70, !tbaa !21
  br i1 %t152, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t154 = insertvalue { i32, %"compiler/views:Cand" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/views:Cand" } %t154, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t157 = call %"compiler/views:Cand" @compiler_2fviews_3aCand_2ector(ptr %v1, i64 %a1)
  store %"compiler/views:Cand" %t157, ptr %l80
  br label %bb52
bb52:
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 104, i64 8)
  store ptr %t158, ptr %lp5
  %t159 = load %"compiler/views:Cand", ptr %l80
  %t160 = load ptr, ptr %lp5
  store %"compiler/views:Cand" %t159, ptr %t160
  store i64 1, ptr %l6, !tbaa !24
  %t161 = load ptr, ptr %l4, !tbaa !29
  %t163 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t161)
  store i64 %t163, ptr %l82
  br label %bb53
bb53:
  %t164 = load i64, ptr %l82, !tbaa !24
  %t165 = sub i64 %t164, 1
  store i64 %t165, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t167 = load i64, ptr %l7, !tbaa !24
  %t168 = load i64, ptr %l6, !tbaa !24
  %t171 = icmp sgt i64 %t167, %t168
  br i1 %t171, label %bb54, label %bb55
bb54:
  %t173 = load i64, ptr %l8, !tbaa !24
  %t175 = icmp sgt i64 %t173, 0
  br i1 %t175, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb59
bb56:
  %t177 = load i64, ptr %l7, !tbaa !24
  %t178 = load i64, ptr %l6, !tbaa !24
  %t181 = sub i64 %t177, %t178
  %t182 = load i64, ptr %l8, !tbaa !24
  %t185 = add i64 %t181, %t182
  %t187 = sub i64 %t185, 1
  %t188 = load i64, ptr %l8, !tbaa !24
  %t191 = sdiv i64 %t187, %t188
  store i64 %t191, ptr %l90, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb58
bb58:
  %t193 = load i64, ptr %l90, !tbaa !24
  store i64 %t193, ptr %l87, !tbaa !24
  br label %bb59
bb59:
  %t194 = load i64, ptr %l87, !tbaa !24
  store i64 %t194, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t195 = load i64, ptr %l10, !tbaa !24
  %t196 = load i64, ptr %l9, !tbaa !24
  %t199 = icmp slt i64 %t195, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s6)
  br label %bb93
bb62:
  br label %bb63
bb63:
  %t203 = load i64, ptr %l6, !tbaa !24
  %t204 = load i64, ptr %l10, !tbaa !24
  %t205 = load i64, ptr %l8, !tbaa !24
  %t208 = mul i64 %t204, %t205
  %t211 = add i64 %t203, %t208
  %t213 = load ptr, ptr %l4, !tbaa !29
  %t217 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t213, i64 %t211)
  store { i64, ptr } %t217, ptr %l110
  br label %bb64
bb64:
  %t218 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t218, ptr %l12, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t221 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s6, { i64, ptr } %t219, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d94, i32 0, i32 1) })
  store i1 %t221, ptr %l112
  br label %bb65
bb65:
  %t222 = load i1, ptr %l112, !tbaa !21
  br i1 %t222, label %bb66, label %bb67
bb66:
  %t223 = load ptr, ptr %lp5
  %t224 = getelementptr %"compiler/views:Cand", ptr %t223, i32 0, i32 1
  %t225 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t224, { i64, ptr } %t225)
  br label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s8
  %t228 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t230 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s8, { i64, ptr } %t228, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d95, i32 0, i32 1) })
  store i1 %t230, ptr %l116
  br label %bb69
bb68:
  br label %bb91
bb69:
  %t231 = load i1, ptr %l116, !tbaa !21
  br i1 %t231, label %bb70, label %bb71
bb70:
  %t232 = load ptr, ptr %lp5
  %t233 = getelementptr %"compiler/views:Cand", ptr %t232, i32 0, i32 2
  store ptr %t233, ptr %l117, !tbaa !29
  %t234 = call ptr @__olang_scope_hold(ptr %v1)
  %t235 = ptrtoint ptr %t234 to i64
  store i64 %t235, ptr %l118, !tbaa !24
  %t236 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t236, label %bb72, label %bb73
bb71:
  store %olang.scope zeroinitializer, ptr %s11
  %t238 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t240 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s11, { i64, ptr } %t238, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t240, ptr %l132
  br label %bb81
bb72:
  %t241 = call ptr @__olang_region_make(ptr %v1)
  %t242 = ptrtoint ptr %t241 to i64
  store i64 %t242, ptr %l118, !tbaa !24
  br label %bb73
bb73:
  %t243 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t243, ptr %l120, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t244, 0
  store i64 %t247, ptr %l123, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t248, 0
  store i64 %t249, ptr %l124, !tbaa !24
  %t250 = icmp sge i64 5, 0
  br i1 %t250, label %bb74, label %bb75
bb74:
  %t252 = load i64, ptr %l123, !tbaa !24
  %t253 = icmp sle i64 5, %t252
  br i1 %t253, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_d6e69897ddbacd4_85b5c87fc3d2b148)
  unreachable
bb76:
  %t255 = load i64, ptr %l123, !tbaa !24
  %t256 = load i64, ptr %l124, !tbaa !24
  %t257 = icmp sle i64 %t255, %t256
  br i1 %t257, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_d6e69897ddbacd4_85b5c87fc3d2b148)
  unreachable
bb78:
  %t259 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = load i64, ptr %l123, !tbaa !24
  %t262 = getelementptr i8, ptr %t260, i64 5
  %t263 = sub i64 %t261, 5
  %t264 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t262, 1
  %t267 = extractvalue { i64, ptr } %t265, 1
  %t268 = extractvalue { i64, ptr } %t265, 0
  %t269 = load i64, ptr %l118
  %t270 = inttoptr i64 %t269 to ptr
  %t271 = call ptr @__olang_held_alloc(ptr %t270, i64 %t268)
  call void @olang_textcopy(ptr %t271, ptr %t267, i64 %t268)
  %t272 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  %t275 = load ptr, ptr %l117, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t275, { i64, ptr } %t273)
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_d6e69897ddbacd4_85b5c87fc3d2b148)
  unreachable
bb80:
  br label %bb90
bb81:
  %t277 = load i1, ptr %l132, !tbaa !21
  br i1 %t277, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l133, !tbaa !21
  br label %bb85
bb83:
  %t278 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t280 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s11, { i64, ptr } %t278, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store i1 %t280, ptr %l135
  br label %bb84
bb84:
  %t281 = load i1, ptr %l135, !tbaa !21
  store i1 %t281, ptr %l133, !tbaa !21
  br label %bb85
bb85:
  %t282 = load i1, ptr %l133, !tbaa !21
  br i1 %t282, label %bb86, label %bb87
bb86:
  %t283 = load ptr, ptr %lp5
  %t284 = getelementptr %"compiler/views:Cand", ptr %t283, i32 0, i32 3
  %t285 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t284, { i64, ptr } %t285)
  br label %bb88
bb87:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t289 = insertvalue { i32, %"compiler/views:Cand" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/views:Cand" } %t289, ptr %rv
  br label %ret
bb88:
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s11)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s8)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s6)
  br label %bb92
bb92:
  %t290 = load i64, ptr %l10, !tbaa !24
  %t293 = add i64 %t290, 1
  store i64 %t293, ptr %l10, !tbaa !24
  br label %bb60
bb93:
  %t295 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @compiler_2fbuild_2eTouch(ptr %v0, { i64, ptr } %t295)
  br label %bb94
bb94:
  %t297 = load ptr, ptr %lp5
  %t298 = load %"compiler/views:Cand", ptr %t297
  call void @__olang_scope_close(ptr %s0)
  %t300 = insertvalue { i32, %"compiler/views:Cand" } zeroinitializer, %"compiler/views:Cand" %t298, 1
  store { i32, %"compiler/views:Cand" } %t300, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/views:Cand" }, ptr %rv
  ret { i32, %"compiler/views:Cand" } %rr
}

define dso_local { i64, ptr } @compiler_2frecords_2ehexByte(ptr %v0, i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l6 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %rv = alloca { i64, ptr }
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l2, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t3 = load i8, ptr %l0, !tbaa !22
  %t5 = lshr i8 %t3, 4
  %t7 = zext i8 %t5 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load i8, ptr %l0, !tbaa !22
  %t10 = lshr i8 %t8, 4
  %t12 = zext i8 %t10 to i64
  %t14 = add i64 %t12, 1
  store i64 %t14, ptr %l10, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = icmp sge i64 %t17, 0
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l10, !tbaa !24
  %t22 = icmp sle i64 %t20, %t21
  br i1 %t22, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_2727131baf418fd5_a166bfe6a37b2109)
  unreachable
bb3:
  %t24 = load i64, ptr %l10, !tbaa !24
  %t25 = load i64, ptr %l11, !tbaa !24
  %t26 = icmp sle i64 %t24, %t25
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_2727131baf418fd5_a166bfe6a37b2109)
  unreachable
bb5:
  %t28 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l10, !tbaa !24
  %t32 = getelementptr i8, ptr %t29, i64 %t30
  %t33 = sub i64 %t31, %t30
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  store { i64, ptr } %t35, ptr %l15, !tbaa !27
  %t36 = load i8, ptr %l0, !tbaa !22
  %t38 = and i8 %t36, 15
  %t40 = zext i8 %t38 to i64
  store i64 %t40, ptr %l18, !tbaa !24
  %t41 = load i8, ptr %l0, !tbaa !22
  %t43 = and i8 %t41, 15
  %t45 = zext i8 %t43 to i64
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l22, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l23, !tbaa !24
  %t50 = load i64, ptr %l18, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_2727131baf418fd5_a166bfe6a37b2109)
  unreachable
bb7:
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = load i64, ptr %l22, !tbaa !24
  %t55 = icmp sle i64 %t53, %t54
  br i1 %t55, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_2727131baf418fd5_a166bfe6a37b2109)
  unreachable
bb9:
  %t57 = load i64, ptr %l22, !tbaa !24
  %t58 = load i64, ptr %l23, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_2727131baf418fd5_a166bfe6a37b2109)
  unreachable
bb11:
  %t61 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l18, !tbaa !24
  %t64 = load i64, ptr %l22, !tbaa !24
  %t65 = getelementptr i8, ptr %t62, i64 %t63
  %t66 = sub i64 %t64, %t63
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t69 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t73 = extractvalue { i64, ptr } %t68, 1
  %t74 = extractvalue { i64, ptr } %t68, 0
  %t75 = add i64 %t71, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t70, i64 %t71)
  %t77 = getelementptr i8, ptr %t76, i64 %t71
  call void @olang_textcopy(ptr %t77, ptr %t73, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t76, 1
  store { i64, ptr } %t79, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_2727131baf418fd5_a166bfe6a37b2109)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2frecords_2eimageText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/eval:Blob"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca i64
  %l20 = alloca i64
  %l25 = alloca %"compiler/eval:Blob"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l33 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i8
  %l41 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l49 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i64
  %l74 = alloca ptr
  %l77 = alloca i64
  %l80 = alloca i64
  %l83 = alloca i64
  %l88 = alloca i64
  %l90 = alloca i1
  %l91 = alloca i64
  %l93 = alloca i64
  %l95 = alloca i1
  %l98 = alloca i64
  %l100 = alloca ptr
  %l102 = alloca ptr
  %l105 = alloca i64
  %l106 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca i32
  %l114 = alloca { i64, ptr }
  %l117 = alloca i64
  %l131 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t19 = alloca %"compiler/eval:Blob", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l15
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/eval:Image", ptr %t3, i32 0, i32 0
  store ptr %t5, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l18, !tbaa !24
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l20
  br label %bb3
bb3:
  %t11 = load i64, ptr %l18, !tbaa !24
  %t12 = load i64, ptr %l20, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %t19, ptr %v1, ptr %v1, ptr %t17, i64 %t18)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t19, i64 272, i1 false)
  br label %bb7
bb7:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l25, i64 272, i1 false)
  store ptr %l2, ptr %l26, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l27, !tbaa !24
  %t24 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 2
  %t25 = load i1, ptr %t24, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l29, !tbaa !27
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d100, i32 0, i32 1) }, ptr %l29, !tbaa !27
  br label %bb10
bb10:
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t29 = load i64, ptr %l27, !tbaa !24
  %t30 = call i64 @__olang_fmt_i64(ptr null, i64 %t29)
  %t31 = add i64 %t28, %t30
  %t32 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t27, i64 %t28)
  %t40 = getelementptr i8, ptr %t39, i64 %t28
  %t41 = call i64 @__olang_fmt_i64(ptr %t40, i64 %t29)
  %t42 = getelementptr i8, ptr %t40, i64 %t30
  call void @olang_textcopy(ptr %t42, ptr %t33, i64 %t34)
  %t43 = getelementptr i8, ptr %t42, i64 %t34
  call void @olang_textcopy(ptr %t43, ptr %t36, i64 %t37)
  %t44 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t39, 1
  %t47 = load ptr, ptr %l26, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t47, { i64, ptr } %t45)
  br label %bb11
bb11:
  %t49 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 0
  store ptr %t49, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t51 = load i64, ptr %l7, !tbaa !24
  store i64 %t51, ptr %l33, !tbaa !24
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %s2, ptr %t52)
  store i64 %t54, ptr %l35
  br label %bb13
bb13:
  %t55 = load i64, ptr %l33, !tbaa !24
  %t56 = load i64, ptr %l35, !tbaa !24
  %t57 = icmp slt i64 %t55, %t56
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t61 = load ptr, ptr %l6, !tbaa !29
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %s2, ptr %t61, i64 %t62)
  store i8 %t65, ptr %l40
  br label %bb17
bb17:
  %t66 = load i8, ptr %l40, !tbaa !22
  store ptr %l2, ptr %l41, !tbaa !29
  %t69 = call { i64, ptr } @compiler_2frecords_2ehexByte(ptr %s5, i8 %t66)
  store { i64, ptr } %t69, ptr %l43
  br label %bb18
bb18:
  %t70 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t71 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t71, { i64, ptr } %t70)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l7, !tbaa !24
  br label %bb12
bb21:
  store i64 0, ptr %l9, !tbaa !24
  %t78 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 3
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t78)
  store i64 %t80, ptr %l49
  br label %bb22
bb22:
  %t81 = load i64, ptr %l49, !tbaa !24
  store i64 %t81, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t88 = load i64, ptr %l11, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb28
bb25:
  %t92 = load i64, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l11, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l56, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb27
bb27:
  %t108 = load i64, ptr %l56, !tbaa !24
  store i64 %t108, ptr %l53, !tbaa !24
  br label %bb28
bb28:
  %t109 = load i64, ptr %l53, !tbaa !24
  store i64 %t109, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  %t110 = load i64, ptr %l13, !tbaa !24
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb31:
  br label %bb32
bb32:
  %t118 = load i64, ptr %l9, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l11, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  store i64 %t126, ptr %l14, !tbaa !24
  store ptr %l2, ptr %l74, !tbaa !29
  %t128 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 3
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t128, i64 %t129)
  store i64 %t132, ptr %l77
  br label %bb33
bb33:
  %t133 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 4
  %t134 = load i64, ptr %l14, !tbaa !24
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t133, i64 %t134)
  store i64 %t137, ptr %l80
  br label %bb34
bb34:
  %t138 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 5
  %t139 = load i64, ptr %l14, !tbaa !24
  %t142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t138, i64 %t139)
  store i64 %t142, ptr %l83
  br label %bb35
bb35:
  %t143 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t145 = load i64, ptr %l77, !tbaa !24
  %t146 = call i64 @__olang_fmt_i64(ptr null, i64 %t145)
  %t147 = add i64 %t144, %t146
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t151 = load i64, ptr %l80, !tbaa !24
  %t152 = call i64 @__olang_fmt_i64(ptr null, i64 %t151)
  %t153 = add i64 %t150, %t152
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t157 = load i64, ptr %l83, !tbaa !24
  %t158 = call i64 @__olang_fmt_i64(ptr null, i64 %t157)
  %t159 = add i64 %t156, %t158
  %t160 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t159)
  call void @olang_textcopy(ptr %t160, ptr %t143, i64 %t144)
  %t161 = getelementptr i8, ptr %t160, i64 %t144
  %t162 = call i64 @__olang_fmt_i64(ptr %t161, i64 %t145)
  %t163 = getelementptr i8, ptr %t161, i64 %t146
  call void @olang_textcopy(ptr %t163, ptr %t148, i64 %t149)
  %t164 = getelementptr i8, ptr %t163, i64 %t149
  %t165 = call i64 @__olang_fmt_i64(ptr %t164, i64 %t151)
  %t166 = getelementptr i8, ptr %t164, i64 %t152
  call void @olang_textcopy(ptr %t166, ptr %t154, i64 %t155)
  %t167 = getelementptr i8, ptr %t166, i64 %t155
  %t168 = call i64 @__olang_fmt_i64(ptr %t167, i64 %t157)
  %t169 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t160, 1
  %t172 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t172, { i64, ptr } %t170)
  br label %bb36
bb36:
  %t174 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 4
  %t175 = load i64, ptr %l14, !tbaa !24
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t174, i64 %t175)
  store i64 %t178, ptr %l88
  br label %bb37
bb37:
  %t179 = load i64, ptr %l88, !tbaa !24
  %t180 = icmp slt i64 %t179, 0
  br i1 %t180, label %bb38, label %bb39
bb38:
  %t182 = load i64, ptr %l14, !tbaa !24
  store i64 %t182, ptr %l91, !tbaa !24
  %t183 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 7
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t183)
  store i64 %t185, ptr %l93
  br label %bb40
bb39:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb41
bb40:
  %t186 = load i64, ptr %l91, !tbaa !24
  %t187 = load i64, ptr %l93, !tbaa !24
  %t188 = icmp slt i64 %t186, %t187
  store i1 %t188, ptr %l90, !tbaa !21
  br label %bb41
bb41:
  %t190 = load i1, ptr %l90, !tbaa !21
  br i1 %t190, label %bb42, label %bb43
bb42:
  %t191 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 7
  %t192 = load i64, ptr %l14, !tbaa !24
  %t195 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t191, i64 %t192)
  store i64 %t195, ptr %l98
  br label %bb44
bb43:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb45
bb44:
  %t196 = load i64, ptr %l98, !tbaa !24
  %t197 = icmp sge i64 %t196, 0
  store i1 %t197, ptr %l95, !tbaa !21
  br label %bb45
bb45:
  %t199 = load i1, ptr %l95, !tbaa !21
  br i1 %t199, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l2, ptr %l100, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/load:Loader", ptr %t200, i32 0, i32 10
  store ptr %t202, ptr %l102, !tbaa !29
  %t203 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 7
  %t204 = load i64, ptr %l14, !tbaa !24
  %t207 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t203, i64 %t204)
  store i64 %t207, ptr %l105
  br label %bb48
bb47:
  br label %bb54
bb48:
  %t208 = load ptr, ptr %l102, !tbaa !29
  %t209 = load i64, ptr %l105, !tbaa !24
  %t210 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t208, i64 %t209)
  store ptr %t210, ptr %l106
  br label %bb49
bb49:
  %t211 = load ptr, ptr %l106, !tbaa !29
  %t213 = getelementptr %"compiler/load:Module", ptr %t211, i32 0, i32 2
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  store { i64, ptr } %t214, ptr %l108, !tbaa !27
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/load:Loader", ptr %t215, i32 0, i32 3
  %t218 = load ptr, ptr %t217, !tbaa !29
  store ptr %t218, ptr %l110, !tbaa !29
  %t219 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 8
  %t220 = load i64, ptr %l14, !tbaa !24
  %t223 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s2, ptr %t219, i64 %t220)
  store i32 %t223, ptr %l113
  br label %bb50
bb50:
  %t224 = load ptr, ptr %l110, !tbaa !29
  %t225 = load i32, ptr %l113, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s10, ptr %t224, i32 %t225)
  store { i64, ptr } %t226, ptr %l114
  br label %bb51
bb51:
  %t227 = getelementptr %"compiler/eval:Blob", ptr %l5, i32 0, i32 9
  %t228 = load i64, ptr %l14, !tbaa !24
  %t231 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t227, i64 %t228)
  store i64 %t231, ptr %l117
  br label %bb52
bb52:
  %t232 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t234 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 1
  %t236 = extractvalue { i64, ptr } %t234, 0
  %t237 = add i64 %t233, %t236
  %t238 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t240 = add i64 %t237, %t239
  %t241 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 1
  %t243 = extractvalue { i64, ptr } %t241, 0
  %t244 = add i64 %t240, %t243
  %t245 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t246 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t247 = add i64 %t244, %t246
  %t248 = load i64, ptr %l117, !tbaa !24
  %t249 = call i64 @__olang_fmt_i64(ptr null, i64 %t248)
  %t250 = add i64 %t247, %t249
  %t251 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t232, i64 %t233)
  %t252 = getelementptr i8, ptr %t251, i64 %t233
  call void @olang_textcopy(ptr %t252, ptr %t235, i64 %t236)
  %t253 = getelementptr i8, ptr %t252, i64 %t236
  call void @olang_textcopy(ptr %t253, ptr %t238, i64 %t239)
  %t254 = getelementptr i8, ptr %t253, i64 %t239
  call void @olang_textcopy(ptr %t254, ptr %t242, i64 %t243)
  %t255 = getelementptr i8, ptr %t254, i64 %t243
  call void @olang_textcopy(ptr %t255, ptr %t245, i64 %t246)
  %t256 = getelementptr i8, ptr %t255, i64 %t246
  %t257 = call i64 @__olang_fmt_i64(ptr %t256, i64 %t248)
  %t258 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t251, 1
  %t261 = load ptr, ptr %l100, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t261, { i64, ptr } %t259)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s10)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  %t263 = load i64, ptr %l13, !tbaa !24
  %t266 = add i64 %t263, 1
  store i64 %t266, ptr %l13, !tbaa !24
  br label %bb29
bb56:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) })
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s2)
  br label %bb58
bb58:
  %t269 = load i64, ptr %l4, !tbaa !24
  %t272 = add i64 %t269, 1
  store i64 %t272, ptr %l4, !tbaa !24
  br label %bb2
bb59:
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t276 = getelementptr %"compiler/eval:Image", ptr %t274, i32 0, i32 2
  %t277 = load i1, ptr %t276, !tbaa !21
  br i1 %t277, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s14
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l2, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_scope_close(ptr %s14)
  br label %bb63
bb63:
  %t281 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t281, ptr %l131
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t282 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t282, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2frecords_2eothers(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l13 = alloca %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8"
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i1
  %l53 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca i1
  %l70 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l71 = alloca %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8"
  %l73 = alloca %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8"
  %l74 = alloca i32
  %l76 = alloca i1
  %l80 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca i64
  %l96 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t2, ptr %lp4
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t4 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store i64 0, ptr %l5, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l20
  br label %bb2
bb2:
  %t11 = load i64, ptr %l20, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb5:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l27, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l27, !tbaa !24
  store i64 %t38, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l24, !tbaa !24
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l10, !tbaa !24
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v1, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l48
  br label %bb13
bb13:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l48, !tbaa !24
  %t69 = icmp ne i64 %t67, %t66
  br i1 %t69, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb18
bb15:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  store ptr %t74, ptr %l53, !tbaa !29
  %t75 = load i64, ptr %l10, !tbaa !24
  %t77 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t75)
  store i64 %t77, ptr %l55
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l53, !tbaa !29
  %t79 = load i64, ptr %l55, !tbaa !24
  %t80 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t78, i64 %t79)
  store i64 %t80, ptr %l56
  br label %bb17
bb17:
  %t81 = load i64, ptr %l56, !tbaa !24
  %t82 = icmp sgt i64 %t81, 0
  store i1 %t82, ptr %l51, !tbaa !21
  br label %bb18
bb18:
  %t84 = load i1, ptr %l51, !tbaa !21
  br i1 %t84, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb20:
  br label %bb21
bb21:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t86 = load i64, ptr %l10, !tbaa !24
  %t89 = call { i64, ptr } @compiler_2frecords_2esigLine(ptr %v1, ptr %v3, ptr %t85, i64 %t86)
  store { i64, ptr } %t89, ptr %l60
  br label %bb22
bb22:
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t90, ptr %lp11
  %t91 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t92 = load ptr, ptr %lp11
  store { i64, ptr } %t91, ptr %t92, !tbaa !27
  %t93 = load ptr, ptr %lp11
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  %t96 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s2, { i64, ptr } %t94, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d111, i32 0, i32 1) })
  store i1 %t96, ptr %l62
  br label %bb23
bb23:
  %t97 = load i1, ptr %l62, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb24, label %bb25
bb24:
  %t100 = load ptr, ptr %lp4
  %t101 = load ptr, ptr %lp11
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t100, { i64, ptr } %t102)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l9, !tbaa !24
  br label %bb9
bb29:
  %t112 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H22169a789cb544431edc747dee234bd5(ptr %v2, ptr %v2, ptr %a3)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t112, ptr %l70
  br label %bb30
bb30:
  %t113 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l70
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t113, ptr %l12
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t115 = call { i32, %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2feval_3aImage_3_Hb70b8ba6c3e879cab72ad6295e03d3b2(ptr %v2, ptr %s7, ptr %l12)
  %t116 = extractvalue { i32, %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8" } %t115, 1
  %t117 = extractvalue { i32, %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8" } %t115, 0
  store i32 %t117, ptr %l74
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb33, label %ok.119, !prof !99
ok.119:
  store %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8" %t116, ptr %l73
  br label %bb32
bb32:
  %t120 = load %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8", ptr %l73
  store %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8" %t120, ptr %l71
  br label %bb35
bb33:
  %t121 = load i32, ptr %l74, !tbaa !23
  %t122 = ashr i32 %t121, 16
  %t124 = icmp eq i32 %t122, 1
  store i1 %t124, ptr %l76, !tbaa !21
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb35:
  %t125 = load %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8", ptr %l71
  store %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8" %t125, ptr %l13
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 19
  %t129 = getelementptr %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8", ptr %l13, i32 0, i32 0
  %t130 = load i64, ptr %t129, !tbaa !24
  %t133 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v1, ptr %v1, ptr %t128, i64 %t130)
  store ptr %t133, ptr %l80
  br label %bb36
bb36:
  %t134 = load ptr, ptr %l80, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Body", ptr %t134, i32 0, i32 1
  %t137 = load { i64, [2 x i64] }, ptr %t136
  store { i64, [2 x i64] } %t137, ptr %l14
  %t139 = load { i64, [2 x i64] }, ptr %l14
  %t141 = extractvalue { i64, [2 x i64] } %t139, 0
  %t142 = icmp eq i64 %t141, 6
  br i1 %t142, label %bb37, label %bb38
bb37:
  %t144 = getelementptr { i64, [2 x i64] }, ptr %l14, i32 0, i32 1
  %t145 = getelementptr { i64, i32 }, ptr %t144, i32 0, i32 0
  %t146 = load i64, ptr %t145
  store i64 %t146, ptr %l15, !tbaa !24
  %t148 = getelementptr { i64, [2 x i64] }, ptr %l14, i32 0, i32 1
  %t149 = getelementptr { i64, i32 }, ptr %t148, i32 0, i32 1
  %t150 = load i32, ptr %t149
  store i32 %t150, ptr %l16, !tbaa !23
  br label %bb39
bb38:
  br label %bb48
bb39:
  %t152 = load i64, ptr %l15, !tbaa !24
  %t153 = load i64, ptr %l2, !tbaa !24
  %t156 = icmp eq i64 %t152, %t153
  br i1 %t156, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s9
  %t158 = load ptr, ptr %lp4
  store ptr %t158, ptr %l90, !tbaa !29
  %t159 = call ptr @__olang_scope_hold(ptr %v3)
  %t160 = ptrtoint ptr %t159 to i64
  store i64 %t160, ptr %l91, !tbaa !24
  %t161 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t161, label %bb42, label %bb43
bb41:
  br label %bb47
bb42:
  %t163 = call ptr @__olang_region_make(ptr %v3)
  %t164 = ptrtoint ptr %t163 to i64
  store i64 %t164, ptr %l91, !tbaa !24
  br label %bb43
bb43:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/load:Loader", ptr %t165, i32 0, i32 3
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t169 = load i32, ptr %l16, !tbaa !23
  %t172 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s9, ptr %t168, i32 %t169)
  store { i64, ptr } %t172, ptr %l96
  br label %bb44
bb44:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8", ptr %l13, i32 0, i32 1
  %t177 = call { i64, ptr } @compiler_2frecords_2eimageText(ptr %v0, ptr %s7, ptr %s9, ptr %t173, ptr %t174)
  store { i64, ptr } %t177, ptr %l99
  br label %bb45
bb45:
  %t178 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t180 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = add i64 %t179, %t182
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t186 = add i64 %t183, %t185
  %t187 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = add i64 %t186, %t189
  %t191 = load i64, ptr %l91
  %t192 = inttoptr i64 %t191 to ptr
  %t193 = call ptr @__olang_held_alloc(ptr %t192, i64 %t190)
  call void @olang_textcopy(ptr %t193, ptr %t178, i64 %t179)
  %t194 = getelementptr i8, ptr %t193, i64 %t179
  call void @olang_textcopy(ptr %t194, ptr %t181, i64 %t182)
  %t195 = getelementptr i8, ptr %t194, i64 %t182
  call void @olang_textcopy(ptr %t195, ptr %t184, i64 %t185)
  %t196 = getelementptr i8, ptr %t195, i64 %t185
  call void @olang_textcopy(ptr %t196, ptr %t188, i64 %t189)
  %t197 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t193, 1
  %t200 = load ptr, ptr %l90, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t200, { i64, ptr } %t198)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb47
bb47:
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_56acc6c2cad66900_a164af229476b69c)
  unreachable
bb53:
  call void @__olang_scope_close(ptr %s7)
  br label %bb54
bb54:
  br label %bb31
bb55:
  %t202 = load ptr, ptr %lp4
  %t203 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_114, 0
  %t204 = insertvalue { ptr, ptr } %t203, ptr null, 1
  %t207 = extractvalue { ptr, ptr } %t204, 0
  %t208 = extractvalue { ptr, ptr } %t204, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v3, ptr %s0, ptr %t202, ptr %t207, ptr %t208)
  br label %bb56
bb56:
  %t209 = load ptr, ptr %lp4
  %t210 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t209
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t210, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2frecords_2eruntimeStamp(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/os:FileInfo"
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca { i64, ptr }
  %l44 = alloca %"std/prelude/text:StringBuilder"
  %l46 = alloca i64
  %l48 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca %"std/os:FileInfo"
  %l59 = alloca %"std/os:FileInfo"
  %l60 = alloca i32
  %l62 = alloca i1
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t5 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l0, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s0, ptr %s0, { i64, ptr } %t13)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l17
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store { i64, ptr } %t16, ptr %l16
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t20, ptr %l14, !tbaa !27
  br label %bb7
bb3:
  %t21 = load i32, ptr %l17, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  store i1 %t24, ptr %l19, !tbaa !21
  %t25 = load i32, ptr %l17, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d116, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l24, !tbaa !24
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l25, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l24, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t44, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb7:
  %t46 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t46, ptr %l1, !tbaa !27
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l26
  br label %bb8
bb8:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l2
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t49, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t63, ptr %l34, !tbaa !27
  %t64 = load i64, ptr %l4, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %t67, i64 %t64
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t69)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %l4, !tbaa !24
  br label %bb9
bb15:
  %t79 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_117, 0
  %t80 = insertvalue { ptr, ptr } %t79, ptr null, 1
  %t83 = extractvalue { ptr, ptr } %t80, 0
  %t84 = extractvalue { ptr, ptr } %t80, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s0, ptr %s0, ptr %l2, ptr %t83, ptr %t84)
  br label %bb16
bb16:
  %t85 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t85, ptr %l44
  br label %bb17
bb17:
  %t86 = load %"std/prelude/text:StringBuilder", ptr %l44
  store %"std/prelude/text:StringBuilder" %t86, ptr %l7
  store ptr %l2, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s7
  %t88 = load i64, ptr %l9, !tbaa !24
  store i64 %t88, ptr %l46, !tbaa !24
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t89)
  store i64 %t91, ptr %l48
  br label %bb19
bb19:
  %t92 = load i64, ptr %l46, !tbaa !24
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s7)
  br label %bb32
bb21:
  br label %bb22
bb22:
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t98, i64 %t99)
  store { i64, ptr } %t102, ptr %l53
  br label %bb23
bb23:
  %t103 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t103, ptr %l10, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = extractvalue { i64, ptr } %t104, 0
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t113 = extractvalue { i64, ptr } %t105, 1
  %t114 = extractvalue { i64, ptr } %t105, 0
  %t115 = add i64 %t111, %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t115)
  call void @olang_textcopy(ptr %t116, ptr %t107, i64 %t108)
  %t117 = getelementptr i8, ptr %t116, i64 %t108
  call void @olang_textcopy(ptr %t117, ptr %t109, i64 %t110)
  %t118 = getelementptr i8, ptr %t117, i64 %t110
  call void @olang_textcopy(ptr %t118, ptr %t113, i64 %t114)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t116, 1
  %t123 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s7, { i64, ptr } %t120)
  %t124 = extractvalue { i32, %"std/os:FileInfo" } %t123, 1
  %t125 = extractvalue { i32, %"std/os:FileInfo" } %t123, 0
  store i32 %t125, ptr %l60
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb25, label %ok.127, !prof !99
ok.127:
  store %"std/os:FileInfo" %t124, ptr %l59
  br label %bb24
bb24:
  %t128 = load %"std/os:FileInfo", ptr %l59
  store %"std/os:FileInfo" %t128, ptr %l54
  br label %bb29
bb25:
  %t129 = load i32, ptr %l60, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  store i1 %t132, ptr %l62, !tbaa !21
  %t133 = load i32, ptr %l60, !tbaa !23
  %t134 = ashr i32 %t133, 16
  %t136 = icmp eq i32 %t134, 1
  br i1 %t136, label %bb26, label %bb27
bb26:
  call void @__olang_errpay_pop()
  br label %bb27
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb29:
  %t138 = load %"std/os:FileInfo", ptr %l54
  store %"std/os:FileInfo" %t138, ptr %l11
  %t139 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t140 = getelementptr %"std/os:FileInfo", ptr %l11, i32 0, i32 1
  %t141 = load i64, ptr %t140, !tbaa !24
  %t142 = getelementptr %"std/os:FileInfo", ptr %l11, i32 0, i32 2
  %t143 = load i64, ptr %t142, !tbaa !24
  %t145 = extractvalue { i64, ptr } %t139, 1
  %t146 = extractvalue { i64, ptr } %t139, 0
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t151 = call i64 @__olang_fmt_i64(ptr null, i64 %t141)
  %t152 = add i64 %t149, %t151
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t155 = add i64 %t152, %t154
  %t157 = call i64 @__olang_fmt_i64(ptr null, i64 %t143)
  %t158 = add i64 %t155, %t157
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t145, i64 %t146)
  %t163 = getelementptr i8, ptr %t162, i64 %t146
  call void @olang_textcopy(ptr %t163, ptr %t147, i64 %t148)
  %t164 = getelementptr i8, ptr %t163, i64 %t148
  %t165 = call i64 @__olang_fmt_i64(ptr %t164, i64 %t141)
  %t166 = getelementptr i8, ptr %t164, i64 %t151
  call void @olang_textcopy(ptr %t166, ptr %t153, i64 %t154)
  %t167 = getelementptr i8, ptr %t166, i64 %t154
  %t168 = call i64 @__olang_fmt_i64(ptr %t167, i64 %t143)
  %t169 = getelementptr i8, ptr %t167, i64 %t157
  call void @olang_textcopy(ptr %t169, ptr %t159, i64 %t160)
  %t170 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t162, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l7, { i64, ptr } %t171)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb31:
  %t175 = load i64, ptr %l9, !tbaa !24
  %t178 = add i64 %t175, 1
  store i64 %t178, ptr %l9, !tbaa !24
  br label %bb18
bb32:
  %t181 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l7)
  store { i64, ptr } %t181, ptr %l75
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t182 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t182, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2frecords_2escopeRecord(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l13 = alloca i1
  %l17 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l23 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l43 = alloca { i64, ptr }
  %l45 = alloca i1
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l57 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i1
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca %"std/prelude/text:LineIter"
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i32
  %l72 = alloca i1
  %l74 = alloca i1
  %l76 = alloca i1
  %l81 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l84 = alloca i1
  %l88 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca i64
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l11, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l13, !tbaa !21
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t19 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t19, ptr %rv
  br label %ret
bb6:
  %t20 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d121, i32 0, i32 1) })
  %t24 = extractvalue { i32, i64 } %t23, 1
  %t25 = extractvalue { i32, i64 } %t23, 0
  store i32 %t25, ptr %l20
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb8, label %ok.27, !prof !99
ok.27:
  store i64 %t24, ptr %l19
  br label %bb7
bb7:
  %t28 = load i64, ptr %l19, !tbaa !24
  store i64 %t28, ptr %l17, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t30 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t30, ptr %rv
  br label %ret
bb10:
  %t31 = load i64, ptr %l17, !tbaa !24
  %t32 = add i64 %t31, 4
  store i64 %t32, ptr %l3, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l23, !tbaa !27
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 5
  store i64 %t37, ptr %l25, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 0
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l29, !tbaa !24
  %t44 = load i64, ptr %l25, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = load i64, ptr %l25, !tbaa !24
  %t48 = load i64, ptr %l28, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_c9a03e1a2ccd76e3_8f1e713d9da8bd47)
  unreachable
bb13:
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = load i64, ptr %l29, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_c9a03e1a2ccd76e3_8f1e713d9da8bd47)
  unreachable
bb15:
  %t55 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l25, !tbaa !24
  %t58 = load i64, ptr %l28, !tbaa !24
  %t59 = getelementptr i8, ptr %t56, i64 %t57
  %t60 = sub i64 %t58, %t57
  %t61 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  %t64 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s0, { i64, ptr } %t62)
  store { i64, ptr } %t64, ptr %l34
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_c9a03e1a2ccd76e3_8f1e713d9da8bd47)
  unreachable
bb17:
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t65, ptr %l35, !tbaa !27
  %t66 = load i64, ptr %l3, !tbaa !24
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l37, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l38, !tbaa !24
  %t71 = icmp sge i64 0, 0
  br i1 %t71, label %bb18, label %bb19
bb18:
  %t73 = load i64, ptr %l37, !tbaa !24
  %t74 = icmp sle i64 0, %t73
  br i1 %t74, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_c9a03e1a2ccd76e3_8f1e713d9da8bd47)
  unreachable
bb20:
  %t76 = load i64, ptr %l37, !tbaa !24
  %t77 = load i64, ptr %l38, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_c9a03e1a2ccd76e3_8f1e713d9da8bd47)
  unreachable
bb22:
  %t80 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l37, !tbaa !24
  %t83 = getelementptr i8, ptr %t81, i64 0
  %t84 = sub i64 %t82, 0
  %t85 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  %t88 = call { i64, ptr } @compiler_2frecords_2esumOf(ptr %s0, ptr %s0, { i64, ptr } %t86)
  store { i64, ptr } %t88, ptr %l43
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_c9a03e1a2ccd76e3_8f1e713d9da8bd47)
  unreachable
bb24:
  %t89 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t92 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t90, { i64, ptr } %t89)
  store i1 %t92, ptr %l45
  br label %bb25
bb25:
  %t93 = load i1, ptr %l45, !tbaa !21
  %t94 = xor i1 %t93, true
  br i1 %t94, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t97 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t97, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t98, ptr %l48, !tbaa !27
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l50, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l51, !tbaa !24
  %t104 = icmp sge i64 0, 0
  br i1 %t104, label %bb29, label %bb30
bb29:
  %t106 = load i64, ptr %l50, !tbaa !24
  %t107 = icmp sle i64 0, %t106
  br i1 %t107, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_c948c74961a5cc06_d4f9b1858678796a)
  unreachable
bb31:
  %t109 = load i64, ptr %l50, !tbaa !24
  %t110 = load i64, ptr %l51, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_c948c74961a5cc06_d4f9b1858678796a)
  unreachable
bb33:
  %t113 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l50, !tbaa !24
  %t116 = getelementptr i8, ptr %t114, i64 0
  %t117 = sub i64 %t115, 0
  %t118 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t116, 1
  store { i64, ptr } %t119, ptr %l4, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t121, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store i1 %t123, ptr %l57
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_c948c74961a5cc06_d4f9b1858678796a)
  unreachable
bb35:
  %t124 = load i1, ptr %l57, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb39
bb37:
  %t127 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s0, { i64, ptr } %t127, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d123, i32 0, i32 1) })
  store i1 %t129, ptr %l61
  br label %bb38
bb38:
  %t130 = load i1, ptr %l61, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l59, !tbaa !21
  br label %bb39
bb39:
  %t133 = load i1, ptr %l59, !tbaa !21
  br i1 %t133, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t135 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t135, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t136 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %l64
  br label %bb43
bb43:
  %t137 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %l5
  %t138 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t140 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t138)
  store %"std/prelude/text:LineIter" %t140, ptr %l66
  br label %bb44
bb44:
  %t141 = load %"std/prelude/text:LineIter", ptr %l66
  store %"std/prelude/text:LineIter" %t141, ptr %l6
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s6
  %t143 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l6)
  %t144 = extractvalue { i32, { i64, ptr } } %t143, 1
  %t145 = extractvalue { i32, { i64, ptr } } %t143, 0
  store i32 %t145, ptr %l70
  %t146 = icmp ne i32 %t145, 0
  br i1 %t146, label %bb47, label %ok.147, !prof !99
ok.147:
  store { i64, ptr } %t144, ptr %l69
  br label %bb46
bb46:
  %t148 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t148, ptr %l67, !tbaa !27
  br label %bb49
bb47:
  %t149 = load i32, ptr %l70, !tbaa !23
  %t150 = ashr i32 %t149, 16
  %t152 = icmp eq i32 %t150, 1
  store i1 %t152, ptr %l72, !tbaa !21
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb49:
  %t153 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t153, ptr %l7, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t156 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t154, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d124, i32 0, i32 1) })
  store i1 %t156, ptr %l74
  br label %bb50
bb50:
  %t157 = load i1, ptr %l74, !tbaa !21
  br i1 %t157, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb52:
  br label %bb53
bb53:
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t158, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d125, i32 0, i32 1) })
  store i1 %t160, ptr %l76
  br label %bb54
bb54:
  %t161 = load i1, ptr %l76, !tbaa !21
  br i1 %t161, label %bb55, label %bb56
bb55:
  %t162 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t162)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb59:
  br label %bb45
bb60:
  %t167 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 3
  store ptr %t170, ptr %l81, !tbaa !29
  %t172 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t172, ptr %l83
  br label %bb61
bb61:
  %t173 = load ptr, ptr %l81, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t175 = call i1 @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eHolds(ptr %v0, ptr %s0, ptr %t173, { i64, ptr } %t174)
  store i1 %t175, ptr %l84
  br label %bb62
bb62:
  %t176 = load i1, ptr %l84, !tbaa !21
  %t177 = xor i1 %t176, true
  br i1 %t177, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s0)
  %t180 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t180, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t181 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fbuild_2eTouch(ptr %v1, { i64, ptr } %t181)
  br label %bb66
bb66:
  %t183 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t183, ptr %l88, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t188 = sub i64 %t186, 4
  store i64 %t188, ptr %l91, !tbaa !24
  %t189 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  store i64 %t190, ptr %l92, !tbaa !24
  %t191 = icmp sge i64 0, 0
  br i1 %t191, label %bb67, label %bb68
bb67:
  %t193 = load i64, ptr %l91, !tbaa !24
  %t194 = icmp sle i64 0, %t193
  br i1 %t194, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_710d0d27a6917125_e2a9a4f84e1a9609)
  unreachable
bb69:
  %t196 = load i64, ptr %l91, !tbaa !24
  %t197 = load i64, ptr %l92, !tbaa !24
  %t198 = icmp sle i64 %t196, %t197
  br i1 %t198, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_710d0d27a6917125_e2a9a4f84e1a9609)
  unreachable
bb71:
  %t200 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l91, !tbaa !24
  %t203 = getelementptr i8, ptr %t201, i64 0
  %t204 = sub i64 %t202, 0
  %t205 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t203, 1
  store { i64, ptr } %t206, ptr %l97, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  store i64 %t209, ptr %l98, !tbaa !24
  %t210 = load i64, ptr %l98, !tbaa !24
  %t211 = mul i64 %t210, 1
  %t212 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t211)
  %t213 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  store { i64, ptr } %t214, ptr %l99, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = load i64, ptr %l98, !tbaa !24
  %t220 = mul i64 %t219, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t216, ptr %t218, i64 %t220, i1 false)
  %t221 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t221, ptr %l97, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t222 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t223 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t222, 1
  store { i32, { i64, ptr } } %t223, ptr %rv
  br label %ret
bb72:
  call void @__olang_check_failed(ptr @olang_loc_710d0d27a6917125_e2a9a4f84e1a9609)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2frecords_2esigLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l45 = alloca i32
  %l48 = alloca { i64, ptr }
  %l53 = alloca i1
  %l57 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t4, i64 %t5, i32 0)
  store i64 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i64, ptr %l13, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t10, i64 %t11)
  store i64 %t14, ptr %l16
  br label %bb2
bb2:
  %t15 = load i64, ptr %l16, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t16, 0
  br i1 %t18, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l20, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l21, !tbaa !24
  %t23 = load i64, ptr %l21, !tbaa !24
  %t24 = mul i64 %t23, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l22, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = mul i64 %t32, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  %t34 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t34, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t35 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t35, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l2, !tbaa !24
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t39, i64 %t40)
  store i32 %t43, ptr %l26
  br label %bb6
bb6:
  %t44 = load i32, ptr %l26, !tbaa !23
  store i32 %t44, ptr %l4, !tbaa !23
  %t45 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t45, ptr %l27
  br label %bb7
bb7:
  %t46 = load %"std/prelude/text:StringBuilder", ptr %l27
  store %"std/prelude/text:StringBuilder" %t46, ptr %l5
  store ptr %l5, ptr %l28, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/load:Loader", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  store ptr %t56, ptr %l32, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t60, i64 %t61)
  store ptr %t64, ptr %l36
  br label %bb8
bb8:
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %t67, !tbaa !23
  %t69 = load ptr, ptr %l32, !tbaa !29
  %t71 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t69, i32 %t68)
  store { i64, ptr } %t71, ptr %l39
  br label %bb9
bb9:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 19
  %t75 = load i64, ptr %l3, !tbaa !24
  %t78 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t74, i64 %t75)
  store ptr %t78, ptr %l43
  br label %bb10
bb10:
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Body", ptr %t79, i32 0, i32 4
  %t82 = getelementptr %"compiler/source:Span", ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82, !tbaa !23
  store i32 %t83, ptr %l45, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t84, i32 %t85)
  store { i64, ptr } %t88, ptr %l48
  br label %bb11
bb11:
  %t89 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t91 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = add i64 %t90, %t93
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t97 = add i64 %t94, %t96
  %t98 = load i32, ptr %l45, !tbaa !23
  %t99 = sext i32 %t98 to i64
  %t100 = call i64 @__olang_fmt_i64(ptr null, i64 %t99)
  %t101 = add i64 %t97, %t100
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t105 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t108 = add i64 %t104, %t107
  %t109 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t89, i64 %t90)
  %t110 = getelementptr i8, ptr %t109, i64 %t90
  call void @olang_textcopy(ptr %t110, ptr %t92, i64 %t93)
  %t111 = getelementptr i8, ptr %t110, i64 %t93
  call void @olang_textcopy(ptr %t111, ptr %t95, i64 %t96)
  %t112 = getelementptr i8, ptr %t111, i64 %t96
  %t113 = call i64 @__olang_fmt_i64(ptr %t112, i64 %t99)
  %t114 = getelementptr i8, ptr %t112, i64 %t100
  call void @olang_textcopy(ptr %t114, ptr %t102, i64 %t103)
  %t115 = getelementptr i8, ptr %t114, i64 %t103
  call void @olang_textcopy(ptr %t115, ptr %t106, i64 %t107)
  %t116 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t109, 1
  %t119 = load ptr, ptr %l28, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t119, { i64, ptr } %t117)
  br label %bb12
bb12:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l4, !tbaa !23
  %t125 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %t121, i32 %t122)
  store i1 %t125, ptr %l53
  br label %bb13
bb13:
  %t126 = load i1, ptr %l53, !tbaa !21
  br i1 %t126, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l5, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d130, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb27
bb16:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  store ptr %t133, ptr %l57, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l3, !tbaa !24
  %t138 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %t134, i64 %t135)
  store i32 %t138, ptr %l60
  br label %bb17
bb17:
  %t139 = load ptr, ptr %l57, !tbaa !29
  %t140 = load i32, ptr %l60, !tbaa !23
  %t141 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t139, i32 %t140)
  store { i64, ptr } %t141, ptr %l61
  br label %bb18
bb18:
  %t142 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t142, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  store i64 %t145, ptr %l8, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t147 = load i64, ptr %l7, !tbaa !24
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb21:
  br label %bb22
bb22:
  %t155 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t155, ptr %l68, !tbaa !27
  %t156 = load i64, ptr %l7, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr i32, ptr %t159, i64 %t156
  %t161 = load i32, ptr %t160, !tbaa !33
  store ptr %l5, ptr %l71, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s5, ptr %t163, i32 %t161)
  store { i64, ptr } %t167, ptr %l74
  br label %bb23
bb23:
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t170 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = add i64 %t169, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t168, i64 %t169)
  %t175 = getelementptr i8, ptr %t174, i64 %t169
  call void @olang_textcopy(ptr %t175, ptr %t171, i64 %t172)
  %t176 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t174, 1
  %t179 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t179, { i64, ptr } %t177)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  %t181 = load i64, ptr %l7, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l7, !tbaa !24
  br label %bb19
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  %t187 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t187, ptr %l81
  br label %bb28
bb28:
  %t188 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = extractvalue { i64, ptr } %t188, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d132, i32 0, i32 1) }, ptr %l84, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, ptr %l85, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t199 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, ptr %s0, ptr %v1, { i64, ptr } %t195, { i64, ptr } %t197, { i64, ptr } %t198)
  store { i64, ptr } %t199, ptr %l86
  br label %bb29
bb29:
  %t200 = load { i64, ptr }, ptr %l86, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t200, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d0 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
declare void @__olang_errpay_pop()
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" prof" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" listing" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" fuzz" }>, align 8
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" bench" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" checked" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" late" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" pairdot" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.c21 = private unnamed_addr constant [5 x i8] c"true\00"
@.c22 = private unnamed_addr constant [6 x i8] c"false\00"
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d23 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"olang: incremental check: " }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d25 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"olang: incremental check: " }>, align 8
@.d26 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d27 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" kept summaries differ\0A" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/rec" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d31 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/rec/" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/rec" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d34 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"olang front record\0A" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d37 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"body " }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"end\0A" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sum " }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/rec" }>, align 8
@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"olang scope record\0A" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"end\0A" }>, align 8
@.d51 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sum " }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\0Aroot " }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d60 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"embed " }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d64 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define internal i1 @olang_lambda_65(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = icmp slt i64 %a0, %a1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d66 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define internal i1 @olang_lambda_67(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d69 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"OLANG_CHECKINCR" }>, align 8
@.d70 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d71 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d72 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d73 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/rec" }>, align 8
@.d74 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d76 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/rec/" }>, align 8
@.d77 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0Arun " }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d78 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
define internal i1 @olang_lambda_81(ptr %env, ptr %v0, ptr %v1, %"compiler/build:Held" %a0, %"compiler/build:Held" %a1) #0 {
entry:
  %l0 = alloca %"compiler/build:Held"
  %l1 = alloca %"compiler/build:Held"
  %rv = alloca i1
  store %"compiler/build:Held" %a0, ptr %l0
  store %"compiler/build:Held" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/build:Held", ptr %l0, i32 0, i32 3
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/build:Held", ptr %l1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = icmp sgt i64 %t2, %t4
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d82 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0 = weak hidden constant i1 false
@.d83 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d84 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/rec" }>, align 8
define linkonce_odr %"compiler/views:Cand" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fviews_3aCand(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/views:Cand"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/views:Cand"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/views:Cand", ptr %a0
  store %"compiler/views:Cand" %t2, ptr %l1
  %t3 = getelementptr %"compiler/views:Cand", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/views:Cand", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = getelementptr %"compiler/views:Cand", ptr %l1, i32 0, i32 2
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l5
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t12 = getelementptr %"compiler/views:Cand", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %t12
  %t13 = getelementptr %"compiler/views:Cand", ptr %l1, i32 0, i32 3
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l7
  br label %bb3
bb3:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t17 = getelementptr %"compiler/views:Cand", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t17
  %t18 = load %"compiler/views:Cand", ptr %l1
  store %"compiler/views:Cand" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:Cand", ptr %rv
  ret %"compiler/views:Cand" %rr
}

@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d87 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c": found '" }>, align 8
@.d88 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"', not in its record" }>, align 8
@.d89 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c": its record says '" }>, align 8
@.d90 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"', not found" }>, align 8
@.d91 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0Asum " }>, align 8
@.d92 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"olang front record" }>, align 8
@.d93 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"end" }>, align 8
@.d94 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"read " }>, align 8
@.d95 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"body " }>, align 8
@.d96 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sig " }>, align 8
@.d97 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"baked " }>, align 8
@.d98 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"0123456789abcdef" }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d100 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d101 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d102 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d103 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d104 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d105 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"+" }>, align 8
@.d106 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d109 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d110 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" mutable" }>, align 8
@.d111 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d112 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"baked " }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define internal i1 @olang_lambda_114(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d115 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/runtime" }>, align 8
@.d116 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define internal i1 @olang_lambda_117(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d120 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d121 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\0Aend\0Asum " }>, align 8
@.d122 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"olang scope record\0A" }>, align 8
@.d123 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"end\0A" }>, align 8
@.d124 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"run " }>, align 8
@.d125 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"read " }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d127 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sig " }>, align 8
@.d128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d129 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d130 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ?" }>, align 8
@.d131 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d132 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d133 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t12 = alloca %olang.slotscope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 16
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  %t8 = call ptr @__olang_scope_hold(ptr %v0)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_3e_2e_2d1
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %v0
  %t14 = icmp eq ptr %t13, @__olang_slot_chunk
  %t15 = getelementptr %olang.scope, ptr %v0, i32 0, i32 2
  %t16 = load ptr, ptr %t15
  %t17 = select i1 %t14, ptr %t16, ptr %v0
  store %olang.scope zeroinitializer, ptr %t12
  store ptr @__olang_slot_chunk, ptr %t12
  %t18 = getelementptr %olang.scope, ptr %t12, i32 0, i32 2
  store ptr %t17, ptr %t18
  %t19 = getelementptr %olang.slotscope, ptr %t12, i32 0, i32 1
  store i64 0, ptr %t19
  %t20 = ptrtoint ptr %t12 to i64
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp slt i64 %t21, %t22
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %t27, i64 %t25
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !37
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %t32, i64 %t30
  store { i64, ptr } %t29, ptr %t33, !tbaa !37
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %t36, i64 %t34
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !37
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb6, label %bb7
bb5:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
bb6:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %t46, i64 %t44
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !37
  store { i64, ptr } %t48, ptr %l9, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l10, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = load i64, ptr %l3
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call ptr @__olang_held_alloc(ptr %t54, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l11, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l10, !tbaa !24
  %t63 = mul i64 %t62, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %t61, i64 %t63, i1 false)
  %t64 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %t67, i64 %t65
  store { i64, ptr } %t64, ptr %t68, !tbaa !37
  br label %bb8
bb7:
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %t71, i64 %t69
  store { i64, ptr } zeroinitializer, ptr %t72, !tbaa !37
  br label %bb8
bb8:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t73, 1
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb3
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_3e_2e_2d1 = weak hidden constant i1 false
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFingerprint(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %a0)
declare void @std_2fos_2eExit(i32 %a0)
@olang_loc_fb666446bedbe7d2_84e447b691c6d3de = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2frecords_2efrontStem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_323c52581f8b1abf_a440e4b95536001b = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_9c5452f20d69d8c2_bc172545126ff01e = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aCand_3e_2ePush_3ccompiler_2fviews_3aCand_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/views:Cand" %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cs_H4aa8749bc5cf37a88c7557cdc2f2204a(ptr %v0, ptr %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ePid()
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cs_H5a6cbfc85b925203d0895958ef20509b(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_f22b8e51d216f7bc_367675fc034647b8 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRecords(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H0211835ad1df5edc8086b9b7bc878d6e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2frecords_2escopeStem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_54f44bc773787685_bd98309550db61e1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2frecords_2esumOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
@olang_loc_8d034036672d852_5fe6d572cc7f08a6 = external constant [0 x i8]
@olang_loc_55114c4c1f153b47_5d38716d9a9c2c3b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_9658ab26a60a31a4_8c8d053bf8a13660 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2eEmbedded(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_7fdbfc0a8c76ca86_bcbf652a9859a812 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
@olang_loc_e43862288177251d_fb6c75927359cd1 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eTokens(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Haef94f44435f0acde1bbcde30a350c1f(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eRecordLines(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i1 %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Ha9227021807533b22d8a6fac522f3c47(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H0fdbabf49251589cbd1b71c681b39072(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2eLen_H327daf8a5f05e7deba4c08807621a9fe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2eAt__Hb06c5aa34d45867a1decef3b510ab43e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_4e9604c680c7b950_9ac30b55dba7b9c = external constant [0 x i8]
@olang_loc_5b539dac05fcd02d_94c517b58e4a7909 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_c66c474bbb96a3ce_87152442c6a85c6a = external constant [0 x i8]
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eAddRecord(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_9ddf5b6d72b888b0_7ac7d96e6bd8ca04 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2eHoldings(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2eSort_3cco_Hab5ed93197c78b68858212b8060a2c8d(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2eLen_3ccompiler_2fbuild_3aHeld_3e(ptr %v0, ptr %a0)
declare %"compiler/build:Held" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2eAt_3ccompiler_2fbuild_3aHeld_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbuild_2eStemOf(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2ePush_3ccompiler_2fbuild_3aHeld_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Held" %a1)
declare i1 @compiler_2fbuild_2eDrop(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fbuild_2eTrim(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_58cc7f1bdd3662ce_92747872ad267992 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i64 @compiler_2fbuild_2eRecent()
@G_2ecompiler_2frecords_2eRecKeys = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2frecords_2eRecCap = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/views:Cand" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aCand_3e_2eAt_3ccompiler_2fviews_3aCand_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_74134b5dcc105c42_96a34be2631e3c86 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_9fb4ac3de319e3f_96fac2b32e45e763 = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fiterator_2estd_2fprelude_2ftext_3aLineIter_2eToVec_3cstd_2fprelude_2ftex_H26ca3914517df8db224f03300752057f(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/views:Cand" @compiler_2fviews_3aCand_2ector(ptr %v0, i64 %a0)
@olang_loc_d6e69897ddbacd4_85b5c87fc3d2b148 = external constant [0 x i8]
declare void @compiler_2fbuild_2eTouch(ptr %v0, { i64, ptr } %a0)
@olang_loc_2727131baf418fd5_a166bfe6a37b2109 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H22169a789cb544431edc747dee234bd5(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.d73a415b3d3fe84ca844d285f54031b8" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2feval_3aImage_3_Hb70b8ba6c3e879cab72ad6295e03d3b2(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_56acc6c2cad66900_a164af229476b69c = external constant [0 x i8]
@olang_loc_c9a03e1a2ccd76e3_8f1e713d9da8bd47 = external constant [0 x i8]
@olang_loc_c948c74961a5cc06_d4f9b1858678796a = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eHolds(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_710d0d27a6917125_e2a9a4f84e1a9609 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
